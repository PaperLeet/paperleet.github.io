from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=r/'search-ui';out.mkdir(exist_ok=True)
a='38bb920f885bd64f4f276415de7fde86ae6f1dce';b='3e41c55ce0433023982b8f88b44f1a3f72f5a841';paths=subprocess.check_output(['git','diff','--name-only',a,b],cwd=repo,text=True).splitlines();assert len(paths)==6 and all(p.startswith('web/') for p in paths)
record=dict(status='retained_fast_forward',before=a,after=b,paths={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths},scope='Six interview/shared-search/component/style/check files; small final UI delta validated with affected suites and both production builds. No math/runtime/catalog/lock/policy/driver changes. Superseded seventeen-file snapshot identities remain bound to933e8886 Git blobs.')
(r/'upstream-sync-search.json').write_text(json.dumps(record,indent=2)+'\n');env=dict(os.environ,PATH='/opt/homebrew/bin:'+os.environ['PATH'],PYTHON=str(r.parent/'torch-iteration-21/stride-dev-env/bin/python'));receipts=[]
plans=[(['/opt/homebrew/bin/node',str(repo/'web/scripts'/('check-'+name+'.mjs'))],name,repo/'web') for name in ('interview-search','interview-ranking','interviews','interview-ui','community-search','community-feed-filters','community-discovery','community-navigation','interview-saved','interview-report-practice')]
profile=json.loads((r/'integration-proof/pages-profile.json').read_text())['environment']
plans+=[(['npm','run','build'],'production-build',repo/'web'),(['npm','run','build'],'pages-profile-build',repo/'web')]
for args,name,cwd in plans:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:result=subprocess.run(args,cwd=cwd,env={**env,**(profile if name=='pages-profile-build' else {})},stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(name=name,exit_code=result.returncode,elapsed_s=time.monotonic()-start,args=args));(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,'TERMINAL',result.returncode,flush=True);result.check_returncode()
expected=json.loads((r/'proof/source-hashes.json').read_text())
for name,digest in expected.items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==digest
for name,digest in json.loads((r/'integration-proof/live-expected-sha256.json').read_text()).items():assert hashlib.sha256((repo/'web/public/data'/name).read_bytes()).hexdigest()==digest
print('FINAL5_UI_DELTA_TERMINAL0;50source+161exports unchanged',flush=True)
