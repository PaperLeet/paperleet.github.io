from pathlib import Path
import os,shutil,subprocess,sys
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
subprocess.check_call([sys.executable,str(r/'audit-main.py'),sys.argv[1]],cwd=repo)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip()
gh=shutil.which('gh');assert gh
binary='/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/fallback/git'
env={k:v for k,v in os.environ.items() if not k.startswith('GIT_TRACE') and k not in ('GIT_CURL_VERBOSE','GH_DEBUG')}
subprocess.check_call([binary,'-c','http.version=HTTP/1.1','-c','http.postBuffer=524288000','-c','push.followTags=false','-c','credential.helper=','-c','credential.helper=!'+gh+' auth git-credential','push','origin','HEAD:main'],cwd=repo,env=env)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=repo,text=True).split()[0];assert head==remote;print('EXACT_REMOTE_MAIN',head,flush=True)
