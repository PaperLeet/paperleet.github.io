from pathlib import Path
import hashlib,json,shutil,subprocess,time
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');p=r/'integration-proof';py=r.parent/'torch-iteration-21/stride-dev-env/bin/python'
front=json.loads((p/'frontend-receipts.json').read_text());assert len(front)==5 and all(v['exit_code']==0 for v in front)
gates=json.loads((r/'proof/gate-receipts.json').read_text());assert len(gates)==6 and all(v['exit_code']==0 for v in gates.values())
shutil.copytree(p,r/'before-empty-optimization/integration-proof',ignore=shutil.ignore_patterns('*-env','*-venv','__pycache__','.pytest_cache'),dirs_exist_ok=True)
old=json.loads((p/'live-expected-sha256.json').read_text());owned=[name for name in old if name.startswith(('browser-judge/','modules/'))];assert len(owned)==158
cached=set(subprocess.check_output(['git','ls-files','-z','--','web/public/data'],cwd=repo).decode().split('\0'))
for name in owned:
 file=repo/'web/public/data'/name;assert 'web/public/data/'+name not in cached
 assert hashlib.sha256(file.read_bytes()).hexdigest()==old[name]
assert len(cached)>9755
for name in owned:(repo/'web/public/data'/name).unlink()
(p/'retired-local-prototype-assets.json').write_text(json.dumps(dict(scope='158 owned,untracked,unpublished preliminary0.43 assets; all9755 tracked prior payloads retained; historical bytes in before-empty-optimization/integration-proof/live-expected',assets={name:old[name] for name in owned}),indent=2)+'\n')
for file in (r/'proof/private-dist').iterdir():
 if file.suffix in ('.whl','.gz'):shutil.copy2(file,p/'dist-paperleet'/file.name)
subprocess.check_call([str(py),str(p/'run-setup.py')],cwd=repo)
expected=json.loads((r/'proof/source-hashes.json').read_text());actual={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (repo/'packages/stridetorch/src/stridetorch').iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')};assert actual==expected
receipts=json.loads((p/'setup-receipts.json').read_text());assert len(receipts)==3 and all(v['exit_code']==0 for v in receipts)
receipts.append(dict(script='final-exact-source-recheck',exit_code=0,resources=len(actual)));(p/'setup-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
subprocess.check_call([str(py),str(p/'run-wasm.py')],cwd=repo)
print('FINAL EXPORTED GENERATION TERMINAL0',flush=True)
