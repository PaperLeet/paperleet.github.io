from pathlib import Path
import gc,json,tracemalloc
import numpy as np
from bench_max_pooling_1d import load
r=Path(__file__).resolve().parent;results=[];identities={}
for label,folder in [('initial_043',r/'before-empty-optimization/proof/source'),('final_043',r/'proof/source')]:
 package,hashes=load('empty_'+label,folder);identities[label]=hashes
 for algorithm in ('scan','window','block','auto'):
  engine=__import__(package.__name__+'._pooling',fromlist=['_ALGORITHM']);engine._ALGORITHM=algorithm
  x=package.torch.zeros(0,1,200,200,200,requires_grad=True)
  gc.collect();tracemalloc.start();y,i=package.torch.nn.functional.max_pool3d(x,1,return_indices=True);current,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
  assert y.shape==i.shape==x.shape and y.numel()==i.numel()==0 and i.dtype==package.torch.int64
  y.sum().backward();assert x.grad.shape==x.shape
  _,tan=package.torch.func.jvp(lambda z:package.torch.max_pool3d(z,1),(x,),(package.torch.ones_like(x),));assert tan.shape==x.shape
  results.append(dict(source=label,algorithm=algorithm,peak_traced_bytes=peak,retained_traced_bytes=current));del x,y,i,tan
for algorithm in ('scan','window','block','auto'):
 old,new=[next(row for row in results if row['source']==label and row['algorithm']==algorithm)['peak_traced_bytes'] for label in ('initial_043','final_043')]
 assert old>64_000_000 and new<1_000_000,(algorithm,old,new)
report=dict(status='success',numpy=np.__version__,source_hashes=identities,results=results,scope='Single traced-allocation call/route on the same empty0x1x200x200x200 input with returned indices; source-bound initial and final unreleased0.43 implementations both support3D. Independent VJP/JVP checks follow outside tracing. NumPy allocations observed by Python tracemalloc,not process RSS,WASM memory or timing.')
(r/'empty-allocation-proof.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(results),flush=True)
