from pathlib import Path
import hashlib,json,subprocess,sys
repo=Path('/Users/david/Developer/PaperLeet-torch-release');r=Path(__file__).resolve().parent
expected=sys.argv[1];remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=repo,text=True).split()[0]
runs=json.loads(subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/runs?per_page=100'],cwd=repo,text=True))['workflow_runs']
active=[dict(id=v['id'],name=v['name'],event=v['event'],status=v['status'],head_sha=v['head_sha'],url=v['html_url']) for v in runs if v['status']!='completed' and v['name'] in ('PaperLeet quality gate','Publish PaperLeet public site')]
policy=json.loads((r/'release-policy-identity.json').read_text())
for name,digest in policy['files'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
source=json.loads((r/'proof/source-hashes.json').read_text())
for name,digest in source.items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==digest
for name,digest in json.loads((r/'integration-proof/live-expected-sha256.json').read_text()).items():assert hashlib.sha256((repo/'web/public/data'/name).read_bytes()).hexdigest()==digest
report=dict(expected_remote=expected,actual_remote=remote,active_release_chains=active,allowed=remote==expected and not active,source_resources=len(source),release_policies=len(policy['files']),export_identities=161)
(r/'latest-main-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));sys.exit(0 if report['allowed'] else 2)
