from pathlib import Path
import argparse,json,pickle,time
import numpy as np
p=argparse.ArgumentParser();p.add_argument('mode',choices=['reference','compare']);p.add_argument('--algorithm',choices=['auto','scan','window','block'],default='auto');args=p.parse_args()
if args.mode=='reference':import torch
else:
 from stridetorch import torch,_pooling
 _pooling._ALGORITHM=args.algorithm
r=Path(__file__).resolve().parent;rng=np.random.default_rng(430310)
results=[];started=time.monotonic()
for n in range(220):
 shape=(int(rng.integers(1,3)),int(rng.integers(1,4)),*map(int,rng.integers(1,9,size=3)))
 if n%11==0:shape=(0,*shape[1:])
 if n%7==0:shape=shape[1:]
 k=tuple(map(int,rng.integers(1,4,size=3)));s=tuple(map(int,rng.integers(1,4,size=3)))
 pad=tuple(int(rng.integers(0,kk//2+1)) for kk in k);d=tuple(map(int,rng.integers(1,3,size=3)));ceil=bool(n%2)
 dtype=np.float64 if n%2 else np.float32
 a=rng.integers(-3,4,size=shape).astype(dtype)
 if n%13==0 and a.size:a.reshape(-1)[::7]=np.nan
 if n%17==0:a.fill(-np.inf)
 layout=n%4
 if layout==1:a=np.asfortranarray(a)
 if layout==2:a=np.repeat(a,2,axis=-1)[...,::2]
 if layout==3 and a.ndim==5:a=a.transpose(0,2,3,4,1).copy().transpose(0,4,1,2,3)
 x=torch.from_numpy(a)
 try:y,i=torch.nn.functional.max_pool3d(x,k,s,pad,d,ceil,True)
 except Exception as e:
  results.append({'error':type(e).__name__});continue
 entry={'value':y.detach().numpy().copy(),'index':i.numpy().copy(),'value_stride':y.stride(),'index_stride':i.stride()}
 seed=rng.normal(size=y.shape).astype(dtype);direction=rng.normal(size=shape).astype(dtype)
 # Do not invoke unsafe native derivatives for windows without actual samples.
 safe=not i.numel() or all(any(0 <= pos*step-pad0+tap*dil < size for tap in range(kernel))
  for size,kernel,step,pad0,dil,count in zip(shape[-3:],k,s,pad,d,y.shape[-3:]) for pos in range(count))
 if safe:
  x.requires_grad_();y,i=torch.nn.functional.max_pool3d(x,k,s,pad,d,ceil,True)
  y.backward(torch.tensor(seed));entry['grad']=x.grad.numpy().copy();entry['grad_stride']=x.grad.stride();x.grad=None
  v=torch.tensor(direction,requires_grad=True)
  _,tan=torch.func.jvp(lambda z:torch.nn.functional.max_pool3d(z,k,s,pad,d,ceil),(x,),(v,))
  entry['tangent']=tan.detach().numpy().copy();entry['tangent_stride']=tan.stride()
  tan.backward(torch.tensor(seed));entry['reverse_tangent']=v.grad.numpy().copy()
 results.append(entry)
# Validate all supported inference dtypes with and without indices.
for dtype in (np.float16,np.float32,np.float64,np.int8,np.int16,np.int32,np.int64,np.uint8):
 for idx in (False,True):
  a=np.arange(216).astype(dtype).reshape(1,1,6,6,6)
  ret=torch.nn.functional.max_pool3d(torch.from_numpy(a),3,2,1,return_indices=idx)
  if not idx:ret=(ret,)
  results.append({f'output{j}':t.numpy() for j,t in enumerate(ret)})
if args.mode=='reference':
 with (r/'native-reference.pkl').open('wb') as f:pickle.dump(results,f)
 receipt={'mode':args.mode,'torch_version':torch.__version__,'trials':len(results),'valid_random':sum('value' in x for x in results[:220]),'elapsed_s':time.monotonic()-started}
else:
 with (r/'native-reference.pkl').open('rb') as f:expected=pickle.load(f)
 for n,(want,got) in enumerate(zip(expected,results)):
  assert want.keys()==got.keys(),(n,want.keys(),got.keys())
  for key in want:
   if isinstance(want[key],np.ndarray):np.testing.assert_allclose(got[key],want[key],rtol=2e-6,atol=2e-7,equal_nan=True,err_msg=f'{n} {key}')
   else:assert got[key]==want[key],(n,key,got[key],want[key])
 receipt={'mode':args.mode,'algorithm':args.algorithm,'trials':len(results),'elapsed_s':time.monotonic()-started,'status':'passed'}
(r/(f'native-compare-{args.algorithm}-receipt.json' if args.mode=='compare' else 'native-reference-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(receipt)
