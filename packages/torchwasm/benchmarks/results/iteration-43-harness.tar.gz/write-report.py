from pathlib import Path
import json,statistics
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
report=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-43.json').read_text());integration=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-43-integration.json').read_text());perf=report['performance']['summary']
def row(runtime,kind,mode,dtype):return next(v for v in perf[runtime] if (v['kind'],v['mode'],v['dtype'])==(kind,mode,dtype))
lines=['# Torch runtime iteration 0.43: volumetric max pooling','',
'Add `nn.MaxPool3d`, functional values/indices, and the value-only root `torch.max_pool3d` alias. Existing host alias/launcher behavior supports ordinary Torch imports. MaxPool1d/2d/3d are public sibling Module classes. Main adoption is recorded after the validated source is actually pushed.','',
'## Compatibility and implementation','',
'CDHW/NCDHW inputs support stride, padding, dilation, ceil mode, empty batches and per-channel flattened int64 indices. Float16 and the supported integer dtypes allow both return forms; float32/float64 support VJP, JVP and reverse differentiation of the tangent. This differs from the native value-only 1D integer dispatch boundary. Native Torch 2.14.1 supplies the local differential oracle.','',
'Positive strided NumPy arrays with an NDHWC layout preserve native value/index strides. Forward AD canonicalizes ambiguous C=1 or single-spatial-point tangent layouts as native gather does. Dense leaf gradient layouts, strided/F-order inputs, empty outputs, first-finite ties, last-NaN selection and signed-zero payload selection are covered. This does not add general channels_last_3d conversion APIs.','',
'A separate three-dimensional numerical engine shares the existing graph/scatter logic. A 1/2-edge block kernel avoids general packing for cube/slab reductions. Ordered scan loops skip globally unreachable taps; packed windows retain a conservative 32 MiB temporary-workspace estimate. That bound excludes output allocations and is not a peak-memory measurement. Returned indices share the actual storage retained by derivative closures, including after output layout conversion. Input/index/tangent version guards remain active.','',
'Valid kernel/output counts above eight million, or flattened spatial indices beyond the runtime pointer range, explicitly require the server. Invalid arguments/output geometry are rejected first. Dilated windows containing no actual sample reproduce native inference values/indices, but derivatives remain explicitly unsupported. Float16 AD, complex/bfloat16 kernels, higher-order graph construction and GPU device execution remain outside this contract.','',
'## Validation','',
f"- Full repository/library CPU suite: {report['full_cpu']['passed']:,} passed, one optional skip; {report['full_cpu']['duration_s']:.2f} s. Other local work overlapped, so this duration is not a performance comparison.",
'- Independent 3D region/scatter/derivative/layout/import/training/checkpoint suite: 520 passed. Existing max/average pooling regression subset: 1,720 passed.',
'- Four dispatch settings repeat 236 native-reference trials each (944 total): 166 valid random geometries, 54 invalid geometries and 16 dtype/return-form probes per setting. Of the random cases, 162 execute VJP/JVP/reverse tangent; empty-sampling derivatives are excluded explicitly. Four trials reproduce inference only. Values, indices and exact layout strides are compared where applicable.',
'- Actual Node/Pyodide and Chrome Worker: 3,822 independent tests each, 42 suites, Pyodide 0.29.4 / NumPy 2.2.5. All 50 source/license resource hashes match the frozen candidate.',
'- Isolated Python 3.10.19 / NumPy 1.26.4 wheel: 3,835 passed, native Torch absent. Public/private wheel source identities, alias imports, independent uninstalls, serialization and 3D VJP/JVP pass in a fresh NumPy-only environment.',
f"- Original native catalog: 78 problems, 10,218 executions, 342 caught mutants, three repeats; {integration['native']['duration_s']:.3f} s within the unchanged 600 s budget.",
f"- Complete exported WASM catalog: 78/78 and 342 mutants; {integration['wasm']['elapsed_ms']/1000:.3f} s, concurrency two, no exceeded browser budgets. The attention path runs all 3,822 contracts against the actual exported library, with only the pre-existing legacy-profile supplementation.",
'- Full frontend checks and both typed production builds pass. The eight upstream School-label/source-check changes and seventeen subsequent frontend navigation/practice-entry files were retained by fast-forward. Full frontend checks and both builds passed after that 17-file state. A subsequent 5-file feed-filter UI delta passed 10 affected suites and both production builds, retaining the earlier snapshot identities against their original Git blobs; a further 5-file reading-toolbar/viewport delta passed 10 affected suites and both production builds; a final six-file interview/shared-search delta passed ten affected suites and both builds; all 50 math/license resources and 161 exports remained identical.',
'- Prior 9,755 immutable export payloads are preserved; 158 new payloads are reachable, with all 161 active export identities frozen. Public and private distributions agree on all 50 core/license resources. The 46 resources outside the three changed files and one new engine are unchanged from 0.42.','',
f"Source/license footprint rises from {report['source_footprint']['baseline']['raw_bytes']:,} to {report['source_footprint']['candidate']['raw_bytes']:,} raw bytes; concatenated local gzip estimates rise from {report['source_footprint']['baseline']['local_gzip_estimate_bytes']:,} to {report['source_footprint']['candidate']['local_gzip_estimate_bytes']:,} bytes. This is not an actual network-transfer, wheel-size, cold-start or peak-memory measurement.",'',
'Empty-batch regression tests forbid positive-length coordinate ranges for all four dispatch settings. On a zero-element `(0, 1, 200, 200, 200)` index-returning call, traced NumPy/Python peak allocations fell from about 64.46 MB to 9–10 KB versus the initial unreleased 0.43 engine. VJP/JVP still return the expected empty shapes. This single-call tracemalloc probe is separate from timing and does not establish RSS or WASM memory bounds.','',
'## Complete-flow performance','',
'The public `bench_max_pooling_3d.py` compares the supported 0.42 separable 2D/1D composition with direct 3D calls. The baseline includes index recombination and output layout restoration; an identical composition in the candidate controls changes in shared code. No absent old 3D API is timed. Each of 62 float32/float64 cases verifies its outputs and applicable gradients/indices or a complete training update before timing.','',
'Twelve sequential children use four fresh CPU, Node/Pyodide and Chrome Worker processes each, alternating variant order, seven samples and forty calls (five training) per sample. Timing starts after all owned correctness/build processes finish. This is a shared host, with every sample retained. The table gives time reductions from medians of the four child medians; negative values mean slower.','',
'| Flow | dtype | CPU | Node/WASM | Chrome/WASM |','|---|---|---:|---:|---:|']
for kind,mode,label in [('cube','forward','Cube forward'),('cube','backward','Cube VJP'),('large_cube','forward','Larger cube forward'),('overlap','forward','Overlap forward'),('dilated','jvp','Dilated JVP'),('cnn','training','Conv3d + SGD step')]:
 for dtype in ('float32','float64'):
  values=[row(runtime,kind,mode,dtype)['direct_time_reduction_percent'] for runtime in ('cpu','node','chrome')]
  lines.append('| '+label+' | '+dtype+' | '+' | '.join(f'{v:.1f}%' for v in values)+' |')
lines += ['', 'The complete case ranges and composition controls are retained rather than claiming every configuration improves:','']
for runtime in ('cpu','node','chrome'):
 values=[v['direct_time_reduction_percent'] for v in perf[runtime]];controls=[v['composition_time_reduction_percent'] for v in perf[runtime]]
 lines.append(f'- {runtime}: direct reductions {min(values):.1f}% to {max(values):.1f}%; composition-control reductions {min(controls):.1f}% to {max(controls):.1f}%.')
lines += ['', 'These measurements compare library flows, including full Tensor calls and the stated training step. They do not establish native-Torch, GPU, cross-runtime, cold-import, browser-transfer or whole-PaperLeet throughput improvements. WebGPU remains a separate storage/backend evaluation; these results establish the NumPy CPU/Pyodide path only.','',
'## Evidence and release controls','',
'Exact source/test hashes, all child samples/receipts, native oracle inputs, runtime harnesses and export identities are retained in `packages/stridetorch/benchmarks/results/iteration-43*.json` and the companion harness archives. Initial package-evidence path, UI-runner working-directory and WASM benchmark helper-search-path errors, and their artifact-copy/cwd/path-only repairs, remain in the raw archives. Failed preliminary timing children are excluded from the final twelve-child dataset. The initial and final unreleased 0.43 empty-batch proof generations are retained separately. All required final source/build/test gates completed successfully.','',
'All seven canonical release-policy files match the retained baseline. This work creates no tag, dispatch, release, PyPI upload or online deployment. A separately started manual quality gate is observed before adopting main; main is not moved during an active quality/Pages chain. The standalone library still uses StrideTorch until the user selects a replacement name.','']
(repo/'docs/validation/torch-runtime-iteration-43.md').write_text('\n'.join(lines))
p=repo/'packages/stridetorch/ROADMAP.md';text=p.read_text()
if '## 0.43:' in text:
 start=text.index('## 0.43:');end=text.index('## Next implementation areas',start);text=text[:start]+text[end:]
section='''## 0.43: volumetric max pooling and native layout routes

- Add MaxPool3d and functional/root value/index aliases, CDHW/NCDHW geometry,
  integer/half inference, float32/64 VJP/JVP/reverse tangent and empty batches.
- Preserve ordered selection and flattened index storage, NDHWC value/index
  strides and native ambiguous-singleton tangent strides. Keep public MaxPool
  classes as siblings and share the existing graph/scatter machinery.
- Add cube/slab block kernels, bounded packing and reachable-tap 3D scans.
  Retain explicit resource/empty-sampling/AD dtype boundaries.
- Validate 37,450 CPU tests, 3,822 tests in Node and Chrome WASM each, 3,835
  minimum-environment wheel tests, 944 native-reference trials, original 78/342
  catalog flows and complete 62-flow performance cases in 12 fresh children.
- Preserve all 9,755 prior immutable payloads and all release rules. See
  [the 0.43 validation record](../../docs/validation/torch-runtime-iteration-43.md).
  The measured overlap-window regression motivates a separable numerical
  reduction path next, preserving native NaN/index/layout and derivative rules.
  Independent-library, broader core API and GPU/backend work remains active.

'''
marker='## Next implementation areas';pos=text.find(marker)
if pos<0:text+='\n'+section
else:text=text[:pos]+section+text[pos:]
p.write_text(text)
print('Wrote validated0.43 report and roadmap')
