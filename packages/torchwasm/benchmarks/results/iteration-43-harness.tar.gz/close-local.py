from pathlib import Path
import hashlib,json,os,pickle,re,shutil,tarfile,subprocess
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results';out.mkdir(exist_ok=True)
def read(name):return json.loads((r/name).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
actual={p.name:sha(p) for p in (repo/'packages/stridetorch/src/stridetorch').iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
tests={p.name:sha(p) for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'};plan=read('proof/chrome-contracts/plan.json')
assert len(actual)==50 and actual==read('proof/source-hashes.json')==plan['source']
assert len(tests)==42 and tests==plan['tests'] and plan['expected']==3822
full=read('full-root-receipt.json');assert full['exit_code']==0 and full['passed']==37450 and full['skipped']==1
assert '520 passed' in (r/'focused.log').read_text() and '1720 passed' in (r/'regression.log').read_text()
gates=read('proof/gate-receipts.json');assert len(gates)==6 and all(v['exit_code']==0 for v in gates.values())
node=read('proof/source-wasm.json');chrome=read('proof/chrome-contracts/result.json');wheel=read('proof/wheel-stride043-result.json');coinstall=read('proof/coinstall-result.json')
assert node['passed']==chrome['passed']==3822 and chrome['test_hashes']==tests
assert node['source_hashes']==chrome['source_hashes']==wheel['source_hashes']==coinstall['source_hashes']==actual
assert all(v['status']=='success' for v in (chrome,wheel,coinstall)) and not wheel['native_torch']
assert '3835 passed' in (r/'proof/python310-stride043-tests.log').read_text()
assert node['numpy']=='2.2.5' and node['library']=='0.43.0'
numeric={name:read(f'native-compare-{name}-receipt.json') for name in ('auto','scan','window','block')}
assert all(x['status']=='passed' and x['trials']==236 for x in numeric.values())
with (r/'native-reference.pkl').open('rb') as f:ref=pickle.load(f)
empty_allocation=read('empty-allocation-proof.json');assert empty_allocation['status']=='success' and empty_allocation['source_hashes']['final_043']==actual
numeric_scope=dict(per_algorithm_trials=len(ref),random_valid=sum('value' in x for x in ref[:220]),random_invalid=sum('error' in x for x in ref[:220]),random_derivative_trials=sum('grad' in x for x in ref[:220]),dtype_inference_trials=len(ref)-220)
perf=read('performance-summary.json');assert perf['status']=='success' and perf['children']==12 and all(v['exit_code']==0 for v in perf['receipts'].values())
baseline={p.name:sha(p) for p in (r/'baseline-source/stridetorch').iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
for runtime in ('cpu','node','chrome'):
 for repeat in range(4):
  row=read(f'performance/{runtime}-{repeat}.json');assert row['status']=='success' and len(row['results'])==62 and row['source_hashes']==dict(baseline=baseline,candidate=actual)
native=read('integration-proof/native-ci.json');wasm=read('integration-proof/full-wasm-result.json')
assert native['passed'] and native['problems']==78 and native['tests_executed']==10218 and native['duration_s']<=600 and native['repeats']==3 and not native['issues']
assert sum(map(len,native['mutation'].values()))==342 and all(hit for rows in native['mutation'].values() for hit in rows.values())
assert wasm['passed'] and wasm['catalog_modules']==wasm['modules']==78 and not wasm['browser_budget_exceeded']
assert sum(v['mutants'] for v in wasm['results'])==342 and all(v['passed'] and not v['browser_budget_exceeded'] for v in wasm['results'])
contracts=next(v for v in wasm['results'] if v['id']=='architecture/attention')['independent_contracts'];assert contracts['passed']==3822 and len(contracts['suites'])==42
assert {v['suite']:v['source_sha256'] for v in contracts['suites']}==tests
assert contracts['runtime_profiles'][0]['supplemented_files']==[]
assert contracts['runtime_profiles'][1]['supplemented_files']==[dict(name='stridetorch/_legacy.py',source_sha256=actual['_legacy.py'])]
setup=read('integration-proof/setup-receipts.json');front=read('integration-proof/frontend-receipts.json');assert len(setup)==4 and len(front)==5 and all(v['exit_code']==0 for v in setup+front)
exports=read('integration-proof/export-identity.json');snapshot=read('integration-proof/release-snapshot.json')
assert exports['published_assets_unchanged']==9755 and exports['active_assets']==exports['new_assets']==158 and exports['all_new_assets_reachable']
assert snapshot['source_hashes']==actual and read('integration-proof/distribution-identity.json')['status']=='success'
live=read('integration-proof/live-expected-sha256.json');assert len(live)==161
for name,digest in live.items():assert sha(repo/'web/public/data'/name)==digest
harness=read('integration-proof/wasm-harness-identity.json');assert sha(repo/harness['file'])==harness['sha256'] and sha(repo/harness['driver_file'])==harness['driver_sha256']
policy=read('release-policy-identity.json');assert policy['status']=='unchanged'
for name,digest in policy['files'].items():assert sha(repo/name)==digest
sync=read('upstream-sync.json');latest_sync=read('upstream-sync-latest.json');followup=read('upstream-sync-followup.json');final_sync=read('upstream-sync-final.json');search_sync=read('upstream-sync-search.json')
current_ui={}
for snapshot0 in (sync,latest_sync,followup,final_sync,search_sync):
 for name,digest in snapshot0['paths'].items():
  assert hashlib.sha256(subprocess.check_output(['git','show',snapshot0['after']+':'+name],cwd=repo)).hexdigest()==digest,(snapshot0['after'],name)
  current_ui[name]=digest
for name,digest in current_ui.items():assert sha(repo/name)==digest,name
followup_receipts=read('followup-ui/receipts.json');final_ui=read('final-ui/receipts.json');search_ui=read('search-ui/receipts.json')
for receipts0 in (followup_receipts,final_ui,search_ui):assert len(receipts0)==12 and all(row['exit_code']==0 for row in receipts0)
changed={name for name,digest in baseline.items() if actual.get(name)!=digest};added=set(actual)-set(baseline)
assert changed=={'__init__.py','_api.py','_pooling.py'} and added=={'_pooling3d.py'}
report=dict(status='validated_locally',version='0.43.0',source_hashes=actual,baseline_source_hashes=baseline,unchanged_resources=len(set(baseline)-changed),changed_resources=sorted(changed),added_resources=sorted(added),full_cpu=full,focused_3d=520,prior_pooling_regression=1720,native_reference=read('native-reference-receipt.json'),native_differential=numeric,native_differential_scope=numeric_scope,node_wasm=node,chrome_worker=chrome,minimal_wheel=wheel,coinstall=coinstall,performance=perf,empty_allocation=empty_allocation,source_footprint=read('source-footprint.json'),release_policy=policy,upstream_sync=sync,latest_upstream_sync=latest_sync,followup_upstream_sync=followup,followup_ui=followup_receipts,final_upstream_sync=final_sync,final_ui=final_ui,search_upstream_sync=search_sync,search_ui=search_ui)
save(out/'iteration-43.json',report)
integration=dict(status='validated_locally',version='0.43.0',native=native,wasm=wasm,frontend=front,setup=setup,export_identity=exports,release_snapshot=snapshot,live_export_sha256=live,source_hashes=actual,distribution=read('integration-proof/distribution-identity.json'),wasm_harness=harness,runtime_sizes=read('integration-proof/runtime-sizes.json'))
save(out/'iteration-43-integration.json',integration)
metadata=r/'package-metadata';metadata.mkdir(exist_ok=True)
for name in ('README.md','pyproject.toml','LICENSE','NOTICE'):shutil.copy2(repo/'packages/stridetorch'/name,metadata/name)
shutil.copy2(repo/'packages/stridetorch/tests/test_standalone.py',metadata/'test_standalone.py')
archives={}
for name,folder,excluded in [('iteration-43-harness.tar.gz',r,{'integration-proof','performance','proof'}),('iteration-43-integration-harness.tar.gz',r/'integration-proof',{'live-expected','dist-paperleet'}) ,('iteration-43-runtime-harness.tar.gz',r/'proof',set()),('iteration-43-performance-harness.tar.gz',r/'performance',set())]:
 target=out/name
 with tarfile.open(target,'w:gz') as archive:
  for current,dirs,names in os.walk(folder):
   dirs[:]=[d for d in dirs if d not in excluded and d not in ('__pycache__','.pytest_cache') and not d.endswith(('-env','-venv'))]
   for name0 in sorted(names):
    path=Path(current)/name0
    if path==r/'performance-initial-run/node-0.log':continue  # Generated asm dump; compact error summary is archived.
    if not path.is_symlink() and (path.name in ('LICENSE','NOTICE') or path.suffix in ('.py','.mjs','.json','.log','.md','.html','.toml','.pkl','.txt')):archive.add(path,arcname=str(path.relative_to(folder)),recursive=False)
 archives[name]=dict(sha256=sha(target),bytes=target.stat().st_size)
report['raw_archives']=archives;save(out/'iteration-43.json',report)
save(r/'state.json',dict(status='local_gates_passed',version='0.43.0',source_hashes=actual,export_sha256=live,all_owned_children_terminal=True,main_adoption_pending=True))
print('PASS0.43 exact local proof:50resources,3822Node/Chrome,37450CPU,3835minimum,944native trials,78/342catalog,62flowsx12children',flush=True)
