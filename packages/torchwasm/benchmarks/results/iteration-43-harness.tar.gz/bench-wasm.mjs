import fs from 'node:fs';import path from 'node:path';import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const root=path.dirname(new URL(import.meta.url).pathname);const repo='/Users/david/Developer/PaperLeet-torch-release';
const py=await loadPyodide({indexURL:repo+'/web/node_modules/pyodide/',packageCacheDir:repo+'/web/public/browser-runtime/pyodide-0.29.4/',stdout(){},stderr(){}});await loadJudgePackages(py,[]);
for(const [name,relative] of [['baseline','baseline-source/stridetorch'],['candidate','proof/source']]){py.FS.mkdirTree('/'+name);for(const file of fs.readdirSync(root+'/'+relative).filter(f=>f.endsWith('.py')||['LICENSE','NOTICE'].includes(f)))py.FS.writeFile('/'+name+'/'+file,fs.readFileSync(root+'/'+relative+'/'+file));}
py.FS.writeFile('/bench.py',fs.readFileSync(root+'/bench_max_pooling_3d.py'));py.FS.writeFile('/bench_max_pooling_1d.py',fs.readFileSync(root+'/bench_max_pooling_1d.py'));py.globals.set('reverse_order',process.argv.includes('--reverse'));
py.runPython(`import sys,runpy
sys.path.insert(0,'/')
sys.argv=['bench.py','--baseline-source','/baseline','--candidate-source','/candidate','--iterations','40','--samples','7','--output','/result.json']+(['--reverse'] if reverse_order else [])
runpy.run_path('/bench.py',run_name='__main__')`);
const result=JSON.parse(py.FS.readFile('/result.json',{encoding:'utf8'}));result.runtime='Node/Pyodide';result.pyodide=py.version;fs.writeFileSync(process.argv[2],JSON.stringify(result,null,2)+'\n');console.log('PASS',result.results.length,'verified Node/WASM flows');
