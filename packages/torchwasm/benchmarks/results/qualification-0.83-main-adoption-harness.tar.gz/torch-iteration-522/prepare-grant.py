from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
assert not (r/'qualification-grant.json').exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip()
application=read(b/'torch-iteration-521/result.json');assert application['status']=='passed_current_083_frontend_followup'
for name,h in read(b/'torch-iteration-521/execution-plan.json')['static_inputs'].items():assert sha(repo/name)==h,name
exports=read(b/'torch-iteration-511/live-export-sha256.json');assert len(exports)==183
exportpaths={'web/public/data/'+name for name in exports}
delta=subprocess.check_output(['git','diff','--name-only',application['head'],'HEAD'],cwd=repo,text=True).splitlines()
assert not (set(delta)&exportpaths),delta
metadata=read(b/'torch-iteration-516/result.json');assert metadata['status']=='passed_postapplication_readme_metadata_refresh_and_package_imports'
readme='packages/stridetorch/README.md';assert sha(repo/readme)==metadata['metadata_delta']['readme_after_sha256']
assert all(name in exportpaths or name==readme or name.startswith(('docs/validation/','packages/stridetorch/benchmarks/results/')) for name in delta),delta
for name,h in exports.items():assert sha(repo/'web/public/data'/name)==h,name
write(r/'live-export-sha256.json',exports)
resources=read(b/'torch-iteration-511/source-hashes.json');assert len(resources)==66
for name,h in resources.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==h,name
write(r/'source-hashes.json',resources)
for name,h in read(b/'torch-iteration-515/source-plan.json')['inputs'].items():assert sha(Path(name))==h,name
for name,h in read(r/'release-policy-identity.json')['files'].items():assert sha(repo/name)==h,name
wrapper=b/'torch-iteration-67/final-integration/push-main-native.py';assert sha(wrapper)=='4b51422c5533ca6177a4a29a557cf37d1c6727d7530908e444be5833588c2882'
required={}
for name in ['operand-lifetime-jspi-followup.json','operand-lifetime-owned-flow.json','qualification-0.83.json']:
 aggregate=read(repo/'packages/stridetorch/benchmarks/results'/name);receipt=aggregate.get('raw_archive',aggregate.get('archive'));archive=repo/receipt['path'];assert sha(archive)==receipt['sha256']
 with tarfile.open(archive) as stream:manifest=json.load(stream.extractfile('sha256.json'))
 for path,h in manifest.items():assert sha(b/path)==h,path;required[str(b/path)]=h
for p in (b/'torch-iteration-521').iterdir():
 if p.is_file():required[str(p)]=sha(p)
for p in list(r.glob('*.py'))+[r/'guard-provenance.json',r/'release-policy-identity.json',r/'release-policy-variants.json',r/'commit-receipt.json',wrapper]:required[str(p)]=sha(p)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();files=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0');reviewed={name:sha(repo/name) for name in files if name}
write(r/'qualification-grant.json',dict(head=head,source_resources=66,runtime_resources=resources,ci_triggered=False,version='0.83.0',local_qualification_complete=True,required_files=[dict(path=name,sha256=h) for name,h in required.items()],reviewed_commit_files=reviewed))
write(r/'grant-receipt.json',dict(head=head,tracked_files=len(reviewed),raw_required_files=len(required),qualified_application_head=application['head'],readme_metadata_qualified=True,readme_sha256=sha(repo/readme),post_qualification_delta=delta,derived_export_paths_verified=183,ci_triggered=False,goal_status='active'));print(json.dumps(dict(head=head,tracked_files=len(reviewed),raw_required_files=len(required))))
