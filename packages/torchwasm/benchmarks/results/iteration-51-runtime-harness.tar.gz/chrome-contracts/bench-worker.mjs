import {loadJudgePackages} from '../../../extraction-browser/packages.mjs';
self.onmessage=async({data})=>{try{
 const plan=await(await fetch('./bench-plan.json')).json();const which=data.legacy?'legacy':'baseline';
 const {loadPyodide}=await import('../../../runtime-0.29.4/pyodide.mjs');const py=await loadPyodide({indexURL:new URL('../../../runtime-0.29.4/',self.location.href).href,stdout(){},stderr(){}});await loadJudgePackages(py,[]);
 for(const [name,folder,hashes] of [['candidate','source',plan.source],['baseline',which,plan[which]]]){
  py.FS.mkdirTree('/'+name);for(const file of Object.keys(hashes))py.FS.writeFile('/'+name+'/'+file,await(await fetch('./'+folder+'/'+file)).text());
 }
 py.FS.writeFile('/bench.py',await(await fetch(data.legacy?'./legacy-bench.py':'./bench.py')).text());py.globals.set('plan_json',JSON.stringify(plan));py.globals.set('legacy_mode',data.legacy);py.globals.set('reverse_order',data.reverse);
 const report=JSON.parse(py.runPython(`import json,pathlib,hashlib,runpy,numpy
plan=json.loads(plan_json);key='legacy' if legacy_mode else 'baseline';digest=plan['legacy_benchmark_sha256' if legacy_mode else 'benchmark_sha256']
for folder,hashes in [('candidate',plan['source']),('baseline',plan[key])]:
 actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path('/'+folder).iterdir() if p.is_file()};assert actual==hashes
assert hashlib.sha256(pathlib.Path('/bench.py').read_bytes()).hexdigest()==digest
report=runpy.run_path('/bench.py')['run']('/baseline','/candidate',reverse_order=reverse_order)
report.update(runtime='Chrome/Pyodide',benchmark_sha256=digest,numpy=numpy.__version__)
json.dumps(report)`));self.postMessage({...report,pyodide:py.version});
}catch(error){self.postMessage({error:String(error.stack||error)});}};
