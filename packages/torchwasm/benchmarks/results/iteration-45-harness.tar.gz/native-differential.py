"""Subprocess-separated installed native Torch vs working-tree adapter evidence."""
from pathlib import Path
import hashlib, json, os, subprocess, sys, time
import numpy as np

ROOT=Path(__file__).resolve().parent
REPO=Path('/Users/david/Developer/PaperLeet-torch-release')

def specifications():
    rng=np.random.default_rng(4503); cases=[]
    for i in range(120):
        spatial=tuple(int(v) for v in rng.integers(3,9,3))
        shape=([int(rng.integers(1,3))] if i%3 else [])+[int(rng.integers(1,4)),*spatial]
        if i%19==0 and len(shape)==5:shape[0]=0
        adaptive=i%2==1
        spec=dict(shape=shape,dtype=['float32','float64'][i%4//2],layout=['C','F','strided','channels_last'][i%4],adaptive=adaptive,seed=45030+i,ad=True)
        if adaptive:
            spec['kwargs']=dict(output_size=([1,1,1] if i%13==0 else [None if (i+j)%11==0 else int(rng.integers(1,11)) for j in range(3)]))
        else:
            kernel=[int(rng.integers(1,min(n,4)+1)) for n in spatial]
            spec['kwargs']=dict(kernel_size=kernel,stride=[int(rng.integers(1,4)) for _ in range(3)],padding=[int(rng.integers(k//2+1)) for k in kernel],ceil_mode=bool(i%3),count_include_pad=bool(i%5),divisor_override=[None,-7,11][i%3])
        cases.append(spec)
    # All four layouts for each dtype; half is an inference-only promise.
    for dtype in ['float16','float32','float64','int64']:
        for layout in ['C','F','strided','channels_last']:
            for adaptive in [False,True]:
                if dtype=='float16' and not adaptive or dtype=='int64' and adaptive:continue
                cases.append(dict(shape=[2,3,4,5,6],dtype=dtype,layout=layout,adaptive=adaptive,seed=45100+len(cases),ad=dtype in ['float32','float64'],kwargs=dict(output_size=[3,2,4]) if adaptive else dict(kernel_size=3,stride=2,padding=1,ceil_mode=True,count_include_pad=False)))
    for shape in [[1,0,3,4,5],[1,2,0,4,5],[0,2,0,4,5]]:
        cases.append(dict(shape=shape,dtype='float32',layout='C',adaptive=True,seed=45200+len(cases),ad=True,kwargs=dict(output_size=1)))
    for adaptive in [False,True]:
        for nonfinite in ['input','seed']:
            cases.append(dict(shape=[1,2,4,5,6],dtype='float64',layout='C',adaptive=adaptive,seed=45300+len(cases),ad=True,nonfinite=nonfinite,kwargs=dict(output_size=[3,2,4]) if adaptive else dict(kernel_size=3,stride=1,padding=1)))
    return cases

def evaluate(backend,route):
    if backend=='native':import torch as api
    else:
        sys.path.insert(0,str(REPO/'packages/stridetorch/src'))
        from stridetorch import torch as api, _average_pooling3d as engine
        engine._ALGORITHM,engine._BACKWARD_ALGORITHM=route.split('/')
    arrays={}; records=[]
    for index,spec in enumerate(specifications()):
        rng=np.random.default_rng(spec['seed']);a=rng.normal(size=spec['shape']).astype(spec['dtype'])
        if spec['dtype']=='int64':a=rng.integers(-200,200,size=spec['shape'],dtype=np.int64)
        if spec.get('nonfinite')=='input':a.flat[0]=np.nan;a.flat[17]=np.inf;a.flat[-1]=-np.inf
        if spec['layout']=='F':a=np.asfortranarray(a)
        if spec['layout']=='strided':a=np.repeat(a,2,axis=-1)[...,::2]
        if spec['layout']=='channels_last' and a.ndim==5:a=a.transpose(0,2,3,4,1).copy().transpose(0,4,1,2,3)
        x=api.from_numpy(a);x.requires_grad_(spec['ad'])
        fn=getattr(api.nn.functional,'adaptive_avg_pool3d' if spec['adaptive'] else 'avg_pool3d')
        function=lambda z:fn(z,**spec['kwargs'])
        y=function(x);values=dict(value=y.detach().numpy());record=dict(index=index,output_shape=list(y.shape),stride=list(y.stride()))
        if spec['ad']:
            seed=rng.normal(size=y.shape).astype(spec['dtype'])
            if spec.get('nonfinite')=='seed':seed.flat[0]=np.nan;seed.flat[-1]=np.inf
            if spec['layout']=='F':seed=np.asfortranarray(seed)
            if spec['layout']=='strided':seed=np.repeat(seed,2,axis=-1)[...,::2]
            y.backward(api.from_numpy(seed));values['vjp']=x.grad.numpy();record['grad_stride']=list(x.grad.stride());x.grad=None
            direction=api.from_numpy(rng.normal(size=a.shape).astype(a.dtype)).requires_grad_()
            primal,tangent=api.func.jvp(function,(x,),(direction,));values['primal']=primal.detach().numpy();values['jvp']=tangent.detach().numpy()
            tangent.backward(api.from_numpy(seed));values['reverse_tangent']=direction.grad.numpy()
            assert x.grad is None
        for name,value in values.items():arrays[f'{index}_{name}']=value.copy()
        records.append(record)
    dest=ROOT/(backend+'-'+route.replace('/','-'))
    np.savez_compressed(str(dest)+'.npz',**arrays)
    source=REPO/'packages/stridetorch/src/stridetorch'
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')} if backend!='native' else None
    dest.with_suffix('.json').write_text(json.dumps(dict(backend=backend,route=route,python=sys.version,numpy=np.__version__,torch=getattr(api,'__version__',None),module_path=getattr(api,'__file__',None),source_hashes=hashes,cases=records),indent=2)+'\n')

def compare():
    start=time.monotonic();env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
    plans=[('native','auto/auto','/Users/david/Developer/PaperLeet-public/.venv/bin/python')]+[('adapter',route,str(ROOT.parent/'torch-iteration-21/stride-dev-env/bin/python')) for route in ['auto/auto','scan/loop','packed/scatter','block/block']]
    for backend,route,python in plans:
        with (ROOT/(backend+'-'+route.replace('/','-')+'.log')).open('w') as log:
            subprocess.run([python,__file__,backend,route],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
        print('TERMINAL',backend,route,flush=True)
    expected=np.load(ROOT/'native-auto-auto.npz');native=json.loads((ROOT/'native-auto-auto.json').read_text());checks=0;singleton_gradient_layouts=[]
    for backend,route,python in plans[1:]:
        stem='adapter-'+route.replace('/','-');actual=np.load(ROOT/(stem+'.npz'));records=json.loads((ROOT/(stem+'.json')).read_text())
        assert records['source_hashes']==json.loads((ROOT/'proof/source-hashes.json').read_text())
        for actual_record,native_record in zip(records['cases'],native['cases']):
            assert actual_record['output_shape']==native_record['output_shape'] and actual_record['stride']==native_record['stride'],(stem,actual_record,native_record)
            if actual_record.get('grad_stride')!=native_record.get('grad_stride'):
                shape=specifications()[actual_record['index']]['shape']
                assert all(a==b for n,a,b in zip(shape,actual_record['grad_stride'],native_record['grad_stride']) if n>1),(stem,actual_record,native_record)
                singleton_gradient_layouts.append(dict(route=route,shape=shape,native=native_record,adapter=actual_record))
        for key in expected.files:
            a,b=actual[key],expected[key]
            tol=(3e-3,3e-3) if b.dtype==np.float16 else (2e-5,2e-6) if b.dtype==np.float32 else (3e-12,3e-13)
            try:np.testing.assert_allclose(a,b,rtol=tol[0],atol=tol[1],equal_nan=True)
            except AssertionError as error:raise AssertionError((stem,key,specifications()[int(key.split('_')[0])],str(error))) from error
            checks+=1
    receipt=dict(status='pass',cases=len(specifications()),adapter_routes=4,array_comparisons=checks,elapsed_s=time.monotonic()-start,native_torch=native['torch'],native_module_path=native['module_path'],source_hashes=records['source_hashes'],harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),singleton_gradient_layouts=singleton_gradient_layouts,scope='values, exact output strides, non-singleton leaf-gradient strides, VJP, JVP, reverse tangent; ordinary random values plus local nonfinites and global empty input; singleton leaf-gradient stride differences retained explicitly; no bitwise claim for ill-conditioned global reductions')
    (ROOT/'native-differential-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='singleton_gradient_layouts'}),flush=True)

if __name__=='__main__':
    if len(sys.argv)>1:evaluate(*sys.argv[1:])
    else:compare()
