from pathlib import Path
import json
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
read=lambda n:json.loads((r/n).read_text());proof=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-45.json').read_text());integration=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-45-integration.json').read_text());perf=proof['performance']['summary']
def row(runtime,kind,mode,dtype):return next(x for x in perf[runtime] if x['kind']==kind and x['mode']==mode and x['dtype']==dtype)
lines=['# Torch runtime iteration 45: volumetric average pooling','',
'## Result and scope','',
'Version 0.45 adds `nn.AvgPool3d`, `nn.AdaptiveAvgPool3d` and their functional entry points to the independent NumPy/Pyodide package and the PaperLeet vendored/browser runtimes. Existing `torch` aliases and module pickling remain available. This iteration retains the current package name; the proposed BrowserTorch rename has not been selected.', '',
'Fixed pooling supports stride, padding, ceil mode, padding inclusion and signed nonzero integer divisor overrides. Adaptive pooling supports scalar/triple output sizes, per-axis `None`, zero-sized forward outputs and the native empty-global specialization. Float32/float64 reverse AD, JVP and reverse-over-forward are verified. Fixed int64 inference and adaptive float16 inference are covered; native CPU fixed float16 pooling is explicitly unsupported.', '',
'## Computation and memory','',
'Small disjoint blocks use strided additions and broadcast adjoints. Other regions use ordered packing, recursive output/plane tiling or bounded single-region streaming; reverse paths use ordered loop/scatter blocks. Non-contiguous gradient seeds are gathered by block, avoiding an implicit full-seed reshape copy. Adaptive division follows depth, height and width order. Masks prevent invalid/padded samples and nonfinite gradient seeds from contaminating unrelated regions.', '',
'Up to 32 small geometries cache readonly coordinate/count arrays and optional flat gather indices/masks. Each gather plan is at most 128 KiB. Contiguous input gathers directly into its accumulation buffer; other layouts retain coordinate gathering. No cache holds input values, tensors or user storage. The 32 MiB packing estimate excludes input/output allocations and is not a total-process or measured peak-memory claim.', '',
'Global 1×1×1 pooling shares the stateless mean rule and canonicalizes Fortran leading axes to native contiguous output metadata while preserving unambiguous channels-last output. An optional output formatter is the only arithmetic-helper change shared with existing 1D/2D averages.', '',
'## Verification','',
'| Check | Observed result |','|---|---|',
f"| Full CPU repository/package tests | {proof['full_cpu']['passed']:,} passed, {proof['full_cpu']['skipped']} skipped, {proof['full_cpu']['elapsed_s']:.2f} s |",
'| New 3D contracts | 724 passed; four forward/backward route pairs |',
'| Installed native PyTorch 2.14.1 | 151 cases × four adapter routes; 2,892 array comparisons |',
'| Node/Pyodide and actual Chrome Worker | 4,701 independent contracts each, 43 suites |',
'| Minimum installed public wheel | Python 3.10.19 / NumPy 1.26.4, 4,714 tests, native Torch absent |',
'| Public/private ownership | Both namespaces, aliases, pickle/checkpoints, VJP/JVP and independent uninstall survival |',
f"| Native PaperLeet catalog | 78 problems, 10,218 executions, 342 mutants, three repeats; {integration['native']['duration_s']:.3f} s < 600 s |",
f"| Exported browser/WASM catalog | 78/78, 342 mutants, 4,701 independent contracts; {read('integration-proof/wasm-receipt.json')['elapsed_s']:.3f} s |",
'| Frontend | Driver/policy checks, complete npm check, normal build and current Pages-profile build |',
'| Identity | 51 source/license resources; 161 active export hashes; 10,071 prior immutable payloads preserved and 158 reachable payloads added |','',
'Native comparisons include CDHW/NCDHW, C/F/strided/channels-last input and seed layouts, local NaN/Inf, empty global input, values, exact output strides, VJP, JVP and reverse-tangent gradients. Non-singleton leaf-gradient strides agree. Four channel-singleton cases retain imported singleton gradient strides that differ from native canonical singleton strides; all indexed values agree. Every raw difference is recorded rather than counted as exact metadata equality.', '',
'A deliberately ill-conditioned global float32 example `[-0,-0,1e20,-1e20,1,2,3,4]` yields 0 from native SIMD mean and 1.25 from NumPy mean, while fixed ordered pooling yields 1.25. Global pooling follows this library\'s mean contract; there is no bitwise-equivalence promise across numerical backends for cancellation-dominated sums. Ordinary native comparisons use explicit dtype-appropriate tolerances.', '',
'## Complete-flow timings','',
'Baseline: supported 0.44 2D spatial pooling followed by 1D depth pooling, including reshapes/permutations. Candidate: direct 0.45 3D pooling. A same-source 0.45 composition is retained as a control. The floating composition is mathematically equivalent on the checked finite random inputs; it is not a bitwise replacement for ordered 3D reduction on exceptional or cancellation-dominated values.', '',
'Four fresh processes per runtime, alternating variant/runtime order, five samples per case, 12 ordinary calls or three training steps per sample. All 42 flows validate values/gradients or one complete CNN SGD update before timing. Every sample and child median is retained. Shared-host results describe these workloads, not native Torch/GPU speed or cross-runtime comparisons.', '',
'Percent reduction in elapsed time versus the 0.44 composition; negative values mean the direct 3D operation is slower. The training flow is Conv3d → SiLU → AvgPool3d → global adaptive average → Linear → loss/backward/SGD.', '',
'| Case | Dtype | CPU | Node/WASM | Chrome Worker/WASM |','|---|---|---:|---:|---:|']
for kind,mode in [('fixed','forward'),('fixed','backward'),('global','forward'),('global','backward'),('irregular','backward'),('upsample','backward'),('overlap','forward'),('overlap','backward'),('cnn','training')]:
 for dtype in ['float32','float64']:
  values=[row(runtime,kind,mode,dtype)['direct_time_reduction_percent'] for runtime in ['cpu','node','chrome']]
  lines.append('| '+kind+' / '+mode+' | '+dtype+' | '+' | '.join(f'{x:.1f}%' for x in values)+' |')
lines+=['',
'The new API is useful beyond speed: native-order volumetric reductions and derivatives can be expressed directly. Overlapping fixed windows and some adaptive adjoints can remain slower than the reassociated composition. These are explicit follow-up optimization targets; the evidence does not support a universal speedup claim.', '',
'## Source footprint','',
'| Measure | 0.44 | 0.45 |','|---|---:|---:|']
for key,title in [('raw_source_license_bytes','Source/license bytes'),('local_concatenated_gzip_bytes','Local concatenated gzip estimate')]:
 lines.append(f"| {title} | {proof['source_footprint']['baseline'][key]:,} | {proof['source_footprint']['candidate'][key]:,} |")
lines+=['','These source estimates do not measure wheel size, network transfer, peak memory or GPU storage. Forty-seven prior source/license resources are unchanged; the existing init/API/mean-helper files change and one 3D average module is added.', '',
'## Reproducibility and integration','',
'The preliminary uncached implementation passed its focused/Node/Chrome/minimum-wheel checks. Its owned full CPU test process was deliberately stopped before source optimization, with its process tree, partial log and nonzero receipt retained in `before-index-plans`; observation timeouts were not treated as termination. The optimized source was frozen anew, and every adapter-dependent gate and full-flow timing was run on the final hashes. The native original-catalog run continued because it uses native Torch and unchanged native problem inputs.', '',
'Repository benchmark: [`bench_average_pooling_3d.py`](../../packages/stridetorch/benchmarks/bench_average_pooling_3d.py). Machine-readable source/integration reports and four raw harness archives are in [`benchmarks/results`](../../packages/stridetorch/benchmarks/results/). Reports include exact source/test/export/dependency hashes and installed distribution identities. Native comparison arrays and all timing samples are retained in the archives.', '',
'Seven release-policy files remain byte-identical to canonical commit `13d2782a494415ba72bc604a0ef7e4c4f875ba25`. Validation is local. No tag, workflow dispatch, release, package upload or online deployment is initiated by this iteration. The broader independent-library/core-efficiency/backend goal remains active.','']
if proof.get('upstream_syncs'):lines+=['## Upstream UI integration','']
for sync in proof.get('upstream_syncs',[]):
 lines+=[f"Preserved all {len(sync['paths'])} web/docs changes from `{sync['before']}` through `{sync['after']}` and reran the complete frontend check and both builds. Scope: {sync['scope']}",'']
if proof.get('upstream_syncs'):lines+=['The runtime/test/export/SDK/catalog/release-policy inputs to the CPU, native, installed-package, exported-WASM and performance evidence remain unchanged. Historical upstream hashes are checked against their Git blobs; current files match the latest union. Every original/latest frontend receipt is retained. Existing manually dispatched quality/Pages chains are observed read-only; remote main is held until they are terminal.','']
(repo/'docs/validation/torch-runtime-iteration-45.md').write_text('\n'.join(lines))
p=repo/'packages/stridetorch/ROADMAP.md';text=p.read_text();marker='## Next implementation areas';assert marker in text
entry='''## 0.45: volumetric average pooling

- Fixed/adaptive 3D module and functional APIs cover float32/float64 VJP, JVP,
  reverse-over-forward, fixed int64 and adaptive half inference, native parameter
  and empty/global boundaries, aliases, pickle and complete Conv3d training.
- Ordered 3D sums, disjoint block kernels, bounded packing/streaming and adjoints;
  readonly geometry/gather plans retain no user values, and strided gradient seeds
  are read by block. Global mean canonicalizes native 3D output layout.
- Native differential, minimum-wheel, Node/actual Chrome, exported 78-problem
  catalog, frontend and four-process/runtime whole-flow evidence are retained.
  Overlapping windows and some adaptive adjoints remain optimization targets.
- See [the 0.45 validation record](../../docs/validation/torch-runtime-iteration-45.md).

'''
if '## 0.45:' in text:
 begin=text.index('## 0.45:');end=text.index(marker,begin);text=text[:begin]+text[end:]
p.write_text(text.replace(marker,entry+marker))
p=repo/'packages/stridetorch/benchmarks/README.md';text=p.read_text();marker='\n## Volumetric average pooling (0.45)\n';text=text.split(marker)[0];text+='\n## Volumetric average pooling (0.45)\n\n`bench_average_pooling_3d.py` compares direct 3D fixed/adaptive averages with the\nexisting 2D+1D floating composition and a same-source composition control. It\nchecks forward, strided input, backward, JVP and a complete Conv3d/SGD flow before\ntiming. Pass `--baseline-source`, `--candidate-source` and `--output`; optional\n`--samples`, `--iterations` and `--reverse` retain every sample and source hash.\nThe composition reassociates sums; no bitwise equivalence is claimed for\nexceptional or ill-conditioned values. See the\n[0.45 validation record](../../../docs/validation/torch-runtime-iteration-45.md)\nand `results/iteration-45*.json` plus the four raw harness archives.\n';p.write_text(text)
print('Wrote0.45 validation, roadmap and benchmark guide')
