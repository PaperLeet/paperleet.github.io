from pathlib import Path
import hashlib,io,json,pstats,tarfile
r=Path(__file__).resolve().parent;b=r.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
native=read(b/'torch-iteration-382/result.json');assert native['status']=='passed_full_native_sdk_experimental_terminal_hvp_no_grad'
wasm=read(b/'torch-iteration-386/result.json');assert wasm['passed']==12212 and wasm['failures']==[] and not wasm['skipped']
cleanup=read(b/'torch-iteration-383/result.json');assert len(cleanup['cases'])==8
performance=read(b/'torch-iteration-381/performance.json');assert not performance['aa_outside_5_percent']
norm=[x['candidate_ratio'] for x in performance['flows'] if x['kind']!='polynomial'];control=[x['candidate_ratio'] for x in performance['flows'] if x['kind']=='polynomial']
profiles={}
for label in ['A0','B']:
 stats=pstats.Stats(str(b/'torch-iteration-381'/(label+'.prof')))
 profiles[label]=dict(total_calls=stats.total_calls,node_constructors=[dict(line=key[1],function=key[2],calls=value[1]) for key,value in stats.stats.items() if key[0].endswith('/_graph.py') and key[2]=='__init__'])
write(r/'result.json',dict(status='promising_experimental_terminal_hvp_values_only_pilot',production_changed=False,version_literal='0.81.0 in isolated copies; no new release version assigned',change='Disable gradient recording only during the final third Tensor reverse; preserve first/second passes, callbacks, validation and finally restoration.',native=dict(numpy25_passed=12225,numpy126_passed=12222,numpy126_skipped=3),actual_node_pyodide_passed=12212,terminal_failure_controls=8,pilot=dict(processes=1,full_flows=14,norm_candidate_baseline_range=[min(norm),max(norm)],legacy_control_range=[min(control),max(control)],aa_outside_5_percent=[],scope='CPU only; identicalbaseline/candidatevaluesbeforetiming,12balancedpermutations;notqualification'),profiles=profiles,source_plan_sha256=sha(b/'torch-iteration-380/source-plan.json'),next=['Independent native oracle corpus including exceptional/strict/alias/mutation boundaries','Repeated CPU and actual WASM whole-HVP timing and memory/lifetime checks','Actual Chrome SDK and final package/application/export gates before adoption'],ci_triggered=False,published=False,goal_status='active'))
files=[p for n in [380,381,382,383,386,389] for p in (b/f'torch-iteration-{n}').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name not in ['archive-receipt.json','harness.tar.gz']]
manifest={str(p.relative_to(b)):sha(p) for p in sorted(files)};destination=r/'harness.tar.gz';assert not destination.exists()
with tarfile.open(destination,'w:gz') as stream:
 for p in sorted(files):stream.add(p,arcname=str(p.relative_to(b)),recursive=False)
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256.json');info.size=len(data);stream.addfile(info,io.BytesIO(data))
with tarfile.open(destination) as stream:
 for name,h in manifest.items():assert hashlib.sha256(stream.extractfile(name).read()).hexdigest()==h,name
receipt=dict(files=len(files),bytes=destination.stat().st_size,sha256=sha(destination),verified_all_payloads=True);write(r/'archive-receipt.json',receipt);print(json.dumps(receipt),flush=True)
