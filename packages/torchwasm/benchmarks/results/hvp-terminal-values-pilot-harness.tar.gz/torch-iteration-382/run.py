from pathlib import Path
import hashlib,json,os,subprocess,time,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
candidate=b/'torch-iteration-380/candidate';tests=repo/'packages/stridetorch/tests'
inputs={str(p):sha(p) for p in list((candidate/'stridetorch').glob('*.py'))+list(tests.rglob('*.py'))+[b/'torch-iteration-380/source-plan.json']}
write(r/'execution-plan.json',dict(runner_sha256=sha(Path(__file__)),inputs=inputs,scope='Full existing SDK against isolated experimental terminal-HVP-no-grad candidate; not release qualification'))
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(candidate),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');results={}
for label,python in [('numpy25',b/'torch-iteration-82/application-env/bin/python'),('numpy126',b/'torch-iteration-137/native26-env/bin/python')]:
 for name,h in inputs.items():assert sha(Path(name))==h
 imported=json.loads(subprocess.check_output([str(python),'-B','-c','import stridetorch,json;print(json.dumps(dict(path=stridetorch.__file__,version=stridetorch.__version__)))'],env=env,text=True,cwd=r));assert Path(imported['path']).is_relative_to(candidate)
 args=[str(python),'-B','-m','pytest',str(tests),'-q','-p','no:cacheprovider','--junitxml='+str(r/(label+'.xml'))]
 start=time.monotonic()
 with (r/(label+'.log')).open('w') as f:code=subprocess.run(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 tree=ET.parse(r/(label+'.xml'));suites=list(tree.getroot().iter('testsuite'));totals={key:sum(int(s.attrib.get(key,0)) for s in suites) for key in ['tests','failures','errors','skipped']}
 results[label]=dict(exit_code=code,seconds=time.monotonic()-start,totals=totals,imported=imported,log_sha256=sha(r/(label+'.log')),xml_sha256=sha(r/(label+'.xml')));print(json.dumps({label:results[label]}),flush=True);write(r/'progress.json',results)
 if code:raise SystemExit(code)
write(r/'result.json',dict(status='passed_full_native_sdk_experimental_terminal_hvp_no_grad',results=results,production_changed=False,ci_triggered=False,goal_status='active'))
