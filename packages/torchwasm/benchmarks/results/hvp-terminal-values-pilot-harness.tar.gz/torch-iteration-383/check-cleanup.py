from pathlib import Path
import hashlib,importlib,json,sys
import numpy as np
r=Path(__file__).resolve().parent;b=r.parent
sys.path.insert(0,str(b/'torch-iteration-380/candidate'))
import stridetorch
torch=stridetorch.torch
higher=importlib.import_module('stridetorch._higher_order');state=importlib.import_module('stridetorch._state')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert str(Path(stridetorch.__file__).parent)==str(b/'torch-iteration-380/candidate/stridetorch')
records=[]
for enabled in [False,True]:
 for dtype in ['float32','float64']:
  for fail in [False,True]:
   original=higher.Context.grad;contexts=[];flags=[];calls=[]
   def instrument(self,*args,**kwargs):
    contexts.append(self);flags.append(torch.is_grad_enabled())
    if fail and len(contexts)==3:raise RuntimeError('injected terminal pullback failure')
    return original(self,*args,**kwargs)
   higher.Context.grad=instrument
   x=torch.tensor([.25,.5,.75],dtype=getattr(torch,dtype),requires_grad=True);v=torch.ones_like(x);buffer=torch.full_like(x,7.);x.grad=buffer
   policy=np.geterr();handler=np.geterrcall()
   def function(a):calls.append(1);return torch.linalg.vector_norm(a).square()
   with torch.set_grad_enabled(enabled):
    try:
     try:
      value,product=torch.autograd.functional.hvp(function,x,v)
      assert not fail
      np.testing.assert_allclose(product.numpy(),np.full(3,2.),rtol=1e-5,atol=1e-6)
      assert not value.requires_grad and not product.requires_grad
     except RuntimeError as error:
      assert fail and str(error)=='injected terminal pullback failure'
     assert torch.is_grad_enabled() is enabled
    finally:higher.Context.grad=original
   assert flags==[True,True,False]
   assert calls==[1] and x.grad is buffer
   np.testing.assert_array_equal(buffer.numpy(),np.full(3,7.,dtype=dtype))
   assert state._tensor_reverse_context is None and np.geterr()==policy and np.geterrcall() is handler
   for context in contexts:assert not context.pending and not context.rules and not context.owners and not context.reverse_active
   probe=torch.tensor([2.],requires_grad=True);probe.square().backward();assert probe.grad.item()==4.
   records.append(dict(caller_grad_enabled=enabled,dtype=dtype,injected_failure=fail,gradient_modes=flags,cleared_contexts=True,caller_buffer_unchanged=True,numerical_backward_restored=True))
(r/'result.json').write_text(json.dumps(dict(status='passed_terminal_reverse_success_failure_state_cleanup',cases=records,script_sha256=sha(Path(__file__)),candidate_plan_sha256=sha(b/'torch-iteration-380/source-plan.json'),production_changed=False,goal_status='active'),indent=2)+'\n');print('passed',len(records),'state and failure controls')
