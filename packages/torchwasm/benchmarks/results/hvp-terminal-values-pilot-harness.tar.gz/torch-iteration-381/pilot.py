from pathlib import Path
import cProfile,gc,hashlib,importlib.util,itertools,json,os,pstats,statistics,sys,time
import numpy as np
r=Path(__file__).resolve().parent;b=r.parent;source=b/'torch-iteration-380'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
plan=json.loads((r/'execution-plan.json').read_text())
assert sha(Path(__file__))==plan['runner_sha256']
for name,h in plan['inputs'].items():assert sha(Path(name))==h,name
def load(name,variant):
 path=source/variant/'stridetorch';spec=importlib.util.spec_from_file_location(name,path/'__init__.py',submodule_search_locations=[str(path)]);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
modules={label:load('_pilot381_'+label,'candidate' if label=='B' else 'baseline') for label in ['A0','A1','B']}
def function(api,kind,x):
 if kind=='polynomial':return (x.sin()*x).sum()
 if kind=='norm_square':return api.linalg.vector_norm(x).square()
 if kind=='norm_sine':return api.linalg.vector_norm(x,ord=2.9).sin()
 return api.linalg.vector_norm(x.sin()+.5,ord=1.5).square()
cases=[]
for n,dtype,kind in itertools.product([64,1024],['float32','float64'],['norm_square','norm_sine','composed_norm']):cases.append((n,dtype,kind))
cases.extend([(64,'float32','polynomial'),(1024,'float64','polynomial')])
write(r/'progress.json',dict(status='running',pid=os.getpid()))
flows=[]
for n,dtype,kind in cases:
 raw=(np.arange(n)%19+1).astype(dtype)/32;direction=((np.arange(n)%7)-3).astype(dtype)/8;raw.setflags(write=False);direction.setflags(write=False)
 calls={};expected=None
 for label,module in modules.items():
  api=module.torch;x=api.from_numpy(raw).requires_grad_(True);v=api.from_numpy(direction);buf=api.full_like(x,9.);x.grad=buf
  def invoke(api=api,x=x,v=v,buf=buf):
   value,product=api.autograd.functional.hvp(lambda a:function(api,kind,a),x,v)
   assert not value.requires_grad and not product.requires_grad and x.grad is buf and api.is_grad_enabled()
   return value.numpy(),product.numpy()
  got=invoke()
  if expected is None:expected=got
  else:
   for actual,wanted in zip(got,expected):np.testing.assert_array_equal(actual,wanted)
  calls[label]=invoke
 samples={label:[] for label in modules};was_enabled=gc.isenabled();gc.disable()
 try:
  # One shared calibrated batch count; every raw balanced permutation is kept.
  counts=[]
  for label in modules:
   count=1
   while True:
    started=time.perf_counter()
    for _ in range(count):calls[label]()
    elapsed=time.perf_counter()-started
    if elapsed>=.06 or count>=4096:break
    count*=2
   counts.append(max(1,int(count*.03/elapsed)))
  count=max(counts)
  orders=list(itertools.permutations(modules));orders+=list(reversed(orders))
  for order in orders:
   for label in order:
    started=time.perf_counter()
    for _ in range(count):calls[label]()
    samples[label].append((time.perf_counter()-started)/count)
 finally:
  if was_enabled:gc.enable()
 medians={label:statistics.median(values) for label,values in samples.items()}
 flow=dict(n=n,dtype=dtype,kind=kind,count=count,samples=samples,medians=medians,aa_ratio=medians['A1']/medians['A0'],candidate_ratio=medians['B']/medians['A0']);flows.append(flow);print(json.dumps({k:v for k,v in flow.items() if k not in ['samples','medians']}),flush=True)
write(r/'performance.json',dict(status='pilot_only_not_release_qualification',flows=flows,numpy=np.__version__,python=sys.version,source_plan_sha256=sha(source/'source-plan.json'),processes=1,independent_native_oracle=False,scope='Exact baseline/candidate equality before timing; full public HVP and ownedCPUcopies; oneprocess only; no speedup qualification claim',aa_outside_5_percent=[(f['n'],f['dtype'],f['kind']) for f in flows if not .95<=f['aa_ratio']<=1.05]))
profiles={}
for label,module in modules.items():
 if label=='A1':continue
 api=module.torch;x=api.linspace(.125,.875,64,dtype=api.float64);v=api.ones_like(x)
 profiler=cProfile.Profile();profiler.enable()
 for _ in range(100):api.autograd.functional.hvp(lambda a:api.linalg.vector_norm(a).square(),x,v)
 profiler.disable();profiler.dump_stats(str(r/(label+'.prof')))
 with (r/(label+'-profile.txt')).open('w') as output:pstats.Stats(profiler,stream=output).sort_stats('cumulative').print_stats(40)
 profiles[label]=dict(total_calls=pstats.Stats(profiler).total_calls)
write(r/'result.json',dict(status='completed_experimental_pilot',profiles=profiles,performance_sha256=sha(r/'performance.json'),production_changed=False,ci_triggered=False,goal_status='active'));write(r/'progress.json',dict(status='completed'))
