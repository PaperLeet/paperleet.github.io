import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
import {loadJudgePackages} from '../torch-iteration-76/chrome-sdk/packages.mjs';
self.onmessage=async()=>{
 try{
  const plan=await(await fetch('./qualification-plan.json')).json(),py=await loadPyodide({indexURL:new URL('../torch-iteration-76/runtime/',self.location.href).href,stdout(){},stderr(){}});await loadJudgePackages(py,[]);
  for(const [name,digest] of Object.entries(plan.files)){
   const bytes=new Uint8Array(await(await fetch('./'+name)).arrayBuffer());const actual=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),v=>v.toString(16).padStart(2,'0')).join('');if(actual!==digest)throw Error('source mismatch '+name);
   const target=name.startsWith('tests/')?'/contracts/'+name.slice(6):'/'+name;py.FS.mkdirTree(target.split('/').slice(0,-1).join('/'));py.FS.writeFile(target,bytes);
  }
  const report=JSON.parse(py.runPython("import sys,json\nsys.path[:0]=['/candidate','/']\nfrom stridetorch import torch,_tensor,_attention\nassert _tensor._WASM_MATMUL and _attention._WASM_ATTENTION\nfrom qualification import qualify\njson.dumps(qualify(torch,'/oracle.npz'))"));
  const sdk=JSON.parse(py.runPython(`
import pytest
class Record:
    passed=0
    def __init__(self):self.failures=[]
    def pytest_runtest_logreport(self,report):
        if report.when=='call' and report.passed:self.passed+=1
        if report.failed:self.failures.append(dict(test=report.nodeid,error=str(report.longrepr)[-3000:]))
record=Record()
code=pytest.main(['/contracts','-q','--noconftest','-p','no:cacheprovider','--import-mode=importlib'],plugins=[record])
json.dumps(dict(exit_code=int(code),passed=record.passed,failures=record.failures))
`));self.postMessage({status:sdk.exit_code===0?'passed':'failed',report,sdk,files:plan.files,pyodide:py.version});
 }catch(error){self.postMessage({status:'failed',error:String(error),stack:error.stack});}
};
