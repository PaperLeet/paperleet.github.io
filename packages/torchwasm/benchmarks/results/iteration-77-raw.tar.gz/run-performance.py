from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent
python='/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-69/integration-dev-env/bin/python'
node='/opt/homebrew/bin/node'
files=[q for label in ['baseline','candidate'] for q in (p/label/'stridetorch').iterdir() if q.is_file()]+list((p/'fixtures').glob('*.py'))+[p/'benchmark.py']
plan=dict(files={str(q.relative_to(p)):hashlib.sha256(q.read_bytes()).hexdigest() for q in files});(p/'performance-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
first=json.loads((p/'latency-native-0.json').read_text());assert len(first['rows'])==78
freeze=json.loads((p/'prototype-v4-freeze.json').read_text());assert first['source_hashes']['candidate']==freeze['source_hashes']
receipts=[dict(runtime='native',cycle=0,status='completed',scope='Reused the successful first fresh native process with identical sources, fixtures, program and sampling; not rerun.')]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
for cycle in range(4):
    for runtime in ['native','node','chrome']:
        if cycle==0 and runtime=='native':continue
        for name,digest in plan['files'].items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest,name
        args=[python,'-B','benchmark.py','--baseline-source','baseline/stridetorch','--candidate-source','candidate/stridetorch','--fixtures','fixtures','--cycle',str(cycle),'--output',f'latency-native-{cycle}.json'] if runtime=='native' else [node,f'bench-{runtime}.mjs',str(cycle)]
        start=time.monotonic()
        with (p/f'latency-{runtime}-{cycle}.log').open('w') as log:
            child=subprocess.Popen(args,cwd=p,env=env,stdout=log,stderr=subprocess.STDOUT)
            (p/'performance-progress.json').write_text(json.dumps(dict(status='running',runtime=runtime,cycle=cycle,pid=child.pid,receipts=receipts),indent=2)+'\n');code=child.wait()
        receipt=dict(runtime=runtime,cycle=cycle,exit_code=code,seconds=time.monotonic()-start);receipts.append(receipt);print(json.dumps(receipt),flush=True)
        if code:raise SystemExit(code)
        for name,digest in plan['files'].items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest,name
(p/'performance-progress.json').write_text(json.dumps(dict(status='completed',receipts=receipts),indent=2)+'\n')
