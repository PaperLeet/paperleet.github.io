from pathlib import Path
import hashlib,json,statistics
p=Path(__file__).resolve().parent;assert json.loads((p/'performance-progress.json').read_text())['status']=='completed'
plan=json.loads((p/'performance-plan.json').read_text())
for name,digest in plan['files'].items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest
rows=[];short=[];source=None
for runtime in ['native','node','chrome']:
    trials=[]
    for cycle in range(4):
        report=json.loads((p/f'latency-{runtime}-{cycle}.json').read_text());report=report.get('report',report);assert len(report['rows'])==78;assert report['cycle']==cycle;trials.append(report)
        if source is None:source=report['source_hashes']
        assert report['source_hashes']==source
        for row in report['rows']:
            for label,series in row['samples'].items():
                for index,batch in enumerate(series):
                    if batch['elapsed_seconds']<.02:short.append(dict(runtime=runtime,cycle=cycle,case=row['key'],label=label,index=index,**batch))
    for key in sorted(row['key'] for row in trials[0]['rows']):
        matched=[next(row for row in trial['rows'] if row['key']==key) for trial in trials];ratios=[row['candidate_over_baseline'] for row in matched];controls=[row['control_over_baseline'] for row in matched]
        rows.append(dict(runtime=runtime,key=key,candidate_over_baseline=statistics.median(ratios),candidate_range=[min(ratios),max(ratios)],control_over_baseline=statistics.median(controls),control_range=[min(controls),max(controls)],baseline_seconds=statistics.median(row['median_seconds']['A0'] for row in matched),candidate_seconds=statistics.median(row['median_seconds']['B'] for row in matched)))
result=dict(status='completed',fresh_processes=12,flows_per_process=78,source_hashes=source,rows=rows,total_batches=12*78*9,short_batches=short,paper_source_hashes=trials[0]['paper_source_hashes'],scope='Warm public Tensor, fused SDPA and unchanged PaperLeet attention function bodies. No native-Torch or WebGPU timing, cold-start, transfer or full-app throughput claim.')
(p/'performance-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status='completed',processes=12,rows=len(rows),short_batches=len(short))),flush=True)
