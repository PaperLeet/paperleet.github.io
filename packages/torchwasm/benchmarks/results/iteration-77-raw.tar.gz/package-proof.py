from pathlib import Path
import hashlib,json,os,subprocess,time,zipfile
root=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');p=root/'package-proof';p.mkdir()
uv='/Users/david/.local/bin/uv';dev=root.parent/'torch-iteration-69/integration-dev-env/bin/python'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');env.pop('PYTHONPATH',None)
expected=json.loads((root/'selected-source-freeze.json').read_text())['source_hashes'];receipts=[]
def run(label,args,cwd=p):
    start=time.monotonic()
    with (p/(label+'.log')).open('w') as log:child=subprocess.run(list(map(str,args)),cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
    receipt=dict(label=label,exit_code=child.returncode,seconds=time.monotonic()-start,command=list(map(str,args)),summary=(p/(label+'.log')).read_text().splitlines()[-1:])
    receipts.append(receipt);(p/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');child.check_returncode();print(label,'PASS',receipt['summary'],flush=True)
run('build-standalone',[uv,'build','--python',dev,'--no-build-isolation','--out-dir',p/'dist',repo/'packages/stridetorch'])
run('build-application',[uv,'build','--python',dev,'--no-build-isolation','--out-dir',p/'app-dist',repo])
public=next((p/'dist').glob('*.whl'));private=next((p/'app-dist').glob('*.whl'))
for wheel,prefix in [(public,'stridetorch/'),(private,'paperleet/_vendor/torch/')]:
    with zipfile.ZipFile(wheel) as z:
        actual={name[len(prefix):]:hashlib.sha256(z.read(name)).hexdigest() for name in z.namelist() if name.startswith(prefix)}
        assert actual==expected,(wheel,sorted(set(actual)^set(expected)))
        if wheel==public:
            assert not any(n.startswith('torch/') or n.startswith('paperleet/') for n in z.namelist())
            metadata=z.read('stridetorch-0.75.0.dist-info/METADATA').decode()
            assert 'Requires-Dist: numpy>=1.26' in metadata and 'License-Expression: Apache-2.0' in metadata
run('minimum-environment',[uv,'venv','--python',root.parent/'torch-iteration-71/torch26-oracle-env/bin/python',p/'minimum-env'])
minimum=p/'minimum-env/bin/python'
run('minimum-dependencies',[uv,'pip','install','--python',minimum,'numpy==1.26.4','pytest>=8','setuptools>=77','wheel'])
run('minimum-install',[uv,'pip','install','--python',minimum,'--no-deps',public])
identity="import stridetorch,numpy,sys,importlib.util;assert stridetorch.__version__=='0.75.0';assert numpy.__version__=='1.26.4';assert importlib.util.find_spec('torch') is None;assert importlib.util.find_spec('paperleet') is None;print(sys.version,stridetorch.__file__)"
run('minimum-isolation',[minimum,'-I','-B','-c',identity])
run('minimum-sdk',[minimum,'-I','-B','-m','pytest',repo/'packages/stridetorch/tests','-q','-p','no:cacheprovider','--basetemp',p/'minimum-pytest-tmp'])
run('minimum-isolation-after-tests',[minimum,'-I','-B','-c',identity])
run('coinstall-private',[uv,'pip','install','--python',minimum,'--no-deps',private])
script="""import hashlib,importlib,json,pathlib
expected=json.loads(pathlib.Path('expected.json').read_text())
for name in ['stridetorch','paperleet._vendor.torch']:
 module=importlib.import_module(name)
 assert module.__version__=='0.75.0'
 actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path(module.__file__).parent.iterdir() if p.is_file()}
 assert actual==expected
 with module.as_torch():
  import torch
  assert torch.ones(2,2).sum().item()==4
print('Both installed namespaces and explicit torch aliases verified')
"""
(p/'expected.json').write_text(json.dumps(expected));run('coinstall-identities',[minimum,'-I','-B','-c',script])
result=dict(status='passed',version='0.75.0',source_hashes=expected,receipts=receipts,wheels={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in [public,private]},native_torch_required_by_standalone=False)
(p/'result.json').write_text(json.dumps(result,indent=2)+'\n');print('PACKAGE PROOF PASSED',flush=True)
