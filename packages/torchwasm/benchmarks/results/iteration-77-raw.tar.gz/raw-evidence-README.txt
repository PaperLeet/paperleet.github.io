Iteration 77 evidence

Selected source is 0.75.0. The measured candidate uses a 0.74.0 version literal;
all compute sources are byte-identical. Baseline, candidate, selected, all 77
SDK test files and four unselected attempts are retained. The complete native
Torch 2.6 MATH-backend oracle.npz and every qualifying latency sample are included.
The native generation copy of qualification.py is oracle-generation-qualification.py;
later validation-only additions are in qualification.py and their distinct hashes
are recorded. Do not equate these complete program hashes.

Performance uses main f2d91d09e1559d287f709094774b3d6e95e234d5. Application gates
use 7e7b64a5a5cfd6f296b76a7f6e740fd2f0900889 with 89 exercises. External changes
are retained and not relabeled as performance reruns. Real PaperLeet fixtures
keep unchanged function bodies/imports; aliases are bound during untimed setup.

The original forced SDK failure rejects the old all-batched-negative dispatcher
expectation. A below-threshold negative replaces it, with 91 new positive/range/
lifetime contracts. High-rank shape-helper failure and cold dtype-cache retention
were reproduced before fixing the selected algorithm; original probes survive.

Runtime binaries, environments, caches and pytest temporary trees are excluded.
Runtime identities and pinned repository artifacts identify the used Pyodide/
NumPy closure. Application fixtures are tied to the recorded Git execution base.
Local wheel/sdist outputs were built before a final README documentation-only
paragraph; executable resources/version exactly match selected source. Nothing
was published. Tracemalloc reports tracked operation allocation deltas, not total
RSS or physical WASM memory. Tiny-call overhead and increased packing peaks are
disclosed alongside per-process A/A/B samples.

All tar mtimes are normalized to zero. File mode, uid/gid and owner/group names
are preserved; duplicate bytes become hardlinks only when those metadata match.
The embedded manifest itself is verified separately rather than self-hashed.
