"""Deterministic full-array native controls for batch matmul and fused SDPA."""
import hashlib,json
import numpy as np


def cases():
    rows=[]
    for dtype in ['float32','float64']:
        for name,a,b,order in [
            ('scores64',(2,4,64,64),(2,4,64,64),'attention'),
            ('scores128',(2,4,128,64),(2,4,64,128),'attention'),
            ('weights_v',(2,4,128,128),(2,4,128,64),'C'),
            ('left_broadcast',(1,128,64),(8,64,128),'C'),
            ('right_broadcast',(8,128,64),(64,128),'C'),
            ('cross_broadcast',(2,1,128,64),(1,3,64,128),'C'),
            ('fortran',(4,128,128),(4,128,128),'F'),
            ('stride',(4,128,128),(4,128,128),'stride'),
            ('zero_stride_batch',(8,64,64),(8,64,64),'repeat'),
            ('small_cores',(32,32,64),(32,64,32),'C'),
            ('empty_batch',(0,64,64),(64,64),'C'),
        ]:rows.append(dict(key=dtype+'_'+name,kind='matmul',dtype=dtype,shapes=[a,b],layout=order))
        for name,order,grouped,dropout in [('sdpa','C',False,0.),('sdpa_interleaved','attention',False,0.),('gqa_mask','attention',True,0.),('sdpa_dropout_one','C',False,1.)]:
            rows.append(dict(key=dtype+'_'+name,kind='sdpa',dtype=dtype,shapes=[(2,4,64,64),(2,2 if grouped else 4,64,64),(2,2 if grouped else 4,64,64)],layout=order,grouped=grouped,dropout=dropout,mask=name=='gqa_mask'))
    return rows


def arrange(value,layout,transpose=False):
    if layout=='F':return np.asfortranarray(value)
    if layout=='stride':return np.repeat(value,2,axis=-1)[...,::2]
    if layout=='repeat':return np.broadcast_to(value[:1],value.shape)
    if layout=='attention':
        if transpose:value=value.swapaxes(-1,-2)
        value=np.ascontiguousarray(value.swapaxes(-3,-2)).swapaxes(-3,-2)
        return value.swapaxes(-1,-2) if transpose else value
    return value


def data(case):
    rng=np.random.default_rng(77051)
    values=[arrange((rng.integers(-32,33,size=shape,dtype=np.int32).astype(case['dtype'])/128),case['layout'],transpose=case['kind']=='matmul' and i==1 and case['layout']=='attention') for i,shape in enumerate(case['shapes'])]
    directions=[arrange((rng.integers(-16,17,size=shape,dtype=np.int32).astype(case['dtype'])/128),case['layout'],transpose=case['kind']=='matmul' and i==1 and case['layout']=='attention') for i,shape in enumerate(case['shapes'])]
    return values,directions


def evaluate(torch,case):
    values,directions=data(case)
    primals=tuple(torch.from_numpy(x).requires_grad_(True) for x in values)
    tangents=tuple(torch.from_numpy(x) for x in directions)
    if case['kind']=='matmul':fn=lambda a,b:a@b
    else:
        mask=np.tril(np.ones((64,64),dtype=bool));mask[0]=False
        mask=torch.from_numpy(mask) if case['mask'] else None
        fn=lambda q,k,v:torch.nn.functional.scaled_dot_product_attention(q,k,v,attn_mask=mask,enable_gqa=case['grouped'],dropout_p=case['dropout'],scale=.125)
    y=fn(*primals)
    rng=np.random.default_rng(77052);seed=rng.integers(-16,17,size=tuple(y.shape),dtype=np.int32).astype(case['dtype'])/128
    gradients=torch.autograd.grad(y,primals,torch.from_numpy(seed))
    primal,tangent=torch.func.jvp(fn,primals,tangents)
    loss,hessian=torch.autograd.functional.hvp(lambda *args:fn(*args).square().sum()*.5,primals,tangents)
    output={'y':y,'primal':primal,'jvp':tangent,'loss':loss}
    output.update({'grad'+str(i):x for i,x in enumerate(gradients)})
    output.update({'hvp'+str(i):x for i,x in enumerate(hessian)})
    arrays={name:value.detach().numpy().copy() for name,value in output.items()}
    hashes=[hashlib.sha256(value.tobytes()).hexdigest() for value in [*values,*directions,seed]]
    return arrays,hashes


def qualify(torch,oracle_path):
    expected=np.load(oracle_path,allow_pickle=False);metadata=json.loads(str(expected['metadata']));rows=[]
    assert metadata['cases']==cases()
    for index,case in enumerate(cases()):
        actual,hashes=evaluate(torch,case);assert hashes==metadata['input_hashes'][case['key']],case['key']
        errors={}
        for name,value in actual.items():
            control=expected[str(index)+'_'+name];assert value.shape==control.shape and value.dtype==control.dtype,(case['key'],name,value.shape,control.shape)
            tolerance=4e-4 if case['dtype']=='float32' else 4e-11
            np.testing.assert_allclose(value,control,rtol=tolerance,atol=tolerance)
            errors[name]=float(np.max(np.abs(value.astype('float64')-control.astype('float64')),initial=0))
        assert actual['y'].flags.c_contiguous
        rows.append(dict(case=case['key'],maximum_absolute_errors=errors))
    return dict(status='passed',cases=len(rows),rows=rows,native_torch=metadata['torch'],numpy=np.__version__)
