"""Archive explicit evidence only; never include runtimes, environments or test temps."""
from pathlib import Path
import gzip,hashlib,io,json,os,tarfile
root=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
gates=json.loads((root/'local-integration/gates-result.json').read_text());assert gates['status']=='passed'
assert json.loads((root/'local-integration/gate-progress.json').read_text())['status']=='completed'
assert json.loads((root/'performance-progress.json').read_text())['status']=='completed'
allowed={p for p in root.iterdir() if p.is_file() and p.suffix in ['.py','.mjs','.json','.log','.html','.diff']}
allowed.add(root/'oracle.npz')
for folder in ['baseline','candidate','selected','tests','fixtures','attempt-1-ellipsis','attempt-2-layout-assessment','attempt-3-pre-high-rank-guard','attempt-4-pre-canonical-limits']:
    allowed.update(p for p in (root/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for folder in ['local-integration','main-integration','package-proof']:
    allowed.update(p for p in (root/folder).iterdir() if p.is_file() and p.suffix in ['.py','.mjs','.json','.log'])
for folder in ['package-proof/dist','package-proof/app-dist']:
    allowed.update(p for p in (root/folder).iterdir() if p.is_file())
# Each earlier candidate diagnostic is explicitly retained above.
allowed={p for p in allowed if p.name not in ['archive-manifest.json','archive-verification.json']}
note=root/'raw-evidence-README.txt'
note.write_text('Iteration 77 evidence\n\nSelected source is 0.75.0. The measured candidate uses a 0.74.0 version literal;\nall compute sources are byte-identical. Baseline, candidate, selected, all 77\nSDK test files and four unselected attempts are retained. The complete native\nTorch 2.6 MATH-backend oracle.npz and every qualifying latency sample are included.\nThe native generation copy of qualification.py is oracle-generation-qualification.py;\nlater validation-only additions are in qualification.py and their distinct hashes\nare recorded. Do not equate these complete program hashes.\n\nPerformance uses main f2d91d09e1559d287f709094774b3d6e95e234d5. Application gates\nuse 7e7b64a5a5cfd6f296b76a7f6e740fd2f0900889 with 89 exercises. External changes\nare retained and not relabeled as performance reruns. Real PaperLeet fixtures\nkeep unchanged function bodies/imports; aliases are bound during untimed setup.\n\nThe original forced SDK failure rejects the old all-batched-negative dispatcher\nexpectation. A below-threshold negative replaces it, with 91 new positive/range/\nlifetime contracts. High-rank shape-helper failure and cold dtype-cache retention\nwere reproduced before fixing the selected algorithm; original probes survive.\n\nRuntime binaries, environments, caches and pytest temporary trees are excluded.\nRuntime identities and pinned repository artifacts identify the used Pyodide/\nNumPy closure. Application fixtures are tied to the recorded Git execution base.\nLocal wheel/sdist outputs were built before a final README documentation-only\nparagraph; executable resources/version exactly match selected source. Nothing\nwas published. Tracemalloc reports tracked operation allocation deltas, not total\nRSS or physical WASM memory. Tiny-call overhead and increased packing peaks are\ndisclosed alongside per-process A/A/B samples.\n\nAll tar mtimes are normalized to zero. File mode, uid/gid and owner/group names\nare preserved; duplicate bytes become hardlinks only when those metadata match.\nThe embedded manifest itself is verified separately rather than self-hashed.\n')
allowed.add(note)
paths=sorted(allowed,key=lambda p:str(p.relative_to(root)))
manifest={};entries=[];unique={};regular=hardlinks=0
for path in paths:
    relative=str(path.relative_to(root));digest=hashlib.sha256(path.read_bytes()).hexdigest()
    with tarfile.open(fileobj=io.BytesIO(),mode='w') as temp:info=temp.gettarinfo(str(path),arcname=relative)
    assert info.isfile(),relative
    info.mtime=0
    info.mode &= 0o7777
    key=(digest,info.mode,info.uid,info.gid,info.uname,info.gname)
    manifest[relative]=dict(sha256=digest,size=info.size,mode=info.mode,uid=info.uid,gid=info.gid,uname=info.uname,gname=info.gname)
    if key in unique:
        info.type=tarfile.LNKTYPE;info.linkname=unique[key];info.size=0;hardlinks+=1
    else:unique[key]=relative;regular+=1
    entries.append((path,info))
manifest_path=root/'archive-manifest.json';manifest_path.write_text(json.dumps(dict(files=manifest,normalization='mtime=0; preserved mode and owner metadata; manifest itself is not self-hashed'),indent=2)+'\n')
archive=repo/'packages/stridetorch/benchmarks/results/iteration-77-raw.tar.gz'
with archive.open('wb') as output,gzip.GzipFile(fileobj=output,filename='',mode='wb',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
    for path,info in entries:
        if info.islnk():tar.addfile(info)
        else:
            with path.open('rb') as payload:tar.addfile(info,payload)
    info=tar.gettarinfo(str(manifest_path),arcname='archive-manifest.json');info.mtime=0;info.mode &= 0o7777
    manifest_metadata={field:getattr(info,field) for field in ['mode','uid','gid','uname','gname']}
    with manifest_path.open('rb') as payload:tar.addfile(info,payload)
with tarfile.open(archive,'r:gz') as tar:
    members={m.name:m for m in tar.getmembers()};assert len(members)==len(manifest)+1
    assert tar.extractfile('archive-manifest.json').read()==manifest_path.read_bytes()
    for field,value in manifest_metadata.items():assert getattr(members['archive-manifest.json'],field)==value,field
    for name,expected in manifest.items():
        actual=members[name];data=tar.extractfile(actual).read()
        assert hashlib.sha256(data).hexdigest()==expected['sha256'] and len(data)==expected['size'],name
        for field in ['mode','uid','gid','uname','gname']:assert getattr(actual,field)==expected[field],(name,field)
result=dict(status='verified',archive=str(archive),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size,logical_payloads=len(manifest)+1,unique_payloads=regular+1,hardlinks=hardlinks,all_logical_payloads_and_owner_modes_verified=True)
(root/'archive-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
