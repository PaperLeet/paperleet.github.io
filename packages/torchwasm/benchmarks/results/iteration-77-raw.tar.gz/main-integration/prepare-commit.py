from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).resolve().parent;r=p.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
freeze=read(r/'selected-source-freeze.json');gates=read(r/'local-integration/gates-result.json')
assert gates['status']=='passed' and read(r/'selection-review.json')['status']=='qualified_for_local_application_gates'
assert read(r/'archive-verification.json')['status']=='verified'
assert read(r/'package-proof/result.json')['status']=='passed'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==freeze['upstream']
for name,digest in freeze['source_hashes'].items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==digest,name
for name,digest in read(r/'runtime-identity.json')['files'].items():assert sha(repo/name)==digest,name
public=read(repo/'packages/stridetorch/benchmarks/results/iteration-77.json');archive=read(r/'archive-verification.json')
assert public['source_hashes']==freeze['source_hashes'] and public['raw_archive']['sha256']==archive['sha256']
assert sha(Path(archive['archive']))==archive['sha256']
owned=set(read(r/'local-owned-inputs.json'))
owned.update(read(r/'local-integration/new-assets-sha256.json'))
owned.update('web/public/data/'+name for name in ['index.json','index-v3.json','catalog.json'])
owned.update(['docs/validation/torch-runtime-iteration-77.md','packages/stridetorch/benchmarks/results/iteration-77.json','packages/stridetorch/benchmarks/results/iteration-77-raw.tar.gz'])
entries=subprocess.check_output(['git','status','--porcelain','-z','--untracked-files=all'],cwd=repo).decode().split('\0')
actual={entry[3:] for entry in entries if entry};assert actual==owned,(sorted(actual-owned),sorted(owned-actual))
assert all(entry[:2] in [' M','??'] for entry in entries if entry)
for name,digest in read(r/'local-owned-inputs.json').items():assert sha(repo/name)==digest,name
subprocess.run(['git','diff','--check'],cwd=repo,check=True)
manifest={name:sha(repo/name) for name in owned}
(p/'owned-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
qualified={name:sha(repo/name) for name in read(r/'local-integration/application-inputs.json')}
qualified.update({'packages/stridetorch/src/stridetorch/'+name:digest for name,digest in freeze['source_hashes'].items()})
qualified.update({'packages/stridetorch/tests/'+name:digest for name,digest in read(r/'local-integration/test-inputs.json').items()})
qualified.update({'web/public/data/'+name:digest for name,digest in read(p/'live-export-sha256.json').items()})
frontend=subprocess.check_output(['git','ls-files','-z','--','web/src','web/scripts','web/index.html','web/package.json','web/package-lock.json','web/vite.config.ts','web/tsconfig*.json','web/public/browser-judge','.github/workflows'],cwd=repo).decode().split('\0')
qualified.update({name:sha(repo/name) for name in frontend if name})
qualified.update(manifest)
for name in ['pyproject.toml','papers.yaml']:qualified[name]=sha(repo/name)
(p/'qualified-git-blobs.json').write_text(json.dumps(qualified,indent=2)+'\n')
paths=p/'owned-paths.txt';paths.write_bytes(b'\0'.join(n.encode() for n in sorted(owned))+b'\0')
subprocess.run(['git','add','--pathspec-from-file='+str(paths),'--pathspec-file-nul'],cwd=repo,check=True)
staged=set(subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=repo).decode().rstrip('\0').split('\0'));assert staged==owned
subprocess.run(['git','diff','--cached','--check'],cwd=repo,check=True)
print(json.dumps(dict(status='ready_to_commit',owned_paths=len(owned),qualified_git_blobs=len(qualified),source_resources=len(freeze['source_hashes']))),flush=True)
