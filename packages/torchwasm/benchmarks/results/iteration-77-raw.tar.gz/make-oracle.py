from pathlib import Path
import hashlib,json,sys
import numpy as np
import torch
from torch.nn.attention import sdpa_kernel,SDPBackend
from qualification import cases,evaluate

p=Path(__file__).resolve().parent;output={};hashes={}
with sdpa_kernel([SDPBackend.MATH]):
    for index,case in enumerate(cases()):
        values,inputs=evaluate(torch,case);hashes[case['key']]=inputs
        output.update({str(index)+'_'+name:value for name,value in values.items()})
metadata=dict(cases=cases(),input_hashes=hashes,torch=torch.__version__,torch_git=torch.version.git_version,numpy=np.__version__,python=sys.version,native_sdpa_backend='MATH')
output['metadata']=np.array(json.dumps(metadata))
np.savez_compressed(p/'oracle.npz',**output)
receipt=dict(status='passed',cases=len(cases()),torch=torch.__version__,sdpa_backend='MATH',oracle_sha256=hashlib.sha256((p/'oracle.npz').read_bytes()).hexdigest(),oracle_bytes=(p/'oracle.npz').stat().st_size,program_sha256=hashlib.sha256((p/'qualification.py').read_bytes()).hexdigest())
(p/'oracle-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
