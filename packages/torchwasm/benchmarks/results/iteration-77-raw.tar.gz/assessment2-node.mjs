import fs from 'node:fs';import crypto from 'node:crypto';
import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
async function main(){
 const root=new URL('./',import.meta.url),py=await loadPyodide({indexURL:new URL('../torch-iteration-76/runtime/',root).pathname,stdout(){},stderr(){}});await py.loadPackage('numpy');
 const source=fs.readFileSync(new URL('candidate/stridetorch/_matmul.py',root));py.FS.mkdirTree('/candidate/stridetorch');py.FS.writeFile('/candidate/stridetorch/_matmul.py',source);
 const code=fs.readFileSync(new URL('assessment2.py',root));const result=JSON.parse(py.runPython(code.toString('utf8')));
 result.node=process.version;result.pyodide=py.version;result.source_sha256=crypto.createHash('sha256').update(source).digest('hex');result.program_sha256=crypto.createHash('sha256').update(code).digest('hex');
 fs.writeFileSync(new URL('assessment2-node.json',root),JSON.stringify(result,null,2)+'\n');
 for(const dtype of ['float32','float64'])for(const name of [...new Set(result.rows.map(r=>r.case))]){const rows=result.rows.filter(r=>r.dtype===dtype&&r.case===name);console.log(dtype,name,Object.fromEntries(rows.map(r=>[r.method,Math.round(r.median_seconds*1e6)])));}
}
main().catch(error=>{console.error(String(error));process.exitCode=1;});
