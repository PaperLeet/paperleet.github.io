import fs from 'node:fs';import crypto from 'node:crypto';import assert from 'node:assert/strict';
import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
import {loadJudgePackages} from '../torch-iteration-76/chrome-sdk/packages.mjs';
async function main(){
 const root=new URL('./',import.meta.url),py=await loadPyodide({indexURL:new URL('../torch-iteration-76/runtime/',root).pathname,stdout(){},stderr(){}});await loadJudgePackages(py,[]);const sources={};
 for(const name of fs.readdirSync(new URL('candidate/stridetorch/',root))){const bytes=fs.readFileSync(new URL('candidate/stridetorch/'+name,root));sources[name]=crypto.createHash('sha256').update(bytes).digest('hex');py.FS.mkdirTree('/candidate/stridetorch');py.FS.writeFile('/candidate/stridetorch/'+name,bytes);}
 for(const name of ['qualification.py','oracle.npz'])py.FS.writeFile('/'+name,fs.readFileSync(new URL(name,root)));
 const report=JSON.parse(py.runPython("import sys,json\nsys.path[:0]=['/candidate','/']\nfrom stridetorch import torch,_tensor,_attention\nassert _tensor._WASM_MATMUL and _attention._WASM_ATTENTION\nfrom qualification import qualify\njson.dumps(qualify(torch,'/oracle.npz'))"));assert.equal(report.status,'passed');assert.equal(report.cases,30);
 const tests={};py.FS.mkdirTree('/contracts');
 for(const name of fs.readdirSync(new URL('tests/',root)).filter(name=>/^test_[a-z0-9_]+\.py$/.test(name)&&name!=='test_standalone.py')){const bytes=fs.readFileSync(new URL('tests/'+name,root));tests[name]=crypto.createHash('sha256').update(bytes).digest('hex');py.FS.writeFile('/contracts/'+name,bytes);}
 const sdk=JSON.parse(py.runPython(`
import pytest
class Record:
    passed=0
    def __init__(self):self.failures=[]
    def pytest_runtest_logreport(self,report):
        if report.when=='call' and report.passed:self.passed+=1
        if report.failed:self.failures.append(dict(test=report.nodeid,error=str(report.longrepr)[-3000:]))
record=Record()
code=pytest.main(['/contracts','-q','--noconftest','-p','no:cacheprovider','--import-mode=importlib'],plugins=[record])
json.dumps(dict(exit_code=int(code),passed=record.passed,failures=record.failures))
`));
 fs.writeFileSync(new URL('qualification-node.json',root),JSON.stringify({...report,source_hashes:sources,test_hashes:tests,sdk,pyodide:py.version,node:process.version},null,2)+'\n');assert.equal(sdk.exit_code,0,JSON.stringify(sdk.failures));assert.equal(sdk.passed,9002);console.log(JSON.stringify({status:report.status,cases:report.cases,sdk_passed:sdk.passed}));
}
main().catch(error=>{console.error(String(error));process.exitCode=1;});
