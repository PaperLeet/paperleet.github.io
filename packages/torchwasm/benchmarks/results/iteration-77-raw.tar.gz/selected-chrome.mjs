import fs from 'node:fs';import assert from 'node:assert/strict';
import {withFixtureServer} from '../torch-iteration-70/fixture-server.mjs';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
await withFixtureServer(async origin=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 try{
  const page=await browser.newPage();await page.goto(origin+'/torch-iteration-77/index.html');
  const result=await page.evaluate(()=>new Promise((resolve,reject)=>{const worker=new Worker('./selected-worker.mjs',{type:'module'});const timer=setTimeout(()=>{worker.terminate();reject(Error('qualification timeout'));},360000);worker.onmessage=({data})=>{clearTimeout(timer);worker.terminate();resolve(data);};worker.onerror=e=>{clearTimeout(timer);worker.terminate();reject(Error(e.message));};worker.postMessage({});}));
  fs.writeFileSync(new URL('selected-chrome-result.json',import.meta.url),JSON.stringify({...result,browser:browser.version()},null,2)+'\n');assert.equal(result.status,'passed',JSON.stringify(result));assert.equal(result.report.cases,30);assert.equal(result.sdk.passed,9002);console.log(JSON.stringify({status:result.status,cases:result.report.cases,sdk_passed:result.sdk.passed}));
 }finally{await browser.close();}
});
