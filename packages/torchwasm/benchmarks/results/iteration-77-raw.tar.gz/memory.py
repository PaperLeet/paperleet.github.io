"""Tracked operation allocations and actual source-buffer lifetime controls."""
import gc,hashlib,json,sys,tracemalloc,weakref
from pathlib import Path
import benchmark


def run(baseline,candidate,fixtures):
    rows=[];sources={}
    for label,root in [('baseline',baseline),('candidate',candidate)]:
        module=benchmark.load(root,'memory_'+label);api=module.torch
        module._tensor._WASM_MATMUL=True
        if hasattr(module._attention,'_WASM_ATTENTION'):module._attention._WASM_ATTENTION=True
        sources[label]={q.name:hashlib.sha256(q.read_bytes()).hexdigest() for q in Path(root).iterdir() if q.is_file()}
        paper=benchmark.paper_functions(module,fixtures)
        for case in ['fortran','repeat_batch','sdpa128','gqa128','paper_attention','paper_gqa']:
            for mode in ['forward','backward']:
                spec=next(row for row in benchmark.specifications() if row['dtype']=='float32' and row['name']==case and row['mode']==mode)
                raw=benchmark.make_inputs(spec);owners=[weakref.ref(module._tensor.storage_owner(value)) for value in raw[0]]
                fn=benchmark.make_flow(module,spec,raw,paper)
                fn();gc.collect();tracemalloc.start();gc.collect();before=tracemalloc.get_traced_memory()[0];tracemalloc.reset_peak()
                output=fn();during,peak=tracemalloc.get_traced_memory();del output;gc.collect();after_one=tracemalloc.get_traced_memory()[0]
                for _ in range(12):fn()
                gc.collect();after_many=tracemalloc.get_traced_memory()[0];tracemalloc.stop()
                assert after_many-before<65536,(label,case,mode,after_many-before)
                del raw,fn;gc.collect();assert all(ref() is None for ref in owners),(label,case,mode,'retained input storage')
                rows.append(dict(label=label,case=case,mode=mode,live_result_delta=during-before,peak_delta=peak-before,after_one_delta=after_one-before,after_thirteen_delta=after_many-before,inputs_collected=True))
    return dict(status='passed',scope='Tracked Python/NumPy operation allocation deltas and source ndarray owner lifetime; not RSS or physical WASM memory',platform=sys.platform,source_hashes=sources,rows=rows)


if __name__=='__main__':
    p=Path(__file__).resolve().parent;result=run(p/'baseline/stridetorch',p/'candidate/stridetorch',p/'fixtures');(p/'memory-native.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],rows=len(result['rows']))),flush=True)
