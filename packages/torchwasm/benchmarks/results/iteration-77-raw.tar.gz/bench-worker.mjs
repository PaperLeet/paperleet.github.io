import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
self.onmessage=async({data})=>{
 try{
  const plan=await(await fetch('./performance-plan.json')).json(),py=await loadPyodide({indexURL:new URL('../torch-iteration-76/runtime/',self.location.href).href,stdout(){},stderr(){}});await py.loadPackage('numpy');
  for(const [name,digest] of Object.entries(plan.files)){
   const bytes=new Uint8Array(await(await fetch('./'+name)).arrayBuffer());const actual=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),v=>v.toString(16).padStart(2,'0')).join('');if(actual!==digest)throw Error('source mismatch '+name);
   py.FS.mkdirTree('/'+name.split('/').slice(0,-1).join('/'));py.FS.writeFile('/'+name,bytes);
  }
  py.globals.set('cycle',data.cycle);
  const report=JSON.parse(py.runPython("import sys,json\nsys.path.insert(0,'/')\nfrom benchmark import run\njson.dumps(run('/baseline/stridetorch','/candidate/stridetorch','/fixtures',cycle))"));self.postMessage({status:'completed',report,pyodide:py.version,programs:plan.files});
 }catch(error){self.postMessage({status:'failed',error:String(error),stack:error.stack});}
};
