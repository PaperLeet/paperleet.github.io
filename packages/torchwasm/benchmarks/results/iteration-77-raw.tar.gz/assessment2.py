import importlib.util,json,statistics,time
from pathlib import Path
import numpy as np

spec=importlib.util.spec_from_file_location('batch_candidate','/candidate/stridetorch/_matmul.py')
kernel=importlib.util.module_from_spec(spec);spec.loader.exec_module(kernel)
specs=[
    ('small_cores',(32,32,64),(32,64,32),'C'),
    ('scores64',(2,4,64,64),(2,4,64,64),'attention'),
    ('scores128',(2,4,128,64),(2,4,64,128),'attention'),
    ('scores256',(1,4,256,64),(1,4,64,256),'attention'),
    ('weights_v',(2,4,128,128),(2,4,128,64),'C'),
    ('broadcast_left',(1,128,64),(16,64,128),'C'),
    ('broadcast_right',(16,128,64),(64,128),'C'),
    ('cross_batch',(2,1,128,64),(1,3,64,128),'C'),
    ('fortran',(4,128,128),(4,128,128),'F'),
    ('strided',(4,128,128),(4,128,128),'stride'),
    ('long_reduce',(8,32,1024),(8,1024,32),'C'),
    ('two_d_control',(256,256),(256,256),'C'),
]

def arrange(value,name,side):
    if name=='F':return np.asfortranarray(value)
    if name=='stride':return np.repeat(value,2,axis=-1)[...,::2]
    if name=='attention':
        if side=='a':
            return np.swapaxes(np.ascontiguousarray(np.swapaxes(value,-3,-2)),-3,-2)
        transposed=np.swapaxes(value,-1,-2)
        transposed=np.swapaxes(np.ascontiguousarray(np.swapaxes(transposed,-3,-2)),-3,-2)
        return np.swapaxes(transposed,-1,-2)
    return value


def loop_product(a,b,use_out=False):
    shape=np.broadcast_shapes(a.shape[:-2],b.shape[:-2])
    aa=np.broadcast_to(a,shape+a.shape[-2:]);bb=np.broadcast_to(b,shape+b.shape[-2:])
    result=np.empty(shape+(a.shape[-2],b.shape[-1]),dtype=a.dtype)
    for index in np.ndindex(shape):
        if use_out:np.einsum('ik,jk->ij',aa[index],bb[index].T,out=result[index],optimize=False)
        else:result[index]=np.einsum('ik,kj->ij',aa[index],bb[index],optimize=False)
    return result

rows=[]
for dtype in ['float32','float64']:
    for name,sa,sb,order in specs:
        rng=np.random.default_rng(7701)
        a=arrange(rng.uniform(-1,1,size=sa).astype(dtype),order,'a')
        b=arrange(rng.uniform(-1,1,size=sb).astype(dtype),order,'b')
        reference=a.astype('float64')@b.astype('float64')
        methods={'matmul':lambda:a@b,
                 'einsum':lambda:np.ascontiguousarray(np.einsum('...ik,...kj->...ij',a,b,optimize=False)),
                 'packed':lambda:np.ascontiguousarray(np.einsum('...ik,...jk->...ij',a,np.ascontiguousarray(np.swapaxes(b,-1,-2)),optimize=False)),
                 'candidate':lambda:kernel.product(a,b)}
        methods['packed_both']=lambda:np.ascontiguousarray(np.einsum('...ik,...jk->...ij',np.ascontiguousarray(a),np.ascontiguousarray(np.swapaxes(b,-1,-2)),optimize=False))
        methods['loop']=lambda:loop_product(a,b)
        methods['loop_out']=lambda:loop_product(a,b,True)
        if b.ndim==2 and a.flags.c_contiguous:
            methods['flatten_rhs2']=lambda:np.ascontiguousarray(np.einsum('ik,kj->ij',a.reshape(-1,a.shape[-1]),b,optimize=False)).reshape(reference.shape)
        for method,fn in methods.items():
            value=fn();np.testing.assert_allclose(value,reference,rtol=3e-4 if dtype=='float32' else 1e-10,atol=3e-4 if dtype=='float32' else 1e-10)
            n=1
            while True:
                start=time.perf_counter()
                for _ in range(n):fn()
                elapsed=time.perf_counter()-start
                if elapsed>=.02:break
                n*=2
            timings=[]
            for _ in range(3):
                start=time.perf_counter()
                for _ in range(n):fn()
                timings.append((time.perf_counter()-start)/n)
            rows.append(dict(case=name,dtype=dtype,shape_a=list(a.shape),shape_b=list(b.shape),layout=order,strides_a=list(a.strides),strides_b=list(b.strides),method=method,median_seconds=statistics.median(timings),iterations=n,max_absolute_error=float(np.max(np.abs(value.astype('float64')-reference))),c_contiguous=bool(value.flags.c_contiguous)))
json.dumps(dict(status='passed',scope='Single-process sequential exploratory kernel assessment; not adoption evidence',numpy=np.__version__,rows=rows))
