import fs from 'node:fs';import crypto from 'node:crypto';import assert from 'node:assert/strict';
import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
async function main(){
 const root=new URL('./',import.meta.url),plan=JSON.parse(fs.readFileSync(new URL('performance-plan.json',root))),py=await loadPyodide({indexURL:new URL('../torch-iteration-76/runtime/',root).pathname,stdout(){},stderr(){}});await py.loadPackage('numpy');
 for(const [name,digest] of Object.entries(plan.files)){const bytes=fs.readFileSync(new URL(name,root));assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),digest,name);py.FS.mkdirTree('/'+name.split('/').slice(0,-1).join('/'));py.FS.writeFile('/'+name,bytes);}
 const memory=fs.readFileSync(new URL('memory.py',root));py.FS.writeFile('/memory.py',memory);
 const report=JSON.parse(py.runPython("import sys,json\nsys.path.insert(0,'/')\nfrom memory import run\njson.dumps(run('/baseline/stridetorch','/candidate/stridetorch','/fixtures'))"));
 fs.writeFileSync(new URL('memory-node.json',root),JSON.stringify({...report,pyodide:py.version,node:process.version,memory_program_sha256:crypto.createHash('sha256').update(memory).digest('hex')},null,2)+'\n');assert.equal(report.status,'passed');console.log(JSON.stringify({status:report.status,rows:report.rows.length}));
}
main().catch(error=>{console.error(String(error));process.exitCode=1;});
