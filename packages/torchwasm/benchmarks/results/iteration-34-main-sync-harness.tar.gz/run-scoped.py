from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');env=dict(os.environ,PATH='/opt/homebrew/bin:'+os.environ['PATH']);receipts=[]
def run(args,name,cwd,overrides=None):
 start=time.monotonic()
 with (r/name).open('w') as log:p=subprocess.run(args,cwd=cwd,env={**env,**(overrides or {})},stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(args=args,log=name,cwd=str(cwd),exit_code=p.returncode,elapsed_s=time.monotonic()-start,overrides=overrides or {}));(r/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,'terminal',p.returncode,flush=True);p.check_returncode()
scripts=['check-solution-reading','check-community-solutions','check-discussion-reading','check-community-navigation','check-community-card-actions','check-community-discussion','check-discussion-replies','check-reply-quotes','check-post-preview','check-reading-tabs','check-reading-return','check-workspace-ui','check-workspace-actions','check-deferred-features']
for name in scripts:run(['/opt/homebrew/bin/node','scripts/'+name+'.mjs'],name+'.log',repo/'web')
run(['npm','run','build'],'build-default.log',repo/'web')
value=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED','--jq','.value'],cwd=repo,text=True).strip();profile=dict(VITE_PUBLIC_SITE='0',VITE_APP_EDITION='hosted',VITE_API_ORIGIN='https://app.paperleet.com',VITE_HOSTED_APP_AVAILABLE='1',VITE_HOSTED_APP_URL='https://app.paperleet.com') if value=='1' else dict(VITE_PUBLIC_SITE='1',VITE_APP_EDITION='public',VITE_API_ORIGIN='',VITE_HOSTED_APP_AVAILABLE='1',VITE_HOSTED_APP_URL='https://app.paperleet.com');(r/'pages-profile.json').write_text(json.dumps(dict(value=value,environment=profile),indent=2)+'\n')
run(['npm','run','build'],'build-pages.log',repo/'web',profile)
print('All14 scopedUI checks and both typed builds terminal0',flush=True)
