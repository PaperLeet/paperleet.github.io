from pathlib import Path
import json,numpy as np,torch
from stridetorch import torch as lite,_average_pooling as module
rng=np.random.default_rng(3902);counts=dict(valid=0,invalid=0,gradients=0)
for trial in range(360):
 h,w=rng.integers(1,10,size=2).tolist();shape=(2,2,h,w) if trial%3 else (2,h,w)
 dtype=[np.float32,np.float64,np.float16,np.int64][trial%4];a=rng.integers(-5,6,size=shape).astype(dtype)
 if trial%13==0 and np.dtype(dtype).kind=='f':a.flat[::7]=np.nan
 if trial%17==0 and np.dtype(dtype).kind=='f':a.flat[::5]=np.inf
 if trial%23==0 and np.dtype(dtype).kind=='f':a[:]=1e38 if dtype==np.float32 else 1e308 if dtype==np.float64 else 65504
 adaptive=bool((trial//4)%2);k=rng.integers(1,5,size=2).tolist();stride=rng.integers(1,4,size=2).tolist();padding=[int(rng.integers(v//2+1)) for v in k]
 kw=dict(output_size=tuple(rng.integers(1,11,size=2).tolist())) if adaptive else dict(kernel_size=k,stride=stride,padding=padding,ceil_mode=bool(trial%3),count_include_pad=bool(trial%5),divisor_override=-3 if trial%7==0 else None)
 name='adaptive_avg_pool2d' if adaptive else 'avg_pool2d'
 try:ny=getattr(torch.nn.functional,name)(torch.from_numpy(a),**kw)
 except Exception:
  try:getattr(lite.nn.functional,name)(lite.from_numpy(a),**kw)
  except Exception:counts['invalid']+=1;continue
  raise AssertionError(('Native-invalid accepted',trial,shape,kw))
 for algorithm in ['scan','packed','auto','matrix','block']:
  module._ALGORITHM=algorithm;y=getattr(lite.nn.functional,name)(lite.from_numpy(a),**kw)
  np.testing.assert_allclose(y.numpy(),ny.numpy(),rtol=2e-3 if dtype==np.float16 else 3e-6 if dtype==np.float32 else 1e-12,atol=1e-6,equal_nan=True,err_msg=f'{trial}/{name}/{algorithm}/{shape}/{kw}')
  np.testing.assert_array_equal(np.isnan(y.numpy()),np.isnan(ny.numpy()));np.testing.assert_array_equal(np.isinf(y.numpy()),np.isinf(ny.numpy()))
  if dtype not in [np.float32,np.float64]:continue
  seed=rng.normal(size=y.shape).astype(dtype)
  for backward in ['loop','scatter','auto','matrix','block']:
   module._BACKWARD_ALGORITHM=backward;x=lite.from_numpy(a).requires_grad_();nx=torch.from_numpy(a).requires_grad_();value=getattr(lite.nn.functional,name)(x,**kw);expected=getattr(torch.nn.functional,name)(nx,**kw)
   value.backward(lite.tensor(seed));expected.backward(torch.tensor(seed));np.testing.assert_allclose(x.grad.numpy(),nx.grad.numpy(),rtol=2e-6 if dtype==np.float32 else 1e-12,atol=1e-7,equal_nan=True);counts['gradients']+=1
 counts['valid']+=1
module._ALGORITHM=module._BACKWARD_ALGORITHM='auto';Path(__file__).with_name('fuzz-final-kernels.json').write_text(json.dumps(dict(status='success',trials=360,seed=3902,counts=counts),indent=2)+'\n');print(counts)
