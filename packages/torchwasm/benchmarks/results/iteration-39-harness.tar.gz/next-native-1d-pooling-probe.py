from pathlib import Path
import json,torch
rows=[]
for dtype in (torch.float16,torch.float32,torch.float64,torch.int64):
 for name,kw in [('avg_pool1d',dict(kernel_size=2)),('avg_pool1d',dict(kernel_size=3,stride=2,padding=1,ceil_mode=True,count_include_pad=False)),('avg_pool1d',dict(kernel_size=2,stride=[])),('adaptive_avg_pool1d',dict(output_size=1)),('adaptive_avg_pool1d',dict(output_size=3))]:
  try:y=getattr(torch.nn.functional,name)(torch.arange(10,dtype=dtype).reshape(1,2,5),**kw);result=dict(shape=list(y.shape),values=y.tolist())
  except Exception as e:result=dict(error=type(e).__name__,message=str(e)[:160])
  rows.append(dict(kind='values',dtype=str(dtype),name=name,kwargs=kw,**result))
for name in ('avg_pool1d','adaptive_avg_pool1d'):
 for global_size in (False,True):
  for target in ('input','output','tangent','tangent_input','jvp_input'):
   x=torch.ones(1,2,5,dtype=torch.float64,requires_grad=True);v=torch.ones_like(x,requires_grad=True)
   fn=(lambda z:torch.nn.functional.adaptive_avg_pool1d(z,1 if global_size else 3)) if name=='adaptive_avg_pool1d' else (lambda z:torch.nn.functional.avg_pool1d(z,5 if global_size else 2))
   if target in ('tangent','tangent_input','jvp_input'):p,t=torch.func.jvp(fn,(x,),(v,));y=t
   else:p=fn(x);y=p
   with torch.no_grad():{'input':x,'output':p,'tangent':t if target=='tangent' else p,'tangent_input':v,'jvp_input':x}[target].detach().add_(1)
   try:y.sum().backward();result=dict(status='success',primal_reverse_edge=x.grad is not None,tangent_reverse_edge=v.grad is not None)
   except Exception as e:result=dict(status=type(e).__name__)
   rows.append(dict(kind='storage_versions',name=name,global_size=global_size,target=target,**result))
for size in (1,3,(3,),[3],(None,),None,0,-1,True):
 try:y=torch.nn.functional.adaptive_avg_pool1d(torch.ones(1,2,5),size);result=dict(shape=list(y.shape))
 except Exception as e:result=dict(error=type(e).__name__,message=str(e)[:160])
 rows.append(dict(kind='output_size',output_size=size,**result))
report=dict(scope='Native-only exploratory reference for future1D core coverage;not implemented API or performance evidence.',torch=torch.__version__,rows=rows)
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print('Recorded',len(rows),'native1D probes')
