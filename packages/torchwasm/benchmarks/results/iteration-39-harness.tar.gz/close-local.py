from pathlib import Path
import hashlib, json, os, shutil, tarfile

r = Path(__file__).resolve().parent
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
out = repo/'packages/stridetorch/benchmarks/results'

def read(name): return json.loads((r/name).read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(name, value): (out/name).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')

actual = {f.name: sha(f) for f in (repo/'packages/stridetorch/src/stridetorch').iterdir()
          if f.suffix == '.py' or f.name in ('LICENSE', 'NOTICE')}
tests = {f.name: sha(f) for f in (repo/'packages/stridetorch/tests').glob('test_*.py')
         if f.name != 'test_standalone.py'}
plan = read('proof/chrome-contracts/plan.json')
assert len(actual) == 49 and actual == read('proof/source-hashes.json') == plan['source']
assert len(tests) == 38 and tests == plan['tests'] and plan['expected'] == 2154
full = read('full-root-receipt.json')
assert full['exit_code'] == 0 and full['passed'] >= 34887 and full['skipped'] == 1
assert '1938 passed' in (r/'focus-adjoint-final-related.log').read_text()
gates = read('proof/gate-receipts.json')
assert len(gates) == 6 and all(v['exit_code'] == 0 for v in gates.values())
node = read('proof/source-wasm.json'); chrome = read('proof/chrome-contracts/result.json')
wheel = read('proof/wheel-stride039-result.json'); coinstall = read('proof/coinstall-result.json')
assert node['passed'] == chrome['passed'] == 2154
assert node['source_hashes'] == chrome['source_hashes'] == wheel['source_hashes'] == coinstall['source_hashes'] == actual
assert chrome['test_hashes'] == tests and not wheel['native_torch']
assert all(v['status'] == 'success' for v in (chrome, wheel, coinstall))
assert node['library'] == '0.39.0' and node['numpy'] == '2.2.5'
assert '2167 passed' in (r/'proof/python310-stride039-tests.log').read_text()
audit = read('existing-source-audit.json')
assert audit['status'] == 'success' and audit['unchanged_resources'] == 45 and audit['source_hashes'] == actual
fuzz = [read(f'fuzz-final-{kind}.json') for kind in ('integers', 'floats')]
assert all(v['status'] == 'success' and v['trials'] == 360 and v['source_hashes'] == actual for v in fuzz)
assert sum(v['counts']['gradients'] for v in fuzz) == 8575

regression = read('performance-final-summary.json'); average = read('average-final-summary.json')
imports = read('import-summary.json')
assert len(regression['receipts']) == len(average['receipts']) == 8
assert all(v['exit_code'] == 0 for v in [*regression['receipts'].values(), *average['receipts'].values()])
assert len(imports['receipts']) == 16 and all(v['exit_code'] == 0 for v in imports['receipts'])
for folder, field, count in [('performance-final', 'candidate', 21), ('average-performance-final', 'current', 36)]:
    rows = [p for p in (r/folder).glob('*.json') if p.name != 'receipts.json']
    assert len(rows) == 8
    for path in rows:
        row = json.loads(path.read_text())
        assert row['source_hashes'][field] == actual and len(row['results']) == count
        if field == 'current': assert row['source_hashes']['scan'] == actual
followup = read('targeted-followup-summary.json'); memory = read('adjoint-memory-final.json')
assert len(followup['receipts']) == 8 and all(v['exit_code'] == 0 for v in followup['receipts'].values())
assert all(row['report']['source_hashes']['candidate'] == actual and len(row['report']['results']) == 4 for row in followup['reports'])
assert memory['status'] == 'success' and memory['source_hashes']['candidate'] == actual
sequential = read('final-sequential-receipts.json')
assert len(sequential) == 5 and all(v['exit_code'] == 0 for v in sequential)
native = read('integration-proof/native-ci.json'); wasm = read('integration-proof/full-wasm-result.json')
assert native['passed'] and native['problems'] == 78 and native['tests_executed'] == 10218
assert native['repeats'] == 3 and native['duration_s'] <= 600 and not native['issues']
assert len(native['mutation']) == 78 and sum(map(len, native['mutation'].values())) == 342
assert all(hits for rows in native['mutation'].values() for hits in rows.values())
assert wasm['passed'] and wasm['catalog_modules'] == wasm['modules'] == 78 and not wasm['browser_budget_exceeded']
assert sum(v['mutants'] for v in wasm['results']) == 342
assert all(v['passed'] and not v['browser_budget_exceeded'] for v in wasm['results'])
contracts = next(v for v in wasm['results'] if v['id'] == 'architecture/attention')['independent_contracts']
assert contracts['passed'] == 2154 and len(contracts['suites']) == 38
assert {v['suite']: v['source_sha256'] for v in contracts['suites']} == tests
profiles = contracts['runtime_profiles']
assert len(profiles) == 2 and profiles[0]['supplemented_files'] == []
assert profiles[1]['supplemented_files'] == [dict(name='stridetorch/_legacy.py', source_sha256=actual['_legacy.py'])]
setup = read('integration-proof/setup-receipts.json'); front = read('integration-proof/frontend-receipts.json')
assert len(setup) == 4 and len(front) == 5 and all(v['exit_code'] == 0 for v in setup+front)
exports = read('integration-proof/export-identity.json'); snapshot = read('integration-proof/release-snapshot.json')
private = read('integration-proof/distribution-identity.json')
assert exports['published_assets_unchanged'] == 9123 and exports['active_assets'] == exports['new_assets'] == 158
assert exports['all_new_assets_reachable'] and snapshot['source_hashes'] == actual and private['status'] == 'success'
assert next(v for v in exports['runtimes'].values() if v['backend'] == 'numpy-wasm')['package_files'] == 6
live = read('integration-proof/live-expected-sha256.json'); assert len(live) == 161
for name, digest in live.items(): assert sha(repo/'web/public/data'/name) == digest
harness = read('integration-proof/wasm-harness-identity.json')
assert sha(repo/harness['file']) == harness['sha256'] and sha(repo/harness['driver_file']) == harness['driver_sha256']
assert read('canonical-policy-identity.json')['status'] == 'success'

for folder, paths in [('native-contracts', (repo/'tests').glob('test_torch_*')),
                      ('package-metadata', [repo/'packages/stridetorch'/n for n in ('README.md','pyproject.toml','LICENSE','NOTICE')])]:
    dest = r/folder; dest.mkdir(exist_ok=True)
    for path in paths:
        if path.is_file(): shutil.copy2(path, dest/path.name)
shutil.copy2(repo/'tests/test_browser_judge.py', r/'native-contracts/test_browser_judge.py')
shutil.copy2(repo/'packages/stridetorch/tests/test_standalone.py', r/'package-metadata/test_standalone.py')

def archive(name, root, excluded):
    files = []
    for folder, dirs, names in os.walk(root):
        dirs[:] = [d for d in dirs if not d.endswith(('-env','-venv')) and d not in excluded and d not in ('__pycache__','.pytest_cache')]
        for filename in names:
            path = Path(folder)/filename
            if not path.is_symlink() and (path.name in ('LICENSE','NOTICE') or path.suffix in ('.py','.mjs','.cjs','.json','.log','.txt','.md','.html','.toml','.diff')):
                files.append(path)
    target = out/name
    with tarfile.open(target, 'w:gz') as tar:
        for path in sorted(files): tar.add(path, arcname=str(path.relative_to(root)), recursive=False)
    return dict(file=target.name, files=len(files), bytes=target.stat().st_size, sha256=sha(target))

core_archive = archive('iteration-39-harness.tar.gz', r, {'dist-preflight','private-dist','dist-paperleet','integration-proof','main-sync-proof'})
core = dict(status='complete_local_core_and_application_gates_passed_main_adoption_pending', version='0.39.0',
    baseline_main='8fbf6524fbf60ed1bc84e2e6fed0f1178b40d3b6', source_hashes=actual, standalone_test_hashes=tests,
    full_cpu=full, focused_passed=1938, minimal_passed=2167, minimal_wheel=wheel, node_wasm=node,
    actual_chrome_worker=chrome, coinstall=coinstall, gate_receipts=gates, existing_source_audit=audit,
    final_random_oracles=fuzz, final_existing_workflows=regression, final_average_workflows=average,
    cold_namespace_imports=imports, diagnostic_existing_flow_followup=followup, adjoint_memory=memory, archive=core_archive,
    scope='AvgPool2d/AdaptiveAvgPool2d; local IEEE behavior and native division order; ordered inverse-region adjoints; float32/64 VJP/JVP and reverse-over-forward,half/long inference boundaries,Module/alias/pickle/version ownership. NumPy CPU/Pyodide WASM only.',
    retained_findings=['Original weighted adaptive/area implementation had six IEEE-class mismatches. First replacement matrix adjoint failed a strict near-zero gradient comparison; tolerances were preserved and the adjoint was replaced with ordered gathering.',
      'Finite forward reassociation now rejects mixed-sign planes. Packing,tiling,streaming,partition and ordered scatter fallbacks retain numerical behavior.',
      'Some existing small adaptive/area workflows regress. Final reports retain all raw timings; new fixed-pooling speedups compare against same-source scan,not unsupported APIs in0.38.',
      'The first freeze passed34719 full checks but predates the adjoint fix; its artifacts are retained separately and are not final evidence. Source-changing/overlapping exploratory pilots are excluded from final performance claims.'],
    release_policy='No GitHub CI,tag,dispatch,package upload or online publication; user will explicitly release later.')
save('iteration-39.json', core)
app_archive = archive('iteration-39-integration-harness.tar.gz', r/'integration-proof', {'dist-paperleet'})
save('iteration-39-integration.json', dict(status='complete_local_application_gates_passed_main_adoption_pending', version='0.39.0',
    upstream=read('integration-proof/context.json')['upstream'], source_hashes=actual, core_report='iteration-39.json',
    native=native, exported_wasm=wasm, setup_receipts=setup, frontend_receipts=front, release_snapshot=snapshot,
    export_integrity=exports, distribution_identity=private, runtime_sizes=read('integration-proof/runtime-sizes.json'),
    wasm_harness=harness, archive=app_archive, publication='Local verification; no remote CI or online deployment claim.'))
print(json.dumps(dict(core=core_archive, integration=app_archive, native_s=native['duration_s'], wasm_ms=wasm['elapsed_ms'])))
