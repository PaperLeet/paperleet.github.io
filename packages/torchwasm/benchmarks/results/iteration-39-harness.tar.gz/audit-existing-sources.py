from pathlib import Path
import ast,hashlib,json
r=Path(__file__).resolve().parent;old=r/'baseline/stridetorch';new=r/'proof/source'
def hashes(folder):return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
a,b=hashes(old),hashes(new);changed=[n for n in a if a[n]!=b[n]]
assert len(a)==48 and len(b)==49 and set(b)-set(a)=={'_average_pooling.py'}
assert set(changed)=={'__init__.py','_api.py','_nn.py'}
def registry(tree):
 result={}
 for node in ast.walk(tree):
  if not isinstance(node,ast.Call) or not isinstance(node.func,ast.Attribute) or not isinstance(node.func.value,ast.Name) or node.func.value.id!='registry':continue
  if node.func.attr not in ('add','group'):continue
  root=ast.literal_eval(node.args[0]) if isinstance(node.args[0],ast.Constant) else ast.dump(node.args[0],include_attributes=False);opts={v.arg:ast.literal_eval(v.value) for v in node.keywords}
  rows=[(root,node.args[1])] if node.func.attr=='add' else [(root+'.'+ast.literal_eval(k),v) for k,v in zip(node.args[1].keys,node.args[1].values)]
  for name,fn in rows:result[name]=(ast.dump(fn,include_attributes=False),opts)
 return result
before=registry(ast.parse((old/'_api.py').read_text()));after=registry(ast.parse((new/'_api.py').read_text()))
assert set(after)-set(before)=={'torch.nn.functional.avg_pool2d'}
modified={name for name in before if before[name]!=after[name]}
assert modified=={'torch.nn.functional.adaptive_avg_pool2d','torch.nn.functional.interpolate'}
for name in modified:
 assert before[name][0]==after[name][0]
 assert {**before[name][1],'forward':True}==after[name][1]
class Normalize(ast.NodeTransformer):
 def visit_ImportFrom(self,node):node.names=[v for v in node.names if v.name!='_average_pooling'];return node
 def visit_Tuple(self,node):
  node=self.generic_visit(node);node.elts=[v for v in node.elts if not (isinstance(v,ast.Tuple) and v.elts and isinstance(v.elts[0],ast.Name) and v.elts[0].id=='_average_pooling')];return node
 def visit_Dict(self,node):
  node=self.generic_visit(node)
  for k,v in zip(node.keys,node.values):
   if isinstance(k,ast.Constant) and k.value=='pooling':v.elts=[e for e in v.elts if not (isinstance(e,ast.Constant) and e.value in ('AvgPool2d','AdaptiveAvgPool2d'))]
  return node
 def visit_Expr(self,node):
  v=node.value
  if isinstance(v,ast.Call) and isinstance(v.func,ast.Attribute) and isinstance(v.func.value,ast.Name) and v.func.value.id=='registry' and v.func.attr in ('add','group'):return None
  return self.generic_visit(node)
 def visit_FunctionDef(self,node):
  if node.name in ('adaptive_avg_pool2d','interpolate'):return None
  return self.generic_visit(node)
for name in ('_api.py','_nn.py'):
 left=ast.dump(Normalize().visit(ast.parse((old/name).read_text())),include_attributes=False);right=ast.dump(Normalize().visit(ast.parse((new/name).read_text())),include_attributes=False);assert left==right,name
report=dict(status='success',unchanged_resources=45,changed_existing=changed,new_resources=['_average_pooling.py'],registry_additions=sorted(set(after)-set(before)),registry_modified=sorted(modified),ast_scope='Other API setup and nn function AST identical after removing explicit average-pooling additions. Existing adaptive/area behavior intentionally replaced; no claim those old functions are unchanged.',source_hashes=b)
(r/'existing-source-audit.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified45 unchanged resources and preserved API/nn AST outside explicit average changes')
