import pathlib, stridetorch
from pathlib import Path
import hashlib, json
import numpy as np

p = Path(__file__).resolve().parent
native = json.loads((p / 'model-native-jacobian.json').read_text())
candidate = json.loads((p / 'model-candidate-jacobian.json').read_text())
assert native['cases'] == candidate['cases'] == 96
maximum = 0.
failures = []
def compare(a, b):
    global maximum
    if isinstance(a, list):
        assert isinstance(b, list) and len(a) == len(b)
        for left, right in zip(a, b): compare(left, right)
    else:
        for key in ['shape', 'dtype', 'requires_grad']: assert a[key] == b[key], key
        left = np.asarray(a['values']); right = np.asarray(b['values'])
        assert left.shape == right.shape
        if left.size: maximum = max(maximum, float(np.max(np.abs(left - right))))
        np.testing.assert_allclose(left, right, rtol=8e-5 if a['dtype'] == 'float32' else 2e-9,
                                   atol=1e-5 if a['dtype'] == 'float32' else 2e-10)
for a, b in zip(native['rows'], candidate['rows']):
    identity = {key: a[key] for key in ['case', 'dtype', 'strict', 'strided']}
    try:
        for key in ['case', 'dtype', 'strict', 'strided', 'status', 'calls', 'hooks', 'caller_preserved']:
            assert a[key] == b[key], (key, a[key], b[key])
        if a['status'] == 'success': compare(a['result'], b['result'])
        else: assert a['exception'] == b['exception'], (a['exception'], b['exception'])
        assert a['model_buffers'].keys() == b['model_buffers'].keys()
        for name in a['model_buffers']: compare(a['model_buffers'][name], b['model_buffers'][name])
    except Exception as error:
        failures.append(dict(**identity, error=str(error)))
source = {q.name: hashlib.sha256(q.read_bytes()).hexdigest() for q in pathlib.Path(stridetorch.__file__).parent.iterdir()
          if q.suffix == '.py' or q.name in ['LICENSE', 'NOTICE']}
assert source == json.loads((p / 'candidate-source-hashes.json').read_text())
report = dict(status='failed' if failures else 'passed', cases=96,
    native_success=sum(row['status'] == 'success' for row in native['rows']), failures=failures,
    max_abs_difference=maximum, native_torch=native['torch'], native_git=native['native_git'], source_hashes=source,
    input_hashes={name: hashlib.sha256((p / name).read_bytes()).hexdigest() for name in
        ['probe-model-jacobian.py', 'model-native-jacobian.json', 'run-model-candidate.py', 'model-candidate-jacobian.json']},
    scope='CPU-only isolated prototype:96native-model Jacobians,Tensor/tuple structures,float32/64,contiguous/strided input,per-output strictness,one callback,gradient flags/buffer identity/input data/strides/hooks and statefulBatchNorm buffers. No WASM/package/fullSDK/latency qualification or adoption.')
(p / 'model-qualification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key not in ['source_hashes', 'input_hashes']}))
assert not failures
