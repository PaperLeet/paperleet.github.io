import contextlib,io,json,pathlib,runpy
p=pathlib.Path('/runtime')
for runner,filename,comparator in [
    ('run-candidate.py','candidate-jacobian.json','compare-jacobian.py'),
    ('run-model-candidate.py','model-candidate-jacobian.json','compare-model-jacobian.py')]:
    output=io.StringIO()
    with contextlib.redirect_stdout(output):runpy.run_path(str(p/runner),run_name='__main__')
    (p/filename).write_text(output.getvalue())
    runpy.run_path(str(p/comparator),run_name='__main__')
boundary=json.loads((p/'qualification.json').read_text())
models=json.loads((p/'model-qualification.json').read_text())
assert boundary['status']==models['status']=='passed'
assert boundary['cases']==72 and models['cases']==96
model_qualification=dict(status='passed',cases=168,boundary=boundary,models=models)
(p/'model-candidate.json').write_text(json.dumps(dict(
    boundary=json.loads((p/'candidate-jacobian.json').read_text()),
    models=json.loads((p/'model-candidate-jacobian.json').read_text()))))
