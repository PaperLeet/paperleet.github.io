from pathlib import Path
import subprocess,json,time
r=Path(__file__).resolve().parent
receipts=[]
for label,driver in [('node','wasm-contracts.mjs'),('chrome','chrome-contracts/run.mjs')]:
 start=time.time()
 with (r/(label+'.log')).open('w') as log:
  p=subprocess.run(['/opt/homebrew/bin/node',str(r/driver)],cwd=r,stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(label=label,exit_code=p.returncode,seconds=time.time()-start))
 (r/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
 p.check_returncode();print(label,'PASS',flush=True)
expected=json.loads((r.parent.parent/'candidate-source-hashes.json').read_text())
for file in ['source-wasm.json','chrome-contracts/result.json']:
 result=json.loads((r/file).read_text());assert result['source_hashes']==expected and result['passed']==8180 and result['library']=='0.69.0'
 assert result['model_qualification']['status']=='passed' and result['model_qualification']['cases']==168
print('PROTOTYPE NODE/CHROME EXACT SOURCE SDK AND168NATIVE FIXTURES PASS',flush=True)
