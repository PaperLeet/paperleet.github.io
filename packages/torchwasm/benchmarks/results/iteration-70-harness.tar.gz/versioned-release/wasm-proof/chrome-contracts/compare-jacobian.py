from pathlib import Path
import hashlib, json
import numpy as np

p = Path(__file__).resolve().parent
native = json.loads((p / 'native-jacobian.json').read_text())
candidate = json.loads((p / 'candidate-jacobian.json').read_text())
assert native['cases'] == candidate['cases'] == 72
failures = []
maximum = 0.
def compare(a, b):
    global maximum
    if isinstance(a, list):
        assert isinstance(b, list) and len(a) == len(b)
        for left, right in zip(a, b): compare(left, right)
    else:
        for key in ['shape', 'dtype', 'requires_grad']: assert a[key] == b[key], key
        left = np.asarray(a['values']); right = np.asarray(b['values'])
        assert left.shape == right.shape
        if left.size: maximum = max(maximum, float(np.max(np.abs(left - right))))
        np.testing.assert_allclose(left, right, rtol=2e-5 if a['dtype'] == 'float32' else 1e-10,
                                   atol=2e-6 if a['dtype'] == 'float32' else 1e-11)
for a, b in zip(native['rows'], candidate['rows']):
    identity = {key: a[key] for key in ['case', 'dtype', 'strict']}
    try:
        for key in ['case', 'dtype', 'strict', 'status', 'calls', 'caller_preserved']:
            assert a[key] == b[key], (key, a[key], b[key])
        if a['status'] == 'success': compare(a['result'], b['result'])
        else: assert a['exception'] == b['exception'], (a['exception'], b['exception'])
    except Exception as error:
        failures.append(dict(**identity, error=str(error)))
result = dict(status='failed' if failures else 'passed', cases=72, native_success=44,
              failures=failures, max_abs_difference=maximum, native_torch=native['torch'],
              source_hashes=json.loads((p / 'candidate-source-hashes.json').read_text()),
              input_hashes={name: hashlib.sha256((p / name).read_bytes()).hexdigest() for name in
                  ['probe-jacobian.py', 'native-jacobian.json', 'run-candidate.py', 'candidate-jacobian.json']},
              scope='Actual Pyodide replay of72independent native boundary fixtures; the enclosing driver verifies the complete SDK. No package,performance or adoption claim.')
(p / 'qualification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key not in ['source_hashes', 'input_hashes']}))
assert not failures
