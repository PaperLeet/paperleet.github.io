from pathlib import Path
import contextlib,hashlib,io,json,runpy,sys
p=Path(__file__).resolve().parent
sys.path.insert(0,str(p.parent/'snapshot/packages/stridetorch/src'))
import stridetorch
source=Path(stridetorch.__file__).parent
expected=json.loads((p/'candidate-source-hashes.json').read_text())
actual={q.name:hashlib.sha256(q.read_bytes()).hexdigest() for q in source.iterdir() if q.suffix=='.py' or q.name in ['LICENSE','NOTICE']}
assert actual==expected and stridetorch.__version__=='0.70.0'
for driver,out,comparator in [('run-candidate.py','candidate-jacobian.json','compare-jacobian.py'),('run-model-candidate.py','model-candidate-jacobian.json','compare-model-jacobian.py')]:
 output=io.StringIO()
 with contextlib.redirect_stdout(output):runpy.run_path(str(p/driver),run_name='__main__')
 (p/out).write_text(output.getvalue())
 runpy.run_path(str(p/comparator),run_name='__main__')
print('FINAL0.70 CPU168NATIVE FIXTURES PASS')
