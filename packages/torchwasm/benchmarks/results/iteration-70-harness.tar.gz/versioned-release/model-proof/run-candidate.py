from pathlib import Path
import sys

p = Path(__file__).resolve().parent
sys.path.insert(0, str(p.parent / 'snapshot/packages/stridetorch/src'))
import stridetorch
stridetorch.install_as_torch()
source = (p / 'probe-jacobian.py').read_text()
# Only the emitted library metadata differs. Callback and numerical probe code
# are identical to the archived native program.
source = source.replace('torch.__version__', 'stridetorch.__version__').replace('torch.version.git_version', 'None')
exec(compile(source, str(p / 'probe-jacobian.py'), 'exec'), {'stridetorch': stridetorch})
