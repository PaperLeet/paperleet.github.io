from pathlib import Path
import hashlib, json, shutil

p = Path(__file__).resolve().parent
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
original = repo / 'packages/stridetorch/src/stridetorch'
target = p / 'candidate-source/stridetorch'
assert not target.exists()
sha = lambda q: hashlib.sha256(q.read_bytes()).hexdigest()
manifest = lambda q: {f.name: sha(f) for f in q.iterdir() if f.suffix == '.py' or f.name in ['LICENSE', 'NOTICE']}
baseline = json.loads((p.parent / 'torch-iteration-69/final-integration/source-hashes.json').read_text())
assert manifest(original) == baseline
shutil.copytree(original, target, ignore=shutil.ignore_patterns('__pycache__'))
code = (target / '_autograd.py').read_text()
assert code.count('\ndef gradcheck(') == 1
code = code.replace('\ndef gradcheck(', '\n' + (p / 'functional-jacobian.py').read_text() + '\n\ndef gradcheck(')
(target / '_autograd.py').write_text(code)
code = (target / '_api.py').read_text()
needle = "    registry.add('torch.autograd.functional.vjp', _autograd.functional_vjp, reverse='control')"
assert code.count(needle) == 1
code = code.replace(needle, needle + "\n    registry.add('torch.autograd.functional.jacobian', _autograd.functional_jacobian, reverse='control')")
(target / '_api.py').write_text(code)
assert {name for name, digest in manifest(target).items() if baseline[name] != digest} == {'_api.py', '_autograd.py'}
(p / 'candidate-source-hashes.json').write_text(json.dumps(manifest(target), indent=2) + '\n')
print('Created isolated first-order Jacobian prototype; version literal remains0.69 as provenance, no application edits')
