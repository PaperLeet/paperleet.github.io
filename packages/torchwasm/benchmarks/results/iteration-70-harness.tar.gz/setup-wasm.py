from pathlib import Path
import hashlib, json, shutil

r = Path(__file__).resolve().parent
old = r.parent / 'torch-iteration-69/versioned-release/wasm-proof'
out = r / 'prototype-proof/wasm-proof'
chrome = out / 'chrome-contracts'
assert not out.exists()
chrome.mkdir(parents=True)
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
source = r / 'candidate-source/stridetorch'
expected = json.loads((r / 'candidate-source-hashes.json').read_text())
assert expected == {f.name: sha(f) for f in source.iterdir() if f.suffix == '.py' or f.name in ['LICENSE', 'NOTICE']}
shutil.copytree(source, chrome / 'source', ignore=shutil.ignore_patterns('__pycache__'))
(chrome / 'tests').mkdir()
for f in Path('/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/tests').glob('test_*.py'):
    if f.name != 'test_standalone.py': shutil.copy2(f, chrome / 'tests' / f.name)
shutil.copy2(r / 'test_functional_jacobian.py', chrome / 'tests/test_functional_jacobian.py')
assert len(list((chrome / 'tests').glob('*.py'))) == 67
for name in ['probe-jacobian.py', 'native-jacobian.json', 'run-candidate.py', 'compare-jacobian.py',
             'probe-model-jacobian.py', 'model-native-jacobian.json', 'run-model-candidate.py', 'compare-model-jacobian.py']:
    shutil.copy2(r / name, chrome / name)
shutil.copy2(r / 'candidate-source-hashes.json', chrome / 'candidate-source-hashes.json')
f = chrome / 'compare-model-jacobian.py'
s = f.read_text()
needle = "(p / 'candidate-source/stridetorch').iterdir()"
assert needle in s
s = 'import pathlib, stridetorch\n' + s.replace(needle, 'pathlib.Path(stridetorch.__file__).parent.iterdir()')
f.write_text(s)
(chrome / 'model-run.py').write_text('''import contextlib,io,json,pathlib,runpy
p=pathlib.Path('/runtime')
for runner,filename,comparator in [
    ('run-candidate.py','candidate-jacobian.json','compare-jacobian.py'),
    ('run-model-candidate.py','model-candidate-jacobian.json','compare-model-jacobian.py')]:
    output=io.StringIO()
    with contextlib.redirect_stdout(output):runpy.run_path(str(p/runner),run_name='__main__')
    (p/filename).write_text(output.getvalue())
    runpy.run_path(str(p/comparator),run_name='__main__')
boundary=json.loads((p/'qualification.json').read_text())
models=json.loads((p/'model-qualification.json').read_text())
assert boundary['status']==models['status']=='passed'
assert boundary['cases']==72 and models['cases']==96
model_qualification=dict(status='passed',cases=168,boundary=boundary,models=models)
(p/'model-candidate.json').write_text(json.dumps(dict(
    boundary=json.loads((p/'candidate-jacobian.json').read_text()),
    models=json.loads((p/'model-candidate-jacobian.json').read_text()))))
''')
model_names = ['probe-jacobian.py', 'native-jacobian.json', 'run-candidate.py', 'compare-jacobian.py',
    'probe-model-jacobian.py', 'model-native-jacobian.json', 'run-model-candidate.py',
    'compare-model-jacobian.py', 'candidate-source-hashes.json', 'model-run.py']
plan = dict(source=expected, tests={f.name: sha(f) for f in sorted((chrome / 'tests').glob('*.py'))},
    version='0.69.0', prototype=True, expected=8180, model_files={name: sha(chrome / name) for name in model_names})
(chrome / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
for name in ['index.html', 'worker.mjs', 'run.mjs']:
    s = (old / 'chrome-contracts' / name).read_text()
    s = s.replace('/torch-iteration-69/versioned-release/', '/torch-iteration-70/prototype-proof/')
    (chrome / name).write_text(s)
shutil.copy2(r.parent / 'torch-iteration-69/fixture-server.mjs', r / 'fixture-server.mjs')
s = (old / 'wasm-contracts.mjs').read_text()
s = s.replace('/torch-iteration-69/versioned-release/snapshot/packages/stridetorch/src/stridetorch',
              '/torch-iteration-70/candidate-source/stridetorch')
s = s.replace('/torch-iteration-69/versioned-release/wasm-proof/', '/torch-iteration-70/prototype-proof/wasm-proof/')
s = s.replace('==8165', '==8180')
(out / 'wasm-contracts.mjs').write_text(s)
s = (old / 'run.py').read_text()
s = s.replace("r.parent/'package-proof/source-hashes.json'", "r.parent.parent/'candidate-source-hashes.json'")
s = s.replace('==8165', '==8180').replace('==368', '==168')
s = s.replace('VERSIONED NODE/CHROME EXACT SOURCE SDK PASS', 'PROTOTYPE NODE/CHROME EXACT SOURCE SDK AND168NATIVE FIXTURES PASS')
(out / 'run.py').write_text(s)
print('Frozen67WASM suites,61source/license identities,168nativeJacobian fixtures; prototype version literal0.69 retained')
