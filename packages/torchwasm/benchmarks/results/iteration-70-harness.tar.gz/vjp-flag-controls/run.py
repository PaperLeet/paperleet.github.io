from pathlib import Path
import json, os, statistics, subprocess

p=Path(__file__).resolve().parent
python=p.parent.parent/'torch-iteration-69/integration-dev-env/bin/python'
assert '94 passed' in (p/'correctness.log').read_text()
env=dict(os.environ,PYTHONHASHSEED='0',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
receipts=[]
for cycle in range(6):
    with (p/f'cpu-{cycle}.json').open('w') as output,(p/f'cpu-{cycle}.log').open('w') as log:
        child=subprocess.run([str(python),str(p/'probe.py'),str(cycle)],env=env,stdout=output,stderr=log)
    receipts.append(dict(cycle=cycle,exit_code=child.returncode))
    (p/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
    child.check_returncode();print('cpu',cycle,'PASS',flush=True)
raw=[json.loads((p/f'cpu-{cycle}.json').read_text()) for cycle in range(6)]
rows=[]
for i in range(2):
    values=[j['rows'][i] for j in raw]
    rows.append(dict(case=values[0]['case'],ratios={key:[v[key] for v in values] for key in ['duplicate_over_baseline','candidate_over_baseline','candidate_over_duplicate']},
        medians={key:statistics.median(v[key] for v in values) for key in ['duplicate_over_baseline','candidate_over_baseline','candidate_over_duplicate']}))
report=dict(status='completed',fresh_children=6,source_hashes=raw[0]['source_hashes'],rows=rows,
    scope='CPU-only causal counterexample:final0.70generic flag versus same code with only3private flag-name replacements. Six load permutations,12balanced>=50ms batches,same-source duplicate,seed0. Both publicVJP APIs and identical numerical/caller-state checks. Not a released0.69 comparison or a source-selection decision.')
(p/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['rows']))
