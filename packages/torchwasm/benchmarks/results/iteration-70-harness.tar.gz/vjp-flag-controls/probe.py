from pathlib import Path
import gc, hashlib, itertools, json, os, statistics, sys, time
import numpy as np

p = Path(__file__).resolve().parent
sys.path.insert(0, str(p.parent / 'performance/assets'))
from bench_vjp import load, build

cycle = int(sys.argv[1])
labels = ['baseline', 'duplicate', 'candidate']
orders = list(itertools.permutations(labels))
order = orders[cycle]
paths = dict(baseline=p.parent/'performance/assets/candidate/stridetorch',
             duplicate=p.parent/'performance/assets/candidate/stridetorch', candidate=p/'legacy-flag/stridetorch')
modules = {}
hashes = {}
for label in order:
    modules[label], hashes[label] = load('_f_' + dict(baseline='a', duplicate='d', candidate='b')[label], paths[label])
expected = json.loads((p/'source-hashes.json').read_text())
assert hashes['baseline'] == hashes['duplicate'] == expected['generic']
assert hashes['candidate'] == expected['legacy_flag']
rows = []
for case in ['vjp_scalar', 'vjp_linear']:
    functions = {}
    captures = {}
    for label in order: functions[label], captures[label], dtype = build(modules[label], case, True)
    reference = captures['baseline']()
    for label in ['duplicate', 'candidate']:
        actual = captures[label]()
        for a,b in zip(reference,actual): np.testing.assert_allclose(a,b,rtol=3e-5 if dtype=='float32' else 3e-11,atol=3e-6 if dtype=='float32' else 3e-11)
    del reference, actual
    gc.collect()
    calls=1
    for label in order:
        batch=1
        while True:
            start=time.perf_counter()
            for _ in range(batch): functions[label]()
            if time.perf_counter()-start>=.05:break
            batch*=2
        calls=max(calls,batch)
    samples={label:[] for label in labels}
    for permutation in orders+list(reversed(orders)):
        for label in permutation:
            fn=functions[label];start=time.perf_counter()
            for _ in range(calls):fn()
            samples[label].append((time.perf_counter()-start)/calls)
    medians={label:statistics.median(values) for label,values in samples.items()}
    rows.append(dict(case=case,samples_s=samples,calls=calls,median_s=medians,
        duplicate_over_baseline=medians['duplicate']/medians['baseline'],
        candidate_over_baseline=medians['candidate']/medians['baseline'],
        candidate_over_duplicate=medians['candidate']/medians['duplicate']))
print(json.dumps(dict(cycle=cycle,load_order=list(order),source_hashes=hashes,rows=rows,
    cpu_hash_seed=os.environ.get('PYTHONHASHSEED'),python=sys.version,numpy=np.__version__,
    program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),indent=2))
