"""Native boundary inventory for the next functional-AD API; no repository edits."""
import json, sys
import numpy as np
import torch

def record(value):
    if isinstance(value, tuple):
        return [record(item) for item in value]
    return dict(shape=list(value.shape), dtype=str(value.dtype).split('.')[-1],
                requires_grad=value.requires_grad, values=value.detach().numpy().tolist())

rows = []
cases = ['scalar', 'vector', 'matrix', 'multiple_inputs', 'multiple_outputs',
         'mixed_constant_output', 'unused_input', 'repeated_input', 'captured_original',
         'connected_zero', 'empty_input_tensor', 'empty_output_tensor', 'empty_inputs',
         'empty_outputs', 'list_output', 'numpy_escape', 'detached_numpy', 'force_numpy']
for dtype in [torch.float32, torch.float64]:
    for strict in [False, True]:
        for case in cases:
            x = torch.tensor([[.2, .5, .8], [1.1, 1.4, 1.7]], dtype=dtype).T
            x.requires_grad_(True)
            x.grad = torch.full_like(x, 3.)
            before = x.detach().clone()
            grad_before = x.grad.clone()
            y = torch.tensor([.1, .3], dtype=dtype)
            calls = []
            inputs = x
            if case == 'scalar': fn = lambda a: a.square().sum()
            elif case == 'vector': fn = lambda a: a.sin().sum(0)
            elif case == 'matrix': fn = lambda a: a @ a.T
            elif case == 'multiple_inputs':
                inputs = (x, y); fn = lambda a, b: (a * b).tanh()
            elif case == 'multiple_outputs': fn = lambda a: (a.square(), a.mean())
            elif case == 'mixed_constant_output': fn = lambda a: (a.sin(), torch.tensor([2.], dtype=dtype))
            elif case == 'unused_input':
                inputs = (x, y); fn = lambda a, b: a.sin()
            elif case == 'repeated_input':
                inputs = (x, x); fn = lambda a, b: a.square() + b.sin()
            elif case == 'captured_original': fn = lambda a: a.sin() + x.square()
            elif case == 'connected_zero': fn = lambda a: a * 0
            elif case == 'empty_input_tensor':
                inputs = torch.empty((0, 2), dtype=dtype); fn = lambda a: a.sum()
            elif case == 'empty_output_tensor': fn = lambda a: a[:0]
            elif case == 'empty_inputs':
                inputs = (); fn = lambda: torch.tensor(2., dtype=dtype)
            elif case == 'empty_outputs': fn = lambda a: ()
            elif case == 'list_output': fn = lambda a: [a.sin()]
            elif case == 'numpy_escape': fn = lambda a: torch.from_numpy(a.numpy())
            elif case == 'detached_numpy': fn = lambda a: torch.from_numpy(a.detach().numpy())
            else: fn = lambda a: torch.from_numpy(a.numpy(force=True))
            def callback(*args):
                calls.append(1)
                return fn(*args)
            row = dict(case=case, dtype=str(dtype).split('.')[-1], strict=strict)
            try:
                with torch.no_grad():
                    value = torch.autograd.functional.jacobian(callback, inputs, strict=strict)
                row.update(status='success', result=record(value))
            except Exception as error:
                row.update(status='error', exception=type(error).__name__, message=str(error))
            row.update(calls=len(calls), caller_preserved=bool(x.requires_grad and
                torch.equal(x.detach(), before) and torch.equal(x.grad, grad_before)))
            assert row['caller_preserved']
            rows.append(row)
print(json.dumps(dict(torch=torch.__version__, native_git=torch.version.git_version,
                      cases=len(rows), rows=rows), allow_nan=False, indent=2))
