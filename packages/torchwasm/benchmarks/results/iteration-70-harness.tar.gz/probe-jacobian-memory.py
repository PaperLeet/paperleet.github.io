"""Tracked CPU allocations, not RSS, latency or browser/GPU heap measurements."""
from pathlib import Path
import gc, hashlib, importlib.util, itertools, json, statistics, sys, tracemalloc
import numpy as np

p = Path(__file__).resolve().parent
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path / '__init__.py', submodule_search_locations=[str(path)])
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    hashes = {q.name: hashlib.sha256(q.read_bytes()).hexdigest() for q in path.iterdir()
              if q.suffix == '.py' or q.name in ['LICENSE', 'NOTICE']}
    return module, hashes

paths = dict(baseline=p / 'before-preallocation/stridetorch',
             duplicate=p / 'before-preallocation/stridetorch', candidate=p / 'candidate-source/stridetorch')
modules = {}
hashes = {}
for label, path in paths.items():
    modules[label], hashes[label] = load('_jac_memory_' + label, path)
assert hashes['baseline'] == hashes['duplicate']
assert hashes['candidate'] == json.loads((p / 'candidate-source-hashes.json').read_text())
rows = []
for size in [8, 16, 24]:
    data = np.arange(size * size, dtype=np.float64).reshape(size, size) / 100
    expected = np.diag(np.cos(data).reshape(-1)).reshape(data.shape + data.shape)
    inputs = {label: module.torch.tensor(data.copy()) for label, module in modules.items()}
    functions = {label: (lambda t=module.torch, x=inputs[label]:
        t.autograd.functional.jacobian(lambda a: a.sin(), x)) for label, module in modules.items()}
    for label, function in functions.items():
        np.testing.assert_allclose(function().numpy(), expected, rtol=1e-12, atol=1e-12)
    samples = {label: [] for label in paths}
    for order in itertools.permutations(paths):
        for label in order:
            gc.collect()
            tracemalloc.start()
            result = functions[label]()
            retained, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            assert not result.requires_grad and not inputs[label].requires_grad and inputs[label].grad is None
            np.testing.assert_allclose(result.numpy(), expected, rtol=1e-12, atol=1e-12)
            samples[label].append(dict(retained_bytes=retained, peak_bytes=peak))
            del result
    medians = {label: {key: statistics.median(value[key] for value in values)
                       for key in ['retained_bytes', 'peak_bytes']} for label, values in samples.items()}
    rows.append(dict(shape=list(data.shape), dtype='float64', jacobian_bytes=expected.nbytes,
        samples=samples, medians=medians,
        candidate_over_baseline_peak=medians['candidate']['peak_bytes'] / medians['baseline']['peak_bytes'],
        duplicate_over_baseline_peak=medians['duplicate']['peak_bytes'] / medians['baseline']['peak_bytes']))
report = dict(status='passed', python=sys.version, numpy=np.__version__, source_hashes=hashes,
    program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), rows=rows,
    scope='Single-process CPU tracemalloc,three dense sin-Jacobian sizes,float64,sixbalanced source orders and same-source duplicate. Analytic diagonal values and caller-state checks on every result. Allocation-only comparison of two isolated prototypes; no latency,RSS,WASM/GPU-heap or universal memory claim.')
(p / 'jacobian-memory.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(status='passed', rows=[{k: v for k, v in row.items() if k not in ['samples', 'medians']} for row in rows])))
