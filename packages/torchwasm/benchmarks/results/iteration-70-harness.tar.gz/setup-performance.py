from pathlib import Path
import hashlib, json, shutil

r = Path(__file__).resolve().parent
p = r / 'performance'
assets = p / 'assets'
old = r.parent / 'torch-iteration-69/performance-selected'
sha = lambda q: hashlib.sha256(q.read_bytes()).hexdigest()
manifest = lambda q: {f.name: sha(f) for f in q.iterdir() if f.suffix == '.py' or f.name in ['LICENSE', 'NOTICE']}
frozen = json.loads((assets / 'source-freeze.json').read_text())
for label in ['baseline', 'candidate']:
    assert manifest(assets / label / 'stridetorch') == frozen['source_hashes'][label]
assert not (assets / 'naive').exists()
shutil.copytree(r / 'before-preallocation/stridetorch', assets / 'naive/stridetorch', ignore=shutil.ignore_patterns('__pycache__'))
program = (old / 'assets/bench_vjp.py').read_text().split('\ndef run(')[0]
start = program.index('  if candidate:fn=lambda:t.autograd.functional.vjp')
end = program.index('  def capture():', start)
program = program[:start] + '  fn=lambda:t.autograd.functional.vjp(function,values,seed)\n' + program[end:]
program = program.replace('Matched legacy/control flows, serialization, exports and first-order VJP reference.',
                          'Matched public0.69/0.70 APIs and a separately labeled naive Jacobian prototype.')
program += '\n' + (p / 'jacobian-benchmark-fragment.py').read_text()
(assets / 'bench_vjp.py').write_text(program)
hashes = {label: manifest(assets / label / 'stridetorch') for label in ['baseline', 'candidate', 'naive']}
hashes['duplicate'] = hashes['baseline']
plan = dict(source_hashes=hashes, programs={'bench_vjp.py': sha(assets / 'bench_vjp.py')},
    existing_api_baseline_version='0.69.0', candidate_version='0.70.0',
    jacobian_baseline='Qualified naive prototype with row-list/stack assembly, not a released API',
    flows=12, legacy_flows=9, jacobian_flows=3)
(assets / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
for source, dest in [(old / 'bench-node.mjs', p / 'bench-node.mjs'),
                     (old / 'bench-chrome.mjs', p / 'bench-chrome.mjs'),
                     (old / 'assets/worker.mjs', assets / 'worker.mjs')]:
    code = source.read_text().replace("['baseline','candidate']", "['baseline','candidate','naive']")
    code = code.replace("'/candidate/stridetorch',cycle", "'/candidate/stridetorch','/naive/stridetorch',cycle")
    code = code.replace('/torch-iteration-69/performance-selected/', '/torch-iteration-70/performance/')
    code = code.replace('rows.length,9', 'rows.length,12')
    dest.write_text(code)
shutil.copy2(old / 'assets/index.html', assets / 'index.html')
code = (old / 'run.py').read_text()
code = code.replace("python=r.parent/'torch-iteration-21/stride-dev-env/bin/python'",
                    "python=r.parent/'torch-iteration-69/integration-dev-env/bin/python'")
code = code.replace("str(assets/'candidate/stridetorch'),str(cycle)",
                    "str(assets/'candidate/stridetorch'),str(assets/'naive/stridetorch'),str(cycle)")
code = code.replace("==9", "==12").replace('range(9)', 'range(12)').replace('flows_per_child=9', 'flows_per_child=12')
code = code.replace("dict(runtime=runtime,case=", "dict(runtime=runtime,family=samples[0]['family'],case=")
code = code.replace('ExistingAPI and unchecked manual-reference newVJP comparisons are labeled separately.',
                    'Nine existing public0.69API flows (publicVJP on both sides) and three separately labeled naiveprototype Jacobian comparisons.')
code = code.replace('ALL18 FRESH9-FLOW', 'ALL18 FRESH12-FLOW')
(p / 'run.py').write_text(code)
print('Prepared18fresh CPU/Node/Chrome processes,9legacy publicAPI and3Jacobian prototype comparison flows')
