"""Commit the verified main receipt after the guarded adoption push."""
from pathlib import Path
import json, subprocess

p=Path(__file__).resolve().parent
repo=Path('/Users/david/Developer/PaperLeet-torch-release')
def git(*args): return subprocess.check_output(['git',*args],cwd=repo)
own=json.loads((p/'own-commits.json').read_text())
proof=json.loads((p/'adoption-verification.json').read_text())
assert proof['status']=='adopted_on_main' and proof['adopted_main_commit']==own['adoption_candidate_commit']
assert git('rev-parse','HEAD').decode().strip()==own['adoption_candidate_commit']
expected={'packages/stridetorch/benchmarks/results/iteration-70-main-adoption.json',
    'docs/validation/torch-runtime-iteration-70.md'}
rows=[row.decode() for row in git('status','--porcelain','-z','--untracked-files=all').split(b'\0') if row]
assert {row[3:] for row in rows}==expected and all(row[:2] in [' M','??'] for row in rows)
subprocess.run(['git','diff','--check'],cwd=repo,check=True)
subprocess.run(['git','add','--',*sorted(expected)],cwd=repo,check=True)
assert set(git('diff','--cached','--name-only','-z').decode().split('\0'))-{''}==expected
subprocess.run(['git','commit','-m','docs(torch): record verified 0.70 main adoption'],cwd=repo,check=True,stdout=subprocess.DEVNULL)
own['proof_commit']=git('rev-parse','HEAD').decode().strip()
assert not git('status','--porcelain','-z')
(p/'own-commits.json').write_text(json.dumps(own,indent=2)+'\n')
print(json.dumps(dict(proof_commit=own['proof_commit'],paths=len(expected))),flush=True)
