"""Publish evidence only after the complete current-application gates pass."""
from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, tarfile

p = Path(__file__).resolve().parent
r = p.parent
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
out = repo / 'packages/stridetorch/benchmarks/results'
read = lambda q: json.loads(q.read_text())
sha = lambda q: hashlib.sha256(q.read_bytes()).hexdigest()
def save(q, value): q.write_text(json.dumps(value, indent=2) + '\n')

source = read(p / 'source-hashes.json')
tests = read(p / 'test-hashes.json')
assert len(source) == 61 and len(tests) == 69
for name, digest in source.items(): assert sha(repo / 'packages/stridetorch/src/stridetorch' / name) == digest
for name, digest in tests.items(): assert sha(repo / 'packages/stridetorch/tests' / name) == digest
for manifest, prefix in [('application-input-sha256.json', repo), ('frontend-input-sha256.json', repo),
    ('owned-input-sha256.json', repo), ('baseline-immutable-sha256.json', repo),
    ('new-assets-sha256.json', repo), ('live-export-sha256.json', repo / 'web/public/data')]:
    for name, digest in read(p / manifest).items(): assert sha(prefix / name) == digest, (manifest, name)
local = read(p / 'local-validation.json')
assert local['status'] == 'passed' and local['source_hashes'] == source
assert len(local['receipts']) == 11 and all(v['exit_code'] == 0 for v in local['receipts'])
for receipt in local['receipts']: assert sha(p / (receipt['label'] + '.log')) == receipt['log_sha256']
cpu = read(p / 'cpu-receipt.json')
assert cpu['exit_code'] == 0 and cpu['source_hashes'] == source
cpu_cases = int(re.search(r'(\d+) passed', cpu['summary'][0]).group(1))
assert cpu_cases > 41804
wasm = read(p / 'full-wasm-result.json')
count = read(p / 'context.json')['catalog_modules']
assert wasm['passed'] and wasm['catalog_modules'] == wasm['modules'] == count
assert len(wasm['results']) == count and not wasm['browser_budget_exceeded']
assert all(v['passed'] and not v['browser_budget_exceeded'] for v in wasm['results'])
contracts = next(v for v in wasm['results'] if v['id'] == 'architecture/attention')['independent_contracts']
assert contracts['passed'] == 8200 and len(contracts['suites']) == 68
assert {v['suite']: v['source_sha256'] for v in contracts['suites']} == {n:h for n,h in tests.items() if n != 'test_standalone.py'}
package_root = Path(read(p / 'package-proof-path.json')['path']) if (p / 'package-proof-path.json').exists() else r / 'versioned-release/package-proof'
package = read(package_root / 'package-identity.json')
assert package['status'] == 'success' and package['source_hashes'] == source
assert package['standalone_installed_tests'] == 8213 and package['native_torch'] is False
for name, digest in package['application_source_hashes'].items(): assert sha(repo / name) == digest
for name, digest in package['artifacts'].items(): assert sha(package_root / name) == digest
runtime_proofs = {}
for label, name in [('node', 'source-wasm.json'), ('chrome', 'chrome-contracts/result.json')]:
    proof = read(r / 'versioned-release/wasm-proof' / name)
    assert proof['source_hashes'] == source and proof['library'] == '0.70.0' and proof['passed'] == 8200
    assert proof['model_qualification']['status'] == 'passed' and proof['model_qualification']['cases'] == 168
    for key, n in [('boundary',72), ('models',96)]:
        value = proof['model_qualification'][key]
        assert value['status'] == 'passed' and value['cases'] == n and not value['failures'] and value['source_hashes'] == source
    runtime_proofs[label] = {k:v for k,v in proof.items() if k != 'model_candidate'}
native = {key:read(r / 'versioned-release/model-proof' / name) for key,name in
          [('boundary','qualification.json'), ('models','model-qualification.json')]}
assert all(v['status'] == 'passed' and v['source_hashes'] == source and not v['failures'] for v in native.values())
formal = read(r / 'performance/summary.json')
controls = read(r / 'latency-controls/summary.json')
memory = read(r / 'performance/final-jacobian-memory.json')
assert formal['status'] == controls['status'] == 'completed'
assert formal['fresh_children'] == controls['fresh_children'] == 18
assert formal['flows_per_child'] == 12 and controls['flows_per_child'] == 5
assert formal['source_hashes'] == controls['source_hashes']
assert formal['source_hashes']['candidate'] == memory['source_hashes']['candidate'] == source
assert memory['source_hashes']['baseline'] == formal['source_hashes']['naive']
review = read(p / 'performance-reviewed.json')
assert review['proceed_local_validation'] and review['performance_sha256'] == sha(r / 'performance/summary.json')
assert review['controls_sha256'] == sha(r / 'latency-controls/summary.json')
assert review['memory_sha256'] == sha(r / 'performance/final-jacobian-memory.json')
worker = read(p / 'generated-worker-proof.json')
assert worker['status'] == 'verified'
for name, digest in worker['inputs'].items(): assert sha(repo / name) == digest
assert sha(repo / worker['asset']) == worker['asset_sha256']
policy = read(p / 'release-policy-identity.json')
for group in [policy['files'], policy['workflows']]:
    for name, digest in group.items(): assert sha(repo / name) == digest
head = subprocess.check_output(['git','rev-parse','HEAD'], cwd=repo, text=True).strip()
assert head == local['upstream']
export = read(p / 'export-identity.json')
assert export['version'] == '0.70.0' and export['source_hashes'] == source and export['catalog_modules'] == count
snapshot = p / 'published-inputs'
snapshot.mkdir(exist_ok=True)
for name, target in [('src/stridetorch','runtime-source'), ('tests','runtime-tests')]:
    shutil.copytree(repo / 'packages/stridetorch' / name, snapshot / target,
        ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'), dirs_exist_ok=True)
for name in ['README.md','pyproject.toml','LICENSE','NOTICE']: shutil.copy2(repo / 'packages/stridetorch' / name, snapshot / name)
archive = out / 'iteration-70-harness.tar.gz'
assert not archive.exists()
seen = {}; payloads = {}; hardlinks = 0; logical_bytes = 0
excluded = {'__pycache__','.pytest_cache','.git','pytest-tmp','sdk-pytest-tmp','node_modules','build','dist'}
allowed = {'.py','.mjs','.json','.log','.md','.html','.toml','.npz','.txt','.whl','.pkl','.patch'}
with tarfile.open(archive,'w:gz') as target:
    for current, dirs, files in os.walk(r):
        dirs[:] = sorted(n for n in dirs if n not in excluded and not n.endswith(('-env','-venv','.egg-info')))
        for name in sorted(files):
            q = Path(current) / name
            if q.is_symlink() or not (q.name in ['LICENSE','NOTICE'] or q.suffix in allowed or q.name.endswith('.tar.gz')): continue
            arc = str(q.relative_to(r)); digest = sha(q); payloads[arc] = digest
            info = target.gettarinfo(str(q), arcname=arc); logical_bytes += q.stat().st_size
            key = (digest,info.mode,info.uid,info.gid,info.uname,info.gname)
            if key in seen:
                info.type = tarfile.LNKTYPE; info.linkname = seen[key]; info.size = 0; target.addfile(info); hardlinks += 1
            else:
                seen[key] = arc
                with q.open('rb') as data: target.addfile(info,data)
with tarfile.open(archive,'r:gz') as target:
    assert len(target.getmembers()) == len(payloads)
    for member in target.getmembers(): assert hashlib.sha256(target.extractfile(member).read()).hexdigest() == payloads[member.name]
record = dict(name=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),files=len(payloads),
              unique_payloads=len(seen),hardlinks=hardlinks,logical_bytes=logical_bytes,
              all_logical_payloads_verified=True,filesystem_timestamps_not_comparison_inputs=True)
assert record['bytes'] < 95*1024*1024
save(p / 'archive-identity.json',record)
report = dict(status='validated_locally',version='0.70.0',baseline_version='0.69.0',upstream=head,
    source_hashes=source,test_hashes=tests,owned_inputs=read(p / 'owned-input-sha256.json'),full_cpu=cpu,
    full_wasm=wasm,independent_package=package,versioned_runtime_contracts=runtime_proofs,native_jacobian=native,
    local_integration=local,export_identity=export,active_export_sha256=read(p / 'live-export-sha256.json'),
    release_policies=policy,generated_worker_derivation=worker,performance=formal,longer_latency_controls=controls,
    performance_review=review,cpu_allocations=memory,private_flag_counterexample=read(r / 'vjp-flag-controls/summary.json'),
    private_flag_decision=read(r / 'vjp-flag-controls/decision.json'),raw_archive=record,
    limitations=['Only first-order real reverse-mode functional Jacobians. Unsupported settings reject explicitly; no GPU dispatch.',
        'Jacobian performance and allocation reference is a qualified naive prototype, not a released0.69 API.',
        'Allocation measurements cover three CPU float64 dense sin-Jacobians; not RSS,WASM/GPU memory or a universal gain.',
        'Initial short-batch timing and rejected private-name experiment are preserved alongside longer controls. No universal speedup claim.',
        'Archive retains original absolute paths; replay requires documented runtimes/dependencies and path adjustment.',
        'Local validation does not imply main adoption,CI,release or deployment.'])
save(out / 'iteration-70.json',report)
save(p / 'state.json',dict(status='all_local_gates_passed',version='0.70.0',source_hashes=source,upstream=head,main_adopted=False))
print(json.dumps(dict(status=report['status'],cpu=cpu['summary'],wasm_modules=count,mutants=local['mutants'],raw_archive=record)),flush=True)
