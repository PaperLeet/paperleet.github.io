from pathlib import Path
import json

p=Path(__file__).resolve().parent
repo=Path('/Users/david/Developer/PaperLeet-torch-release')
report=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-70.json').read_text())
assert report['status']=='validated_locally' and report['version']=='0.70.0'
def table(rows):
    lines=['| Runtime | Flow | A/A | B/A | B/AA |','| --- | --- | --- | --- | --- |']
    for row in rows:
        med=row['medians']
        lines.append('| '+' | '.join([row['runtime'],row['case'],
            f"{med['duplicate_over_baseline']:.4f}",f"{med['candidate_over_baseline']:.4f}",
            f"{med['candidate_over_duplicate']:.4f}"])+' |')
    return '\n'.join(lines)
archive=report['raw_archive'];export=report['export_identity'];local=report['local_integration']
models=report['native_jacobian']['models'];memory=report['cpu_allocations']
memory_table='\n'.join('| '+str(row['shape'])+' | '+str(row['jacobian_bytes'])+' | '+
    f"{row['candidate_over_baseline_peak']:.4f}"+' | '+f"{row['duplicate_over_baseline_peak']:.4f}"+' |'
    for row in memory['rows'])
text=f'''# Torch runtime iteration 70: functional Jacobians with bounded temporary storage

Version 0.70 adds `torch.autograd.functional.jacobian` for the supported real
first-order reverse-mode operators. Each returned matrix has shape
`output.shape + input.shape` and the input's dtype. Tensor/tuple nesting follows
the input and output structure. The callback executes once with distinct input
objects, including repeated arguments. Original input data, gradient flags,
existing `.grad` buffers and original tensor hooks remain intact. The callback
can still update its own model buffers, as native Torch does: training BatchNorm
updates its running statistics once.

The implementation allocates one final dense buffer per input and fills rows
directly. It avoids retaining every temporary gradient row before stacking.
Dense output size still scales with output elements times input elements.

`strict=True` checks each output against each input. Default mode returns zeros
for constant or unused paths. Implicit NumPy exports during the recorded
callback raise an error; `detach()`, `no_grad()` and `numpy(force=True)` preserve
deliberate disconnection. Native empty-input, empty-output and empty-tuple
boundaries are checked. Complex inputs, higher-order graphs, vectorized or
forward-mode Jacobians and nesting inside forward AD remain unsupported.
This change adds neither `torch.func.jacrev`/`jacfwd` nor a GPU backend.

Ordinary `from torch.autograd.functional import jacobian` works inside the
existing explicit alias context. Registered Jacobian attributes on modules
survive shallow/deep copy, both tested pickle protocols and fresh-process
restoration in the standalone and private distribution namespaces.

## Verification

- Current application plus standalone CPU suite: **{report['full_cpu']['summary'][0]}**.
- Actual current Pyodide catalog: **{local['catalog_modules']} modules / {local['mutants']} mutants**, with no browser-budget exceedance.
- Exact final source in Node and Chrome WASM: **8,200 SDK cases / 68 suites each**, plus **168 independent native fixtures each** (72 boundary cases and 96 model cases).
- The same 168 fixtures replayed on final-version CPU source. Models cover linear, normalization, convolution, SDPA, captured MultiheadAttention, inverse, Cholesky, slogdet, classifier, stateful BatchNorm and embedding. Inputs cover float32/float64, contiguous/strided layout, strict mode, gradient-buffer identity, hooks, tuple structure and callback count. The model maximum observed absolute difference is `{models['max_abs_difference']}` against Torch `{models['native_torch']}`.
- Actual standalone wheel/sdist and application wheel: **8,213 installed SDK cases** on Python 3.10.19 / NumPy 1.26.4 without native Torch. All 61 runtime/license identities and 37 application identities match. Independent uninstall ownership, aliases, checkpoint resume and fresh-process VJP/Jacobian/activation restoration passed.
- **{local['frontend_commands']} frontend commands**, WASM-driver and release-policy checks, both Node 22.23.3 local build profiles and exact worker-bundle regeneration from committed source inputs.
- **{export['preserved_assets']:,}** earlier immutable cached assets preserved; **{export['new_assets']}** new reachable assets; **{export['active_export_and_index_hashes']}** live export/index identities checked.
- Application baseline: `{report['upstream']}`. Local gates do not imply main adoption; an adoption receipt is recorded separately.

## Latency and allocation tradeoffs

The initial comparison uses 18 fresh processes: six each for CPU, Node WASM
and Chrome WASM, all six source-load orders, twelve balanced common batches
of at least 20 ms per flow, and an identical-source A/A control. The nine legacy
flows compare public 0.69 and 0.70 APIs, including public VJP on both sides.
The three Jacobian flows compare a validated naive prototype with final 0.70;
they are **not** a comparison against a released 0.69 Jacobian API.

Values below are medians of per-process ratios; they are not ratios of pooled
absolute medians. Lower B/A means faster.

{table(report['performance']['rows'])}

Five older-API flows received an additional 18 fresh processes with batches
of at least 100 ms. CPU controls use hash seed 0; WASM uses its runtime default.
These longer controls retain all source-load orders and balanced A/A/B samples.

{table(report['longer_latency_controls']['rows'])}

The longer B/A medians range from approximately 0.986 to 1.017. The initially
larger VJP differences did not persist at their initial magnitude. Paired
same-source variance remains: CPU copy has B/AA 1.0311 despite B/A 1.0035.
Every original sample and both denominators are retained. No blanket
no-regression or universal speedup claim is made.

A separate six-process CPU counterexample restored only the legacy private
flag name. It showed no stable benefit and was rejected; the already qualified
generic AD source remained unchanged.

CPU `tracemalloc` measurements use three dense float64 sin-Jacobian sizes,
six balanced source orders and an identical-source duplicate. Analytic diagonal
values and caller state are checked on every result. The candidate uses about
36%–46% of the naive prototype's tracked peak allocation in these cases.

| Input shape | Final dense Jacobian bytes | Candidate / naive peak | A/A peak |
| --- | --- | --- | --- |
{memory_table}

These are CPU tracked allocations, not RSS, WASM heap or GPU memory. No latency
child overlapped our package or full application gates. Numerical kernels and
the existing cotangent lifetime improvements remain in use.

## Reproducible evidence

Machine report: `packages/stridetorch/benchmarks/results/iteration-70.json`.
Raw archive: `{archive['name']}` ({archive['bytes']:,} bytes), SHA256
`{archive['sha256']}`. All {archive['files']} logical payloads were verified after
writing; identical-content hardlinks preserve permissions and ownership. File
timestamps are not comparison inputs. The archive preserves the rejected flag
experiment, initial short samples, longer controls, source snapshots, model
fixtures and installed-package evidence. Scripts retain original absolute paths
and require dependency setup and path adjustment for replay.

The selected final source is `versioned-release/snapshot`; earlier prototype
sources retain their original 0.69 version literal and are not relabeled as
final-version runs. No CI workflow, tag, package publication or deployment was
initiated by these local checks. The independent library name remains
StrideTorch pending a naming decision.
'''
(repo/'docs/validation/torch-runtime-iteration-70.md').write_text(text)
print('Wrote terminal-evidence validation report; no commit,push or release',flush=True)
