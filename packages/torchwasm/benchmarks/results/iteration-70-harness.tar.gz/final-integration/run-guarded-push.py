"""Record the mandatory atomic guard/push sequence; never bypass a rejection."""
from pathlib import Path
import hashlib, json, subprocess, sys, time

p = Path(__file__).resolve().parent
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
own = json.loads((p / 'own-commits.json').read_text())
kind = sys.argv[1]
assert kind in ['adoption', 'proof']
expected = own['expected_remote'] if kind == 'adoption' else own['adoption_candidate_commit']
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert head == (own['adoption_candidate_commit'] if kind == 'adoption' else own['proof_commit'])
assert not subprocess.check_output(['git', 'status', '--porcelain', '-z'], cwd=repo)
wrapper = p.parent.parent / 'torch-iteration-67/final-integration/push-main-native.py'
started = time.monotonic()
with (p / ('guarded-' + kind + '-push.log')).open('w') as log:
    child = subprocess.run([sys.executable, str(wrapper), expected, str(p / 'audit-main.py')],
                           cwd=repo, stdout=log, stderr=subprocess.STDOUT)
audit = json.loads((p / 'latest-main-audit.json').read_text())
(p / (kind + '-push-audit.json')).write_text(json.dumps(audit, indent=2) + '\n')
receipt = dict(exit_code=child.returncode, seconds=time.monotonic()-started, expected_remote=expected,
    pushed_head=head, guard_allowed=audit['allowed'], audit=audit,
    log_sha256=hashlib.sha256((p / ('guarded-' + kind + '-push.log')).read_bytes()).hexdigest(),
    scope='Mandatory wrapper runs checked release-chain audit and clean-worktree check before ordinary no-tag main push. A rejection prevents Git mutation; never followed by raw push.')
(p / (kind + '-push-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key not in ['audit']}), flush=True)
child.check_returncode()
assert receipt['guard_allowed']
