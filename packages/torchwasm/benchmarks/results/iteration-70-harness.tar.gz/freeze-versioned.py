from pathlib import Path
import hashlib, json, shutil

r = Path(__file__).resolve().parent
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
release = r / 'versioned-release'
snapshot = release / 'snapshot'
package = snapshot / 'packages/stridetorch'
assert not release.exists()
package.mkdir(parents=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
prototype = r / 'candidate-source/stridetorch'
baseline = json.loads((r / 'candidate-source-hashes.json').read_text())
assert baseline == {f.name: sha(f) for f in prototype.iterdir() if f.suffix == '.py' or f.name in ['LICENSE', 'NOTICE']}
shutil.copytree(prototype, package / 'src/stridetorch', ignore=shutil.ignore_patterns('__pycache__'))
shutil.copytree(repo / 'packages/stridetorch/tests', package / 'tests', ignore=shutil.ignore_patterns('__pycache__', '.pytest_cache'))
for name in ['test_functional_jacobian.py', 'test_functional_jacobian_contracts.py']:
    shutil.copy2(r / name, package / 'tests' / name)
for name in ['README.md', 'pyproject.toml', 'LICENSE', 'NOTICE']:
    shutil.copy2(repo / 'packages/stridetorch' / name, package / name)
for q in [package / 'pyproject.toml', package / 'src/stridetorch/__init__.py']:
    s = q.read_text()
    assert '0.69.0' in s
    q.write_text(s.replace('0.69.0', '0.70.0'))
f = package / 'tests/test_module_operator_pickle.py'
s = f.read_text().replace("['sin','vjp']", "['sin','vjp','jacobian']")
s = s.replace("else torch.autograd.functional.vjp", "else getattr(torch.autograd.functional,operator)")
s = s.replace("    else:\n        out,g=restored.operator", "    elif operator=='vjp':\n        out,g=restored.operator")
s += "\n" if not s.endswith('\n') else ''
needle = "        assert out.item()==13 and g.tolist()==[4.,6.] and x.grad is None"
assert needle in s
s = s.replace(needle, needle + "\n    else:\n        jac=restored.operator(lambda a:a.square(),x)\n        assert jac.tolist()==[[4.,0.],[0.,6.]] and not jac.requires_grad and x.grad is None")
f.write_text(s)
with (package / 'README.md').open('a') as out:
    out.write('''

## Functional Jacobians

Version 0.70 adds `torch.autograd.functional.jacobian(func, inputs,
create_graph=False, strict=False, vectorize=False, strategy='reverse-mode')`
for supported real first-order operators. It runs the callback once, isolates
each explicit input from repeated arguments and captured originals, and returns
detached Jacobians shaped as `output.shape + input.shape`, with each input's
dtype. Tensor/tuple nesting follows the input and output structure. Caller
gradient flags, existing `.grad` buffers and original tensor hooks are preserved.
The callback can update its own model buffers, as in native Torch; a training
BatchNorm callback runs once and updates its running statistics once.

```python
x = torch.tensor([2., 3.])
jacobian = torch.autograd.functional.jacobian(lambda a: a.square(), x)
assert jacobian.tolist() == [[4., 0.], [0., 6.]]
```

`strict=True` checks each output against each input, including outputs that are
independent of only one argument. Constant or unused paths produce zeros in
default mode. Implicit NumPy exports inside the recorded callback raise an
error; `detach()`, `no_grad()` and `numpy(force=True)` deliberately disconnect
the graph. Empty inputs with nonempty output can yield empty Jacobians; native
empty-output and empty-tuple error boundaries are preserved.

Dense Jacobians allocate one final buffer per input and fill gradient rows
directly. Their inherent output size still scales with output elements times
input elements. Higher-order graphs, complex inputs, vectorized/forward-mode
Jacobians and nesting in forward AD remain explicitly unsupported. This API
does not add `torch.func.jacrev`, `torch.func.jacfwd` or a GPU backend.
''')
shutil.copytree(repo / 'paperleet', snapshot / 'paperleet', ignore=shutil.ignore_patterns('__pycache__'))
shutil.copy2(repo / 'pyproject.toml', snapshot / 'pyproject.toml')
source = {f.name: sha(f) for f in (package / 'src/stridetorch').iterdir() if f.suffix == '.py' or f.name in ['LICENSE', 'NOTICE']}
assert {name for name, digest in source.items() if baseline[name] != digest} == {'__init__.py'}
(release / 'source-hashes.json').write_text(json.dumps(source, indent=2) + '\n')
(release / 'test-hashes.json').write_text(json.dumps({f.name: sha(f) for f in (package / 'tests').glob('test_*.py')}, indent=2) + '\n')
print('Frozen0.70snapshot:',len(source),'source/license files;',len(list((package/'tests').glob('test_*.py'))),'test files; only version literal differs from the qualified prototype runtime')
