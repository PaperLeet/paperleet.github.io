from pathlib import Path
import hashlib,json,subprocess,datetime
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=repo,text=True).split()[0];assert head==remote
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip()
actions=json.loads(subprocess.check_output(['gh','api',f'repos/PaperLeet/paperleet.github.io/actions/runs?head_sha={head}&per_page=100'],cwd=repo,text=True));assert actions['total_count']==0,[(v['id'],v['event'],v['status']) for v in actions['workflow_runs']]
source=json.loads((r/'proof/source-hashes.json').read_text());live=json.loads((r/'integration-proof/live-expected-sha256.json').read_text());policy=json.loads((r/'release-policy-identity.json').read_text())
for name,digest in source.items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==digest
for name,digest in live.items():assert hashlib.sha256((repo/'web/public/data'/name).read_bytes()).hexdigest()==digest
for name,digest in policy['files'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
assert len(subprocess.check_output(['git','ls-files','-z','--','web/public/data/browser-judge','web/public/data/modules'],cwd=repo).split(b'\0'))-1==11177
report=dict(status='source_adopted_on_main',version='0.51.0',source_commit=head,observed_remote_main=remote,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actions_runs_for_source_sha=actions['total_count'],source_resources=source,active_export_sha256=live,canonical_release_policy=policy,immutable_payloads=11177,scope='Ordinary non-force main push after exact local source/test/package/frontend/catalog/performance gates. No tag,workflow dispatch,release,package upload or deployment initiated by this work. Proof commit follows; final proof-head verification is recorded outside repository to avoid recursive commit identities.')
(repo/'packages/stridetorch/benchmarks/results/iteration-51-main-adoption.json').write_text(json.dumps(report,indent=2)+'\n')
p=repo/'docs/validation/torch-runtime-iteration-51.md';text=p.read_text();assert '## Main adoption' not in text
text+='\n## Main adoption\n\nValidated source `'+head+'` was adopted on remote main by ordinary non-force push. The remote SHA was verified exactly; zero Actions runs were observed for this source SHA. All 55 source/license resources, 161 active export identities, 10,861 immutable payloads and seven canonical release-policy files were rechecked. The separate proof commit is verified outside the repository after its push. No tag,dispatch,release,PyPI upload or online deployment was initiated by this work.\n';p.write_text(text)
print('RECORDED SOURCE_MAIN',head,flush=True)
