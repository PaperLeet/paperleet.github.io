from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,os,subprocess,time,hashlib,shutil
r=Path(__file__).resolve().parent;p=r/'proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release');py=r.parent/'torch-iteration-21/stride-dev-env/bin/python'
gates=json.loads((p/'gate-receipts.json').read_text());assert len(gates)==6 and all(v['exit_code']==0 for v in gates.values())
shutil.copy2(p/'gate-receipts.json',p/'gate-receipts-before-readme.json')
shutil.copytree(p/'dist-preflight',p/'dist-before-readme',dirs_exist_ok=True)
env=dict(os.environ,OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');receipts={}
def run(name,args,cwd):
 start=time.monotonic()
 with (p/(name+'-metadata-recheck.log')).open('w') as log:child=subprocess.run([str(v) for v in args],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 return name,dict(exit_code=child.returncode,elapsed_s=time.monotonic()-start,args=[str(v) for v in args],cwd=str(cwd))
name,receipt=run('build-public',['/Users/david/.local/bin/uv','build','--out-dir',p/'dist-preflight'],repo/'packages/stridetorch');receipts[name]=receipt;assert receipt['exit_code']==0,receipt
with ThreadPoolExecutor(max_workers=2) as pool:
 for future in as_completed([pool.submit(run,name,[py,p/script],repo) for name,script in [('minimal-wheel','check-wheel.py'),('coinstall','check-coinstall.py')]]):
  name,receipt=future.result();receipts[name]=receipt;print(name,receipt['exit_code'],flush=True)
assert all(v['exit_code']==0 for v in receipts.values()),receipts
for name,digest in json.loads((p/'source-hashes.json').read_text()).items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==digest
gates.update(receipts);(p/'gate-receipts.json').write_text(json.dumps(gates,indent=2)+'\n');(p/'metadata-recheck-receipts.json').write_text(json.dumps(dict(reason='Clarify selective pullback buffer ownership versus active leaf storage; package README metadata changed, numerical source/tests unchanged',receipts=receipts),indent=2)+'\n');print('PACKAGE METADATA RECHECK PASS',flush=True)
