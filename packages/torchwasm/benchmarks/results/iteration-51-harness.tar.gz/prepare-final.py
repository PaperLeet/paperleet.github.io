from pathlib import Path
import json,hashlib,shutil,subprocess
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-50';repo=Path('/Users/david/Developer/PaperLeet-torch-release');p=r/'proof';p.mkdir(exist_ok=True);chrome=p/'chrome-contracts';chrome.mkdir(exist_ok=True)
def save(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n')
def hashes(folder):return {f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in folder.iterdir() if f.is_file()}
for dest in [p/'source',chrome/'source']:
    dest.mkdir(exist_ok=True)
    for f in (repo/'packages/stridetorch/src/stridetorch').iterdir():
        if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']:shutil.copy2(f,dest/f.name)
source=hashes(p/'source');assert len(source)==55;save(p/'source-hashes.json',source)
tests=chrome/'tests';tests.mkdir(exist_ok=True)
for f in (repo/'packages/stridetorch/tests').glob('test_*.py'):
    if f.name!='test_standalone.py':shutil.copy2(f,tests/f.name)
assert len(hashes(tests))==48
save(chrome/'plan.json',dict(version='0.51.0',expected=6184,source=source,tests=hashes(tests)))
def adapt(text):return text.replace('torch-iteration-50','torch-iteration-51').replace('0.50.0','0.51.0').replace('stride050','stride051')
for name in ['run.mjs','worker.mjs','index.html']:
    s=adapt((old/'proof/chrome-contracts'/name).read_text())
    if name=='run.mjs':
        s="import {withFixtureServer} from '../../fixture-server.mjs';\n"+s
        pos=s.index('const browser=');s=s[:pos]+"await withFixtureServer(async origin=>{\n"+s[pos:]+"\n});\n"
        s=s.replace("'http://127.0.0.1:8766/torch-iteration-51/proof/chrome-contracts/'","origin+'/torch-iteration-51/proof/chrome-contracts/'")
    (chrome/name).write_text(s)
for name in ['wasm-contracts.mjs','check-wheel.py','check-coinstall.py']:
    s=adapt((old/'proof'/name).read_text())
    if name=='wasm-contracts.mjs':s=s.replace("'nn_workflows','attention'","'nn_workflows','attention','attention_efficiency'").replace('6053','6184')
    (p/name).write_text(s)
for name in ['run-full.py','run-gates.py','run-setup-final.py']:(r/name).write_text(adapt((old/name).read_text()))
i=r/'integration-proof';i.mkdir(exist_ok=True)
for name in ['run-setup.py','run-export.py','freeze.py','verify-private.py','verify-export.py','run-native.py','run-frontend.py','run-wasm.py']:
    s=adapt((old/'integration-proof'/name).read_text())
    if name=='freeze.py':s=s.replace('len(tests)==47','len(tests)==48').replace('6053','6184').replace('expected_suites=47','expected_suites=48')
    if name=='verify-export.py':s=s.replace('10861','11019')
    if name=='run-wasm.py':s=s.replace('6053','6184').replace('==47','==48')
    (i/name).write_text(s)
upstream=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
save(i/'context.json',dict(upstream=upstream,version='0.51.0',source_hashes=source))
shutil.copy2(repo/'packages/stridetorch/benchmarks/bench_attention.py',r/'bench_attention.py')
for name in ['native-ci.json','native-receipt.json','native-ci.log']:
    shutil.copy2(old/'integration-proof'/name,i/name)
shutil.copy2(old/'native-catalog-input-identity.json',r/'native-catalog-input-identity.json')
identity=json.loads((r/'native-catalog-input-identity.json').read_text())
for name,digest in identity['files'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
save(i/'native-reference-reuse.json',dict(status='unchanged_native_reference_reused',files=len(identity['files']),original='../torch-iteration-50/integration-proof/native-ci.json',reason='Native catalog,runner,solutions,mutants,tests and configuration unchanged; adapter-only attention efficiency changes. Final CPU/WASM/package/export gates run on final source.'))
for name in ['release-policy-identity.json','runtime-metadata.json']:shutil.copy2(old/name,r/name)
for name,digest in json.loads((r/'release-policy-identity.json').read_text())['files'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
print(dict(resources=len(source),suites=48,contracts=6184,upstream=upstream))
