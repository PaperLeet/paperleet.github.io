from pathlib import Path
import hashlib,json,os,statistics,subprocess,time
r=Path(__file__).resolve().parent;out=r/'performance';out.mkdir(exist_ok=True);py=r.parent/'torch-iteration-21/stride-dev-env/bin/python'
def read(name):return json.loads((r/name).read_text())
source=read('proof/source-hashes.json');baseline=read('baseline.json')['source'];legacy=read('legacy-baseline.json')['source'];receipts={}
assert read('full-root-receipt.json')['exit_code']==0 and read('integration-proof/wasm-receipt.json')['exit_code']==0
for name in ['adapter-differential.json','adapter-training.json','adapter-scaling.json']:assert read(name)['status']=='success' and read(name)['source_hashes']==source
assert read('tape-proof.json')['status']=='success' and read('tape-proof.json')['source_hashes']==dict(baseline=baseline,candidate=source)
for name in ['proof/source-wasm.json','proof/chrome-contracts/result.json']:assert read(name)['source_hashes']==source
env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');load_before=os.getloadavg()
digests={phase:hashlib.sha256((r/('bench_attention.py' if phase=='primary' else 'bench_attention_legacy.py')).read_bytes()).hexdigest() for phase in ['primary','legacy']}
for repeat in range(4):
 for runtime in (('cpu','node','chrome') if repeat%2==0 else ('chrome','node','cpu')):
  for phase in (('primary','legacy') if repeat%2==0 else ('legacy','primary')):
   name=f'{phase}-{runtime}-{repeat}';output=out/(name+'.json');reverse=['--reverse'] if (repeat+(phase=='legacy'))%2 else []
   bench='bench_attention.py' if phase=='primary' else 'bench_attention_legacy.py';base='baseline-source' if phase=='primary' else 'legacy-source'
   args=([str(py),str(r/bench),'--baseline-source',str(r/base/'stridetorch'),'--candidate-source',str(r/'proof/source'),'--output',str(output)] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(r/('bench-wasm.mjs' if runtime=='node' else 'bench-chrome.mjs')),str(output),*(['--legacy'] if phase=='legacy' else [])])+reverse
   start=time.monotonic()
   with (out/(name+'.log')).open('w') as log:child=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
   receipts[name]=dict(args=args,exit_code=child.returncode,elapsed_s=time.monotonic()-start);(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');child.check_returncode()
   row=json.loads(output.read_text());assert row['status']=='success' and row['candidate_version']=='0.51.0' and row['baseline_version']==('0.50.0' if phase=='primary' else '0.49.0')
   assert len(row['flows'])==(40 if phase=='primary' else 22) and row['source_hashes']==dict(baseline=baseline if phase=='primary' else legacy,candidate=source)
   if runtime!='cpu':assert row['numpy']=='2.2.5' and row['pyodide']=='0.29.4' and row['benchmark_sha256']==digests[phase]
   print(name,'PASS',round(receipts[name]['elapsed_s'],2),flush=True)
summary={}
for phase in ['primary','legacy']:
 summary[phase]={}
 for runtime in ['cpu','node','chrome']:
  reports=[read(f'performance/{phase}-{runtime}-{i}.json') for i in range(4)];rows=[]
  for case,first in enumerate(reports[0]['flows']):
   row={k:first[k] for k in ['kind','dtype','mode','probability'] if k in first};times={name:[j['flows'][case]['median_s'][name] for j in reports] for name in first['median_s']};medians={name:statistics.median(v) for name,v in times.items()}
   row.update(median_s=medians,all_child_median_s=times,time_reduction_percent=100*(1-medians['candidate']/medians['baseline']))
   if 'repeated_control' in medians:row['repeated_control_time_reduction_percent']=100*(1-medians['candidate']/medians['repeated_control'])
   rows.append(row)
  summary[phase][runtime]=rows
for phase,bench in [('primary','bench_attention.py'),('legacy','bench_attention_legacy.py')]:assert digests[phase]==hashlib.sha256((r/bench).read_bytes()).hexdigest()
(r/'performance-summary.json').write_text(json.dumps(dict(status='success',children=len(receipts),all_children_terminal=True,summary=summary,receipts=receipts,source_hashes=dict(baseline=baseline,legacy=legacy,candidate=source),benchmark_sha256=digests,load_before=load_before,load_after=os.getloadavg(),scope='24 fresh children:40 primary flows compare actual0.50 builtin attention with0.51 forward/reverse/JVP/dropout/SGD;22 preserved legacy flows compare actual0.49 with0.51 and retain singleton broadcasting. Four children per phase/runtime,alternating phase/runtime/method order,5samples/8calls. All samples and regressions retained; not exclusive-host,RSS,GPU,native Torch or universal speed evidence.'),indent=2)+'\n')
