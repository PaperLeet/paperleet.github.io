import fs from 'node:fs';import assert from 'node:assert/strict';import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import {withFixtureServer} from './fixture-server.mjs';
await withFixtureServer(async origin=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 try{
  const page=await browser.newPage();await page.goto(origin+'/torch-iteration-51/proof/chrome-contracts/');
  const result=await page.evaluate(options=>new Promise((resolve,reject)=>{
   const worker=new Worker('./bench-worker.mjs',{type:'module'});const timer=setTimeout(()=>{worker.terminate();reject(Error('benchmark timeout'));},240000);
   worker.onmessage=({data})=>{clearTimeout(timer);worker.terminate();resolve(data);};worker.onerror=e=>{clearTimeout(timer);worker.terminate();reject(Error(e.message));};worker.postMessage(options);
  }),{reverse:process.argv.includes('--reverse'),legacy:process.argv.includes('--legacy')});
  assert(!result.error,JSON.stringify(result));assert.equal(result.status,'success');result.browser=browser.version();fs.writeFileSync(process.argv[2],JSON.stringify(result,null,2)+'\n');console.log('PASS',result.flows.length,'Chrome flows');
 }finally{await browser.close();}
});
