from pathlib import Path
import json,hashlib,shutil
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');c=r/'proof/chrome-contracts'
def hashes(d):return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.iterdir() if p.is_file() and (p.suffix=='.py' or p.name in ['LICENSE','NOTICE'])}
shutil.copy2(repo/'packages/stridetorch/benchmarks/bench_attention.py',r/'bench_attention.py');shutil.copy2(r/'bench_attention.py',c/'bench.py');shutil.copy2(r/'bench_attention_legacy.py',c/'legacy-bench.py')
for name in ['baseline','legacy']:
 target=c/name;target.mkdir(exist_ok=True)
 for p in (r/('baseline-source' if name=='baseline' else 'legacy-source')/'stridetorch').iterdir():
  if p.is_file() and (p.suffix=='.py' or p.name in ['LICENSE','NOTICE']):shutil.copy2(p,target/p.name)
plan=dict(source=hashes(r/'proof/source'),baseline=hashes(r/'baseline-source/stridetorch'),legacy=hashes(r/'legacy-source/stridetorch'),benchmark_sha256=hashlib.sha256((r/'bench_attention.py').read_bytes()).hexdigest(),legacy_benchmark_sha256=hashlib.sha256((r/'bench_attention_legacy.py').read_bytes()).hexdigest())
assert len(plan['source'])==len(plan['baseline'])==55 and len(plan['legacy'])==54
(c/'bench-plan.json').write_text(json.dumps(plan,indent=2)+'\n');print('Prepared modern40/legacy22 flows,55/55/54 source identities')
