from pathlib import Path
import json,statistics
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
a=json.loads((out/'iteration-51.json').read_text());b=json.loads((out/'iteration-51-integration.json').read_text());perf=a['performance'];primary=[];legacy=[]
for runtime,label in [('cpu','NumPy CPU'),('node','Node/Pyodide'),('chrome','Chrome Worker')]:
 rows=perf['summary']['primary'][runtime]
 for group,kinds in [('ordinary',['small','self']),('GQA',['grouped','cross_grouped','long_grouped']),('dropout GQA',['dropout_grouped'])]:
  for mode in ['forward','reverse','jvp']:
   values=[v['time_reduction_percent'] for v in rows if v['kind'] in kinds and v['mode']==mode]
   primary.append(f'| {label} | {group} | {mode} | {statistics.median(values):.1f}% | {min(values):.1f}% to {max(values):.1f}% |')
 for probability in [0.,.25]:
  values=[v['time_reduction_percent'] for v in rows if v['kind']=='training' and v['probability']==probability]
  primary.append(f'| {label} | encoder SGD p={probability} | full step | {statistics.median(values):.1f}% | {min(values):.1f}% to {max(values):.1f}% |')
 rows=perf['summary']['legacy'][runtime]
 for group,kinds in [('ordinary',['small','self']),('GQA',['grouped','cross_grouped','long_grouped']),('encoder SGD',['training'])]:
  values=[v['time_reduction_percent'] for v in rows if v['kind'] in kinds]
  legacy.append(f'| {label} | {group} | {statistics.median(values):.1f}% | {min(values):.1f}% to {max(values):.1f}% |')
text=f'''# Torch runtime iteration 51 — Attention validation and selective saved buffers

Version 0.51.0 reduces repeated attention metadata work and selectively retains
ordinary VJP operands. It preserves 0.50's GQA, dropout, forward/mixed AD and signed
balanced Q/K prescaling. The broader independent-library, core API/efficiency and
optional GPU-backend objective remains active.

## Implementation and memory scope

- Move repeated shape/dtype validation and default-scale calculation into one
  bounded 64-entry metadata cache. Keys contain shapes, canonical dtype strings
  and configuration; no NumPy dtype metadata, tensor, activation, seed, gradient
  or RNG state is cached. Tensor types and scalar options are checked every call.
- Replace generator-based hot-path checks with direct checks. A no-gradient call
  constructs its output without constructing an unused joint pullback. Saved
  versions, dtype rules, scalar validation and forward-tensor handling remain.
- Singleton K/V heads use normal matrix broadcasting in ordinary and forward AD,
  avoiding extra grouped reshapes and graph nodes. Other GQA heads retain grouped
  contraction and reduction without materialized repeated K/V heads.
- Save scaled K only when Q gradients need it, scaled Q only when K gradients
  need it, and V values only when logits gradients need them. Pullback needs stay
  captured at graph construction even when leaf flags later change.
- For a dropout VJP with Q/K/mask gradients, retain probabilities and one sampled
  multiplier; regenerate their product only for V gradients. A V-only pullback
  retains just the product. Retained backwards reuse the original multiplier and
  never draw RNG samples. Original input/mask version guards are preserved.

| Ordinary fused VJP | 0.50 unique score-shaped arrays | 0.51 |
|---|---:|---:|
| No dropout, all gradients | 1 | 1 |
| Dropout, all gradients | 3 | 2 |
| Dropout, V gradient only | 3 | 1 |

The 192 source-identified tape observations cover both dtypes, all 16 active-input
subsets and probabilities 0/.25/1. Weak-reference tests independently track
probabilities, the multiplier, the used probability product and scaled operands.
These are retained logical arrays in the fused first-order pullback, not complete
graph storage, process peak RSS or a compositional JVP/mixed-AD tape bound. Active
leaf storage can remain live for accumulation; the original-array lifetime probe
records that behavior explicitly. Transient products can be created in backward.
Score/probability sizes still grow with query length × key length; no streaming
attention, FlashAttention or GPU execution is claimed.

## Local validation

| Check | Result |
|---|---|
| Complete repository/library CPU suite | {a['full_cpu']['passed']:,} passed, {a['full_cpu']['skipped']} skipped; {a['full_cpu']['duration_s']:.2f}s |
| New efficiency regression suite | 131 tests: 96 independent scalar dropout/VJP cases, 24 lifetime cases, 11 cache/type/value cases |
| Existing attention regression suite | 161 tests; 292 focused total |
| Native math primitive comparison | 204 cases, 2,592 arrays |
| Selected extreme finite-logit comparison | 32 cases, 208 arrays |
| Native mixed-AD encoder/SGD/checkpoint comparison | 200 arrays |
| Actual Node/Pyodide 0.29.4 / NumPy 2.2.5 | 6,184 contracts, 48 suites |
| Actual Chrome {a['chrome_worker']['browser']} Worker | 6,184 contracts, identical sources/tests |
| Installed Python 3.10.19 / NumPy 1.26.4 standalone wheel | 6,197 passed; native Torch absent |
| Both distributions and independent uninstall | Exact 55 source/license resources, separate ownership |
| Original native PaperLeet catalog | 78 problems, 10,218 executions, 342 mutants, three repeats; {b['native']['duration_s']:.3f}s / 600s |
| Final exported WASM catalog | 78/78, 342 mutants, 6,184 contracts; {b['wasm']['elapsed_ms']/1000:.3f}s |
| Frontend and both build profiles | Five successful local receipts |
| Release policy | Seven files byte-identical to canonical `13d2782a494415ba72bc604a0ef7e4c4f875ba25` |

Independent scalar loops calculate grouped softmax, dropout values and every VJP
for each active-input subset, including fully-masked rows and repeated seeds.
Warm-cache tests change values, dtypes, feature/head shapes and scalar options.
The dtype-metadata test proves that a user object attached to a NumPy dtype is
collected after caller references disappear. Cache capacity stays bounded at 64.

Frozen native oracle arrays are reused from iteration 50's separately executed
PyTorch 2.14.1 math backend and checked against final 0.51 source. The primitive
set uses a native compositional safe-softmax reference for fully-masked mixed AD;
the 496 official-SDPA NaN-containing mixed arrays and their 100 cases remain
explicitly classified in the original oracle record. Every finite official entry
and all official values/JVPs/first VJPs are checked there. The stable zero mixed
derivative extension, strict [0,1] dropout probability rule and distribution-faithful
library RNG stream remain as documented in the [0.50 record](torch-runtime-iteration-50.md).
No native seeded dropout bit-stream equivalence is asserted.

The unchanged original native catalog receipt is reused after checking all 1,152
native catalog/runner/test/configuration file identities. Final source CPU,
Node/Chrome, package and exported-WASM checks run on the final adapter. Native
tolerances remain rtol 3e-5/atol 2e-5 for float32 primitive arrays, 5e-5/4e-6 for
encoder training; float64 uses 1e-11/8e-12 and 2e-11/2e-12. Selected extreme cases
use tighter checks. README wording was clarified to distinguish pullback arrays
from live leaf storage; the public package was rebuilt and minimum-wheel/coinstall
checks repeated. Mathematical source/test hashes did not change for that recheck.

## Performance versus 0.50

The primary portable benchmark loads independent actual 0.50 and 0.51 snapshots.
Both use their builtin GQA. It runs 36 primitive flows across ordinary/GQA/dropout
attention and forward/reverse/JVP, plus four full encoder SGD flows with/without
dropout in both dtypes. Values, all VJPs, JVPs and reverse-over-forward derivatives
are compared before timing; three seeded matching optimizer updates are checked.
Timed SGD does not copy parameters back for diagnostics on every update.

A same-source fully repeated K/V control covers forward/reverse/SGD. It does not
claim unsupported repeat_interleave JVP. Dropout qualification resets identical
seeds; timed calls use the same distribution without per-call seed-reset overhead.
All timing samples and regressions are retained. Positive percentages mean less time.

| Runtime | Workload | Mode | Median time reduction vs 0.50 | Range across flows/dtypes |
|---|---|---|---:|---:|
{chr(10).join(primary)}

The primary complete-SGD time reductions, taking the median across both dtypes
and dropout settings, are 2.2% on CPU, 3.5% on Node/Pyodide and 0.5% on Chrome.
Some individual flows still regress; every range and underlying sample is retained.

## Regression comparison versus 0.49

A separate unchanged 22-flow harness compares actual 0.49 and 0.51 source.
It preserves singleton-head broadcasting and repeats only non-singleton heads that
must expand. This covers 0.49-supported forward/reverse and original encoder SGD
workloads; it does not simulate its missing dropout/JVP support. Its original
timed diagnostic copies remain unchanged, so it is separate from the primary
training benchmark. The comparison measures whether 0.50's observed regressions
are recovered under the same current runtime, without mixing old timing sessions.

| Runtime | Workload | Median time reduction vs 0.49 | Range across flows/dtypes |
|---|---|---:|---:|
{chr(10).join(legacy)}

Under this unchanged legacy protocol, complete-SGD medians remain 0.9%–1.8%
slower than 0.49. This revision does not fully erase the older-version regression.
The primary and legacy training protocols are kept distinct.

There are 24 fresh child invocations: four per runtime per benchmark phase, with
alternating phase/runtime/method order, five samples and eight calls per sample.
CPU numerical-library threads are capped at two; Node and actual Chrome use the
pinned Pyodide runtime. Runtime metadata and load observations are retained. This
shared-host evidence does not establish exclusive capacity, universal speed,
native Torch/GPU speed, cold-start or process peak-memory improvement. Pilots and
concurrent preflights are preserved separately from the final sequential run.

## Source and integration identity

All 53 Python modules plus LICENSE/NOTICE remain. Fifty-three old resources are
unchanged; `__init__.py` and `_attention.py` change. Source/license bytes change
from {a['source_footprint']['baseline']['raw_source_license_bytes']:,} to {a['source_footprint']['candidate']['raw_source_license_bytes']:,};
local concatenated gzip changes from {a['source_footprint']['baseline']['local_concatenated_gzip_bytes']:,} to {a['source_footprint']['candidate']['local_concatenated_gzip_bytes']:,}.
These are source estimates, not wheel/network bytes or measured memory. Dependency
versions and lockfile are unchanged; fourteen pinned Pyodide files were rechecked.

All 11,019 published immutable payloads are preserved. The 158 new reachable
payloads yield 11,177 total; 161 active export hashes match the final source.
Concurrent upstream changes, when present, are preserved as exact Git blobs with
fresh affected frontend/build checks and recorded in `upstream_syncs`.

The Chrome harness owns a localhost fixture server on an ephemeral port and closes
it with its browser. It needs no pre-existing fixed-port server. Numerical source,
tests, native reference arrays, scalar/lifetime observations, command receipts,
logs and all primary/legacy timing samples are retained in `iteration-51.json`,
`iteration-51-integration.json` and four matching raw harness archives under
`packages/stridetorch/benchmarks/results`.

Broader core coverage, Multihead/Transformer modules, additional temporary-buffer
work and optional persistent GPU execution remain active. No tag, workflow
dispatch, release, PyPI upload or deployment is initiated by this work.
'''
(repo/'docs/validation/torch-runtime-iteration-51.md').write_text(text)
def section(path,heading,body):
 p=repo/path;s=p.read_text().split('\n'+heading)[0].rstrip();p.write_text(s+'\n\n'+heading+'\n\n'+body+'\n')
section('packages/stridetorch/ROADMAP.md','## Attention validation and selective saved buffers (0.51)', '''- Cache canonical shape/dtype metadata without retaining NumPy dtype metadata,
  tensor values or RNG state. Keep scalar/type guards per call and the 64-entry cap.
- Use singleton-head matrix broadcasting and release unneeded scaled operands.
  Dropout ordinary VJPs retain two score-shaped arrays with all gradients or one
  with V-only gradients, versus three before; active leaf storage remains scoped.
- Preserve signed balanced prescaling, fully-masked behavior, all AD channels,
  original version guards, original multipliers and retained backwards.
- Validate 131 new cases, 161 existing attention cases, source-identified native
  primitive/extreme/encoder oracles, 192 tape observations, full CPU/Node/Chrome,
  minimum package/coinstall and 78 exported problems. Retain 40 primary and 22
  legacy timing flows across 24 fresh children, including every regression.
- See the [iteration 51 record](../../docs/validation/torch-runtime-iteration-51.md).
  Core API coverage, Multihead/Transformer modules, temporary work and persistent
  GPU-backend evaluation continue toward independent-library quality.''')
section('packages/stridetorch/benchmarks/README.md','## Attention validation and saved buffers (0.51)', '''The updated `bench_attention.py` compares actual builtin attention in 0.50/0.51
over 40 forward/reverse/JVP/dropout/encoder-SGD flows, with a repeated K/V control
for supported forward/reverse/SGD paths. It checks values/all VJPs/JVP/mixed AD and
three matching optimizer updates before timing. Timed training avoids diagnostic
weight copies. The preserved 22-flow legacy harness separately compares 0.49/0.51
with singleton broadcasting retained. Four fresh children per runtime/phase,
alternating orders and every sample are kept. See the
[validation record](../../../docs/validation/torch-runtime-iteration-51.md) for
scope, regressions and retained-buffer versus peak-memory distinctions.''')
print('WROTE51 validation/roadmap/benchmark documentation')
