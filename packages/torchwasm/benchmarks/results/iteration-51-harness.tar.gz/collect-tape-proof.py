from pathlib import Path
import gc,hashlib,importlib.util,json,sys,weakref
import numpy as np
r=Path(__file__).resolve().parent
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path/'__init__.py',submodule_search_locations=[str(path)]);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m)
 return m,{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in path.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']}
results={};sources={}
for label,path in [('baseline',r/'baseline-source/stridetorch'),('candidate',r/'proof/source')]:
 package,sources[label]=load('_tape_'+label,path);t=package.torch;rows=[]
 for dtype in ['float32','float64']:
  for probability in [0.,.25,1.]:
   for active in range(16):
    values=[t.ones(*s,dtype=getattr(t,dtype),requires_grad=bool(active&(1<<i))) for i,s in enumerate([(6,3,4),(2,5,4),(3,5,6),(3,5)])]
    refs=[weakref.ref(x._data) for x in values]
    y=t.nn.functional.scaled_dot_product_attention(*values[:3],attn_mask=values[3],enable_gqa=True,dropout_p=probability)
    cells=[];seen={}
    if active:
     callback=y._grad_node.joint[0]
     for name,cell in zip(callback.__code__.co_freevars,callback.__closure__):
      value=cell.cell_contents
      if isinstance(value,np.ndarray):
       alias=seen.setdefault(id(value),len(seen));cells.append(dict(name=name,shape=list(value.shape),dtype=str(value.dtype),bytes=value.nbytes,alias_group=alias))
     del callback,value,cell
    score={v['alias_group']:v['bytes'] for v in cells if v['shape']==[6,3,5]}
    del values;gc.collect();alive=[ref() is not None for ref in refs]
    rows.append(dict(dtype=dtype,dropout_p=probability,active_mask=active,unique_score_arrays=len(score),logical_score_bytes=sum(score.values()),captured_arrays=cells,original_arrays_alive_without_caller_refs=alive))
    if active:y.sum().backward()
    del y
 results[label]=dict(version=package.__version__,rows=rows)
for dtype in ['float32','float64']:
 for active,wanted in [(15,2),(4,1)]:
  b=next(v for v in results['baseline']['rows'] if v['dtype']==dtype and v['dropout_p']==.25 and v['active_mask']==active)
  c=next(v for v in results['candidate']['rows'] if v['dtype']==dtype and v['dropout_p']==.25 and v['active_mask']==active)
  assert b['unique_score_arrays']==3 and c['unique_score_arrays']==wanted
out=dict(status='success',scope='Unique NumPy arrays captured in the ordinary fused VJP callback. Original active leaf storage may remain live; this is not complete graph storage, JVP tape or process RSS.',source_hashes=sources,results=results)
(r/'tape-proof.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS192 tape cases;all-gradient dropout3to2;V-only3to1;original leaf storage recorded')
