from pathlib import Path
import subprocess,json,hashlib,shutil
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
before=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();after=subprocess.check_output(['git','rev-parse','FETCH_HEAD'],cwd=repo,text=True).strip()
assert before=='e4139c1eeb1dc64ea8d43189c9a90aa4b8b18eae' and after=='4081ce14ee98319f3da5f6708184991222fbf7e0'
expected={'web/package.json','web/scripts/check-build.mjs','web/scripts/check-interview-facets.mjs','web/scripts/check-profile-interviews.mjs','web/src/Community.tsx','web/src/InterviewMeta.tsx','web/src/InterviewReportCard.tsx','web/src/interviewFacetNavigation.ts','web/src/interviews.css'}
paths=set(subprocess.check_output(['git','diff','--name-only',before,after],cwd=repo,text=True).splitlines());assert paths==expected
for name,digest in json.loads((r/'proof/source-hashes.json').read_text()).items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==digest
for name,digest in json.loads((r/'integration-proof/live-expected-sha256.json').read_text()).items():assert hashlib.sha256((repo/'web/public/data'/name).read_bytes()).hexdigest()==digest
hashes={name:hashlib.sha256(subprocess.check_output(['git','show',after+':'+name],cwd=repo)).hexdigest() for name in paths}
archive=r/'integration-proof/frontend-before-upstream';archive.mkdir()
front=json.loads((r/'integration-proof/frontend-receipts.json').read_text())
for name in ['frontend-receipts.json','pages-profile.json',*[v['log'] for v in front]]:shutil.copy2(r/'integration-proof'/name,archive/name)
subprocess.check_call(['git','merge','--ff-only','FETCH_HEAD'],cwd=repo,stdout=subprocess.DEVNULL)
for name,digest in hashes.items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
(r/'upstream-syncs.json').write_text(json.dumps([dict(before=before,after=after,paths=hashes,receipts='integration-proof/frontend-receipts.json',scope='Nine exact UI-only blobs preserved; final numerical source/tests/exports and all performance samples unchanged; rerun5 frontend/build receipts')],indent=2)+'\n')
p=r/'integration-proof/context.json';x=json.loads(p.read_text());x['upstream']=after;p.write_text(json.dumps(x,indent=2)+'\n');print('FAST-FORWARD9 UI blobs preserved;final source/exports unchanged')
