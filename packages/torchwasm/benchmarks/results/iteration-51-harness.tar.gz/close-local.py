from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results';out.mkdir(exist_ok=True)
def read(name):return json.loads((r/name).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,obj):path.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')
source=repo/'packages/stridetorch/src/stridetorch';actual={p.name:sha(p) for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
plan=read('proof/chrome-contracts/plan.json');tests={p.name:sha(p) for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'}
assert len(actual)==55 and actual==read('proof/source-hashes.json')==plan['source'];assert len(tests)==48 and tests==plan['tests'] and plan['expected']==6184
full=read('full-root-receipt.json');assert full['exit_code']==0 and full['passed']==39813 and full['skipped']==1
assert '292 passed' in (r/'attention-final.log').read_text()
gates=read('proof/gate-receipts.json');assert len(gates)==6 and all(v['exit_code']==0 for v in gates.values())
node=read('proof/source-wasm.json');chrome=read('proof/chrome-contracts/result.json');wheel=read('proof/wheel-stride051-result.json');coinstall=read('proof/coinstall-result.json')
assert node['passed']==chrome['passed']==6184 and chrome['test_hashes']==tests
assert node['source_hashes']==chrome['source_hashes']==wheel['source_hashes']==coinstall['source_hashes']==actual
assert all(v['status']=='success' for v in (chrome,wheel,coinstall)) and not wheel['native_torch']
assert '6197 passed' in (r/'proof/python310-stride051-tests.log').read_text();assert node['numpy']=='2.2.5' and node['library']=='0.51.0'
numeric=read('adapter-differential.json');oracle=read('native-differential.json');training=read('adapter-training.json');scaling=read('adapter-scaling.json')
reused_oracles=read('native-oracle-reuse.json');assert reused_oracles['status']=='verified_exact_frozen_native_oracles'
for name,digest in reused_oracles['files'].items():assert sha(r/name)==digest
assert numeric['status']=='success' and numeric['cases']==204 and numeric['checks']==2592 and numeric['source_hashes']==actual and not numeric['failures']
assert oracle['status']=='success' and oracle['checks']==2592 and len(oracle['fully_masked_mixed_differences'])==496
assert training['status']=='success' and training['checks']==200 and training['source_hashes']==actual
assert scaling['status']=='success' and scaling['cases']==32 and scaling['checks']==208 and scaling['source_hashes']==actual
for name,digest in read('native-catalog-input-identity.json')['files'].items():assert sha(repo/name)==digest
assert read('integration-proof/native-reference-reuse.json')['status']=='unchanged_native_reference_reused'
performance=read('performance-summary.json');assert performance['status']=='success' and performance['children']==24 and performance['all_children_terminal'] and all(v['exit_code']==0 for v in performance['receipts'].values())
baseline=read('baseline.json');assert len(baseline['source'])==55
assert (r/'bench_attention.py').read_bytes()==(repo/'packages/stridetorch/benchmarks/bench_attention.py').read_bytes()
legacy=read('legacy-baseline.json');assert len(legacy['source'])==54
for phase,expected_flows in [('primary',40),('legacy',22)]:
 for runtime in ('cpu','node','chrome'):
  for repeat in range(4):
   row=read(f'performance/{phase}-{runtime}-{repeat}.json');base=baseline['source'] if phase=='primary' else legacy['source']
   assert row['status']=='success' and len(row['flows'])==expected_flows and row['source_hashes']==dict(baseline=base,candidate=actual) and row['candidate_version']=='0.51.0' and row['baseline_version']==('0.50.0' if phase=='primary' else '0.49.0')
   bench=r/('bench_attention.py' if phase=='primary' else 'bench_attention_legacy.py');assert performance['benchmark_sha256'][phase]==sha(bench)
tape=read('tape-proof.json');assert tape['status']=='success' and tape['source_hashes']==dict(baseline=baseline['source'],candidate=actual)
assert len(tape['results']['candidate']['rows'])==len(tape['results']['baseline']['rows'])==96
for dtype in ['float32','float64']:
 for active,wanted in [(15,2),(4,1)]:
  b=next(v for v in tape['results']['baseline']['rows'] if v['dtype']==dtype and v['dropout_p']==.25 and v['active_mask']==active)
  c=next(v for v in tape['results']['candidate']['rows'] if v['dtype']==dtype and v['dropout_p']==.25 and v['active_mask']==active)
  assert b['unique_score_arrays']==3 and c['unique_score_arrays']==wanted
native=read('integration-proof/native-ci.json');wasm=read('integration-proof/full-wasm-result.json')
assert native['passed'] and native['problems']==78 and native['tests_executed']==10218 and native['duration_s']<=600 and native['repeats']==3 and not native['issues']
assert sum(map(len,native['mutation'].values()))==342 and all(hit for rows in native['mutation'].values() for hit in rows.values())
assert wasm['passed'] and wasm['catalog_modules']==wasm['modules']==78 and not wasm['browser_budget_exceeded']
assert sum(v['mutants'] for v in wasm['results'])==342 and all(v['passed'] and not v['browser_budget_exceeded'] for v in wasm['results'])
contracts=next(v for v in wasm['results'] if v['id']=='architecture/attention')['independent_contracts'];assert contracts['passed']==6184 and len(contracts['suites'])==48
assert {v['suite']:v['source_sha256'] for v in contracts['suites']}==tests
assert contracts['runtime_profiles'][0]['supplemented_files']==[]
assert contracts['runtime_profiles'][1]['supplemented_files']==[dict(name='stridetorch/_legacy.py',source_sha256=actual['_legacy.py'])]
setup=read('integration-proof/setup-receipts.json');front=read('integration-proof/frontend-receipts.json');assert len(setup)==4 and len(front)==5 and all(v['exit_code']==0 for v in setup+front)
exports=read('integration-proof/export-identity.json');snapshot=read('integration-proof/release-snapshot.json')
assert exports['published_assets_unchanged']==11019 and exports['active_assets']==exports['new_assets']==158 and exports['all_new_assets_reachable'];assert snapshot['source_hashes']==actual
assert read('integration-proof/distribution-identity.json')['status']=='success'
live=read('integration-proof/live-expected-sha256.json');assert len(live)==161
for name,digest in live.items():assert sha(repo/'web/public/data'/name)==digest
harness=read('integration-proof/wasm-harness-identity.json');assert sha(repo/harness['file'])==harness['sha256'] and sha(repo/harness['driver_file'])==harness['driver_sha256']
policy=read('release-policy-identity.json');assert policy['status']=='unchanged'
for name,digest in policy['files'].items():assert sha(repo/name)==digest
syncs=read('upstream-syncs.json') if (r/'upstream-syncs.json').exists() else []
for sync in syncs:
 for name,digest in sync['paths'].items():
  assert hashlib.sha256(subprocess.check_output(['git','show',sync['after']+':'+name],cwd=repo)).hexdigest()==digest and sha(repo/name)==digest
 assert len(read(sync['receipts']))==5 and all(v['exit_code']==0 for v in read(sync['receipts']))
changed={name for name,digest in baseline['source'].items() if actual.get(name)!=digest};assert changed=={'__init__.py','_attention.py'} and set(actual)==set(baseline['source'])
sizes={}
for label,directory,hashes in [('baseline',r/'baseline-source/stridetorch',baseline['source']),('candidate',source,actual)]:
 raw=b''.join((directory/name).read_bytes() for name in sorted(hashes));sizes[label]=dict(raw_source_license_bytes=len(raw),local_concatenated_gzip_bytes=len(gzip.compress(raw,mtime=0)))
sizes['scope']='Sorted source/license concatenation and local gzip estimate; not network transfer,wheel size,RSS or GPU data.'
metadata=r/'package-metadata';metadata.mkdir(exist_ok=True)
for name in ('README.md','pyproject.toml','LICENSE','NOTICE'):shutil.copy2(repo/'packages/stridetorch'/name,metadata/name)
shutil.copy2(repo/'packages/stridetorch/tests/test_standalone.py',metadata/'test_standalone.py');shutil.copy2(repo/'tests/test_browser_autograd.py',metadata/'test_browser_autograd.py')
archives={}
for name,folder,excluded in [('iteration-51-harness.tar.gz',r,{'integration-proof','proof','performance'}),('iteration-51-integration-harness.tar.gz',r/'integration-proof',{'dist-paperleet','live-expected'}),('iteration-51-runtime-harness.tar.gz',r/'proof',set()),('iteration-51-performance-harness.tar.gz',r/'performance',set())]:
 target=out/name
 with tarfile.open(target,'w:gz') as archive:
  for current,dirs,names in os.walk(folder):
   dirs[:]=[d for d in dirs if d not in ('__pycache__','.pytest_cache') and not d.endswith(('-env','-venv')) and not (Path(current)==folder and d in excluded)]
   for name0 in sorted(names):
    path=Path(current)/name0
    if not path.is_symlink() and (path.name in ('LICENSE','NOTICE') or path.suffix in ('.py','.mjs','.json','.log','.md','.html','.toml','.npz','.txt')):archive.add(path,arcname=str(path.relative_to(folder)),recursive=False)
 archives[name]=dict(sha256=sha(target),bytes=target.stat().st_size)
report=dict(status='validated_locally',version='0.51.0',source_hashes=actual,baseline=baseline,unchanged_resources=53,changed_resources=sorted(changed),added_resources=[],full_cpu=full,new_attention_tests=131,attention_tests=161,focused_attention_tests=292,node_wasm=node,chrome_worker=chrome,minimal_wheel=wheel,coinstall=coinstall,native_differential=numeric,official_sdpa_oracle=oracle,native_training=training,native_scaling=scaling,frozen_native_oracles=reused_oracles,tape=tape,legacy_baseline=legacy,performance=performance,source_footprint=sizes,release_policy=policy,upstream_syncs=syncs,raw_archives=archives,metadata_recheck=read('proof/metadata-recheck-receipts.json'))
integration=dict(status='validated_locally',version='0.51.0',native=native,wasm=wasm,frontend=front,setup=setup,export_identity=exports,release_snapshot=snapshot,live_export_sha256=live,source_hashes=actual,distribution=read('integration-proof/distribution-identity.json'),wasm_harness=harness,runtime_sizes=read('integration-proof/runtime-sizes.json'),native_reference_reuse=read('integration-proof/native-reference-reuse.json'),upstream_syncs=syncs)
save(out/'iteration-51.json',report);save(out/'iteration-51-integration.json',integration)
save(r/'state.json',dict(status='local_gates_passed',version='0.51.0',source_hashes=actual,export_sha256=live,all_owned_children_terminal=True,main_adoption_pending=True))
print('PASS0.51 exact local proof:55resources,6184Node/Chrome,39813CPU,6197minimum,204cases/2592arrays,200native-training arrays,78/342catalog,40primary+22legacy flows x24children',flush=True)
