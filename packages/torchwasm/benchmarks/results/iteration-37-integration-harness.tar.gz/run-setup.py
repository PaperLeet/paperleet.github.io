from pathlib import Path
import json,subprocess,time
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');py=r.parent.parent/'torch-iteration-21/stride-dev-env/bin/python';receipts=[]
for script in ('run-export.py','freeze.py','verify-private.py','run-frontend.py'):
 start=time.monotonic()
 with (r/(script.removesuffix('.py')+'-runner.log')).open('w') as log:p=subprocess.run([str(py),str(r/script)],cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(script=script,exit_code=p.returncode,elapsed_s=time.monotonic()-start));(r/'setup-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(script,'terminal',p.returncode,flush=True);p.check_returncode()
