from pathlib import Path
import hashlib,json,os,statistics,subprocess,time
p=Path(__file__).resolve().parent;out=p/'performance';out.mkdir(exist_ok=True)
base=[dict(name='paperleet_attention_score_head',shape=[4,5,6],kind='matmul'),dict(name='attention_score_128',shape=[128,64,128],kind='matmul'),
      dict(name='dense_256',shape=[256,256,256],kind='matmul'),dict(name='dense_512',shape=[512,512,512],kind='matmul'),
      dict(name='resident_mlp_chain',shape=[128,64,32],last=16,kind='chain'),dict(name='linear_vjp',shape=[128,64,32],kind='vjp')]
cases=[dict(case,name=case['name']+'_'+mode,mode=mode) for case in base for mode in ['roundtrip','resident']]
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
files=['gpu-service.mjs','plan-program.mjs','rpc-client.mjs','matrix_client.py','qualify.py','benchmark.py','run-browser.mjs','run-performance.py','native-oracle.npz','native-oracle.json']
source={name:sha(p/name) for name in files};qualification=json.loads((p/'browser-result.json').read_text())
assert qualification['status']=='passed' and qualification['numerical']['program_executions']==108
for name,digest in qualification['source_sha256'].items():assert source[name]==digest
(out/'plan.json').write_text(json.dumps(dict(cases=cases,fresh_cycles=6,fresh_children=72,source_sha256=source,preceding_qualification_sha256=sha(p/'browser-result.json'),scope='Sequential latency only; no overlapping qualification, allocation or archive jobs. Four balanced profiles with sequential GPU A/A, bounded program, NumPy context and under-target batch disclosure.'),indent=2)+'\n')
receipts=[]
for cycle in range(6):
    order=cases[cycle:]+cases[:cycle]
    if cycle%2:order=list(reversed(order))
    for case in order:
        for name,digest in source.items():assert sha(p/name)==digest
        name=case['name']+'-'+str(cycle);start=time.monotonic()
        with (out/(name+'.log')).open('w') as log:
            child=subprocess.run(['/opt/homebrew/bin/node',str(p/'run-browser.mjs')],cwd=p,env={**os.environ,'GPU_BENCHMARK_CASE':json.dumps(case),'GPU_BENCHMARK_CYCLE':str(cycle)},stdout=log,stderr=subprocess.STDOUT)
        receipts.append(dict(case=case['name'],cycle=cycle,exit_code=child.returncode,seconds=time.monotonic()-start,log_sha256=sha(out/(name+'.log'))))
        (out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');child.check_returncode()
        result=json.loads((out/'results'/(name+'.json')).read_text());assert result['status']==result['benchmark']['status']=='passed'
        for key,digest in result['source_sha256'].items():assert source[key]==digest
        print(name,'TERMINAL0',json.dumps(result['benchmark']['ratios']),flush=True)
rows=[]
for case in cases:
    values=[json.loads((out/'results'/(case['name']+'-'+str(cycle)+'.json')).read_text())['benchmark'] for cycle in range(6)]
    keys=['duplicate_over_sequential','program_over_sequential','program_over_duplicate','program_over_cpu']
    rows.append(dict(case=case,medians={label:statistics.median(value['median_seconds'][label] for value in values) for label in ['sequential','duplicate','program','cpu']},
                     ratios={key:statistics.median(value['ratios'][key] for value in values) for key in keys},all_ratios=[value['ratios'] for value in values],
                     undersized_batches=sum(len(value['undersized_batches']) for value in values)))
(out/'summary.json').write_text(json.dumps(dict(status='completed',fresh_children=72,source_sha256=source,rows=rows,receipts=receipts,
    scope='Six fresh Chrome/Pyodide/device processes per12explicit workflow/profile combinations. Same candidate engine sequential A/A versus bounded program; not a released torch API/native CPU or universal crossover claim.'),indent=2)+'\n')
print('ALL72 FRESH SEQUENTIAL/PROGRAM GPU CHILDREN TERMINAL0',flush=True)
