"""Explicit NumPy/GPU matrix programs, including transfers and Python RPC costs."""
import contextlib,itertools,json,statistics,time
import numpy as np
from pyodide.ffi import run_sync

case=json.loads(_benchmark_case_json)
cycle=int(_benchmark_cycle)
rng=np.random.default_rng(7410)
m,k,n=case['shape']
a=rng.normal(0,.3,(m,k)).astype('float32')
b=rng.normal(0,.3,(k,n)).astype('float32')
kind=case['kind']
extra=rng.normal(0,.3,(n,case.get('last',n)) if kind=='chain' else (m,n)).astype('float32')
inputs=[a,b]+([extra] if kind in ['chain','vjp'] else [])
original=[value.copy() for value in inputs]

def numpy_program(values):
    a,b=values[:2]
    if kind=='chain':return (a@b@values[2],)
    if kind=='vjp':return (a@b,values[2]@b.T,a.T@values[2])
    return (a@b,)

def gpu_program(values):
    a,b=values[:2]
    with contextlib.ExitStack() as stack:
        y=stack.enter_context(a.matmul(b))
        if kind=='chain':return (stack.enter_context(y.matmul(values[2])).numpy(),)
        if kind=='vjp':
            ga=stack.enter_context(values[2].matmul(b,False,True))
            gb=stack.enter_context(a.matmul(values[2],True,False))
            return (y.numpy(),ga.numpy(),gb.numpy())
        return (y.numpy(),)

def cpu_factory():
    def operation():return numpy_program(inputs)
    return operation

def roundtrip():
    with contextlib.ExitStack() as stack:
        values=[stack.enter_context(Matrix.upload(value)) for value in inputs]
        return gpu_program(values)

with contextlib.ExitStack() as resident_scope:
    resident=[resident_scope.enter_context(Matrix.upload(value)) for value in inputs]
    functions=dict(cpu=cpu_factory(),duplicate=cpu_factory(),roundtrip=roundtrip,resident=lambda:gpu_program(resident))
    references=numpy_program([value.astype('float64') for value in inputs])
    errors={}
    for label,operation in functions.items():
        actual=operation();assert len(actual)==len(references)
        for value,reference in zip(actual,references):
            assert value.dtype==np.float32
            np.testing.assert_allclose(value,reference,rtol=1e-4,atol=5e-4)
        errors[label]=max(float(np.max(np.abs(value-reference),initial=0)) for value,reference in zip(actual,references))
        for _ in range(3):operation()
    for value,expected in zip(inputs,original):np.testing.assert_array_equal(value,expected)
    gc_before=run_sync(matrix_rpc.stats()).resident_handles
    assert gc_before==len(inputs)
    def measure(operation,count):
        start=time.perf_counter()
        for _ in range(count):operation()
        return time.perf_counter()-start
    target=.02
    counts={};calibration=[]
    max_gpu=8 if kind=='vjp' else 16 if kind=='chain' else 32
    for label in ['cpu','duplicate','roundtrip','resident'][cycle%4:]+['cpu','duplicate','roundtrip','resident'][:cycle%4]:
        count=1;maximum=(1<<20) if label in ['cpu','duplicate'] else max_gpu
        while True:
            elapsed=measure(functions[label],count)
            calibration.append(dict(label=label,count=count,seconds=elapsed))
            if elapsed>=target or count==maximum:break
            count=min(count*2,maximum)
        counts[label]=count
    # Match the work count for the identical CPU controls after calibration.
    counts['cpu']=counts['duplicate']=max(counts['cpu'],counts['duplicate'])
    design=[['cpu','duplicate','resident','roundtrip'],['duplicate','roundtrip','cpu','resident'],
            ['roundtrip','resident','duplicate','cpu'],['resident','cpu','roundtrip','duplicate']]
    design+= [list(reversed(order)) for order in design]
    design=design[cycle%8:]+design[:cycle%8]
    samples={label:[] for label in functions};batches=[]
    for order in design:
        batch={}
        for label in order:
            elapsed=measure(functions[label],counts[label]);batch[label]=dict(count=counts[label],seconds=elapsed)
            samples[label].append(elapsed/counts[label])
        batches.append(dict(order=order,results=batch))
    for value,expected in zip(inputs,original):np.testing.assert_array_equal(value,expected)
    assert run_sync(matrix_rpc.stats()).resident_handles==len(inputs)
    medians={label:statistics.median(values) for label,values in samples.items()}
    undersized=[dict(batch=i,label=label,seconds=value['seconds']) for i,batch in enumerate(batches) for label,value in batch['results'].items() if value['seconds']<target]
stats=run_sync(matrix_rpc.stats())
assert stats.resident_handles==stats.total_bytes==0
json.dumps(dict(status='passed',case=case,cycle=cycle,target_batch_seconds=target,batches=batches,
                counts=counts,calibration=calibration,median_seconds=medians,
                ratios={label+'_over_cpu':medians[label]/medians['cpu'] for label in ['duplicate','roundtrip','resident']},
                undersized_batches=undersized,preflight_max_abs_error=errors,final_stats=stats.to_py(),
                scope='Explicit float32 NumPy matrix programs versus GPU primitives; same mathematical results, CPU A/A control and full per-call Python/RPC/dispatch/readback costs. Resident excludes one-time input upload, which roundtrip includes. Not a torch API/autograd or native CPU benchmark. Batches below target remain disclosed.'))
