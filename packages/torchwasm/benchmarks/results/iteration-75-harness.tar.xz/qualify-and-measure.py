from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent;p=r/'webgpu-rpc'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
receipts=[]
checks=[('legacy-protocol',['/opt/homebrew/bin/node',str(p/'check-protocol.mjs')]),('program-unit',['/opt/homebrew/bin/node',str(p/'check-program.mjs')]),('real-lifecycle',['/opt/homebrew/bin/node',str(p/'check-real-lifecycle.mjs')])]
for label,args in checks:
    start=time.monotonic()
    with (p/(label+'-receipt.log')).open('w') as log:
        child=subprocess.run(args,cwd=p,env={**os.environ,'GPU_PROTOCOL_RESULT':str(r/'legacy-protocol-result.json')},stdout=log,stderr=subprocess.STDOUT)
    receipts.append(dict(label=label,args=args,exit_code=child.returncode,seconds=time.monotonic()-start,log_sha256=sha(p/(label+'-receipt.log'))))
    (r/'qualification-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');child.check_returncode();print(label,'TERMINAL0',flush=True)
proof=json.loads((p/'browser-result.json').read_text());assert proof['status']=='passed' and proof['numerical']['program_executions']==108 and len(proof['program_boundaries'])==4
for name,digest in proof['source_sha256'].items():assert sha(p/name)==digest
for q in [r/'legacy-protocol-result.json',p/'program-unit-result.json',p/'real-lifecycle-result.json']:
    proof=json.loads(q.read_text());assert proof['status']=='passed'
    for name,digest in proof['source_sha256'].items():assert sha(p/name)==digest
print('ALL QUALIFICATION CHILDREN TERMINAL0; STARTING SEQUENTIAL LATENCY ONLY',flush=True)
subprocess.run([os.sys.executable,'-B',str(p/'run-performance.py')],cwd=p,check=True)
