import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-runtime/pyodide-0.29.4/pyodide.mjs';
const py=await loadPyodide({indexURL:'/Users/david/Developer/PaperLeet-torch-release/web/public/browser-runtime/pyodide-0.29.4/',stdout(){},stderr(){}});await py.loadPackage('numpy');
const value=py.runPython(`import gc,weakref,numpy as np
from pyodide.ffi import to_js
from js import Object
def inspect():
    root=np.ones((3,4),dtype=np.float32)
    ref=weakref.ref(root)
    values=[dict(rows=3,cols=4,data=np.ascontiguousarray(root).reshape(-1))]
    converted=to_js(values,dict_converter=Object.fromEntries)
    return ref,converted
ref,converted=inspect()
gc.collect()
root_alive=ref() is not None
converted`);
const result={status:'observed',pyodide:py.version,numpy:py.runPython('np.__version__'),array:Array.isArray(value),dtype:value[0].data?.constructor?.name,pyproxy_created:typeof value[0].data?.toJs==='function',python_root_alive_after_conversion:py.runPython('root_alive'),values:Array.from(value[0].data),script_sha256:createHash('sha256').update(fs.readFileSync(new URL(import.meta.url))).digest('hex'),scope:'One direct observation of the actual nested ndarray to_js conversion schema used by MatrixProgram. No GPU/RSS/general heap-growth claim.'};
if(!result.array||result.dtype!=='Float32Array'||result.pyproxy_created)throw Error(JSON.stringify(result));
fs.writeFileSync(new URL('./conversion-observation.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
