from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,tarfile
p=Path(__file__).resolve().parent;r=p.parent;raw=r/'webgpu-rpc';repo=Path('/Users/david/Developer/PaperLeet-torch-release')
read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();save=lambda q,d:q.write_text(json.dumps(d,indent=2)+'\n')
context=read(p/'context.json');formal=read(raw/'performance/summary.json');qual=read(raw/'browser-result.json');review=read(p/'performance-reviewed.json')
assert formal['status']=='completed' and formal['fresh_children']==72 and all(v['exit_code']==0 for v in formal['receipts'])
assert review['proceed_local_validation'] and review['performance_sha256']==sha(raw/'performance/summary.json')
assert qual['status']=='passed' and qual['numerical']['program_executions']==108 and len(qual['program_boundaries'])==4
for proof in [formal,qual,read(raw/'program-unit-result.json'),read(raw/'real-lifecycle-result.json'),read(r/'legacy-protocol-result.json')]:
    for name,digest in proof['source_sha256'].items():assert sha(raw/name)==digest
for name,digest in context['runtime_source_hashes'].items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==digest
for name,digest in read(p/'copied-source-sha256.json').items():assert sha(repo/name)==digest
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==context['upstream']
policy=read(p/'release-policy-identity.json')
for group in [policy['files'],policy['workflows']]:
    for name,digest in group.items():assert sha(repo/name)==digest
for name,digest in read(p/'live-export-sha256.json').items():assert sha(repo/'web/public/data'/name)==digest
equivalence=read(p/'upstream-equivalence.json');assert equivalence==context['upstream_equivalence']
for name,digest in equivalence['executed_runtime_asset_sha256'].items():
    assert sha(repo/'web/public/browser-runtime/pyodide-0.29.4'/name)==digest
for item in qual['requests']:
    if item['path'].startswith('/runtime/') and 'sha256' in item:assert equivalence['executed_runtime_asset_sha256'][item['path'].removeprefix('/runtime/')]==item['sha256']
checks={}
for name in ['package-check','wheel-check']:
    receipt=read(p/(name+'-receipt.json'));assert receipt['exit_code']==0 and sha(p/(name+'.log'))==receipt['log_sha256']
    counts=re.findall(r'(\d+) passed',(p/(name+'.log')).read_text());assert len(counts)==1;checks[name]=dict(receipt,passed=int(counts[0]),executed_on_upstream=context['original_qualified_upstream'])
protocol=read(p/'protocol-main-result.json');unit=read(p/'program-main-result.json')
for proof,cases in [(protocol,9),(unit,40)]:
    assert proof['status']=='passed' and proof['cases']==cases
    for name,digest in proof['source_sha256'].items():assert sha(repo/'packages/stridetorch/benchmarks/webgpu_rpc'/name)==digest
minimum={};under=0
for q in sorted((raw/'performance/results').glob('*.json')):
    result=read(q);assert result['status']==result['benchmark']['status']=='passed' and result['measurement_request_quota']==32768
    assert all(row['stats']['total_bytes']==0 and row['stats']['closed'] for row in result['host_disposals'])
    for name,digest in result['source_sha256'].items():assert sha(raw/name)==digest
    for batch in result['benchmark']['batches']:
        for label,value in batch['results'].items():minimum[label]=min(minimum.get(label,float('inf')),value['seconds']);under+=value['seconds']<.02
assert under==3
owned={};published=p/'published-inputs';published.mkdir()
for q in sorted((repo/'packages/stridetorch/benchmarks/webgpu_rpc').iterdir()):
    assert q.is_file();shutil.copy2(q,published/q.name);owned[str(q.relative_to(repo))]=sha(q)
assert len(owned)==7;save(p/'owned-input-sha256.json',owned)
state=read(r/'state.json');state.update(status='all_bounded_program_checks_passed',active_processes=[],main_modified=True,main_adopted=False,goal_status='active',last_goal_turn_classification='progress')
for name in ['state.json','continuation-latest.json']:save(r/name,state)
out=repo/'packages/stridetorch/benchmarks/results';archive=out/'iteration-75-harness.tar.xz';assert not archive.exists()
excluded={'package-check-tmp','wheel-check-tmp','__pycache__','.pytest_cache','.git','node_modules','build','dist'}
allowed={'.py','.mjs','.json','.log','.md','.npz','.toml','.txt','.cjs'};seen={};payloads={};logical=0;links=0
with tarfile.open(archive,'w:xz',preset=6) as target:
    for current,dirs,files in os.walk(r):
        dirs[:]=sorted(name for name in dirs if name not in excluded and not name.endswith(('-env','-venv','.egg-info')))
        for name in sorted(files):
            q=Path(current)/name
            # Keep the full Node loader failure locally; publish its compact
            # diagnostic, not an unnecessary complete third-party minified line.
            if q.is_symlink() or q.suffix not in allowed or q.name=='inspect-conversions-failure.log':continue
            arc=str(q.relative_to(r));digest=sha(q);payloads[arc]=digest;info=target.gettarinfo(str(q),arcname=arc);logical+=q.stat().st_size
            key=(digest,info.mode,info.uid,info.gid,info.uname,info.gname)
            if key in seen:info.type=tarfile.LNKTYPE;info.linkname=seen[key];info.size=0;target.addfile(info);links+=1
            else:
                seen[key]=arc
                with q.open('rb') as data:target.addfile(info,data)
with tarfile.open(archive,'r:xz') as target:
    assert len(target.getmembers())==len(payloads)
    for member in target.getmembers():assert hashlib.sha256(target.extractfile(member).read()).hexdigest()==payloads[member.name]
identity=dict(name=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,files=len(payloads),unique_payloads=len(seen),hardlinks=links,logical_bytes=logical,all_logical_payloads_verified=True,excluded_local_diagnostic='inspect-conversions-failure.log')
save(p/'archive-identity.json',identity)
first=read(r/'first-72-short-batches/performance/summary.json')
report=dict(status='validated_experimental_bounded_program',iteration=75,supported_library_version='0.73.0',upstream=context['upstream'],original_qualified_upstream=context['original_qualified_upstream'],
            supported_runtime_changed=False,production_judge_changed=False,gpu_torch_device_enabled=False,runtime_source_hashes=context['runtime_source_hashes'],published_inputs=owned,
            opaque_gpu_qualification=qual,deterministic_protocol=protocol,program_failure_injection=unit,additional_real_device_lifecycle=read(raw/'real-lifecycle-result.json'),
            legacy_body_identity=read(r/'legacy-body-identity.json'),performance=formal,initial_short_batch_performance=first,performance_review=review,
            long_batch_minimum_seconds=minimum,under_target_batches=under,total_batches=2304,trusted_measurement_request_quota=32768,default_service_request_quota=4096,
            local_checks=checks,upstream_equivalence=equivalence,raw_archive=identity,release_policies=policy,
            limitations=['Experimental explicit float32 2D matrix/VJP programs only;no automatic torch/autograd,production judge async integration or GPU default routing.',
                         'All timings use the same candidate engine;the unchanged shader and legacy primitive bodies do not establish released-version/native CPU/public torch API latency equivalence.',
                         'Six fresh processes per12workflow/profile combinations on one Chrome155/AppleMetal3 device. Individual A/A variation remains0.7839–1.1136;dense512 improvements are modest/variable,not universal.',
                         'Three of2304long batches are below20ms. First72children with503short batches are preserved separately,not relabeled.',
                         'Only a trusted measurement host raises session request quota to32768. Default4096 and memory/work/handle/pending/lease limits remain unchanged.',
                         'Tracked buffers/destruction are not physical VRAM or preemptive GPU cancellation;MessagePort/browser/driver resources do not provide hard tenant DoS isolation.'])
save(out/'iteration-75.json',report)
table=[]
for row in formal['rows']:
    a=row['ratios'];t=row['medians'];table.append(f"| {row['case']['name']} | {a['duplicate_over_sequential']:.4f} | {a['program_over_sequential']:.4f} | {a['program_over_duplicate']:.4f} | {a['program_over_cpu']:.4f} | {t['sequential']*1e6:.2f} → {t['program']*1e6:.2f} |")
text=f'''# Torch runtime iteration 75: bounded WebGPU matrix programs

The stable library remains **0.73.0**, with its CPU/NumPy/WASM backend. This
iteration extends the experimental host-Worker matrix service; no public torch
GPU device, automatic autograd, import alias or production judge is enabled.

`MatrixProgram` submits a bounded DAG of fixed matmul operations in one request.
Inputs may be copied float32 NumPy arrays or same-session resident matrices.
One command submission contains the compute passes and final packed readback.
Requested outputs may be read, retained, or both; intermediate buffers are
released and retained outputs close through an atomic `release_many` request.
The [portable sources and examples](../../packages/stridetorch/benchmarks/webgpu_rpc/README.md)
have no PaperLeet imports.

## Validation and failure handling

The host validates every reference/shape/flag, aggregate compute work, published
handle count and peak byte requirement before GPU allocation. Default limits
remain 32 MiB tracked GPU bytes, 24 resident handles, eight pending requests,
4096 requests and a 120-second lease. Programs accept at most eight inputs,
eight matmul nodes and eight distinct computed outputs. The 268,435,456 MAC
limit applies to all nodes together; uploads, temporary values, per-node uniforms
and packed readback count toward the same byte budget.

An early review found that queue writes may precede a later encoding/mapping
failure. Program rollback now drains pending work before freeing tracked
resources; a failed drain invalidates the device. Preflight rejections preserve
existing resident handles. Cancellation skips queued requests or discards all
new retained outputs after completion, rather than preempting GPU kernels.
The original source and its narrower legacy evidence are retained. A first test
expectation incorrectly required a second queue fence after successful mapping;
its failure/source are also retained, with the corrected map-completion check.

* 36 original native Torch 2.6.0 and independent float64 matrix/VJP fixtures,
  each executed with ephemeral uploads, retained outputs and resident inputs:
  **108 program executions**, not 108 distinct native fixtures. All four
  transpose combinations and nine irregular/tile-boundary shapes retain
  `rtol=1e-4`, `atol=5e-4`. Every program execution adds one submission.
* Legacy 36 native fixtures and 13 real boundary rows still pass. Four additional
  real program checks cover aggregate work/byte rejection, two-output
  cancellation recovery and separate packed/read/retained snapshots for three
  large outputs. Both real cancellation attempts in this run were acknowledged
  and their new retained outputs reclaimed.
* 40 actual planner/engine/RPC fault-injection tests using a fake GPU surface,
  plus nine legacy protocol tests. These test allocation/encoding/submission/
  mapping/read/scope failures, drain failure, full-budget preflight, atomic
  release and multi-output cancellation; they do not execute a shader.
* Four additional real GPU lifecycle checks retain the iteration-74 scope:
  startup disposal, resident-handle invalidation, short trusted lease recovery
  and explicit device destruction to exercise device-lost handling. They do not
  simulate hardware crashes or run their clients in the opaque Python Worker.
* The repository copies pass **{checks['package-check']['passed']} namespace/feature tests** and
  **{checks['wheel-check']['passed']} built-wheel/ownership/install tests**. The stable runtime's
  61 resources and live exports are unchanged. The 42,477/full-catalog/frontend
  gates from iteration 73 are not rerun or presented as new program checks.

The real numerical path remains an opaque-origin `sandbox="allow-scripts"`
iframe/Worker, without direct GPU access, connected to an owned secure host
Worker. Unmodified headless Chrome 155.0.8059.82/Apple Metal3 uses no extra flags.
All successful sessions finish with zero tracked allocations/handles; this is
API accounting/destruction evidence, not physical VRAM reclaim. The actual
nested ndarray conversion produces `Float32Array`, no PyProxy, and permits the
sample Python source allocation to be collected; this is one schema observation,
not a general heap/RSS benchmark. A Node ESM loader inspection failed before
conversion, so the observation was made in the real Chrome fixture. Its compact
diagnostic is archived; the full minified-line log stays local.

## Sequential requests versus one program

Both GPU sides use the **same candidate engine** and unchanged WGSL/legacy
primitive bodies. A and A′ are identical sequential callables; B builds/runs
one program for the same mathematical outputs. NumPy/WASM is a separate context
baseline. Roundtrip profiles include input conversion/upload and all output
readback/release. Resident profiles exclude one-time input uploads on both GPU
sides. Program construction and Python/RPC costs remain timed. Adapter/pipeline/
interpreter initialization is excluded. These are explicit matrix programs,
not public torch/autograd/native-CPU or complete attention/training comparisons.

Six workflows × two transfer profiles × six fresh Chrome/Pyodide/device
processes give **72 children**, each with eight balanced batches of four paths.
The initial 72-child run retained 503/2304 batches below20ms. A second run uses
40ms calibration and longer iteration caps: **3/2304** batches remain below20ms,
with minimum sequential/A′/program/NumPy batches
{minimum['sequential']*1000:.1f}/{minimum['duplicate']*1000:.1f}/{minimum['program']*1000:.1f}/{minimum['cpu']*1000:.1f}ms.
For this long sampling only, trusted host code raises the **request count** to
32768. Default4096 and GPU byte/work/handle/pending/lease limits are unchanged;
untrusted clients cannot change limits. Actual served runtime assets have six
consistent hashes across all measured children; NumPy is 2.2.5/Pyodide0.29.4.

Ratios are medians of six per-process ratios. Descriptive microsecond medians
are aggregated separately and need not reproduce those ratios.

| Program/profile | A′/A | B/A | B/A′ | B/NumPy | A → B μs |
| --- | --- | --- | --- | --- | --- |
{chr(10).join(table)}

The matrix VJP includes the output and two explicit analytical matrix products;
the chain contains two products without activation. Relative to sequential GPU
calls, these multi-operation profiles show clear benefits against both A/A
denominators. They remain slower than NumPy for these small fixtures. Dense512
gains are smaller/variable: resident A/A median0.9112 and individual A/A range
0.7839–1.1136 across profiles caution against a precise universal gain. The first
wave is preserved, and no automatic routing threshold is selected. Default
CPU/WASM execution remains appropriate while GPU storage/autograd and real
judge async/budget/cancellation integration are developed.

## Reproduction and scope

The [WebGPU encoder documentation](https://developer.mozilla.org/en-US/docs/Web/API/GPUCommandEncoder)
describes collecting multiple commands into a submitted command buffer.
The [buffer-copy requirements](https://developer.mozilla.org/en-US/docs/Web/API/GPUCommandEncoder/copyBufferToBuffer)
apply to the packed readback offsets/sizes. Cancellation and device destruction
do not establish preemption. Transport queues and browser/driver resources lack
a hard tenant memory/DoS guarantee. Float64/complex/special values,
batched/broadcast/empty tensors, automatic torch AD and a supported GPU backend
remain future work; large graphs may need partitioning to respect budgets.

Namespace/wheel checks and original qualification executed on
`{context['original_qualified_upstream']}`. Main then advanced through 28 frontend/docs
files to `{context['upstream']}`. Those updates were retained with a fast-forward;
runtime/Python/test/package/dependency/judge inputs and measured runtime assets
are unchanged. This is explicit source-equivalence, not a claim of re-execution
on the newer SHA or updated frontend testing for a benchmark-only change.

Machine report: `packages/stridetorch/benchmarks/results/iteration-75.json`.
Raw harness `{identity['name']}`: {identity['bytes']:,} bytes,
SHA-256 `{identity['sha256']}`; {identity['files']} logical files,
{identity['unique_payloads']} mode/ownership-compatible payloads,
{identity['hardlinks']} hardlinks; every logical extracted payload verified.
It preserves prototypes, test failures, both timing waves and receipts, with
historical absolute paths/dependency setup required. Remote integration is
verified separately. No CI, tag, package release or deployment is requested.
'''
(repo/'docs/validation/torch-runtime-iteration-75.md').write_text(text)
save(p/'local-report-identity.json',dict(report_sha256=sha(out/'iteration-75.json'),doc_sha256=sha(repo/'docs/validation/torch-runtime-iteration-75.md'),archive=identity,owned_inputs=owned))
print(json.dumps(dict(status=report['status'],program_executions=108,unit_cases=40,latency_children=72,under_target_batches=under,archive=identity)),flush=True)
