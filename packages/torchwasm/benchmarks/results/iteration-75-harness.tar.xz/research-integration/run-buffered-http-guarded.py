"""Reuse the successful native HTTPS buffering settings with the mandatory guard."""
from pathlib import Path
import json
import os
import subprocess
import sys

p = Path(__file__).resolve().parent
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
kind = sys.argv[1]
assert kind in ['adoption', 'proof']
config = {'http.postBuffer': '67108864', 'http.lowSpeedTime': '30', 'http.lowSpeedLimit': '1'}
env = dict(os.environ)
count = int(env.get('GIT_CONFIG_COUNT', '0'))
for offset, (key, value) in enumerate(config.items()):
    env[f'GIT_CONFIG_KEY_{count+offset}'] = key
    env[f'GIT_CONFIG_VALUE_{count+offset}'] = value
env['GIT_CONFIG_COUNT'] = str(count + len(config))
env['GIT_TERMINAL_PROMPT'] = '0'
record = dict(kind=kind, scoped_git_config=config, no_global_config_changes=True,
              mandatory_wrapper_unchanged=True,
              scope='Native ordinary no-tag HEAD:main push after fresh checked audit and clean-worktree '
                    'check in the mandatory iteration67 wrapper. Seekable request buffering addresses '
                    'observed non-rewindable POST errors; idle failure timeout bounds transport waits.')
(p / (kind + '-buffered-HTTP-transport.json')).write_text(json.dumps(record, indent=2) + '\n')
subprocess.run([sys.executable, str(p / 'run-guarded-push.py'), kind], cwd=repo, env=env, check=True)
