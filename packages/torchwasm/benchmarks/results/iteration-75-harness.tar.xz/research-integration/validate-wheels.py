from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
python=p.parent.parent/'torch-iteration-69/integration-dev-env/bin/python'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
core=json.loads((p/'context.json').read_text())['runtime_source_hashes']
for name,digest in core.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==digest
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=os.pathsep.join([str(repo/'packages/stridetorch/src'),str(repo)]),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
args=[str(python),'-B','-m','pytest','tests/test_lightweight_torch.py','-q','-p','no:cacheprovider','--basetemp',str(p/'wheel-check-tmp')]
start=time.monotonic()
with (p/'wheel-check.log').open('w') as log:child=subprocess.run(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt=dict(exit_code=child.returncode,seconds=time.monotonic()-start,args=args,cwd=str(repo),log_sha256=sha(p/'wheel-check.log'),summary=(p/'wheel-check.log').read_text().splitlines()[-1:])
(p/'wheel-check-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');child.check_returncode()
for name,digest in core.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==digest
print(json.dumps(receipt),flush=True)
