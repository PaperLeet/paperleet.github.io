from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
python=p.parent.parent/'torch-iteration-69/integration-dev-env/bin/python'
read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
context=read(p/'context.json');core=context['runtime_source_hashes']
for name,digest in core.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==digest
protocol=read(p/'protocol-main-result.json');assert protocol['status']=='passed' and protocol['cases']==9
for name,digest in protocol['source_sha256'].items():assert sha(repo/'packages/stridetorch/benchmarks/webgpu_rpc'/name)==digest
program=read(p/'program-main-result.json');assert program['status']=='passed' and program['cases']==40
for name,digest in program['source_sha256'].items():assert sha(repo/'packages/stridetorch/benchmarks/webgpu_rpc'/name)==digest
for name,digest in read(p/'copied-source-sha256.json').items():assert sha(repo/name)==digest
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==context['upstream']
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=os.pathsep.join([str(repo/'packages/stridetorch/src'),str(repo)]),
         OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
args=[str(python),'-B','-m','pytest','packages/stridetorch/tests/test_standalone.py','packages/stridetorch/tests/test_feature_detection.py',
      '-q','-p','no:cacheprovider','--basetemp',str(p/'package-check-tmp')]
start=time.monotonic()
with (p/'package-check.log').open('w') as log:child=subprocess.run(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt=dict(exit_code=child.returncode,seconds=time.monotonic()-start,args=args,cwd=str(repo),log_sha256=sha(p/'package-check.log'),summary=(p/'package-check.log').read_text().splitlines()[-1:])
(p/'package-check-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');child.check_returncode()
for name,digest in core.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==digest
for name,digest in read(p/'copied-source-sha256.json').items():assert sha(repo/name)==digest
print(json.dumps(receipt),flush=True)
