import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {loadPyodide} from './runtime/pyodide.mjs';
async function main(){
 const root=new URL('./',import.meta.url),plan=JSON.parse(fs.readFileSync(new URL('qualification-plan.json',root))),cycle=Number(process.argv[2]);
 const py=await loadPyodide({indexURL:new URL('runtime/',root).pathname,stdout(){},stderr(){}});await py.loadPackage('numpy');
 for(const [name,digest] of Object.entries(plan.files)){
  if(name==='oracle.npz')continue;
  const bytes=fs.readFileSync(new URL(name,root));assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),digest,name);
  py.FS.mkdirTree('/'+name.split('/').slice(0,-1).join('/'));py.FS.writeFile('/'+name,bytes);
 }
 py.globals.set('cycle',cycle);
 const result=JSON.parse(py.runPython("import sys,json\nsys.path.insert(0,'/')\nfrom benchmark import run_benchmark\njson.dumps(run_benchmark(cycle))"));
 fs.writeFileSync(new URL('latency-node-'+cycle+'.json',root),JSON.stringify({runtime:process.version,pyodide:py.version,...result},null,2)+'\n');
 console.log(JSON.stringify({status:'passed',cycle,rows:result.rows.length}));
}
main().catch(error=>{console.error(String(error));process.exitCode=1;});
