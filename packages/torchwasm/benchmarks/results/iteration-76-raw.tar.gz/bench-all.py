from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path(__file__).resolve().parent
node='/opt/homebrew/bin/node'
python='/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-69/integration-dev-env/bin/python'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
plan=json.loads((root/'qualification-plan.json').read_text())
def verify():
    for name,digest in plan['files'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
receipts=[]
for cycle in range(4):
    for runtime,args in [('node',[node,'bench-node.mjs',str(cycle)]),
                         ('chrome',[node,'bench-chrome.mjs',str(cycle)]),
                         ('native',[python,'-B','benchmark.py',str(cycle)])]:
        verify();log=root/f'latency-{runtime}-{cycle}.log';start=time.monotonic()
        with log.open('w') as output:
            child=subprocess.Popen(args,cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
            (root/'latency-progress.json').write_text(json.dumps(dict(status='running',runtime=runtime,cycle=cycle,pid=child.pid,completed=receipts),indent=2)+'\n')
            code=child.wait()
        verify();receipt=dict(runtime=runtime,cycle=cycle,pid=child.pid,returncode=code,seconds=time.monotonic()-start,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        receipts.append(receipt);print(json.dumps(receipt),flush=True)
        if code:raise SystemExit(code)
(root/'latency-progress.json').write_text(json.dumps(dict(status='completed',completed=receipts),indent=2)+'\n')
