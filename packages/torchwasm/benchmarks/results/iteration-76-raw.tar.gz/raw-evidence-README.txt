Iteration 76 evidence

The selected source is 0.74.0. Performance candidate 0.73.0 differs only in the
__init__.py version literal; all compute sources are byte-identical. Baseline,
candidate, selected and the unselected explicit-order=C source are retained.
The complete native Torch 2.6 oracle.npz and all qualifying samples are included.
Native oracle generation is make-oracle.py; workload.py checks forward/VJP/JVP/
HVP and exceptional fallbacks. The private measurement programs match the raw
timings; the public benchmark has a standalone CLI and untimed value checks.

The first harness attempt rejected negative-stride public NumPy imports before
candidate comparison. Its original oracle binary was regenerated with supported
row-stride descriptors and was not retained. Its old plan is diagnostic only.
The minified unhandled Node error log is excluded; diagnostic.json and the native
trace preserve the cause. Attempt 2 and every qualifying candidate use the complete
current oracle.npz. The private kernel also checks negative strides directly.

Runtime binaries/wheels, virtual environments, caches and pytest temporary trees
are excluded. Runtime identities and the pinned Pyodide 0.29.4 / NumPy 2.2.5 wheel
closure are recorded; retrieve them from the repository's pinned browser runtime.
Application fixtures are tied to the recorded Git SHA and selected sources.
Local wheel/sdist outputs are included; nothing was published.

Tracemalloc reports tracked operation allocation deltas, not RSS or physical
WASM memory. HVP float32 precision limits and small-call overhead are disclosed.
All tar mtimes are normalized to zero. File mode, uid/gid and owner/group names
are preserved; duplicate bytes become hardlinks only when those metadata match.
