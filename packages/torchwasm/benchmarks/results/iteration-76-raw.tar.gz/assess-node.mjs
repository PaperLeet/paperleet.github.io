import fs from 'node:fs';
import {loadPyodide} from './runtime/pyodide.mjs';
const py=await loadPyodide({indexURL:new URL('./runtime/',import.meta.url).pathname,stdout(){},stderr(){}});await py.loadPackage('numpy');
const report=JSON.parse(py.runPython(fs.readFileSync(new URL('./assess.py',import.meta.url),'utf8')));
report.pyodide=py.version;report.node=process.version;
fs.writeFileSync(new URL('./assessment-node.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
for(const dtype of ['float32','float64'])for(const shape of [[4,5,6],[32,64,32],[128,64,128],[128,128,128],[256,256,256],[512,512,512]]){
 const rows=report.rows.filter(row=>row.dtype===dtype&&JSON.stringify(row.shape)===JSON.stringify(shape));
 console.log(dtype,shape.join('x'),Object.fromEntries(rows.map(row=>[row.method,Math.round(row.median_s*1e6)])));
}
