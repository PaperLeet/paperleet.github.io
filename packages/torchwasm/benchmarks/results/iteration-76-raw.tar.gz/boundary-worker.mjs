import {loadPyodide} from './runtime/pyodide.mjs';
self.onmessage=async({data})=>{
 try{
  const plan=await(await fetch('./boundary-plan.json')).json(),py=await loadPyodide({indexURL:new URL('./runtime/',self.location.href).href,stdout(){},stderr(){}});await py.loadPackage('numpy');
  for(const [name,digest] of Object.entries(plan.files)){
   const bytes=new Uint8Array(await(await fetch('./'+name)).arrayBuffer());const actual=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),v=>v.toString(16).padStart(2,'0')).join('');if(actual!==digest)throw Error('source mismatch '+name);
   py.FS.mkdirTree('/'+name.split('/').slice(0,-1).join('/'));py.FS.writeFile('/'+name,bytes);
  }
  py.globals.set('cycle',data.cycle||0);
  const report=JSON.parse(py.runPython("import sys,json\nsys.path.insert(0,'/')\nimport boundary_workload\njson.dumps(boundary_workload."+(data.mode==='qualify'?'qualify()':'benchmark(cycle)')+")"));self.postMessage({status:'passed',report,programs:plan.files,pyodide:py.version});
 }catch(error){self.postMessage({status:'failed',error:String(error),stack:error.stack});}
};
