from pathlib import Path
import hashlib
import json
import math
import time
import numpy as np
import torch
from workload import layout

root=Path(__file__).resolve().parent
rng=np.random.default_rng(76024)
cases=[]; store={}; controls=[]
for dtype in ['float32','float64']:
    for shape in [(128,64,128),(64,128,128),(128,128,128),(64,256,64)]:
        m,k,n=shape
        for order in ['C','F','stride','row_stride','broadcast']:
            key=f'{dtype}_{m}_{k}_{n}_{order}'
            case=dict(key=key,dtype=dtype,shape=shape,layout=order);cases.append(case)
            arrays=[]
            for name,dimensions in [('a',(m,k)),('b',(k,n)),('ta',(m,k)),('tb',(k,n)),('seed',(m,n))]:
                value=rng.uniform(-1,1,size=dimensions).astype(dtype)
                if order=='broadcast' and name!='seed':value[:]=value[:1]
                store[key+'_'+name]=value
                if name!='seed':arrays.append(value)
            a,b,ta,tb=[torch.from_numpy(x.copy()).requires_grad_(i<2) for i,x in enumerate(arrays)]
            seed=torch.from_numpy(store[key+'_seed'])
            y=a@b;ga,gb=torch.autograd.grad(y,(a,b),seed)
            _,tangent=torch.func.jvp(lambda x,y:x@y,(a,b),(ta,tb))
            loss,hessian=torch.autograd.functional.hvp(lambda x,y:(x@y).square().sum()*.5,(a,b),(ta,tb))
            for name,value in [('y',y),('ga',ga),('gb',gb),('jvp',tangent),('loss',loss),('ha',hessian[0]),('hb',hessian[1])]:
                store[key+'_'+name]=value.detach().numpy().copy()
            # A scalar reference independent of the BLAS/GEMM implementation.
            error=0.
            for i,j in [(0,0),(m//2,n//2),(m-1,n-1)]:
                exact=math.fsum(float(arrays[0][i,t])*float(arrays[1][t,j]) for t in range(k))
                error=max(error,abs(float(store[key+'_y'][i,j])-exact))
                assert math.isclose(float(store[key+'_y'][i,j]),exact,rel_tol=3e-5 if dtype=='float32' else 2e-12,abs_tol=3e-5 if dtype=='float32' else 2e-12)
            controls.append(dict(case=key,scalar_reference_max_absolute_error=error))
store['cases']=np.array(json.dumps(cases))
np.savez_compressed(root/'oracle.npz',**store)
report=dict(status='passed',torch=torch.__version__,numpy=np.__version__,cases=len(cases),scalar_controls=controls,
            sha256=hashlib.sha256((root/'oracle.npz').read_bytes()).hexdigest(),bytes=(root/'oracle.npz').stat().st_size)
(root/'oracle-receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='scalar_controls'}),flush=True)
