import fs from 'node:fs';
import {loadPyodide} from './runtime/pyodide.mjs';
async function main(){
 const root=new URL('./',import.meta.url),py=await loadPyodide({indexURL:new URL('runtime/',root).pathname,stdout(){},stderr(){}});await py.loadPackage('numpy');
 for(const name of fs.readdirSync(new URL('candidate/stridetorch/',root))){py.FS.mkdirTree('/candidate/stridetorch');py.FS.writeFile('/candidate/stridetorch/'+name,fs.readFileSync(new URL('candidate/stridetorch/'+name,root)));}
 py.FS.writeFile('/workload.py',fs.readFileSync(new URL('workload.py',root)));py.runPython("import sys;sys.path.insert(0,'/')");
 const result=JSON.parse(py.runPython(fs.readFileSync(new URL('profile.py',root),'utf8')));fs.writeFileSync(new URL('kernel-profile-node.json',root),JSON.stringify(result,null,2)+'\n');
 for(const row of result.rows)console.log(row.dtype,row.method,Math.round(row.median_seconds*1e6),row.strides);
}
main().catch(error=>{console.error(String(error));process.exitCode=1;});
