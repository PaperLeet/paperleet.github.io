import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {loadPyodide} from './runtime/pyodide.mjs';
async function main(){
const root=new URL('./',import.meta.url),plan=JSON.parse(fs.readFileSync(new URL('qualification-plan.json',root)));
const py=await loadPyodide({indexURL:new URL('runtime/',root).pathname,stdout(){},stderr(){}});
await py.loadPackage('numpy');
for(const [name,digest] of Object.entries(plan.files)){
 const bytes=fs.readFileSync(new URL(name,root));assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),digest,name);
 py.FS.mkdirTree('/'+name.split('/').slice(0,-1).join('/'));py.FS.writeFile('/'+name,bytes);
}
const report=JSON.parse(py.runPython("import sys,json\nsys.path.insert(0,'/')\nfrom workload import run\njson.dumps([run('/'+label+'/stridetorch',label,'/oracle.npz') for label in ['baseline','candidate']])"));
assert(report.every(x=>x.rows.length===40));assert.equal(report[1].wasm_route,true);
fs.writeFileSync(new URL('qualification-node.json',root),JSON.stringify({status:'passed',runtime:process.version,pyodide:py.version,source_files:plan.files,reports:report},null,2)+'\n');
console.log(JSON.stringify({status:'passed',cases:report.map(x=>[x.label,x.rows.length]),fallback:report[1].fallback}));

}
main().catch(error=>{console.error(String(error));process.exitCode=1;});
