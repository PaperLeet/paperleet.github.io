from pathlib import Path
import hashlib,json,statistics
root=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
read=lambda path:json.loads(path.read_text());sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
freeze=read(root/'selected-source-freeze.json');latency=read(root/'latency-summary.json')
cpu=read(root/'local-integration/cpu-receipt.json');chrome=read(root/'chrome-sdk/result.json');package=read(root/'package-proof/result.json')
assert cpu['status']==package['status']=='passed' and chrome['status']=='success'
assert cpu['source_hashes']==chrome['source_hashes']==package['source_hashes']==freeze['source_hashes']
gates=read(root/'local-integration/gates-result.json') if (root/'local-integration/gates-result.json').exists() else None
if gates:assert gates['status']=='passed' and gates['source_hashes']==freeze['source_hashes']
boundary=read(root/'boundary-summary.json') if (root/'boundary-summary.json').exists() else None
if boundary:assert read(root/'boundary-selection-review.json')['status']=='qualified'
result=dict(iteration=76,version='0.74.0',status='local_application_qualified' if gates else 'core_qualified_application_gates_pending',
 baseline_execution_sha=read(root/'snapshot-identity.json')['main_sha'],application_execution_sha=freeze['upstream'],source_hashes=freeze['source_hashes'],
 performance_metadata_equivalence=dict(measured_candidate_version='0.73.0',selected_version='0.74.0',only_difference='__init__.py version literal',compute_sources_byte_identical=True),
 selection=read(root/'selection-review.json'),latency=latency,chrome_sdk=dict(passed=chrome['passed'],suites=chrome['suites'],browser=chrome['browser']),
 cpu_summary=cpu['summary'],minimum_wheel_summary=next(x['summary'][0] for x in package['receipts'] if x['label']=='minimum-sdk'),
 memory_node=read(root/'memory-node.json'),hvp_precision_controls={name:read(root/name) for name in ['hvp-precision-native-2.6.0.json','hvp-precision-baseline.json','hvp-precision-candidate.json']},
 numerical_oracle=dict(native_torch=read(root/'oracle-receipt.json')['torch'],fixtures=40,checks_per_fixture=['forward','VJP_a','VJP_b','JVP','HVP_a','HVP_b','scalar_loss'],node_selected_new_pytest=73),
 application_gates=gates,ci_triggered=False,tags_created=False,published=False,deployed=False)
if boundary:result['additional_dispatch_boundary_validation']=dict(summary=boundary,review=read(root/'boundary-selection-review.json'),native_torch_polynomial=read(root/'boundary-native-oracle.json'))
archive=repo/'packages/stridetorch/benchmarks/results/iteration-76-raw.tar.gz'
if archive.exists():result['raw_archive']=dict(path=archive.name,sha256=sha(archive),bytes=archive.stat().st_size)
out=repo/'packages/stridetorch/benchmarks/results/iteration-76.json';out.write_text(json.dumps(result,indent=2)+'\n')
lines=['# Iteration 76: large 2D matmul on NumPy/WASM','',
 'Version 0.74 keeps the synchronous NumPy/Pyodide runtime and optimizes large float32/float64 matrix products and their two pullbacks. Native CPU keeps NumPy matmul. No supported WebGPU device or new binary/runtime dependency is introduced.','',
 '## Dispatch and storage','',
 'Both operands must be 2D, have equal real float32/float64 dtypes and matching inner dimensions. Output dimensions must be at least 32, the reduction dimension at least 64, work at least 1,048,576 multiply-add terms, and the captured left input at least 4,096 elements. All other inputs retain the original operation. Nonzero magnitudes must be between `sqrt(finfo.tiny)` and `sqrt(finfo.max / K) / 2`; NaN, infinity and exceptional finite ranges fall back. This range guard does not eliminate cancellation or backend roundoff.','',
 'The implementation uses direct `einsum` with its default traversal, then normalizes output to C layout. Explicit `order="C"` was an unselected attempt: it disabled the fast WASM traversal despite the output already being C-contiguous. Both failed/unselected attempts and their diagnostics remain in the raw evidence. Opposite-operand live reads, minimal saved-value guards and zero signs remain qualified. Inputs and packed operands are not cached.','',
 '## Numeric and package controls','',
 '* Forty native Torch 2.6 fixtures cover four large shapes, five supported layouts and two dtypes. Each checks forward, both VJPs, JVP, both HVP outputs and scalar loss; 120 independent scalar forward entries also use `math.fsum`. The new contraction executes 13 times per fixture in the combined derivative workflow.','* Final-version Node/Pyodide reruns all 40 fixtures and 73 new regressions. Chrome/Pyodide runs the complete 75-suite SDK: 8,911 passed. The complete native application and standalone suites report '+cpu['summary']+'.','* A fresh Python 3.10.19 / NumPy 1.26.4 environment installs the standalone wheel with no Torch or PaperLeet installed: '+result['minimum_wheel_summary']+'. Both built wheels contain the exact 62 selected source/notice resources in their respective public/private namespaces; explicit `import torch` aliases work after co-installation.','',
 'A repeated-row float32 HVP fixture exposes composed-reduction rounding: maximum absolute errors against float64 controls were about 0.00190 for native Torch/unchanged adapter and 0.00228 for the candidate. The HVP regressions use a separate `atol=0.002, rtol=0.0003` budget; other new comparisons retain their own stricter budgets. This is not a bit-identical floating-point claim.','',
 '## Warm-call performance','',
 'Four fresh processes each in Node/Pyodide, Chrome/Pyodide and native CPU compare baseline A0, an independent baseline import A1, and candidate B. Thirty-four flows per process cover both dtypes, forward/full forward-VJP calls, layouts and fallback controls. Batches target 50 ms, three rotated samples per variant. All samples are retained: 3 of 3,672 batches were below 20 ms. The original candidate carried version 0.73.0; selected 0.74.0 changes only that version literal, with all compute sources byte-identical.','',
 'Ratios below are medians of four per-process B/A0 ratios in Chrome; lower is faster. Full data, including A/A drift, ranges and all native controls, is in the machine record.','',
 '| Flow | float32 B/A0 | float64 B/A0 |','| --- | ---: | ---: |']
for key,label in [('dense256_forward','256-square forward'),('dense256_backward','256-square forward + VJP'),('dense512_forward','512-square forward'),('transpose256_forward','256-square Fortran layout'),('stride256_forward','256-square strided'),('threshold_forward','128×64×128 forward'),('tiny_forward','4×5×6 forward')]:
 ratios=[next(r['candidate_over_baseline_median'] for r in latency['rows'] if r['runtime']=='chrome' and r['key']==dtype+'_'+key) for dtype in ['float32','float64']]
 lines.append('| '+label+' | '+' | '.join(f'{x:.4f}' for x in ratios)+' |')
lines += ['', 'Small WASM calls show approximately 1–2% overhead in these measurements. A focused four-process CPU follow-up covers six flows with nine longer rotated batches: median B/A0 ratios range from 0.9955 to 1.0006. These controls did not reproduce the first-pass 4.5% CPU outlier. No universal speedup, native-Torch latency comparison, GPU routing threshold, cold-load, transfer or full-application throughput claim is made.','',
 '## Tracked allocation','',
 'In Node/Pyodide, 512-square float32 forward incremental traced peak increased from 1,049,932 to 1,345,400 bytes; forward/VJP increased from 3,149,212 to 3,445,240 bytes. The extra peak comes from bounded range scans and optional output-layout normalization. After 13 discarded calls, both baseline and candidate retained the same 188 traced harness bytes; weak references confirmed the source buffers were collectable. This measures tracked Python/NumPy allocation deltas, not total RSS or physical WASM heap.','',
 '## Application and release boundaries','']
if boundary:
    location=lines.index('## Tracked allocation')
    lines[location:location]=['## Dispatch-boundary follow-up','',
      'Six additional shapes include `(32,128,256)`, `(256,128,32)`, `(32,1024,32)`, `(64,64,256)`, the inactive left-size boundary `(32,64,512)`, and the short-reduction forward fallback `(128,32,256)`. Thirty-six float32/float64/layout fixtures use closed-form rank-one polynomial forward/VJP/JVP/HVP controls with `math.fsum` scalar factors. Native Torch 2.6 and both selected-version WASM runtimes independently pass those same 36 fixtures. These are additional controls outside the maintained SDK inventory.','',
      'Eight more fresh WASM processes measure 24 forward/forward-VJP flows per process, with 0 of 1,728 batches below 20 ms. Active-forward boundary median B/A0 ratios range from approximately 0.497 to 0.887 across the two runtimes; inactive forward controls retain approximately 1–2% overhead. The original dispatch is retained. The short-reduction case can still accelerate a separately eligible pullback. Every boundary sample, range and A/A control is retained.','']
if gates:lines.append(f"All local application gates passed on `{gates['upstream']}` with the 0.74 selected source. Real exported WASM passed {gates['modules']}/{gates['modules']} catalog modules and {gates['mutants']} mutants, plus the complete frontend checks, policy checks and both build profiles. The 14,779 prior immutable assets remain byte-identical; 174 new content-addressed assets are reachable from the live export. Release policies remain unchanged. No CI, tag, package publication or deployment was initiated.")
else:lines.append('Full exported WASM and frontend/build gates are still running. Main adoption remains pending these gates. The preceding counts describe the completed core/package checks only.')
lines += ['',f"Baseline numeric/performance sources were frozen at `{result['baseline_execution_sha']}`. The unrelated seven-file UI advance to `{freeze['upstream']}` was reviewed and preserved before application validation; all core sources were unchanged by that advance.",'', '[Machine record](../../packages/stridetorch/benchmarks/results/iteration-76.json).']
if archive.exists():lines += ['',f"[Raw evidence](../../packages/stridetorch/benchmarks/results/{archive.name}) — {archive.stat().st_size:,} bytes; SHA-256 `{sha(archive)}`."]
(repo/'docs/validation/torch-runtime-iteration-76.md').write_text('\n'.join(lines)+'\n')
print(result['status'],len(lines),'report lines')
