import json,sys,statistics,time
import numpy as np
from workload import load_library
_,_,kernel=load_library('/candidate/stridetorch','profile')
rows=[]
for dtype in ['float32','float64']:
    rng=np.random.default_rng(76);a=rng.uniform(-1,1,size=(256,256)).astype(dtype);b=rng.uniform(-1,1,size=(256,256)).astype(dtype)
    limits=np.finfo(dtype);lower=np.sqrt(limits.tiny);upper=np.sqrt(limits.max/256)*.5;mag=np.abs(a)
    methods={'matmul':lambda:a@b,'einsum_C':lambda:np.einsum('ik,kj->ij',a,b,optimize=False,order='C'),
             'einsum_K':lambda:np.einsum('ik,kj->ij',a,b,optimize=False),
             'einsum_K_copy_C':lambda:np.ascontiguousarray(np.einsum('ik,kj->ij',a,b,optimize=False)),
             'abs':lambda:np.abs(a),'max':lambda:mag.max(),
             'masked_min':lambda:np.min(mag,where=mag!=0,initial=upper),
             'lower_bool':lambda:np.logical_or(mag==0,mag>=lower).all(),
             'candidate':lambda:kernel.product(a,b)}
    for name,fn in methods.items():
        n=1
        while True:
            start=time.perf_counter()
            for _ in range(n):fn()
            elapsed=time.perf_counter()-start
            if elapsed>=.025:break
            n*=2
        timings=[]
        for _ in range(3):
            start=time.perf_counter()
            for _ in range(n):result=fn()
            timings.append((time.perf_counter()-start)/n)
        rows.append(dict(dtype=dtype,method=name,median_seconds=statistics.median(timings),strides=list(result.strides) if hasattr(result,'strides') else None))
json.dumps(dict(numpy=np.__version__,rows=rows))
