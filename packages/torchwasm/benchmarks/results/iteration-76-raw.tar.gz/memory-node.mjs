import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {loadPyodide} from './runtime/pyodide.mjs';
async function main(){
 const root=new URL('./',import.meta.url),plan=JSON.parse(fs.readFileSync(new URL('qualification-plan.json',root)));
 const py=await loadPyodide({indexURL:new URL('runtime/',root).pathname,stdout(){},stderr(){}});await py.loadPackage('numpy');
 for(const [name,digest] of Object.entries(plan.files)){
  if(name==='oracle.npz'||name==='benchmark.py')continue;
  const bytes=fs.readFileSync(new URL(name,root));assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),digest,name);
  py.FS.mkdirTree('/'+name.split('/').slice(0,-1).join('/'));py.FS.writeFile('/'+name,bytes);
 }
 const code=fs.readFileSync(new URL('memory.py',root));py.FS.writeFile('/memory.py',code);
 const result=JSON.parse(py.runPython("import sys,json\nsys.path.insert(0,'/')\nfrom memory import measure\njson.dumps(measure())"));
 fs.writeFileSync(new URL('memory-node.json',root),JSON.stringify({runtime:process.version,pyodide:py.version,...result,source_files:plan.files,memory_script_sha256:crypto.createHash('sha256').update(code).digest('hex')},null,2)+'\n');
 console.log(JSON.stringify(result));
}
main().catch(error=>{console.error(String(error));process.exitCode=1;});
