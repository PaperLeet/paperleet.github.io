import fs from 'node:fs';import crypto from 'node:crypto';import assert from 'node:assert/strict';
import {loadPyodide} from './runtime/pyodide.mjs';
async function main(){
 const root=new URL('./',import.meta.url),mode=process.argv[2]||'qualify',cycle=Number(process.argv[3]||0),plan=JSON.parse(fs.readFileSync(new URL('boundary-plan.json',root)));
 const py=await loadPyodide({indexURL:new URL('runtime/',root).pathname,stdout(){},stderr(){}});await py.loadPackage('numpy');
 for(const [name,digest] of Object.entries(plan.files)){
  const bytes=fs.readFileSync(new URL(name,root));assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),digest,name);py.FS.mkdirTree('/'+name.split('/').slice(0,-1).join('/'));py.FS.writeFile('/'+name,bytes);
 }
 py.globals.set('cycle',cycle);
 const result=JSON.parse(py.runPython("import sys,json\nsys.path.insert(0,'/')\nimport boundary_workload\njson.dumps(boundary_workload."+(mode==='qualify'?'qualify()':'benchmark(cycle)')+")"));
 fs.writeFileSync(new URL('boundary-node-'+mode+'-'+cycle+'.json',root),JSON.stringify({runtime:process.version,pyodide:py.version,programs:plan.files,...result},null,2)+'\n');console.log(JSON.stringify({status:'passed',mode,cycle,cases:result.cases,rows:result.rows.length}));
}
main().catch(error=>{console.error(String(error));process.exitCode=1;});
