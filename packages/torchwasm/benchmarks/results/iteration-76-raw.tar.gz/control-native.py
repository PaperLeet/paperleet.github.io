from pathlib import Path
import gc,hashlib,json,math,statistics,sys,time
import benchmark
from workload import load_library
root=Path(__file__).resolve().parent;cycle=int(sys.argv[1])
libraries={label:load_library(root/folder/'stridetorch','native_control_'+label)[0] for label,folder in [('A0','baseline'),('A1','baseline'),('B','candidate')]}
keys=['float32_tiny_forward','float64_tiny_forward','float64_below_threshold_forward','float64_threshold_forward','float64_small_forward','float64_small_backward']
rows=[]
for key in keys[cycle%6:]+keys[:cycle%6]:
    spec=next(x for x in benchmark.specs() if x['key']==key);raw=benchmark.inputs(spec)
    functions={label:benchmark.function(torch,raw,spec['mode']) for label,torch in libraries.items()}
    iterations={label:2*benchmark.iterations(fn) for label,fn in functions.items()}
    gc.collect();gc.disable()
    try:
        samples={label:[] for label in libraries}
        for repeat in range(9):
            order=list(libraries);rotation=(cycle+repeat)%3;order=order[rotation:]+order[:rotation]
            for label in order:
                elapsed=benchmark.duration(functions[label],iterations[label]);samples[label].append(dict(elapsed_seconds=elapsed,iterations=iterations[label],seconds_per_call=elapsed/iterations[label]))
    finally:gc.enable()
    median={label:statistics.median(s['seconds_per_call'] for s in series) for label,series in samples.items()}
    rows.append(dict(key=key,samples=samples,median_seconds=median,candidate_over_baseline=median['B']/median['A0'],control_over_baseline=median['A1']/median['A0']))
result=dict(cycle=cycle,platform=sys.platform,rows=rows,scope='Focused native CPU follow-up; normal platform dispatch, no forced WASM route',source_hashes={folder:{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/folder/'stridetorch').iterdir() if p.is_file()} for folder in ['baseline','candidate']})
(root/f'native-control-{cycle}.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(cycle=cycle,status='passed',rows=len(rows))),flush=True)
