"""Tracked live allocations; this is not process RSS or physical WASM memory."""
import gc,json,sys,tracemalloc,weakref
from pathlib import Path
import numpy as np
from workload import load_library


def measure(root='/'):
    rows=[]
    for label in ['baseline','candidate']:
        torch,tensor_module,_=load_library(Path(root)/label/'stridetorch','memory_'+label)
        if label=='candidate':tensor_module._WASM_MATMUL=True
        for size in [256,512]:
            for mode in ['forward','backward']:
                rng=np.random.default_rng(76076)
                raw_a=rng.uniform(-1,1,size=(size,size)).astype('float32')
                raw_b=rng.uniform(-1,1,size=(size,size)).astype('float32')
                a=torch.from_numpy(raw_a).requires_grad_(mode=='backward')
                b=torch.from_numpy(raw_b).requires_grad_(mode=='backward')
                seed=torch.ones(size,size)
                def call():
                    y=a@b
                    return y if mode=='forward' else torch.autograd.grad(y,(a,b),seed)
                call();gc.collect();tracemalloc.start();gc.collect()
                before=tracemalloc.get_traced_memory()[0];tracemalloc.reset_peak()
                result=call();during,peak=tracemalloc.get_traced_memory()
                del result;gc.collect();after_one=tracemalloc.get_traced_memory()[0]
                for _ in range(12):call()
                gc.collect();after_many=tracemalloc.get_traced_memory()[0];tracemalloc.stop()
                assert after_many-before<65536,(label,size,mode,after_many-before)
                ref_a,ref_b=weakref.ref(raw_a),weakref.ref(raw_b)
                del a,b,seed,raw_a,raw_b,call;gc.collect()
                assert ref_a() is None and ref_b() is None,(label,size,mode,'retained input storage')
                rows.append(dict(label=label,size=size,mode=mode,live_result_delta=during-before,
                                 peak_delta=peak-before,after_one_delta=after_one-before,after_thirteen_delta=after_many-before,inputs_collected=True))
    return dict(status='passed',scope='tracemalloc tracked Python/NumPy allocations, not RSS or physical WASM heap',platform=sys.platform,numpy=np.__version__,rows=rows)


if __name__=='__main__':
    root=Path(__file__).resolve().parent
    result=measure(str(root));(root/'memory-native.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
