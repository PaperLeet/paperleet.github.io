"""Archive explicit evidence only; never include runtimes, environments or test temps."""
from pathlib import Path
import gzip,hashlib,io,json,os,tarfile
root=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
gates=json.loads((root/'local-integration/gates-result.json').read_text());assert gates['status']=='passed'
assert json.loads((root/'local-integration/gate-progress.json').read_text())['status']=='completed'
assert json.loads((root/'latency-progress.json').read_text())['status']=='completed'
allowed={p for p in root.iterdir() if p.is_file() and p.suffix in ['.py','.mjs','.json','.log','.html']}
allowed.add(root/'oracle.npz')
for folder in ['baseline','candidate','selected','chrome-sdk','attempt-2-order-C']:
    allowed.update(p for p in (root/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for folder in ['local-integration','main-integration','package-proof']:
    allowed.update(p for p in (root/folder).iterdir() if p.is_file() and p.suffix in ['.py','.json','.log'])
for folder in ['package-proof/dist','package-proof/app-dist']:
    allowed.update(p for p in (root/folder).iterdir() if p.is_file())
allowed.update(p for p in (root/'attempt-1').iterdir() if p.is_file() and p.name!='qualification-node.log')
allowed={p for p in allowed if p.name not in ['archive-manifest.json','archive-verification.json']}
note=root/'raw-evidence-README.txt'
note.write_text('''Iteration 76 evidence

The selected source is 0.74.0. Performance candidate 0.73.0 differs only in the
__init__.py version literal; all compute sources are byte-identical. Baseline,
candidate, selected and the unselected explicit-order=C source are retained.
The complete native Torch 2.6 oracle.npz and all qualifying samples are included.
Native oracle generation is make-oracle.py; workload.py checks forward/VJP/JVP/
HVP and exceptional fallbacks. The private measurement programs match the raw
timings; the public benchmark has a standalone CLI and untimed value checks.

The first harness attempt rejected negative-stride public NumPy imports before
candidate comparison. Its original oracle binary was regenerated with supported
row-stride descriptors and was not retained. Its old plan is diagnostic only.
The minified unhandled Node error log is excluded; diagnostic.json and the native
trace preserve the cause. Attempt 2 and every qualifying candidate use the complete
current oracle.npz. The private kernel also checks negative strides directly.

Runtime binaries/wheels, virtual environments, caches and pytest temporary trees
are excluded. Runtime identities and the pinned Pyodide 0.29.4 / NumPy 2.2.5 wheel
closure are recorded; retrieve them from the repository's pinned browser runtime.
Application fixtures are tied to the recorded Git SHA and selected sources.
Local wheel/sdist outputs are included; nothing was published.

Tracemalloc reports tracked operation allocation deltas, not RSS or physical
WASM memory. HVP float32 precision limits and small-call overhead are disclosed.
All tar mtimes are normalized to zero. File mode, uid/gid and owner/group names
are preserved; duplicate bytes become hardlinks only when those metadata match.
''')
allowed.add(note)
paths=sorted(allowed,key=lambda p:str(p.relative_to(root)))
manifest={};entries=[];unique={};regular=hardlinks=0
for path in paths:
    relative=str(path.relative_to(root));digest=hashlib.sha256(path.read_bytes()).hexdigest()
    with tarfile.open(fileobj=io.BytesIO(),mode='w') as temp:info=temp.gettarinfo(str(path),arcname=relative)
    assert info.isfile(),relative
    info.mtime=0
    key=(digest,info.mode,info.uid,info.gid,info.uname,info.gname)
    manifest[relative]=dict(sha256=digest,size=info.size,mode=info.mode,uid=info.uid,gid=info.gid,uname=info.uname,gname=info.gname)
    if key in unique:
        info.type=tarfile.LNKTYPE;info.linkname=unique[key];info.size=0;hardlinks+=1
    else:unique[key]=relative;regular+=1
    entries.append((path,info))
manifest_path=root/'archive-manifest.json';manifest_path.write_text(json.dumps(dict(files=manifest,normalization='mtime=0; preserved mode and owner metadata; manifest itself is not self-hashed'),indent=2)+'\n')
archive=repo/'packages/stridetorch/benchmarks/results/iteration-76-raw.tar.gz'
with archive.open('wb') as output,gzip.GzipFile(fileobj=output,filename='',mode='wb',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
    for path,info in entries:
        if info.islnk():tar.addfile(info)
        else:
            with path.open('rb') as payload:tar.addfile(info,payload)
    info=tar.gettarinfo(str(manifest_path),arcname='archive-manifest.json');info.mtime=0
    with manifest_path.open('rb') as payload:tar.addfile(info,payload)
with tarfile.open(archive,'r:gz') as tar:
    members={m.name:m for m in tar.getmembers()};assert len(members)==len(manifest)+1
    assert tar.extractfile('archive-manifest.json').read()==manifest_path.read_bytes()
    for name,expected in manifest.items():
        actual=members[name];data=tar.extractfile(actual).read()
        assert hashlib.sha256(data).hexdigest()==expected['sha256'] and len(data)==expected['size'],name
        for field in ['mode','uid','gid','uname','gname']:assert getattr(actual,field)==expected[field],(name,field)
result=dict(status='verified',archive=str(archive),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size,logical_payloads=len(manifest)+1,unique_payloads=regular+1,hardlinks=hardlinks,all_logical_payloads_and_owner_modes_verified=True)
(root/'archive-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
