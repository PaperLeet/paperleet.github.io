import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {loadPyodide} from './runtime/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
async function main(){
 const root=new URL('./',import.meta.url),freeze=JSON.parse(fs.readFileSync(new URL('selected-source-freeze.json',root)));
 const py=await loadPyodide({indexURL:new URL('runtime/',root).pathname,stdout(){},stderr(){}});await loadJudgePackages(py,[]);
 for(const [name,digest] of Object.entries(freeze.source_hashes)){
  const bytes=fs.readFileSync(new URL('selected/stridetorch/'+name,root));assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),digest,name);
  py.FS.mkdirTree('/selected/stridetorch');py.FS.writeFile('/selected/stridetorch/'+name,bytes);
 }
 const programs={};
 for(const name of ['workload.py','oracle.npz','test_matmul_wasm.py']){
  const bytes=fs.readFileSync(new URL(name,root));programs[name]=crypto.createHash('sha256').update(bytes).digest('hex');py.FS.writeFile('/'+name,bytes);
 }
 const report=JSON.parse(py.runPython("import sys,json\nsys.path.insert(0,'/')\nfrom workload import run\njson.dumps(run('/selected/stridetorch','selected','/oracle.npz'))"));
 const pytest=JSON.parse(py.runPython(`
sys.path.insert(0,'/selected')
import stridetorch,pytest
assert stridetorch.__version__=='0.74.0'
class Results:
    passed=0
    def __init__(self):self.failures=[]
    def pytest_runtest_logreport(self,report):
        if report.when=='call' and report.passed:self.passed+=1
        if report.failed:self.failures.append(dict(nodeid=report.nodeid,message=str(report.longrepr)[-3000:]))
records=Results()
code=pytest.main(['/test_matmul_wasm.py','-q','--noconftest','-p','no:cacheprovider','--import-mode=importlib'],plugins=[records])
json.dumps(dict(exit_code=int(code),passed=records.passed,failures=records.failures))
`));
 const result={status:pytest.exit_code===0?'passed':'failed',runtime:process.version,pyodide:py.version,source_hashes:freeze.source_hashes,programs,report,pytest};
 fs.writeFileSync(new URL('selected-node-result.json',root),JSON.stringify(result,null,2)+'\n');
 assert.equal(pytest.exit_code,0,JSON.stringify(pytest.failures));assert.equal(pytest.passed,73);assert.equal(report.rows.length,40);assert.equal(report.wasm_route,true);
 console.log(JSON.stringify({status:result.status,native_oracle_cases:report.rows.length,pytest_passed:pytest.passed}));
}
main().catch(error=>{console.error(String(error));process.exitCode=1;});
