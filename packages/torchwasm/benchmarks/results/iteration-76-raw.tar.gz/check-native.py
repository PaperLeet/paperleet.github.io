from pathlib import Path
import json
import sys
from workload import load_library, observe_numeric, check_fallback_and_guards
import numpy as np

root=Path(__file__).resolve().parent
fixture=np.load(root/'oracle.npz',allow_pickle=False)
cases=json.loads(str(fixture['cases']))
report=[]
for label in ['baseline','candidate']:
    torch,tensor_module,kernel_module=load_library(root/label/'stridetorch',label)
    assert not getattr(tensor_module,'_WASM_MATMUL',False)
    if label=='candidate':tensor_module._WASM_MATMUL=True
    rows=observe_numeric(torch,kernel_module,fixture,cases)
    fallback=check_fallback_and_guards(torch,tensor_module,kernel_module) if kernel_module else None
    report.append(dict(label=label,rows=rows,fallback=fallback))
(root/'qualification-native.json').write_text(json.dumps(dict(status='passed',python=sys.version,numpy=np.__version__,reports=report),indent=2)+'\n')
print(json.dumps(dict(status='passed',cases=[(x['label'],len(x['rows'])) for x in report])))
