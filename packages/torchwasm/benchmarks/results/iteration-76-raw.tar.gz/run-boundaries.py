from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path(__file__).resolve().parent;assert json.loads((root/'local-integration/gate-progress.json').read_text())['status']=='completed'
files=[p for label in ['baseline','candidate','selected'] for p in (root/label/'stridetorch').iterdir() if p.is_file()]+[root/name for name in ['workload.py','benchmark.py','boundary_workload.py']]
plan=dict(files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files});(root/'boundary-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
tasks=[('node','qualify',0),('chrome','qualify',0)]+[(runtime,'benchmark',cycle) for cycle in range(4) for runtime in ['node','chrome']];receipts=[]
for runtime,mode,cycle in tasks:
    args=['/opt/homebrew/bin/node',f'boundary-{runtime}.mjs',mode,str(cycle)];start=time.monotonic()
    with (root/f'boundary-{runtime}-{mode}-{cycle}.log').open('w') as log:
        child=subprocess.Popen(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
        (root/'boundary-progress.json').write_text(json.dumps(dict(status='running',runtime=runtime,mode=mode,cycle=cycle,pid=child.pid,receipts=receipts),indent=2)+'\n');code=child.wait()
    receipt=dict(runtime=runtime,mode=mode,cycle=cycle,exit_code=code,seconds=time.monotonic()-start);receipts.append(receipt);print(json.dumps(receipt),flush=True)
    if code:raise SystemExit(code)
    for name,digest in plan['files'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
(root/'boundary-progress.json').write_text(json.dumps(dict(status='completed',receipts=receipts),indent=2)+'\n')
