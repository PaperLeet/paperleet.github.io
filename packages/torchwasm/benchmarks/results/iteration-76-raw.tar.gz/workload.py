"""Large-matmul controls shared by native Torch and the two WASM snapshots."""
import importlib.util
import json
import math
from pathlib import Path
import sys
import warnings

import numpy as np


def layout(value, name):
    if name == 'C': return value.copy(order='C')
    if name == 'F': return value.copy(order='F')
    if name == 'stride':
        result = np.empty((value.shape[0]*2, value.shape[1]*2), dtype=value.dtype)
        result[::2, ::2] = value
        return result[::2, ::2]
    if name == 'row_stride':
        result = np.empty((value.shape[0]*2, value.shape[1]), dtype=value.dtype)
        result[::2] = value
        return result[::2]
    if name == 'broadcast': return np.broadcast_to(value[:1], value.shape)
    raise ValueError(name)


def load_library(root, label):
    name = '_matmul_trial_' + label
    spec = importlib.util.spec_from_file_location(name, str(Path(root)/'__init__.py'),
                                                submodule_search_locations=[str(root)])
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module.torch, sys.modules[name+'._tensor'], sys.modules.get(name+'._matmul')


def check_numeric(torch, fixture, cases, route_counts=None):
    rows = []
    for case in cases:
        before = len(route_counts) if route_counts is not None else 0
        key = case['key']
        arrays = [layout(fixture[key+'_'+name], case['layout']) for name in ['a','b','ta','tb']]
        a,b,ta,tb = [torch.from_numpy(value).requires_grad_(i < 2) for i,value in enumerate(arrays)]
        seed = torch.from_numpy(fixture[key+'_seed'].copy())
        output = a @ b
        ga,gb = torch.autograd.grad(output, (a,b), seed)
        primal,tangent = torch.func.jvp(lambda x,y:x@y, (a,b), (ta,tb))
        loss,hessian = torch.autograd.functional.hvp(lambda x,y:((x@y).square().sum()*.5), (a,b), (ta,tb))
        values = {'y':output, 'ga':ga, 'gb':gb, 'jvp':tangent, 'ha':hessian[0], 'hb':hessian[1], 'loss':loss, 'primal':primal}
        atol = 3e-4 if case['dtype']=='float32' else 3e-11
        errors = {}
        for name,value in values.items():
            actual = value.detach().numpy()
            expected = fixture[key+'_'+('y' if name=='primal' else name)]
            np.testing.assert_allclose(actual, expected, rtol=atol, atol=atol)
            errors[name] = float(np.max(np.abs(actual.astype('float64')-expected.astype('float64'))))
        assert output.is_contiguous(), (key, output.stride())
        assert tuple(output.shape) == (case['shape'][0],case['shape'][2])
        row=dict(case=key, maximum_absolute_errors=errors, output_stride=list(output.stride()))
        if route_counts is not None:
            row['contractions']=len(route_counts)-before
            assert row['contractions'] >= 10, (key,row['contractions'])
        rows.append(row)
    return rows


def observe_numeric(torch, kernel_module, fixture, cases):
    if kernel_module is None: return check_numeric(torch,fixture,cases)
    calls=[];original=np.einsum
    def counted(*args,**kwargs):
        calls.append(args[0]); return original(*args,**kwargs)
    np.einsum=counted
    try: return check_numeric(torch,fixture,cases,calls)
    finally: np.einsum=original


def check_fallback_and_guards(torch, tensor_module, kernel_module):
    """Exceptional inputs must use the original operation, not merely agree."""
    calls = []
    einsum = np.einsum
    def counted(*args, **kwargs):
        calls.append(args[0]); return einsum(*args, **kwargs)
    np.einsum = counted
    counts = {}
    try:
        for dtype in ['float32','float64']:
            finfo = np.finfo(dtype)
            for name, value in [('nan',np.nan),('inf',np.inf),('negative_inf',-np.inf),
                                ('large',finfo.max/2),('subnormal',finfo.smallest_subnormal),
                                ('tiny',finfo.tiny),('small_normal',np.sqrt(finfo.tiny)/2)]:
                a=np.ones((128,64),dtype=dtype); b=np.ones((64,128),dtype=dtype); a[0,0]=value
                start=len(calls)
                with warnings.catch_warnings(), np.errstate(all='ignore'):
                    warnings.simplefilter('ignore')
                    expected=a@b; actual=kernel_module.product(a,b)
                np.testing.assert_array_equal(actual,expected)
                np.testing.assert_array_equal(np.signbit(actual),np.signbit(expected))
                assert len(calls)==start, (dtype,name,'unexpected contraction')
                counts[dtype+'_'+name]='fallback'
            for av,bv in [(0.,0.),(-0.,1.),(1.,-0.),(-1.,0.),(-0.,-0.),(0.,-1.)]:
                a=np.full((128,64),av,dtype=dtype); b=np.full((64,128),bv,dtype=dtype)
                expected=a@b;start=len(calls);actual=kernel_module.product(a,b)
                np.testing.assert_array_equal(actual,expected)
                np.testing.assert_array_equal(np.signbit(actual),np.signbit(expected))
                assert len(calls)==start+1
                counts[f'{dtype}_zeros_{av}_{bv}']='contraction'
        for a,b in [(np.ones((4,64)),np.ones((64,4))),
                    (np.ones((128,64),dtype='int64'),np.ones((64,128),dtype='int64')),
                    (np.ones((128,64),dtype='complex64'),np.ones((64,128),dtype='complex64')),
                    (np.ones((2,128,64)),np.ones((64,128))),
                    (np.ones(64),np.ones((64,128))),
                    (np.ones((128,0)),np.ones((0,128)))]:
            start=len(calls); np.testing.assert_array_equal(kernel_module.product(a,b),a@b); assert len(calls)==start
        for dtype in ['float32','float64']:
            a=np.arange(128*64,dtype=dtype).reshape(128,64)[::-1,::-1]/8192
            b=np.arange(64*128,dtype=dtype).reshape(64,128)[::-1,::-1]/8192
            start=len(calls)
            np.testing.assert_allclose(kernel_module.product(a,b),a@b,rtol=3e-6 if dtype=='float32' else 1e-12)
            assert len(calls)==start+1
        # The large route must retain minimal saved-value guards.
        for active in [(True,True),(True,False),(False,True)]:
            for changed in ['a','b','output']:
                a=torch.ones((128,64),requires_grad=active[0]);b=torch.ones((64,128),requires_grad=active[1]);y=a@b
                with torch.no_grad(): {'a':a,'b':b,'output':y}[changed].detach().add_(1)
                guarded = changed=='a' and active[1] or changed=='b' and active[0]
                try: y.sum().backward()
                except RuntimeError:
                    assert guarded,(active,changed)
                else: assert not guarded,(active,changed)
        return dict(exceptional_and_zero_cases=counts, fallback_shapes=6, negative_stride_private_kernel=2, mutation_cases=9)
    finally:
        np.einsum=einsum


def run(root, label, fixture_path):
    torch,tensor_module,kernel_module=load_library(root,label)
    fixture=np.load(fixture_path,allow_pickle=False)
    cases=json.loads(str(fixture['cases']))
    rows=observe_numeric(torch,kernel_module,fixture,cases)
    fallback=check_fallback_and_guards(torch,tensor_module,kernel_module) if kernel_module else None
    return dict(label=label, rows=rows, fallback=fallback, platform=sys.platform, python=sys.version, numpy=np.__version__,
                wasm_route=bool(getattr(tensor_module,'_WASM_MATMUL',False)))
