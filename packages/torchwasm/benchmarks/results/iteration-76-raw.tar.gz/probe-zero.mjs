import fs from 'node:fs';
import {loadPyodide} from './runtime/pyodide.mjs';
const py=await loadPyodide({indexURL:new URL('./runtime/',import.meta.url).pathname,stdout(){},stderr(){}});await py.loadPackage('numpy');
const value=JSON.parse(py.runPython(`import json,numpy as np
rows=[]
for dtype in [np.float32,np.float64]:
 for av,bv in [(0.,0.),(-0.,1.),(1.,-0.),(-1.,0.),(-0.,-0.),(0.,-1.)]:
  a=np.full((32,64),av,dtype=dtype);b=np.full((64,512),bv,dtype=dtype)
  old=a@b;new=np.einsum('ik,kj->ij',a,b,optimize=False,order='C')
  rows.append(dict(dtype=str(np.dtype(dtype)),a=repr(av),b=repr(bv),same_sign=bool(np.array_equal(np.signbit(old),np.signbit(new))),old_sign=bool(np.signbit(old[0,0])),new_sign=bool(np.signbit(new[0,0]))))
json.dumps(rows)`));
fs.writeFileSync(new URL('./zero-probe.json',import.meta.url),JSON.stringify(value,null,2)+'\n');console.log(JSON.stringify(value));
