import fs from 'node:fs';
import assert from 'node:assert/strict';
import {withFixtureServer} from '../torch-iteration-70/fixture-server.mjs';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
await withFixtureServer(async origin=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 try{
  const page=await browser.newPage();await page.goto(origin+'/torch-iteration-76/index.html');
  const result=await page.evaluate(()=>new Promise((resolve,reject)=>{
   const worker=new Worker('./worker.mjs',{type:'module'});const timer=setTimeout(()=>{worker.terminate();reject(Error('qualification timeout'));},240000);
   worker.onmessage=({data})=>{clearTimeout(timer);worker.terminate();resolve(data);};worker.onerror=e=>{clearTimeout(timer);worker.terminate();reject(Error(e.message));};worker.postMessage({});
  }));
  fs.writeFileSync(new URL('./qualification-chrome.json',import.meta.url),JSON.stringify({...result,browser:browser.version()},null,2)+'\n');
  assert.equal(result.status,'passed',JSON.stringify(result));assert(result.report.every(x=>x.rows.length===40));assert.equal(result.report[1].wasm_route,true);
  console.log(JSON.stringify({status:'passed',browser:browser.version(),cases:result.report.map(x=>[x.label,x.rows.length])}));
 }finally{await browser.close();}
});
