"""Rank-one polynomial controls at the actual dispatch boundaries."""
import json,math
from pathlib import Path
import numpy as np
from workload import load_library,layout

SHAPES=[(32,128,256),(256,128,32),(32,1024,32),(64,64,256),(32,64,512),(128,32,256)]


def vector(n,seed,dtype):return (((np.arange(n)*(2*seed+1)+seed)%17-8)/16).astype(dtype)
def dot(a,b):return math.fsum(float(x)*float(y) for x,y in zip(a,b))


def qualify(root='/',label='selected',native=None):
    if native is None:torch,_,_=load_library(Path(root)/label/'stridetorch','boundary_'+label)
    else:torch=native
    rows=[]
    for dtype in ['float32','float64']:
        for m,k,n in SHAPES:
            u,v,s,t,p,q,r,z,c,d=[vector(size,i+1,dtype) for i,size in enumerate([m,k,k,n,m,k,k,n,m,n])]
            alpha,beta,gamma=dot(v,s),dot(q,s),dot(v,r)
            y=alpha*np.outer(u.astype('float64'),t.astype('float64'))
            tangent=beta*np.outer(p.astype('float64'),t.astype('float64'))+gamma*np.outer(u.astype('float64'),z.astype('float64'))
            ga=dot(d,t)*np.outer(c.astype('float64'),s.astype('float64'))
            gb=dot(c,u)*np.outer(v.astype('float64'),d.astype('float64'))
            ha=beta*dot(t,t)*np.outer(p.astype('float64'),s.astype('float64'))+gamma*dot(z,t)*np.outer(u.astype('float64'),s.astype('float64'))+alpha*dot(t,z)*np.outer(u.astype('float64'),r.astype('float64'))
            hb=alpha*dot(p,u)*np.outer(q.astype('float64'),t.astype('float64'))+beta*dot(u,p)*np.outer(v.astype('float64'),t.astype('float64'))+gamma*dot(u,u)*np.outer(v.astype('float64'),z.astype('float64'))
            for order in ['C','F','stride']:
                raw=[layout(np.outer(a,b).astype(dtype),order) for a,b in [(u,v),(s,t),(p,q),(r,z)]]
                a,b,ta,tb=[torch.from_numpy(value).requires_grad_(i<2) for i,value in enumerate(raw)]
                seed=torch.from_numpy(np.outer(c,d).astype(dtype));output=a@b
                gradients=torch.autograd.grad(output,(a,b),seed)
                primal,direction=torch.func.jvp(lambda a,b:a@b,(a,b),(ta,tb))
                loss,hessian=torch.autograd.functional.hvp(lambda a,b:(a@b).square().sum()*.5,(a,b),(ta,tb))
                expected=[y,y,ga,gb,tangent,ha,hb,.5*alpha**2*dot(u,u)*dot(t,t)]
                actual=[output,primal,*gradients,direction,*hessian,loss]
                errors=[]
                for value,control in zip(actual,expected):
                    value=value.detach().numpy();np.testing.assert_allclose(value,control,rtol=3e-4 if dtype=='float32' else 3e-11,atol=3e-4 if dtype=='float32' else 3e-11)
                    errors.append(float(np.max(np.abs(value.astype('float64')-control))))
                assert output.is_contiguous()
                rows.append(dict(dtype=dtype,shape=[m,k,n],layout=order,maximum_absolute_errors=errors))
    return dict(status='passed',label=label,cases=len(rows),rows=rows,scope='Independent rank-one polynomial forward/VJP/JVP/HVP and scalar-loss controls, including active and inactive dispatch boundaries')


def boundary_specs():
    return [dict(key=f'{dtype}_{m}_{k}_{n}_{mode}',dtype=dtype,name=f'boundary_{m}_{k}_{n}',shape=[m,k,n],layout='C',mode=mode)
            for dtype in ['float32','float64'] for m,k,n in SHAPES for mode in ['forward','backward']]


def benchmark(cycle):
    import benchmark as module
    original=module.specs;module.specs=boundary_specs
    try:return module.run_benchmark(cycle)
    finally:module.specs=original
