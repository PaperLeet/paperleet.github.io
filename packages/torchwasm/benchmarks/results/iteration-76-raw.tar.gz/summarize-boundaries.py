from pathlib import Path
import hashlib,json,statistics
p=Path(__file__).resolve().parent;assert json.loads((p/'boundary-progress.json').read_text())['status']=='completed'
rows=[];short=[]
for runtime in ['node','chrome']:
    trials=[]
    for cycle in range(4):
        d=json.loads((p/f'boundary-{runtime}-benchmark-{cycle}.json').read_text());d=d.get('report',d);assert len(d['rows'])==24;trials.append(d)
        for r in d['rows']:
            for label,series in r['samples'].items():
                for sample in series:
                    if sample['elapsed_seconds']<.02:short.append(dict(runtime=runtime,cycle=cycle,key=r['key'],label=label,**sample))
    for key in sorted(r['key'] for r in trials[0]['rows']):
        matches=[next(r for r in d['rows'] if r['key']==key) for d in trials]
        values=[r['candidate_over_baseline'] for r in matches];controls=[r['control_over_baseline'] for r in matches]
        rows.append(dict(runtime=runtime,key=key,candidate_over_baseline=statistics.median(values),candidate_range=[min(values),max(values)],control_over_baseline=statistics.median(controls),control_range=[min(controls),max(controls)]))
result=dict(status='completed',fresh_processes=8,flows_per_process=24,total_batches=8*24*9,short_batches=short,rows=rows,native_polynomial_cases=json.loads((p/'boundary-native-oracle.json').read_text())['cases'])
(p/'boundary-summary.json').write_text(json.dumps(result,indent=2)+'\n')
for runtime in ['node','chrome']:
    print(runtime)
    for r in rows:
        if r['runtime']==runtime:print(r['key'],round(r['candidate_over_baseline'],4),'AA',round(r['control_over_baseline'],4))
print('short',len(short),'/',result['total_batches'])
