import json,time,statistics
import numpy as np
rng=np.random.default_rng(7601)
rows=[]
for dtype in [np.float32,np.float64]:
    for m,k,n in [(4,5,6),(32,64,32),(128,64,128),(128,128,128),(256,256,256),(512,512,512)]:
        a=rng.normal(0,.3,(m,k)).astype(dtype);b=rng.normal(0,.3,(k,n)).astype(dtype)
        methods=dict(matmul=lambda:a@b,dot=lambda:np.dot(a,b),einsum=lambda:np.einsum('ik,kj->ij',a,b,optimize=False),
                     packed=lambda:np.einsum('ik,jk->ij',a,np.ascontiguousarray(b.T),optimize=False),
                     opt_einsum=lambda:np.einsum('ik,kj->ij',a,b,optimize=True))
        reference=a.astype('float64')@b.astype('float64')
        for name,fn in methods.items():
            actual=fn();np.testing.assert_allclose(actual,reference,rtol=1e-4 if dtype==np.float32 else 1e-10,atol=5e-4 if dtype==np.float32 else 1e-10)
            count=1
            while True:
                start=time.perf_counter()
                for _ in range(count):fn()
                elapsed=time.perf_counter()-start
                if elapsed>=.02 or count>=65536:break
                count*=2
            timings=[]
            for _ in range(3):
                start=time.perf_counter()
                for _ in range(count):fn()
                timings.append((time.perf_counter()-start)/count)
            rows.append(dict(dtype=str(np.dtype(dtype)),shape=[m,k,n],method=name,median_s=statistics.median(timings),count=count))
json.dumps(dict(status='pilot_completed',numpy=np.__version__,rows=rows,scope='Single-process exploratory algorithm/layout pilot including packed-B copy, not release-quality latency evidence or a route selection. All methods preflight against float64.'))
