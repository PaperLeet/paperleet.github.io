from pathlib import Path
import hashlib,json,statistics
root=Path(__file__).resolve().parent
progress=json.loads((root/'latency-progress.json').read_text());assert progress['status']=='completed'
plan=json.loads((root/'qualification-plan.json').read_text())
for name,digest in plan['files'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
reports={};source_hashes=None;rows=[];short=[]
for runtime in ['node','chrome','native']:
    trials=[]
    for cycle in range(4):
        path=root/f'latency-{runtime}-{cycle}.json';outer=json.loads(path.read_text());data=outer.get('report',outer)
        assert data['cycle']==cycle and len(data['rows'])==34
        if source_hashes is None:source_hashes=data['source_hashes']
        assert data['source_hashes']==source_hashes
        for row in data['rows']:
            for label,batches in row['samples'].items():
                assert len(batches)==3
                for i,batch in enumerate(batches):
                    if batch['elapsed_seconds']<.02:short.append(dict(runtime=runtime,cycle=cycle,case=row['key'],label=label,sample=i,**batch))
        trials.append(data)
    keys=sorted(r['key'] for r in trials[0]['rows'])
    for key in keys:
        cases=[next(x for x in t['rows'] if x['key']==key) for t in trials]
        ratios=[x['candidate_over_baseline'] for x in cases];controls=[x['control_over_baseline'] for x in cases]
        rows.append(dict(runtime=runtime,key=key,candidate_over_baseline_median=statistics.median(ratios),candidate_over_baseline_range=[min(ratios),max(ratios)],control_over_baseline_median=statistics.median(controls),control_over_baseline_range=[min(controls),max(controls)],baseline_seconds_median=statistics.median(x['median_seconds']['A0'] for x in cases),candidate_seconds_median=statistics.median(x['median_seconds']['B'] for x in cases)))
    reports[runtime]=dict(fresh_processes=4,flows_per_process=34,platform=trials[0]['platform'],python=trials[0]['python'],numpy=trials[0]['numpy'])
result=dict(status='completed',fresh_processes=12,runtimes=reports,source_hashes=source_hashes,rows=rows,short_batches=short,total_batches=12*34*3*3,
            scope='Warm public Tensor forward and full forward/VJP calls. No native Torch, GPU, cold import, transfer, full app throughput, or universal speedup claim.')
(root/'latency-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],processes=12,rows=len(rows),short_batches=len(short))))
