import {loadPyodide} from './runtime/pyodide.mjs';
self.onmessage=async({data})=>{
 try{
  const plan=await (await fetch('./qualification-plan.json')).json();
  const py=await loadPyodide({indexURL:new URL('./runtime/',self.location.href).href,stdout(){},stderr(){}});await py.loadPackage('numpy');
  for(const [name,digest] of Object.entries(plan.files)){
   if(data?.benchmark && name==='oracle.npz')continue;
   const bytes=new Uint8Array(await(await fetch('./'+name)).arrayBuffer());
   const actual=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),v=>v.toString(16).padStart(2,'0')).join('');
   if(actual!==digest)throw Error('source mismatch '+name);
   py.FS.mkdirTree('/'+name.split('/').slice(0,-1).join('/'));py.FS.writeFile('/'+name,bytes);
  }
  const code=data?.benchmark
   ? "import sys,json\nsys.path.insert(0,'/')\nfrom benchmark import run_benchmark\njson.dumps(run_benchmark(cycle))"
   : "import sys,json\nsys.path.insert(0,'/')\nfrom workload import run\njson.dumps([run('/'+label+'/stridetorch',label,'/oracle.npz') for label in ['baseline','candidate']])";
  if(data?.benchmark)py.globals.set('cycle',data.cycle);
  const report=JSON.parse(py.runPython(code));
  self.postMessage({status:'passed',pyodide:py.version,source_files:plan.files,report});
 }catch(error){self.postMessage({status:'failed',error:String(error),stack:error.stack});}
};
