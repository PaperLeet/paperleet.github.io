from pathlib import Path
import json,sys
import numpy as np
from workload import load_library,layout
root=Path(__file__).resolve().parent;engine=sys.argv[1]
if engine=='native':import torch
else:
    torch,tensor_module,_=load_library(root/engine/'stridetorch','precision_'+engine)
    if engine=='candidate':tensor_module._WASM_MATMUL=True
rows=[]
for shape in [(128,64,128),(64,128,128),(64,256,64)]:
    for order in ['C','F','stride','broadcast']:
        m,k,n=shape;rng=np.random.default_rng(76040)
        arrays=[layout(rng.uniform(-1,1,size=dimensions).astype('float32'),order) for dimensions in [(m,k),(k,n),(m,k),(k,n)]]
        args=[torch.from_numpy(x).requires_grad_(i<2) for i,x in enumerate(arrays)]
        _,hessian=torch.autograd.functional.hvp(lambda x,w:(x@w).square().sum()*.5,tuple(args[:2]),tuple(args[2:]))
        a,b,ta,tb=[x.astype('float64') for x in arrays];y=a@b;dy=ta@b+a@tb
        controls=[dy@b.T+y@tb.T,ta.T@y+a.T@dy]
        errors=[float(np.max(np.abs(x.detach().numpy().astype('float64')-y))) for x,y in zip(hessian,controls)]
        rows.append(dict(shape=shape,layout=order,maximum_absolute_errors=errors))
report=dict(engine=engine,torch=getattr(torch,'__version__','compat'),numpy=np.__version__,rows=rows)
name='hvp-precision-'+engine+('-'+str(torch.__version__) if engine=='native' else '')+'.json'
(root/name).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(file=name,max_absolute_error=max(max(r['maximum_absolute_errors']) for r in rows))))
