from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
target='ffa9d1912abd176bace4767fdb6cb6c97adcb4bc'
def api(endpoint,name):
 x=json.loads(subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/'+endpoint],cwd=repo,text=True));write(r/name,x);return x
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
remote=api('git/ref/heads/main','remote-main.json');assert remote['object']['sha']==target
commit=api('git/commits/'+target,'remote-commit.json');assert commit['sha']==target
root_tree=git('rev-parse',target+'^{tree}').decode().strip();assert commit['tree']['sha']==root_tree
prefix='packages/stridetorch/src/stridetorch';subtree=git('rev-parse',target+':'+prefix).decode().strip();tree=api('git/trees/'+subtree,'remote-runtime-tree.json');assert tree['sha']==subtree and not tree['truncated']
resources=read(b/'torch-iteration-360/result.json')['resources'];entries={x['path']:x for x in tree['tree']};assert set(entries)==set(resources)
for name,h in resources.items():
 payload=git('show',target+':'+prefix+'/'+name);assert hashlib.sha256(payload).hexdigest()==h,name
 object_id=hashlib.sha1(b'blob '+str(len(payload)).encode()+b'\0'+payload).hexdigest();assert entries[name]['sha']==object_id and entries[name]['type']=='blob',name
exports=read(b/'torch-iteration-398/live-export-sha256.json')
for name,h in exports.items():assert hashlib.sha256(git('show',target+':web/public/data/'+name)).hexdigest()==h,name
pages=api('pages','pages.json');assert pages['build_type']=='legacy' and pages['source']==dict(branch='gh-pages',path='/')
runs=api('actions/runs?head_sha='+target+'&per_page=100','workflow-runs.json');assert runs['total_count']==0 and not runs['workflow_runs']
receipt=read(b/'torch-iteration-402/adoption-push-receipt.json');assert receipt['exit_code']==0 and receipt['ordinary_no_tag_push'] and receipt['mandatory_wrapper_unchanged']
assert receipt['scoped_git_config']['push.negotiate']=='true'
result=dict(status='verified_main_adoption_without_ci_or_publication',version='0.81.0',adopted_commit=target,verified_remote_sha=remote['object']['sha'],verified_utc=datetime.now(timezone.utc).isoformat(),remote_root_tree=root_tree,remote_runtime_subtree=subtree,runtime_resources=resources,runtime_files_verified_from_remote_commit_tree=True,export_identities_verified_from_same_commit=len(exports),qualified_application_head=read(b/'torch-iteration-398/result.json')['head'],full_frontend_commands_at_code_baseline=204,fresh_append_only_data_checks=2,both_current_builds_passed=True,actual_chrome_worker_passed=True,main_adopted=True,workflow_runs_for_adopted_commit=0,ci_triggered=False,tags_pushed=False,published=False,deployed=False,pages_source=pages['source'],ordinary_guarded_push=True,standard_object_negotiation=True,mandatory_wrapper_sha256=sha(b/'torch-iteration-67/final-integration/push-main-native.py'),successful_push_seconds=receipt['seconds'],successful_push_log_sha256=receipt['log_sha256'],known_raw_wasm_norm_hvp_point_gate_passed=False,production_torch_gpu_backend_enabled=False,terminal_hvp_optimization_enabled_in_production=False,goal_status='active')
write(r/'result.json',result);print(json.dumps({k:v for k,v in result.items() if k!='runtime_resources'}),flush=True)
