from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
assert not (r/'qualification-grant.json').exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip()
application=read(b/'torch-iteration-398/result.json');assert application['status']=='passed_local_application_catalog_export_frontend_worker_gates'
for name,h in read(b/'torch-iteration-398/static-inputs.json').items():assert sha(repo/name)==h,name
delta=subprocess.check_output(['git','diff','--name-only',application['head'],'HEAD'],cwd=repo,text=True).splitlines()
assert all(name.startswith(('docs/validation/','packages/stridetorch/benchmarks/results/')) for name in delta),delta
for name,h in read(b/'torch-iteration-366/source-plan.json')['inputs'].items():assert sha(Path(name))==h,name
resources=read(b/'torch-iteration-360/result.json')['resources'];assert len(resources)==65
for name,h in resources.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==h,name
write(r/'source-hashes.json',resources)
exports=read(b/'torch-iteration-398/live-export-sha256.json');assert len(exports)==183
for name,h in exports.items():assert sha(repo/'web/public/data'/name)==h,name
write(r/'live-export-sha256.json',exports)
for name,h in read(r/'release-policy-identity.json')['files'].items():assert sha(repo/name)==h,name
wrapper=b/'torch-iteration-67/final-integration/push-main-native.py';assert sha(wrapper)=='4b51422c5533ca6177a4a29a557cf37d1c6727d7530908e444be5833588c2882'
required={}
for name in ['qualification-0.81.json','qualification-0.81-main-sync.json','qualification-0.81-data-followup.json']:
 aggregate=read(repo/'packages/stridetorch/benchmarks/results'/name);receipt=aggregate.get('raw_archive',aggregate.get('archive'));archive=repo/receipt['path'];assert sha(archive)==receipt['sha256']
 with tarfile.open(archive) as stream:manifest=json.load(stream.extractfile('sha256.json'))
 for path,h in manifest.items():assert sha(b/path)==h,path;required[str(b/path)]=h
for p in list(r.glob('*.py'))+[r/'guard-provenance.json',r/'release-policy-identity.json',r/'release-policy-variants.json',wrapper,b/'torch-iteration-356/result.json',b/'torch-iteration-360/result.json',b/'torch-iteration-389/result.json']:
 required[str(p)]=sha(p)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();files=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0');reviewed={name:sha(repo/name) for name in files if name}
write(r/'qualification-grant.json',dict(head=head,source_resources=65,runtime_resources=resources,ci_triggered=False,version='0.81.0',local_qualification_complete=True,required_files=[dict(path=name,sha256=h) for name,h in required.items()],reviewed_commit_files=reviewed))
write(r/'grant-receipt.json',dict(head=head,tracked_files=len(reviewed),raw_required_files=len(required),qualified_application_head=application['head'],post_qualification_delta=delta,ci_triggered=False,goal_status='active'));print(json.dumps(dict(head=head,tracked_files=len(reviewed),raw_required_files=len(required))))
