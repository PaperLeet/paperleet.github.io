from pathlib import Path
import hashlib,io,json,shutil,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
result=json.loads((b/'torch-iteration-403/result.json').read_text());assert result['status']=='verified_main_adoption_without_ci_or_publication'
files=[p for n in [402,403,404] for p in (b/f'torch-iteration-{n}').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='archive-receipt.json'];manifest={str(p.relative_to(b)):sha(p) for p in files}
destination=out/'qualification-0.81-main-adoption-harness.tar.gz';assert not destination.exists()
with tarfile.open(destination,'w:gz') as stream:
 for p in files:stream.add(p,arcname=str(p.relative_to(b)),recursive=False)
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256.json');info.size=len(data);stream.addfile(info,io.BytesIO(data))
with tarfile.open(destination) as stream:
 for name,h in manifest.items():assert hashlib.sha256(stream.extractfile(name).read()).hexdigest()==h,name
receipt=dict(path=str(destination.relative_to(repo)),files=len(files),bytes=destination.stat().st_size,sha256=sha(destination),verified_all_payloads=True);write(r/'archive-receipt.json',receipt)
result['raw_archive']=receipt;write(out/'qualification-0.81-main-adoption.json',result)
doc=repo/'docs/validation/torch-runtime-0.81-qualification.md';doc.write_text(doc.read_text()+f'\n## Verified main adoption\n\nMain adopted 0.81 at **`{result["adopted_commit"]}`**. The remote Git commit\nroot and runtime subtree match the verified local commit. Every one of the 65\nruntime/license blobs and all 183 active export identities match the qualified\nhashes. The current code baseline passed all 204 frontend commands; the later\nappend-only data delta passed its two checks, both builds and the real Worker.\n\nGitHub reports zero workflow runs for the adopted commit at the recorded\nverification time. No CI/manual workflow, tag, package publication or deployment\nwas initiated. Pages remains legacy `gh-pages /`. The successful ordinary\nnative push used the unchanged mandatory wrapper and fresh full source/release\nguards, with standard object negotiation; it completed in about 10.13 seconds.\nThe known raw norm/sine WASM discrepancy remains and the production GPU backend\nand experimental terminal-HVP change remain disabled. The broader library goal\ncontinues.\n\n[Remote adoption receipt](../../packages/stridetorch/benchmarks/results/qualification-0.81-main-adoption.json)\nand [raw audit/remote-tree archive](../../{receipt["path"]}):\n{receipt["files"]} verified files, {receipt["bytes"]:,} bytes, SHA-256\n`{receipt["sha256"]}`.\n')
print(json.dumps(receipt),flush=True)
