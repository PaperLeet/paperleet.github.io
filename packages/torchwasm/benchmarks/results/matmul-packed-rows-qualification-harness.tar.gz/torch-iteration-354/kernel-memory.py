import gc
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tracemalloc
import weakref
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parent
bench=root.parent/'torch-iteration-346'
plan=json.loads((root/'plan.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
    assert sha(Path(__file__))==plan['runner_sha256']
    for name,digest in plan['inputs'].items():assert sha(Path(name))==digest,name
verify();sys.path.insert(0,str(bench))
import numpy as np
import workloads
kernels={}
for label in ('A0','A1','B'):
    folder=bench/('candidate' if label=='B' else 'baseline');name='_kernel_memory_'+label
    spec=importlib.util.spec_from_file_location(name,str(folder/'__init__.py'),submodule_search_locations=[str(folder)])
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    api=module.torch
    kernels[label]=sys.modules[name+'._matmul'].product
oracle=np.load(bench/'native26.npz',allow_pickle=False)
rows=[]
for index,spec in enumerate(workloads.specifications()):
    values=workloads.make_inputs(spec);a,b,g=values;before=workloads.fingerprint(values)
    calls=[('forward',a,b,0)]
    if spec['active'][0]:calls.append(('left_vjp',g,b.T,1))
    if spec['active'][1]:calls.append(('right_vjp',a.T,g,1+int(spec['active'][0])))
    observations=[]
    for operation,left,right,output_index in calls:
        expected=oracle[f'case{index}_output{output_index}'];details={}
        for label,kernel in kernels.items():
            np.testing.assert_array_equal(kernel(left,right),expected)
            refs=[];copy_sizes=[];original=np.ascontiguousarray
            def observed(value,*args,**kwargs):
                output=original(value,*args,**kwargs)
                if not np.shares_memory(value,output):
                    refs.append(weakref.ref(output));copy_sizes.append(output.nbytes)
                return output
            gc.collect();tracemalloc.start(5)
            try:
                np.ascontiguousarray=observed
                output=kernel(left,right)
                current,peak=tracemalloc.get_traced_memory()
                np.testing.assert_array_equal(output,expected)
                del output;gc.collect();remaining=sum(ref() is not None for ref in refs)
                assert remaining==0,(spec,operation,label)
            finally:
                np.ascontiguousarray=original;tracemalloc.stop()
            details[label]=dict(peak_traced_bytes=peak,current_with_output=current,contiguous_copy_sizes=copy_sizes,
                                contiguous_copy_bytes=sum(copy_sizes),copy_owners_remaining=remaining)
        observations.append(dict(operation=operation,details=details,additional_peak_bytes=details['B']['peak_traced_bytes']-details['A0']['peak_traced_bytes']))
    assert workloads.fingerprint(values)==before
    row=dict(spec=spec,operations=observations);rows.append(row)
    print(json.dumps(dict(key=spec['key'],max_additional_kernel_peak=max(o['additional_peak_bytes'] for o in observations))),flush=True)
verify()
report=dict(status='passed_per_kernel_allocation_diagnostic',numpy=np.__version__,rows=rows,
            scope='CPython tracemalloc for exact candidate/base product kernels, separately from full calls. Not actual browser RSS. Copied contiguous-array owners all released; numerical outputs match native2.6.',
            plan_sha256=sha(root/'plan.json'))
(root/(sys.argv[1]+'-result.json')).write_text(json.dumps(report,indent=2)+'\n')
