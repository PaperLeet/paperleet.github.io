import hashlib
import json
from pathlib import Path
import sys
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root))
import numpy as np
import torch
import workloads
arrays={};cases=[]
for index,spec in enumerate(workloads.specifications()):
    values=workloads.make_inputs(spec);before=workloads.fingerprint(values)
    outputs=workloads.MatrixFlow(torch,spec,values)()
    for i,value in enumerate(outputs):arrays[f'case{index}_output{i}']=value
    assert workloads.fingerprint(values)==before
    cases.append(dict(spec=spec,fingerprint=before))
np.savez_compressed(root/'native26.npz',**arrays)
(root/'native-meta.json').write_text(json.dumps(dict(torch=torch.__version__,numpy=np.__version__,cases=cases),indent=2)+'\n')
print(json.dumps(dict(status='native_controls_created',cases=len(cases),outputs=len(arrays),torch=torch.__version__)))
