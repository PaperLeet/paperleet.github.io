"""Shared whole-call matrix workloads for native oracles and paired WASM timing."""
import hashlib
import numpy as np


def specifications():
    rows=[]
    for size in (128,256):
        for dtype in ('float32','float64'):
            for layout in ('C','F','stride','broadcast'):
                rows.append(dict(key=f'{size}/{dtype}/{layout}/both',shape=(size,size,size),dtype=dtype,
                                 layouts=(layout,)*3,active=(True,True)))
    rows += [dict(key=f'{size}/float32/C/both',shape=(size,)*3,dtype='float32',layouts=('C',)*3,active=(True,True)) for size in (512,64)]
    for name,shape,dtype,layouts,active in (
        ('threshold',(128,64,128),'float32',('C',)*3,(True,True)),
        ('below_threshold',(127,64,128),'float32',('C',)*3,(True,True)),
        ('rect_F',(64,256,64),'float64',('F',)*3,(True,True)),
        ('tall',(1024,64,32),'float32',('C',)*3,(True,True)),
        ('wide_reduction',(32,1024,32),'float64',('stride',)*3,(True,True)),
        ('mixed',(128,64,128),'float64',('F','C','stride'),(True,True)),
        ('left_only',(256,256,256),'float32',('C',)*3,(True,False)),
        ('right_only',(256,256,256),'float32',('C',)*3,(False,True)),
        ('forward_only',(256,256,256),'float64',('C',)*3,(False,False)),
    ):
        rows.append(dict(key=name,shape=shape,dtype=dtype,layouts=layouts,active=active))
    assert len(rows)==27
    return rows


def arrange(value, layout):
    if layout in ('C','F'):
        return value.copy(order=layout)
    if layout=='broadcast':
        return np.broadcast_to(value[:1],value.shape)
    storage=np.empty((value.shape[0]*2,value.shape[1]*2),dtype=value.dtype)
    storage[::2,::2]=value
    return storage[::2,::2]


def make_inputs(spec):
    m,k,n=spec['shape']
    values=tuple(arrange(((np.arange(rows*cols)%mod-center)/8).astype(spec['dtype']).reshape(rows,cols),layout)
                 for (rows,cols,mod,center),layout in zip(((m,k,17,8),(k,n,13,6),(m,n,11,5)),spec['layouts']))
    for value in values:
        value.flags.writeable=False
    return values


def fingerprint(values):
    return [(str(v.dtype),v.shape,v.strides,v.flags.writeable,hashlib.sha256(v.tobytes()).hexdigest()) for v in values]


class MatrixFlow:
    def __init__(self, api, spec, values):
        self.spec=spec
        self.inputs=tuple(api.from_numpy(value).requires_grad_(bool(active))
                          for value,active in zip(values,(*spec['active'],False)))
        self.api=api
        assert all(tensor.data_ptr()==value.__array_interface__['data'][0] for tensor,value in zip(self.inputs,values))
        self.targets=tuple(tensor for tensor,active in zip(self.inputs[:2],spec['active']) if active)

    def __call__(self):
        a,b,g=self.inputs
        y=a@b
        gradients=self.api.autograd.grad(y,self.targets,g) if self.targets else ()
        assert a.grad is None and b.grad is None
        return tuple(value.detach().numpy().copy() for value in (y,*gradients))
