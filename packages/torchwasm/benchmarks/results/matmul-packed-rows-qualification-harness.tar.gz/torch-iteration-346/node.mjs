import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
const root=new URL('./',import.meta.url),cycle=Number(process.argv[2]),validateOnly=process.argv.includes('--validate-only');
assert([0,1,2].includes(cycle));
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const plan=JSON.parse(fs.readFileSync(new URL('source-plan.json',root)));
const output=new URL(`${validateOnly?'validation':'latency'}-node-${cycle}.json`,root);assert(!fs.existsSync(output));
function verify(){for(const [name,digest] of Object.entries(plan.files))assert.equal(hash(fs.readFileSync(new URL(name,root))),digest,name);}
verify();
let prerequisites=null;
if(!validateOnly){prerequisites=JSON.parse(fs.readFileSync(new URL('measurement-prerequisites.json',root)));assert(prerequisites.ready);assert.equal(prerequisites.source_plan_sha256,hash(fs.readFileSync(new URL('source-plan.json',root))));}
try{
 const py=await loadPyodide({indexURL:new URL('../torch-iteration-76/runtime/',root).pathname,stdout(message){if(message.startsWith('PACK_'))console.log(message);},stderr:console.error});
 await py.loadPackage('numpy');py.runPython('import sys;sys.dont_write_bytecode=True;sys.path.insert(0,"/")');
 for(const name of Object.keys(plan.files)){
  if(name.startsWith('baseline/')||name.startsWith('candidate/')||['workloads.py','benchmark.py','native26.npz','native-meta.json'].includes(name)){
   py.FS.mkdirTree('/'+name.split('/').slice(0,-1).join('/'));py.FS.writeFile('/'+name,fs.readFileSync(new URL(name,root)));
  }
 }
 py.globals.set('cycle',cycle);py.globals.set('validate_only',validateOnly);
 const report=JSON.parse(py.runPython('import json,benchmark\njson.dumps(benchmark.run(cycle,validate_only))'));
 verify();assert.equal(report.rows.length,27);
 fs.writeFileSync(output,JSON.stringify({...report,pyodide:py.version,node:process.version,plan_sha256:hash(fs.readFileSync(new URL('source-plan.json',root))),prerequisites},null,2)+'\n');
 console.log(JSON.stringify({status:report.status,cycle,rows:report.rows.length,aa_passed:report.all_aa_passed}));
}catch(error){fs.writeFileSync(new URL(`${validateOnly?'validation':'latency'}-node-${cycle}-failure.json`,root),JSON.stringify({error:String(error.stack||error)},null,2)+'\n');throw error;}
