import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import os

root=Path(__file__).resolve().parent
for label in ('baseline','candidate'):
    shutil.copytree(root.parent/'torch-iteration-340'/label,root/label)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
command=[str(root.parent/'torch-iteration-137/native26-env/bin/python'),'-I','-B',str(root/'native.py')]
with (root/'native.log').open('w') as output:
    subprocess.run(command,env=env,stdout=output,stderr=subprocess.STDOUT,check=True)
plan=dict(source_commit='29e96600663a86c6f24f40cb3e1d8d378508946e',candidate_source=340,
          cases=27,runtimes=['node','chrome'],fresh_process_cycles=[0,1,2],
          scope='Full public matrix forward, requested two/one/zero inputVJPs and owned snapshots; shared readonly physical operands. Existing18 flows plus9 rectangles/thresholds/gradientmodes.',
          controls='All6implementation permutations followedbyreverse,12rounds;calibration100ms,measurement45ms,cap8192. GCdisabled;eachlastoutputverifiedagainstnativeTorch2.6outsideclock. InputfingerprintandNumPyerrorstate/GCchecked.',
          decision='EveryAApairedmedianmustbe[.95,1.05];flagB/A0>1.10perprocessandacrossmedians. Preserveeveryflow/process/failure;nofavorablereruns. Do notclaimproductionreadinessfromtimingalone.',
          prerequisites='Complete preflight in both runtimes before timing. Native NP1.26/2.5 targeted and fullNodeSDK from341/342 retained; this candidate isbyteidentical.',
          files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()})
(root/'source-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps(dict(status='frozen',files=len(plan['files']))))
