import gc
import hashlib
import importlib.util
import itertools
import json
import math
from pathlib import Path
import statistics
import sys
import time
import numpy as np
import workloads


def load(root,label):
    name='_packed_formal_'+label
    spec=importlib.util.spec_from_file_location(name,root+'/__init__.py',submodule_search_locations=[root])
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module
    spec.loader.exec_module(module)
    return module.torch


def verify(actual,expected,values):
    assert len(actual)==len(expected)
    for value,reference in zip(actual,expected):
        assert value.flags.owndata and value.dtype==reference.dtype and value.shape==reference.shape
        assert all(not np.shares_memory(value,source) for source in values)
        np.testing.assert_array_equal(value,reference)


def timed(call,count):
    start=time.perf_counter()
    for _ in range(count):
        output=call()
    return time.perf_counter()-start,output


def run(cycle,validate_only=False):
    assert cycle in (0,1,2) and sys.platform=='emscripten'
    apis={label:load('/candidate' if label=='B' else '/baseline',label) for label in ('A0','A1','B')}
    oracle=np.load('/native26.npz',allow_pickle=False)
    meta=json.loads(Path('/native-meta.json').read_text())
    rows=[];specs=list(enumerate(workloads.specifications()));specs=specs[cycle:]+specs[:cycle]
    orders=list(itertools.permutations(('A0','A1','B')))
    orders=orders[cycle:]+orders[:cycle];orders+=list(reversed(orders))
    err,handler=np.geterr(),np.geterrcall();initial_gc=gc.isenabled()
    for index,spec in specs:
        values=workloads.make_inputs(spec);before=workloads.fingerprint(values)
        assert json.loads(json.dumps(before))==meta['cases'][index]['fingerprint']
        calls={label:workloads.MatrixFlow(api,spec,values) for label,api in apis.items()}
        expected=tuple(oracle[f'case{index}_output{i}'] for i in range(1+sum(spec['active'])))
        for call in calls.values():verify(call(),expected,values)
        if validate_only:
            rows.append(dict(spec=spec,validated=True));continue
        print('PACK_PROGRESS '+spec['key'],flush=True)
        gc.collect();gc.disable()
        calibration={};counts={};raw=[]
        try:
            for label,call in calls.items():
                count=1;samples=[]
                while True:
                    elapsed,output=timed(call,count)
                    samples.append(dict(iterations=count,elapsed_seconds=elapsed))
                    verify(output,expected,values)
                    if elapsed>=.1 or count==8192:break
                    count=min(8192,max(count+1,math.ceil(count*.12/max(elapsed,1e-6))))
                calibration[label]=samples
                counts[label]=min(8192,max(1,math.ceil(count*.045/elapsed)))
            for round_index,order in enumerate(orders):
                sample={}
                for label in order:
                    elapsed,output=timed(calls[label],counts[label])
                    verify(output,expected,values)
                    sample[label]=dict(iterations=counts[label],elapsed_seconds=elapsed,seconds_per_call=elapsed/counts[label])
                raw.append(dict(round=round_index,order=order,samples=sample))
        finally:
            if initial_gc:gc.enable()
        assert workloads.fingerprint(values)==before
        ratios={pair:statistics.median(s['samples'][left]['seconds_per_call']/s['samples'][right]['seconds_per_call'] for s in raw)
                for pair,left,right in (('A1/A0','A1','A0'),('B/A0','B','A0'))}
        row=dict(spec=spec,calibration=calibration,raw=raw,ratios=ratios,aa_passed=.95<=ratios['A1/A0']<=1.05,
                 inputs_unchanged=True,shared_readonly_operands=True,owned_outputs=True,
                 min_chunk_seconds={label:min(s['samples'][label]['elapsed_seconds'] for s in raw) for label in calls},
                 median_seconds={label:statistics.median(s['samples'][label]['seconds_per_call'] for s in raw) for label in calls})
        rows.append(row);print('PACK_SAMPLE '+json.dumps(row),flush=True)
    assert np.geterr()==err and np.geterrcall() is handler and gc.isenabled()==initial_gc
    return dict(status='validated' if validate_only else 'completed',cycle=cycle,rows=rows,numpy=np.__version__,
                all_aa_passed=all(r.get('aa_passed',True) for r in rows),source_sha256={name:{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('/'+name).iterdir() if p.is_file()} for name in ('baseline','candidate')},
                scope='27 native-controlled whole-call flows, actual public forward/selected VJPs/owned copies. Three independent imports; no implementation selection or production change.')
