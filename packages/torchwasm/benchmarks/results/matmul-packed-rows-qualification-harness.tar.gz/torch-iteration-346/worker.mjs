import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
self.onmessage=async({data})=>{
 try{
  const plan=await(await fetch('./source-plan.json')).json();
  const py=await loadPyodide({indexURL:new URL('../torch-iteration-76/runtime/',self.location.href).href,
   stdout(message){if(message.startsWith('PACK_'))self.postMessage({status:'progress',message});},stderr(message){self.postMessage({status:'diagnostic',message});}});
  await py.loadPackage('numpy');py.runPython('import sys;sys.dont_write_bytecode=True;sys.path.insert(0,"/")');
  for(const [name,digest] of Object.entries(plan.files)){
   const response=await fetch('./'+name);if(!response.ok)throw Error('Missing '+name);
   const bytes=new Uint8Array(await response.arrayBuffer());
   const actual=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),v=>v.toString(16).padStart(2,'0')).join('');
   if(actual!==digest)throw Error('Changed '+name);
   if(name.startsWith('baseline/')||name.startsWith('candidate/')||['workloads.py','benchmark.py','native26.npz','native-meta.json'].includes(name)){
    py.FS.mkdirTree('/'+name.split('/').slice(0,-1).join('/'));py.FS.writeFile('/'+name,bytes);
   }
  }
  py.globals.set('cycle',data.cycle);py.globals.set('validate_only',data.validateOnly);
  const report=JSON.parse(py.runPython('import json,benchmark\njson.dumps(benchmark.run(cycle,validate_only))'));
  self.postMessage({status:'completed',report,pyodide:py.version});
 }catch(error){self.postMessage({status:'failed',error:String(error.stack||error)});}
};
