import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {withFixtureServer} from '../torch-iteration-70/fixture-server.mjs';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const root=new URL('./',import.meta.url),cycle=Number(process.argv[2]),validateOnly=process.argv.includes('--validate-only');
assert([0,1,2].includes(cycle));
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const plan=JSON.parse(fs.readFileSync(new URL('source-plan.json',root)));
const output=new URL(`${validateOnly?'validation':'latency'}-chrome-${cycle}.json`,root);assert(!fs.existsSync(output));
function verify(){for(const [name,digest] of Object.entries(plan.files))assert.equal(hash(fs.readFileSync(new URL(name,root))),digest,name);}
verify();let prerequisites=null;
if(!validateOnly){prerequisites=JSON.parse(fs.readFileSync(new URL('measurement-prerequisites.json',root)));assert(prerequisites.ready);assert.equal(prerequisites.source_plan_sha256,hash(fs.readFileSync(new URL('source-plan.json',root))));}
await withFixtureServer(async origin=>{
 let browser;
 try{
  browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
  const page=await browser.newPage();page.on('console',event=>console.log(event.text()));
  await page.goto(origin+'/torch-iteration-346/index.html');
  const result=await page.evaluate(({cycle,validateOnly})=>new Promise((resolve,reject)=>{
   const worker=new Worker('./worker.mjs',{type:'module'});
   const timer=setTimeout(()=>{worker.terminate();reject(Error('Matrix fixture deadline180s'));},180000);
   worker.onmessage=({data})=>{if(data.status==='progress'||data.status==='diagnostic'){console.log(data.message);return;}clearTimeout(timer);worker.terminate();resolve(data);};
   worker.onerror=event=>{clearTimeout(timer);worker.terminate();reject(Error(event.message));};worker.postMessage({cycle,validateOnly});
  }),{cycle,validateOnly});
  verify();fs.writeFileSync(output,JSON.stringify({...result,browser:browser.version(),plan_sha256:hash(fs.readFileSync(new URL('source-plan.json',root))),prerequisites},null,2)+'\n');
  assert.equal(result.status,'completed',JSON.stringify(result));assert.equal(result.report.rows.length,27);
  console.log(JSON.stringify({status:result.report.status,cycle,rows:result.report.rows.length,aa_passed:result.report.all_aa_passed}));
 }catch(error){fs.writeFileSync(new URL(`${validateOnly?'validation':'latency'}-chrome-${cycle}-failure.json`,root),JSON.stringify({error:String(error.stack||error)},null,2)+'\n');throw error;}
 finally{if(browser)await browser.close();}
});
