import hashlib
import json
from pathlib import Path
import statistics

root=Path(__file__).resolve().parent
bench=root.parent/'torch-iteration-346'
run=root.parent/'torch-iteration-347'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
progress=read(run/'progress.json');assert progress['status']=='completed' and len(progress['receipts'])==6
plan=read(bench/'source-plan.json')
for name,digest in plan['files'].items():assert sha(bench/name)==digest,name
rows={};processes=[]
for cycle in (0,1,2):
    for runtime in ('node','chrome'):
        path=bench/f'latency-{runtime}-{cycle}.json';wrapped=read(path);report=wrapped.get('report',wrapped)
        assert report['status']=='completed' and report['cycle']==cycle and len(report['rows'])==27
        assert wrapped['plan_sha256']==sha(bench/'source-plan.json')
        raw=[json.loads(line[len('PACK_SAMPLE '):]) for line in (run/f'{runtime}-{cycle}.log').read_text().splitlines() if line.startswith('PACK_SAMPLE ')]
        assert raw==report['rows']
        for name in ('baseline','candidate'):
            assert report['source_sha256'][name]=={p.name:sha(p) for p in (bench/name).iterdir() if p.is_file()}
        for row in raw:
            assert len(row['raw'])==12 and all(len(sample['order'])==3 for sample in row['raw'])
            assert row['shared_readonly_operands'] and row['inputs_unchanged'] and row['owned_outputs']
            assert all(row['calibration'][label][-1]['elapsed_seconds']>=.1 for label in ('A0','A1','B'))
            assert sorted(tuple(s['order']) for s in row['raw'][:6])==sorted(tuple(s['order']) for s in row['raw'][6:])
            rows.setdefault(runtime,{}).setdefault(row['spec']['key'],[]).append(dict(cycle=cycle,**row))
        processes.append(dict(runtime=runtime,cycle=cycle,source_sha256=report['source_sha256'],result_sha256=sha(path),
                              browser=wrapped.get('browser'),node=wrapped.get('node'),pyodide=wrapped['pyodide'],numpy=report['numpy'],
                              aa_findings=[r['spec']['key'] for r in raw if not r['aa_passed']],
                              regressions_over_ten_percent=[r['spec']['key'] for r in raw if r['ratios']['B/A0']>1.10]))
aggregate={}
for runtime,cases in rows.items():
    aggregate[runtime]={}
    assert len(cases)==27
    for key,observations in cases.items():
        assert len(observations)==3 and [o['cycle'] for o in observations]==[0,1,2]
        ratios=[o['ratios']['B/A0'] for o in observations]
        controls=[o['ratios']['A1/A0'] for o in observations]
        aggregate[runtime][key]=dict(spec=observations[0]['spec'],median_ratio=statistics.median(ratios),per_process_ratios=ratios,
                                    aa_controls=controls,all_aa_passed=all(.95<=v<=1.05 for v in controls),
                                    min_chunk_ms=1000*min(min(o['min_chunk_seconds'].values()) for o in observations),
                                    baseline_median_ms=1000*statistics.median(o['median_seconds']['A0'] for o in observations),
                                    candidate_median_ms=1000*statistics.median(o['median_seconds']['B'] for o in observations))
    print(runtime,'ratio range',min(v['median_ratio'] for v in aggregate[runtime].values()),max(v['median_ratio'] for v in aggregate[runtime].values()),
          'min chunk ms',min(v['min_chunk_ms'] for v in aggregate[runtime].values()))
findings=dict(aa=sum(len(p['aa_findings']) for p in processes),per_process_over_ten_percent=sum(len(p['regressions_over_ten_percent']) for p in processes),
              median_over_ten_percent={runtime:[k for k,v in cases.items() if v['median_ratio']>1.1] for runtime,cases in aggregate.items()})
result=dict(status='completed_three_process_node_chrome_matrix_performance',findings=findings,processes=processes,aggregate=aggregate,
            all_samples_retained=True,favorable_reruns=False,selected=False,production_changed=False,goal_status='active',
            scope='27native-controlled completeforward/selectedgradients/ownedcopies flows in3freshNode and3freshChrome processes. Timing alone does not prove full package/application/memory readiness.')
(root/'performance.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(findings))
