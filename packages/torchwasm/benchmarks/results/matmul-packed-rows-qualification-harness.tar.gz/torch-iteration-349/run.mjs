import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {withFixtureServer} from '../torch-iteration-70/fixture-server.mjs';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const root=new URL('./',import.meta.url),hash=bytes=>createHash('sha256').update(bytes).digest('hex');
assert(!fs.existsSync(new URL('result.json',root)));
const campaign=JSON.parse(fs.readFileSync(new URL('../torch-iteration-347/progress.json',root)));assert.equal(campaign.status,'completed');
const plan=JSON.parse(fs.readFileSync(new URL('source-plan.json',root)));
function verify(){
 for(const [name,digest] of Object.entries(plan.files))assert.equal(hash(fs.readFileSync(new URL(name,root))),digest,name);
 for(const [name,item] of Object.entries(plan.payload))assert.equal(hash(fs.readFileSync(new URL(item.source,root))),item.sha256,name);
}
verify();await withFixtureServer(async origin=>{
 let browser;
 try{
  browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
  const page=await browser.newPage();page.on('console',event=>console.log(event.text()));await page.goto(origin+'/torch-iteration-349/index.html');
  const result=await page.evaluate(()=>new Promise((resolve,reject)=>{
   const worker=new Worker('./worker.mjs',{type:'module'}),timer=setTimeout(()=>{worker.terminate();reject(Error('SDK deadline360s'));},360000);
   worker.onmessage=({data})=>{if(data.status==='progress'||data.status==='diagnostic'){console.log(data.message);return;}clearTimeout(timer);worker.terminate();resolve(data);};
   worker.onerror=event=>{clearTimeout(timer);worker.terminate();reject(Error(event.message));};worker.postMessage({});
  }));
  verify();fs.writeFileSync(new URL('result.json',root),JSON.stringify({...result,browser:browser.version(),source_plan_sha256:hash(fs.readFileSync(new URL('source-plan.json',root)))},null,2)+'\n');
  assert.equal(result.status,'completed',JSON.stringify(result));assert.equal(result.report.status,'passed_full_node_wasm_sdk');assert.equal(result.report.passed,12212);
  console.log(JSON.stringify({status:'passed_full_chrome_sdk',passed:12212,browser:browser.version()}));
 }catch(error){fs.writeFileSync(new URL('failure.json',root),JSON.stringify({error:String(error.stack||error)},null,2)+'\n');throw error;}
 finally{if(browser)await browser.close();}
});
