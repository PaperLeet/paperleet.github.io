import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
destination = repo / 'packages/stridetorch/benchmarks/results/matmul-packed-rows-qualification-harness.tar.gz'
files = sorted(p for directory in tuple('torch-iteration-'+str(n) for n in [342,*range(346,357)])
               for p in (root.parent / directory).rglob('*') if p.is_file() and p.name != 'archive-receipt.json')
manifest = {str(p.relative_to(root.parent)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with tarfile.open(destination, 'w:gz') as archive:
    for p in files:
        archive.add(p, arcname=str(p.relative_to(root.parent)), recursive=False)
    data = (json.dumps(manifest, indent=2) + '\n').encode()
    info = tarfile.TarInfo('sha256.json'); info.size = len(data)
    archive.addfile(info, io.BytesIO(data))
with tarfile.open(destination, 'r:gz') as archive:
    for name, expected in manifest.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected, name
receipt = dict(path=str(destination.relative_to(repo)), files=len(manifest), bytes=destination.stat().st_size,
               sha256=hashlib.sha256(destination.read_bytes()).hexdigest(), verified_all_payloads=True)
(root / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
