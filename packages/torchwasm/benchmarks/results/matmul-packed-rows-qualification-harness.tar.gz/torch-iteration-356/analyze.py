import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
base=root.parent
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
performance=read(base/'torch-iteration-350/performance.json')
assert performance['findings']==dict(aa=0,per_process_over_ten_percent=0,median_over_ten_percent=dict(node=[],chrome=[]))
assert read(base/'torch-iteration-353/result.json')['status']=='passed_candidate_memory_and_full_chrome_sdk'
memory={};kernel={}
for name in ('numpy25','numpy126'):
    full=read(base/'torch-iteration-352'/(name+'-result.json'))
    per_kernel=read(base/'torch-iteration-354'/(name+'-result.json'))
    assert len(full['rows'])==len(per_kernel['rows'])==27
    assert full['status']=='passed_forced_wasm_allocation_lifetime_diagnostic'
    assert per_kernel['status']=='passed_per_kernel_allocation_diagnostic'
    assert all(v['contiguous_copy_owners_remaining']==v['output_owners_remaining']==0 for row in full['rows'] for v in row['details'].values())
    assert all(v['copy_owners_remaining']==0 for row in per_kernel['rows'] for op in row['operations'] for v in op['details'].values())
    extra=[(row['spec']['key'],op['operation'],op['additional_peak_bytes']) for row in per_kernel['rows'] for op in row['operations']]
    memory[name]=dict(report_sha256=sha(base/'torch-iteration-352'/(name+'-result.json')),
                      full_call_extra_peak_range=[min(r['additional_peak_bytes'] for r in full['rows']),max(r['additional_peak_bytes'] for r in full['rows'])],
                      per_kernel_report_sha256=sha(base/'torch-iteration-354'/(name+'-result.json')),
                      max_kernel_extra_peak=max(extra,key=lambda r:r[2]))
wasm=read(base/'torch-iteration-355/result.json')
assert wasm['status']=='passed_actual_node_wasm_copy_lifetimes' and len(wasm['rows'])==27
assert all(v['copy_owners_remaining']==v['output_owners_remaining']==0 for row in wasm['rows'] for v in row['details'].values())
chrome=read(base/'torch-iteration-349/result.json');assert chrome['report']['passed']==12212 and chrome['report']['failures']==[]
source={name:{p.name:sha(p) for p in (base/'torch-iteration-346'/name).iterdir() if p.is_file()} for name in ('baseline','candidate')}
assert len(source['baseline'])==len(source['candidate'])==65
assert [name for name,digest in source['baseline'].items() if source['candidate'][name]!=digest]==['_matmul.py']
prior=read(base/'torch-iteration-345/result.json');assert prior['source_sha256']==source['candidate']
timing={}
for runtime,rows in performance['aggregate'].items():
    groups={}
    for name,selected in dict(strided=[v for k,v in rows.items() if '/' in k and v['spec']['layouts'][0]=='stride'],
                              broadcast=[v for v in rows.values() if 'broadcast' in v['spec']['layouts']],
                              dense_c_f=[v for k,v in rows.items() if '/' in k and not k.startswith('64/') and v['spec']['layouts'][0] in ('C','F')],
                              additional=[v for k,v in rows.items() if '/' not in k]).items():
        groups[name]=dict(rows=len(selected),median_ratio_range=[min(v['median_ratio'] for v in selected),max(v['median_ratio'] for v in selected)])
    timing[runtime]=dict(groups=groups,rows=rows,min_chunk_ms=min(v['min_chunk_ms'] for v in rows.values()))
result=dict(status='selected_packed_row_candidate_for_integration_after_scoped_qualification',candidate_source=340,
            selected_for_integration=True,production_runtime_changed=False,main_adopted=False,goal_status='active',
            source_sha256=source,performance=timing,performance_findings=performance['findings'],processes=performance['processes'],
            targeted_native_inherited=prior['targeted_native'],full_node_sdk_inherited=prior['full_node_wasm_sdk'],
            full_chrome_sdk=dict(passed=12212,browser=chrome['browser'],report_sha256=sha(base/'torch-iteration-349/result.json')),
            allocation_lifetime=memory,actual_wasm_lifetime=dict(report_sha256=sha(base/'torch-iteration-355/result.json'),
                flow_calls=27*3*30,max_live_contiguity_copy_bytes=max(v['peak_live_contiguous_copy_bytes'] for row in wasm['rows'] for v in row['details'].values()),
                heap_capacity_initial=wasm['rows'][0]['details']['A0']['heap_capacity_before'],heap_capacity_final=wasm['rows'][-1]['details']['B']['heap_capacity_after'],
                retained_copy_or_output_owners=0),
            retained_harness_failure=dict(source=348,supervisor=351,reason='Lazy torch namespace must materialize before looking up imported _tensor. Failed before measurements. Fresh352/353corrected harness, no candidate changes.'),
            limitations=['45ms measured batch target is not always reached; observed minima34.519msNode/38.5msChrome. Every sample retained.',
                         'CPython tracemalloc peaks are not browser RSS. ActualWASM instrumentation tracks contiguous-copy payloads/owners only; heapcapacity is retainedhighwater,not liveusage.',
                         'Three fresh processes per runtime on one machine, finite real dyadic timing data; prior randomized/exceptional/HVP tests retained.',
                         'Complete fullcall snapshots can mask individual kernel extra memory. Largest observed individualkernelextra1,835,306bytes; report both scopes.',
                         'Source is still an experimental0.80copy. Final version/comment/source changes and package/currentapplication/immutableexport/main-synchronization gates remain.'],
            next='Integrate as nextcandidateversion, preserve exact qualified expression, finalize source comments/version, and run current application/distribution/export gates before guardedmainadoption. Keep GPUdisabled and continue normHVP/coreAPI work.')
(root/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],memory=memory,wasm=result['actual_wasm_lifetime'])))
