import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
import {loadJudgePackages} from '../torch-iteration-76/chrome-sdk/packages.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const plan=JSON.parse(fs.readFileSync(root+'/source-plan.json','utf8'));
for(const [name,digest] of Object.entries(plan.files))assert.equal(hash(root+'/'+name),digest,name);
const py=await loadPyodide({indexURL:path.resolve(root,'../torch-iteration-76/runtime'),stdout:console.log,stderr:console.error});
await loadJudgePackages(py,[]);
py.runPython('import sys;sys.dont_write_bytecode=True');
for(const name of Object.keys(plan.files)){
 if(name.startsWith('candidate/')||name.startsWith('contracts/')){
  py.FS.mkdirTree('/'+path.dirname(name));py.FS.writeFile('/'+name,fs.readFileSync(root+'/'+name));
 }
}
py.FS.writeFile('/check-sdk.py',fs.readFileSync(root+'/check-sdk.py'));
try{
 const report=JSON.parse(py.runPython("exec(compile(open('/check-sdk.py').read(),'/check-sdk.py','exec'))\njson.dumps(report)"));
 for(const [name,digest] of Object.entries(plan.files))assert.equal(hash(root+'/'+name),digest,name);
 fs.writeFileSync(root+'/result.json',JSON.stringify({...report,pyodide:py.version,plan_sha256:hash(root+'/source-plan.json')},null,2)+'\n');
 assert.equal(report.status,'passed_full_node_wasm_sdk');
}catch(error){fs.writeFileSync(root+'/failure.json',JSON.stringify({error:String(error.stack||error)},null,2)+'\n');throw error;}
