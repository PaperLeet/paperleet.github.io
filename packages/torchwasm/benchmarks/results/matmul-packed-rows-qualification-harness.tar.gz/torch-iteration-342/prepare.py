import hashlib
import json
from pathlib import Path
import shutil

root=Path(__file__).resolve().parent
repo=Path('/Users/david/Developer/PaperLeet-torch-release')
shutil.copytree(root.parent/'torch-iteration-340/candidate',root/'candidate/stridetorch')
(root/'contracts').mkdir()
for p in (repo/'packages/stridetorch/tests').glob('*.py'):
    if p.name != 'test_standalone.py':
        shutil.copy2(p,root/'contracts'/p.name)
assert len(list((root/'contracts').glob('*.py')))==89
plan=dict(source_commit='a09b33b0',candidate='torch-iteration-340/candidate',expected_tests=12212,
          scope='Current89 SDK suites in actual Node/Pyodide. Only13 standalone native-process tests omitted, as in prior qualified WASM gates. No tolerance/test or default-limit changes.',
          files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()})
(root/'source-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps(dict(status='prepared',files=len(plan['files']))))
