"""One sequential campaign; failures and every planned timing result are retained."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import traceback

root=Path(__file__).resolve().parent
bench=root.parent/'torch-iteration-346'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
plan=read(root/'plan.json');receipts=[]

def verify():
    assert sha(Path(__file__))==plan['runner_sha256']
    assert sha(bench/'source-plan.json')==plan['source_plan_sha256']
    for name,digest in read(bench/'source-plan.json')['files'].items():assert sha(bench/name)==digest,name
    assert sha(bench/'measurement-prerequisites.json')==plan['prerequisites_sha256']


def progress(status,**extra):
    write(root/'progress.json',dict(status=status,pid=os.getpid(),observed_unix=time.time(),receipts=receipts,**extra))


try:
    verify()
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
    for key in ('NODE_OPTIONS','PYTHONTRACEMALLOC','PYTHONPROFILEIMPORTTIME'):env.pop(key,None)
    for cycle in (0,1,2):
        for runtime in ('node','chrome'):
            verify();label=f'{runtime}-{cycle}';log=root/(label+'.log');target=bench/f'latency-{runtime}-{cycle}.json'
            assert not target.exists() and not log.exists(),label
            command=['/opt/homebrew/bin/node',str(bench/(runtime+'.mjs')),str(cycle)]
            started=time.time()
            with log.open('w') as output:
                child=subprocess.Popen(command,cwd=bench,env=env,stdout=output,stderr=subprocess.STDOUT)
                progress('running',label=label,child_pid=child.pid,command=command)
                print(json.dumps(dict(status='running',label=label,pid=child.pid)),flush=True)
                code=child.wait()
            receipt=dict(label=label,exit_code=code,started_unix=started,ended_unix=time.time(),log_sha256=sha(log))
            receipts.append(receipt);write(root/'receipts.json',receipts);verify();assert code==0,receipt
            wrapped=read(target);report=wrapped.get('report',wrapped)
            assert report['status']=='completed' and len(report['rows'])==27 and report['cycle']==cycle
            assert wrapped['plan_sha256']==plan['source_plan_sha256']
            raw=[json.loads(line[len('PACK_SAMPLE '):]) for line in log.read_text().splitlines() if line.startswith('PACK_SAMPLE ')]
            assert raw==report['rows'] and len(raw)==27
            receipt.update(result_sha256=sha(target),aa_failures=[r['spec']['key'] for r in raw if not r['aa_passed']],
                           over_ten_percent=[r['spec']['key'] for r in raw if r['ratios']['B/A0']>1.10])
            write(root/'receipts.json',receipts)
            print(json.dumps(dict(status='finished',**receipt)),flush=True)
    progress('completed');print(json.dumps(dict(status='completed',processes=6)),flush=True)
except BaseException as error:
    progress('failed',error=str(error),traceback=traceback.format_exc());raise
