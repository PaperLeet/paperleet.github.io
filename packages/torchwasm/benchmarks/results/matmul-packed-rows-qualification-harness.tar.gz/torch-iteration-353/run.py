import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import traceback

root=Path(__file__).resolve().parent
base=root.parent
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
plan=read(root/'plan.json');receipts=[]
def verify():
    for path,digest in plan['inputs'].items():assert sha(Path(path))==digest,path
    assert sha(Path(__file__))==plan['runner_sha256']
def progress(status,**details):
    write(root/'progress.json',dict(status=status,pid=os.getpid(),observed_unix=time.time(),receipts=receipts,**details))
try:
    verify();assert read(base/'torch-iteration-347/progress.json')['status']=='completed'
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
    commands=[('memory-np25',[str(base/'torch-iteration-82/application-env/bin/python'),'-I','-B',str(base/'torch-iteration-352/memory.py'),'numpy25']),
              ('memory-np126',[str(base/'torch-iteration-137/native26-env/bin/python'),'-I','-B',str(base/'torch-iteration-352/memory.py'),'numpy126']),
              ('chrome-sdk',['/opt/homebrew/bin/node',str(base/'torch-iteration-349/run.mjs')])]
    for label,command in commands:
        log=root/(label+'.log');assert not log.exists();verify()
        with log.open('w') as output:
            child=subprocess.Popen(command,env=env,cwd=root,stdout=output,stderr=subprocess.STDOUT)
            progress('running',label=label,child_pid=child.pid,command=command)
            print(json.dumps(dict(status='running',label=label,pid=child.pid)),flush=True)
            code=child.wait()
        receipt=dict(label=label,exit_code=code,log_sha256=sha(log));receipts.append(receipt)
        write(root/'receipts.json',receipts);verify();assert code==0,receipt
        print(json.dumps(dict(status='finished',**receipt)),flush=True)
    memories={name:read(base/'torch-iteration-352'/(name+'-result.json')) for name in ('numpy25','numpy126')}
    for name,report in memories.items():
        assert report['status']=='passed_forced_wasm_allocation_lifetime_diagnostic' and len(report['rows'])==27
        assert all(row['details'][label]['contiguous_copy_owners_remaining']==row['details'][label]['output_owners_remaining']==0 for row in report['rows'] for label in ('A0','A1','B'))
    chrome=read(base/'torch-iteration-349/result.json');assert chrome['status']=='completed' and chrome['report']['passed']==12212
    result=dict(status='passed_candidate_memory_and_full_chrome_sdk',memory_reports={name:sha(base/'torch-iteration-352'/(name+'-result.json')) for name in memories},
                chrome_sdk_sha256=sha(base/'torch-iteration-349/result.json'),chrome_passed=12212,production_changed=False)
    write(root/'result.json',result);progress('completed');print(json.dumps(result),flush=True)
except BaseException as error:
    progress('failed',error=str(error),traceback=traceback.format_exc());raise
