"""Allocation/lifetime diagnostic; timings are not used as performance evidence."""
import gc
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tracemalloc
import weakref

sys.dont_write_bytecode=True
root=Path(__file__).resolve().parent
bench=root.parent/'torch-iteration-346'
plan=json.loads((root/'plan.json').read_text())
def verify():
    for name,digest in plan['inputs'].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
    assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==plan['runner_sha256']
verify()
campaign=json.loads((root.parent/'torch-iteration-347/progress.json').read_text())
assert campaign['status']=='completed' and len(campaign['receipts'])==6
sys.path.insert(0,str(bench))
import numpy as np
import workloads


def load(folder,label):
    name='_pack_memory_'+label
    spec=importlib.util.spec_from_file_location(name,str(folder/'__init__.py'),submodule_search_locations=[str(folder)])
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    sys.modules[name+'._tensor']._WASM_MATMUL=True
    return module.torch


apis={label:load(bench/('candidate' if label=='B' else 'baseline'),label) for label in ('A0','A1','B')}
oracle=np.load(bench/'native26.npz',allow_pickle=False)
rows=[]
for index,spec in enumerate(workloads.specifications()):
    values=workloads.make_inputs(spec);before=workloads.fingerprint(values)
    expected=tuple(oracle[f'case{index}_output{i}'] for i in range(1+sum(spec['active'])))
    operations={label:workloads.MatrixFlow(api,spec,values) for label,api in apis.items()}
    for call in operations.values():
        for actual,target in zip(call(),expected):np.testing.assert_array_equal(actual,target)
    details={}
    for label,call in operations.items():
        copies=[];original=np.ascontiguousarray
        def observed(value,*args,**kwargs):
            output=original(value,*args,**kwargs)
            if not np.shares_memory(value,output):
                copies.append(dict(ref=weakref.ref(output),bytes=output.nbytes,shape=output.shape))
            return output
        gc.collect();tracemalloc.start(5)
        initial=tracemalloc.get_traced_memory()[0]
        try:
            np.ascontiguousarray=observed
            output=call()
            current,peak=tracemalloc.get_traced_memory()
            copied=[dict(bytes=c['bytes'],shape=c['shape']) for c in copies]
            output_bytes=sum(value.nbytes for value in output)
            for actual,target in zip(output,expected):np.testing.assert_array_equal(actual,target)
            del actual,output
            gc.collect()
            alive=sum(c['ref']() is not None for c in copies)
            assert alive==0,(spec,label,alive)
            after=tracemalloc.get_traced_memory()[0]
        finally:
            np.ascontiguousarray=original
            tracemalloc.stop()
        # Separate repeated lifetime sampling from tracemalloc peak accounting.
        refs=[]
        for repeat in range(30):
            output=call()
            refs.extend(weakref.ref(value) for value in output)
            del output
        gc.collect();remaining=sum(ref() is not None for ref in refs)
        assert remaining==0,(spec,label,remaining)
        details[label]=dict(initial_traced_bytes=initial,peak_traced_bytes=peak,current_with_outputs=current,
                            output_bytes=output_bytes,current_after_gc=after,packing_copies=copied,
                            packing_bytes_total=sum(c['bytes'] for c in copied),packing_remaining=alive,
                            repeated_calls=30,output_owners_remaining=remaining)
    assert workloads.fingerprint(values)==before
    row=dict(spec=spec,details=details,additional_peak_bytes=details['B']['peak_traced_bytes']-details['A0']['peak_traced_bytes'])
    rows.append(row);print(json.dumps(dict(key=spec['key'],additional_peak_bytes=row['additional_peak_bytes'],packing_bytes_total=details['B']['packing_bytes_total'])),flush=True)
report=dict(status='passed_forced_wasm_allocation_lifetime_diagnostic',numpy=np.__version__,python=sys.version,rows=rows,
            limitations='CPython tracemalloc with the exact WASM kernel routing forced, not physical browser RSS/VRAM. NumPy copy payloads and weakref lifetimes observed separately. Metadata instrumentation contributes to traced peaks.',
            source_sha256={label:{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (bench/label).iterdir() if p.is_file()} for label in ('baseline','candidate')})
verify()
(root/(sys.argv[1]+'-result.json')).write_text(json.dumps(report,indent=2)+'\n')
