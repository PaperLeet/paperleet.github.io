import gc
import json
import weakref
import sys
import numpy as np
import benchmark
import workloads
from js import wasm_heap_bytes
assert sys.platform=='emscripten'
apis={label:benchmark.load('/candidate' if label=='B' else '/baseline',label) for label in ('A0','A1','B')}
oracle=np.load('/native26.npz',allow_pickle=False)
rows=[]
for index,spec in enumerate(workloads.specifications()):
    values=workloads.make_inputs(spec);before=workloads.fingerprint(values);details={}
    for label,api in apis.items():
        call=workloads.MatrixFlow(api,spec,values)
        expected=tuple(oracle[f'case{index}_output{i}'] for i in range(1+sum(spec['active'])))
        refs=[];sizes=[];output_refs=[];peak=[0]
        contiguous,einsum=np.ascontiguousarray,np.einsum
        def sample():
            peak[0]=max(peak[0],sum(size for ref,size in refs if ref() is not None))
        def copied(value,*args,**kwargs):
            output=contiguous(value,*args,**kwargs)
            if not np.shares_memory(value,output):
                refs.append((weakref.ref(output),output.nbytes));sizes.append(output.nbytes);sample()
            return output
        def contraction(*args,**kwargs):
            sample();return einsum(*args,**kwargs)
        gc.collect();heap_before=int(wasm_heap_bytes())
        try:
            np.ascontiguousarray=copied;np.einsum=contraction
            for repeat in range(30):
                output=call()
                if repeat in (0,29):
                    for actual,target in zip(output,expected):np.testing.assert_array_equal(actual,target)
                    del actual
                output_refs.extend(weakref.ref(value) for value in output)
                del output
        finally:
            np.ascontiguousarray=contiguous;np.einsum=einsum
        gc.collect();copy_remaining=sum(ref() is not None for ref,size in refs);output_remaining=sum(ref() is not None for ref in output_refs)
        assert copy_remaining==output_remaining==0,(spec,label)
        details[label]=dict(peak_live_contiguous_copy_bytes=peak[0],contiguous_copy_bytes_total=sum(sizes),
                            copy_owners_remaining=copy_remaining,output_owners_remaining=output_remaining,
                            calls=30,heap_capacity_before=heap_before,heap_capacity_after=int(wasm_heap_bytes()))
    assert workloads.fingerprint(values)==before
    row=dict(spec=spec,details=details);rows.append(row)
    print('MEMORY_PROGRESS '+json.dumps(dict(key=spec['key'],candidate_copy_peak=details['B']['peak_live_contiguous_copy_bytes'])),flush=True)
report=dict(status='passed_actual_node_wasm_copy_lifetimes',rows=rows,numpy=np.__version__,
            limitations='Tracked payloads are observed np.ascontiguousarray copies, including output normalization; not total live memory. Emscripten heap capacity is a retained high-water capacity, not exact live usage or physical RSS. No timing conclusions.')
