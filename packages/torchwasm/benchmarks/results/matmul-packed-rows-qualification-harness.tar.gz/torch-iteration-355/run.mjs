import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
const root=new URL('./',import.meta.url),hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const plan=JSON.parse(fs.readFileSync(new URL('source-plan.json',root)));
assert(!fs.existsSync(new URL('result.json',root)));
function verify(){for(const [name,item] of Object.entries(plan.payload))assert.equal(hash(fs.readFileSync(new URL(item.source,root))),item.sha256,name);for(const [name,digest] of Object.entries(plan.files))assert.equal(hash(fs.readFileSync(new URL(name,root))),digest,name);}
verify();
try{
 const py=await loadPyodide({indexURL:new URL('../torch-iteration-76/runtime/',root).pathname,stdout:console.log,stderr:console.error});await py.loadPackage('numpy');
 py.runPython('import sys;sys.dont_write_bytecode=True;sys.path.insert(0,"/")');
 for(const [name,item] of Object.entries(plan.payload)){py.FS.mkdirTree('/'+name.split('/').slice(0,-1).join('/'));py.FS.writeFile('/'+name,fs.readFileSync(new URL(item.source,root)));}
 globalThis.wasm_heap_bytes=()=>py._module.HEAPU8.buffer.byteLength;
 py.FS.writeFile('/memory.py',fs.readFileSync(new URL('memory.py',root)));
 const report=JSON.parse(py.runPython("exec(compile(open('/memory.py').read(),'/memory.py','exec'))\njson.dumps(report)"));
 verify();fs.writeFileSync(new URL('result.json',root),JSON.stringify({...report,pyodide:py.version,source_plan_sha256:hash(fs.readFileSync(new URL('source-plan.json',root)))},null,2)+'\n');
 assert.equal(report.status,'passed_actual_node_wasm_copy_lifetimes');assert.equal(report.rows.length,27);
}catch(error){fs.writeFileSync(new URL('failure.json',root),JSON.stringify({error:String(error.stack||error)},null,2)+'\n');throw error;}
