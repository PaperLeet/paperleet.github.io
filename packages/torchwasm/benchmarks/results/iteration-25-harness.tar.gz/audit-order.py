import hashlib,json,itertools,pathlib,warnings
import numpy as np
import torch as native
from stridetorch import torch
warnings.simplefilter('ignore');r=pathlib.Path(__file__).parent;diffs=[];count=0
cases=[{},dict(keepdim=True),dict(dim=0),dict(dim=-1,keepdim=True),dict(dim=[]),dict(dim=()),dict(dim=(0,1)),dict(dim=(0,0)),dict(dim=5),dict(dim=True),dict(dim=1.2),dict(keepdim=1)]
for name,shape,source,target,options in itertools.product(('nansum','nanmean'),((),(2,3),(0,3)),('float16','float32','float64','int64','bool','complex64'),(None,'float16','float32','float64','int64','bool','complex64'),cases):
 data=np.arange(int(np.prod(shape))).reshape(shape).astype(source)
 if data.dtype.kind=='f' and data.size:data.flat[::3]=np.nan
 outcomes=[]
 for api in (native,torch):
  try:
   x=api.tensor(data,requires_grad=source.startswith('float'));kw=dict(options)
   if target is not None:kw['dtype']=getattr(api,target)
   y=getattr(api,name)(x,**kw);gradient=None
   if y.requires_grad:y.backward(api.full(y.shape,.37,dtype=y.dtype));gradient=x.grad.numpy()
   outcomes.append((y.detach().numpy(),gradient))
  except Exception as e:outcomes.append(type(e).__name__)
 count+=1;expected,actual=outcomes
 try:
  if isinstance(expected,str) or isinstance(actual,str):assert expected==actual
  else:
   for a,b in zip(expected,actual):
    if a is None or b is None:assert a is b;continue
    assert a.dtype==b.dtype and a.shape==b.shape
    np.testing.assert_allclose(b,a,rtol=2e-3 if a.dtype==np.float16 else 3e-6,atol=0 if a.dtype==np.float16 else 1e-7,equal_nan=True)
 except AssertionError as e:diffs.append(dict(name=name,shape=shape,source=source,target=target,options=options,expected=str(expected),actual=str(actual),error=str(e)[:500]))
p=pathlib.Path(__import__('stridetorch').__file__).parent
report=dict(cases=count,differences=diffs,source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in p.iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')},native=native.__version__,numpy=np.__version__)
(r/'nan-audit-order.json').write_text(json.dumps(report,indent=2)+'\n');print(count,'cases',len(diffs),'differences');print(json.dumps(diffs[:6],indent=2))
