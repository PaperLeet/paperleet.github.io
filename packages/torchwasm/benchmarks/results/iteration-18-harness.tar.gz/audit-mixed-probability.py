import itertools,json,numpy as np,torch
from pathlib import Path
from paperleet_torch import torch as lite
torch.set_num_threads(1);rng=np.random.default_rng(1813);rows=[]
for dtypes in itertools.product([np.float32,np.float64],repeat=3):
 for smoothing in [0.,.2,1.]:
  arrays=[rng.normal(size=(2,4,3)).astype(dtypes[0]),rng.uniform(.1,1,size=(2,4,3)).astype(dtypes[1]),rng.uniform(.2,2,size=4).astype(dtypes[2])];arrays += [rng.normal(size=a.shape).astype(a.dtype) for a in arrays];records=[]
  for api in [lite,torch]:
   v=[api.tensor(a,requires_grad=True) for a in arrays];p,t=api.func.jvp(lambda x,y,w:api.nn.functional.cross_entropy(x,y,w,label_smoothing=smoothing),tuple(v[:3]),tuple(v[3:]));(p.square()+t.square()).backward();records.append([p,t,*[a.grad for a in v]])
  errors=[]
  for a,b in zip(*records):
   aa=a.detach().numpy();bb=b.detach().numpy();np.testing.assert_allclose(aa,bb,rtol=1e-5 if np.float32 in dtypes else 1e-11,atol=5e-6 if np.float32 in dtypes else 1e-12);errors.append(float(np.max(np.abs(aa-bb))))
  assert records[0][0].dtype==np.result_type(*dtypes)
  rows.append(dict(dtypes=[np.dtype(d).name for d in dtypes],smoothing=smoothing,max_abs_errors=errors))
Path(__file__).with_name('mixed-probability-audit.json').write_text(json.dumps(dict(status='success',native=torch.__version__,numpy=np.__version__,seed=1813,rows=rows),indent=2)+'\n');print('PASS all8 dtype triples x3 smoothing levels: full JVP/reverse tapes')
