from pathlib import Path
import json,numpy as np,torch
root=Path(__file__).parent;torch.set_num_threads(1);rows=[]
def record(label,fn):
 try:result=fn()
 except Exception as e:result={'error':type(e).__name__,'message':str(e)}
 rows.append(dict(case=label,result=result))
def example(shape=(2,3),soft=False,weight=False,dtype=torch.float64,targetdtype=None,weightdtype=None,smoothing=0.,ignore=-100,values=None,needs=(True,False,False),reduction='mean',op='ce'):
 x=torch.tensor(np.random.default_rng(1801).normal(size=shape),dtype=dtype,requires_grad=needs[0]);dim=0 if x.ndim==1 else 1;c=shape[dim]
 tshape=shape[:dim]+shape[dim+1:]
 y=torch.full_like(x,1/max(c,1),dtype=targetdtype or dtype,requires_grad=needs[1]) if soft else torch.zeros(tshape,dtype=torch.int64)
 if values is not None:y=torch.tensor(values,dtype=y.dtype)
 w=torch.arange(1,c+1,dtype=weightdtype or dtype,requires_grad=needs[2]) if weight else None
 fn=torch.nn.functional.cross_entropy if op=='ce' else torch.nn.functional.nll_loss
 args=dict(weight=w,ignore_index=ignore,reduction=reduction)
 if op=='ce':args['label_smoothing']=smoothing
 z=fn(x,y,**args);z.sum().backward()
 return dict(output=z.detach().tolist(),dtype=str(z.dtype),dx=x.grad.tolist() if x.grad is not None else None,dy=y.grad.tolist() if y.grad is not None else None,dw=w.grad.tolist() if w is not None and w.grad is not None else None)
for shape in [(3,),(2,3,4),(2,3,2,4),(0,3),(2,3,0),(2,0),(0,)]:
 for op in ['ce','nll']:record(f'{op} shape{shape}',lambda shape=shape,op=op:example(shape=shape,op=op))
for soft in [False,True]:
 for smoothing in [-.2,0.,.2,1.,1.2,float('nan')]:
  record(f'soft{soft} smoothing{smoothing}',lambda soft=soft,smoothing=smoothing:example(soft=soft,weight=True,smoothing=smoothing))
 for ignore in [-100,-1,0]:record(f'soft{soft} ignore{ignore}',lambda soft=soft,ignore=ignore:example(soft=soft,ignore=ignore))
 for needs in [(True,False,True),(True,True,True)]:record(f'soft{soft} needs{needs}',lambda soft=soft,needs=needs:example(soft=soft,weight=True,needs=needs))
for td in [torch.float32,torch.float64]:
 for wd in [torch.float32,torch.float64]:record(f'soft mixed{td}/{wd}',lambda td=td,wd=wd:example(soft=True,weight=True,dtype=torch.float32,targetdtype=td,weightdtype=wd,needs=(True,True,True)))
for smoothing in [0.,.2,1.]:
 for reduction in ['none','sum','mean']:
  record(f'allignored sm{smoothing}/{reduction}',lambda smoothing=smoothing,reduction=reduction:example(values=[-100,-100],weight=True,smoothing=smoothing,reduction=reduction))
# Which operands native backward guards is operator- and target-specific.
for soft in [False,True]:
 for changed in ['input','target','weight','output']:
  def mutate(soft=soft,changed=changed):
   x=torch.randn(2,3,dtype=torch.float64,requires_grad=True);y=torch.ones_like(x)/3 if soft else torch.tensor([0,2]);w=torch.ones(3,dtype=torch.float64)
   out=torch.nn.functional.cross_entropy(x,y,w,label_smoothing=.2);v={'input':x,'target':y,'weight':w,'output':out}[changed]
   with torch.no_grad():v.add_(1)
   out.backward();return 'ok'
  record(f'mutation soft{soft}/{changed}',mutate)
report=dict(native=torch.__version__,numpy=np.__version__,rows=rows)
(root/'native-classification-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps([{k:v for k,v in row.items() if k!='result'}|{'result':{k:v for k,v in row['result'].items() if k in ['error','dtype','message']} if isinstance(row['result'],dict) else row['result']} for row in rows],indent=2))
