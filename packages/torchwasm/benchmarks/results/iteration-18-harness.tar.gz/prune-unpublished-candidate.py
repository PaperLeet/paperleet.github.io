from pathlib import Path
import hashlib,json,subprocess,shutil
repo=Path.cwd();root=Path(__file__).parent;data=repo/'web/public/data';old=set(json.loads((root/'before-fastpath-asset-paths.json').read_text()))
active=set();index=json.loads((data/'index.json').read_text())
for row in index['problems']:
 for relative in [row['detail_url'],row['browser_judge']['bundle_url']]:active.add('web/public/data/'+relative)
 manifest=json.loads((data/row['browser_judge']['bundle_url']).read_text());active.add('web/public/data/'+manifest['runtime_bundle_url'])
untracked=set(subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','web/public/data/browser-judge','web/public/data/modules'],text=True).splitlines())
published=set(subprocess.check_output(['git','ls-tree','-r','--name-only','origin/main','--','web/public/data/browser-judge','web/public/data/modules'],text=True).splitlines())
remove=old-active;assert remove and remove<=untracked and not remove&published
assert untracked-active==remove,(untracked-active)-remove
archive=root/'before-fastpath-assets';archive.mkdir(exist_ok=False);hashes={}
for name in sorted(old):
 file=repo/name;raw=file.read_bytes();target=archive/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);hashes[name]=hashlib.sha256(raw).hexdigest()
for name in sorted(remove):
 assert (repo/name).is_file() and name not in published;(repo/name).unlink()
(root/'unpublished-prune-receipt.json').write_text(json.dumps(dict(reason='Only own pre-fastpath additions proven untracked, unpublished and unreachable;all bytes archived before deletion',removed=sorted(remove),retained_reachable=sorted(old&active),archived_sha256=hashes,published_assets_untouched=len(published)),indent=2)+'\n');print('archived',len(old),'pruned',len(remove),'retained',len(old&active))
