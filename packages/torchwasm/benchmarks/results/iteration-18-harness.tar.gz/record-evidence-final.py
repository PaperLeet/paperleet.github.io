from pathlib import Path
import gzip,hashlib,io,json,math,re,shutil,tarfile
root=Path(__file__).parent;repo=Path.cwd();read=lambda n:json.loads((root/n).read_text());results=repo/'packages/paperleet-torch/benchmarks/results'
def clean(value):
 if isinstance(value,float) and not math.isfinite(value):return 'NaN' if math.isnan(value) else 'Infinity' if value>0 else '-Infinity'
 if isinstance(value,dict):return {k:clean(v) for k,v in value.items()}
 if isinstance(value,list):return [clean(v) for v in value]
 return value
source=repo/'packages/paperleet-torch/src/paperleet_torch';hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']}
assert hashes==read('source-hashes-final.json')==read('distribution-identity-final.json')['source_hashes']==read('source-wasm-final.json')['source_hashes']==read('chrome-contracts-final/result.json')['source_hashes']
perf=read('performance-final-summary.json');assert perf['status']=='success'
assert hashes=={k.removeprefix('src/paperleet_torch/'):v for k,v in perf['inputs'].items() if k.startswith('src/paperleet_torch/')}
ci=read('native-ci-final.json');wasm=read('full-wasm-final-result.json')
assert ci['passed'] and ci['problems']==77 and ci['tests_executed']==9987 and not ci['issues'] and sum(map(len,ci['mutation'].values()))==336
assert wasm['passed'] and wasm['modules']==77 and not wasm['browser_budget_exceeded']
native=(root/'full-native-final.log').read_text();match=re.search(r'(18393) passed, (1) skipped, (\d+) warnings in ([\d.]+)s',native);assert match
assert '435 passed' in (root/'python310-v018-final-tests.log').read_text()
assert 'PASS initial build graph:' in (root/'frontend-build.log').read_text()
index=json.loads((repo/'web/public/data/index.json').read_text());by_id={r['id']:r for r in index['problems']};paths={'index.json','index-v3.json','catalog.json'};data=repo/'web/public/data'
for row in wasm['results']:
 entry=by_id[row['id']];assert entry['browser_judge']['bundle_url']==row['bundle_url']
 manifest=json.loads((data/row['bundle_url']).read_text());assert manifest['runtime_bundle_url']==row['runtime_bundle_url']
 assert hashlib.sha256(manifest['reference'].encode()).hexdigest()==row['source_sha256']
 paths.update([entry['detail_url'],row['bundle_url'],row['runtime_bundle_url']])
expected=root/'live-expected';expected.mkdir(exist_ok=False);live_hashes={}
for name in sorted(paths):
 p=expected/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(data/name,p);live_hashes[name]=hashlib.sha256(p.read_bytes()).hexdigest()
(root/'live-expected-hashes.json').write_text(json.dumps(live_hashes,indent=2)+'\n')
logs=['classification-initial.log','classification-core.log','classification-edges.log','classification-final.log','full-native-initial.log','full-native.log','full-native-final.log','source-wasm-initial.log','source-wasm-final.log','full-wasm-cancelled.log','full-wasm.log','full-wasm-final.log','native-catalog-final.log','python310-v018-final-tests.log','frontend-check.log','frontend-build.log','fastpath-focused-final.log','fastpath-layout-focused.log','fastpath-matrix-focused.log','performance.log','performance-fastpath.log','performance-matrix.log','performance-final.log']
report=dict(status='final local runtime and application gates passed;post-upstream frontend integration pending',version='0.18.0',source_hashes=hashes,
 native_probes={n:read(n) for n in ['native-classification-audit.json','native-classification-edges.json','mixed-probability-audit.json']},
 infrastructure=dict(passed=18393,skipped=1,warnings=int(match[3]),duration_s=float(match[4])),native_new_tests=640,independent_new_tests=95,focused_with_existing_tests=985,
 native_catalog=ci,real_wasm_catalog=wasm,node_contracts=read('source-wasm-final.json'),chrome_worker=read('chrome-contracts-final/result.json'),minimum_wheel=read('wheel-v018-final-result.json'),distributions=read('distribution-identity-final.json'),
 assets=read('export-identity.json'),unpublished_candidate_pruning=read('unpublished-prune-receipt.json'),runtime_transfer_size=read('runtime-size-final.json'),performance=perf,
 retained_rejected_candidate=read('before-fastpath-validation.json'),intermediate_preflights={n:read(n) for n in ['performance-fastpath-summary.json','performance-matrix-summary.json']},
 initial_failures='36 initial native failures:24 float32 smoothing scalar-promotion errors fixed;12 native macOS Fortran NLL2D backward failures use contiguous native oracle plus independent scalar formula.3 later failures established zero-class spatial native rejection.1 WASM fixture used default int32 and was corrected to explicit int64;owned initial full-WASM parent/children intentionally cancelled143 for that concrete failure.1 old full-native expectation required unsupported smoothing and now checks unsupported legacy option. All failures/samples retained;no tolerance relaxation.',
 performance_decision='First fully correct but unpublished candidate regressed common CE time50-86%;held from main. Reuse exponential/partition,cache finite unweighted constant VJP,skip identity-axis transforms,and avoid spatial/probability validation on the complete-bounds-checked default matrix route. Keep target version protection and general weighted/nonfinite coefficient ordering.',
 all_local_producers_terminal_before_measurements=True,producer_receipts='Final native63353,native-catalog79124,WASM99600,Node37413,Chrome19848,minimum-wheel76557,private-build5624,export/prune99300 all observed terminal0;final performance receipt recorded in state.985 focused58893 terminal0. Earlier36failed26197,3failed40942,obsolete-boundary63718 and fixture Node43276/Chrome55235 failures retained;initialWASM99308 deliberately terminated143.',
 frontend_before_upstream=dict(check='passed',build='passed',scope='Incoming UI/workflow changes need a separate final rerun after safe rebase.'),visualization='All77 generated earlier;only browser-library code and tests changed afterward,not native plotting/application/problem sources.',
 live_expected_hashes=live_hashes,remote_adoption='Exact current main Quality and Pages verification follows mature publication;new upstream Pages policy gates deploy on tested latest main.',logs={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in logs})
raw=json.dumps(clean(report),indent=2,allow_nan=False)+'\n';(root/'local-validation-final.json').write_text(raw);(results/'iteration-18.json').write_text(raw)
# Retain experimental runners, each frozen implementation and browser contract
# snapshot, failed fixtures/logs, and archived unpublished JSON bytes. Exclude
# every virtualenv, node_modules, built wheel and bytecode.
members=set()
for p in root.iterdir():
 if p.is_file() and p.suffix in ['.py','.mjs']:members.add(p)
for folder in ['perf-frozen','perf-frozen-fastpath','perf-frozen-matrix','perf-frozen-final','chrome-contracts-initial','chrome-contracts','chrome-contracts-final','before-fastpath-assets']:
 for p in (root/folder).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and (p.suffix in ['.py','.mjs','.json'] or p.name in ['LICENSE','NOTICE']):members.add(p)
for n in ['classification-initial.log','classification-edges.log','source-wasm-initial.log','full-native-initial.log']:members.add(root/n)
with (results/'iteration-18-harness.tar.gz').open('wb') as file:
 with gzip.GzipFile(filename='',mode='wb',fileobj=file,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT) as archive:
   for p in sorted(members):
    payload=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(root)));info.size=len(payload);info.mtime=0;info.mode=0o644;archive.addfile(info,io.BytesIO(payload))
print(json.dumps(dict(status=report['status'],evidence_bytes=len(raw.encode()),harness_files=len(members),frozen_live_files=len(live_hashes))))
