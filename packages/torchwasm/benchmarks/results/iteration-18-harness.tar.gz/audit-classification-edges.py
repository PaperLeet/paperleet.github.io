import json,torch,numpy as np
from pathlib import Path
torch.set_num_threads(1);rows=[]
def rec(case,fn):
 try:r=fn()
 except Exception as e:r={'error':type(e).__name__,'message':str(e)}
 rows.append(dict(case=case,result=r))
def case(kind,shape=(2,3),targets=None,weights=None,smooth=0.,reduction='mean',jvp=False):
 x=torch.tensor([[.2,-.3,.7],[.8,.4,-.2]],dtype=torch.float64,requires_grad=True) if shape==(2,3) else torch.ones(shape,dtype=torch.float64,requires_grad=True)
 y=torch.tensor([0,-100] if targets is None else targets,dtype=torch.int64)
 w=torch.tensor(weights,dtype=torch.float64) if weights is not None else None
 def fn(a):return torch.nn.functional.cross_entropy(a,y,w,label_smoothing=smooth,reduction=reduction) if kind=='ce' else torch.nn.functional.nll_loss(a,y,w,reduction=reduction)
 if jvp:
  p,t=torch.func.jvp(fn,(x,),(torch.ones_like(x),));return dict(primal=p.tolist(),tangent=t.tolist())
 p=fn(x);p.sum().backward();return dict(primal=p.tolist(),gradient=x.grad.tolist())
for kind in ['ce','nll']:
 for smooth in ([0.,.2,1.] if kind=='ce' else [0.]):
  for weights in [[0.,1.,2.],[0.,0.,0.],[-1.,1.,2.]]:
   for jvp in [False,True]:rec(f'{kind} sm{smooth} w{weights} jvp{jvp}',lambda:case(kind,weights=weights,smooth=smooth,jvp=jvp))
 for jvp in [False,True]:rec(f'{kind} ignored jvp{jvp}',lambda:case(kind,targets=[-100,-100],jvp=jvp))
 for changed in ['input','target','weight','output']:
  def mutate():
   x=torch.randn(2,3,requires_grad=True);y=torch.tensor([0,2]);w=torch.ones(3)
   z=torch.nn.functional.nll_loss(x,y,w);v=dict(input=x,target=y,weight=w,output=z)[changed]
   with torch.no_grad():v.add_(1)
   z.backward();return 'ok'
  if kind=='nll':rec(f'nll mutation {changed}',mutate)
for shape in [(0,3),(2,0),(2,0,3)]:
 for smoothing in [0.,.2]:
  def softempty():
   x=torch.ones(shape,dtype=torch.float64,requires_grad=True);y=torch.zeros_like(x,requires_grad=True);p=torch.nn.functional.cross_entropy(x,y,label_smoothing=smoothing);p.backward();return dict(value=p.tolist(),dx=x.grad.tolist(),dy=y.grad.tolist())
  rec(f'softempty {shape} sm{smoothing}',softempty)
for sm in [0.,.2]:rec(f'zerochannels ignored sm{sm}',lambda:case('ce',shape=(2,0),targets=[-100,-100],smooth=sm))
Path(__file__).with_name('native-classification-edges.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
