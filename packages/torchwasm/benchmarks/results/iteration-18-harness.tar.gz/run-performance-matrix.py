from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess,time
root=Path(__file__).parent;repo=Path.cwd();frozen=root/'perf-frozen-matrix';frozen.mkdir(exist_ok=False)
source=frozen/'src/paperleet_torch';source.mkdir(parents=True)
for p in (repo/'packages/paperleet-torch/src/paperleet_torch').iterdir():
 if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']:shutil.copyfile(p,source/p.name)
old=frozen/'baseline/paperleet_torch';old.parent.mkdir();shutil.copytree(root.parent/'torch-iteration-17/perf-frozen/src/paperleet_torch',old,ignore=shutil.ignore_patterns('__pycache__'))
bench=frozen/'benchmarks';bench.mkdir()
for name in ['bench_classification.py','bench_wasm.mjs']:shutil.copyfile(repo/'packages/paperleet-torch/benchmarks'/name,bench/name)
def hashes():return {str(p.relative_to(frozen)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(frozen.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
inputs=hashes();assert {n.removeprefix('src/paperleet_torch/'):v for n,v in inputs.items() if n.startswith('src/paperleet_torch/')}==json.loads((root/'source-hashes-matrix.json').read_text())
assert {n.removeprefix('baseline/paperleet_torch/'):v for n,v in inputs.items() if n.startswith('baseline/paperleet_torch/')}==json.loads((root.parent/'torch-iteration-17/source-hashes.json').read_text())
target=root/'performance-matrix';target.mkdir(exist_ok=False);reports=[]
for series in ['release-common']:
 order=['composite','joint','joint','composite'] if series=='same-source' else ['baseline','candidate','candidate','baseline']
 for runtime in ['cpu','wasm']:
  for dtype in ['float32','float64']:
   for i,role in enumerate(order):
    assert hashes()==inputs;implementation=role if series=='same-source' else 'joint';selected_source=old if role=='baseline' else source
    label=f'{series}-{runtime}-{dtype}-{i}-{role}';output=target/(label+'.json')
    env=dict(os.environ,PYTHONPATH=str(selected_source.parent),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2')
    args=[str(repo/'.venv/bin/python'),str(bench/'bench_classification.py')] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(bench/'bench_wasm.mjs'),'--benchmark','classification','--source',str(selected_source),'--runtime',str(repo/'web/node_modules/pyodide'),'--cache',str(repo/'web/public/browser-runtime/pyodide-0.29.4')]
    args+=['--dtype',dtype,'--implementation',implementation,'--repeat','9','--iterations','80','--output',str(output)]
    if series=='release-common':
     for case in ['tiny_index','classifier_index','vocabulary_index']:args+=['--case',case]
    start=time.monotonic()
    with (target/(label+'.log')).open('w') as log:result=subprocess.run(args,cwd=frozen,env=env,stdout=log,stderr=subprocess.STDOUT)
    receipt=dict(series=series,runtime=runtime,dtype=dtype,index=i,role=role,implementation=implementation,args=args,elapsed_s=time.monotonic()-start,exit_code=result.returncode)
    with (target/'receipts.jsonl').open('a') as f:f.write(json.dumps(receipt)+'\n')
    result.check_returncode();report=json.loads(output.read_text());assert report['library_version']==('0.17.0' if role=='baseline' else '0.18.0')
    if runtime=='cpu':assert str(selected_source) in report['runtime_module']
    else:assert report['pyodide']=='0.29.4' and report['numpy']=='2.2.5'
    reports.append(dict(series=series,runtime=runtime,role=role,**report));assert hashes()==inputs;print(label,'complete',flush=True)
summary={}
for series in ['release-common']:
 summary[series]={};roles=['composite','joint'] if series=='same-source' else ['baseline','candidate']
 for runtime in ['cpu','wasm']:
  summary[series][runtime]={}
  for dtype in ['float32','float64']:
   rows=[r for r in reports if r['series']==series and r['runtime']==runtime and r['dtype']==dtype];summary[series][runtime][dtype]={}
   for case in rows[0]['results']:
    medians={role:[r['results'][case]['median_ms'] for r in rows if r['role']==role] for role in roles}
    summary[series][runtime][dtype][case]=dict(process_medians_ms=medians,time_reduction_percent=(1-statistics.median(medians[roles[1]])/statistics.median(medians[roles[0]]))*100)
record=dict(status='success',inputs=inputs,configuration=dict(repeat=9,iterations=80,warmup=3,tiny_multiplier=4,vocabulary_spatial_divisor=4),summary=summary,reports=reports,
 scope='Fast-path preflight:published0.17 vs revised0.18 identical common2D unweighted class-index workloads across3 cases. CPU/WASM independent; no concurrent local correctness/build/audits; all samples retained; not native Torch or full-application comparisons.')
(root/'performance-matrix-summary.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(summary,indent=2))
