from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile

r=Path(__file__).resolve().parent;s=r/'main-sync-proof'
repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
context=json.loads((s/'context.json').read_text());front=json.loads((s/'frontend-receipts.json').read_text())
assert len(front)==5 and all(v['exit_code']==0 for v in front)
additional=json.loads((s/'additional-receipts.json').read_text())
assert len(additional)==2 and all(v['exit_code']==0 for v in additional)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==context['upstream']
assert len(context['changed_files'])==25 and len(context['source_hashes'])==49 and len(context['active_export_sha256'])==161
for name,digest in context['changed_files'].items():
    assert sha(s/'incoming'/name)==sha(repo/name)==digest
    blob=subprocess.check_output(['git','show',context['upstream']+':'+name],cwd=repo)
    assert hashlib.sha256(blob).hexdigest()==digest
for name,digest in context['source_hashes'].items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==digest
for name,digest in context['active_export_sha256'].items():assert sha(repo/'web/public/data'/name)==digest
for name,digest in json.loads((r/'canonical-policy-identity.json').read_text())['hashes'].items():assert sha(repo/name)==digest
shutil.copy2(Path(__file__),s/'close-main-sync.py')
archive=out/'iteration-41-main-sync-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for path in sorted(s.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:tar.add(path,arcname=str(path.relative_to(s)),recursive=False)
report=dict(status='complete_local_latest_frontend_passed_runtime_identity_unchanged',version='0.41.0',context=context,frontend_receipts=front,additional_checks=additional,
            archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),
            scope='25 incoming frontend/check/style/documentation files. package.json adds only a check command. Full frontend and both builds pass on the merged snapshot.49 computational/license and161 export identities unchanged;full CPU/native/all WASM evidence retains exact source and catalog inputs.',
            publication='No GitHub CI,tag,dispatch,package upload or online publication.')
(out/'iteration-41-main-sync.json').write_text(json.dumps(report,indent=2)+'\n')
doc=repo/'docs/validation/torch-runtime-iteration-41.md'
doc.write_text(doc.read_text()+f'\nLatest upstream `{context["upstream"]}` adds 25 frontend/check/style/documentation\nfiles. These changes were retained by fast-forward and validated with the full\nfrontend suite and both typed builds. Package dependencies, Python, SDK, catalog,\nruntime and publishing-policy inputs did not change. All 49 source/license and\n161 export identities retain the numerical/full-WASM proof. See\n`iteration-41-main-sync.json` and `iteration-41-main-sync-harness.tar.gz`.\n')
print(json.dumps(dict(upstream=context['upstream'],source_unchanged=49,exports_unchanged=161,archive=report['archive'])))
