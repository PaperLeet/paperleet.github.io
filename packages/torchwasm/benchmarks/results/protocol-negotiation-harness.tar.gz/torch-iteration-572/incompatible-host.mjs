import {createGpuEngine,servePort} from './gpu-service.mjs';
let service,attached=false;
self.onmessage=async event=>{
 if(event.data?.type==='dispose'){if(service)await service.close('host disposed');return;}
 if(event.data?.type!=='connect'||attached||event.ports.length!==1)return;attached=true;
 try{
  const engine=await createGpuEngine(),port=event.ports[0];
  const wrapper={postMessage(value,transfer){if(value.event==='ready')value={...value,protocol:{...value.protocol,major:2}};port.postMessage(value,transfer);},set onmessage(value){port.onmessage=value;},set onmessageerror(value){port.onmessageerror=value;},start(){port.start();},close(){port.close();}};
  service=servePort(wrapper,engine,{onClosed:value=>self.postMessage({type:'disposed',...value})});
  self.postMessage({type:'ready',info:engine.info});
 }catch(error){self.postMessage({type:'unavailable',error:String(error)});}
};
