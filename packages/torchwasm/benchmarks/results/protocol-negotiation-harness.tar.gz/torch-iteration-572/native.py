from pathlib import Path
import hashlib,json,sys
import numpy as np
import torch
import cases
r=Path(__file__).resolve().parent;label=sys.argv[1];arrays={};metadata=[]
for i,spec in enumerate(cases.specs()):
 values=cases.exercise(torch,spec,lambda a,b:a@b);metadata.append(dict(spec=spec,outputs=len(values)))
 for j,value in enumerate(values):arrays[f'case{i}_{j}']=value
for j,value in enumerate(cases.training(torch,lambda a,b:a@b)):arrays[f'training{j}']=value
np.savez_compressed(r/(label+'.npz'),**arrays);(r/(label+'.json')).write_text(json.dumps(dict(torch=torch.__version__,numpy=np.__version__,cases=metadata,training_outputs=17,cases_sha256=hashlib.sha256((r/'cases.py').read_bytes()).hexdigest()),indent=2)+'\n');print(json.dumps(dict(torch=torch.__version__,cases=len(metadata),outputs=len(arrays))))
