from pathlib import Path
import hashlib,json,sys
import numpy as np
import torch
import cases
r=Path(__file__).resolve().parent;label=sys.argv[1];arrays={}
for layout in ['C','F','slice']:
 for i,value in enumerate(cases.chain_exercise(torch,layout,lambda a,b:a@b)):arrays[f'{layout}_{i}']=value
for i,value in enumerate(cases.chain_training(torch,lambda a,b:a@b)):arrays[f'training_{i}']=value
np.savez_compressed(r/(label+'.npz'),**arrays);(r/(label+'.json')).write_text(json.dumps(dict(torch=torch.__version__,numpy=np.__version__,cases_sha256=hashlib.sha256((r/'cases.py').read_bytes()).hexdigest(),outputs=len(arrays)),indent=2)+'\n');print(json.dumps(dict(torch=torch.__version__,outputs=len(arrays))))
