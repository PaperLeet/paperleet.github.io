from pathlib import Path
import hashlib,io,json,shutil,tarfile,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
assert not (r/'protocol-negotiation-harness.tar.gz').exists()
performance=read(b/'torch-iteration-575/result.json');assert performance['all_preplanned_controls_passed'] and performance['all_overhead_gates_passed'] and not performance['claimed_speedup']
gpu=read(b/'torch-iteration-572/browser-result-0.json');assert gpu['status']=='passed' and gpu['numerical']['cases']==51 and len(gpu['numerical']['controls'])==31 and gpu['numerical']['compatibility']['cases']==4
assert len(gpu['host_disposals'])==4 and all(v['stats']['closed'] and v['stats']['total_bytes']==v['stats']['resident_handles']==v['stats']['allocations']==0 for v in gpu['host_disposals'])
assert gpu['host_disposals'][3]['stats']['peak_bytes']==0
native={}
for label,path in [('numpy25',b/'torch-iteration-574/native25.xml'),('numpy126',b/'torch-iteration-574/native126.xml'),('repository',b/'torch-iteration-576/repo-tests.xml')]:
 suites=list(ET.parse(path).getroot().iter('testsuite'));totals={k:sum(int(v.attrib.get(k,0)) for v in suites) for k in ['tests','failures','errors','skipped']};assert totals==dict(tests=132,failures=0,errors=0,skipped=0);native[label]=totals
for stage in [568,569,570,571,572,573,574]:
 for n,h in read(b/f'torch-iteration-{stage}/source-plan.json')['files'].items():assert sha(b/f'torch-iteration-{stage}'/n)==h,(stage,n)
qualified=read(b/'torch-iteration-576/result.json');assert qualified['status']=='passed_repository_negotiation_checks'
for n,h in qualified['qualified_files'].items():assert sha(repo/'packages/stridetorch/benchmarks/webgpu_rpc'/n)==h,n
for n,h in read(b/'torch-iteration-515/source-plan.json')['inputs'].items():assert sha(Path(n))==h,n
for n,h in read(b/'torch-iteration-511/live-export-sha256.json').items():assert sha(repo/'web/public/data'/n)==h,n
summary=dict(status='qualified_matrix_rpc_capability_negotiation',canonical_runtime_version='0.83.0',native=native,repository_checks=qualified,actual_gpu=dict(browser=gpu['browser'],gpu_info=gpu['gpu_info'],worker=gpu['worker'],cases=51,state_controls=31,compatibility=gpu['numerical']['compatibility'],capabilities=gpu['capabilities'],host_disposals=gpu['host_disposals'],main_requests=gpu['requests_sent']),performance=performance,features=['program-matmul-f32','program-retain-inputs'],protocol=dict(name='stridetorch-matrix-rpc',major=1,minor=0),legacy_computed_programs_supported=True,incompatible_startup_abandoned=True,additional_discovery_rpc=0,raw_send_is_low_level=True,shader_execution_and_quotas_unchanged=True,canonical_resources_unchanged=66,public_sdk_sources_unchanged=93,active_export_identities_unchanged=183,package_inputs_unchanged=206,automatic_dispatch=False,public_gpu_storage=False,ci_triggered=False,tags_pushed=False,published=False,deployed=False,goal_status='active')
write(r/'result.json',summary)
write(r/'iteration-outcomes.json',dict(initial568='30 negotiation cases passed, both native132 passed; review identified primitive pre-ready upload gap',negative569='New upload regression test fails with one conversion instead of zero, preserving evidence of the gap',intermediate570='Primitive readiness waits and timeout abandonment added; early-close test fails because ready could resolve before close acknowledgement',selected571='Early close now abandons startup immediately; all39 negotiation cases and115 previous portable cases pass',final574='Same executable candidate with historical v0 fixtures in final repository paths; both native132 and39 negotiation cases pass',real572='Four actual GPU hosts cover new/new, new/v0, old/new and explicit major incompatibility; original51+31 gates and4 compatibility cases pass',performance573='All six preplanned sessions retained; no favorable reruns; one individual A/A context flagged and aggregate gates pass',repository576='132 native plus154 portable cases pass; all206 package inputs and183 exports unchanged'))
write(r/'replay-dependencies.json',dict(entrypoints=['574/check-negotiation.mjs and native test_*.py','572/run-browser.mjs for four-host real-browser qualification','573/run-all.py for all six preplanned performance processes','575/analyze.py with 573 path for fixed analysis'],external=['Pyodide0.29.4/NumPy2.2.5 runtime assets at stage76, not included','Chrome155/Apple metal-3 adapter; Node22 and Playwright','Py3.12/NumPy2.5.4/Torch2.14.1 and Py3.10/NumPy1.26.4/Torch2.6 environments','Adjust historical absolute paths before replay'],scope=['No new speedup claim; worst aggregate paired latency ratio1.0304311291','Public wrappers wait for handshake, raw send remains low-level','Discovery adds metadata to existing ready event, no extra request','General task isolation, public GPU Tensor storage and stable packaged GPU API remain future work']))
files=[r/'aggregate.py',r/'result.json',r/'iteration-outcomes.json',r/'replay-dependencies.json']
for stage in range(568,577):files.extend(p for p in (b/f'torch-iteration-{stage}').rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts)
for n in [*qualified['qualified_files'],'README.md']:
 target=r/'repository'/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/'packages/stridetorch/benchmarks/webgpu_rpc'/n,target);files.append(target)
files=sorted(set(files));manifest={str(p.relative_to(b)):sha(p) for p in files};seen={};target=r/'protocol-negotiation-harness.tar.gz'
with tarfile.open(target,'w:gz') as stream:
 for p in files:
  n=str(p.relative_to(b));h=manifest[n]
  if h in seen:
   item=stream.gettarinfo(str(p),arcname=n);item.type=tarfile.LNKTYPE;item.linkname=seen[h];item.size=0;stream.addfile(item)
  else:stream.add(p,arcname=n,recursive=False);seen[h]=n
 data=(json.dumps(manifest,indent=2)+'\n').encode();item=tarfile.TarInfo('sha256.json');item.size=len(data);stream.addfile(item,io.BytesIO(data))
with tarfile.open(target) as stream:
 for n,h in manifest.items():assert hashlib.sha256(stream.extractfile(n).read()).hexdigest()==h,n
receipt=dict(path='packages/stridetorch/benchmarks/results/'+target.name,sha256=sha(target),files=len(files),unique_payloads=len(seen),bytes=target.stat().st_size,all_payloads_verified=True);write(r/'archive-receipt.json',receipt);summary['raw_archive']=receipt
write(repo/'packages/stridetorch/benchmarks/results/protocol-negotiation.json',summary);shutil.copy2(target,repo/receipt['path']);print(json.dumps(receipt))
