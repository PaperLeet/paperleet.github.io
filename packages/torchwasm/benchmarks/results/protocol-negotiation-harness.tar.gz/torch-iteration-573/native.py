from pathlib import Path
import json,sys,hashlib
import torch
import numpy as np
from workloads import Flow,inputs,EPS
r=Path(__file__).resolve().parent;label=sys.argv[1];arrays={}
for size in [256,512]:
 for kind in ['steady_single','steady_chain']:
  _,values=Flow(torch,lambda a,b:a@b,size,kind)()
  for i,value in enumerate(values):arrays[f'{size}_{kind}_{i}']=value
 aa,bb,cc,gg=inputs(size);a=torch.from_numpy(aa);g=torch.from_numpy(gg);ones=torch.ones_like(a)
 arrays[f'{size}_y_slope']=(a@ones*EPS).numpy().copy();arrays[f'{size}_da_slope']=(g@ones*EPS).numpy().copy()
np.savez_compressed(r/(label+'.npz'),**arrays);(r/(label+'.json')).write_text(json.dumps(dict(torch=torch.__version__,numpy=np.__version__,workloads_sha256=hashlib.sha256((r/'workloads.py').read_bytes()).hexdigest(),outputs=len(arrays)),indent=2)+'\n');print(json.dumps(dict(torch=torch.__version__,outputs=len(arrays))))
