from pathlib import Path
import hashlib,json,os,subprocess,time,traceback
r=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n');plan=read(r/'source-plan.json');receipts=[]
def verify():
 for name,h in plan['files'].items():assert sha(r/name)==h,name
try:
 assert not (r/'progress.json').exists()
 for cycle in [0,1,2]:
  for size in [256,512]:
   verify();label=str(size)+'-'+str(cycle);start=time.monotonic();target=r/('browser-result-'+label+'.json');assert not target.exists()
   with (r/(label+'.log')).open('w') as output:
    child=subprocess.Popen(['/Users/david/.local/share/fnm/node-versions/v22.22.1/installation/bin/node',str(r/'run-browser.mjs'),str(cycle),str(size)],cwd=r,stdout=output,stderr=subprocess.STDOUT);write(r/'progress.json',dict(status='running',label=label,pid=child.pid,supervisor_pid=os.getpid(),receipts=receipts));code=child.wait()
   receipt=dict(label=label,exit_code=code,seconds=time.monotonic()-start,log_sha256=sha(r/(label+'.log')));receipts.append(receipt);write(r/'receipts.json',receipts);print(json.dumps(receipt),flush=True);assert code==0,(label,(r/(label+'.log')).read_text()[-2500:]);verify()
   primary=read(target)['numerical']['rows'];ledger=[json.loads(v.removeprefix('BROWSER RESIDENT_SAMPLE ')) for v in (r/(label+'.log')).read_text().splitlines() if v.startswith('BROWSER RESIDENT_SAMPLE ')];assert primary==ledger and len(primary)==3
 write(r/'progress.json',dict(status='completed',receipts=receipts));print('Completed six preplanned processes',flush=True)
except BaseException as error:write(r/'progress.json',dict(status='failed',error=str(error),traceback=traceback.format_exc(),receipts=receipts));raise
