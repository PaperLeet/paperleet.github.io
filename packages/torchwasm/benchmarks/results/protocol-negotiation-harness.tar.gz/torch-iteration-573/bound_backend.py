class BoundBackend:
    def __init__(self, client, module):
        self.client, self.module = client, module
    def program(self, jobs, resolved, retain_outputs, retain_inputs):
        from matrix_client import MatrixProgram
        from types import SimpleNamespace
        program = self.module.MatrixProgram(self.client)
        refs, seen = {}, {}
        for a, b, _, _ in jobs:
            for value in (a, b):
                actual = resolved[id(value)]
                if id(actual) not in seen:
                    seen[id(actual)] = program.input(actual)
                refs[id(value)] = seen[id(actual)]
        outputs = [program.matmul(refs[id(a)], refs[id(b)], ta, tb) for a, b, ta, tb in jobs]
        retained = [refs[key] for key in retain_inputs]
        result = program.run(outputs, read=True, retain_inputs=retained, retain_outputs=retain_outputs)
        return SimpleNamespace(arrays=result.arrays, matrices=result.matrices,
                               inputs={key:result.input_matrices[refs[key]] for key in retain_inputs})

    def release(self, matrices):
        from pyodide.ffi import run_sync, to_js
        live = [matrix for matrix in matrices if not matrix.closed]
        if not live:
            return
        client = live[0].client
        if any(matrix.client != client for matrix in live):
            raise RuntimeError('Resident buffers belong to different sessions')
        if not client.closed:
            run_sync(client.releaseMany(to_js([matrix.handle for matrix in live])))
        for matrix in live:
            matrix.closed = True
