import numpy as np
EPS=1./4096.

def inputs(size):
 def array(mod,center):return ((np.arange(size*size)%mod-center)/8.).astype('float32').reshape(size,size)
 return array(17,8),array(13,6),array(19,9),array(11,5)

class Flow:
 def __init__(self,api,operation,size,kind):
  self.api,self.operation,self.kind,self.iteration=api,operation,kind,0
  aa,bb,cc,gg=inputs(size)
  self.a=api.from_numpy(aa).requires_grad_();self.b=api.from_numpy(bb).requires_grad_();self.c=api.from_numpy(cc).requires_grad_();self.g=api.from_numpy(gg)
 def __call__(self):
  index=self.iteration;y=self.operation(self.a,self.b)
  if self.kind=='steady_chain':
   z=self.operation(y,self.c);grads=self.api.autograd.grad(z,(self.a,self.b,self.c),self.g);tensors=(y,z,*grads)
  else:grads=self.api.autograd.grad(y,(self.a,self.b),self.g);tensors=(y,*grads)
  assert self.a.grad is None and self.b.grad is None and self.c.grad is None
  result=tuple(value.detach().numpy().copy() for value in tensors)
  if self.kind=='changing_rhs':
   with self.api.no_grad():self.b.add_(EPS)
   self.iteration+=1
  return index,result
 def close(self):
  method=getattr(self.operation,'close',None)
  if method is not None:method()
