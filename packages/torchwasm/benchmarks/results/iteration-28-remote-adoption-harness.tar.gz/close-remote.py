from pathlib import Path
import hashlib,json,re,subprocess,tarfile
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
def read(name):return json.loads((r/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
publication=read('publication.json');commit=publication['commit'];observed=read('remote-observer-terminal.json');assert observed['status']=='success' and observed['commit']==commit
quality=observed['runs']['quality'];pages=observed['runs']['pages'];assert quality['id']==38919796621 and pages['id']==38921426204
assert quality['head_sha']==pages['head_sha']==commit and quality['conclusion']==pages['conclusion']=='success'
for name in ('native','infrastructure','browser-wasm','pilot'):
 jobs=[j for j in quality['jobs'] if j['name']==name];assert len(jobs)==1 and jobs[0]['status']=='completed' and jobs[0]['conclusion']=='success'
deploy=[j for j in pages['jobs'] if j['name']=='deploy'];assert len(deploy)==1 and deploy[0]['conclusion']=='success' and all(s['conclusion']=='success' for s in deploy[0]['steps'])
for name,h in publication['source_hashes'].items():assert hashlib.sha256(subprocess.check_output(['git','show',commit+':packages/stridetorch/src/stridetorch/'+name],cwd=repo)).hexdigest()==h
for name,h in publication['export_sha256'].items():
 assert sha(r/'integration-proof/live-expected'/name)==h
 assert hashlib.sha256(subprocess.check_output(['git','show',commit+':web/public/data/'+name],cwd=repo)).hexdigest()==h
n=read('remote-native/ci.json');local_n=read('native-ci.json');w=read('remote-wasm/browser-wasm.json');local_w=read('integration-proof/full-wasm-result.json')
assert n['passed'] and not n['issues'] and n['problems']==78 and n['tests_executed']==10218 and n['repeats']==3 and n['duration_s']<=600
assert n['mutation']==local_n['mutation'] and sum(len(x) for x in n['mutation'].values())==342
assert w['passed'] and w['scope']=='catalog' and w['modules']==w['catalog_modules']==78 and not w['browser_budget_exceeded']
reference={case['id']:case for case in local_w['results']};assert len(w['results'])==len(reference)==78
for case in w['results']:
 expected=reference[case['id']]
 for key in ('tests','mutants','pyodide','numpy','backend','packages','bundle_url','runtime_bundle_url','source_sha256','budgets'):assert case[key]==expected[key],(case['id'],key)
 assert case['passed'] and not case['browser_budget_exceeded'];b=case['budgets'];assert case['calibration_ms']<=b['calibration'] and case['learner_ms']<=b['run'] and case['preparation_ms']+case['calibration_ms']+case['learner_ms']<=b['total']
contracts=next(c['independent_contracts'] for c in w['results'] if 'independent_contracts' in c);frozen=read('integration-proof/wasm-harness-identity.json');assert contracts['passed']==881 and len(contracts['suites'])==28
assert {s['suite']:s['source_sha256'] for s in contracts['suites']}==frozen['test_hashes']
text=(r/'remote-infrastructure.log').read_text();m=re.search(r'29402 passed, 1 skipped, 37 warnings in ([\d.]+)s',text);assert m
live=read('integration-proof/live-assets.json');assert live['status']=='success' and live['commit']==commit and live['modules']==78 and live['immutable_assets_equal']==158 and all(live[k] for k in ('starters_equal','manifests_equal','module_details_equal'))
files=['close-remote.py','publication.json','remote-observer-terminal.json','watch-remote.py','remote-infrastructure.log','remote-native/ci.json','remote-wasm/browser-wasm.json','integration-proof/verify-live.py','integration-proof/live-assets.json','integration-proof/live.log','integration-proof/live-expected-sha256.json','integration-proof/release-snapshot.json','integration-proof/wasm-harness-identity.json']
archive=out/'iteration-28-remote-adoption-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name in files:tar.add(r/name,arcname=name,recursive=False)
report=dict(status='actual_exact_source_quality_pages_and_live_verified',version='0.28.0',source_commit=commit,source_quality=quality,source_pages=pages,all_four_jobs_and_actual_deploy_steps_verified=True,source_hashes=publication['source_hashes'],export_files=161,source_base_passed=29402,source_optional_skips=1,source_infrastructure_s=float(m[1]),native=n,native_mutants=342,wasm={k:v for k,v in w.items() if k!='results'},wasm_mutants=sum(c['mutants'] for c in w['results']),independent_contracts=contracts,live=live,receipts=dict(observer=dict(session=88242,exit_code=0),live=dict(session=91147,exit_code=0),wasm_artifact_download=dict(session=8550,exit_code=0),infrastructure_log=dict(chunk='ec4027',exit_code=0)),download_note='Initial artifact name browser-wasm-report did not exist;discovered actual browser-wasm-reports via API and downloaded successfully. Original judge artifact present and validated byte/schema inputs;its first command exit was not separately captured.',archive=dict(file=archive.name,files=len(files),bytes=archive.stat().st_size,sha256=sha(archive)),timing_scope='Actual runner compatibility/budget gates;no cross-run speedup inference')
(out/'iteration-28-remote-adoption.json').write_text(json.dumps(report,indent=2)+'\n');(r/'remote-adoption.json').write_text(json.dumps(report,indent=2)+'\n')
state=read('state.json');state.update(phase='0.28 exact-main Quality/actual Pages/live fully verified',remote_adoption={k:report[k] for k in ('status','source_commit','source_base_passed','source_optional_skips','source_infrastructure_s','archive')});(r/'state.json').write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],native_s=n['duration_s'],wasm_ms=w['elapsed_ms'],infrastructure_s=float(m[1]),archive=report['archive']),indent=2))
