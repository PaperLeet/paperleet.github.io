from pathlib import Path
import hashlib,json,statistics
r=Path(__file__).resolve().parent;b=r.parent;lat=b/'torch-iteration-492';mem=b/'torch-iteration-493';read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
assert read(lat/'progress.json')['status']=='completed';assert read(mem/'progress.json')['status']=='completed'
config=read(lat/'config.json');gates=config['campaign_acceptance'];plan=read(lat/'source-plan.json')
for n,h in plan['files'].items():assert sha(lat/n)==h,n
for n,item in plan['payload'].items():assert sha((lat/item['source']).resolve())==item['sha256'],n
reports={};individual=[];aggregated=[];issues=[]
for runtime in config['runtimes']:
 reports[runtime]=[]
 for cycle in config['cycles']:
  p=lat/f'latency-{runtime}-{cycle}.json';x=read(p);report=x.get('report',x);assert report['config']==config and report['status']=='completed' and len(report['rows'])==24
  ledger=[json.loads(line) for line in p.with_suffix('.jsonl').read_text().splitlines()];assert ledger==report['rows']
  assert report['config_sha256']==sha(lat/'config.json');reports[runtime].append(report)
  for row in report['rows']:
   flags=[name for name in ['aa_passed','floor_passed','candidate_no_regression'] if not row[name]]
   if flags:individual.append(dict(runtime=runtime,cycle=cycle,key=row['spec']['key'],flags=flags,aa_ratio=row['aa_ratio'],paired_aa_ratio=row['paired_aa_ratio'],candidate_ratio=row['candidate_ratio'],paired_candidate_ratio=row['paired_candidate_ratio'],minimum_batch_seconds=row['minimum_batch_seconds']))
   if not row['floor_passed']:issues.append(dict(kind='measurement_floor',runtime=runtime,cycle=cycle,key=row['spec']['key']))
 for key in sorted({v['spec']['key'] for v in reports[runtime][0]['rows']}):
  rows=[next(v for v in report['rows'] if v['spec']['key']==key) for report in reports[runtime]]
  ratios={name:statistics.median(v[name] for v in rows) for name in ['aa_ratio','paired_aa_ratio','candidate_ratio','paired_candidate_ratio']}
  valid_aa=all(1-gates['aa_tolerance']<=ratios[n]<=1+gates['aa_tolerance'] for n in ['aa_ratio','paired_aa_ratio'])
  valid_b=all(ratios[n]<=gates['median_candidate_regression_threshold'] for n in ['candidate_ratio','paired_candidate_ratio'])
  maximum=max(v[n] for v in rows for n in ['candidate_ratio','paired_candidate_ratio']);valid_cap=maximum<=gates['maximum_individual_candidate_ratio']
  item=dict(runtime=runtime,key=key,ratios=ratios,aa_passed=valid_aa,candidate_median_no_regression=valid_b,maximum_individual_candidate_ratio=maximum,individual_cap_passed=valid_cap)
  aggregated.append(item)
  if not(valid_aa and valid_b and valid_cap):issues.append(dict(kind='aggregate_latency_gate',**item))
accept=read(r/'memory-acceptance.json')['required'];memory_rows=[];capabilities={}
for runtime in ['cpu25','cpu126','node','chrome']:
 x=read(mem/f'memory-{runtime}.json');report=x.get('report',x);assert report['status']=='passed_owned_flow_allocation_and_lifetime_observations' and len(report['rows'])==24
 capabilities[runtime]=report['trace_capability']
 if runtime.startswith('cpu') and not report['trace_capability']['numpy_data_tracking_verified']:issues.append(dict(kind='native_trace_unavailable',runtime=runtime))
 for row in report['rows']:
  old=row['observations']['baseline'];new=row['observations']['candidate'];a=old['tensor_backed_owner_high_water'];c=new['tensor_backed_owner_high_water'];assert a['owners']==a['bytes']==c['owners']==c['bytes']==0
  item=dict(runtime=runtime,spec=row['spec'],baseline_owner_peak_bytes=a['peak_bytes'],candidate_owner_peak_bytes=c['peak_bytes'],baseline_trace_peak_median=statistics.median(v['peak_extra_bytes'] for v in old['traced_peaks']) if old['traced_peaks'] else None,candidate_trace_peak_median=statistics.median(v['peak_extra_bytes'] for v in new['traced_peaks']) if new['traced_peaks'] else None)
  if c['peak_bytes']>a['peak_bytes']+accept['wasm_owner_peak_absolute_allowance_bytes']:issues.append(dict(kind='owner_peak_increase',**item))
  if item['baseline_trace_peak_median'] is not None:
   ap=item['baseline_trace_peak_median'];cp=item['candidate_trace_peak_median'];item['trace_peak_ratio']=cp/ap
   if cp>ap*(1+accept['native_control_peak_relative_allowance'])+accept['native_control_peak_absolute_allowance_bytes']:issues.append(dict(kind='traced_peak_increase',**item))
   if row['spec']['kind']=='scalar32_large' and cp/ap>accept['large_scalar32_float32_and_float64_peak_ratio_at_most']:issues.append(dict(kind='large_chain_peak_saving_insufficient',**item))
  memory_rows.append(item)
result=dict(status='qualified_preplanned_owned_flow_latency_and_allocation_gates' if not issues else 'inconclusive_or_failed_preplanned_gate',latency_processes=12,latency_process_flow_observations=288,latency_aggregate_contexts=96,latency_aggregate=aggregated,individual_process_flags=individual,memory_rows=memory_rows,trace_capabilities=capabilities,issues=issues,config_sha256=sha(lat/'config.json'),memory_acceptance_sha256=sha(r/'memory-acceptance.json'),production_changed=False,candidate_adopted=False,prior_hvp_campaigns_unchanged=True,goal_status='active')
assert not (r/'result.json').exists();write(r/'result.json',result);print(json.dumps(dict(status=result['status'],issues=len(issues),individual_process_flags=len(individual))))
