"""Apply the frozen candidate only after the predeclared qualification gates."""
from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
plan=read(r/'plan.json')
assert not (r/'result.json').exists()
assert sha(Path(__file__))==plan['applier_sha256']
for name,h in plan['production_inputs'].items():assert sha(repo/name)==h,name
for name,h in read(b/'torch-iteration-494/pre-execution-binding.json')['files'].items():assert sha(b/'torch-iteration-494'/name)==h,name
qualification=read(b/'torch-iteration-494/result.json');assert qualification['status']=='qualified_preplanned_owned_flow_latency_and_allocation_gates' and not qualification['issues']
assert read(b/'torch-iteration-495/result.json')['status']=='passed_candidate_lifetime_regressions_with_expected_baseline_failures'
assert read(b/'torch-iteration-497/progress.json')['status'] in ['completed','failed'],'Do not overlap application tests with GPU measurements'
source=repo/'packages/stridetorch/src/stridetorch'
for p in (b/'torch-iteration-491/baseline/stridetorch').iterdir():
 if p.is_file():assert sha(source/p.name)==sha(p),p.name
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip(),'Review current edits before applying source changes'
# No numerical helper, storage guard or higher-order optimization is changed.
shutil.copy2(b/'torch-iteration-491/candidate/stridetorch/_autograd.py',source/'_autograd.py')
p=source/'__init__.py';s=p.read_text();assert s.count("__version__ = '0.82.0'")==1;p.write_text(s.replace("__version__ = '0.82.0'","__version__ = '0.83.0'"))
p=repo/'packages/stridetorch/pyproject.toml';s=p.read_text();assert s.count('version = "0.82.0"')==1;p.write_text(s.replace('version = "0.82.0"','version = "0.83.0"'))
shutil.copy2(b/'torch-iteration-493/test_binary_operand_lifetime.py',repo/'packages/stridetorch/tests/test_binary_operand_lifetime.py')
p=repo/'packages/stridetorch/README.md';s=p.read_text();needle='Version **0.81**';assert s.count(needle)==1
s=s.replace(needle,"Version **0.83** is a development candidate that releases unused operand arrays\nfrom ordinary multiplication and direct-division pullbacks. Gradient arithmetic,\nsaved-value guards and higher-order rules retain their qualified 0.82 behavior.\nThe [development record](../../docs/validation/torch-runtime-0.83-development.md)\nseparates measured allocation/timing scope from application integration, which\nremains pending. Production WebGPU remains disabled.\n\n"+needle)
s=s.replace('### Gradient clipping (0.82, in development)','### Gradient clipping (0.82)');p.write_text(s)
summary=dict(status='applied_qualified_operand_lifetime_candidate_application_gate_pending',version='0.83.0',mathematical_source='Frozen491candidate;onlyversionliteralchangesafterqualification',qualification_sha256=sha(b/'torch-iteration-494/result.json'),new_sdk_regressions=10,application_qualified=False,packaging_qualified=False,main_adopted=False,ci_triggered=False,published=False,goal_status='active')
write(r/'result.json',summary);print(json.dumps(summary))
