from pathlib import Path
import hashlib,io,json,shutil,statistics,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
assert not (r/'operand-lifetime-owned-flow-harness.tar.gz').exists()
qualification=read(b/'torch-iteration-494/result.json');regression=read(b/'torch-iteration-495/result.json');assert regression['status']=='passed_candidate_lifetime_regressions_with_expected_baseline_failures'
assert read(b/'torch-iteration-497/progress.json')['status']=='completed'
for name,h in read(b/'torch-iteration-494/pre-execution-binding.json')['files'].items():assert sha(b/'torch-iteration-494'/name)==h,name
sources=read(b/'torch-iteration-491/source-plan.json')
for name,h in sources['files'].items():assert sha(b/'torch-iteration-491'/name)==h,name
cpu_gpu=[read(b/f'torch-iteration-496/browser-result-{i}.json') for i in [0,1,2]]
for x in cpu_gpu:
 assert x['status']=='passed' and x['numerical']['cases']==8 and x['worker']['origin']=='null' and not x['worker']['gpu_exposed']
 assert all(v['stats']['total_bytes']==0 and v['stats']['closed'] for v in x['host_disposals'])
gpu_rows=[]
for example in cpu_gpu[0]['numerical']['rows']:
 rows=[next(v for v in x['numerical']['rows'] if v['shape']==example['shape'] and v['resident']==example['resident']) for x in cpu_gpu]
 assert all(v['native_controls_passed'] and v['owned_outputs'] and v['inputs_unchanged'] for v in rows)
 gpu_rows.append(dict(shape=example['shape'],resident=example['resident'],cpu_seconds=statistics.median(v['median_seconds']['A0'] for v in rows),gpu_seconds=statistics.median(v['median_seconds']['G'] for v in rows),paired_gpu_over_cpu=[v['gpu_over_cpu_ratio'] for v in rows],paired_aa=[v['aa_ratio'] for v in rows],all_aa_passed=all(v['aa_within_five_percent'] for v in rows),minimum_gpu_batch_seconds=min(v['min_chunk_seconds']['G'] for v in rows),transfer_plan=example['transfer_plan']))
summary=dict(status='completed_owned_flow_and_current_cpu_gpu_experiments',baseline_version='0.82.0',allocation_and_latency_qualification=qualification,regression_checks=regression,current_cpu_gpu=dict(baseline_version='0.82.0',runtime_resources=66,baseline_includes_packed_wasm_matmul=True,processes=3,cases_per_process=8,rows=gpu_rows,all_aa_passed=all(v['all_aa_passed'] for v in gpu_rows),browser=[x['browser'] for x in cpu_gpu],gpu_info=[x['gpu_info'] for x in cpu_gpu],numerical_native26_and214_passed=True,default_quotas_unchanged=True,explicit_gpu_vjps=True,steady_state_only=True,short_chunks_retained=True,production_backend_qualified=False),source_changes_adopted=False,application_qualified=False,main_adopted=False,ci_triggered=False,published=False,goal_status='active')
write(r/'results.json',summary)
write(r/'replay-dependencies.json',dict(external=['Python3.12NumPy2.5.4andPython3.10NumPy1.26.4Torch2.6','Node22.22.1Chrome155Playwright','Pyodide0.29.4runtime76andNumPywheel;loaderfixture70;sourcehashesrecorded','ExistingindependentGPUoraclescopiedfrom338andverifiedagainstreadonlyinputfingerprints'],notes=['Adaptabsolutepathsforreplay','All12latencyprocessesandallindividualflagsretained;predefinedthree-processaggregateisscopeddifferentlyfrompriorHVPcampaigns','Peakmetricsseparateverifiedtracedallocations,Tensor-ownerhigh-water,WASMheapcapacityandRSS','GPUcomparisonusesactual0.82CPUautogradandexplicitGPUVJPprogramswiththreeownedcopies;notautomaticTorchGPUbackend','DefaultGPUlimitsandoriginalshortbatchcapsunchanged']))
files=[]
for stage in [491,492,493,494,495,496,497,498]:files.extend(p for p in (b/f'torch-iteration-{stage}').rglob('*') if p.is_file() and '__pycache__' not in p.parts)
files.extend([r/'archive.py',r/'results.json',r/'replay-dependencies.json']);files=sorted(set(files));manifest={str(p.relative_to(b)):sha(p) for p in files};seen={};target=r/'operand-lifetime-owned-flow-harness.tar.gz'
with tarfile.open(target,'w:gz') as archive:
 for p in files:
  name=str(p.relative_to(b));h=manifest[name]
  if h in seen:
   info=archive.gettarinfo(str(p),arcname=name);info.type=tarfile.LNKTYPE;info.linkname=seen[h];info.size=0;archive.addfile(info)
  else:archive.add(p,arcname=name,recursive=False);seen[h]=name
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256.json');info.size=len(data);archive.addfile(info,io.BytesIO(data))
with tarfile.open(target) as archive:
 for name,h in manifest.items():assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==h,name
receipt=dict(path='packages/stridetorch/benchmarks/results/'+target.name,files=len(files),unique_payloads=len(seen),bytes=target.stat().st_size,sha256=sha(target),all_payloads_verified=True);write(r/'archive-receipt.json',receipt);summary['raw_archive']=receipt
write(repo/'packages/stridetorch/benchmarks/results/operand-lifetime-owned-flow.json',summary);shutil.copy2(target,repo/receipt['path']);print(json.dumps(receipt))
