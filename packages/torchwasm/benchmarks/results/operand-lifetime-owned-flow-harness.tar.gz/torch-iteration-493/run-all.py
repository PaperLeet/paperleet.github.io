from pathlib import Path
import hashlib,json,os,subprocess,time,traceback
r=Path(__file__).resolve().parent;b=r.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n');receipts=[];plan=read(r/'source-plan.json')
node=Path('/Users/david/.local/share/fnm/node-versions/v22.22.1/installation/bin/node');env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');env.pop('PYTHONPATH',None)
def verify():
 for n,h in plan['files'].items():assert sha(r/n)==h,n
 for n,item in plan['payload'].items():assert sha((r/item['source']).resolve())==item['sha256'],n
try:
 assert not (r/'progress.json').exists();write(r/'progress.json',dict(status='waiting_for_latency_campaign',supervisor_pid=os.getpid(),receipts=[]))
 while True:
  status=read(b/'torch-iteration-492/progress.json');assert status['status']!='failed','Latencycampaignsupervisorfailed;holdmemoryjobstoavoidinterferencewithrecovery'
  if status['status']=='completed':assert len(status['receipts'])==12;break
  time.sleep(5)
 for runtime in ['cpu25','cpu126','node','chrome']:
  verify();target=r/('memory-'+runtime+'.json');assert not target.exists();python=b/('torch-iteration-82/application-env/bin/python' if runtime=='cpu25' else 'torch-iteration-137/native26-env/bin/python')
  command=[str(python),'-B',str(r/'memory.py'),'--source-root',str(b/'torch-iteration-491'),'--output',str(target)] if runtime.startswith('cpu') else [str(node),str(r/'run.mjs'),runtime]
  with (r/(runtime+'.log')).open('w') as log:
   child=subprocess.Popen(command,env=env,cwd=r,stdout=log,stderr=subprocess.STDOUT);write(r/'progress.json',dict(status='running',label=runtime,pid=child.pid,supervisor_pid=os.getpid(),receipts=receipts));code=child.wait()
  receipt=dict(runtime=runtime,exit_code=code,command=command,log_sha256=sha(r/(runtime+'.log')));receipts.append(receipt);write(r/'receipts.json',receipts);print(json.dumps(receipt),flush=True);assert code==0;verify()
 write(r/'progress.json',dict(status='completed',receipts=receipts))
except BaseException as error:write(r/'progress.json',dict(status='failed',error=str(error),traceback=traceback.format_exc(),receipts=receipts));raise
