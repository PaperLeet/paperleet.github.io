import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
export async function execute(plan,read,diagnostic){
 const url=new URL('../torch-iteration-76/runtime/',import.meta.url),py=await loadPyodide({indexURL:url.protocol==='file:'?decodeURIComponent(url.pathname):url.href,stdout:diagnostic,stderr:diagnostic});await py.loadPackage('numpy');py.runPython('import sys;sys.dont_write_bytecode=True');
 for(const[name,item]of Object.entries(plan.payload)){const bytes=await read(item);py.FS.mkdirTree('/qualification/'+name.split('/').slice(0,-1).join('/'));py.FS.writeFile('/qualification/'+name,bytes);}
 const before=py._module.HEAPU8.buffer.byteLength;
 const report=JSON.parse(py.runPython("import runpy,sys,json;sys.argv=['/qualification/memory.py','--source-root','/qualification','--output','/result.json'];runpy.run_path(sys.argv[0],run_name='__main__');json.dumps(json.load(open('/result.json')))"));
 return {report,pyodide:py.version,heap_capacity_before:before,heap_capacity_after:py._module.HEAPU8.buffer.byteLength};
}
