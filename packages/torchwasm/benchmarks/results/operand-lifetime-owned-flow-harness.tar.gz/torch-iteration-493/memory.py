"""Separate traced NumPy/Python peaks and Tensor-backed owner high-water marks."""
from pathlib import Path
import argparse,gc,hashlib,importlib,importlib.util,json,sys,weakref
import numpy as np
parser=argparse.ArgumentParser();parser.add_argument('--source-root',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();source=args.source_root.resolve();sys.path.insert(0,str(source))
from workloads import specs,arrays,setup,compare
reference=json.loads((source/'native26.json').read_text());assert hashlib.sha256((source/'workloads.py').read_bytes()).hexdigest()==reference['workloads_sha256']
def load(variant):
 folder=source/variant/'stridetorch';name='_allocation493_'+variant;s=importlib.util.spec_from_file_location(name,folder/'__init__.py',submodule_search_locations=[str(folder)]);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
modules={variant:load(variant) for variant in ['baseline','candidate']}
trace=None;capability={}
try:
 import tracemalloc as trace
 gc.collect();trace.start();before,_=trace.get_traced_memory();probe=np.empty(131072,dtype=np.float64);held,peak=trace.get_traced_memory();size=probe.nbytes;del probe;gc.collect();after,_=trace.get_traced_memory();trace.stop()
 capability=dict(available=True,numpy_buffer_probe_bytes=size,observed_held_extra_bytes=held-before,observed_peak_extra_bytes=peak-before,after_release_extra_bytes=after-before,numpy_data_tracking_verified=held-before>=size)
except (ImportError,RuntimeError) as error:capability=dict(available=False,error=str(error),numpy_data_tracking_verified=False)
rows=[]
for spec,ref in zip(specs(),reference['rows']):
 data=arrays(spec);observations={};expected=None
 for variant,module in modules.items():
  invoke=setup(module.torch,spec,data)
  for _ in range(3):values=invoke();compare(values,ref['outputs'])
  if expected is None:expected=[a.copy() for a in values]
  else:assert all(a.dtype==e.dtype and a.shape==e.shape and a.tobytes()==e.tobytes() for a,e in zip(values,expected)),spec
  del values;gc.collect();peaks=[]
  if capability['numpy_data_tracking_verified']:
   for _ in range(3):
    gc.collect();trace.start();before,_=trace.get_traced_memory();values=invoke();held,peak=trace.get_traced_memory();output_bytes=sum(a.nbytes for a in values);del values;gc.collect();after,_=trace.get_traced_memory();trace.stop()
    peaks.append(dict(peak_extra_bytes=peak-before,held_output_extra_bytes=held-before,after_release_extra_bytes=after-before,owned_output_bytes=output_bytes))
  tensor=importlib.import_module(module.__name__+'._tensor');state=importlib.import_module(module.__name__+'._state');original=tensor.Tensor.__init__;tracked={};refs=[];live=dict(bytes=0,owners=0,peak_bytes=0,peak_owners=0,total_owners=0,total_bytes=0)
  def track(self,*a,**kw):
   original(self,*a,**kw);owner=self._data
   while isinstance(owner.base,np.ndarray):owner=owner.base
   key=id(owner)
   if key in tracked and tracked[key]() is owner:return
   size=owner.nbytes;live['bytes']+=size;live['owners']+=1;live['total_owners']+=1;live['total_bytes']+=size;live['peak_bytes']=max(live['peak_bytes'],live['bytes']);live['peak_owners']=max(live['peak_owners'],live['owners'])
   def released(reference):
    if tracked.get(key) is reference:
     tracked.pop(key);live['bytes']-=size;live['owners']-=1
   reference=weakref.ref(owner,released);tracked[key]=reference;refs.append(reference)
  tensor.Tensor.__init__=track
  try:
   for _ in range(3):values=invoke();assert all(a.flags.owndata and a.base is None for a in values);del values
  finally:tensor.Tensor.__init__=original
  gc.collect();assert live['owners']==live['bytes']==0 and not tracked,(spec,variant,live)
  assert state._tensor_reverse_context is None and state._grad_enabled
  observations[variant]=dict(traced_peaks=peaks,tensor_backed_owner_high_water=live,instrumented_calls=3,owned_outputs_verified=True)
 del expected
 rows.append(dict(spec=spec,observations=observations));print('ALLOCATION_FLOW '+spec['key'],flush=True)
report=dict(status='passed_owned_flow_allocation_and_lifetime_observations',rows=rows,trace_capability=capability,numpy=np.__version__,python=sys.version,platform=sys.platform,scope='UninstrumentedtracemallocpeakswhenNumPydata-trackingprobeverified;separateTensor-backed-ownerhigh-waterandpost-releaseweakrefs;fixturesoutsideclockbutcopiesinsideflow;notRSSorwholeWASMheappeak;unwrappedNumPytemporaries/outputcopiesonlyincludedintracedpeaks')
assert not args.output.exists();args.output.write_text(json.dumps(report,indent=2)+'\n')
