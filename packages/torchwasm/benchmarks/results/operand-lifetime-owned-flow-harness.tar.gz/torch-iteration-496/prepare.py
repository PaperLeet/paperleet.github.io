from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');old=b/'torch-iteration-338';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
load=read(old/'load-plan.json');items={}
for name,item in load['files'].items():
 if name.startswith('stridetorch/') or name=='measure-matrix.py':continue
 target=r/item['source'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old/item['source'],target);items[name]=dict(source=item['source'],sha256=sha(target))
for p in (b/'torch-iteration-491/baseline/stridetorch').iterdir():
 if p.is_file():
  name='stridetorch/'+p.name;target=r/'payload'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);items[name]=dict(source=str(target.relative_to(r)),sha256=sha(target))
assert len([n for n in items if n.startswith('stridetorch/')])==66
for name in ['rpc-client.mjs','gpu-service.mjs','plan-program.mjs','matrix_client.py','torch_workload.py']:
 source=repo/'packages/stridetorch/benchmarks/webgpu_rpc'/name
 # The existing numerical fixture and workload must stay the same.
 if name in ['matrix_client.py','torch_workload.py']:
  assert sha(source)==sha(r/items[name]['source']),name
 else:assert sha(source)==sha(old/name),name
 shutil.copy2(source,r/name)
s=(old/'measure-matrix.py').read_text();assert "stridetorch.__version__ == '0.80.0'" in s;(r/'measure-matrix.py').write_text(s.replace("stridetorch.__version__ == '0.80.0'","stridetorch.__version__ == '0.82.0'"))
items['measure-matrix.py']=dict(source='measure-matrix.py',sha256=sha(r/'measure-matrix.py'));write(r/'load-plan.json',dict(files=items))
(r/'run-browser.mjs').write_bytes((old/'run-browser.mjs').read_bytes())
write(r/'source-plan.json',dict(frozen_utc=datetime.now(timezone.utc).isoformat(),source_version='0.82.0',source_head='21667758ef8d5c9b7c0e2785ad973bd9fd7a0e1c',baseline='Frozen491baseline66resources;includes0.81packedWASMmatrixkernelsand0.82clippingnamespace;actualTorchCPUautograd',runs=[0,1,2],controls='Unchanged338A0/A1paired5percent;all8cases/3processes;allrawbatchesincludingoldshortGPUchunksretained;noindividualfavourablereruns',limits='All11defaultlimitsunchanged;100secondfixturedeadline;120secondlease;explicitmanualGPUVJPsnotautomaticTorchGPUbackend',scope='RepeatmatchedcurrentCPUcomparisononlyafterlatency/allocation/regressionjobsareterminal;allthreeownedoutputcopiesandcold/residentinputsemanticsunchanged',files={str(p.relative_to(r)):sha(p) for p in r.rglob('*') if p.is_file()}))
print(json.dumps(dict(status='prepared_unexecuted',version='0.82.0',resources=66,runs=3)))
