"""Whole-call measurements; manual GPU VJPs are not a Torch GPU backend."""
import gc
import itertools
import json
import math
import statistics
import time

import numpy as np
from pyodide.ffi import run_sync
from js import matrix_rpc
import stridetorch
import matrix_client
import torch_workload as workloads

cycle = int(_cycle)
assert cycle in (0, 1, 2)
assert stridetorch.__version__ == '0.82.0'
limits = json.loads(_limits_json)
assert limits == dict(bytes=33554432, matrixBytes=4194304, dimension=1024,
                     macs=268435456, handles=24, pending=8, requests=4096, leaseMs=120000,
                     programInputs=8, programNodes=8, programOutputs=8)
meta = json.load(open('/native-meta.json'))
oracles = [np.load('/native26.npz', allow_pickle=False), np.load('/native214.npz', allow_pickle=False)]
initial_err, initial_handler = np.geterr(), np.geterrcall()
initial_gc = gc.isenabled()
rows = []
permutations = list(itertools.permutations(('A0', 'A1', 'G')))
orders = permutations + list(reversed(permutations))
specs = [(i, shape, resident) for i, shape in enumerate(workloads.specifications()) for resident in (False, True)]
specs = specs[cycle:] + specs[:cycle]


def verify(actual, index, values, reference=None):
    assert len(actual) == 3
    for output, label in zip(actual, ('forward', 'left_vjp', 'right_vjp')):
        assert output.dtype == np.dtype('float32')
        owner = output
        while isinstance(owner.base, np.ndarray):
            owner = owner.base
        assert owner.flags.owndata and owner.base is None
        assert all(not np.shares_memory(output, value) for value in values)
        if reference is None:
            for oracle in oracles:
                expected = oracle[f'case{index}_{label}']
                assert output.shape == expected.shape
                np.testing.assert_allclose(output, expected, rtol=1e-5, atol=1e-6)
    assert all(not np.shares_memory(a, b) for i, a in enumerate(actual) for b in actual[i+1:])
    if reference is not None:
        for value, expected in zip(actual, reference):
            np.testing.assert_array_equal(value, expected)


def timed(operation, count):
    start = time.perf_counter()
    for _ in range(count):
        output = operation()
    return time.perf_counter() - start, output


for index, shape, resident in specs:
    values = workloads.make_inputs(shape)
    before = workloads.fingerprint(values)
    assert list(shape) == meta['cases'][index]['shape']
    assert json.loads(json.dumps(before)) == meta['cases'][index]['input_fingerprint']
    operations, setup, references, calibration, counts = {}, {}, {}, {}, {}
    try:
        for label in ('A0', 'A1', 'G'):
            start = time.perf_counter()
            operations[label] = (workloads.GpuMatrixStep(matrix_client, values, resident=resident)
                                 if label == 'G' else workloads.TorchMatrixStep(stridetorch.torch, values, resident=resident))
            setup[label] = time.perf_counter() - start
        for label in ('A0', 'A1', 'G'):
            references[label] = operations[label]()
            verify(references[label], index, values)
        gc.collect()
        gc.disable()
        try:
            for label in ('A0', 'A1', 'G'):
                count, samples = 1, []
                cap = 8 if label == 'G' else 8192
                while True:
                    elapsed, output = timed(operations[label], count)
                    samples.append(dict(iterations=count, elapsed_seconds=elapsed))
                    verify(output, index, values, references[label])
                    if elapsed >= .080 or count == cap:
                        break
                    count = min(cap, max(count + 1, math.ceil(count * .100 / max(elapsed, 1e-6))))
                calibration[label] = samples
                counts[label] = min(cap, max(1, math.ceil(count * .040 / elapsed)))
            raw = []
            for round_index, order in enumerate(orders):
                samples = {}
                for label in order:
                    elapsed, output = timed(operations[label], counts[label])
                    verify(output, index, values, references[label])
                    samples[label] = dict(iterations=counts[label], elapsed_seconds=elapsed,
                                          seconds_per_call=elapsed / counts[label])
                raw.append(dict(round=round_index, order=order, samples=samples))
        finally:
            if initial_gc:
                gc.enable()
        stats = run_sync(matrix_rpc.stats()).to_py()
        expected_handles = 3 if resident else 0
        expected_bytes = sum(value.nbytes for value in values) if resident else 0
        assert stats['resident_handles'] == expected_handles
        assert stats['total_bytes'] == stats['resident_bytes'] == expected_bytes
        assert workloads.fingerprint(values) == before
        aa = statistics.median(r['samples']['A1']['seconds_per_call'] / r['samples']['A0']['seconds_per_call'] for r in raw)
        ga = statistics.median(r['samples']['G']['seconds_per_call'] / r['samples']['A0']['seconds_per_call'] for r in raw)
        rows.append(dict(shape=shape, resident=resident, setup_seconds=setup, calibration=calibration,
                         iterations=counts, raw=raw, aa_ratio=aa, aa_within_five_percent=.95 <= aa <= 1.05,
                         gpu_over_cpu_ratio=ga,
                         median_seconds={label: statistics.median(r['samples'][label]['seconds_per_call'] for r in raw) for label in ('A0', 'A1', 'G')},
                         min_chunk_seconds={label: min(r['samples'][label]['elapsed_seconds'] for r in raw) for label in ('A0', 'A1', 'G')},
                         transfer_plan=workloads.description(values, resident), resource_stats=stats,
                         inputs_unchanged=True, owned_outputs=True, native_controls_passed=True))
    finally:
        for operation in operations.values():
            operation.close()
        if initial_gc:
            gc.enable()
    stats = run_sync(matrix_rpc.stats()).to_py()
    assert stats['resident_handles'] == stats['total_bytes'] == stats['allocations'] == 0
    print(json.dumps(dict(phase='measured_case', cycle=cycle, shape=shape, resident=resident, aa_ratio=aa, gpu_over_cpu_ratio=ga)), flush=True)

assert len(rows) == 8 and np.geterr() == initial_err and np.geterrcall() is initial_handler
assert gc.isenabled() == initial_gc
assert not stridetorch.torch.cuda.is_available()
report = dict(status='passed_matched_whole_call_measurement', cycle=cycle, cases=8, rows=rows,
              limits=limits, source_version=stridetorch.__version__, numpy=np.__version__,
              final_stats=run_sync(matrix_rpc.stats()).to_py(), latency_measured=True,
              torch_gpu_backend_enabled=False, all_aa_controls_passed=all(row['aa_within_five_percent'] for row in rows),
              scope='Actual Torch-compatible CPU autograd forward and two VJPs versus explicit GPU programs. Every call returns three owned CPU arrays; resident input setup measured separately. Manual VJPs do not establish a Torch GPU backend.')
