"""Preplanned balanced whole-call timing with ordinary garbage collection."""
from pathlib import Path
import argparse,gc,hashlib,importlib.util,itertools,json,math,statistics,sys,time
import numpy as np
parser=argparse.ArgumentParser();parser.add_argument('--source-root',type=Path,required=True);parser.add_argument('--config',type=Path,required=True);parser.add_argument('--cycle',type=int,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();source=args.source_root.resolve();sys.path.insert(0,str(source))
from workloads import specs,arrays,setup,compare
config=json.loads(args.config.read_text());reference=json.loads((source/'native26.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(source/'workloads.py')==reference['workloads_sha256'] and len(specs())==config['flows']==24
assert args.cycle in config['cycles'] and gc.isenabled()
def load(label,variant):
 folder=source/variant/'stridetorch';name='_lifetime492_'+label;s=importlib.util.spec_from_file_location(name,folder/'__init__.py',submodule_search_locations=[str(folder)]);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
modules={label:load(label,'candidate' if label=='B' else 'baseline') for label in ['A0','A1','B']};orders=list(itertools.permutations(modules));offset=args.cycle%len(orders);orders=orders[offset:]+orders[:offset];orders+=list(reversed(orders))
pairs=list(zip(specs(),reference['rows']));offset=(args.cycle*7)%len(pairs);pairs=pairs[offset:]+pairs[:offset];rows=[]
for spec,ref in pairs:
 assert spec==ref['spec'];data=arrays(spec);calls={};baseline=None
 for label,module in modules.items():
  invoke=setup(module.torch,spec,data);values=invoke();compare(values,ref['outputs'])
  if baseline is None:baseline=values
  else:assert all(a.dtype==e.dtype and a.shape==e.shape and a.tobytes()==e.tobytes() for a,e in zip(values,baseline)),(spec,label)
  warm=time.perf_counter()
  while time.perf_counter()-warm<config['warmup_seconds']:invoke()
  calls[label]=invoke
 del values,baseline
 calibration={};counts=[];samples={label:[] for label in modules}
 for label in list(modules)[args.cycle:]+list(modules)[:args.cycle]:
  count=1;attempts=[]
  while True:
   gc.collect();start=time.perf_counter()
   for _ in range(count):calls[label]()
   elapsed=time.perf_counter()-start;attempts.append(dict(iterations=count,seconds=elapsed))
   if elapsed>=config['calibration_seconds'] or count>=config['iteration_cap']:break
   count=min(count*2,config['iteration_cap'])
  calibration[label]=attempts;counts.append(min(config['iteration_cap'],max(1,math.ceil(count*config['target_batch_seconds']/elapsed))))
 count=max(counts)
 for order in orders:
  for label in order:
   gc.collect();start=time.perf_counter()
   for _ in range(count):calls[label]()
   elapsed=time.perf_counter()-start;samples[label].append(dict(iterations=count,batch_seconds=elapsed,seconds_per_call=elapsed/count))
 medians={label:statistics.median(v['seconds_per_call'] for v in values) for label,values in samples.items()}
 paired_aa=statistics.median(y['seconds_per_call']/x['seconds_per_call'] for x,y in zip(samples['A0'],samples['A1']));paired_b=statistics.median(y['seconds_per_call']/x['seconds_per_call'] for x,y in zip(samples['A0'],samples['B']))
 aa=medians['A1']/medians['A0'];ratio=medians['B']/medians['A0'];minimum=min(v['batch_seconds'] for values in samples.values() for v in values)
 row=dict(spec=spec,orders=orders,count=count,calibration=calibration,samples=samples,medians=medians,aa_ratio=aa,paired_aa_ratio=paired_aa,candidate_ratio=ratio,paired_candidate_ratio=paired_b,minimum_batch_seconds=minimum,aa_passed=all(1-config['aa_tolerance']<=v<=1+config['aa_tolerance'] for v in [aa,paired_aa]),floor_passed=minimum>=config['minimum_batch_seconds'],candidate_no_regression=all(v<=config['regression_threshold'] for v in [ratio,paired_b]),owned_outputs=True,normal_gc_enabled=gc.isenabled())
 rows.append(row)
 with (args.output.with_suffix('.jsonl')).open('a') as ledger:ledger.write(json.dumps(row,allow_nan=False)+'\n');ledger.flush()
 print('LIFETIME_SAMPLE '+json.dumps(dict(key=spec['key'],aa=aa,paired_aa=paired_aa,candidate=ratio,paired_candidate=paired_b,minimum=minimum)),flush=True)
report=dict(status='completed',cycle=args.cycle,rows=rows,config=config,config_sha256=sha(args.config),workloads_sha256=sha(source/'workloads.py'),native_reference_sha256=sha(source/'native26.json'),numpy=np.__version__,python=sys.version,platform=sys.platform,scope='Wholeforward/grad/HVPplusownedcopies;fixturescopiedwithinflow;normalGCenabled;explicitGCbeforeeachbatchoutsideclock;instrumentationseparate')
assert not args.output.exists();args.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
