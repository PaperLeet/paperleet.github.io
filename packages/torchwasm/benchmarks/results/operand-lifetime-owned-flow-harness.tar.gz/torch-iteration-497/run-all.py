from pathlib import Path
import hashlib,json,os,subprocess,time,traceback
r=Path(__file__).resolve().parent;b=r.parent;experiment=b/'torch-iteration-496';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n');receipts=[];node='/Users/david/.local/share/fnm/node-versions/v22.22.1/installation/bin/node'
try:
 assert not (r/'plan.json').exists();write(r/'plan.json',dict(runner_sha256=sha(Path(__file__)),source_plan_sha256=sha(experiment/'source-plan.json'),prerequisite='495allterminalafter492and493',runs=[0,1,2],scope='ThreefreshChromeGPUprocesses,currentfrozen0.82CPUbaseline;originalprotocoland8wholeownedflowsunchanged'))
 write(r/'progress.json',dict(status='waiting_for_prior_campaigns',supervisor_pid=os.getpid(),receipts=[]))
 while True:
  p=b/'torch-iteration-495/progress.json'
  if p.exists():
   status=read(p);assert status['status']!='failed','Regressionchainfailed;holdGPUtiminguntilinspected'
   if status['status']=='completed':break
  time.sleep(5)
 for cycle in [0,1,2]:
  assert sha(experiment/'source-plan.json')==read(r/'plan.json')['source_plan_sha256'];assert not (experiment/f'browser-result-{cycle}.json').exists()
  with (r/f'run-{cycle}.log').open('w') as log:
   child=subprocess.Popen([node,str(experiment/'run-browser.mjs'),str(cycle)],cwd=experiment,stdout=log,stderr=subprocess.STDOUT);write(r/'progress.json',dict(status='running',cycle=cycle,pid=child.pid,supervisor_pid=os.getpid(),receipts=receipts));code=child.wait()
  receipt=dict(cycle=cycle,exit_code=code,log_sha256=sha(r/f'run-{cycle}.log'));receipts.append(receipt);write(r/'receipts.json',receipts);print(json.dumps(receipt),flush=True);assert code==0
 write(r/'progress.json',dict(status='completed',receipts=receipts))
except BaseException as error:write(r/'progress.json',dict(status='failed',error=str(error),traceback=traceback.format_exc(),receipts=receipts));raise
