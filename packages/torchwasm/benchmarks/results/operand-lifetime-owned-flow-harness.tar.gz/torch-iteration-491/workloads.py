"""Whole ordinary grad/HVP calls with independent owned NumPy outputs."""
import base64
import numpy as np

def specs():
 result=[]
 for dtype in ['float32','float64']:
  for kind,size in [('scalar1',32),('scalar8',64),('scalar32',128),('scalar32_large',256),('tensor_left',64),('tensor_right',64),('mixed_left',64),('divide_left',64),('both_mul',64),('both_div',64),('add_control',32),('hvp_control',32)]:
   result.append(dict(key=dtype+'/'+kind,dtype=dtype,kind=kind,size=size))
 return result

def arrays(spec):
 n=spec['size'];dtype=spec['dtype']
 a=np.linspace(.75,1.25,n*n,dtype=dtype).reshape(n,n)
 other_dtype=('float64' if dtype=='float32' else 'float32') if spec['kind']=='mixed_left' else dtype
 b=np.linspace(1.25,1.75,n*n,dtype=other_dtype).reshape(n,n)
 return a,b

def setup(api,spec,data):
 raw,constant=data;kind=spec['kind']
 def invoke():
  x=api.from_numpy(raw.copy()).requires_grad_()
  if kind=='hvp_control':
   value,product=api.autograd.functional.hvp(lambda z:(z*2.).square().sum(),x,api.ones_like(x))
   assert x.grad is None
   return value.detach().numpy().copy(),product.detach().numpy().copy()
  both=kind in ['both_mul','both_div','add_control']
  g=x+.25
  if kind.startswith('scalar'):
   count=32 if kind=='scalar32_large' else int(kind[6:]);value=g
   for index in range(count):value=value*(2. if index%2==0 else .5)
   targets=(x,)
  else:
   y=api.from_numpy(constant.copy()).requires_grad_(both);h=y+.5
   if kind in ['tensor_left','mixed_left']:value=g*h
   elif kind=='tensor_right':value=h*g
   elif kind=='divide_left':value=g/h
   elif kind=='both_mul':value=g*h
   elif kind=='both_div':value=g/h
   else:value=g+h
   targets=(x,y) if both else (x,)
  loss=value.square().sum();gradients=api.autograd.grad(loss,targets)
  assert all(target.grad is None for target in targets)
  return (value.detach().numpy().copy(),loss.detach().numpy().copy(),*(g.detach().numpy().copy() for g in gradients))
 return invoke

def packed(values):return [dict(dtype=a.dtype.str,shape=list(a.shape),bytes=base64.b64encode(a.tobytes()).decode()) for a in values]
def unpacked(value):return np.frombuffer(base64.b64decode(value['bytes']),dtype=value['dtype']).reshape(value['shape'])
def compare(values,reference):
 assert len(values)==len(reference)
 for a,ref in zip(values,reference):
  expected=unpacked(ref);assert a.shape==expected.shape and a.dtype==expected.dtype
  np.testing.assert_allclose(a,expected,rtol=8e-6 if a.dtype.itemsize==4 else 4e-12,atol=2e-6 if a.dtype.itemsize==4 else 1e-12)
  assert a.flags.owndata and a.base is None
