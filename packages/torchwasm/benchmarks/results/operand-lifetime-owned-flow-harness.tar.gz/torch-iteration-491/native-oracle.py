from pathlib import Path
import hashlib,json
import torch
from workloads import specs,arrays,setup,packed
r=Path(__file__).resolve().parent;rows=[]
for spec in specs():rows.append(dict(spec=spec,outputs=packed(setup(torch,spec,arrays(spec))())))
assert not (r/'native26.json').exists();(r/'native26.json').write_text(json.dumps(dict(torch=torch.__version__,workloads_sha256=hashlib.sha256((r/'workloads.py').read_bytes()).hexdigest(),rows=rows),indent=2)+'\n');print(json.dumps(dict(status='recorded',cases=len(rows),torch=torch.__version__)))
