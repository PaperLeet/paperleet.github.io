from pathlib import Path
import hashlib,importlib.util,json,sys
from workloads import specs,arrays,setup,compare
r=Path(__file__).resolve().parent;reference=json.loads((r/'native26.json').read_text());assert reference['workloads_sha256']==hashlib.sha256((r/'workloads.py').read_bytes()).hexdigest()
results=[]
for spec,ref in zip(specs(),reference['rows']):
 old=None
 for variant in ['baseline','candidate']:
  name='_preflight491_'+variant
  if name not in sys.modules:
   folder=r/variant/'stridetorch';s=importlib.util.spec_from_file_location(name,folder/'__init__.py',submodule_search_locations=[str(folder)]);module=importlib.util.module_from_spec(s);sys.modules[name]=module;s.loader.exec_module(module)
  api=sys.modules[name].torch;values=setup(api,spec,arrays(spec))();compare(values,ref['outputs'])
  if old is None:old=values
  else:assert all(a.dtype==e.dtype and a.shape==e.shape and a.tobytes()==e.tobytes() for a,e in zip(values,old)),spec
 results.append(spec['key'])
print(json.dumps(dict(status='passed_full_owned_flow_preflight',flows=len(results),keys=results)))
