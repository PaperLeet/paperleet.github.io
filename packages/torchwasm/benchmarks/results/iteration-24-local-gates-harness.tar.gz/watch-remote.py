"""Observe tested-main Quality and its deferred Pages run; never dispatch deploy."""
from pathlib import Path
import datetime,json,subprocess,time
root=Path(__file__).parent;publication=json.loads((root/'publication.json').read_text());commit=publication['commit'];quality_id=publication['quality_id'];start=time.monotonic();last=None;errors=[]
def api(path):
 r=subprocess.run(['gh','api','repos/PaperLeet/paperleet.github.io/'+path],text=True,capture_output=True,timeout=60)
 if r.returncode:raise RuntimeError(r.stderr[-1500:])
 return json.loads(r.stdout)
def observe(run):
 jobs=api(f"actions/runs/{run['id']}/jobs?filter=latest&per_page=100")['jobs']
 return dict(id=run['id'],status=run['status'],conclusion=run['conclusion'],head_sha=run['head_sha'],event=run['event'],url=run['html_url'],jobs=[dict(name=j['name'],id=j['id'],status=j['status'],conclusion=j['conclusion'],current_steps=[s['name'] for s in j.get('steps',[]) if s['status']=='in_progress'],steps=[dict(name=s['name'],status=s['status'],conclusion=s['conclusion']) for s in j.get('steps',[])]) for j in jobs])
def save(report,terminal=None,code=0):
 (root/'remote-state.tmp').write_text(json.dumps(report,indent=2)+'\n');(root/'remote-state.tmp').replace(root/'remote-state.json')
 if terminal:
  (root/'remote-observer-terminal.json').write_text(json.dumps(dict(status=terminal,**report),indent=2)+'\n');raise SystemExit(code)
while time.monotonic()-start<2700:
 try:
  quality=api(f'actions/runs/{quality_id}');assert quality['head_sha']==commit
  runs={'quality':observe(quality)}
  pages=[p for p in api('actions/workflows/pages.yml/runs?per_page=50')['workflow_runs'] if p['head_sha']==commit and p['event']=='workflow_run']
  # Other Quality runs can create skipped Pages runs with this same default-branch
  # head_sha. A skipped build is not this tested commit's deployment evidence.
  observed_pages=[observe(p) for p in pages]
  eligible=[p for p in observed_pages if not (p['status']=='completed' and any(j['name']=='build' and j['conclusion']=='skipped' for j in p['jobs']))]
  runs['pages']=max(eligible,key=lambda p:p['id']) if eligible else dict(id=None,status='awaiting_eligible_pages_build',conclusion=None,head_sha=commit,jobs=[])
  runs['ignored_skipped_pages']=[p['id'] for p in observed_pages if p not in eligible]
  report=dict(commit=commit,checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_s=time.monotonic()-start,runs=runs,errors=errors,policy='Pages is discovered after Quality;never invented or manually dispatched')
  signature=json.dumps(runs,sort_keys=True)
  if signature!=last:print(json.dumps(report),flush=True);last=signature
  if quality['status']=='completed':
   if quality['conclusion']!='success':save(report,'failure',1)
   required_jobs=[[j for j in runs['quality']['jobs'] if j['name']==name] for name in ['native','browser-wasm','pilot']]
   verified=all(len(j)==1 and j[0]['status']=='completed' and j[0]['conclusion']=='success' for j in required_jobs)
   if not verified:
    report['required_jobs_observed_terminal']=False;save(report);time.sleep(30);continue
   if runs['pages']['status']=='completed':
    deploy=[j for j in runs['pages']['jobs'] if j['name']=='deploy']
    published=runs['pages']['conclusion']=='success' and len(deploy)==1 and deploy[0]['conclusion']=='success' and all(s['conclusion']=='success' for s in deploy[0]['steps'])
    save(report,'success' if published else 'pages_not_published',0 if published else 3)
   if not eligible:
    current=api('branches/main')['commit']['sha'];report['current_main']=current
    if current!=commit:save(report,'superseded_after_quality',3)
  save(report)
 except (RuntimeError,subprocess.TimeoutExpired) as error:
  errors.append(dict(elapsed_s=time.monotonic()-start,error=str(error)));print('OBSERVATION ERROR '+str(error),flush=True)
 time.sleep(30)
(root/'remote-observer-terminal.json').write_text(json.dumps(dict(status='observation_timeout',commit=commit,quality_id=quality_id,errors=errors),indent=2)+'\n');raise SystemExit(2)
