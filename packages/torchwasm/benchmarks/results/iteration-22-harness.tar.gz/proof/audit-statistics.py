from pathlib import Path
import itertools,json,warnings
import numpy as np
import torch as native
from stridetorch import torch
root=Path(__file__).parent

def run(lib,a,method,dim,correction,keepdim):
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            x=lib.tensor(a,requires_grad=True);y=getattr(x,method)(dim=dim,correction=correction,keepdim=keepdim)
            g=lib.tensor(np.arange(y.numel(),dtype=a.dtype).reshape(tuple(y.shape))+1)
            y.backward(g)
            arr=lambda z:z.detach().numpy()
            return dict(value=arr(y),grad=arr(x.grad),shape=tuple(y.shape),dtype=str(arr(y).dtype))
    except Exception as e:return dict(error=type(e).__name__,message=str(e))
rows=[];diffs=[]
for shape in [(),(1,),(3,),(2,3),(0,3),(2,0,3)]:
 a=np.linspace(.5,2.5,num=int(np.prod(shape,dtype=int)),dtype=np.float64).reshape(shape)
 for method,dim,correction,keepdim in itertools.product(['var','std'],[None,0,-1,1,(),[],(0,1),(0,0),(0,-len(shape)),True,1.2],[0,.5,1,2,5,-1], [False,True]):
  n=run(native,a,method,dim,correction,keepdim);c=run(torch,a,method,dim,correction,keepdim)
  reasons=[]
  if n.get('error')!=c.get('error'):reasons.append('exception')
  if 'error' not in n and 'error' not in c:
   for name in ['shape','dtype']:
    if n[name]!=c[name]:reasons.append(name)
   for name in ['value','grad']:
    try:np.testing.assert_allclose(c[name],n[name],rtol=2e-12,atol=2e-12,equal_nan=True)
    except AssertionError:reasons.append(name)
  row=dict(shape=shape,method=method,dim=dim,correction=correction,keepdim=keepdim,differences=reasons,native={k:(v.tolist() if isinstance(v,np.ndarray) else v) for k,v in n.items()},candidate={k:(v.tolist() if isinstance(v,np.ndarray) else v) for k,v in c.items()});rows.append(row)
  if reasons:diffs.append(row)
report=dict(cases=len(rows),differences=len(diffs),by_reason={reason:sum(reason in row['differences'] for row in diffs) for reason in ['exception','shape','dtype','value','grad']},rows=rows)
(root/('statistics-audit-'+__import__('sys').argv[1]+'.json')).write_text(json.dumps(report,indent=2,allow_nan=True)+'\n');print({k:v for k,v in report.items() if k!='rows'})
