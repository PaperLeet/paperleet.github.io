"""Shared moments, validation and analytical rules for real statistics."""
import math
import warnings
import numpy as np
from . import _layout

MISSING = _layout.UNSPECIFIED_DIM


def options(shape, args, dim, unbiased, keepdim, correction):
    """Resolve the legacy unbiased overload without accepting bool dimensions."""
    if args and type(args[0]) is bool:
        if len(args) != 1 or dim is not MISSING or unbiased is not MISSING:
            raise TypeError('Invalid statistics arguments')
        unbiased = args[0]
    else:
        if len(args) > 3: raise TypeError('Too many statistics arguments')
        values = [dim, unbiased, keepdim]
        for index, value in enumerate(args):
            if values[index] is not MISSING: raise TypeError('Repeated statistics argument')
            values[index] = value
        dim, unbiased, keepdim = values
    if unbiased is not MISSING:
        if type(unbiased) is not bool or correction is not MISSING:
            raise TypeError('Specify boolean unbiased or correction, not both')
        correction = int(unbiased)
    elif correction is MISSING or correction is None:
        correction = 1
    if keepdim is MISSING: keepdim = False
    if type(keepdim) is not bool: raise TypeError('keepdim must be bool')
    from . import _tensor
    if isinstance(correction, _tensor.Tensor):
        if correction.numel() != 1: raise TypeError('correction must be a scalar')
        correction = correction.item()
    if isinstance(correction, (complex, np.complexfloating)):
        raise RuntimeError('correction must be real')
    if not isinstance(correction, (int, float, np.integer, np.floating, np.bool_)):
        raise TypeError('correction must be a real number')
    correction = float(correction)
    if dim is MISSING: dim = None
    requested = () if dim is None else tuple(dim) if isinstance(dim, (tuple, list)) else (dim,)
    normalized = tuple(_layout.dimension(d, len(shape)) for d in requested)
    if len(set(normalized)) != len(normalized): raise RuntimeError('Duplicate reduction dimensions')
    axes = tuple(range(len(shape))) if not requested else normalized if shape else ()
    count = math.prod(shape[d] for d in axes)
    # Native reverse rules distinguish a missing dimension from an explicit
    # empty list. Forward moments still reduce all dimensions in both cases.
    backward_count = 1 if dim is not None and not requested else count
    return axes, count, backward_count, dim is None or not shape, keepdim, correction


def mean_array(data, axes):
    accumulator = np.float32 if data.dtype.itemsize < 4 else data.dtype
    count = math.prod(data.shape[d] for d in axes)
    with np.errstate(all='ignore'):
        return data.sum(axis=axes, keepdims=True, dtype=accumulator) / np.asarray(count, dtype=accumulator)


def _restore(value, axes, keepdim):
    if not keepdim:
        for axis in sorted(axes): value = np.expand_dims(value, axis)
    return value


def _variance_backward(input, seed, config):
    axes, _, count, global_rule, keepdim, correction = config
    data = input._data
    center_mean = mean_array(data, axes).astype(data.dtype, copy=False)
    grad = _restore(seed, axes, keepdim)
    with np.errstate(all='ignore'):
        if global_rule and count - correction <= 0:
            return grad * np.where(data == center_mean, np.nan, np.inf).astype(data.dtype)
        factor = np.divide(np.asarray(2, dtype=data.dtype), np.asarray(count-correction, dtype=data.dtype))
        return (factor * grad) * (data-center_mean)


def _calculate(input, config, kind, paired):
    from . import _autograd
    axes, count, _, _, keepdim, correction = config
    data = input._data
    if count-correction <= 0:
        warnings.warn('Degrees of freedom <= 0 for statistics reduction', UserWarning, stacklevel=4)
    with np.errstate(all='ignore'):
        mean = mean_array(data, axes)
        centered = data-mean
        variance = np.sum(centered*centered, axis=axes, keepdims=True)
        denominator = np.asarray(max(0., count-correction), dtype=variance.dtype)
        variance = variance/denominator
        if not count: variance = np.full_like(variance, np.nan)
        # NaN correction is propagated rather than converted by Python max.
        if math.isnan(correction): variance = np.full_like(variance, np.nan)
        raw = np.sqrt(variance) if kind == 'std' else variance
        raw = np.asarray(raw if keepdim else raw.squeeze(axis=axes), dtype=data.dtype)
        mean = np.asarray(mean if keepdim else mean.squeeze(axis=axes), dtype=data.dtype)
    def backward(seed):
        if kind == 'std':
            with np.errstate(all='ignore'):
                seed = np.divide(seed, raw*np.asarray(2, dtype=raw.dtype))
                seed = np.where(raw == 0, np.asarray(0, dtype=raw.dtype), seed)
        return _variance_backward(input, seed, config)
    result = _autograd.result(raw, (input, backward), versioned=(input,) if kind == 'var' else None)
    if not paired: return result
    def mean_backward(seed):
        with np.errstate(all='ignore'):
            grad = _restore(seed, axes, keepdim)/np.asarray(count, dtype=seed.dtype)
            return np.broadcast_to(grad, input.shape)
    saved = (input, result) if kind == 'std' else (input,)
    average = _autograd.result(mean, (input, mean_backward), versioned=saved)
    return result, average


def _forward(input, config, kind, paired):
    from . import _autograd, _ops
    primal, tangent = input._primal, input._tangent
    outputs = _calculate(primal, config, kind, paired)
    value = outputs[0] if paired else outputs
    axes, _, count, global_rule, keepdim, correction = config
    centered = primal-primal.mean(axes, True)
    with np.errstate(all='ignore'):
        if global_rule and count-correction <= 0:
            derivative = _ops.where(centered == 0, float('nan'), float('inf'))
        else:
            factor = float(np.divide(2., count-correction))
            derivative = centered*factor
        product = (derivative*tangent).sum(axes, keepdim)
        if kind == 'std': product = _ops.where(value == 0, 0., product/(value*2))
    first = _autograd.ForwardTensor(value, product)
    if not paired: return first
    return first, _autograd.ForwardTensor(outputs[1], tangent.mean(axes, keepdim))


def reduce(input, *args, dim=MISSING, unbiased=MISSING, keepdim=MISSING,
           correction=MISSING, kind='var', paired=False):
    from . import _autograd
    if input.dtype.kind != 'f': raise RuntimeError('Statistics require a real floating tensor')
    config = options(input.shape, args, dim, unbiased, keepdim, correction)
    if isinstance(input, _autograd.ForwardTensor): return _forward(input, config, kind, paired)
    return _calculate(input, config, kind, paired)


def var_mean(input, *args, dim=MISSING, unbiased=MISSING, keepdim=MISSING, correction=MISSING):
    return reduce(input, *args, dim=dim, unbiased=unbiased, keepdim=keepdim,
                  correction=correction, paired=True)


def std_mean(input, *args, dim=MISSING, unbiased=MISSING, keepdim=MISSING, correction=MISSING):
    return reduce(input, *args, dim=dim, unbiased=unbiased, keepdim=keepdim,
                  correction=correction, kind='std', paired=True)
