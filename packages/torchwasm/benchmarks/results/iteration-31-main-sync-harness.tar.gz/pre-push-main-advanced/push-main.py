from pathlib import Path
import datetime,json,subprocess,time
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');receipts=[]
def run(args,name):
 start=time.monotonic();p=subprocess.run(args,cwd=repo,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(r/(name+'.log')).write_text(p.stdout);receipts.append(dict(name=name,args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-start));(r/'push-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode();return p.stdout.strip()
assert not run(['git','status','--porcelain'],'pre-push-status')
run(['git','fetch','origin','main'],'pre-push-fetch');upstream=run(['git','rev-parse','origin/main'],'pre-push-main');assert upstream=='769915be5215c22bcb13bd0518e8406dde6731b7',upstream
run(['git','merge-base','--is-ancestor',upstream,'HEAD'],'pre-push-ancestry');commit=run(['git','rev-parse','HEAD'],'pre-push-head')
run(['git','-c','http.postBuffer=524288000','-c','http.version=HTTP/1.1','push','origin','HEAD:main'],'main-push')
remote=run(['git','ls-remote','origin','refs/heads/main'],'post-push-main').split()[0];assert remote==commit,(remote,commit)
proof=json.loads((r/'integration-proof/release-snapshot.json').read_text());proof.update(commit=commit,quality_id=None,quality_url=None,local_gate_report='iteration-31-integration.json',core_report='iteration-31.json',eligible_pages_run=None,live_verified=False,last_verified_site=dict(version='0.30.0',commit='b1a1631a31ccc17f8f5346f8329cdb54e723f24d'),push=dict(status='actual_main_ref_verified',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),previous_main=upstream,commit=commit,non_force=True,receipts=receipts));(r/'publication.json').write_text(json.dumps(proof,indent=2)+'\n')
print('ACTUAL NON-FORCE MAIN',commit,flush=True)
