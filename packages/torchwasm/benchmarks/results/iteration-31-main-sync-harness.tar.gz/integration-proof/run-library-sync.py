from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');old='769915be5215c22bcb13bd0518e8406dde6731b7';upstream='06a205556b28f04b6e566fcd5e59dda01407107c';receipts=[];env={**os.environ,'PATH':'/opt/homebrew/bin:'+os.environ['PATH']}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):(r/name).write_text(json.dumps(value,indent=2)+'\n')
files=subprocess.check_output(['git','diff','--name-only',old,upstream],cwd=repo,text=True).splitlines();assert set(files)=={'docs/validation/library-topic-filter.md','web/scripts/check-catalog-workbench.mjs','web/scripts/check-library-navigation.mjs','web/src/PaperViews.tsx','web/src/libraryNavigation.ts','web/src/libraryPractice.ts'}
for name in files:assert (repo/name).read_bytes()==subprocess.check_output(['git','show',upstream+':'+name],cwd=repo)
assert json.loads((r.parent/'proof-refined/source-hashes.json').read_text())=={p.name:sha(p) for p in (repo/'packages/stridetorch/src/stridetorch').iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
exports=json.loads((r/'live-expected-sha256.json').read_text());assert all(sha(repo/'web/public/data'/name)==h for name,h in exports.items())
profile=json.loads((r/'pages-profile-latest.json').read_text());value=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED','--jq','.value'],text=True).strip();assert value==profile['observed_value']
context=dict(upstream=upstream,merge_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),changed_files=files,upstream_files_preserved=subprocess.check_output(['git','diff','--name-only','b1a1631a',upstream],cwd=repo,text=True).splitlines(),source_hashes=json.loads((r.parent/'proof-refined/source-hashes.json').read_text()),exports_identical=161,scope='Only library topic-filter TSX/pure helpers,checks/docs. Original problems/backend/library/catalog/package/lock inputs unchanged. Existing full infrastructure/native/WASM evidence retained.',react_review='Topic options and canonical selected label are derived during render;case-insensitive matching is shared by normalization and practice selection. Existing bounded URL parsing and native labelled select remain. No added hook,effect,listener or dependency;no manual visual QA.');save('library-sync-context.json',context)
plans=[(['/opt/homebrew/bin/node','scripts/'+name],'library-sync-'+name+'.log',{}) for name in ('check-catalog-workbench.mjs','check-library-navigation.mjs')]+[(['npm','run','build'],'library-sync-default-build.log',{}),(['npm','run','build'],'library-sync-pages-build.log',profile['environment'])]
for args,name,overrides in plans:
 start=time.monotonic()
 with (r/name).open('w') as log:p=subprocess.run(args,cwd=repo/'web',env={**env,**overrides},stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(args=args,log=name,cwd=str(repo/'web'),exit_code=p.returncode,elapsed_s=time.monotonic()-start,environment=overrides));save('library-sync-receipts.json',receipts);print(name,'terminal',p.returncode,flush=True);p.check_returncode()
