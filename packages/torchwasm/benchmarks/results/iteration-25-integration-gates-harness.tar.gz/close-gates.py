from pathlib import Path
import hashlib,json,re,shutil,subprocess,tarfile
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');data=repo/'web/public/data';out=repo/'packages/stridetorch/benchmarks/results'
context=json.loads((r/'context.json').read_text());latest=json.loads((r/'latest-upstream.json').read_text());state=json.loads((r.parent/'state.json').read_text());source=repo/'packages/stridetorch/src/stridetorch'
actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};assert actual==context['source_hashes']==state['source_hashes']
index=json.loads((data/'index.json').read_text());entries={x['id']:x for x in index['problems']};hashes=json.loads((r/'live-expected-sha256.json').read_text());assert hashes=={name:hashlib.sha256((data/name).read_bytes()).hexdigest() for name in hashes}
w=json.loads((repo/'reports/browser-wasm.json').read_text());shutil.copy2(repo/'reports/browser-wasm.json',r/'full-wasm-result.json');assert w['scope']=='catalog' and w['passed'] and w['modules']==w['catalog_modules']==len(entries)==78 and not w['browser_budget_exceeded']
assert len(w['results'])==78 and {x['id'] for x in w['results']}==set(entries)
for case in w['results']:
 e=entries[case['id']];assert case['passed'] and not case['browser_budget_exceeded'];assert case['tests']==sum(e['tests'].values()) and case['budgets']==e['browser_judge']['budgets'] and case['bundle_url']==e['browser_judge']['bundle_url']
 assert case['calibration_ms']<=case['budgets']['calibration'] and case['learner_ms']<=case['budgets']['run']
 assert case['preparation_ms']+case['calibration_ms']+case['learner_ms']<=case['budgets']['total']
 payload=json.loads((data/case['bundle_url']).read_text());assert case['runtime_bundle_url']==payload['runtime_bundle_url'] and case['source_sha256']==hashlib.sha256(payload['reference'].encode()).hexdigest()
attention=next(x for x in w['results'] if x['id']=='architecture/attention');contracts=attention['independent_contracts'];assert contracts['passed']==806 and len(contracts['suites'])==25
expected_suites={x.name for x in (repo/'packages/stridetorch/tests').glob('test_*.py') if x.name!='test_standalone.py'};assert expected_suites=={x['suite'] for x in contracts['suites']}
for suite in contracts['suites']:assert suite['source_sha256']==hashlib.sha256((repo/'packages/stridetorch/tests'/suite['suite']).read_bytes()).hexdigest()
harness=json.loads((r/'wasm-harness-identity.json').read_text());assert harness['sha256']==hashlib.sha256((repo/harness['file']).read_bytes()).hexdigest();assert contracts==harness['independent_contracts']
shutil.copy2(repo/harness['file'],r/'maintained-check-browser-wasm.mjs')
n=json.loads((r/'native-ci.json').read_text());assert n['passed'] and not n['issues'] and n['problems']==78 and n['tests_executed']==10218 and n['repeats']==3 and n['duration_s']<=600
assert sum(len(x) for x in n['mutation'].values())==sum(x['mutants'] for x in w['results'])==342
builds={}
for name in ('frontend-build.log','latest-frontend-build.log','pages-profile-build.log'):
 text=(r/name).read_text();m=re.search(r'PASS initial build graph: (\d+) JS assets, (\d+) bytes raw / (\d+) bytes gzip',text);assert m,name
 builds[name]=dict(js_assets=int(m[1]),raw_bytes=int(m[2]),gzip_bytes=int(m[3]))
assert '26 passed' in (r/'affected-python.log').read_text();assert 'PASS preparation handbook: 51' in (r/'frontend-check.log').read_text()
for name in ('latest-interview-ranking.log','latest-concept-journey.log','latest-company-preparation.log','latest-interview-ui.log','pages-policy.log'):assert 'PASS ' in (r/name).read_text(),name
for name in latest['upstream_files_preserved']:assert (repo/name).read_bytes()==subprocess.check_output(['git','show',latest['upstream']+':'+name]),name
subprocess.run(['/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-21/stride-dev-env/bin/python',str(r/'verify-export.py')],cwd=repo,check=True,stdout=subprocess.DEVNULL)
report=dict(status='all_local_integration_gates_passed',version='0.25.0',source_hashes=actual,context=context,latest_upstream=latest,prior_core_report='iteration-25.json',native_catalog={k:v for k,v in n.items() if k!='mutation'},native_mutants=342,affected_python_passed=26,full_wasm={k:v for k,v in w.items() if k!='results'},independent_exported_vm_contracts=contracts,export=json.loads((r/'export-identity.json').read_text()),runtime_sizes=json.loads((r/'runtime-sizes.json').read_text()),distribution=json.loads((r/'distribution-identity.json').read_text()),builds=builds,pages_profile=json.loads((r/'pages-profile.json').read_text()),timing_scope='Catalog durations are independent budget gates,not controlled speedup measurements. All budgets,repeats,test suites and mutants unchanged;independent exported-VM coverage expanded.',frontend_log_notes='Ephemeral Vite dependency-scan shutdown/occupied-HMR messages are retained;complete assertions and npm scripts returned0. No application browser visual QA is claimed.',remaining=['Latest-main revalidation before non-force push','Actual exact-main remote Quality','Eligible Pages deployment and live-byte verification'])
(r/'integration-gates.json').write_text(json.dumps(report,indent=2)+'\n')
archive=out/'iteration-25-integration-gates-harness.tar.gz';files=[p for p in r.rglob('*') if p.is_file() and p.suffix in ('.py','.mjs','.json','.log','.whl','.gz','.html') and '__pycache__' not in p.parts]
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
report['archive']=dict(file=archive.name,files=len(files),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest());(out/'iteration-25-integration-gates.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],native_s=n['duration_s'],wasm_ms=w['elapsed_ms'],contracts=contracts['passed'],archive=report['archive']),indent=2))
