import {loadJudgePackages} from '../../../extraction-browser/packages.mjs';
self.onmessage=async({data})=>{try{
 const plan=await(await fetch('./bench-plan.json')).json();
 const {loadPyodide}=await import('../../../runtime-0.29.4/pyodide.mjs');
 const py=await loadPyodide({indexURL:new URL('../../../runtime-0.29.4/',self.location.href).href,stdout(){},stderr(){}});await loadJudgePackages(py,[]);py.FS.mkdirTree('/runtime/stridetorch');
 for(const name of Object.keys(plan.source))py.FS.writeFile('/runtime/stridetorch/'+name,await(await fetch('./source/'+name)).text());
 py.FS.writeFile('/bench.py',await(await fetch('./bench_instance_norm.py')).text());py.globals.set('plan_json',JSON.stringify(plan));py.globals.set('reverse_order',data.reverse);
 const report=JSON.parse(py.runPython(`import sys,json,pathlib,hashlib,runpy
sys.path.insert(0,'/runtime')
plan=json.loads(plan_json)
actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path('/runtime/stridetorch').iterdir() if p.is_file()}
assert actual==plan['source']
assert hashlib.sha256(pathlib.Path('/bench.py').read_bytes()).hexdigest()==plan['benchmark_sha256']
import stridetorch,numpy
report=runpy.run_path('/bench.py')['run'](reverse_order=reverse_order)
report.update(runtime='Chrome/Pyodide',library=stridetorch.__version__,numpy=numpy.__version__,source_hashes=actual,benchmark_sha256=plan['benchmark_sha256'])
json.dumps(report)`));self.postMessage({...report,pyodide:py.version});
 }catch(error){self.postMessage({error:String(error.stack||error)});}};
