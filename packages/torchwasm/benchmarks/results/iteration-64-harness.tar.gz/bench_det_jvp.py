"""New JVP API versus an explicitly labeled prior-API composition."""
import gc
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time
import warnings

import numpy as np

try:import bench_determinants as common
except ModuleNotFoundError:
    sys.path.insert(0,str(Path(__file__).resolve().parent/'proof/chrome-contracts'))
    import bench_determinants as common


def method(module,data,direction,backward,direct):
    t=module.torch;a=t.tensor(data,requires_grad=backward);e=t.tensor(direction,requires_grad=backward)
    weight=t.tensor(np.full(data.shape[:-2],.7,dtype=data.dtype)) if backward else None
    def call():
        a.grad=e.grad=None
        if direct:p,v=t.func.jvp(t.det,(a,),(e,))
        else:
            p=t.det(a)
            trace=t.linalg.solve(a.detach(),e).diagonal(dim1=-2,dim2=-1).sum(-1)
            v=p*trace
        if backward:(v*weight).sum().backward()
        return p,v
    def capture():
        p,v=call();values=[p.numpy().copy(),v.numpy().copy()]
        if backward:values.extend([a.grad.numpy().copy(),e.grad.numpy().copy()])
        return values
    return call,capture


def compare(actual,expected,dtype):
    assert len(actual)==len(expected)
    for i,(a,b) in enumerate(zip(actual,expected)):
        assert a.shape==b.shape and a.dtype==b.dtype
        for fn in [np.isnan,np.isposinf,np.isneginf]:np.testing.assert_array_equal(fn(a),fn(b))
        if dtype=='float32' and i>=2:
            delta=a.astype('float64')-b.astype('float64');scale=float(np.max(np.abs(b),initial=0))
            assert float(np.max(np.abs(delta),initial=0))<=1e-5*scale
        else:np.testing.assert_allclose(a,b,rtol=3e-5 if dtype=='float32' else 3e-11,atol=0)


def run(baseline_source,candidate_source,samples=5):
    old,oh=common.load('_jvp_composition_baseline',baseline_source);new,nh=common.load('_jvp_direct_candidate',candidate_source)
    rows=[];warnings.filterwarnings('ignore',category=RuntimeWarning)
    for dtype in ['float32','float64']:
        for label,shape in [('scalar',(1,1)),('small',(2,2)),('larger',(64,64)),('batch_large',(4,32,32))]:
            data=common._data(shape,dtype);direction=(np.eye(shape[-1])*.2+np.sin(np.arange(data.size).reshape(shape)*.17)*.01).astype(dtype)
            for backward in [False,True]:
                methods={};captures={}
                for name,module,direct in [('baseline_composition',old,False),('candidate_jvp',new,True)]:
                    methods[name],captures[name]=method(module,data,direction,backward,direct)
                compare(captures['candidate_jvp'](),captures['baseline_composition'](),dtype)
                for fn in methods.values():fn()
                gc.collect();calibration={};calls=1;times={key:[] for key in methods}
                for name,fn in methods.items():
                    batch=1
                    while True:
                        started=time.perf_counter()
                        for _ in range(batch):fn()
                        elapsed=time.perf_counter()-started
                        if elapsed>=.02:break
                        if batch>=1_048_576:raise RuntimeError('JVP timer resolution is insufficient')
                        batch*=2
                    calls=max(calls,batch);calibration[name]=dict(calls=batch,elapsed_s=elapsed)
                for repeat in range(samples):
                    for name in list(methods) if repeat%2==0 else list(reversed(methods)):
                        started=time.perf_counter()
                        for _ in range(calls):methods[name]()
                        times[name].append((time.perf_counter()-started)/calls)
                medians={name:statistics.median(values) for name,values in times.items()}
                rows.append(dict(dtype=dtype,shape=label,input_shape=list(shape),mode='full_step' if backward else 'forward',calls=calls,calibration=calibration,samples_s=times,median_s=medians,candidate_over_composition=medians['candidate_jvp']/medians['baseline_composition']))
    assert len(rows)==16
    return dict(versions=dict(baseline=old.__version__,candidate=new.__version__),source_hashes=dict(baseline=oh,candidate=nh),program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),samples=samples,rows=rows,scope='New direct det JVP versus explicit prior 0.63 det(A) * trace(solve(A.detach(), E)) composition. The prior library has no det JVP API. Only nonsingular finite inputs; values and weighted input/direction reverse gradients are checked. Primal alias/hooks and singular behavior differ and are qualified by separate native tests, not this performance comparator. Inputs/conversions/directions/seeds precede timing; transform/dispatch/graph/kernels/weighted backward/clearing/destruction are timed. Five alternating common calibrated >=20ms samples. No native-Torch/GPU or universal-throughput claim.')


def memory(baseline_source,candidate_source):
    import tracemalloc
    old,oh=common.load('_jvp_memory_baseline',baseline_source);new,nh=common.load('_jvp_memory_candidate',candidate_source);rows=[]
    for dtype in ['float32','float64']:
        for shape in [(64,64),(4,32,32)]:
            data=common._data(shape,dtype);direction=np.broadcast_to(np.eye(shape[-1])*.2,shape).astype(dtype)
            for name,module,direct in [('baseline_composition',old,False),('candidate_jvp',new,True)]:
                call,_=method(module,data,direction,True,direct);call();gc.collect()
                tracemalloc.start();p,v=call();retained,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
                rows.append(dict(variant=name,dtype=dtype,input_shape=list(shape),new_retained_bytes=retained,full_step_peak_bytes=peak))
                del p,v,call;gc.collect()
    return dict(source_hashes=dict(baseline=oh,candidate=nh),rows=rows,scope='Warm CPU tracemalloc for complete weighted JVP forward/backward step. Inputs/directions/seeds predate tracing. Includes newly stored leaf gradients, not total tape memory/RSS/WASM heap. The direct API owns a factor-source snapshot to preserve native mutation semantics; the composition borrows guarded input storage, so retained allocation is not an equivalent storage-lifetime contract.')


if __name__=='__main__':print(json.dumps(memory(sys.argv[1],sys.argv[2]) if '--memory' in sys.argv[3:] else run(sys.argv[1],sys.argv[2]),indent=2))
