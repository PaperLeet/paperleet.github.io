from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,subprocess,time
r=Path(__file__).resolve().parent;receipts={}
def run(label,script):
 start=time.monotonic()
 with (r/(label+'-determinants.log')).open('w') as log:p=subprocess.run(['/opt/homebrew/bin/node',str(r/script)],stdout=log,stderr=subprocess.STDOUT)
 return label,dict(exit_code=p.returncode,elapsed_s=time.monotonic()-start,script=script)
with ThreadPoolExecutor(max_workers=2) as pool:
 for future in as_completed([pool.submit(run,label,script) for label,script in [('node','proof/oracle-node.mjs'),('chrome','proof/chrome-contracts/oracle-run.mjs')]]):
  label,result=future.result();receipts[label]=result;(r/'oracle-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(label,'terminal',result['exit_code'],flush=True)
assert all(v['exit_code']==0 for v in receipts.values())
