from pathlib import Path
import json,sys
import numpy as np
if sys.argv[1]=='native':import torch as t
else:from stridetorch import torch as t
rows=[]
for need_a,need_e in [(True,True),(True,False),(False,True)]:
 for n in [1,2]:
  for target in ['input','direction','primal','tangent']:
   for channel in ['primal','tangent']:
    a=t.from_numpy(np.eye(n)*2).requires_grad_(need_a);e=t.from_numpy(np.ones((n,n))).requires_grad_(need_e)
    p,v=t.func.jvp(t.det,(a,),(e,));value=p if channel=='primal' else v
    row=dict(need_a=need_a,need_e=need_e,n=n,target=target,channel=channel,requires_grad=value.requires_grad)
    with t.no_grad():{'input':a,'direction':e,'primal':p,'tangent':v}[target].detach().add_(1)
    if not value.requires_grad:row['status']='no_graph'
    else:
     try:value.sum().backward();row['status']='ok'
     except RuntimeError:row['status']='guarded'
    rows.append(row)
r=Path(__file__).resolve().parent;(r/('mutations-'+sys.argv[1]+'.json')).write_text(json.dumps(rows,indent=2)+'\n')
print(sys.argv[1],len(rows),'rows')
