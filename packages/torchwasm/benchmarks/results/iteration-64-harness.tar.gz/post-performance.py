from pathlib import Path
import json,os,platform,subprocess,sys,time
import numpy as np
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');py=sys.executable
identity=json.loads((r/'performance/identity.json').read_text());assert identity['status']=='success' and identity['children']==12 and identity['all_children_terminal']
subprocess.run([py,str(r/'summarize-performance.py')],check=True)
start=time.monotonic();args=[py,str(repo/'packages/stridetorch/benchmarks/bench_determinants.py'),str(r/'baseline-source/stridetorch'),str(repo/'packages/stridetorch/src/stridetorch'),'--memory']
with (r/'performance/memory.json').open('w') as log:p=subprocess.run(args,cwd=repo,stdout=log,stderr=subprocess.PIPE,text=True,env={**os.environ,**identity['thread_caps']})
(r/'performance/memory-receipt.json').write_text(json.dumps(dict(exit_code=p.returncode,elapsed_s=time.monotonic()-start,args=args,stderr=p.stderr),indent=2)+'\n');p.check_returncode()
environment=dict(python=sys.version,numpy=np.__version__,system=platform.system(),machine=platform.machine(),macos=platform.mac_ver()[0],logical_cpus=os.cpu_count(),cpu_model=subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),node=subprocess.check_output(['/opt/homebrew/bin/node','--version'],text=True).strip(),thread_caps=identity['thread_caps'],scope='Host/runtime metadata recorded after the serial formal timing phase. No host-wide isolation claim.')
(r/'performance/environment.json').write_text(json.dumps(environment,indent=2)+'\n');print('Memory and performance summaries complete')
