from pathlib import Path
import json,sys
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'proof/chrome-contracts'))
import bench_determinants
import bench_det_jvp
result=bench_determinants.run(sys.argv[1],sys.argv[2]);result['jvp_benchmark']=bench_det_jvp.run(sys.argv[1],sys.argv[2])
print(json.dumps(result,indent=2))
