from pathlib import Path
import hashlib,json,sys,warnings
import numpy as np
if sys.argv[1]=='native':import torch as t
else:from stridetorch import torch as t
r=Path(__file__).resolve().parent;plan=json.loads((r/'jvp-inputs.json').read_text());inputs=np.load(r/'jvp-inputs.npz');rows={};arrays={}
def tensor(data,layout,requires):
 if layout=='F':value=t.from_numpy(data.swapaxes(-1,-2).copy()).transpose(-1,-2)
 elif layout=='S':
  backing=np.zeros((*data.shape[:-2],data.shape[-2]*2,data.shape[-1]*2),dtype=data.dtype);backing[...,::2,::2]=data;value=t.from_numpy(backing)[...,::2,::2]
 else:value=t.from_numpy(data.copy())
 return value.detach().requires_grad_(requires)
for item in plan['cases']:
 key=item['key'];a=inputs[key+'.a'];e=inputs[key+'.e'];seed=inputs[key+'.seed']
 for li,layout in enumerate(['C','F','S']):
  for fi,(need_a,need_e) in enumerate([(True,True),(True,False),(False,True),(False,False)]):
   direction_layout=['C','F','S'][(li+fi+item['index'])%3];name=f'{key}.{layout}.{fi}';meta=dict(**item,layout=layout,direction_layout=direction_layout,need_a=need_a,need_e=need_e)
   try:
    with warnings.catch_warnings():
     warnings.simplefilter('ignore');x=tensor(a,layout,need_a);direction=tensor(e,direction_layout,need_e);p,v=t.func.jvp(t.det,(x,),(direction,));values=dict(primal=p,tangent=v)
     hook=[]
     if p.requires_grad:p.retain_grad();p.register_hook(lambda g:hook.append(g.detach().clone()))
     if v.requires_grad:
      active=tuple(value for value,needed in [(x,need_a),(direction,need_e)] if needed)
      gradients=iter(t.autograd.grad(v,active,t.from_numpy(seed.copy()),retain_graph=True,allow_unused=True))
      values['gradient_a']=next(gradients) if need_a else None;values['gradient_e']=next(gradients) if need_e else None
      values['retained_primal']=p.grad.detach().clone() if p.requires_grad else None;values['hook_primal']=hook[0] if hook else None
      if need_a:values['primal_gradient_a']=t.autograd.grad(p,x,t.from_numpy(seed.copy()),retain_graph=True)[0]
      else:values['primal_gradient_a']=None
      v.backward(t.from_numpy(seed.copy()));values['stored_a']=x.grad;values['stored_e']=direction.grad
     else:
      for field in ['gradient_a','gradient_e','retained_primal','hook_primal','primal_gradient_a','stored_a','stored_e']:values[field]=None
    schema={}
    for field,value in values.items():
     if value is None:schema[field]=None;continue
     data=value.detach().numpy();arrays[name+'.'+field]=data.copy();schema[field]=dict(dtype=str(data.dtype),shape=list(data.shape),stride=list(value.stride()),requires_grad=value.requires_grad)
    rows[name]=dict(status='ok',values=schema,**meta)
   except Exception as error:rows[name]=dict(status='error',error=type(error).__name__,message=str(error)[:220],**meta)
np.savez_compressed(r/(sys.argv[1]+'-jvp.npz'),**arrays)
(r/(sys.argv[1]+'-jvp.json')).write_text(json.dumps(dict(status='recorded',rows=rows,input_sha256=plan['sha256'],driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),backend=sys.argv[1]),indent=2)+'\n')
print(sys.argv[1],len(rows),'cases;',sum(v['status']=='error' for v in rows.values()),'errors;',len(arrays),'arrays')
