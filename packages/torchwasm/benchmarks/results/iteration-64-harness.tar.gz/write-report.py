from pathlib import Path
import json
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');j=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-64.json').read_text())
def jvp_table(rows):
 text='| Runtime | Dtype | Shape | Mode | Direct JVP / composition | Four-child range |\n|---|---|---|---|---:|---:|\n'
 for row in rows:
  lo,hi=row['ratio_range'];text+=f"| {row['runtime']} | {row['dtype']} | {row['input_shape']} | {row['mode']} | {row['ratio_median']:.3f} | {lo:.3f}–{hi:.3f} |\n"
 return text
def regression_table(rows):
 text='| Runtime | Operation | Dtype | Shape | Mode | 0.64 / actual 0.63 | Four-child range |\n|---|---|---|---|---|---:|---:|\n'
 for row in rows:
  lo,hi=row['ratio_range'];text+=f"| {row['runtime']} | {row['operation']} | {row['dtype']} | {row['input_shape']} | {row['mode']} | {row['ratio_median']:.3f} | {lo:.3f}–{hi:.3f} |\n"
 return text
stages=j['ui_qualification_stages'];ui='; '.join(f"{len(s['checks'])} affected checks plus driver/policy/two builds at `{s['upstream']}`" for s in stages) if stages else 'No later UI sync was required.'
performance=j['performance']['rows'];worst=sorted(performance,key=lambda row:row['ratio_median'],reverse=True)[:10];controls=[row for row in performance if row['operation']=='graph']
memory=j['jvp_memory'];archive=j['raw_archive'];q=j['jvp_qualification']
allocation_table='| Dtype | Shape | Composition step peak bytes | Direct JVP step peak bytes | Direct / composition |\n|---|---|---:|---:|---:|\n'
for old,new in zip(memory['rows'][::2],memory['rows'][1::2]):
 assert old['variant']=='baseline_composition' and new['variant']=='candidate_jvp' and old['dtype']==new['dtype'] and old['input_shape']==new['input_shape']
 allocation_table+=f"| {old['dtype']} | {old['input_shape']} | {old['full_step_peak_bytes']:,} | {new['full_step_peak_bytes']:,} | {new['full_step_peak_bytes']/old['full_step_peak_bytes']:.3f} |\n"
text=f'''# Torch runtime iteration 64 — determinant forward AD

Version **0.64.0** adds real float32/64 determinant JVPs through `torch.det`,
`torch.linalg.det` and `Tensor.det()`. Final integration baseline is
`{j['baseline_main']}`; full CPU/frontend/catalog validation baseline is
`{j['full_validation_baseline']}`. {ui}

## Missing API and numerical behavior

The prior 0.63 implementation rejects all 52 initial determinant JVP probes.
The new implementation computes the native saved-factor directional rule and
supports reverse propagation through both returned channels. Normal, negative,
singular, mixed batched, strided, empty and extreme finite matrices are covered.
Complex AD, output buffers and nonfinite matrix inputs remain unsupported.
Directions and gradient seeds retain the separately tested IEEE behavior.

The native reference is **PyTorch 2.14.1**, git
`5c4886908584029761b579af026dcfb627c84070`. Its
[pinned forward-AD implementation](https://github.com/pytorch/pytorch/blob/5c4886908584029761b579af026dcfb627c84070/torch/csrc/autograd/FunctionsManual.cpp#L4419)
uses saved LU factors, replacing exactly zero LU diagonal pivots by the dtype's
epsilon. Reverse differentiation retains the saved-factor behavior; it does
not differentiate a newly recomputed factorization. This compatibility target
is explicit and does not promise arbitrary higher derivatives or parity with
future upstream changes.

Consequently, native singular determinant JVPs can be zero even when the
polynomial differential is nonzero. Inside JVP, the primal and tangent reverse
paths follow this pinned native convention. Ordinary `det` backward keeps its
existing polynomial-cofactor extension for singular/extreme values; the old
48-case legacy qualification is retained separately. The 0.63 exact singleton
ordinary value/VJP and floating-point-policy fixes remain in force.

The returned primal is a metadata alias of the private determinant result.
Retaining its gradient or registering its hook does not intercept the tangent's
private factor path. Primal storage mutations are still guarded. Mutating the
direction or returned tangent follows the tested native behavior. A dedicated
48-case mutation probe and independent SDK tests cover all requires-grad pairs
with a differentiable output and both channels.

## Computation and lifetime

The implementation uses NumPy's matrix solve for ordinary batches and invokes
the existing pivoted-LU fallback only for singular batches. Determinant JVP opts
into epsilon pivots; log determinant singular IEEE handling is unchanged.
Float32 singleton reverse solves preserve native reciprocal precision instead
of accepting NumPy's promoted solve behavior at subnormal scales.

One immutable matrix snapshot is shared between the two reverse paths when
gradients need matrix values. Forward-only/no-grad JVP avoids that snapshot.
Only the solve trace is retained; the full temporary solution is released.
Two independent reverse edges allow the existing graph engine to skip the
unrequested direction solve. The returned-primal alias keeps hooks and graph
lifetime behavior distinct from the private determinant value. No new runtime
dependency or GPU path is introduced.

## Verification

- **41,253 CPU tests pass, 1 skip**; exact source identity is checked before and
  after the run.
- **7,623 contracts / 56 suites** pass independently on Node/Pyodide and Chrome
  Worker. The Python 3.10.19 / NumPy 1.26.4 installed wheel passes **7,636 tests**
  with native Torch absent.
- **169 new independent SDK tests** cover analytic 2×2 polynomial oracles,
  native singleton/epsilon/IEEE rules, singular JVP versus ordinary cofactor
  gradients, three aliases, C/F/sliced inputs, mutation guards, returned-primal
  hooks, graph pruning, snapshot lifetime, no-grad empties and error policies.
- **696 new frozen native controls** compare **3,132 numerical arrays and
  3,132 None-gradient/hook fields** on CPU, Node, Chrome and the minimum wheel.
  They include 58 exact matrix/direction/seed groups (174 arrays), three layouts,
  all four requires-grad pairs, mixed singular batches, 32×32 matrices, Inf/NaN
  directions, raw/stored gradients and both primal/tangent reverse paths.
- NaN/+Inf/-Inf masks are exact. Float64 finite values use componentwise
  `rtol=3e-12, atol=0`; float32 finite values use `rtol=2e-5, atol=0`, with a
  per-matrix max-norm bound `1e-5` for float32 matrix gradients at size >=8.
  Eight initial strict componentwise differences involved near-zero entries in
  32×32 float32 gradients; the retained float64 diagnostic has scaled max error
  below 6.5e-7. No IEEE mask checks are relaxed. Singleton output zero signs
  are checked exactly. The **48** equivalent positive singleton stored-gradient
  layouts follow the existing owned-buffer contract; raw layouts are exact.
- The earlier **600-case determinant/log qualification** and **398 singleton
  controls** still pass on all four environments. Native, legacy-cofactor and
  input-restriction cases remain separately labeled.
- Public wheel/sdist, vendored wheel, coinstallation/uninstall isolation,
  native-Torch alias restoration and fresh-process serialization are checked.
  Both package forms contain the same 59 Python modules and two license files.
- All **78 exported modules and 342 mutants** pass the original browser budgets;
  the embedded independent SDK run includes all 56 suites. All 1,152 native
  catalog input hashes and **13,073 prior immutable payloads** are unchanged;
  158 new reachable assets and 161 active export/index identities are recorded.
- Full frontend checks and both build profiles pass at the recorded baseline.
  Any later disjoint UI changes are qualified explicitly above.
- Seven release-policy files remain byte-identical to canonical
  `13d2782a494415ba72bc604a0ef7e4c4f875ba25`. No CI trigger, tag, workflow dispatch,
  release, package upload or deployment is initiated.

## Performance with explicit comparators

Twelve fresh children (four CPU, four Node and four Chrome), with two CPU
threads capped per supported backend, run five alternating samples with common
calibrated batches of at least 20 ms. Correctness/budget runs finish before
formal timing. This is host measurement without machine-wide isolation.

The regression comparator invokes actual 0.63 APIs for **100 matched workflows
per child** (1,200 workflow results): real/complex determinant/log forward,
real weighted reverse and graph controls. All 300 aggregate rows and original
samples are retained. The largest median ratios, including losses, are:

{regression_table(worst)}
Graph controls:

{regression_table(controls)}
The new-feature comparator has **16 additional workflows per child** (192
results, 48 aggregates). Since 0.63 has no determinant JVP API, its comparator
is explicitly the existing-API composition
`det(A) * trace(solve(A.detach(), E))`, tested only on finite nonsingular
matrices. It checks values and weighted matrix/direction gradients, not alias,
hook or singular equivalence. Those differences are covered by native controls.
Below 1 means the new direct API is faster than that composition:

{jvp_table(j['jvp_performance']['rows'])}
Inputs, conversions, directions and seeds precede timing. Dispatch/transform,
graph construction, kernels, optional weighted backward, clearing and result
destruction are timed. No native-Torch, GPU, cold-start or universal speedup
claim is made.

## Allocation and reproduction

The 24 ordinary determinant/log allocation diagnostics retain separate warm and
cold-first results. Eight additional warm CPU tracemalloc rows measure complete
weighted JVP steps against the composition. Inputs/directions/seeds predate
tracing; tracked retained allocations include newly stored leaf gradients.
The direct API's source snapshot and the composition's borrowed guarded input
are different lifetime contracts. These are not total tape bytes, process RSS,
LAPACK workspace or WASM heap measurements. In this one warm diagnostic,
tracked step peaks are 7–36% higher for the direct API, while retained bytes
are roughly 1.3–1.4 KB lower. The required immutable source snapshot has a
visible allocation cost; this iteration does not claim a universal RAM saving.

{allocation_table}
[Machine report](../../packages/stridetorch/benchmarks/results/iteration-64.json)
and [raw harness](../../packages/stridetorch/benchmarks/results/iteration-64-harness.tar.gz)
contain source/test snapshots, frozen inputs/native outputs, programs, failed
development pilots, source identities, packages, receipts and all samples.
Archive: {archive['bytes']:,} bytes; SHA-256 `{archive['sha256']}`.

CPU/WASM is the only backend changed this iteration. The prior WebGPU design
assessment remains applicable; no GPU prototype or GPU performance is claimed.
The wider independent-library/core-coverage/backend objective remains active.
'''
(repo/'docs/validation/torch-runtime-iteration-64.md').write_text(text);print('Wrote iteration-64 validation report')
