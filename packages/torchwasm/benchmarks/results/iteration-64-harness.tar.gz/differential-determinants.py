from pathlib import Path
import importlib.util,json,sys,warnings
import numpy as np
r=Path(__file__).resolve().parent;backend=sys.argv[1]
if backend=='native':import torch as t
elif backend=='adapter':from stridetorch import torch as t
else:
    path=r/'baseline-source/stridetorch';spec=importlib.util.spec_from_file_location('_det_oracle_baseline',path/'__init__.py',submodule_search_locations=[str(path)]);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);t=m.torch
inputs=np.load(r/'determinant-inputs.npz');rows={};arrays={}
def source(data,layout,requires):
    if layout=='F':value=t.from_numpy(data.swapaxes(-1,-2).copy()).transpose(-1,-2)
    elif layout=='S':
        backing=np.zeros((*data.shape[:-2],data.shape[-2]*2,data.shape[-1]*2),dtype=data.dtype);backing[...,::2,::2]=data;value=t.from_numpy(backing)[...,::2,::2]
    else:value=t.from_numpy(data.copy())
    return value.detach().requires_grad_() if requires else value

def run(op,dtype,index,layout):
    key=f'{dtype}.{index}';data=inputs[key+'.a'];real=data.dtype.kind!='c';x=source(data,layout,real);fn=getattr(t,op);value=fn(x);outs=tuple(value) if op=='slogdet' else (value,);values={f'value{i}':v for i,v in enumerate(outs)}
    if real:
        (outs[-1]*t.from_numpy(inputs[key+'.seed'].copy())).sum().backward();values['gradient']=x.grad
        if op=='slogdet':
            xx=source(data,layout,True);t.slogdet(xx).sign.sum().backward();values['sign_gradient']=xx.grad
        if op!='det':
            a=source(data,layout,True);e=t.from_numpy(inputs[key+'.direction'].copy()).requires_grad_();p,dual=t.func.jvp(fn,(a,),(e,));duals=tuple(dual) if op=='slogdet' else (dual,)
            for i,v in enumerate(duals):values[f'tangent{i}']=v
            ga,ge=t.autograd.grad((duals[-1]*t.from_numpy(inputs[key+'.seed'].copy())).sum(),(a,e),allow_unused=True);values['jvp_a_gradient']=ga;values['jvp_e_gradient']=ge
    return values
for dtype in ['float32','float64','complex64','complex128']:
    for index in range(20):
        for layout in ['C','F','S']:
            for op in (['det'] if backend=='baseline' else ['slogdet','logdet','det'] if dtype.startswith('float') else ['slogdet','logdet']):
                if backend=='baseline' and not dtype.startswith('float'):continue
                key=f'{op}.{dtype}.{index}.{layout}';meta=dict(operation=op,dtype=dtype,case=index,layout=layout)
                try:
                    with warnings.catch_warnings():
                        warnings.simplefilter('ignore');values=run(op,dtype,index,layout)
                    schema={}
                    for name,v in values.items():
                        if v is None:schema[name]=None;continue
                        a=v.detach().clone().numpy();schema[name]=dict(dtype=str(a.dtype),shape=list(a.shape),stride=list(v.stride()),requires_grad=v.requires_grad);arrays[key+'.'+name]=a.copy()
                    rows[key]=dict(status='ok',values=schema,**meta)
                except Exception as e:rows[key]=dict(status='error',error=type(e).__name__,message=str(e)[:180],**meta)
np.savez_compressed(r/(backend+'-determinants.npz'),**arrays)
(r/(backend+'-determinants.json')).write_text(json.dumps(dict(backend=backend,version=getattr(t,'__version__',None),numpy=np.__version__,rows=rows),indent=2)+'\n');print(backend,len(rows),'rows',sum(v['status']=='error' for v in rows.values()),'errors')
