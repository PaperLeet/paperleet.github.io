from pathlib import Path
import json,hashlib,numpy as np
r=Path(__file__).resolve().parent;native=json.loads((r/'native-singleton-controls.json').read_text())['rows'];adapter=json.loads((r/'adapter-singleton-controls.json').read_text())['rows'];na=np.load(r/'native-singleton-controls.npz');ca=np.load(r/'adapter-singleton-controls.npz');qualified=[];count=0
assert len(native)==len(adapter)==398
for key,row in native.items():
 other=adapter[key];assert row['status']==other['status']=='ok',(key,row,other);assert row['seed_alias']==other['seed_alias'] and row['output_alias']==other['output_alias'],(key,'alias');assert row['values'].keys()==other['values'].keys()
 for field,desc in row['values'].items():
  actual=other['values'][field];assert {k:v for k,v in desc.items() if k!='stride'}=={k:v for k,v in actual.items() if k!='stride'},(key,field,'schema')
  if actual['stride']!=desc['stride']:
   assert field=='stored' and all((n==1 and x>0 and y>0) or x==y for n,x,y in zip(desc['shape'],actual['stride'],desc['stride'])),(key,field,desc,actual);qualified.append(dict(case=key,field=field,native=desc['stride'],adapter=actual['stride']))
  a=ca[key+'.'+field];b=na[key+'.'+field];assert a.shape==b.shape and a.dtype==b.dtype
  np.testing.assert_array_equal(a,b,err_msg=key+'.'+field)
  finite=~np.isnan(b);assert np.array_equal(np.signbit(a[finite]),np.signbit(b[finite])),(key,field,'sign bit');count+=1
report=dict(status='success',cases=398,numeric_arrays=count,singleton_stride_qualifications=qualified,input_sha256=hashlib.sha256((r/'singleton-inputs.npz').read_bytes()).hexdigest(),numpy=np.__version__)
(r/'singleton-qualification.json').write_text(json.dumps(report,indent=2)+'\n');print('Singleton qualification',count,'arrays;',len(qualified),'equivalent stored layouts')
