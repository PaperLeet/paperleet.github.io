from pathlib import Path
import hashlib,json
import numpy as np
r=Path(__file__).resolve().parent
native=json.loads((r/'native-determinants.json').read_text());candidate=json.loads((r/'adapter-determinants.json').read_text());baseline=json.loads((r/'baseline-determinants.json').read_text())
na=np.load(r/'native-determinants.npz');ca=np.load(r/'adapter-determinants.npz');ba=np.load(r/'baseline-determinants.npz')
assert native['version']=='2.14.1'
counts=dict(log_native_cases=0,det_native_cases=0,det_legacy_cases=0,det_restricted_cases=0,numeric_arrays=0,none_gradients=0,singleton_layout_contract_arrays=0)
qualifications=[];max_errors={}
def compare_array(key,field,target,tolerance=None):
    a=ca[key+'.'+field];b=target[key+'.'+field]
    assert a.shape==b.shape and a.dtype==b.dtype,(key,field,'array schema')
    error=0.
    for aa,bb in ((a.real,b.real),(a.imag,b.imag)) if np.iscomplexobj(a) else ((a,b),):
        assert np.array_equal(np.isnan(aa),np.isnan(bb)),(key,field,'NaN')
        assert np.array_equal(np.isposinf(aa),np.isposinf(bb)),(key,field,'+Inf')
        assert np.array_equal(np.isneginf(aa),np.isneginf(bb)),(key,field,'-Inf')
        mask=np.isfinite(bb);x=aa[mask].astype(np.float64);y=bb[mask].astype(np.float64)
        if x.size:
            scale=max(float(np.max(np.abs(y))),float(np.max(np.abs(x))),np.finfo(np.float64).tiny)
            error=max(error,float(np.linalg.norm((x-y)/scale)/max(np.linalg.norm(y/scale),np.finfo(np.float64).tiny)))
            if tolerance is not None:assert error<=tolerance,(key,field,'normwise',error)
            else:np.testing.assert_allclose(x,y,rtol=3e-5 if a.dtype.itemsize/(2 if np.iscomplexobj(a) else 1)==4 else 3e-11,atol=3e-6 if a.dtype.itemsize/(2 if np.iscomplexobj(a) else 1)==4 else 3e-12,err_msg=key+'.'+field)
    counts['numeric_arrays']+=1
    label=('float32' if a.dtype in (np.dtype('float32'),np.dtype('complex64')) else 'float64')+'.'+field
    max_errors[label]=max(max_errors.get(label,0.),error)
def schema(key,actual,expected):
    assert actual.keys()==expected.keys(),(key,'field names')
    for field,value in actual.items():
        other=expected[field]
        if value is None or other is None:
            assert value is other,(key,field,'None');counts['none_gradients']+=1;continue
        assert {k:v for k,v in value.items() if k!='stride'}=={k:v for k,v in other.items() if k!='stride'},(key,field,'metadata')
        if value['stride']!=other['stride']:
            # Native's gradient layout contract ignores singleton-axis strides
            # when the incoming owned gradient is reused. We own a separate
            # parameter-layout gradient buffer; both descriptors address exactly
            # the same elements. All non-singleton strides must still match.
            assert field=='gradient' and all((n==1 and s>0 and t>0) or s==t for n,s,t in zip(value['shape'],value['stride'],other['stride'])),(key,field,'stride',value,other)
            counts['singleton_layout_contract_arrays']+=1;qualifications.append(dict(case=key,field=field,candidate=value['stride'],native=other['stride']))
for key,row in candidate['rows'].items():
    ref=native['rows'][key];op=row['operation'];case=row['case']
    if op=='det' and case in {12,13,15}:
        old=baseline['rows'][key];assert row['status']==old['status']=='error' and row['error']==old['error'] and row['message']==old['message'];counts['det_restricted_cases']+=1;continue
    assert row['status']==ref['status']=='ok',(key,row,ref)
    if op=='det' and case in {2,3,4,10,11,14,16,18}:
        old=baseline['rows'][key];assert old['status']=='ok';schema(key,row['values'],old['values'])
        for field,value in row['values'].items():
            if value is not None:compare_array(key,field,ba,1e-5 if row['dtype']=='float32' else 3e-11)
        counts['det_legacy_cases']+=1
    else:
        schema(key,row['values'],ref['values'])
        for field,value in row['values'].items():
            if value is not None:compare_array(key,field,na)
        counts['log_native_cases' if op!='det' else 'det_native_cases']+=1
assert counts['log_native_cases']==480 and counts['det_native_cases']==54 and counts['det_legacy_cases']==48 and counts['det_restricted_cases']==18
source=Path('/runtime/stridetorch')
if not source.exists():source=Path('/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src/stridetorch')
report=dict(status='success',native_version=native['version'],numpy=np.__version__,counts=counts,maximum_scaled_l2_diagnostics=max_errors,singleton_stride_qualifications=qualifications,source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in source.iterdir() if f.is_file()},input_sha256=hashlib.sha256((r/'determinant-inputs.npz').read_bytes()).hexdigest())
(r/'determinants-qualification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],counts=counts)))
