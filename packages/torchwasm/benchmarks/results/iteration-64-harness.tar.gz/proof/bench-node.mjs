import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const base=new URL('./chrome-contracts/',import.meta.url);const plan=JSON.parse(fs.readFileSync(new URL('bench-plan.json',base)));
const py=await loadPyodide({indexURL:'/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/',packageCacheDir:'/Users/david/Developer/PaperLeet-torch-release/web/public/browser-runtime/pyodide-0.29.4/',stdout(){},stderr(){}});
await loadJudgePackages(py,[]);
for(const [name,dir] of [['baseline','baseline'],['candidate','source']]){
 py.FS.mkdirTree('/'+name+'/stridetorch');
 for(const file of Object.keys(plan[name]))py.FS.writeFile('/'+name+'/stridetorch/'+file,fs.readFileSync(new URL(dir+'/'+file,base)));
}
py.FS.writeFile('/bench_determinants.py',fs.readFileSync(new URL('bench_determinants.py',base)));
py.FS.writeFile('/bench_det_jvp.py',fs.readFileSync(new URL('bench_det_jvp.py',base)));
py.globals.set('plan_json',JSON.stringify(plan));
const result=JSON.parse(py.runPython(`
import sys,json,pathlib,hashlib
sys.path.insert(0,'/')
plan=json.loads(plan_json)
for label in ['baseline','candidate']:
 actual={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in pathlib.Path('/'+label+'/stridetorch').iterdir() if f.is_file()}
 assert actual==plan[label]
assert hashlib.sha256(pathlib.Path('/bench_determinants.py').read_bytes()).hexdigest()==plan['benchmark_sha256']
import numpy
from bench_determinants import run
bench=run('/baseline/stridetorch','/candidate/stridetorch')
from bench_det_jvp import run as run_jvp
bench['jvp_benchmark']=run_jvp('/baseline/stridetorch','/candidate/stridetorch')
assert bench['jvp_benchmark']['program_sha256']==plan['jvp_benchmark_sha256']
assert bench['source_hashes']==dict(baseline=plan['baseline'],candidate=plan['candidate'])
json.dumps(dict(status='success',numpy=numpy.__version__,benchmark_sha256=plan['benchmark_sha256'],benchmark=bench))
`));result.pyodide=py.version;assert.equal(result.numpy,'2.2.5');
fs.writeFileSync(new URL("bench-node-result.json",import.meta.url),JSON.stringify(result,null,2)+String.fromCharCode(10));
console.log(JSON.stringify({status:result.status,flows:result.benchmark.rows.length,pyodide:result.pyodide,numpy:result.numpy}));
