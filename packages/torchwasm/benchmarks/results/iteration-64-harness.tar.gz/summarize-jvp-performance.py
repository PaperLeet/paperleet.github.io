from pathlib import Path
import json,statistics
r=Path(__file__).resolve().parent;rows=[]
for runtime in ['cpu','node','chrome']:
 runs=[]
 for repeat in range(4):
  data=json.loads((r/f'performance/{runtime}-{repeat}.json').read_text());run=data.get('benchmark',data)['jvp_benchmark'];assert len(run['rows'])==16;runs.append(run)
 for index,first in enumerate(runs[0]['rows']):
  metadata={key:first[key] for key in ['dtype','shape','input_shape','mode']};children=[run['rows'][index] for run in runs]
  assert all({key:value[key] for key in metadata}==metadata for value in children)
  ratios=[value['candidate_over_composition'] for value in children]
  rows.append(dict(runtime=runtime,**metadata,ratio_median=statistics.median(ratios),ratio_range=[min(ratios),max(ratios)],child_ratios=ratios,candidate_median_us=statistics.median(value['median_s']['candidate_jvp'] for value in children)*1e6,composition_median_us=statistics.median(value['median_s']['baseline_composition'] for value in children)*1e6))
result=dict(status='measured',children=12,rows_per_child=16,rows=rows,scope=runs[0]['scope'])
(r/'jvp-performance-summary.json').write_text(json.dumps(result,indent=2)+'\n');print('Summarized',len(rows),'runtime/JVP workflows against the explicit 0.63 composition')
