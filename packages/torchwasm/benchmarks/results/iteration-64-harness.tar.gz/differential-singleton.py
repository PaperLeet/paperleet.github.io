from pathlib import Path
import json,sys,warnings
import numpy as np
r=Path(__file__).resolve().parent;backend=sys.argv[1]
if backend=='native':import torch as t
else:from stridetorch import torch as t
inputs=np.load(r/'singleton-inputs.npz');cases=json.loads((r/'singleton-inputs.json').read_text())['cases'];rows={};arrays={}
def source(data,layout):
 if layout=='factory':return t.ones(data.shape,dtype=getattr(t,str(data.dtype))).requires_grad_()
 if layout=='S':
  base=np.zeros((*data.shape[:-2],2,2),dtype=data.dtype);base[...,0,0]=data[...,0,0];value=t.from_numpy(base)[...,::2,::2]
 else:value=t.from_numpy(np.array(data,order=layout,copy=True))
 return value.detach().requires_grad_()
def seed(data,layout):
 if layout=='S' and data.ndim:
  base=np.zeros(tuple(2*n for n in data.shape),dtype=data.dtype);slices=tuple(slice(None,None,2) for _ in data.shape);base[slices]=data;return t.from_numpy(base)[slices]
 return t.from_numpy(np.array(data,order=layout if layout!='S' else 'C',copy=True))
for case in cases:
 key=case['key'];data=inputs[key+'.a'];x=source(data,case['layout']);g=seed(inputs[key+'.seed'],case['seed_layout'])
 try:
  with warnings.catch_warnings():
   warnings.simplefilter('ignore');value=x.det();gradient=t.autograd.grad(value,x,g)[0];other=source(data,case['layout']);other.det().backward(g)
  row=dict(status='ok',seed_alias=bool(np.shares_memory(gradient.detach().numpy(),g.numpy())),output_alias=bool(np.shares_memory(value.detach().numpy(),x.detach().numpy())),values={})
  for name,v in [('value',value),('gradient',gradient),('stored',other.grad)]:
   a=v.detach().numpy();row['values'][name]=dict(shape=list(v.shape),stride=list(v.stride()),dtype=str(a.dtype),requires_grad=v.requires_grad);arrays[key+'.'+name]=a.copy()
  rows[key]=row
 except Exception as e:rows[key]=dict(status='error',error=type(e).__name__,message=str(e))
np.savez_compressed(r/(backend+'-singleton-controls.npz'),**arrays);(r/(backend+'-singleton-controls.json')).write_text(json.dumps(dict(backend=backend,numpy=np.__version__,rows=rows),indent=2)+'\n');print(backend,'singleton',len(rows),'cases',sum(v['status']!='ok' for v in rows.values()),'errors')
