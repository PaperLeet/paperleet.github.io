"""Explain near-zero componentwise differences without weakening IEEE checks."""
from pathlib import Path
import json
import numpy as np
r=Path(__file__).resolve().parent;native=np.load(r/'native-jvp.npz');candidate=np.load(r/'adapter-jvp.npz');inputs=np.load(r/'jvp-inputs.npz')
a=inputs['float32.26.a'].astype('float64');e=inputs['float32.26.e'].astype('float64');seed=inputs['float32.26.seed']
with np.errstate(all='ignore'):
 solved=np.linalg.solve(a,e);trace=np.trace(solved);_,logabs=np.linalg.slogdet(a);det=np.exp(logabs)
 expected=det*trace*np.linalg.inv(a).T*seed
rows=[]
for layout in ['C','F','S']:
 key='float32.26.'+layout+'.0';x=native[key+'.gradient_a'].astype('float64');y=candidate[key+'.gradient_a'].astype('float64');scale=float(np.max(np.abs(x)));delta=np.abs(x-y)
 rows.append(dict(layout=layout,reference_trace=float(native[key+'.tangent']/native[key+'.primal']),candidate_trace=float(candidate[key+'.tangent']/candidate[key+'.primal']),float64_trace=float(trace),scaled_max_error=float(np.max(delta)/scale),relative_l2_error=float(np.linalg.norm(x-y)/np.linalg.norm(x)),reference_relative_error_to_float64=float(np.linalg.norm(x-expected)/np.linalg.norm(expected)),candidate_relative_error_to_float64=float(np.linalg.norm(y-expected)/np.linalg.norm(expected))))
result=dict(scope='Diagnostic against a double-precision inverse/trace formula at the same exact float32 inputs; not an arbitrary-precision oracle. Eight original strict componentwise failures are confined to near-zero entries; large float32 matrix gradients use a documented per-matrix max-norm bound of 1e-5 while NaN/Inf masks remain exact.',rows=rows)
(r/'float32-cancellation-diagnostic.json').write_text(json.dumps(result,indent=2)+'\n')
print('Maximum observed scaled max error:',max(v['scaled_max_error'] for v in rows))
