from pathlib import Path
import hashlib,json
import numpy as np
r=Path(__file__).resolve().parent;arrays={};cases=[]
with np.errstate(all='ignore'):
 for dtype in ['float32','float64']:
  d=np.dtype(dtype);f=np.finfo(d);rng=np.random.default_rng(6401)
  a2=np.array([[2.,.3],[.4,3.]],dtype=d)
  examples=[('scalar_regular',[[2.]]),('scalar_zero',[[0.]]),('scalar_negative_zero',[[-0.]]),('scalar_maximum',[[f.max]]),('scalar_tiny',[[f.tiny]]),('scalar_subnormal',[[np.nextafter(d.type(0),d.type(1))]]),('regular2',a2),('negative2',a2*np.array([[-1], [1]],dtype=d)),('zero_pivot2',np.diag([0.,2.])),('rank_one2',[[1.,2.],[2.,4.]]),('zero2',np.zeros((2,2))),('regular3',np.eye(3)*3+rng.normal(size=(3,3))*.1),('rank_two3',np.diag([2.,0.,3.])),('mixed_batch',np.stack([a2,np.diag([0.,2.]),[[1.,2.],[2.,4.]],np.zeros((2,2))])),('batch3',np.eye(3)*3+rng.normal(size=(2,3,3))*.1),('singleton_batch',np.array([0.,f.max,f.tiny,np.nextafter(d.type(0),d.type(1)),-1.,-0.],dtype=d).reshape(2,3,1,1)),('empty0',np.empty((0,0))),('batch_empty0',np.empty((2,0,0))),('empty_batch2',np.empty((0,2,2))),('empty_batch1',np.empty((2,0,1,1))),('underflow4',np.eye(4)*(1e-15 if dtype=='float32' else 1e-100)),('overflow4',np.eye(4)*(1e15 if dtype=='float32' else 1e100)),('infinite_direction',a2),('nan_direction',a2),('zero_direction',a2),('regular8',np.eye(8)*4+rng.normal(size=(8,8))*.1),('regular32',np.eye(32)*4+rng.normal(size=(32,32))*.1),('singular32',np.diag(np.r_[np.arange(1,32),0.])),('pivoted_rank_two3',[[0.,2.,1.],[0.,4.,3.],[0.,6.,5.]])]
  for index,(name,data) in enumerate(examples):
   a=np.array(data,dtype=d);e=rng.normal(size=a.shape).astype(d);seed=rng.uniform(.4,1.2,size=a.shape[:-2]).astype(d)
   if name=='infinite_direction':e[0,0]=np.inf
   if name=='nan_direction':e[0,0]=np.nan
   if name=='zero_direction':e[...]=0
   key=f'{dtype}.{index}'
   for suffix,value in [('a',a),('e',e),('seed',seed)]:arrays[key+'.'+suffix]=value
   cases.append(dict(key=key,dtype=dtype,index=index,name=name,shape=list(a.shape)))
np.savez_compressed(r/'jvp-inputs.npz',**arrays)
(r/'jvp-inputs.json').write_text(json.dumps(dict(cases=cases,arrays=len(arrays),sha256=hashlib.sha256((r/'jvp-inputs.npz').read_bytes()).hexdigest()),indent=2)+'\n')
print(len(cases),'matrix/direction/seed groups;',len(arrays),'frozen arrays')
