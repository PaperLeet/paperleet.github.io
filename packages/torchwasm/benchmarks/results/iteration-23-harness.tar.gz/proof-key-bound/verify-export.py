from pathlib import Path
import hashlib,json,re,subprocess
from stridetorch import runtime

repo=Path.cwd();root=Path(__file__).parent;data=repo/'web/public/data'
upstream=subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip()
rows=subprocess.check_output(['git','ls-tree','-rz',upstream,'--','web/public/data/browser-judge','web/public/data/modules']).split(b'\0')
published={};tree=[]
for row in rows:
    if not row:continue
    header,name=row.split(b'\t',1);mode,kind,object_id=header.decode().split();name=name.decode()
    assert kind=='blob'
    raw=(repo/name).read_bytes()
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==object_id,name
    published[name]=hashlib.sha256(raw).hexdigest();tree.append(name+' '+published[name])
index=json.loads((data/'index.json').read_text());active=set();runtimes={}
def read(relative):
    path=data/relative;raw=path.read_bytes();digest=hashlib.sha256(raw).hexdigest()
    assert digest[:20] in path.name,relative
    active.add(relative);return json.loads(raw)
for entry in index['problems']:
    read(entry['detail_url'])
    manifest=read(entry['browser_judge']['bundle_url'])
    assert manifest['problem']==entry['id']
    relative=manifest['runtime_bundle_url'];payload=read(relative)
    profile='autograd' if payload['backend']=='numpy-autograd-wasm' else 'schedules'
    expected=runtime.source_files(profile)
    assert all(payload['files'].get(name)==value for name,value in expected.items()),(entry['id'],profile)
    runtimes[relative]=dict(backend=payload['backend'],package_files=len(expected),sha256=hashlib.sha256((data/relative).read_bytes()).hexdigest())
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z','--','web/public/data/browser-judge','web/public/data/modules']).decode().split('\0')
new=[path for path in new if path]
unreachable=[path for path in new if str(Path(path).relative_to('web/public/data')) not in active]
assert not unreachable,unreachable
assert len(published)==6440,len(published)
report=dict(status='success',upstream=upstream,published_assets_unchanged=len(published),published_sha256_tree=hashlib.sha256('\n'.join(sorted(tree)).encode()).hexdigest(),catalog_modules=len(index['problems']),active_assets=len(active),new_assets=len(new),all_new_assets_reachable=True,runtimes=runtimes)
(root/'export-identity.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
