from pathlib import Path
import hashlib,json,os,statistics,subprocess,time
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');h=r/'frozen-key-bound/harness';out=r/'performance-key-bound';out.mkdir();python='/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-21/stride-dev-env/bin/python';receipts=[];start=time.monotonic()
def hashes(p):return {x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in p.iterdir() if x.is_file() and (x.suffix in ('.py','.mjs') or x.name in ('LICENSE','NOTICE'))}
hash_harness=hashes(h);source={'baseline':r/'baseline/stridetorch','candidate':r/'frozen-key-bound/stridetorch'};expected={k:hashes(p) for k,p in source.items()}
for backend in ('cpu','wasm'):
 for dtype in ('float32','float64'):
  for index,label in enumerate(('baseline','candidate','candidate','baseline')):
   assert hashes(h)==hash_harness and all(hashes(p)==expected[k] for k,p in source.items())
   name=f'{backend}-{dtype}-{index}-{label}';dest=out/(name+'.json');env=os.environ.copy();env['PYTHONPATH']=str(source[label].parent);common=['--benchmark','dispatch','--dtype',dtype,'--repeat','11','--iterations','2000','--output',str(dest)]
   if backend=='cpu':cmd=[python,str(h/'bench_cpu.py'),'--threads','2',*common]
   else:cmd=['/opt/homebrew/bin/node',str(h/'bench_wasm.mjs'),'--source',str(source[label]),'--runtime',str(repo/'web/node_modules/pyodide'),'--cache',str(repo/'web/public/browser-runtime/pyodide-0.29.4'),*common]
   t=time.monotonic()
   with (out/(name+'.log')).open('w') as log:completed=subprocess.run(cmd,env=env,cwd=r,stdout=log,stderr=subprocess.STDOUT)
   receipt=dict(name=name,backend=backend,dtype=dtype,label=label,exit_code=completed.returncode,elapsed_s=time.monotonic()-t,command=cmd);receipts.append(receipt);(r/'performance-key-bound-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');assert completed.returncode==0,receipt
   result=json.loads(dest.read_text());actual=result['source_hashes'] if backend=='cpu' else {**result['source_hashes'],**result['resource_hashes']};assert actual==expected[label],name
   assert hashes(h)==hash_harness and all(hashes(p)==expected[k] for k,p in source.items())
   print(name,round(receipt['elapsed_s'],3),'terminal0',flush=True)
summary=dict(status='success',elapsed_s=time.monotonic()-start,source_hashes=expected,harness_hashes=hash_harness,receipts=receipts,scope='ABBA fresh sequential processes;11 batches;3 warmups;2000 forward/400 reverse calls per batch. Shared machine,CPU env requested2 threads;actual BLAS threading unverified. No local tests/builds/audits overlap. Steady-state library measurements;no coldstart/native Torch/application speed claims.',results={})
for backend in ('cpu','wasm'):
 for dtype in ('float32','float64'):
  inputs={label:[json.loads((out/(x['name']+'.json')).read_text()) for x in receipts if x['backend']==backend and x['dtype']==dtype and x['label']==label] for label in source};rows={}
  for case in inputs['baseline'][0]['results']:
   a=[x['results'][case]['median_ms'] for x in inputs['baseline']];b=[x['results'][case]['median_ms'] for x in inputs['candidate']];rows[case]=dict(baseline_medians_ms=a,candidate_medians_ms=b,time_reduction_percent=100*(1-statistics.mean(b)/statistics.mean(a)))
  summary['results'][backend+'-'+dtype]=rows
(r/'performance-key-bound-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('ALL16TERMINAL0',flush=True)
