from pathlib import Path
import json
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');j=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-63.json').read_text());rows=j['performance']['rows']
def table(selected):
 s='| Runtime | Operation | Dtype | Shape | Mode | Candidate / 0.62 | Four-child range |\n|---|---|---|---|---|---:|---:|\n'
 for v in selected:
  a,b=v['ratio_range'];s+=f"| {v['runtime']} | {v['operation']} | {v['dtype']} | {v['input_shape']} | {v['mode']} | {v['ratio_median']:.3f} | {a:.3f}–{b:.3f} |\n"
 return s
scalar=[v for v in rows if v['operation']=='det' and v['shape']=='scalar'];small=[v for v in rows if v['operation']=='det' and v['shape']=='small' and v['mode']=='forward'];large=[v for v in rows if v['operation']=='det' and v['shape']=='larger'];controls=[v for v in rows if v['operation']=='graph'];worst=sorted(rows,key=lambda v:v['ratio_median'],reverse=True)[:8]
a=j['raw_archive'];stages=j['ui_qualification_stages'];ui='; '.join(f"{len(v['checks'])} affected checks at `{v['upstream']}` plus driver/policy/two-build gates" for v in stages) if stages else 'No later UI sync was needed.'
text=f'''# Torch runtime iteration 63 — robust determinants under NumPy policies

Version **0.63.0** fixes false floating-point failures in determinant evaluation
and exact 1×1 determinant values/gradients at extreme scales. Final integration
base is `{j['baseline_main']}`; the full CPU/frontend/catalog baseline is
`{j['full_validation_baseline']}`. {ui}

## Actual failures and correction

The prior 0.62 implementation raises `FloatingPointError` for finite 32×32,
64×64 and 128×128 identity determinants under `numpy.seterr(all='raise')` on the
tested CPU NumPy 2.5.4 build. A frozen 162-case diagnostic across nine linalg
APIs, two real dtypes and nine sizes identifies determinant failures; the same
candidate diagnostic has no errors. This is a runtime observation, not a claim
that every NumPy/BLAS build has the defect.

On runtimes that report IEEE error flags, determinant factorization now runs
inside a local NumPy ignore context. Valid finite Torch inputs no longer depend
on the caller's NumPy arithmetic exception/callback policy. The policy and callback
are restored. The WASM runtime that cannot report those flags avoids that context.
Existing dtype, square-matrix, finite-input and output-buffer guards remain in
place. Genuine determinant overflow/underflow keeps its IEEE value rather than
becoming a Python exception.

For 1×1 matrices, the determinant is the stored element and its differential is
the incoming seed. Copying that value avoids logarithm/exponential rounding.
Returning the seed view avoids multiplying by a huge/tiny determinant and then
dividing it back out. Native reference confirms the corrected behavior: the old
maximum-float32 matrix with seed 2 produced Inf instead of 2; the old smallest
float64 subnormal could produce NaN/Inf instead of the seed. Negative zero is
preserved. Raw VJP returns native seed-view strides/aliasing, including strided
batches; leaf `.grad` still owns its buffer. Empty raw VJPs preserve native input
layout. Input/output saved-value mutation guards remain in force.

No other determinant cofactor contract, log API, JVP boundary or runtime dependency
is changed. General singular/extreme matrices retain the existing cofactor path.
Real first-order gradients remain the scope; det JVP and complex det remain
unsupported. Existing broader limits are recorded in the
[0.62 report](torch-runtime-iteration-62.md).

## Verification

- **41,084 CPU passes, 1 skip**, exact source hashes checked before and after.
- Actual Node/Pyodide and Chrome Worker: **7,454 independent contracts each**,
  all **55 suites**. Python 3.10.19 / NumPy 1.26.4 installed public wheel:
  **7,467 passes**, native Torch absent.
- **114 new independent SDK cases** cover exact singleton polynomial values and
  slopes, negative zero, subnormals/maximum finite inputs, Inf/NaN seeds, NumPy
  raise/warn/call policies, restored callbacks, seed aliases versus owned leaf
  gradients, empty/factory layouts and saved-value mutation failures.
- Original 600-case qualification remains: 480 native log cases, 54 ordinary
  native det cases, 48 separate legacy det cases and 18 retained restriction
  cases, with 1,764 numerical arrays and 360 None-gradient fields per runtime.
- Additional **398 frozen singleton cases / 796 exact inputs and seeds** compare
  **1,194 arrays** with native Torch 2.14.1. C/F/sliced data and seeds, scalar and
  batched cases, empty NumPy/factory inputs, output ownership and raw seed aliases
  are checked. Values, NaN/Inf masks and non-NaN sign bits are exact. The 118
  equivalent positive-singleton stored-gradient layouts retain the documented
  allocation rule; raw VJP layouts are checked exactly.
- Both qualifiers run on CPU, Node, Chrome and the isolated minimum environment.
  Native reference git is `5c4886908584029761b579af026dcfb627c84070`. Legacy
  cofactor/restriction cases are not reported as native passes.
- Public wheel/sdist and vendored wheel match all 59 Python modules plus two
  license resources. Coexistence, uninstalling either owner, alias restoration,
  fresh-process model/activation serialization and native Torch isolation pass.
- All **78 exported modules and 342 mutants** pass original browser budgets.
  The embedded independent contracts include all 55 suites. All 1,152 native
  catalog input hashes and 12,915 earlier immutable payloads are unchanged;
  158 new assets are reachable and 161 active export/index hashes are recorded.
- Full frontend checks and both build profiles pass at the recorded baseline;
  later disjoint UI changes, if any, have explicit staged qualification above.
- Seven release-policy files are byte-identical to canonical
  `13d2782a494415ba72bc604a0ef7e4c4f875ba25`. No CI trigger, tag, workflow dispatch,
  release, package upload or deployment is initiated.

## Performance and cost against actual 0.62

Twelve fresh children, four CPU/Node/Chrome each, **100 matched workflows per
child**, five alternating samples with common calibrated batches of at least
20 ms. Both variants invoke actual 0.62/0.63 determinant/log APIs. Tables give
median child ratios and ranges; below 1 is faster. Inputs/conversions/seeds
are outside timing; dispatch, graphs, kernels, weighted backward, clearing and
result destruction are inside. Correctness/budget runs finish before timing.
CPU thread caps are two; no host-wide isolation, cold-start, native-Torch or GPU
throughput claim is made.

1×1 determinant workflows:

{table(scalar)}
The CPU error-policy context has a cost for ordinary 2×2 forward-only calls.
These costs are retained explicitly rather than hidden by singleton gains:

{table(small)}
64×64 determinant workflows:

{table(large)}
Graph controls:

{table(controls)}
Largest matched ratios, including losses:

{table(worst)}
All 300 runtime/workflow aggregate rows, 1,200 child workflow results, samples,
calibration values and source identities are retained. Float32 benchmark gradient
checks keep the existing separately labeled 1e-5 normwise bound; native/singleton
correctness qualification does not relax its checks.

## Allocation and reproduction

Warm incremental CPU tracemalloc allocations are recorded for 24 ordinary
64×64/4×32×32 workflows. `warm-memory.py` primes both actual API paths; inputs
and seeds predate tracing. Forward retained/peak and backward peak are separate,
not total tape bytes, process RSS, LAPACK workspace or WASM heap size. Cold-first
diagnostics remain separate. Full allocation/footprint tables are in the machine
report; no new runtime dependency or GPU path is introduced.

[Machine report](../../packages/stridetorch/benchmarks/results/iteration-63.json)
and [raw harness](../../packages/stridetorch/benchmarks/results/iteration-63-harness.tar.gz).
Archive: {a['bytes']:,} bytes; SHA-256 `{a['sha256']}`. Source snapshots, frozen
native inputs/results, policy diagnostics, programs, plans, package artifacts,
receipts, development failures and samples are included. The public benchmark
is `packages/stridetorch/benchmarks/bench_determinants.py`.

The broader independent-library/core-coverage/backend objective remains active.
'''
(repo/'docs/validation/torch-runtime-iteration-63.md').write_text(text);print('Wrote iteration-63 validation report')
