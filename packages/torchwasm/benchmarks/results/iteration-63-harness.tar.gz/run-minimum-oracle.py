from pathlib import Path
import hashlib,json,shutil,subprocess,os,time
r=Path(__file__).resolve().parent;d=r/'minimum-oracle';d.mkdir();python=r/'proof/python310-stride063-env/bin/python';env=dict(os.environ);env.pop('PYTHONPATH',None)
installed=Path(subprocess.check_output([str(python),'-I','-c','import pathlib,stridetorch;print(pathlib.Path(stridetorch.__file__).parent)'],cwd=d,env=env,text=True).strip())
expected=json.loads((r/'proof/source-hashes.json').read_text());actual={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in installed.iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')};assert actual==expected
for name in ['differential-determinants.py','native-determinants.json','native-determinants.npz','baseline-determinants.json','baseline-determinants.npz','determinant-inputs.npz','determinant-inputs.json','differential-singleton.py','qualify-singleton.py','singleton-inputs.json','singleton-inputs.npz','native-singleton-controls.json','native-singleton-controls.npz']:shutil.copy2(r/name,d/name)
s=(r/'qualify-determinants.py').read_text().replace('/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src/stridetorch',str(installed));(d/'qualify-determinants.py').write_text(s)
receipts=[]
for name,args in [('adapter',[str(python),'-I',str(d/'differential-determinants.py'),'adapter']),('qualification',[str(python),'-I',str(d/'qualify-determinants.py')]),('singleton-adapter',[str(python),'-I',str(d/'differential-singleton.py'),'adapter']),('singleton-qualification',[str(python),'-I',str(d/'qualify-singleton.py')])]:
 start=time.monotonic()
 with (d/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(label=name,args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-start));p.check_returncode()
q=json.loads((d/'determinants-qualification.json').read_text());assert q['source_hashes']==expected and q['numpy']=='1.26.4'
report=dict(status='success',scope='Same 600-case qualifier on isolated installed wheel, Python 3.10.19 / NumPy 1.26.4, native Torch absent; baseline legacy arrays remain frozen 0.62 outputs.',source_hashes=actual,receipts=receipts,qualification=q,singleton_qualification=json.loads((d/'singleton-qualification.json').read_text()))
(r/'minimum-oracle-result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],numpy=q['numpy'],counts=q['counts'])))
