import json,numpy as np,torch as t
from pathlib import Path
rows=[]
for shape in [(1,1),(3,1,1),(2,3,1,1),(0,1,1)]:
 for layout in ['C','S']:
  base=np.ones((*shape[:-2],2,2),dtype=np.float64);data=base[...,::2,::2] if layout=='S' else np.ones(shape)
  x=t.from_numpy(data).requires_grad_();out=x.det();seed=t.arange(out.numel(),dtype=t.float64).reshape(out.shape)+1;g=t.autograd.grad(out,x,seed)[0]
  rows.append(dict(shape=shape,layout=layout,input_stride=x.stride(),output_stride=out.stride(),gradient_stride=g.stride(),gradient_seed_alias=bool(np.shares_memory(g.numpy(),seed.numpy())),output_input_alias=bool(np.shares_memory(out.detach().numpy(),x.detach().numpy()))))
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
