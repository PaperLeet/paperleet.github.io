import {loadJudgePackages} from '../../../extraction-browser/packages.mjs';
self.onmessage=async()=>{try{
 const plan=await(await fetch('./oracle-plan.json')).json();
 const {loadPyodide}=await import('../../../runtime-0.29.4/pyodide.mjs');
 const py=await loadPyodide({indexURL:new URL('../../../runtime-0.29.4/',self.location.href).href,stdout(){},stderr(){}});
 await loadJudgePackages(py,[]);py.FS.mkdirTree('/runtime/stridetorch');py.FS.mkdirTree('/oracle');
 for(const name of Object.keys(plan.source))py.FS.writeFile('/runtime/stridetorch/'+name,await(await fetch('./source/'+name)).text());
 for(const name of Object.keys(plan.files))py.FS.writeFile('/oracle/'+name,new Uint8Array(await(await fetch('./'+name)).arrayBuffer()));
 py.globals.set('plan_json',JSON.stringify(plan));
 const report=JSON.parse(py.runPython("\nimport sys,json,pathlib,hashlib\nsys.path.insert(0,'/runtime')\nplan=json.loads(plan_json)\nfor name,digest in plan['source'].items():assert hashlib.sha256(pathlib.Path('/runtime/stridetorch',name).read_bytes()).hexdigest()==digest\nfor name,digest in plan['files'].items():assert hashlib.sha256(pathlib.Path('/oracle',name).read_bytes()).hexdigest()==digest\nsys.argv=['/oracle/differential-determinants.py','adapter']\nexec(compile(pathlib.Path(sys.argv[0]).read_text(),sys.argv[0],'exec'),{'__file__':sys.argv[0],'__name__':'__main__'})\nsys.argv=['/oracle/differential-singleton.py','adapter']\nexec(compile(pathlib.Path(sys.argv[0]).read_text(),sys.argv[0],'exec'),{'__file__':sys.argv[0],'__name__':'__main__'})\nscript='/oracle/qualify-singleton.py'\nexec(compile(pathlib.Path(script).read_text(),script,'exec'),{'__file__':script,'__name__':'__main__'})\nscript='/oracle/qualify-determinants.py'\nexec(compile(pathlib.Path(script).read_text(),script,'exec'),{'__file__':script,'__name__':'__main__'})\nreport=json.loads(pathlib.Path('/oracle/determinants-qualification.json').read_text())\nassert report['source_hashes']==plan['source']\njson.dumps(dict(status='success',qualification=report,singleton_qualification=json.loads(pathlib.Path('/oracle/singleton-qualification.json').read_text())))\n"));
 self.postMessage({...report,pyodide:py.version,numpy:py.runPython('__import__("numpy").__version__')});
}catch(error){self.postMessage({error:String(error.stack||error)});}};
