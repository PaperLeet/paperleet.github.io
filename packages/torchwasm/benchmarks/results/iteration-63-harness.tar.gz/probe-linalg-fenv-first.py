from pathlib import Path
import importlib.util,json,sys,warnings
import numpy as np
r=Path(__file__).resolve().parent;sys.path.insert(0,'/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src');from stridetorch import torch as t
rows=[]
for dtype in [np.float32,np.float64]:
 for n in [1,2,3,4,8,16,32,64,128]:
  a=np.eye(n,dtype=dtype);x=t.tensor(a);b=t.ones(n,2,dtype=dtype)
  for name,fn in [('det',lambda:t.det(x)),('inv',lambda:t.linalg.inv(x)),('solve',lambda:t.linalg.solve(x,b)),('cholesky',lambda:t.linalg.cholesky(x)),('eigvalsh',lambda:t.linalg.eigvalsh(x)),('qr',lambda:t.linalg.qr(x)),('svd',lambda:t.linalg.svd(x)),('logdet',lambda:t.logdet(x)),('slogdet',lambda:t.slogdet(x))]:
   row=dict(dtype=str(a.dtype),n=n,operation=name)
   with np.errstate(all='raise'):
    try:
     out=fn();values=list(out) if isinstance(out,tuple) else [out];row.update(status='ok',finite=all(np.isfinite(y.numpy()).all() for y in values))
    except Exception as e:row.update(status='error',error=type(e).__name__,message=str(e))
   rows.append(row)
(r/'linalg-fenv-baseline.json').write_text(json.dumps(dict(numpy=np.__version__,version=t.__version__,rows=rows),indent=2)+'\n');print(json.dumps([v for v in rows if v['status']!='ok']))
