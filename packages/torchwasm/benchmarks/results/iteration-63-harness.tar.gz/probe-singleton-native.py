from pathlib import Path
import sys,json,warnings
import numpy as np
r=Path(__file__).resolve().parent;kind=sys.argv[1]
if kind=='native':import torch as t
else:
 sys.path.insert(0,'/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src');from stridetorch import torch as t
rows=[]
for dtype in [np.float32,np.float64]:
 info=np.finfo(dtype)
 for a in [0.,-1.,1.,info.tiny,float(np.nextafter(dtype(0),dtype(1))),info.max]:
  for g in [0.,1.,2.,float('inf'),float('nan')]:
   with warnings.catch_warnings():
    warnings.simplefilter('ignore')
    x=t.tensor([[a]],dtype=getattr(t,str(np.dtype(dtype))),requires_grad=True);y=t.det(x);y.backward(t.tensor(g,dtype=x.dtype))
   rows.append(dict(dtype=str(np.dtype(dtype)),a=str(a),seed=str(g),value=str(y.item()),gradient=str(x.grad.item())))
(r/(kind+'-singleton.json')).write_text(json.dumps(rows,indent=2)+'\n');print(kind,len(rows),'cases')
