from pathlib import Path
import json,numpy as np
r=Path(__file__).resolve().parent;rows=[];arrays={}
with np.errstate(all='ignore'):
 for dtype in [np.float32,np.float64]:
  info=np.finfo(dtype);values=[dtype(0),dtype(-0.),dtype(-1),dtype(info.tiny),np.nextafter(dtype(0),dtype(1)),dtype(info.max),dtype(-info.max)]
  seeds=[0.,-0.,1.,-1.,2.,np.inf,-np.inf,np.nan]
  for ai,a in enumerate(values):
   for si,seed in enumerate(seeds):
    for layout in ['C','F','S']:
     key=str(len(rows));arrays[key+'.a']=np.array([[a]],dtype=dtype);arrays[key+'.seed']=np.array(seed,dtype=dtype);rows.append(dict(key=key,dtype=str(np.dtype(dtype)),kind='scalar',value=ai,seed=si,layout=layout,seed_layout='C'))
  for batch in [(3,),(2,3),(2,0)]:
   size=int(np.prod(batch));a=np.resize(np.array(values,dtype=dtype),size).reshape(*batch,1,1);g=np.resize(np.array(seeds,dtype=dtype),size).reshape(batch)
   for layout in ['C','F','S']:
    for seed_layout in ['C','F','S']:
     key=str(len(rows));arrays[key+'.a']=a;arrays[key+'.seed']=g;rows.append(dict(key=key,dtype=str(np.dtype(dtype)),kind='batch',layout=layout,seed_layout=seed_layout))
  for batch in [(0,),(2,0)]:
   for layout in ['C','factory']:
    key=str(len(rows));arrays[key+'.a']=np.empty((*batch,1,1),dtype=dtype);arrays[key+'.seed']=np.empty(batch,dtype=dtype);rows.append(dict(key=key,dtype=str(np.dtype(dtype)),kind='empty',layout=layout,seed_layout='C'))
assert len(rows)==398
np.savez_compressed(r/'singleton-inputs.npz',**arrays);(r/'singleton-inputs.json').write_text(json.dumps(dict(cases=rows,arrays=len(arrays)),indent=2)+'\n');print('Prepared',len(rows),'singleton controls,',len(arrays),'frozen arrays')
