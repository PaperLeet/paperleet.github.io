"""Verify complete selected-version reference, WASM and installed-package evidence."""
from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent;v=r/'selected-release'
read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
freeze=read(v/'source-freeze.json');source=freeze['source_hashes'];tests=freeze['test_hashes']
package=v/'snapshot/packages/stridetorch'
for key,directory in [('source_hashes','src/stridetorch'),('test_hashes','tests')]:
    for name,digest in freeze[key].items():assert sha(package/directory/name)==digest
for name,digest in freeze['package_hashes'].items():assert sha(package/name)==digest
assert freeze['version']=='0.72.0' and len(source)==61 and len(tests)==74
for name,count in [('prototype-proof',480),('advanced-proof',512),('default-model-proof',416),('model-math-controls',416)]:
    proof=read(v/'native-cpu'/name/'qualification.json')
    assert proof['source_hashes']==source and proof['status'].startswith('passed')
raw=read(v/'native-cpu/model-proof/qualification.json')
assert raw['source_hashes']==source and len(raw['failures'])==48
deps=read(v/'native-cpu/dependencies/dependencies-qualification.json')
assert deps['source_hashes']==source and not deps['failures'] and deps['counts']==dict(direct_native=408,independent_polynomial=40,explicit_unsupported=32)
for name in ['node-result.json','chrome-contracts/result.json']:
    proof=read(v/'wasm-proof'/name)
    assert proof['status']=='success' and proof['passed']==8710 and proof['suites']==73 and proof['library']=='0.72.0'
    assert proof['source_hashes']==source and proof['test_hashes']=={k:h for k,h in tests.items() if k!='test_standalone.py'}
    assert proof['pyodide']=='0.29.4' and proof['numpy']=='2.2.5' and not proof['failures']
for name in ['node-result.json','chrome/result.json']:
    proof=read(v/'numerical-wasm'/name)
    assert proof['status']=='success' and proof['cases']==2304 and not proof['failures'] and proof['source_hashes']==source
for base,name in [('native-cpu/legacy-hvp','result.json'),('legacy-hvp-wasm','node-result.json'),('legacy-hvp-wasm','chrome/result.json')]:
    proof=read(v/base/name)
    assert proof['status']=='success' and proof['cases']==720 and not proof['failures'] and proof['source_hashes']==source
    assert proof['direct_native_cases']==676 and len(proof['independent_precision_controls'])==4 and len(proof['polynomial_extension_controls'])==40
installed=read(v/'package-proof/package-identity.json')
assert installed['status']=='success' and installed['source_hashes']==source and installed['standalone_installed_tests']==8723
assert installed['python']=='3.10.19' and installed['numpy']=='1.26.4' and installed['native_torch'] is False
for name,digest in installed['artifacts'].items():assert sha(v/'package-proof'/name)==digest
assert '8723 passed' in (v/'package-proof/python310-stride072-tests.log').read_text()
assert 'fresh-process functional JVP operator restore' in (v/'package-proof/fresh-pickle-stridetorch.log').read_text()
assert 'fresh-process functional JVP operator restore' in (v/'package-proof/fresh-pickle-paperleet-_vendor-torch.log').read_text()
evidence={}
for q in v.rglob('*'):
    if not q.is_file() or any(part in ['snapshot','coinstall-env','python310-stride072-env','python310-stride072-tests','runtime','__pycache__'] for part in q.relative_to(v).parts):continue
    if q.suffix in ['.json','.log','.py','.mjs','.html','.whl','.gz'] and q.name!='core-and-package-proof.json':evidence[str(q.relative_to(v))]=sha(q)
result=dict(status='selected_version_cpu_native_wasm_and_package_passed',version='0.72.0',source_hashes=source,test_hashes=tests,
 minimum_installed_sdk_cases=8723,wasm_sdk_cases_per_runtime=8710,jvp_cases_per_runtime=2304,
 jvp_classification=dict(direct_native_qualified=2184,independent_math_controls=88,explicit_unsupported_hooks=32),
 legacy_hvp_cases_per_runtime=720,evidence_sha256=evidence,
 scope='Exact selected0.72 runtime,tests,README,wheel/sdist/private-wheel identities;CPU references,minimumNumPy-only SDK,Node/Chrome SDK,JVP inventories and legacy HVP fixtures. Performance,application validation and main adoption remain separate.')
(v/'core-and-package-proof.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],minimum_sdk=8723,wasm_sdk=8710,jvp=2304,legacy_hvp=720)))
