"""Check normalization JVP graph gradients against shift invariance and finite differences."""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np

r = Path(__file__).resolve().parent
adapter = '--adapter' in sys.argv
if adapter:
    sys.path.insert(0, str(r / 'candidate/packages/stridetorch/src'))
    from stridetorch import torch, __version__ as version
else:
    import torch
    version = torch.__version__

oracle = json.loads((r / 'native-model-functional-jvp-torch26.json').read_text())
rows = []
for case in ['layernorm', 'instancenorm_train', 'batchnorm_train']:
    fixture = next(row for row in oracle['rows'] if row['case'] == case and row['dtype'] == 'float64'
                   and not row['strict'] and not row['strided'] and not row['vector_grad'])
    arrays = [np.array(row['values'], dtype=np.float64) for row in fixture['fixture_inputs']]
    directions = [np.array(row['values'], dtype=np.float64) for row in fixture['fixture_vectors']]
    values = tuple(torch.tensor(value, dtype=torch.float64, requires_grad=True) for value in arrays)
    vectors = tuple(torch.tensor(value, dtype=torch.float64) for value in directions)
    x = values[0]
    masks = []
    if case == 'layernorm':
        function = lambda a, w, b: torch.nn.functional.layer_norm(a, (3,), w, b).square().sum()
        for n in range(arrays[0].shape[0]):
            mask = np.zeros_like(arrays[0]); mask[n] = 1; masks.append(mask)
    elif case == 'instancenorm_train':
        function = lambda a, w, b: torch.nn.functional.instance_norm(a, weight=w, bias=b).square().sum()
        for n in range(arrays[0].shape[0]):
            for c in range(arrays[0].shape[1]):
                mask = np.zeros_like(arrays[0]); mask[n, c] = 1; masks.append(mask)
    else:
        weight = torch.tensor(np.sin(np.arange(2) * .13) * .2, dtype=torch.float64, requires_grad=True)
        bias = torch.tensor(np.sin(np.arange(2) * .13 + 1) * .2, dtype=torch.float64, requires_grad=True)
        function = lambda a: torch.nn.functional.batch_norm(a, None, None, weight, bias, training=True).square().sum()
        for c in range(arrays[0].shape[1]):
            mask = np.zeros_like(arrays[0]); mask[:, c] = 1; masks.append(mask)
    _, tangent = torch.autograd.functional.jvp(function, values, vectors, create_graph=True)
    record = dict(case=case, dtype='float64', shape=list(x.shape), tangent=tangent.item())
    try:
        gradient = torch.autograd.grad(tangent, x)[0].detach().clone().numpy()
        record.update(reverse_status='success', reverse_gradient=gradient.tolist(),
                      reverse_group_sums=[float(np.sum(gradient * mask)) for mask in masks])
    except Exception as error:
        record.update(reverse_status='error', exception=type(error).__name__, message=str(error))
    epsilon = 1e-5
    differences = []
    for mask in masks:
        samples = []
        for sign in [-1, 1]:
            shifted = (torch.tensor(arrays[0] + sign * epsilon * mask, dtype=torch.float64),
                       *(item.detach() for item in values[1:]))
            _, product = torch.autograd.functional.jvp(function, shifted, vectors)
            samples.append(product.item())
        differences.append((samples[1] - samples[0]) / (2 * epsilon))
    record['finite_difference_group_sums'] = differences
    record['finite_difference_matches_shift_invariance'] = max(abs(value) for value in differences) < 1e-6
    record['reverse_matches_shift_invariance'] = (record['reverse_status'] == 'success'
        and max(abs(value) for value in record['reverse_group_sums']) < 1e-6)
    rows.append(record)
assert all(row['finite_difference_matches_shift_invariance'] for row in rows)
if adapter:
    assert all(row['reverse_matches_shift_invariance'] for row in rows)
print(json.dumps(dict(status='symmetry_audit', version=version, adapter=adapter, cases=3, rows=rows,
                      program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                      fixture_sha256=hashlib.sha256((r / 'native-model-functional-jvp-torch26.json').read_bytes()).hexdigest(),
                      scope='Three float64 normalization objectives, fixed fixtures/vectors. This checks '
                            'only constant-shift directional invariants using graph gradients and central '
                            'differences of independently re-evaluated JVP values; not full model qualification.'), indent=2))
