"""Freeze 20 released public API flows and seven qualified new JVP compositions."""
from pathlib import Path
import hashlib,json,shutil,subprocess

r=Path(__file__).resolve().parent;p=r/'performance';a=p/'assets';a.mkdir(parents=True)
repo=Path('/Users/david/Developer/PaperLeet-torch-release');old=r.parent/'torch-iteration-71/production-performance'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
manifest=lambda q:{f.name:sha(f) for f in q.iterdir() if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']}
freeze=json.loads((r/'selected-release/source-freeze.json').read_text())
assert not subprocess.check_output(['git','status','--porcelain','-z'],cwd=repo)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
for label,origin in [('baseline',repo/'packages/stridetorch/src/stridetorch'),
 ('jacobian_baseline',repo/'packages/stridetorch/src/stridetorch'),
 ('candidate',r/'selected-release/snapshot/packages/stridetorch/src/stridetorch')]:
    shutil.copytree(origin,a/label/'stridetorch',ignore=shutil.ignore_patterns('__pycache__'))
hashes={label:manifest(a/label/'stridetorch') for label in ['baseline','candidate','jacobian_baseline']};hashes['duplicate']=hashes['baseline']
assert hashes['candidate']==freeze['source_hashes'] and hashes['jacobian_baseline']==hashes['baseline']
for name,digest in hashes['baseline'].items():assert hashlib.sha256(subprocess.check_output(['git','show',head+':packages/stridetorch/src/stridetorch/'+name],cwd=repo)).hexdigest()==digest
prefix=(old/'assets/bench_vjp.py').read_text().split('\n_original_build=build')[0]
fragment=(r.parent/'torch-iteration-71/performance-fragment.py').read_text()
start=fragment.index(' def fn():\n  if candidate:return t.autograd.functional.hvp')
end=fragment.index(' def capture():',start)
fragment=fragment[:start]+''' def fn():
  return t.autograd.functional.hvp(callback,values,directions)
'''+fragment[end:]
needle='def run(baseline,candidate,jacobian_baseline,cycle,check_only=False):'
fragment=fragment.replace(needle,(r/'performance-jvp-factory.py').read_text()+'\n'+needle)
needle="hvp=(baseline,['hvp_scalar','hvp_linear','hvp_unused']))"
assert needle in fragment
fragment=fragment.replace(needle,"hvp=(baseline,['hvp_scalar','hvp_linear','hvp_unused']),functional_jvp=(baseline,['functional_jvp_scalar','functional_jvp_graph_scalar','functional_jvp_unused','functional_jvp_linear','functional_jvp_layernorm','functional_jvp_batchnorm','functional_jvp_instancenorm']))")
fragment=fragment.replace("family_order=list(itertools.permutations(families))[cycle%6]", "family_order=[('legacy','jacobian','hvp','functional_jvp'),('functional_jvp','hvp','jacobian','legacy'),('jacobian','functional_jvp','legacy','hvp'),('hvp','legacy','functional_jvp','jacobian'),('legacy','functional_jvp','hvp','jacobian'),('jacobian','hvp','functional_jvp','legacy')][cycle%6]")
fragment=fragment.replace("factory=build_jacobian if family=='jacobian' else build_hvp if family=='hvp' else build", "factory=build_jacobian if family=='jacobian' else build_hvp if family=='hvp' else build_functional_jvp if family=='functional_jvp' else build")
fragment=fragment.replace("'Validated released0.70 public AD composition; not a functional HVP API' if family=='hvp' else 'Released0.70 public API on both sides'", "'Qualified pure-callback composition of released0.71 public AD; not an existing functional JVP API' if family=='functional_jvp' else 'Released0.71 public API on both sides'")
fragment=fragment.replace('Seventeen released0.70 public API flows and three independently checked pure-callback HVP compositions.',
 'Twenty released0.71 public API flows and seven independently checked pure-callback JVP compositions.')
program=prefix+'\n'+fragment
program=program.replace('Matched public0.69/0.70 APIs and a separately labeled naive Jacobian prototype.',
 'Twenty public0.71API regression flows and seven qualified new functionalJVP workflows.')
compile(program,str(a/'bench_vjp.py'),'exec');(a/'bench_vjp.py').write_text(program)
plan=dict(source_hashes=hashes,programs={'bench_vjp.py':sha(a/'bench_vjp.py')},baseline_version='0.71.0',candidate_version='0.72.0',
 baseline_main=head,flows=27,legacy_public_flows=20,qualified_jvp_composition_flows=7,
 scope='20direct existing public APIs,7new JVP workflows against explicitly isolated public0.71AD compositions; all verified for these pure callbacks only.')
(a/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for name in ['bench-node.mjs','bench-chrome.mjs','assets/worker.mjs']:
    code=(old/name).read_text().replace('rows.length,20','rows.length,27').replace('/torch-iteration-71/production-performance/', '/torch-iteration-72/performance/')
    target=p/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(code)
shutil.copy2(old/'assets/index.html',a/'index.html')
code=(old/'run.py').read_text().replace('==20','==27').replace('range(20)','range(27)').replace('flows_per_child=20','flows_per_child=27').replace('FRESH20-FLOW','FRESH27-FLOW')
code=code.replace('Seventeen existing public0.70API flows (including publicVJP/Jacobian) and three analytically validated HVP compositions of released0.70 public AD primitives.',
 'Twenty existing public0.71API flows and seven independently checked pure-callback JVP compositions of released0.71 public AD primitives. The new functionalJVP API has no released0.71 counterpart.')
compile(code,str(p/'run.py'),'exec');(p/'run.py').write_text(code)
print('Prepared27flows,18fresh CPU/Node/Chrome processes,all6source loadorders,A/A controls; timing has not started')
