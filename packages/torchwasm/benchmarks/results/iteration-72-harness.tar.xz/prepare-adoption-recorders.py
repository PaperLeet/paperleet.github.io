"""Prepare checked commit/adoption recorders; this script never commits or pushes."""
from pathlib import Path
r=Path(__file__).resolve().parent;p=r/'final-integration';old=r.parent/'torch-iteration-71/final-integration'
for name in ['commit-local.py','record-adoption.py','commit-proof.py']:
    code=(old/name).read_text().replace('iteration-71','iteration-72').replace('0.71','0.72')
    if name=='commit-local.py':
        code=code.replace('len(expected)==195',"len(expected)==len(read(p/'owned-input-sha256.json'))+len(read(p/'new-assets-sha256.json'))+6")
        code=code.replace('add matrix-free HVP and differentiable curvature rules','add functional JVP and differentiable output graphs')
    if name=='record-adoption.py':
        code=code.replace('node_chrome_sdk_cases_each=8350','node_chrome_sdk_cases_each=8710')
        needle='direct_native_cases_each=676,independent_precision_controls_each=4,polynomial_extension_controls_each=40,'
        assert needle in code
        code=code.replace(needle,needle+'''
    node_chrome_jvp_inventory_cases_each=2304,jvp_direct_native_qualified_cases_each=2184,
    jvp_independent_math_controls_each=88,jvp_explicit_unsupported_hook_cases_each=32,
''')
    compile(code,str(p/name),'exec');(p/name).write_text(code)
print('Prepared0.72 exact-owned-path commits and guarded source/proof adoption recorders; no commit/push performed')
