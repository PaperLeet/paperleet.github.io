# Functional JVP candidate

This is an unreleased iteration-72 prototype in an isolated evaluation directory.
Its version literal remains `0.71.0`; it is not the adopted 0.71 release.
The application checkout and main have not been changed by this iteration.
The independent library name is still undecided; BrowserTorch is a suggestion.

## API and ownership

The candidate adds `torch.autograd.functional.jvp(func, inputs, v=None,
create_graph=False, strict=False)`. Inputs and outputs are a Tensor or a flat
tuple of Tensors. Inputs must be real float32/float64. Vectors must match their
corresponding input shapes and are converted to their input dtypes. An omitted
vector requires one input with one element. The callback is evaluated once.

By default both returned values are detached. With `create_graph=True`, callers
can differentiate the returned value and JVP using ordinary reverse queries.
Original input/vector gradient flags and existing gradient buffers are preserved;
the API does not run hooks on original arguments during its internal work.
Repeated arguments receive distinct callback objects. Captured original tensors
remain separate from those objects. `no_grad()`, detach, and forced NumPy exports
respect the validated reverse-based functional-JVP boundaries.

Strict mode checks both input and output Jacobian dependencies. It tracks private
vector leaves rather than testing numerical nonzero gradients, so zero directions
do not become unused inputs. In graph mode those private leaves cannot make a
constant Jacobian appear differentiable. Differentiable captured weights remain
valid dependencies. Empty sums and empty determinants have different strict
semantics; the candidate tests both.

This API does not enable `autograd.grad(create_graph=True)`, arbitrary higher-order
reverse graphs, complex differentiation, nested forward transforms, or unvalidated
operator JVP rules. Registering gradient hooks inside the callback raises an
explicit `BrowserUnsupported`; callbacks that alter reverse derivatives this way
are not silently evaluated with ordinary forward-mode semantics.

## Determinants and independent references

Default functional JVP now uses the determinant's cofactor direction at singular
matrices. The earlier prototype reused the ordinary saved-LU JVP path and could
return zero for a nonzero cofactor direction. Ordinary `torch.func.jvp` retains
its established behavior. HVP's empty-determinant independence is also preserved.

For empty determinants, graph mode retains native gradient metadata while reverse
queries return no gradient. The 1x1 determinant retains an exact symbolic zero
edge for its constant directional derivative.

Five small singular determinant families, in both FP32 and FP64, are checked with
an independent permutation-polynomial reference. Every matrix/vector coordinate
of both scalar outputs is additionally checked against fresh native Torch 2.6
FP64 functional-JVP values using two-step central differences and Richardson
extrapolation. Rounded FP32 fixtures are lifted to FP64 explicitly. Maximum
absolute derivative discrepancy in these controls is below 3.1e-11.

Native Torch 2.6's returned reverse graphs disagree with these mathematical
controls in 40 graph cases, including zero primal gradients or SVD-tape NaNs.
The candidate deliberately preserves mathematical cofactor/curvature derivatives
for these cases. Raw native disagreements are retained. This is a scoped
polynomial extension, not a claim of literal native graph equivalence.

The existing 48 normalization graph controls likewise retain their independent
complex-step and native finite-difference validation. No tolerances were widened
to turn the raw native comparisons into passes.

## Evidence and remaining gates

`dependency-revision/source-freeze.json` identifies the runtime, tests and package
metadata snapshot. The qualification receipt records the terminal CPU, Node and
Chrome results and their hashes. The numerical WASM replay compares all raw rows
against the separately qualified CPU inventories; it is not an additional
independent native oracle.

Earlier default-normalization timing/allocation measurements belong to the exact
pre-fix prototype identified in their own freezes. They have not been relabelled
as performance results for this revision.

Release selection/versioning, minimum-version installed-wheel checks, fresh
performance qualification, full application checks and guarded main adoption
remain separate gates. No CI, tag, release, publication or deployment was run.
