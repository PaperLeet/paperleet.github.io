"""Audit native JVP *values* with fresh FP64 finite differences of every coordinate."""
from pathlib import Path
import hashlib
import json
import numpy as np
import torch
from determinant_jvp_math_reference import fixture, reference

r = Path(__file__).resolve().parent
rows = []
for case in ['det_zero1', 'det_rank1_2', 'det_rank2_3', 'det_rank1_3', 'det_squared_rank1_2']:
    for dtype in ['float32', 'float64']:
        a, e = fixture(case, dtype)
        squared = case.startswith('det_squared')
        expected = reference(a, e, squared)

        def evaluate(matrix, vector):
            x = torch.tensor(matrix, dtype=torch.float64)
            v = torch.tensor(vector, dtype=torch.float64)
            def objective(value):
                d = torch.linalg.det(value)
                return d.square() if squared else d
            result = torch.autograd.functional.jvp(objective, x, v)
            return np.asarray([item.detach().clone().numpy().item() for item in result])

        values = evaluate(a, e)
        np.testing.assert_allclose(values, expected['values'], rtol=1e-8, atol=2e-10)
        derivatives = []
        errors = []
        for argument in [0, 1]:
            estimates = []
            for step in [1e-4, 5e-5]:
                gradients = np.empty((2,) + a.shape)
                for index in np.ndindex(a.shape):
                    plus, minus = [a.copy(), e.copy()], [a.copy(), e.copy()]
                    plus[argument][index] += step
                    minus[argument][index] -= step
                    gradients[(slice(None),) + index] = (evaluate(*plus) - evaluate(*minus)) / (2 * step)
                estimates.append(gradients)
            richardson = (4 * estimates[1] - estimates[0]) / 3
            target = np.stack([expected['primal_gradient'], expected['tangent_gradient']]) if argument == 0 else np.stack([np.zeros_like(a), expected['vector_gradient']])
            np.testing.assert_allclose(richardson, target, rtol=1e-8, atol=2e-9)
            errors.append(float(np.max(np.abs(richardson - target))))
            derivatives.append(dict(steps=[1e-4, 5e-5], raw=[item.tolist() for item in estimates],
                                    richardson=richardson.tolist(), expected=target.tolist()))
        rows.append(dict(case=case, dtype=dtype, matrix=a.tolist(), vector=e.tolist(),
                         values=values.tolist(), references={key:np.asarray(value).tolist() for key,value in expected.items()},
                         coordinate_audits=derivatives, max_absolute_error=max(errors)))

result = dict(status='validated', cases=len(rows), native_version=torch.__version__,
              native_git=torch.version.git_version, rows=rows,
              scope='Rounded FP32 fixtures lifted to FP64 and FP64 fixtures. Fresh native functional JVP values; '
                    'two-step central/Richardson differences independently verify both reverse channels for all input/vector coordinates.',
              source_hashes={name:hashlib.sha256((r/name).read_bytes()).hexdigest() for name in
                             ['determinant_jvp_math_reference.py', Path(__file__).name, 'probe-functional-jvp-dependencies.py']})
print(json.dumps(result, indent=2))
