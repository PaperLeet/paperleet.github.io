import fs from 'node:fs';
import assert from 'node:assert/strict';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const repo='/Users/david/Developer/PaperLeet-torch-release';
const plan=JSON.parse(fs.readFileSync(new URL('./plan.json',import.meta.url)));
const py=await loadPyodide({indexURL:repo+'/web/node_modules/pyodide/',packageCacheDir:repo+'/web/public/browser-runtime/pyodide-0.29.4/',stdout:console.log,stderr:console.error});
await loadJudgePackages(py,[]);
for(const [folder,manifest] of [['stridetorch',plan.source],['fixtures',plan.fixtures]]){
 py.FS.mkdirTree('/runtime/'+folder);
 for(const name of Object.keys(manifest))py.FS.writeFile('/runtime/'+folder+'/'+name,fs.readFileSync(new URL('./'+(folder==='stridetorch'?'source':'fixtures')+'/'+name,import.meta.url)));
}
py.globals.set('plan_json',JSON.stringify(plan));
const result=JSON.parse(py.runPython(fs.readFileSync(new URL('./replay.py',import.meta.url),'utf8')));
result.pyodide=py.version;result.node=process.version;
fs.writeFileSync(new URL('./node-result.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({status:result.status,cases:result.cases,counts:result.counts,failures:result.failures.length}));
assert.equal(result.status,'success');assert.equal(result.cases,2304);
