import {loadJudgePackages} from '../../../../extraction-browser/packages.mjs';
self.onmessage=async()=>{try{
 const plan=await(await fetch('../plan.json')).json();
 const {loadPyodide}=await import('../../../../runtime-0.29.4/pyodide.mjs');
 const py=await loadPyodide({indexURL:new URL('../../../../runtime-0.29.4/',self.location.href).href,stdout:()=>{},stderr:()=>{}});
 await loadJudgePackages(py,[]);
 for(const [folder,manifest] of [['stridetorch',plan.source],['fixtures',plan.fixtures]]){
  py.FS.mkdirTree('/runtime/'+folder);
  for(const name of Object.keys(manifest))py.FS.writeFile('/runtime/'+folder+'/'+name,await(await fetch('../'+(folder==='stridetorch'?'source':'fixtures')+'/'+name)).text());
 }
 py.globals.set('plan_json',JSON.stringify(plan));
 const result=JSON.parse(py.runPython(await(await fetch('../replay.py')).text()));
 self.postMessage({...result,pyodide:py.version});
}catch(error){self.postMessage({error:String(error.stack||error)});}};
