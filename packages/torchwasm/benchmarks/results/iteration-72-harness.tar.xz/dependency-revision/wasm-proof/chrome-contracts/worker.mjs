import {loadJudgePackages} from '../../../../extraction-browser/packages.mjs';
self.onmessage=async()=>{
 const output=[];
 try{
  const plan=await(await fetch('./plan.json')).json();
  const {loadPyodide}=await import('../../../../runtime-0.29.4/pyodide.mjs');
  const py=await loadPyodide({indexURL:new URL('../../../../runtime-0.29.4/',self.location.href).href,
   stdout:value=>output.push(value),stderr:value=>output.push(value)});
  await loadJudgePackages(py,[]);py.FS.mkdirTree('/runtime/stridetorch');
  for(const name of Object.keys(plan.source))py.FS.writeFile('/runtime/stridetorch/'+name,await(await fetch('./source/'+name)).text());
  for(const name of Object.keys(plan.tests))py.FS.writeFile('/runtime/'+name,await(await fetch('./tests/'+name)).text());
  py.globals.set('plan_json',JSON.stringify(plan));
  const report=JSON.parse(py.runPython(await(await fetch('../sdk.py')).text()));
  self.postMessage({...report,pyodide:py.version,output});
 }catch(error){self.postMessage({error:String(error.stack||error),output});}
};
