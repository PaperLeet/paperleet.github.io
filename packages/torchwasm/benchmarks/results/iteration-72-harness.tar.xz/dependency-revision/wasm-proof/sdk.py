import sys,json,pathlib,hashlib
sys.path.insert(0,'/runtime')
plan=json.loads(plan_json)
actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path('/runtime/stridetorch').iterdir() if p.is_file()}
assert actual==plan['source']
for name,expected in plan['tests'].items():assert hashlib.sha256(pathlib.Path('/runtime',name).read_bytes()).hexdigest()==expected
import pytest,stridetorch,numpy
assert stridetorch.__version__==plan['version']
class Record:
    passed=0
    failures=[]
    def pytest_runtest_logreport(self,report):
        if report.when=='call' and report.passed:self.passed+=1
        if report.failed:self.failures.append(dict(test=report.nodeid,phase=report.when,error=str(report.longrepr)))
record=Record()
code=pytest.main(['/runtime/'+name for name in plan['tests']]+['-q','--noconftest','-p','no:cacheprovider','--import-mode=importlib'],plugins=[record])
json.dumps(dict(status='success' if int(code)==0 and record.passed==plan['expected'] else 'failed',exit_code=int(code),
    library=stridetorch.__version__,prototype_iteration=plan['prototype_iteration'],numpy=numpy.__version__,python=sys.version.split()[0],
    passed=record.passed,failures=record.failures,source_hashes=actual,test_hashes=plan['tests'],suites=len(plan['tests'])))
