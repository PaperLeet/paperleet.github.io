"""Native HVP boundary inventory; no adapter implementation is asserted."""
import inspect, json
from pathlib import Path
from stridetorch import torch, __version__ as library_version

def record(value):
    if isinstance(value, tuple): return [record(v) for v in value]
    return dict(shape=list(value.shape),dtype=str(value.dtype).split('.')[-1],
                requires_grad=value.requires_grad,values=value.detach().numpy().tolist())

rows=[]
cases=['quadratic','cubic','linear','constant','unused_input','mixed_inputs',
       'captured_original','one_element_output','non_scalar_output','tuple_output',
       'numpy_escape','force_numpy','empty_input','implicit_seed','missing_seed','wrong_seed']
for dtype in [torch.float32,torch.float64]:
    for strict in [False,True]:
        for original_grad in [False,True]:
            for case in cases:
                x=torch.tensor([.2,.7],dtype=dtype,requires_grad=original_grad)
                if case=='empty_input':x=torch.empty(0,dtype=dtype,requires_grad=original_grad)
                if case=='implicit_seed':x=torch.tensor([.2],dtype=dtype,requires_grad=original_grad)
                x.grad=torch.ones_like(x)*3;buffer=x.grad;before=x.detach().clone();grad_before=x.grad.clone()
                inputs=x;seed=torch.ones_like(x,dtype=torch.float64 if dtype==torch.float32 else torch.float32)*.3
                if case in ['implicit_seed','missing_seed']:seed=None
                if case=='wrong_seed':seed=torch.ones(3,dtype=dtype)
                if case=='quadratic':fn=lambda a:a.square().sum()
                elif case=='cubic':fn=lambda a:a.pow(3).sum()
                elif case in ['linear','empty_input']:fn=lambda a:a.sum()
                elif case=='constant':fn=lambda a:torch.tensor(2.,dtype=dtype)
                elif case=='unused_input':
                    y=torch.tensor([.4,.9],dtype=dtype);inputs=(x,y);seed=(seed,torch.ones_like(y));fn=lambda a,b:a.square().sum()
                elif case=='mixed_inputs':
                    y=torch.tensor([.4,.9],dtype=dtype);inputs=(x,y);seed=(seed,torch.ones_like(y));fn=lambda a,b:(a*b+a.pow(3)).sum()
                elif case=='captured_original':fn=lambda a:(a.pow(3)+x.square()).sum()
                elif case=='one_element_output':fn=lambda a:a.square().sum().reshape(1)
                elif case=='non_scalar_output':fn=lambda a:a.square()
                elif case=='tuple_output':fn=lambda a:(a.square().sum(),)
                elif case=='numpy_escape':fn=lambda a:torch.from_numpy(a.numpy()).sum()
                elif case=='force_numpy':fn=lambda a:torch.from_numpy(a.numpy(force=True)).sum()
                else:fn=lambda a:a.sin().sum()
                calls=[];hooks=[]
                handle=x.register_hook(lambda g:hooks.append(g)) if original_grad else None
                def callback(*args):
                    calls.append(torch.is_grad_enabled())
                    return fn(*args)
                row=dict(case=case,dtype=str(dtype).split('.')[-1],strict=strict,original_grad=original_grad)
                try:
                    with torch.no_grad():
                        result=torch.autograd.functional.hvp(callback,inputs,seed,strict=strict)
                        assert not torch.is_grad_enabled()
                    row.update(status='success',result=record(result))
                except Exception as error:row.update(status='error',exception=type(error).__name__,message=str(error))
                row.update(calls=calls,hooks=len(hooks),caller_preserved=bool(x.requires_grad==original_grad and x.grad is buffer and torch.equal(x.detach(),before) and torch.equal(x.grad,grad_before)))
                assert row['caller_preserved'] and not hooks
                if handle:handle.remove()
                rows.append(row)
print(json.dumps(dict(torch=library_version,native_git='adapter-not-native',cases=len(rows),rows=rows),allow_nan=False,indent=2))
