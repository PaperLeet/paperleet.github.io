"""Small independent polynomial-minor witness for native SVD-tape NaNs."""
import numpy as np

def _minor(a,i,j):return np.delete(np.delete(a,i,axis=0),j,axis=1)

def reference(inputs,vectors,squared):
    assert len(inputs)==len(vectors)==1
    assert len(inputs[0]['shape'])==2
    a=np.asarray(inputs[0]['values'],dtype=np.float64).reshape(inputs[0]['shape'])
    e=np.asarray(vectors[0]['values'],dtype=np.float64).reshape(vectors[0]['shape'])
    assert a.shape==e.shape and a.shape[0]==a.shape[1] and 2<=len(a)<=3
    assert np.isfinite(a).all() and np.isfinite(e).all()
    c=np.empty_like(a);h=np.empty_like(a);n=len(a)
    for i in range(n):
        for j in range(n):
            block=_minor(a,i,j);direction=_minor(e,i,j)
            c[i,j]=(-1.)**(i+j)*np.linalg.det(block)
            value=0.
            for k in range(n-1):
                for l in range(n-1):value+=(-1.)**(i+j+k+l)*np.linalg.det(_minor(block,k,l))*direction[k,l]
            h[i,j]=value
    return 2*np.sum(c*e)*c+2*np.linalg.det(a)*h if squared else h
