"""Prepare final-version CPU/native and actual WASM qualification without reusing prototype claims."""
from pathlib import Path
import hashlib,json,shutil

r=Path(__file__).resolve().parent;v=r/'selected-release';c=v/'native-cpu';c.mkdir()
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
freeze=json.loads((v/'source-freeze.json').read_text())
directories=['prototype-proof','advanced-proof','default-model-proof','model-proof','model-math-controls']
jobs=[]
for name,expected in [('qualify-functional-jvp.py',0),('qualify-functional-jvp-advanced.py',0),
 ('qualify-model-functional-jvp-default.py',0),('qualify-model-functional-jvp.py',1),
 ('qualify-normalization-math-controls.py',0),('qualify-functional-jvp-dependencies.py',0)]:
    code=(r/name).read_text().replace('candidate/packages/stridetorch','selected-release/snapshot/packages/stridetorch')
    for directory in directories:code=code.replace("'"+directory,"'selected-release/native-cpu/"+directory)
    code=code.replace("'dependency-revision'","'selected-release/native-cpu/dependencies'")
    code=code.replace('p.mkdir(exist_ok=True)','p.mkdir(parents=True,exist_ok=True)')
    target=r/('selected-'+name);target.write_text(code);jobs.append((name,target.name,expected))
code=(r/'replay-legacy-hvp-cpu.py').read_text().replace("r / 'legacy-hvp-cpu'","r / 'selected-release/native-cpu/legacy-hvp'").replace(
 "r/'optimized-prototype-freeze.json'","r/'selected-release/source-freeze.json'").replace('candidate/packages/stridetorch','selected-release/snapshot/packages/stridetorch').replace('0.71.0','0.72.0')
(r/'selected-replay-legacy-hvp.py').write_text(code);jobs.append(('legacy-hvp','selected-replay-legacy-hvp.py',0))
(c/'jobs.json').write_text(json.dumps(jobs,indent=2)+'\n')
old=r/'dependency-revision/wasm-proof';w=v/'wasm-proof';b=w/'chrome-contracts';b.mkdir(parents=True)
for name in ['node.mjs','sdk.py']:shutil.copy2(old/name,w/name)
for name in ['worker.mjs','index.html']:shutil.copy2(old/'chrome-contracts'/name,b/name)
driver=(old/'chrome-contracts/run.mjs').read_text().replace('/torch-iteration-72/dependency-revision/wasm-proof/', '/torch-iteration-72/selected-release/wasm-proof/')
(b/'run.mjs').write_text(driver)
for directory,manifest,origin in [('source',freeze['source_hashes'],v/'snapshot/packages/stridetorch/src/stridetorch'),
 ('tests',{k:h for k,h in freeze['test_hashes'].items() if k!='test_standalone.py'},v/'snapshot/packages/stridetorch/tests')]:
    (b/directory).mkdir()
    for name,digest in manifest.items():assert sha(origin/name)==digest;shutil.copy2(origin/name,b/directory/name)
plan=dict(source=freeze['source_hashes'],tests={k:h for k,h in freeze['test_hashes'].items() if k!='test_standalone.py'},
 version='0.72.0',prototype_iteration=72,expected=8710,scope='Selected final-version0.72 candidate full SDK; native references,packaging,performance and app qualification are separate.')
(b/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
code=(r/'prepare-functional-jvp-numerical-wasm.py').read_text().replace('dependency-revision/numerical-wasm','selected-release/numerical-wasm').replace(
 'dependency-revision/source-freeze.json','selected-release/source-freeze.json').replace('dependency-revision/snapshot','selected-release/snapshot').replace(
 "r/'dependency-revision'/directory","r/'selected-release/native-cpu'/directory").replace(
 'dependency-revision/candidate-dependencies.json','selected-release/native-cpu/dependencies/candidate-dependencies.json').replace(
 'dependency-revision/dependencies-qualification.json','selected-release/native-cpu/dependencies/dependencies-qualification.json').replace("version='0.71.0'","version='0.72.0'")
(r/'prepare-selected-numerical-wasm.py').write_text(code)
old=r.parent/'torch-iteration-71/production-release/native-wasm-proof';w=v/'legacy-hvp-wasm';w.mkdir()
plan=json.loads((old/'plan.json').read_text());plan['source']=freeze['source_hashes'];plan['version']='0.72.0'
shutil.copytree(old/'fixtures',w/'fixtures');shutil.copytree(b/'source',w/'source')
for name,digest in plan['fixtures'].items():assert sha(w/'fixtures'/name)==digest
for name in ['node.mjs','replay.py']:(w/name).write_text((old/name).read_text().replace('0.71.0','0.72.0'))
(w/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
shutil.copytree(old/'chrome',w/'chrome',ignore=shutil.ignore_patterns('result.json'))
q=w/'chrome/run.mjs';q.write_text(q.read_text().replace('0.71.0','0.72.0').replace('/torch-iteration-71/production-release/native-wasm-proof/', '/torch-iteration-72/selected-release/legacy-hvp-wasm/'))
print('Prepared selected0.72 CPU/native,SDK8710,andlegacy720 harnesses; numerical WASM setup follows CPU qualification')
