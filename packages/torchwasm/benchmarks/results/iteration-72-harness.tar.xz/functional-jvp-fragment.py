def functional_jvp(func, inputs, v=None, create_graph=False, strict=False):
    """Functional JVP with isolated arguments and optional differentiable results."""
    if _state._jvp_active:
        raise _errors.BrowserUnsupported('Functional JVP inside forward AD is unsupported')

    def tensors(value, name):
        was_tuple = isinstance(value, tuple)
        values = value if was_tuple else (value,)
        if any(not isinstance(item, _tensor.Tensor) for item in values):
            raise TypeError(name + ' must be a Tensor or a tuple of Tensors')
        return values, was_tuple

    def prepare(item, need_graph):
        if create_graph and item.requires_grad:
            return item.view_as(item)
        return item.detach().requires_grad_(need_graph)

    with enable_grad():
        original, _ = tensors(inputs, 'inputs')
        if any(isinstance(item, ForwardTensor) or item.dtype not in (np.dtype('float32'), np.dtype('float64'))
               for item in original):
            raise _errors.BrowserUnsupported('Functional JVP requires real float32/float64 inputs')
        arguments = tuple(prepare(item, True) for item in original)
        if v is None:
            if len(arguments) != 1 or arguments[0].numel() != 1:
                raise RuntimeError('Implicit JVP vectors require one input with one element')
            seeds = (_tensor.Tensor(np.ones_like(arguments[0]._data)),)
        else:
            vectors, _ = tensors(v, 'v')
            if len(vectors) != len(arguments) or any(a.shape != b.shape for a, b in zip(arguments, vectors)):
                raise RuntimeError('JVP vector shapes must match the inputs')
            if any(isinstance(item, ForwardTensor) or item.dtype.kind == 'c' for item in vectors):
                raise _errors.BrowserUnsupported('Complex or forward-AD JVP vectors are unsupported')
            seeds = tuple(prepare(item, False).to(dtype=argument.dtype)
                          for item, argument in zip(vectors, arguments))
        previous = _state._functional_ad_active
        previous_jvp = _state._functional_jvp_active
        _state._functional_ad_active = True
        _state._functional_jvp_active = True
        try:
            if arguments:
                output, tangent = jvp(func, arguments, seeds)
            else:
                output = func()
                values, was_tuple = tensors(output, 'outputs')
                if any(item.requires_grad for item in values):
                    # Match the production Torch 2.6 empty-input boundary.
                    raise ValueError('Functional JVP requires nonempty differentiation inputs')
                zeros = tuple(_tensor.Tensor(np.zeros_like(item._data)) for item in values)
                tangent = zeros if was_tuple else zeros[0]
        finally:
            _state._functional_ad_active = previous
            _state._functional_jvp_active = previous_jvp
        outputs, output_tuple = tensors(output, 'outputs')
        tangents, _ = tensors(tangent, 'JVP outputs')
        if not outputs:
            raise IndexError('Empty functional JVP output tuple')
        if strict:
            if any(not item.requires_grad for item in outputs):
                raise RuntimeError('A functional JVP output does not require gradients in strict mode')
            gradients = autograd_grad(outputs, arguments,
                                      tuple(_tensor.Tensor(np.ones_like(item._data)) for item in outputs),
                                      retain_graph=True, allow_unused=True)
            if any(item is None for item in gradients):
                raise RuntimeError('A functional JVP input is independent of all outputs in strict mode')
            if create_graph and any(not item.requires_grad for item in tangents):
                raise RuntimeError('A functional JVP derivative is constant in strict graph mode')
        if not create_graph:
            outputs = tuple(item.detach() for item in outputs)
            tangents = tuple(item.detach() for item in tangents)
        return (outputs if output_tuple else outputs[0], tangents if output_tuple else tangents[0])


