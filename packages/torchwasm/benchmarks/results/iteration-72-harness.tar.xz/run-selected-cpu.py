"""Run all selected-source CPU reference checks, retaining expected native disagreements."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
r=Path(__file__).resolve().parent;v=r/'selected-release';p=v/'native-cpu'
freeze=json.loads((v/'source-freeze.json').read_text());receipts=[]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
for label,name,expected in json.loads((p/'jobs.json').read_text()):
    for filename,digest in freeze['source_hashes'].items():assert sha(v/'snapshot/packages/stridetorch/src/stridetorch'/filename)==digest
    start=time.monotonic()
    with (p/(label+'.log')).open('w') as output:
        child=subprocess.run([sys.executable,str(r/name)],cwd=r,env=env,stdout=output,stderr=subprocess.STDOUT)
    receipts.append(dict(label=label,exit_code=child.returncode,expected_exit_code=expected,seconds=time.monotonic()-start,log_sha256=sha(p/(label+'.log'))))
    (p/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
    assert child.returncode==expected,label
    if expected:
        raw=json.loads((p/'model-proof/qualification.json').read_text())
        assert len(raw['failures'])==48 and {x['case'] for x in raw['failures']}=={'layernorm','instancenorm_train','batchnorm_train'}
    print(label,'TERMINAL',child.returncode,flush=True)
print('Selected0.72 CPU JVP2304 andlegacyHVP720 checks passed with explicit mathematical/unsupported boundaries',flush=True)
