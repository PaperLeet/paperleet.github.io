"""Close the exact isolated prototype qualification without changing the application."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

r=Path(__file__).resolve().parent
p=r/'dependency-revision'
repo=Path('/Users/david/Developer/PaperLeet-torch-release')
read=lambda q:json.loads(q.read_text())
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
freeze=read(p/'source-freeze.json')
for root in [r/'candidate/packages/stridetorch',p/'snapshot/packages/stridetorch']:
    for key,directory in [('source_hashes','src/stridetorch'),('test_hashes','tests')]:
        assert all(sha(root/directory/name)==digest for name,digest in freeze[key].items())
assert '8723 passed, 1 warning' in (p/'sdk.log').read_text()
assert '181 passed' in (p/'focused-sdk.log').read_text()
for name in ['prototype-proof','advanced-proof','default-model-proof','model-math-controls']:
    proof=read(p/name/'qualification.json')
    assert proof['source_hashes']==freeze['source_hashes']
    assert proof['status'].startswith('passed')
raw=read(p/'model-proof/qualification.json')
assert raw['source_hashes']==freeze['source_hashes'] and len(raw['failures'])==48
deps=read(p/'dependencies-qualification.json')
assert deps['source_hashes']==freeze['source_hashes'] and not deps['failures']
assert deps['counts']==dict(direct_native=408,independent_polynomial=40,explicit_unsupported=32)
checks={}
for label,path in [('node-sdk','wasm-proof/node-result.json'),('chrome-sdk','wasm-proof/chrome-contracts/result.json')]:
    result=read(p/path)
    assert result['status']=='success' and result['exit_code']==0 and not result['failures']
    assert result['passed']==8710 and result['suites']==73
    assert result['source_hashes']==freeze['source_hashes']
    assert result['test_hashes']=={k:v for k,v in freeze['test_hashes'].items() if k!='test_standalone.py'}
    assert result['pyodide']=='0.29.4' and result['numpy']=='2.2.5'
    checks[label]=dict(path=path,sha256=sha(p/path),passed=8710,suites=73,
                       runtime=result.get('node',result.get('browser')))
for label,path in [('node-jvp','numerical-wasm/node-result.json'),('chrome-jvp','numerical-wasm/chrome/result.json')]:
    result=read(p/path)
    assert result['status']=='success' and result['cases']==2304 and not result['failures']
    assert result['source_hashes']==freeze['source_hashes'] and result['pyodide']=='0.29.4'
    checks[label]=dict(path=path,sha256=sha(p/path),cases=2304,
                       scope='CPU inventory replay:2184 direct-native-qualified,88 independently controlled,32 explicitly unsupported hook cases.')
for label,path in [('cpu-legacy-hvp','legacy-hvp-cpu/result.json'),
                   ('node-legacy-hvp','legacy-hvp-wasm/node-result.json'),
                   ('chrome-legacy-hvp','legacy-hvp-wasm/chrome/result.json')]:
    result=read(p/path)
    assert result['status']=='success' and result['cases']==720 and not result['failures']
    assert result['source_hashes']==freeze['source_hashes'] and result['direct_native_cases']==676
    assert len(result['independent_precision_controls'])==4 and len(result['polynomial_extension_controls'])==40
    checks[label]=dict(path=path,sha256=sha(p/path),cases=720,direct_native=676,precision=4,polynomial=40)
controls=read(r/'determinant-jvp-polynomial-controls.json')
assert controls['status']=='validated' and controls['cases']==10
for name,digest in controls['source_hashes'].items():assert sha(r/name)==digest
assert max(row['max_absolute_error'] for row in controls['rows'])<3.1e-11
git=lambda *args:subprocess.check_output(['/usr/bin/git',*args],cwd=repo)
assert git('status','--porcelain=v1','-z')==b''
local=git('rev-parse','HEAD').decode().strip()
remote=git('rev-parse','FETCH_HEAD').decode().strip()
assert local=='821c1b39c6e2583bb57cb517265f5c19ed94c701'
assert remote=='096e3ec42c82de5e202bd0691aef7948f2bc7f7f'
assert git('rev-parse',local+':packages/stridetorch')==git('rev-parse',remote+':packages/stridetorch')
assert git('diff','--name-only',local,remote,'--','.github/workflows')==b''
evidence={}
for q in p.rglob('*'):
    if not q.is_file() or any(part in ['snapshot','sdk-pytest-tmp','__pycache__','runtime'] for part in q.relative_to(p).parts):continue
    if q.name=='qualification.json' and q.parent==p:continue
    if q.suffix in ['.json','.log','.py','.mjs','.html']:evidence[str(q.relative_to(r))]=sha(q)
for name in ['probe-functional-jvp-dependencies.py','qualify-functional-jvp-dependencies.py',
             'determinant_jvp_math_reference.py','probe-determinant-jvp-polynomial-controls.py',
             'determinant-jvp-polynomial-controls.json','dependency-initial-comparison.json',
             'dependency-after-comparison.json','candidate-functional-jvp-dependencies-before.json',
             'candidate-functional-jvp-dependencies-after.json','native-functional-jvp-dependencies.json',
             'functional-jvp-candidate-notes.md',Path(__file__).name]:evidence[name]=sha(r/name)
result=dict(status='isolated_cpu_node_chrome_qualification_passed',prototype_iteration=72,
            version_literal='0.71.0',source_hashes=freeze['source_hashes'],test_hashes=freeze['test_hashes'],
            cpu_sdk_cases=8723,wasm_sdk_cases_per_runtime=8710,jvp_inventory_cases_per_runtime=2304,
            jvp_inventory_classification=dict(direct_native_qualified=2184,independent_math=88,explicit_unsupported=32),
            legacy_hvp_cases_per_runtime=720,checks=checks,evidence_sha256=evidence,
            preserved_failures=dict(initial_dependency_mismatches=164,first_revision_mismatches=80,
                                    raw_normalization_graph_mismatches=48,
                                    note='All raw inventories retained. An initial test-only import collection error was corrected to use the existing private BrowserUnsupported definition.'),
            application=dict(local_head=local,last_observed_remote_main=remote,working_tree_clean=True,
                             package_subtree_identical=True,workflow_files_identical=True,
                             external_main_changes='23 application/UI/docs files; retained, no checkout/reset/cherry-pick.'),
            remaining_gates=['release version selection and documentation','minimum-version installed-wheel/package checks',
                             'fresh performance qualification','full current-main application checks','guarded main adoption'],
            limitations=['Callback gradient hook registration explicitly unsupported.',
                         'No arbitrary higher-order reverse AD, nested forward transforms or general complex AD.',
                         '88 JVP cases use explicit independent mathematical controls; not literal native graph equivalence.',
                         'Previous optimization performance evidence belongs to its original source freeze.',
                         'No new GPU backend enabled.'],
            goal_status='active',previous_turn_classification='no engineering progress in the naming-only response; current turn completed source fixes and qualification',
            scope='Unreleased isolated prototype. No application source change, push, CI, tag, release, publication or deployment.')
(p/'qualification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:result[key] for key in ['status','cpu_sdk_cases','wasm_sdk_cases_per_runtime','jvp_inventory_cases_per_runtime','legacy_hvp_cases_per_runtime','goal_status']}))
