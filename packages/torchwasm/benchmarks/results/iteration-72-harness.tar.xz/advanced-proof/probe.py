"""Native mixed-gradient-mode, alias, output structure and reverse-channel inventory."""
from pathlib import Path
import hashlib
import itertools
import json
from stridetorch import torch, __version__ as library_version

def record(value):
    if value is None: return None
    if isinstance(value, tuple): return [record(item) for item in value]
    return dict(shape=list(value.shape), dtype=str(value.dtype).split('.')[-1],
                requires_grad=value.requires_grad, values=value.detach().clone().numpy().tolist())

cases = ['mixed_no_grad', 'no_grad_view', 'mixed_no_grad_view', 'no_grad_identity',
         'numpy_force', 'capture_only', 'unused_second_input', 'tuple_constant',
         'empty_tuple_output', 'list_output', 'dictionary_output', 'callback_error',
         'duplicate_tuple_outputs', 'repeated_inputs', 'mixed_grad_modes', 'no_grad_then_detach']
rows = []
for dtype, gx, gv, graph, strict, case in itertools.product(
        [torch.float32, torch.float64], [False, True], [False, True],
        [False, True], [False, True], cases):
    x = torch.tensor([-.4, .2], dtype=dtype, requires_grad=gx)
    y = torch.tensor([.5, .9], dtype=dtype, requires_grad=gx)
    v = torch.tensor([.7, -.3], dtype=dtype, requires_grad=gv)
    w = torch.tensor([-.2, .6], dtype=dtype, requires_grad=gv)
    originals = (x, y, v, w)
    for item in originals: item.grad = torch.full_like(item, 17.)
    buffers = tuple(item.grad for item in originals)
    hooks = []
    handles = [item.register_hook(lambda gradient, index=index: hooks.append(index))
               for index, item in enumerate(originals) if item.requires_grad]
    calls = []
    def function(*arguments):
        calls.append(dict(distinct=len({id(item) for item in arguments}) == len(arguments),
                          flags=[item.requires_grad for item in arguments],
                          leaves=[item.is_leaf for item in arguments]))
        a = arguments[0]
        if case == 'mixed_no_grad':
            with torch.no_grad(): frozen = a.square()
            return a + frozen
        if case == 'no_grad_view':
            with torch.no_grad(): return a.view_as(a)
        if case == 'mixed_no_grad_view':
            with torch.no_grad(): frozen = a.view_as(a)
            return a.sin() + frozen
        if case == 'no_grad_identity':
            with torch.no_grad(): return a
        if case == 'numpy_force': return torch.from_numpy(a.numpy(force=True)).square()
        if case == 'capture_only': return x.square()
        if case == 'unused_second_input': return a.sin()
        if case == 'tuple_constant': return a.sin(), torch.ones_like(a)
        if case == 'empty_tuple_output': return ()
        if case == 'list_output': return [a.sin()]
        if case == 'dictionary_output': return {'output': a.sin()}
        if case == 'callback_error': raise ValueError('intentional callback error')
        if case == 'duplicate_tuple_outputs':
            output = a.sin()
            return output, output
        if case == 'repeated_inputs': return a * arguments[1]
        if case == 'mixed_grad_modes':
            with torch.no_grad():
                frozen = a.square()
                with torch.enable_grad(): live = a.sin()
            return frozen + live
        with torch.no_grad(): frozen = a.view_as(a)
        return frozen.detach()
    inputs, vectors = (x, y) if case == 'unused_second_input' else (x, x) if case == 'repeated_inputs' else x, (v, w) if case in ['unused_second_input', 'repeated_inputs'] else v
    row = dict(case=case, dtype=str(dtype).split('.')[-1], gx=gx, gv=gv,
               create_graph=graph, strict=strict)
    try:
        with torch.no_grad():
            output, product = torch.autograd.functional.jvp(function, inputs, vectors,
                                                            create_graph=graph, strict=strict)
            assert not torch.is_grad_enabled()
        row.update(status='success', result=record((output, product)))
    except Exception as error:
        row.update(status='error', exception=type(error).__name__, message=str(error))
    row.update(callbacks=calls, api_original_hooks=list(hooks),
               api_buffers_preserved=all(item.grad is buffer for item, buffer in zip(originals, buffers)))
    with torch.no_grad():
        _, after = torch.func.jvp(lambda a: a.square(), (x,), (v,))
    row['post_transform_no_grad_direction'] = record(after)
    assert torch.is_grad_enabled()
    active = tuple(item for item in originals if item.requires_grad)
    active_names = [name for name, item in zip(['x', 'y', 'v', 'w'], originals) if item.requires_grad]
    if row['status'] == 'success':
        channels = []
        for component in [output, product]:
            outputs = component if isinstance(component, tuple) else (component,)
            live = tuple(item for item in outputs if item.requires_grad)
            try:
                gradients = torch.autograd.grad(live, active, tuple(torch.ones_like(item) for item in live),
                                                allow_unused=True, retain_graph=True) if live and active else (None,) * len(active)
                channels.append(dict(status='success', names=active_names, gradients=record(gradients)))
            except Exception as error:
                channels.append(dict(status='error', exception=type(error).__name__, message=str(error)))
        row['reverse_channels'] = channels
    row['reverse_hook_counts'] = {str(index): hooks.count(index) for index, item in enumerate(originals) if item.requires_grad}
    row['caller_preserved'] = (all(item.grad is buffer and item.grad.tolist() == [17., 17.]
                                   for item, buffer in zip(originals, buffers))
        and [item.requires_grad for item in originals] == [gx, gx, gv, gv]
        and x.detach().tolist() == torch.tensor([-.4, .2], dtype=dtype).tolist())
    for handle in handles: handle.remove()
    rows.append(row)
assert len(rows) == 512
print(json.dumps(dict(status='native_inventory', torch=library_version, native_git='adapter-not-native',
                      cases=len(rows), rows=rows,
                      program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()), indent=2))
