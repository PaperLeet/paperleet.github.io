"""Select an isolated 0.72 candidate, preserving every prototype source identity."""
from pathlib import Path
import hashlib,json,shutil

r=Path(__file__).resolve().parent
v=r/'selected-release';v.mkdir()
old=r/'dependency-revision/snapshot/packages/stridetorch'
package=v/'snapshot/packages/stridetorch'
proof=json.loads((r/'dependency-revision/qualification.json').read_text())
assert proof['status']=='isolated_cpu_node_chrome_qualification_passed'
shutil.copytree(old,package,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
for name in ['pyproject.toml','src/stridetorch/__init__.py']:
    q=package/name;code=q.read_text();assert code.count('0.71.0')==1
    q.write_text(code.replace('0.71.0','0.72.0'))
with (package/'README.md').open('a') as output:
    output.write('''

## Functional Jacobian-vector products

Version 0.72 adds `torch.autograd.functional.jvp(func, inputs, v=None,
create_graph=False, strict=False)` for the supported real float32/float64
operators. Inputs and outputs may be a Tensor or a flat tuple of Tensors.
Vectors match their corresponding input shapes and are converted to the input
dtypes. An omitted vector requires one input containing one element.

```python
x = torch.tensor([2., 3.], requires_grad=True)
value, direction = torch.autograd.functional.jvp(
    lambda a: a.pow(3), x, torch.ones_like(x), create_graph=True)
assert value.tolist() == [8., 27.]
assert direction.tolist() == [12., 27.]
curvature = torch.autograd.grad(direction.sum(), x)[0]
assert curvature.tolist() == [12., 18.]
```

Default mode returns detached values and directions. `create_graph=True`
allows ordinary reverse queries on the returned graphs. The callback runs
once, repeated inputs become distinct callback objects, and original gradient
flags, existing gradient buffers and hooks remain isolated from internal work.
Captured originals remain separate from the processed arguments. Reverse-based
functional JVP respects `no_grad()`, `detach()` and `numpy(force=True)` boundaries;
ordinary `torch.func.jvp` retains its forward-mode behavior.

Strict mode checks dependencies for every input and output, including zero
derivatives. With `create_graph=True`, a constant Jacobian must still have a
natural differentiable dependency; private vector leaves cannot satisfy that
check. Differentiable captured weights are valid dependencies. Empty sums and
empty determinants preserve their different native strict/graph behavior.

Normalization and matrix-factor graphs remain differentiable when graph mode
needs them. Default normalization JVP avoids building those higher-order graphs.
Training BatchNorm may update its own buffers once. Singular determinant JVPs
use cofactor directions, retaining polynomial curvature rather than adopting
native saved-LU zeros or SVD-tape NaNs. The validation record distinguishes
direct native comparisons from independently checked mathematical derivatives
for the documented small determinant and fused-normalization fixtures.

This API does not enable general `autograd.grad(create_graph=True)` support,
arbitrary higher-order reverse graphs, complex differentiation, nested forward
transforms or unvalidated operator JVP rules. Registering gradient hooks inside
the callback is explicitly unsupported: such hooks can change the reverse-based
JVP and cannot be silently evaluated as an ordinary forward direction.
The registered functional JVP operator survives model copy and pickle.
''')
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
source={q.name:sha(q) for q in (package/'src/stridetorch').iterdir() if q.suffix=='.py' or q.name in ['LICENSE','NOTICE']}
tests={q.name:sha(q) for q in (package/'tests').glob('test_*.py')}
assert len(source)==61 and len(tests)==74 and tests==proof['test_hashes']
assert {k for k in source if source[k]!=proof['source_hashes'][k]}=={'__init__.py'}
freeze=dict(version='0.72.0',source_hashes=source,test_hashes=tests,
            package_hashes={name:sha(package/name) for name in ['pyproject.toml','README.md','LICENSE','NOTICE']},
            prototype_qualification_sha256=sha(r/'dependency-revision/qualification.json'),
            selection_scope='Version metadata and API documentation only; runtime/tests match the qualified prototype except __version__.')
(v/'source-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
print(json.dumps(dict(status='selected',version='0.72.0',source_files=61,test_files=74)))
