"""Freeze the dependency-corrected prototype and prepare real Pyodide SDK runs."""
from pathlib import Path
import hashlib
import json
import shutil

r=Path(__file__).resolve().parent
p=r/'dependency-revision'
package=r/'candidate/packages/stridetorch'
snapshot=p/'snapshot/packages/stridetorch'
shutil.copytree(package,snapshot,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
source={q.name:sha(q) for q in (snapshot/'src/stridetorch').iterdir() if q.suffix=='.py' or q.name in ['LICENSE','NOTICE']}
tests={q.name:sha(q) for q in (snapshot/'tests').glob('test_*.py')}
assert len(source)==61 and len(tests)==74
freeze=dict(source_hashes=source,test_hashes=tests,version_literal='0.71.0',prototype_iteration=72,
            scope='Unreleased functional JVP prototype. Existing main remains0.71; version selection/adoption are separate.',
            package_hashes={name:sha(snapshot/name) for name in ['pyproject.toml','README.md','LICENSE','NOTICE']})
(p/'source-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
old=r.parent/'torch-iteration-71/production-release/wasm-proof'
w=p/'wasm-proof';c=w/'chrome-contracts';c.mkdir(parents=True)
for name in ['node.mjs','sdk.py']:shutil.copy2(old/name,w/name)
for name in ['worker.mjs','index.html']:shutil.copy2(old/'chrome-contracts'/name,c/name)
driver=(old/'chrome-contracts/run.mjs').read_text().replace('/torch-iteration-71/production-release/wasm-proof/',
                                                       '/torch-iteration-72/dependency-revision/wasm-proof/')
(c/'run.mjs').write_text(driver)
for directory,manifest,origin in [('source',source,snapshot/'src/stridetorch'),
        ('tests',{k:v for k,v in tests.items() if k!='test_standalone.py'},snapshot/'tests')]:
    (c/directory).mkdir()
    for name,digest in manifest.items():
        assert sha(origin/name)==digest
        shutil.copy2(origin/name,c/directory/name)
plan=dict(source=source,tests={k:v for k,v in tests.items() if k!='test_standalone.py'},
          version='0.71.0',prototype_iteration=72,expected=8710,
          scope='Full SDK on frozen unreleased functional JVP prototype. No package/release/main qualification.')
(c/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
legacy=(r/'replay-legacy-hvp-cpu.py').read_text().replace("r / 'legacy-hvp-cpu'","r / 'dependency-revision/legacy-hvp-cpu'").replace(
    "r/'optimized-prototype-freeze.json'","r/'dependency-revision/source-freeze.json'")
(r/'dependency-revision-replay-legacy-hvp-cpu.py').write_text(legacy)
print(json.dumps(dict(status='frozen',source_files=len(source),test_files=len(tests),wasm_cases=8710)))
