"""Requalify the exact optimization source before any timing experiment."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

r = Path(__file__).resolve().parent
p = r / 'optimized-proof'
p.mkdir(exist_ok=True)
read = lambda q: json.loads(q.read_text())
sha = lambda q: hashlib.sha256(q.read_bytes()).hexdigest()
freeze = read(r / 'optimized-prototype-freeze.json')
source = r / 'candidate/packages/stridetorch'
def verify():
    for key, directory in [('source_hashes', 'src/stridetorch'), ('test_hashes', 'tests')]:
        for name, digest in freeze[key].items(): assert sha(source/directory/name) == digest

verify()
sdk_log = (r / 'optimized-sdk.log').read_text()
assert '8542 passed, 1 warning' in sdk_log and 'FAILED ' not in sdk_log
(r / 'optimized-sdk-receipt.json').write_text(json.dumps(dict(status='passed', cases=8542,
    source_hashes=freeze['source_hashes'], test_hashes=freeze['test_hashes'],
    log_sha256=sha(r/'optimized-sdk.log'), version_literal='0.71.0'), indent=2)+'\n')
jobs = [('basic', 'qualify-functional-jvp.py', 0),
        ('advanced', 'qualify-functional-jvp-advanced.py', 0),
        ('default-models', 'qualify-model-functional-jvp-default.py', 0),
        ('graph-model-native', 'qualify-model-functional-jvp.py', 1),
        ('graph-model-math', 'qualify-normalization-math-controls.py', 0)]
receipts = []
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='2', MKL_NUM_THREADS='2',
           OPENBLAS_NUM_THREADS='2', VECLIB_MAXIMUM_THREADS='2')
for label, name, expected in jobs:
    verify(); start = time.monotonic()
    with (p/(label+'.log')).open('w') as output:
        child = subprocess.run([sys.executable, str(r/name)], cwd=r, env=env, stdout=output, stderr=subprocess.STDOUT)
    receipts.append(dict(label=label, exit_code=child.returncode, expected_exit_code=expected,
                         seconds=time.monotonic()-start, log_sha256=sha(p/(label+'.log'))))
    (p/'receipts.json').write_text(json.dumps(receipts, indent=2)+'\n')
    assert child.returncode == expected, label
    verify()
    if label == 'graph-model-native':
        raw = read(r/'model-proof/qualification.json')
        assert len(raw['failures']) == 48 and {v['case'] for v in raw['failures']} == {'layernorm','batchnorm_train','instancenorm_train'}
    print(label, 'TERMINAL', child.returncode, flush=True)
paths = ['prototype-proof/qualification.json', 'advanced-proof/qualification.json',
         'default-model-proof/qualification.json', 'model-math-controls/qualification.json']
for name in paths: assert read(r/name)['source_hashes'] == freeze['source_hashes']
assert read(r/'default-model-proof/qualification.json')['status'] == 'passed'
result = dict(status='cpu_sdk_and_optimized_numerical_controls_passed',
              source_hashes=freeze['source_hashes'], test_hashes=freeze['test_hashes'],
              sdk_cases=8542, numerical_cases=1824, direct_native_cases=1776,
              independent_normalization_controls=48, receipts=receipts,
              evidence_sha256={name:sha(r/name) for name in paths+['optimized-sdk-receipt.json']},
              scope='Isolated prototype with0.71version literal:8542CPU SDK and1824CPU numerical/caller cases. '
                    '1776direct native comparisons include expected errors;48normalization graph gradients '
                    'use independently validated complex-step/native finite-difference controls. '
                    'No WASM/minimum-package/performance/application/main-adoption qualification.')
(p/'qualification.json').write_text(json.dumps(result, indent=2)+'\n')
print(result['status'], flush=True)
