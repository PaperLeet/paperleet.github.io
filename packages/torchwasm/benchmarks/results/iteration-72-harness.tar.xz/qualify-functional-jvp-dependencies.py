"""Classify exact compatibility, independently checked math, and explicit unsupported hooks."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import numpy as np
from determinant_jvp_math_reference import fixture, reference

r = Path(__file__).resolve().parent
p = r / 'dependency-revision'
p.mkdir(exist_ok=True)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = r / 'candidate/packages/stridetorch/src/stridetorch'
hashes = lambda: {path.name:sha(path) for path in source.iterdir() if path.suffix == '.py' or path.name in ['LICENSE', 'NOTICE']}
before = hashes()
with (p/'candidate-dependencies.json').open('w') as output, (p/'dependencies.stderr.log').open('w') as error:
    subprocess.run([sys.executable, str(r/'probe-functional-jvp-dependencies.py')], check=True,
                   env=dict(os.environ, STRIDE_PROBE='1', PYTHONPATH=str(source.parent), PYTHONDONTWRITEBYTECODE='1'),
                   stdout=output, stderr=error)
assert before == hashes()
read = lambda path: json.loads(path.read_text())
native = read(r/'native-functional-jvp-dependencies.json')
actual = read(p/'candidate-dependencies.json')
controls = read(r/'determinant-jvp-polynomial-controls.json')
assert controls['status'] == 'validated' and controls['cases'] == 10
for name, digest in controls['source_hashes'].items(): assert sha(r/name) == digest
assert native['cases'] == actual['cases'] == 480
assert native['probe_sha256'] == actual['probe_sha256'] == sha(r/'probe-functional-jvp-dependencies.py')


def compare(a, b, dtype, path=(), skip_reverse_values=False):
    if isinstance(a, dict):
        assert set(a)-{'message'} == set(b)-{'message'}, (path, set(a), set(b))
        if 'values' in a:
            for key in ['dtype', 'shape', 'requires_grad']: assert a[key] == b[key], (path, key)
            if not (skip_reverse_values and path[0] == 'reverse'):
                np.testing.assert_allclose(b['values'], a['values'], rtol=1e-4 if dtype == 'float32' else 1e-8,
                                           atol=3e-6 if dtype == 'float32' else 2e-10)
        else:
            for key in set(a)-{'message'}: compare(a[key], b[key], dtype, path+(key,), skip_reverse_values)
    elif isinstance(a, list):
        assert len(a) == len(b), path
        for index, (x,y) in enumerate(zip(a,b)): compare(x,y,dtype,path+(index,),skip_reverse_values)
    else:
        assert a == b, (path, a, b)


counts = dict(direct_native=0, independent_polynomial=0, explicit_unsupported=0)
failures = []
math_cases = {row['case'] for row in controls['rows']}
for expected, observed in zip(native['rows'], actual['rows']):
    identity = {key:expected[key] for key in ['case','dtype','gx','gv','create_graph','strict']}
    try:
        for key,value in identity.items(): assert observed[key] == value
        if expected['case'] == 'hook_in_callback':
            assert 'result' in expected and observed['error'] == 'BrowserUnsupported'
            assert observed['api_hooks'] == observed['internal_api_hooks'] == []
            compare(expected['state'], observed['state'], expected['dtype'])
            counts['explicit_unsupported'] += 1
        elif expected['case'] in math_cases and expected['gx'] and expected['create_graph']:
            compare(expected, observed, expected['dtype'], skip_reverse_values=True)
            a,e = fixture(expected['case'], expected['dtype'])
            refs = reference(a,e,expected['case'].startswith('det_squared'))
            # Targets retain probe ordering: x, v (when enabled), y, w (when enabled), capture.
            for channel,key in [(0,'primal_gradient'),(1,'tangent_gradient')]:
                targets = observed['reverse'][channel]['result']
                np.testing.assert_allclose(targets[0]['values'], refs[key],
                    rtol=1e-4 if expected['dtype']=='float32' else 1e-8,
                    atol=3e-6 if expected['dtype']=='float32' else 2e-10)
                if expected['gv']:
                    if channel == 0: assert targets[1] is None
                    else: np.testing.assert_allclose(targets[1]['values'],refs['vector_gradient'],
                        rtol=1e-4 if expected['dtype']=='float32' else 1e-8,
                        atol=3e-6 if expected['dtype']=='float32' else 2e-10)
                for target in targets[2 if expected['gv'] else 1:]: assert target is None
            counts['independent_polynomial'] += 1
        else:
            compare(expected, observed, expected['dtype'])
            counts['direct_native'] += 1
    except (AssertionError, KeyError, TypeError) as error:
        failures.append(dict(identity=identity, error=str(error), native=expected, actual=observed))
result = dict(status='failed' if failures else 'passed_with_explicit_boundaries', cases=480, counts=counts,
              failures=failures, source_hashes=before,
              evidence_sha256={str(path.relative_to(r)):sha(path) for path in [r/'native-functional-jvp-dependencies.json',
                  p/'candidate-dependencies.json', r/'determinant-jvp-polynomial-controls.json',
                  r/'probe-functional-jvp-dependencies.py', Path(__file__)]},
              scope='408 direct native cases (including errors), 40 singular determinant graph cases checked against '
                    'independent polynomials and full-coordinate native FP64 finite differences; 32 callback hook cases '
                    'explicitly rejected as BrowserUnsupported. No claim of general native graph equivalence or hook support.')
(p/'dependencies-qualification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],cases=480,counts=counts,failures=len(failures))))
assert not failures
assert counts == dict(direct_native=408, independent_polynomial=40, explicit_unsupported=32)
