"""Compare isolated prototype caller/output behavior to the production oracle."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import numpy as np

r = Path(__file__).resolve().parent
p = r / 'selected-release/native-cpu/prototype-proof'
p.mkdir(parents=True,exist_ok=True)
source = r / 'selected-release/snapshot/packages/stridetorch/src'
sha = lambda q: hashlib.sha256(q.read_bytes()).hexdigest()
before = {q.name: sha(q) for q in (source / 'stridetorch').iterdir() if q.suffix == '.py' or q.name in ['LICENSE', 'NOTICE']}
program = (r / 'probe-functional-jvp.py').read_text().replace(
    'import torch', 'from stridetorch import torch, __version__ as library_version').replace(
    'torch.__version__', 'library_version').replace('torch.version.git_version', "'adapter-not-native'")
(p / 'probe.py').write_text(program)
with (p / 'candidate.json').open('w') as output, (p / 'stderr.log').open('w') as error:
    child = subprocess.run([sys.executable, str(p / 'probe.py')], env=dict(
        os.environ, PYTHONPATH=str(source), PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='2',
        MKL_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', VECLIB_MAXIMUM_THREADS='2'),
        stdout=output, stderr=error)
child.check_returncode()
assert before == {q.name: sha(q) for q in (source / 'stridetorch').iterdir() if q.suffix == '.py' or q.name in ['LICENSE', 'NOTICE']}
native = json.loads((r / 'native-functional-jvp-torch26.json').read_text())
candidate = json.loads((p / 'candidate.json').read_text())
assert native['cases'] == candidate['cases'] == 480

def compare(a, b):
    if isinstance(a, dict):
        keys = set(a) - {'message'}
        assert keys == set(b) - {'message'}, (set(a), set(b))
        if 'values' in a:
            assert a['shape'] == b['shape'] and a['requires_grad'] == b['requires_grad']
            assert a['dtype'].removeprefix('torch.') == b['dtype'].removeprefix('torch.')
            np.testing.assert_allclose(b['values'], a['values'], rtol=1e-6, atol=1e-8)
        else:
            for key in keys: compare(a[key], b[key])
    elif isinstance(a, list):
        assert len(a) == len(b)
        for x, y in zip(a, b): compare(x, y)
    elif isinstance(a, str) and a.startswith('torch.'):
        assert a.removeprefix('torch.') == b.removeprefix('torch.')
    else:
        assert a == b, (a, b)

failures = []
for a, b in zip(native['rows'], candidate['rows']):
    try:
        compare(a, b)
    except (AssertionError, TypeError, KeyError) as error:
        failures.append(dict(case=a['case'], dtype=a['dtype'], gx=a['gx'], gv=a['gv'],
                             strict=a['strict'], create_graph=a['create_graph'], error=str(error),
                             native=a, actual=b))
record = dict(status='failed' if failures else 'passed', cases=480, failures=failures,
              source_hashes={q.name: sha(q) for q in (source / 'stridetorch').iterdir()
                             if q.suffix == '.py' or q.name in ['LICENSE', 'NOTICE']},
              native_sha256=sha(r / 'native-functional-jvp-torch26.json'),
              candidate_sha256=sha(p / 'candidate.json'), probe_sha256=sha(p / 'probe.py'),
              scope='Isolated initial functionalJVP prototype, 480 boundary/caller/output cases only. '
                    'No model-curvature, SDK, WASM, package, performance or main-adoption qualification.')
(p / 'qualification.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(dict(status=record['status'], cases=480, failures=len(failures),
                     failed_cases=sorted({row['case'] for row in failures}))), flush=True)
sys.exit(bool(failures))
