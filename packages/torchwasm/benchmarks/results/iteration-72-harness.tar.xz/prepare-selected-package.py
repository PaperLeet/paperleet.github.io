"""Prepare minimum-version wheel/sdist and coinstalled private-package checks."""
from pathlib import Path
import hashlib,json,shutil,subprocess

r=Path(__file__).resolve().parent;v=r/'selected-release';p=v/'package-proof';p.mkdir()
repo=Path('/Users/david/Developer/PaperLeet-torch-release');snapshot=v/'snapshot'
old=r.parent/'torch-iteration-71/production-release'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
freeze=json.loads((v/'source-freeze.json').read_text())
assert subprocess.check_output(['git','status','--porcelain','-z'],cwd=repo)==b''
names=[n for n in subprocess.check_output(['git','ls-files','-z','--','paperleet','pyproject.toml','setup.py','LICENSE','NOTICE','README.md','MANIFEST.in'],cwd=repo).decode().split('\0') if n]
application={}
for name in names:
    source=repo/name;target=snapshot/name;target.parent.mkdir(parents=True,exist_ok=True)
    assert not target.exists();shutil.copy2(source,target)
    if name.startswith('paperleet/') and (name.endswith('.py') or name=='paperleet/interview_catalog.json'):application[name]=sha(source)
assert len(application)==37
(p/'application-source-hashes.json').write_text(json.dumps(application,indent=2)+'\n')
(p/'application-fixture.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),files={n:sha(repo/n) for n in names}),indent=2)+'\n')
(p/'source-hashes.json').write_text(json.dumps(freeze['source_hashes'],indent=2)+'\n')
for name in ['check-wheel.py','check-coinstall.py','fresh-load.py']:
    code=(old/'package-proof'/name).read_text().replace('0.71.0','0.72.0').replace('stride071','stride072').replace('8363','8723')
    if name=='check-coinstall.py':
        needle='saved.hvp_operator is t.autograd.functional.hvp'
        assert needle in code;code=code.replace(needle,needle+' and saved.jvp_operator is t.autograd.functional.jvp')
        needle='saved.hvp_operator=t.autograd.functional.hvp'
        assert needle in code;code=code.replace(needle,needle+';saved.jvp_operator=t.autograd.functional.jvp')
        needle="print('PASS isolated ownership,aliases,ZIP resume,triangular,Cholesky and Cholesky solve VJP/JVP/full tangent reverse')"
        assert needle in code
        code=code.replace(needle,'''for name in NAMES:
 m=importlib.import_module(name);t=m.torch
 with m.as_torch() as api:
  from torch.autograd.functional import jvp
  assert jvp is api.autograd.functional.jvp
  x=api.tensor([2.,3.],requires_grad=True);x.grad=api.full_like(x,17.);buffer=x.grad
  y,d=jvp(lambda a:a.pow(3),x,api.ones_like(x),create_graph=True,strict=True)
  assert y.tolist()==[8.,27.] and d.tolist()==[12.,27.] and x.grad is buffer
  assert api.autograd.grad(d.sum(),x)[0].tolist()==[12.,18.]
  a=api.tensor([[1.,2.],[2.,4.]],dtype=api.float64)
  _,d=jvp(api.linalg.det,a,api.tensor([[.2,.3],[-.5,.7]],dtype=api.float64),strict=True)
  np.testing.assert_allclose(d.numpy(),1.9)
 assert sys.modules.get('torch') is host
'''+needle)
    elif name=='fresh-load.py':
        code+='''
assert model.jvp_operator is m.torch.autograd.functional.jvp
primal,direction=model.jvp_operator(lambda a:a.pow(3),value,m.torch.ones_like(value),create_graph=True,strict=True)
assert primal.tolist()==[8.,27.] and direction.tolist()==[12.,27.] and value.grad is None
assert m.torch.autograd.grad(direction.sum(),value)[0].tolist()==[12.,18.]
assert sys.modules['torch'] is host
print('PASS fresh-process functional JVP operator restore',name)
'''
    compile(code,str(p/name),'exec');(p/name).write_text(code)
code=(old/'run-package-proof.py').read_text().replace('0.71.0','0.72.0').replace('stride071','stride072').replace('8363','8723')
code=code.replace('activation,VJP,Jacobian andHVP operator pickle','activation,VJP,Jacobian,HVP andfunctionalJVP operator pickle')
compile(code,str(v/'run-package-proof.py'),'exec');(v/'run-package-proof.py').write_text(code)
print('Prepared0.72 wheel/sdist,coinstall,aliases,checkpoints,fresh-process JVP pickle and8723minimum-runtime tests')
