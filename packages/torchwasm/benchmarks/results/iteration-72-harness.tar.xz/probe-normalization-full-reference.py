"""Validate every reference derivative against native FP64 value/direction differences."""
from pathlib import Path
import hashlib
import json
import numpy as np
import torch
from normalization_math_reference import objective_and_direction, complex_step_gradients, fixture_values

r = Path(__file__).resolve().parent
oracle = json.loads((r / 'native-model-functional-jvp-torch26.json').read_text())
rows = []
for case in ['layernorm', 'instancenorm_train', 'batchnorm_train']:
    for dtype in ['float32', 'float64']:
        fixture = next(row for row in oracle['rows'] if row['case'] == case and row['dtype'] == dtype
                       and not row['strict'] and not row['strided'] and not row['vector_grad'])
        values = fixture_values(fixture)
        def native(pair):
            x, w, b, vx, vw, vb = [torch.tensor(pair[key], dtype=torch.float64)
                                  for key in ['x', 'weight', 'bias', 'vx', 'vweight', 'vbias']]
            if case == 'layernorm':
                function = lambda a, weight, bias: torch.nn.functional.layer_norm(a, (3,), weight, bias).square().sum()
            elif case == 'instancenorm_train':
                function = lambda a, weight, bias: torch.nn.functional.instance_norm(a, weight=weight, bias=bias).square().sum()
            else:
                function = lambda a, weight, bias: torch.nn.functional.batch_norm(a, None, None, weight, bias, training=True).square().sum()
            output, product = torch.autograd.functional.jvp(function, (x, w, b), (vx, vw, vb))
            return np.array([output.item(), product.item()])
        base = objective_and_direction(case, values)
        np.testing.assert_allclose(base, native(values), rtol=1e-10, atol=1e-11)
        gradients = complex_step_gradients(case, values)
        finite = {}
        max_error = 0.
        max_step_difference = 0.
        for name, original in values.items():
            full = np.empty_like(gradients[name])
            for index in np.ndindex(original.shape):
                estimates = []
                step = 2e-5 * max(1., abs(float(original[index])))
                for h in [step, step / 2]:
                    samples = []
                    for sign in [-1, 1]:
                        perturbed = {key: value.copy() for key, value in values.items()}
                        perturbed[name][index] += sign * h
                        samples.append(native(perturbed))
                    estimates.append((samples[1] - samples[0]) / (2 * h))
                result = (4 * estimates[1] - estimates[0]) / 3
                full[(slice(None),) + index] = result
                max_step_difference = max(max_step_difference, float(np.max(np.abs(estimates[1]-estimates[0]))))
            np.testing.assert_allclose(gradients[name], full, rtol=1e-6, atol=2e-7)
            max_error = max(max_error, float(np.max(np.abs(gradients[name]-full))))
            finite[name] = full.tolist()
        rows.append(dict(case=case, original_dtype=dtype, reference_dtype='float64',
                         values={key: value.tolist() for key, value in values.items()},
                         result=base.tolist(), gradients={key: value.tolist() for key, value in gradients.items()},
                         native_richardson_gradients=finite, max_abs_complex_vs_native_finite_difference=max_error,
                         max_abs_full_vs_half_step_difference=max_step_difference))
assert len(rows) == 6
result = dict(status='validated', cases=6, torch=torch.__version__, native_git=torch.version.git_version,
              rows=rows, complex_step=1e-20, finite_steps=[2e-5, 1e-5],
              source_hashes={name: hashlib.sha256((r/name).read_bytes()).hexdigest()
                             for name in ['normalization_math_reference.py', 'probe-normalization-full-reference.py',
                                          'native-model-functional-jvp-torch26.json']},
              scope='Six distinct rounded input/direction fixtures; independent complex-step full gradients '
                    'for both scalar components, checked against two-step Richardson differences of freshly '
                    'evaluated native FP64 fused normalization JVP values. Not a native graph-gradient match '
                    'or standalone adapter/runtime qualification.')
print(json.dumps(result, indent=2))
