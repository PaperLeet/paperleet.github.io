"""Preserve native differences while checking full independent normalization derivatives."""
from pathlib import Path
import hashlib
import json
import numpy as np
from normalization_math_reference import fixture_values

r = Path(__file__).resolve().parent
p = r / 'selected-release/native-cpu/model-math-controls'
p.mkdir(parents=True,exist_ok=True)
read = lambda q: json.loads(q.read_text())
sha = lambda q: hashlib.sha256(q.read_bytes()).hexdigest()
source = r / 'selected-release/snapshot/packages/stridetorch/src/stridetorch'
hashes = {q.name: sha(q) for q in source.iterdir() if q.suffix == '.py' or q.name in ['LICENSE', 'NOTICE']}
raw = read(r / 'selected-release/native-cpu/model-proof/qualification.json')
assert raw['source_hashes'] == hashes and raw['cases'] == 416 and len(raw['failures']) == 48
assert raw['candidate_sha256'] == sha(r / 'selected-release/native-cpu/model-proof/candidate.json')
assert raw['native_sha256'] == sha(r / 'native-model-functional-jvp-torch26.json')
native = read(r / 'native-model-functional-jvp-torch26.json')
candidate = read(r / 'selected-release/native-cpu/model-proof/candidate.json')
reference = read(r / 'normalization-full-reference.json')
assert reference['status'] == 'validated' and reference['cases'] == 6
for name, digest in reference['source_hashes'].items(): assert sha(r / name) == digest
refs = {(row['case'], row['original_dtype']): row for row in reference['rows']}
families = {'layernorm', 'batchnorm_train', 'instancenorm_train'}
assert {row['case'] for row in raw['failures']} == families

def compare(a, b, dtype, path=(), skip_reverse_values=False):
    if isinstance(a, dict):
        keys = set(a) - {'message'}
        assert keys == set(b) - {'message'}, (path, set(a), set(b))
        if 'values' in a:
            for key in ['shape', 'dtype', 'requires_grad']:
                assert a[key] == b[key], (path, key, a[key], b[key])
            if not (skip_reverse_values and 'reverse_channels' in path):
                np.testing.assert_allclose(b['values'], a['values'],
                    rtol=1e-4 if dtype == 'float32' else 1e-8,
                    atol=3e-6 if dtype == 'float32' else 2e-10)
        else:
            for key in keys: compare(a[key], b[key], dtype, path + (key,), skip_reverse_values)
    elif isinstance(a, list):
        assert len(a) == len(b), path
        for index, (x, y) in enumerate(zip(a, b)):
            compare(x, y, dtype, path + (index,), skip_reverse_values)
    else:
        assert a == b, (path, a, b)

names = {'input:0': 'x', 'input:1': 'weight', 'input:2': 'bias',
         'parameter:0': 'weight', 'parameter:1': 'bias',
         'vector:0': 'vx', 'vector:1': 'vweight', 'vector:2': 'vbias'}
controls = []
direct = 0
failures = []
for original, actual in zip(native['rows'], candidate['rows']):
    try:
        dtype = original['dtype']
        controlled = original['case'] in families
        compare(original, actual, dtype, skip_reverse_values=controlled)
        if not controlled:
            direct += 1
            continue
        assert actual['status'] == 'success'
        ref = refs[(original['case'], dtype)]
        arrays = fixture_values(original)
        for name, values in arrays.items():
            np.testing.assert_allclose(values, ref['values'][name], rtol=0, atol=1e-15)
        np.testing.assert_allclose([item['values'] for item in actual['result']], ref['result'],
            rtol=1e-4 if dtype == 'float32' else 1e-8,
            atol=3e-6 if dtype == 'float32' else 2e-10)
        component_errors = []
        for component, channel in enumerate(actual['reverse_channels']):
            errors = {}
            for name, value in zip(channel['names'], channel['gradients']):
                target = np.asarray(ref['gradients'][names[name]])[component]
                if value is None:
                    np.testing.assert_array_equal(target, np.zeros_like(target))
                    errors[name] = 0.
                    continue
                assert value['shape'] == list(target.shape) and value['dtype'] == dtype
                assert value['requires_grad'] is False
                data = np.asarray(value['values'])
                np.testing.assert_allclose(data, target,
                    rtol=1e-4 if dtype == 'float32' else 1e-8,
                    atol=3e-6 if dtype == 'float32' else 2e-10)
                errors[name] = float(np.max(np.abs(data-target)))
            component_errors.append(errors)
        controls.append(dict(case=original['case'], dtype=dtype, strict=original['strict'],
                             strided=original['strided'], vector_grad=original['vector_grad'],
                             component_max_abs_errors=component_errors,
                             reference_finite_difference_max_error=ref['max_abs_complex_vs_native_finite_difference']))
    except (AssertionError, KeyError, TypeError) as error:
        failures.append(dict(case=original['case'], dtype=original['dtype'], strict=original['strict'],
                             strided=original['strided'], vector_grad=original['vector_grad'], error=str(error)))
record = dict(status='passed_with_explicit_normalization_math_controls' if not failures else 'failed',
              source_hashes=hashes, cases=416, direct_native_cases=direct, independent_math_cases=len(controls),
              controls=controls, failures=failures,
              raw_direct_native_disagreements=48,
              evidence_sha256={name: sha(r / name) for name in ['selected-release/native-cpu/model-proof/qualification.json',
                  'selected-release/native-cpu/model-proof/candidate.json', 'native-model-functional-jvp-torch26.json',
                  'normalization-full-reference.json', 'normalization_math_reference.py']},
              scope='368 direct native graph-model comparisons plus48 explicitly independent full-gradient '
                    'normalization controls. All metadata, state, hooks and forward results still compare '
                    'to fused native2.6; only reverse numeric values in these48cases use independently '
                    'validated math references. FP32 fixtures use their rounded values in FP64 references. '
                    'Existing native disagreement report is retained. No SDK/WASM/package/performance/adoption claim.')
if not failures: assert direct == 368 and len(controls) == 48
(p / 'qualification.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(dict(status=record['status'], direct_native_cases=direct,
                     independent_math_cases=len(controls), failures=failures)), flush=True)
raise SystemExit(bool(failures))
