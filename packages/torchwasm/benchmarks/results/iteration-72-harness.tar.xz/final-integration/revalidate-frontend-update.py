"""Retain unchanged numeric/package proofs and revalidate the new frontend integration base."""
from pathlib import Path
import hashlib,json,os,subprocess,time

p=Path(__file__).resolve().parent;r=p.parent;old=p/'validated-on-096e'
repo=Path('/Users/david/Developer/PaperLeet-torch-release');python=r.parent/'torch-iteration-69/integration-dev-env/bin/python'
read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
save=lambda q,d:q.write_text(json.dumps(d,indent=2)+'\n')
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
before=read(old/'local-validation.json');assert before['status']=='passed'
head=git('rev-parse','HEAD').decode().strip();assert head=='77be0d1be2af79a3a7d315c80991d55014c711c8'
changed=[name for name in git('diff','--name-only',before['upstream'],head).decode().splitlines() if name]
assert len(changed)==9 and all(name.startswith(('web/src/','web/scripts/')) or name in ['web/package.json','docs/validation/solution-reading-navigation.md'] for name in changed)
for manifest,prefix in [('application-input-sha256.json',''),('source-hashes.json','packages/stridetorch/src/stridetorch'),
 ('test-hashes.json','packages/stridetorch/tests'),('baseline-immutable-sha256.json',''),('live-export-sha256.json','web/public/data')]:
    for name,digest in read(old/manifest).items():assert sha(repo/prefix/name)==digest,(manifest,name)
policy=read(old/'release-policy-identity.json')
for group in [policy['files'],policy['workflows']]:
    for name,digest in group.items():assert sha(repo/name)==digest
worker=read(old/'generated-worker-proof.json')
for name,digest in worker['inputs'].items():assert sha(repo/name)==digest
package=read(r/'selected-release/package-proof/package-identity.json')
for name,digest in package['application_source_hashes'].items():assert sha(repo/name)==digest
context=read(p/'context.json');context.update(upstream=head,original_qualified_upstream=before['upstream']);save(p/'context.json',context)
tracked=git('ls-files','-z','--','web/src','web/scripts','web/index.html','web/package.json','web/package-lock.json','web/vite.config.ts','web/tsconfig*.json','web/public/browser-judge').decode().split('\0')
frontend={name:sha(repo/name) for name in tracked if name};save(p/'frontend-input-sha256.json',frontend)
receipts=read(old/'receipts.json')[:5]
assert [row['label'] for row in receipts]==['editable-environment','export','verify-export','cpu','wasm']
assert all(row['exit_code']==0 for row in receipts)
env=dict(os.environ,PYTHON=str(python),PYTHONDONTWRITEBYTECODE='1',
 PYTHONPATH=os.pathsep.join([str(repo/'packages/stridetorch/src'),str(repo)]),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
env['PATH']='/Users/david/.npm/_npx/d18f28baf1132559/node_modules/node/bin:/opt/homebrew/bin:'+str(python.parent)+':'+env['PATH']
assert subprocess.check_output(['node','--version'],env=env,text=True).strip()=='v22.23.3'
def run(label,args,cwd=repo,extra=None):
    start=time.monotonic()
    with (p/(label+'.log')).open('w') as output:child=subprocess.run(args,cwd=cwd,env={**env,**(extra or {})},stdout=output,stderr=subprocess.STDOUT)
    receipt=dict(label=label,exit_code=child.returncode,seconds=time.monotonic()-start,args=args,cwd=str(cwd),log_sha256=sha(p/(label+'.log')),
                 summary=(p/(label+'.log')).read_text().splitlines()[-1:],executed_on_upstream=head)
    receipts.append(receipt);save(p/'receipts.json',receipts);child.check_returncode()
    print(label,'TERMINAL0',receipt['summary'],flush=True)
run('full-frontend-check',['npm','run','check'],repo/'web')
run('wasm-driver',['node','web/scripts/check-wasm-cases.mjs'])
run('pages-policy',['node','web/scripts/check-pages-release.cjs'])
run('build',['npm','run','build'],repo/'web')
value=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED','--jq','.value'],cwd=repo,text=True).strip()
assert value in ['0','1']
profile=dict(PAPERLEET_MAIN_SITE_ENABLED=value,VITE_PUBLIC_SITE='0' if value=='1' else '1',VITE_APP_EDITION='hosted' if value=='1' else 'local',
 VITE_API_ORIGIN='https://app.paperleet.com' if value=='1' else '',VITE_HOSTED_APP_AVAILABLE='1',VITE_HOSTED_APP_URL='https://app.paperleet.com')
save(p/'current-pages-profile.json',profile)
run('pages-profile-build',['npm','run','build'],repo/'web',profile)
run('generated-worker',['node',str(p/'verify-generated-worker.mjs')])
for name,digest in frontend.items():assert sha(repo/name)==digest,name
for manifest,prefix in [('application-input-sha256.json',''),('source-hashes.json','packages/stridetorch/src/stridetorch'),
 ('test-hashes.json','packages/stridetorch/tests'),('baseline-immutable-sha256.json',''),('live-export-sha256.json','web/public/data')]:
    for name,digest in read(old/manifest).items():assert sha(repo/prefix/name)==digest,(manifest,name)
assert git('rev-parse','HEAD').decode().strip()==head
equivalence=dict(status='verified_unchanged_numeric_inputs_and_revalidated_frontend',original_qualified_upstream=before['upstream'],current_upstream=head,
 changed_paths=changed,changed_file_sha256={name:sha(repo/name) for name in changed},
 retained_proof_sha256={name:sha(old/name) for name in ['local-validation.json','cpu-receipt.json','full-wasm-result.json','application-input-sha256.json','source-hashes.json','test-hashes.json','release-policy-identity.json']},
 retained_domains=['Complete application/Python tests/problems/scripts input manifests','Exact selected0.72 runtime and SDK tests','All immutable and live export inputs',
 'Installed public/private package source identities','Browser Worker source graph','All release-policy/workflow files'],
 replayed_domains=['Complete updated frontend check script','WASM driver and release-policy contracts','Both build profiles','Exact generated Worker derivation'],
 scope='CPU/WASM/package/performance evidence was executed before this frontend-only fast-forward. Exact input identities are retained;frontend/build gates rerun on the new base. No re-labelling of old execution provenance.')
save(p/'source-equivalent-frontend-update.json',equivalence)
result=dict(before,upstream=head,receipts=receipts,frontend_commands=len(read(repo/'web/package.json')['scripts']['check'].split(' && ')),
 source_equivalent_frontend_update=equivalence,main_adopted=False,ci_triggered=False,deployed=False)
save(p/'local-validation.json',result)
print('LATEST FRONTEND INTEGRATION BASE VERIFIED; NUMERIC INPUTS IDENTICAL; NO PUSH OR RELEASE',flush=True)
