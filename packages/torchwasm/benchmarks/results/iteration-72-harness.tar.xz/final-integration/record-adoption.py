"""Verify tested inputs as committed blobs before recording main adoption."""
from pathlib import Path
import datetime, hashlib, json, re, subprocess, sys

p = Path(__file__).resolve().parent
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
read = lambda q: json.loads(q.read_text())
sha = lambda q: hashlib.sha256(q.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git', *args], cwd=repo)
def api(endpoint): return json.loads(subprocess.check_output(['gh','api',endpoint], cwd=repo))
def save(q, value): q.write_text(json.dumps(value,indent=2)+'\n')

own = read(p / 'own-commits.json')
final = sys.argv[1:] == ['--verify-final']
assert not sys.argv[1:] or final
adopted = own['adoption_candidate_commit']
target = own['proof_commit'] if final else adopted
remote = api('repos/PaperLeet/paperleet.github.io/git/ref/heads/main')['object']['sha']
assert remote == target and git('rev-parse','HEAD').decode().strip() == target
assert not git('status','--porcelain','-z')
push = read(p / ('proof-push-receipt.json' if final else 'adoption-push-receipt.json'))
assert push['exit_code'] == 0 and push['guard_allowed'] and push['pushed_head'] == target
source_report = read(repo / 'packages/stridetorch/benchmarks/results/iteration-72.json')
local = source_report['local_integration']
assert source_report['status']=='validated_locally' and source_report['version']=='0.72.0'
assert local['status']=='passed' and len(local['receipts'])==11
assert all(v['exit_code']==0 for v in local['receipts'])
expected = {}
for manifest, prefix in [('source-hashes.json','packages/stridetorch/src/stridetorch/'),
    ('test-hashes.json','packages/stridetorch/tests/'),('live-export-sha256.json','web/public/data/'),
    ('application-input-sha256.json',''),('frontend-input-sha256.json',''),
    ('owned-input-sha256.json',''),('new-assets-sha256.json','')]:
    expected.update({prefix+n:d for n,d in read(p/manifest).items()})
policy=read(p/'release-policy-identity.json')
expected.update(policy['files']); expected.update(policy['workflows'])
worker=read(p/'generated-worker-proof.json')
assert worker['status']=='verified' and worker['node']=='v22.23.3'
assert sha(repo/worker['generated_module'])==worker['generated_module_sha256']
assert sha(repo/worker['asset'])==worker['asset_sha256']
expected.update(worker['inputs'])
tracked=set(git('ls-tree','-r','--name-only','-z',target).decode().split('\0'))-{''}
derivatives={}
for name,digest in [(worker['generated_module'],worker['generated_module_sha256']),
                    (worker['asset'],worker['asset_sha256'])]:
    if name in tracked: expected[name]=digest
    else:
        assert subprocess.run(['git','check-ignore','--quiet',name],cwd=repo).returncode==0
        derivatives[name]=digest
assert all(name in tracked for name in worker['inputs'])
for name in ['packages/stridetorch/README.md','packages/stridetorch/pyproject.toml',
    'packages/stridetorch/benchmarks/results/iteration-72.json',
    'packages/stridetorch/benchmarks/results/iteration-72-harness.tar.xz',
    'docs/validation/torch-runtime-iteration-72.md']:
    expected[name]=sha(repo/name)
archive=source_report['raw_archive']
assert sha(repo/'packages/stridetorch/benchmarks/results'/archive['name'])==archive['sha256']
if final:
    name='packages/stridetorch/benchmarks/results/iteration-72-main-adoption.json'
    receipt=read(repo/name)
    assert receipt['adopted_main_commit']==adopted
    expected[name]=sha(repo/name)
process=subprocess.Popen(['git','cat-file','--batch'],cwd=repo,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for name,digest in expected.items():
    assert sha(repo/name)==digest, name
    process.stdin.write((target+':'+name+'\n').encode()); process.stdin.flush()
    header=process.stdout.readline().split()
    assert len(header)==3 and header[1]==b'blob', (name,header)
    data=process.stdout.read(int(header[2])); assert process.stdout.read(1)==b'\n'
    assert hashlib.sha256(data).hexdigest()==digest, name
process.stdin.close(); assert process.wait(timeout=10)==0
def tree(ref):
    result={}
    for row in git('ls-tree','-r','-z',ref,'--','web/public/data/browser-judge','web/public/data/modules').split(b'\0'):
        if row:
            info,name=row.split(b'\t',1); result[name.decode()]=info.decode()
    return result
before,after=tree(own['expected_remote']),tree(target)
old=read(p/'baseline-immutable-sha256.json')
assert len(old)==local['original_immutable_assets']
assert all(before[n]==after[n] for n in old)
runs={}
for ref in dict.fromkeys([adopted,target]):
    value=api(f'repos/PaperLeet/paperleet.github.io/actions/runs?head_sha={ref}&per_page=100')
    assert value['total_count']==0 and not value['workflow_runs']
    runs[ref]=value['total_count']
report=dict(status='verified_final_main_adoption' if final else 'adopted_on_main',
    observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),version='0.72.0',
    implementation_commit=own['source_commit'],adopted_main_commit=adopted,verified_main_commit=target,
    prior_remote=own['expected_remote'],verified_git_blob_hashes=expected,
    preserved_immutable_assets=len(old),preserved_old_asset_git_tree_entries=True,
    source_resources=len(read(p/'source-hashes.json')),live_export_identities=len(read(p/'live-export-sha256.json')),
    full_cpu_summary=source_report['full_cpu']['summary'],full_wasm_modules=local['catalog_modules'],
    full_wasm_mutants=local['mutants'],minimum_installed_cases=source_report['independent_package']['standalone_installed_tests'],
    node_chrome_sdk_cases_each=8710,node_chrome_native_and_analytic_cases_each=720,
    direct_native_cases_each=676,independent_precision_controls_each=4,polynomial_extension_controls_each=40,
    node_chrome_jvp_inventory_cases_each=2304,jvp_direct_native_qualified_cases_each=2184,
    jvp_independent_math_controls_each=88,jvp_explicit_unsupported_hook_cases_each=32,

    current_frontend_commands=local['frontend_commands'],raw_archive=archive,
    source_report_sha256=sha(repo/'packages/stridetorch/benchmarks/results/iteration-72.json'),
    guarded_push=push,generated_worker_derivation=worker,qualified_ignored_build_derivatives=derivatives,
    actions_at_verified_shas=runs,
    workflows_dispatched=False,tags_created=False,package_published=False,deployment_requested=False,
    scope='Guarded ordinary main push; exact remote ref, tested Git blobs, generated worker derivatives and prior immutable assets verified. Actions observations apply at verification time only.')
if final:
    save(p/'final-adoption-verification.json',report)
else:
    save(repo/'packages/stridetorch/benchmarks/results/iteration-72-main-adoption.json',report)
    doc=repo/'docs/validation/torch-runtime-iteration-72.md'
    doc.write_text(doc.read_text()+'\n## Main adoption\n\nVersion 0.72.0 was adopted on main at `'+adopted+
        '`. The guarded ordinary push passed with no active release chain. The remote ref and '+str(len(expected))+
        ' tested Git blobs were verified, together with generated Worker derivatives and all '+format(len(old),',')+
        ' prior immutable asset tree entries. The adopted SHA had zero Actions runs at verification. No workflow dispatch, tag, package publication or deployment was initiated. '+
        '[Adoption receipt](../../packages/stridetorch/benchmarks/results/iteration-72-main-adoption.json).\n')
    save(p/'adoption-verification.json',report)
print(json.dumps(dict(status=report['status'],head=target,git_blobs=len(expected),preserved_assets=len(old),actions=runs)),flush=True)
