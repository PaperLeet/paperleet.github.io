"""Close exact-source application validation and preserve the complete0.72 evidence."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,tarfile

p=Path(__file__).resolve().parent;r=p.parent
repo=Path('/Users/david/Developer/PaperLeet-torch-release')
out=repo/'packages/stridetorch/benchmarks/results';out.mkdir(exist_ok=True)
read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
save=lambda q,value:q.write_text(json.dumps(value,indent=2)+'\n')
local=read(p/'local-validation.json');assert local['status']=='passed'
selected=r/'selected-release';freeze=read(selected/'source-freeze.json')
source=read(p/'source-hashes.json');tests=read(p/'test-hashes.json')
assert freeze['version']=='0.72.0' and source==freeze['source_hashes'] and tests==freeze['test_hashes']
for name,digest in source.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==digest
for name,digest in tests.items():assert sha(repo/'packages/stridetorch/tests'/name)==digest
for name,digest in freeze['package_hashes'].items():assert sha(repo/'packages/stridetorch'/name)==digest
core=read(selected/'core-and-package-proof.json')
assert core['status']=='selected_version_cpu_native_wasm_and_package_passed' and core['source_hashes']==source and core['test_hashes']==tests
for name,digest in core['evidence_sha256'].items():assert sha(selected/name)==digest
extra_boundary=read(selected/'captured-vector-mutation-boundary.json')
assert extra_boundary['status']=='explicit_unsupported_boundary_verified' and extra_boundary['cases']==4 and extra_boundary['source_hashes']==source
for name,digest in extra_boundary['evidence_sha256'].items():assert sha(r/name)==digest
package=read(selected/'package-proof/package-identity.json')
assert package['status']=='success' and package['standalone_installed_tests']==8723 and package['native_torch'] is False
for name,digest in package['application_source_hashes'].items():assert sha(repo/name)==digest
for name,digest in package['artifacts'].items():assert sha(selected/'package-proof'/name)==digest
wasm=read(p/'full-wasm-result.json');count=local['catalog_modules']
assert wasm['passed'] and wasm['modules']==wasm['catalog_modules']==count and len(wasm['results'])==count
assert all(row['passed'] and not row['browser_budget_exceeded'] for row in wasm['results'])
contracts=next(row for row in wasm['results'] if row['id']=='architecture/attention')['independent_contracts']
assert contracts['passed']==8710 and len(contracts['suites'])==73
assert {row['suite']:row['source_sha256'] for row in contracts['suites']}=={n:h for n,h in tests.items() if n!='test_standalone.py'}
cpu=read(p/'cpu-receipt.json');assert cpu['exit_code']==0 and cpu['source_hashes']==source
cpu_text=(p/'cpu.log').read_text();assert 'FAILED ' not in cpu_text
cpu_counts=[int(n) for n in re.findall(r'(\d+) passed',cpu_text)];assert len(cpu_counts)==1
formal=read(r/'performance/summary.json');memory=read(r/'performance/api-memory.json')
review=read(p/'performance-reviewed.json')
assert formal['status']=='completed' and formal['fresh_children']==18 and formal['flows_per_child']==27 and len(formal['rows'])==81
assert formal['source_hashes']['candidate']==memory['source_hashes']['candidate']==source
assert memory['status']=='passed' and len(memory['rows'])==10
assert review['proceed_local_validation'] and review['performance_sha256']==sha(r/'performance/summary.json') and review['memory_sha256']==sha(r/'performance/api-memory.json')
if 'controls_sha256' in review:assert review['controls_sha256']==sha(r/review['controls_path'])
worker=read(p/'generated-worker-proof.json');assert worker['status']=='verified'
for name,digest in worker['inputs'].items():assert sha(repo/name)==digest
assert sha(repo/worker['generated_module'])==worker['generated_module_sha256']
assert sha(repo/worker['asset'])==worker['asset_sha256']
policy=read(p/'release-policy-identity.json')
for group in [policy['files'],policy['workflows']]:
    for name,digest in group.items():assert sha(repo/name)==digest
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head==local['upstream']
export=read(p/'export-identity.json');assert export['version']=='0.72.0' and export['source_hashes']==source
for name,digest in read(p/'baseline-immutable-sha256.json').items():assert sha(repo/name)==digest
for name,digest in read(p/'live-export-sha256.json').items():assert sha(repo/'web/public/data'/name)==digest
snapshot=p/'published-inputs';snapshot.mkdir()
for name,target in [('src/stridetorch','runtime-source'),('tests','runtime-tests')]:
    shutil.copytree(repo/'packages/stridetorch'/name,snapshot/target,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
for name in ['README.md','pyproject.toml','LICENSE','NOTICE']:shutil.copy2(repo/'packages/stridetorch'/name,snapshot/name)
checkpoint=read(r/'state.json')
save(p/'state-before-local-close.json',checkpoint)
checkpoint.update(status='all_072_local_application_gates_passed',active_processes=[],main_adopted=False,goal_status='active',
                  full_cpu_passed=cpu_counts[0],full_wasm_modules=count,full_wasm_mutants=local['mutants'])
for name in ['state.json','continuation-latest.json']:save(r/name,checkpoint)
archive=out/'iteration-72-harness.tar.xz';assert not archive.exists()
seen={};payloads={};hardlinks=0;logical_bytes=0
excluded={'__pycache__','.pytest_cache','.git','pytest-tmp','sdk-pytest-tmp','node_modules','build','dist'}
allowed={'.py','.mjs','.json','.log','.md','.html','.toml','.npz','.txt','.whl','.pkl','.patch','.in','.ini','.yaml','.yml','.csv','.cjs','.ts','.tsx','.css'}
with tarfile.open(archive,'w:xz',preset=6) as target:
    for current,dirs,files in os.walk(r):
        dirs[:]=sorted(n for n in dirs if n not in excluded and not n.endswith(('-env','-venv','.egg-info')))
        for name in sorted(files):
            q=Path(current)/name
            if q.is_symlink() or not(q.name in ['LICENSE','NOTICE','.gitignore'] or q.suffix in allowed or q.name.endswith('.tar.gz')):continue
            arc=str(q.relative_to(r));digest=sha(q);payloads[arc]=digest
            info=target.gettarinfo(str(q),arcname=arc);logical_bytes+=q.stat().st_size
            key=(digest,info.mode,info.uid,info.gid,info.uname,info.gname)
            if key in seen:
                info.type=tarfile.LNKTYPE;info.linkname=seen[key];info.size=0;target.addfile(info);hardlinks+=1
            else:
                seen[key]=arc
                with q.open('rb') as data:target.addfile(info,data)
with tarfile.open(archive,'r:xz') as target:
    assert len(target.getmembers())==len(payloads)
    for member in target.getmembers():assert hashlib.sha256(target.extractfile(member).read()).hexdigest()==payloads[member.name]
identity=dict(name=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),files=len(payloads),unique_payloads=len(seen),
              hardlinks=hardlinks,logical_bytes=logical_bytes,all_logical_payloads_verified=True,filesystem_timestamps_not_comparison_inputs=True)
assert identity['bytes']<95*1024*1024;save(p/'archive-identity.json',identity)
report=dict(status='validated_locally',version='0.72.0',baseline_version='0.71.0',upstream=head,source_hashes=source,test_hashes=tests,
 full_cpu=dict(**cpu,passed=cpu_counts[0]),full_wasm=wasm,independent_package=package,core_package_qualification=core,
 local_integration=local,export_identity=export,active_export_sha256=read(p/'live-export-sha256.json'),
 owned_inputs=read(p/'owned-input-sha256.json'),release_policies=policy,generated_worker_derivation=worker,
 performance=formal,performance_review=review,cpu_allocations=memory,raw_archive=identity,
 numerical_scope=dict(jvp_cases_per_runtime=2304,direct_native_qualified=2184,independent_math_controls=88,explicit_unsupported_hooks=32,
                      legacy_hvp_cases_per_runtime=720,legacy_hvp_direct_native=676,legacy_hvp_precision=4,legacy_hvp_polynomial=40),
 additional_cpu_unsupported_boundary=extra_boundary,
 limitations=['Real float32/64 functionalJVP with ordinary reverse queries of returned graphs; no general higher-order reverse AD,complex/nested transforms,callback hook registration,in-place Tensor mutations inside forward AD or GPU backend.',
 '88JVP cases use explicit mathematical controls for qualified fused-normalization/singular-determinant graph discrepancies;32callback hook combinations explicitly reject. Not literal native graph equivalence.',
 'Seven newJVP performance references are independently qualified pure-callback compositions of released0.71 publicAD primitives,not an existing0.71functionalJVP API.',
 'CPU allocation peaks are one process,ten specific API workflows,six balanced call orders. Not RSS,WASM/GPU memory,latency or universal gains.',
 'Archive preserves prototypes,failed comparisons and source identities. Scripts retain absolute paths and require dependency setup/path adjustment.',
 'Local validation does not imply main adoption,CI,release or deployment.'])
save(out/'iteration-72.json',report)
save(p/'state.json',dict(status='all_local_gates_passed',version='0.72.0',upstream=head,source_hashes=source,main_adopted=False))
print(json.dumps(dict(status=report['status'],cpu_passed=cpu_counts[0],wasm_modules=count,mutants=local['mutants'],archive=identity)),flush=True)
