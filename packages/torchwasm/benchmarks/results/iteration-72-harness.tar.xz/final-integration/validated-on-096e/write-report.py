"""Render the human0.72 report from verified terminal evidence only."""
from pathlib import Path
import json
p=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
report=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-72.json').read_text())
assert report['status']=='validated_locally' and report['version']=='0.72.0'
local=report['local_integration'];archive=report['raw_archive'];rows=report['performance']['rows']
legacy=[];jvp=[]
for runtime in ['cpu','node','chrome']:
    selected=[row for row in rows if row['runtime']==runtime and row['family']!='functional_jvp'];assert len(selected)==20
    def span(key):
        values=[row['medians'][key] for row in selected];return f'{min(values):.4f}–{max(values):.4f}'
    legacy.append(f"| {runtime} | {span('candidate_over_baseline')} | {span('duplicate_over_baseline')} | {span('candidate_over_duplicate')} |")
    for row in rows:
        if row['runtime']!=runtime or row['family']!='functional_jvp':continue
        ratios=row['medians'];ns=row['median_ns']
        jvp.append(f"| {runtime} | {row['case']} | {ratios['duplicate_over_baseline']:.4f} | {ratios['candidate_over_baseline']:.4f} | {ratios['candidate_over_duplicate']:.4f} | {ns['baseline']/1000:.2f} → {ns['candidate']/1000:.2f} |")
memory=[]
for row in report['cpu_allocations']['rows']:
    memory.append(f"| {row['case']} | {row['duplicate_over_baseline_peak']:.4f} | {row['candidate_over_baseline_peak']:.4f} |")
text=f'''# Torch runtime iteration 72: functional JVP and returned reverse graphs

Version 0.72 adds `torch.autograd.functional.jvp(func, inputs, v=None,
create_graph=False, strict=False)` for the supported real float32/float64
operators. Tensor/flat-tuple input and output structure is preserved. The callback
runs once; processed arguments isolate repeated inputs and captured originals.
Original gradient flags, existing gradient buffers and original argument hooks
remain intact during the API's internal work.

Default results are detached. `create_graph=True` enables ordinary reverse
queries of the returned value and directional derivative. This does not enable
general `autograd.grad(create_graph=True)`, arbitrary higher-order reverse AD,
complex differentiation, nested forward transforms or unvalidated forward rules.
Registering gradient hooks inside the callback explicitly rejects because such
hooks can change reverse-based JVP values.

Strict mode tracks Jacobian dependencies of every input and output, including
zero directions. Private vector leaves cannot make a constant Jacobian appear
naturally differentiable. Differentiable captured weights remain valid. Empty
sums and empty determinants retain their different strict and graph semantics.

Normalization/matrix-factor graphs remain differentiable where requested.
Default normalization JVP avoids building the additional higher-order graphs.
Singular determinant directions use cofactors; 1x1 determinant directions keep
their symbolic zero reverse edge. Ordinary `torch.func.jvp`, production Torch 2.6
inclusive clamp boundaries and existing functional HVP behavior remain qualified
by the old SDK/model fixtures and the full application checks below.

## Reference boundaries

The JVP inventory has **2,304 cases per CPU/Node/Chrome runtime**:

- 2,184 directly native-qualified cases, including expected errors.
- 48 fused-normalization graph cases use independent complex-step derivatives,
  validated by full-coordinate native FP64 two-step finite differences.
- 40 singular determinant graph cases use an independent permutation-polynomial
  reference. Five fixture families in both rounded-FP32/lifted-FP64 and FP64 are
  additionally validated against native FP64 JVP value differences for every
  matrix/vector coordinate of both scalar outputs. Native returned reverse
  graphs can give zero gradients or SVD-tape NaNs on these fixtures; the library
  deliberately provides their mathematical cofactor/curvature derivatives.
- 32 callback hook combinations explicitly raise `BrowserUnsupported`.

Four additional CPU boundary probes confirm that `Tensor.add_` on captured
vectors before or after constructing the callback output explicitly rejects in
both graph modes. These are separate unsupported-operation checks, not part of
the 2,304-case inventory or a native-compatible feature claim.

Raw native disagreements, rejected prototypes, source identities and original
tolerances are retained. These mathematical controls are not literal native
graph matches. The adopted 0.71 HVP inventory is also replayed on this source in
CPU/Node/Chrome: 720 cases each, comprising 676 direct native cases, four explicit
precision controls and 40 finite polynomial extensions to native SVD-tape NaNs.

## Final-version verification

| Gate | Result |
| --- | --- |
| Minimum installed standalone wheel | 8,723 tests; Python 3.10.19, NumPy 1.26.4, no native Torch |
| Node / Chrome Pyodide SDK | 8,710 tests and 73 suites each; Pyodide 0.29.4, NumPy 2.2.5 |
| Installed package ownership | Wheel/sdist identities, coinstall, separate uninstall, aliases, checkpoints and fresh-process JVP operator pickle |
| Current application CPU | {report['full_cpu']['passed']:,} passed |
| Full browser catalog | {local['catalog_modules']} modules, {local['mutants']} mutants; no failed cases or browser-budget overruns |
| Frontend | {local['frontend_commands']} check commands, Worker derivation and two build profiles |
| Existing immutable export assets | {report['export_identity']['preserved_assets']:,} preserved byte-for-byte |
| New export assets | {report['export_identity']['new_assets']} reachable content-addressed assets |

The integration base is `{report['upstream']}`. All application/frontend inputs
and seven canonical release-policy files were checked against their recorded
identities. Generated Worker files are verified by exact esbuild derivation,
separately from tracked source files. No CI, tag, release or deployment is part
of this local validation. Remote main adoption is recorded separately.

## CPU and WASM latency

Six fresh processes per runtime exercise all six source-load permutations,
twelve balanced common batches of at least 20 ms per workflow, and a same-source
duplicate. Every child runs numerical, dtype/shape, alias and caller-state checks
before timing. A is released 0.71, A′ is its same-source control, B is selected
0.72. Ratios below one mean shorter measured duration. Interpret both denominators
and the explicit performance review; these measurements do not establish
universal gains or native-Torch/GPU/cold-start performance.

Twenty existing public API workflows use the same public APIs on both sides:

| Runtime | B/A median range | A′/A median range | B/A′ median range |
| --- | --- | --- | --- |
{chr(10).join(legacy)}

The seven new functional-JVP workflows compare B with explicitly isolated
compositions of released 0.71 public AD primitives. They are independently
validated for these pure callbacks only; 0.71 has no functional-JVP API.

| Runtime | Workflow | A′/A | B/A | B/A′ | A → B μs |
| --- | --- | --- | --- | --- | --- |
{chr(10).join(jvp)}

## CPU allocation peaks

One CPU process uses six balanced call orders after every latency child has
terminated. These are `tracemalloc` peaks for ten particular API workflows,
including retained result graphs when requested. They are not RSS, WASM/GPU
memory, latency, isolated-cause evidence or universal improvement claims.

| Workflow | A′/A peak | B/A peak |
| --- | --- | --- |
{chr(10).join(memory)}

Earlier optimization timings remain attached to their original prototype source
freezes and do not substitute for these selected-source measurements.

## Reproduction evidence

Machine evidence: `packages/stridetorch/benchmarks/results/iteration-72.json`.
Raw harness: `{archive['name']}`, {archive['bytes']:,} bytes,
SHA-256 `{archive['sha256']}`. It retains {archive['files']:,} logical files,
{archive['unique_payloads']:,} unique mode/ownership-compatible payloads and
{archive['hardlinks']:,} deduplicated hardlinks. Every extracted logical payload
was verified against its original digest. Scripts retain absolute paths and
require dependency setup/path adjustment; no virtual environments are bundled.
'''
(repo/'docs/validation/torch-runtime-iteration-72.md').write_text(text)
print('Wrote exact-source0.72 human validation report')
