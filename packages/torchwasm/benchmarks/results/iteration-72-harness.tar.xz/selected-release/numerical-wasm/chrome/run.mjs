import {withFixtureServer} from '../../../../torch-iteration-70/fixture-server.mjs';
import fs from 'node:fs';import assert from 'node:assert/strict';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
await withFixtureServer(async origin=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 try{
  const page=await browser.newPage();
  await page.goto(origin+'/torch-iteration-72/selected-release/numerical-wasm/chrome/');
  const result=await page.evaluate(()=>new Promise((resolve,reject)=>{
   const worker=new Worker('./worker.mjs',{type:'module'});
   const timer=setTimeout(()=>{worker.terminate();reject(Error('JVP replay exceeded180seconds'));},180000);
   worker.onmessage=({data})=>{clearTimeout(timer);worker.terminate();resolve(data);};
   worker.onerror=e=>{clearTimeout(timer);worker.terminate();reject(Error(e.message));};worker.postMessage({});
  }));
  result.browser=browser.version();
  fs.writeFileSync(new URL('./result.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify({status:result.status,cases:result.cases,counts:result.counts,failures:result.failures?.length,error:result.error}));
  assert(!result.error);assert.equal(result.status,'success');assert.equal(result.cases,2304);
 }finally{await browser.close();}
});
