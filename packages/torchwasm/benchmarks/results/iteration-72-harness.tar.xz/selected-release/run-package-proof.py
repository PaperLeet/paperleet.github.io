from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path(__file__).resolve().parent
repo = root / 'snapshot'
proof = root / 'package-proof'
python = root.parent.parent / 'torch-iteration-69/integration-dev-env/bin/python'
uv = '/Users/david/.local/bin/uv'
expected = json.loads((proof / 'source-hashes.json').read_text())
env = dict(os.environ, OMP_NUM_THREADS='2', MKL_NUM_THREADS='2',
           OPENBLAS_NUM_THREADS='2', VECLIB_MAXIMUM_THREADS='2')
env.pop('PYTHONPATH', None)
receipts = []

def run(label, args, cwd):
    started = time.time()
    with (proof / (label + '.log')).open('w') as log:
        subprocess.run(list(map(str, args)), cwd=cwd, env=env,
                       stdout=log, stderr=subprocess.STDOUT, check=True)
    receipts.append(dict(label=label, status='success', seconds=time.time() - started))
    (proof / 'package-receipts.json').write_text(json.dumps(receipts, indent=2) + '\n')
    print(label, 'PASS', flush=True)

run('build-standalone', [uv, 'build', '--python', python, '--no-build-isolation',
                       '--out-dir', proof / 'dist-preflight',
                       repo / 'packages/stridetorch'], repo)
run('build-application', [uv, 'build', '--python', python, '--no-build-isolation',
                        '--out-dir', proof / 'private-dist', repo], repo)
import zipfile
app_expected = json.loads((proof / 'application-source-hashes.json').read_text())
private_wheel = next((proof / 'private-dist').glob('*.whl'))
with zipfile.ZipFile(private_wheel) as archive:
    actual = {name: hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist()
              if name.startswith('paperleet/') and not name.startswith('paperleet/_vendor/torch/')}
    assert actual == app_expected

run('minimum-wheel-and-sdist', [python, proof / 'check-wheel.py'], repo)
run('coinstall-ownership-aliases-checkpoints', [python, proof / 'check-coinstall.py'], repo)
public = next((proof / 'dist-preflight').glob('*.whl'))
installed = proof / 'coinstall-env/bin/python'
run('restore-standalone-for-fresh-pickle',
    [uv, 'pip', 'install', '--python', installed, '--no-deps', public], proof)
for name in ['stridetorch', 'paperleet._vendor.torch']:
    path = proof / (name.replace('.', '-') + '-activation.pkl')
    assert path.is_file()
    run('fresh-pickle-' + name.replace('.', '-'),
        [installed, '-I', proof / 'fresh-load.py', name, path], proof)
check = (
    "import pathlib,hashlib,json,importlib,importlib.util;"
    "expected=json.loads(pathlib.Path('source-hashes.json').read_text());"
    "names=['stridetorch','paperleet._vendor.torch'];"
    "actual={name:{p.name:hashlib.sha256(p.read_bytes()).hexdigest() "
    "for p in pathlib.Path(importlib.import_module(name).__file__).parent.iterdir() "
    "if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']} for name in names};"
    "assert all(value==expected for value in actual.values());"
    "assert importlib.util.find_spec('torch') is None;print('Both installed namespaces retain exact source identity')"
)
run('final-installed-identities', [installed, '-I', '-c', check], proof)
co = json.loads((proof / 'coinstall-result.json').read_text())
wheel = json.loads((proof / 'wheel-stride072-result.json').read_text())
assert co['status'] == wheel['status'] == 'success'
assert co['source_hashes'] == wheel['source_hashes'] == expected
assert '8723 passed' in (proof / 'python310-stride072-tests.log').read_text()
artifacts = {str(path.relative_to(proof)): hashlib.sha256(path.read_bytes()).hexdigest()
             for directory in ['dist-preflight', 'private-dist']
             for path in (proof / directory).iterdir() if path.is_file()}
(proof / 'package-identity.json').write_text(json.dumps(dict(
    status='success', source_hashes=expected, standalone_installed_tests=8723,
    application_source_hashes=app_expected,
    python='3.10.19', numpy='1.26.4', native_torch=False, artifacts=artifacts,
    receipts=receipts,
    scope='Actual current application including GraphSAGE interview catalog, version0.72.0 runtime and final README in standalone/application wheels; '
          'minimum NumPy-only standalone test suite, uninstall ownership, aliases, '
          'checkpoint resume and fresh-process activation,VJP,Jacobian,HVP andfunctionalJVP operator pickle. '
          'Not an installed full-application dependency gate or a release.'
), indent=2) + '\n')
print('ALL INSTALLED PACKAGE AND PICKLE CHECKS PASS', flush=True)
