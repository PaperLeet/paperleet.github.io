"""Validated new-API workflows versus explicit released0.71 public-AD compositions."""
def build_functional_jvp(module,case,candidate):
 t=module.torch;rng=np.random.default_rng(7231);counter=[0];graph=case=='functional_jvp_graph_scalar'
 if case in ['functional_jvp_scalar','functional_jvp_graph_scalar','functional_jvp_unused']:
  arrays=[np.sin(np.arange(64)*.17)];vectors=[np.cos(np.arange(64)*.11)];dtype='float64'
  if case=='functional_jvp_unused':arrays.append(np.cos(np.arange(64)*.19));vectors.append(np.sin(np.arange(64)*.07))
  def raw(a,*unused):return a.sin()*a.square()
  a=arrays[0];e=vectors[0];y=np.sin(a)*a*a;first=2*a*np.sin(a)+a*a*np.cos(a)
  expected=(y,first*e)
  if graph:
   second=2*np.sin(a)+4*a*np.cos(a)-a*a*np.sin(a)
   reverse_expected=(2*y*first+2*expected[1]*second*e,2*expected[1]*first)
 elif case=='functional_jvp_linear':
  arrays=[rng.normal(size=s).astype('float32')*.2 for s in [(16,32),(8,32),(8,)]]
  vectors=[rng.normal(size=a.shape).astype('float32') for a in arrays];dtype='float32'
  def raw(a,w,b):return t.nn.functional.linear(a,w,b).tanh()
  a,w,b=[v.astype('float64') for v in arrays];da,dw,db=[v.astype('float64') for v in vectors]
  y=np.tanh(a@w.T+b);expected=(y,(da@w.T+a@dw.T+db)*(1-y*y))
 else:
  shape=(8,16) if case=='functional_jvp_layernorm' else (2,4,8,8)
  width=shape[-1] if case=='functional_jvp_layernorm' else shape[1]
  arrays=[rng.normal(size=s).astype('float32')*.2 for s in [shape,(width,),(width,)]]
  vectors=[rng.normal(size=a.shape).astype('float32') for a in arrays];dtype='float32'
  if case=='functional_jvp_layernorm':
   def raw(a,w,b):return t.nn.functional.layer_norm(a,(width,),w,b,eps=1e-5)
   axes=(-1,);broadcast=(1,width)
  elif case=='functional_jvp_batchnorm':
   def raw(a,w,b):return t.nn.functional.batch_norm(a,None,None,w,b,training=True,eps=1e-5)
   axes=(0,2,3);broadcast=(1,width,1,1)
  else:
   assert case=='functional_jvp_instancenorm'
   def raw(a,w,b):return t.nn.functional.instance_norm(a,weight=w,bias=b,eps=1e-5)
   axes=(2,3);broadcast=(1,width,1,1)
  a,w,b=[v.astype('float64') for v in arrays];da,dw,db=[v.astype('float64') for v in vectors]
  centered=a-a.mean(axis=axes,keepdims=True);centered_direction=da-da.mean(axis=axes,keepdims=True)
  inv=1/np.sqrt(np.mean(centered*centered,axis=axes,keepdims=True)+1e-5)
  normalized=centered*inv
  dnormalized=centered_direction*inv-centered*inv**3*np.mean(centered*centered_direction,axis=axes,keepdims=True)
  expected=(normalized*w.reshape(broadcast)+b.reshape(broadcast),
            dnormalized*w.reshape(broadcast)+normalized*dw.reshape(broadcast)+db.reshape(broadcast))
 values=tuple(t.tensor(a,dtype=getattr(t,dtype),requires_grad=graph or bool(i%2)) for i,a in enumerate(arrays))
 directions=tuple(t.tensor(a,dtype=getattr(t,dtype),requires_grad=True) for a in vectors)
 originals=(*values,*directions);buffers=[];hooks=[]
 for value in originals:
  value.grad=t.full_like(value,17.);buffers.append(value.grad)
  if value.requires_grad:value.register_hook(lambda gradient:hooks.append(gradient))
 def callback(*args):counter[0]+=1;return raw(*args)
 def fn():
  if candidate:return t.autograd.functional.jvp(callback,values,directions,create_graph=graph)
  # Released0.71 has no functional.jvp. Only these independently checked pure
  # callbacks use this public-API composition; no generic equivalence claim.
  with t.enable_grad():
   args=tuple(a.view_as(a) if graph and a.requires_grad else a.detach().requires_grad_(True) for a in values)
   seeds=tuple(a.view_as(a) if graph and a.requires_grad else a.detach() for a in directions)
   y,d=t.func.jvp(callback,args,seeds)
   return (y,d) if graph else (y.detach(),d.detach())
 def capture():
  before=counter[0];y,d=fn();assert counter[0]==before+1 and not hooks
  for actual,target in zip((y,d),expected):
   np.testing.assert_allclose(actual.detach().numpy(),target,rtol=3e-5 if dtype=='float32' else 3e-11,atol=3e-6 if dtype=='float32' else 3e-11)
  assert y.requires_grad==d.requires_grad==graph
  result=[y.detach().numpy().copy(),d.detach().numpy().copy()]
  if graph:
   reverse=t.autograd.grad(y.square().sum()+d.square().sum(),(values[0],directions[0]),retain_graph=True)
   for actual,target in zip(reverse,reverse_expected):np.testing.assert_allclose(actual.numpy(),target,rtol=3e-11,atol=3e-11)
   result.extend(a.numpy().copy() for a in reverse)
  for value,buffer,data in zip(originals,buffers,(*arrays,*vectors)):
   assert value.grad is buffer
   np.testing.assert_array_equal(value.grad.numpy(),np.full(value.shape,17.))
   np.testing.assert_array_equal(value.detach().numpy(),data)
  # Original hooks fire only for the explicit reverse query above.
  hooks.clear()
  return result
 return fn,capture,dtype
