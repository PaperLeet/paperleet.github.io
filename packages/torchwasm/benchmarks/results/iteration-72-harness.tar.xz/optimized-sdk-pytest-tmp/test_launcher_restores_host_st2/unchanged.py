import torch
assert torch.Tensor is not None
raise RuntimeError("script failure")