import torch
assert torch.Tensor is not None
