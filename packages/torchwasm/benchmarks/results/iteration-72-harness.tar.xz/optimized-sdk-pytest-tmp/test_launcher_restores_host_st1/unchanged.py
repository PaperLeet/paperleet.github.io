import torch
assert torch.Tensor is not None
raise SystemExit(7)