"""Small determinant/JVP polynomial reference, independent of SVD/solve rules."""
import itertools
import numpy as np


def fixture(case, dtype):
    matrices = {'det_zero1': [[0.]], 'det_rank1_2': [[1., 2.], [2., 4.]],
                'det_squared_rank1_2': [[1., 2.], [2., 4.]],
                'det_rank2_3': [[1., 0., 0.], [0., 1., 0.], [0., 0., 0.]],
                'det_rank1_3': [[1., 0., 0.], [0., 0., 0.], [0., 0., 0.]]}
    a = np.asarray(matrices[case], dtype=dtype).astype(np.float64)
    e = np.cos(np.arange(a.size)).reshape(a.shape).astype(dtype).astype(np.float64)
    return a, e


def reference(a, e, squared=False):
    n = len(a)
    value = 0.
    directional = 0.
    gradient = np.zeros_like(a)
    curvature = np.zeros_like(a)
    for columns in itertools.permutations(range(n)):
        inversions = sum(columns[i] > columns[j] for i in range(n) for j in range(i + 1, n))
        sign = (-1.) ** inversions
        product = lambda excluded: np.prod([a[i, columns[i]] for i in range(n) if i not in excluded])
        value += sign * product(())
        for i in range(n):
            partial = sign * product((i,))
            gradient[i, columns[i]] += partial
            directional += partial * e[i, columns[i]]
            for j in range(n):
                if i != j:
                    curvature[i, columns[i]] += sign * e[j, columns[j]] * product((i, j))
    if squared:
        curvature = 2 * directional * gradient + 2 * value * curvature
        gradient = 2 * value * gradient
        directional = 2 * value * directional
        value = value ** 2
    return dict(values=[value, directional], primal_gradient=gradient,
                tangent_gradient=curvature, vector_gradient=gradient)
