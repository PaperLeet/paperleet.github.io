"""Native graph-producing functional JVPs and their two reverse channels."""
import json, contextlib
import numpy as np
import torch

def tensor_record(value):
    if value is None: return None
    if isinstance(value, tuple): return [tensor_record(item) for item in value]
    return dict(shape=list(value.shape), dtype=str(value.dtype).split('.')[-1],
                requires_grad=value.requires_grad, values=value.detach().numpy().tolist())

rows = []
cases = ['linear', 'layernorm', 'groupnorm', 'conv2d', 'attention', 'multihead',
         'inverse', 'cholesky', 'slogdet', 'classifier', 'batchnorm_train', 'embedding',
         'relu_linear', 'abs_linear', 'clamp_linear', 'linear_plain',
         'solve', 'solve_right', 'solve_triangular', 'det', 'logdet',
         'instancenorm_train', 'rmsnorm', 'gelu', 'batchnorm_eval', 'instance_eval']
for dtype in [torch.float32, torch.float64]:
    for strict in [False, True]:
        for strided, vector_grad in [(a,b) for a in [False,True] for b in [False,True]]:
            for case in cases:
                rng = np.random.default_rng(7021)
                inputs = []
                def value(shape, positive=False):
                    array = (rng.normal(size=shape) * .2).astype('float32' if dtype == torch.float32 else 'float64')
                    if positive: array += np.eye(shape[-1], dtype=array.dtype) * 2
                    if strided:
                        storage = np.empty(shape + (2,), dtype=array.dtype)
                        storage[..., 0] = array
                        storage[..., 1] = -7
                        array = storage[..., 0]
                    tensor = torch.from_numpy(array).requires_grad_(len(inputs) % 2 == 0)
                    inputs.append(tensor)
                    return tensor
                model = None
                if case in ['relu_linear','abs_linear','clamp_linear','linear_plain']:
                    value((2, 3))
                    if case == 'relu_linear': fn = lambda a: a.relu()
                    elif case == 'abs_linear': fn = lambda a: a.abs()
                    elif case == 'clamp_linear': fn = lambda a: a.clamp(-.1,.1)
                    else: fn = lambda a: a * 2
                elif case in ['solve','solve_right','solve_triangular']:
                    value((2,2),True); value((2,2))
                    if case == 'solve_triangular': fn = lambda a,b: torch.linalg.solve_triangular(a,b,upper=True)
                    else: fn = lambda a,b: torch.linalg.solve(a,b,left=case=='solve')
                elif case in ['det','logdet']:
                    value((2,2),True)
                    fn = torch.det if case == 'det' else torch.logdet
                elif case == 'instancenorm_train':
                    value((2,2,3)); value((2,)); value((2,))
                    fn = lambda a,w,b: torch.nn.functional.instance_norm(a,weight=w,bias=b)
                elif case == 'rmsnorm':
                    value((2,3));value((3,))
                    fn = lambda a,w: torch.nn.functional.rms_norm(a,(3,),w,eps=1e-5)
                elif case == 'gelu':
                    value((2,3));fn = torch.nn.functional.gelu
                elif case == 'instance_eval':
                    value((2,2,3));model = torch.nn.InstanceNorm1d(2,affine=True,track_running_stats=True,dtype=dtype).eval();fn=model
                elif case == 'linear':
                    value((2, 3)); value((2, 3)); value((2,))
                    fn = lambda a, w, b: torch.nn.functional.linear(a, w, b).tanh()
                elif case == 'layernorm':
                    value((2, 3)); value((3,)); value((3,))
                    fn = lambda a, w, b: torch.nn.functional.layer_norm(a, (3,), w, b)
                elif case == 'groupnorm':
                    value((1, 4, 2)); value((4,)); value((4,))
                    fn = lambda a, w, b: torch.nn.functional.group_norm(a, 2, w, b)
                elif case == 'conv2d':
                    value((1, 1, 3, 3)); value((1, 1, 2, 2)); value((1,))
                    fn = lambda a, w, b: torch.nn.functional.conv2d(a, w, b)
                elif case == 'attention':
                    for _ in range(3): value((1, 1, 2, 2))
                    fn = lambda q, k, v: torch.nn.functional.scaled_dot_product_attention(q, k, v)
                elif case == 'multihead':
                    value((1, 2, 2))
                    model = torch.nn.MultiheadAttention(2, 1, dropout=0., batch_first=True, dtype=dtype)
                    fn = lambda a: model(a, a, a, need_weights=False)[0]
                elif case == 'inverse':
                    value((2, 2), True)
                    fn = lambda a: torch.linalg.inv(a)
                elif case in ['cholesky', 'slogdet']:
                    value((2, 2))
                    if case == 'cholesky': fn = lambda a: torch.linalg.cholesky(a @ a.T + torch.eye(2, dtype=dtype))
                    else: fn = lambda a: tuple(torch.linalg.slogdet(a @ a.T + torch.eye(2, dtype=dtype)))
                elif case == 'classifier':
                    value((2, 3))
                    model = torch.nn.Sequential(torch.nn.Linear(3, 2, dtype=dtype), torch.nn.Tanh(), torch.nn.Linear(2, 1, dtype=dtype))
                    fn = model
                elif case in ['batchnorm_train','batchnorm_eval']:
                    value((2, 2, 2))
                    model = torch.nn.BatchNorm1d(2, dtype=dtype)
                    if case == 'batchnorm_eval': model.eval()
                    fn = model
                else:
                    value((4, 2))
                    fn = lambda a: torch.nn.functional.embedding(torch.tensor([1, 1, 3]), a)
                parameters = list(model.parameters()) if model is not None else []
                with torch.no_grad():
                    for i, parameter in enumerate(parameters):
                        data = (np.sin(np.arange(parameter.numel()) * .13 + i) * .2).reshape(tuple(parameter.shape))
                        parameter.copy_(torch.tensor(data, dtype=dtype))
                vectors = tuple(torch.tensor(np.cos(np.arange(item.numel()) * .11 + i).reshape(item.shape), dtype=dtype,requires_grad=vector_grad) for i, item in enumerate(inputs))
                observed = inputs + parameters + list(vectors)
                snapshots = []
                hooks = []
                handles = []
                for i, item in enumerate(observed):
                    item.grad = torch.ones_like(item) * (i + 1)
                    snapshots.append((item.detach().clone(), item.grad, item.grad.clone(), item.requires_grad, item.stride()))
                    if item.requires_grad:
                        handles.append(item.register_hook(lambda grad, i=i: hooks.append(i)))
                calls = []
                def callback(*args):
                    calls.append(torch.is_grad_enabled())
                    with torch.nn.attention.sdpa_kernel([torch.nn.attention.SDPBackend.MATH]):
                        output = fn(*args)
                    if case.endswith('_linear') or case == 'linear_plain': return output.sum()
                    outputs = output if isinstance(output,tuple) else (output,)
                    return sum((i+1)*item.square().sum() for i,item in enumerate(outputs))
                row = dict(case=case, dtype=str(dtype).split('.')[-1], strict=strict, strided=strided, vector_grad=vector_grad, fixture_inputs=tensor_record(tuple(inputs)), fixture_vectors=tensor_record(vectors))
                try:
                    with torch.no_grad():
                        result = torch.autograd.functional.jvp(callback, tuple(inputs), vectors, create_graph=True, strict=strict)
                        assert not torch.is_grad_enabled()
                    row.update(status='success', result=tensor_record(result))
                except Exception as error:
                    row.update(status='error', exception=type(error).__name__, message=str(error))
                preserved = all(torch.equal(item.detach(), before) and item.grad is buffer and
                    torch.equal(item.grad, grad) and item.requires_grad == flag and item.stride() == strides
                    for item, (before, buffer, grad, flag, strides) in zip(observed, snapshots))
                row.update(calls=calls, hooks=list(hooks), caller_preserved=bool(preserved),
                    model_buffers={name: tensor_record(buffer) for name, buffer in model.named_buffers()} if model is not None else {})
                assert preserved and calls == [True] and not hooks
                if row['status']=='success':
                    active=tuple(item for item in observed if item.requires_grad)
                    names=['input:'+str(i) for i,item in enumerate(inputs) if item.requires_grad]
                    names+=['parameter:'+str(i) for i,item in enumerate(parameters) if item.requires_grad]
                    names+=['vector:'+str(i) for i,item in enumerate(vectors) if item.requires_grad]
                    reverse=[]
                    for component in result:
                        gradients=torch.autograd.grad(component,active,allow_unused=True,retain_graph=True) if component.requires_grad and active else (None,)*len(active)
                        reverse.append(dict(names=names,gradients=tensor_record(gradients)))
                    row['reverse_channels']=reverse
                    row['reverse_hook_counts']={str(i):hooks.count(i) for i,item in enumerate(observed) if item.requires_grad}
                    row['post_reverse_buffers_preserved']=all(item.grad is snapshot[1] and torch.equal(item.grad,snapshot[2]) for item,snapshot in zip(observed,snapshots))
                    assert row['post_reverse_buffers_preserved']
                for handle in handles: handle.remove()
                rows.append(row)
print(json.dumps(dict(torch=torch.__version__, native_git=torch.version.git_version,
                      sdpa_backend="math", cases=len(rows), rows=rows), allow_nan=False, indent=2))
