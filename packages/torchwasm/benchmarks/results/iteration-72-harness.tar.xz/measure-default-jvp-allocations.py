"""Bounded CPU allocation comparison after latency children are terminal."""
from pathlib import Path
import gc
import hashlib
import importlib.util
import itertools
import json
import statistics
import tracemalloc
import numpy as np

r=Path(__file__).resolve().parent
p=r/'default-jvp-optimization-performance'
read=lambda q:json.loads(q.read_text())
assert read(p/'summary.json')['status']=='completed'
receipts=read(p/'receipts.json');assert len(receipts)==6 and all(v['exit_code']==0 for v in receipts)
plan=read(p/'plan.json')
spec=importlib.util.spec_from_file_location('_jvp_optimization_allocations',r/'benchmark-default-jvp-optimization.py')
bench=importlib.util.module_from_spec(spec);spec.loader.exec_module(bench)
assert bench.manifest(bench.baseline)==plan['source_hashes']['baseline'] and bench.manifest(bench.candidate)==plan['source_hashes']['candidate']
apis={label:bench.load('_jvp_allocation_'+label,bench.candidate if label=='candidate' else bench.baseline) for label in bench.labels}
rows=[]
for case,graph in bench.flows:
    entries={label:bench.make(api,case,graph) for label,api in apis.items()}
    expected=[item.detach().item() for item in entries['baseline'][0]()]
    samples=[]
    for order in itertools.permutations(bench.labels):
        for label in order:
            gc.collect();tracemalloc.start();tracemalloc.reset_peak()
            values=entries[label][0]();current,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
            np.testing.assert_allclose([item.detach().item() for item in values],expected,rtol=1e-4,atol=3e-6)
            entries[label][1]()
            samples.append(dict(order=list(order),label=label,current_bytes=current,peak_bytes=peak))
            del values
    medians={label:statistics.median(v['peak_bytes'] for v in samples if v['label']==label) for label in bench.labels}
    rows.append(dict(case=case,create_graph=graph,samples=samples,median_peak_bytes=medians,
                     candidate_over_baseline_peak=medians['candidate']/medians['baseline'],
                     duplicate_over_baseline_peak=medians['duplicate']/medians['baseline']))
result=dict(status='passed',source_hashes=plan['source_hashes'],rows=rows,
    program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    scope='One CPU process,four bounded normalization flows,six balanced source-call orders and identical-source A/A. Tracked Python/NumPy allocations only,not RSS,WASM/GPU memory or latency. Compares unreleased prototypes.')
(p/'allocations.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps([dict(case=v['case'],graph=v['create_graph'],ratio=v['candidate_over_baseline_peak'],aa=v['duplicate_over_baseline_peak']) for v in rows]),flush=True)
