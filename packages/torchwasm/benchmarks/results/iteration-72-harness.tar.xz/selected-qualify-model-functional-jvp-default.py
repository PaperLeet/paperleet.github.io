"""Compare graph-producing JVPs and both reverse channels on model fixtures."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import numpy as np

r = Path(__file__).resolve().parent
p = r / 'selected-release/native-cpu/default-model-proof'
p.mkdir(parents=True,exist_ok=True)
source = r / 'selected-release/snapshot/packages/stridetorch/src'
sha = lambda q: hashlib.sha256(q.read_bytes()).hexdigest()
before = {q.name: sha(q) for q in (source / 'stridetorch').iterdir() if q.suffix == '.py' or q.name in ['LICENSE', 'NOTICE']}
program = (r / 'probe-model-functional-jvp-default.py').read_text().replace(
    'import torch', 'from stridetorch import torch, __version__ as library_version').replace(
    'torch.__version__', 'library_version').replace('torch.version.git_version', "'adapter-not-native'")
program = program.replace('torch.nn.attention.sdpa_kernel([torch.nn.attention.SDPBackend.MATH])',
                          'contextlib.nullcontext()')
(p / 'probe.py').write_text(program)
with (p / 'candidate.json').open('w') as output, (p / 'stderr.log').open('w') as error:
    child = subprocess.run([sys.executable, str(p / 'probe.py')], env=dict(
        os.environ, PYTHONPATH=str(source), PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='2',
        MKL_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', VECLIB_MAXIMUM_THREADS='2'),
        stdout=output, stderr=error)
child.check_returncode()
assert before == {q.name: sha(q) for q in (source / 'stridetorch').iterdir() if q.suffix == '.py' or q.name in ['LICENSE', 'NOTICE']}
native = json.loads((r / 'native-model-functional-jvp-default-torch26.json').read_text())
candidate = json.loads((p / 'candidate.json').read_text())
assert native['cases'] == candidate['cases'] == 416
maximum = 0.

def compare(a, b, dtype):
    global maximum
    if isinstance(a, dict):
        keys = set(a) - {'message'}
        assert keys == set(b) - {'message'}, (set(a), set(b))
        if 'values' in a:
            for key in ['shape', 'dtype', 'requires_grad']:
                assert a[key] == b[key], (key, a[key], b[key])
            x, y = np.asarray(a['values']), np.asarray(b['values'])
            np.testing.assert_allclose(y, x, rtol=1e-4 if dtype == 'float32' else 1e-8,
                                       atol=3e-6 if dtype == 'float32' else 2e-10)
            if x.size: maximum = max(maximum, float(np.max(np.abs(y-x))))
        else:
            for key in keys: compare(a[key], b[key], dtype)
    elif isinstance(a, list):
        assert len(a) == len(b)
        for x, y in zip(a, b): compare(x, y, dtype)
    else:
        assert a == b, (a, b)

failures = []
for a, b in zip(native['rows'], candidate['rows']):
    try:
        compare(a, b, a['dtype'])
    except (AssertionError, TypeError, KeyError) as error:
        failures.append(dict(case=a['case'], dtype=a['dtype'], strict=a['strict'],
                             strided=a['strided'], vector_grad=a['vector_grad'], error=str(error),
                             native=a, actual=b))
record = dict(status='failed' if failures else 'passed', cases=416, failures=failures,
              max_finite_abs_difference=maximum,
              source_hashes={q.name: sha(q) for q in (source / 'stridetorch').iterdir()
                             if q.suffix == '.py' or q.name in ['LICENSE', 'NOTICE']},
              native_sha256=sha(r / 'native-model-functional-jvp-default-torch26.json'),
              candidate_sha256=sha(p / 'candidate.json'), probe_sha256=sha(p / 'probe.py'),
              scope='Isolated functionalJVP prototype, graph-producing model and reverse-channel fixtures. '
                    'No full SDK, WASM, package, performance or main-adoption qualification.')
(p / 'qualification.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(dict(status=record['status'], cases=416, failures=len(failures),
                     failed_cases=sorted({row['case'] for row in failures}))), flush=True)
sys.exit(bool(failures))
