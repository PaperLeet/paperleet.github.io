"""Replay qualified CPU inventories on actual Pyodide, retaining every raw row."""
import ast
import hashlib
import json
import os
from pathlib import Path
import sys
import numpy as np

sys.path.insert(0,'/runtime')
plan=json.loads(plan_json)
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
actual={p.name:sha(p) for p in Path('/runtime/stridetorch').iterdir() if p.is_file()}
assert actual==plan['source']
for name,digest in plan['fixtures'].items():assert sha(Path('/runtime/fixtures')/name)==digest
import stridetorch
assert stridetorch.__version__==plan['version']
os.environ['STRIDE_PROBE']='1'


def compare(a,b,dtype,path=()):
    if isinstance(a,dict):
        assert set(a)-{'message'}==set(b)-{'message'},(path,set(a),set(b))
        if 'values' in a:
            for key in ['dtype','shape','requires_grad']:assert a[key]==b[key],(path,key,a[key],b[key])
            np.testing.assert_allclose(b['values'],a['values'],rtol=1e-4 if dtype=='float32' else 1e-8,
                                      atol=3e-6 if dtype=='float32' else 2e-10)
        else:
            for key in set(a)-{'message'}:compare(a[key],b[key],dtype,path+(key,))
    elif isinstance(a,list):
        assert len(a)==len(b),path
        for i,(x,y) in enumerate(zip(a,b)):compare(x,y,dtype,path+(i,))
    elif isinstance(a,(float,int)) and not isinstance(a,bool):
        np.testing.assert_allclose(b,a,rtol=1e-4 if dtype=='float32' else 1e-8,
                                  atol=3e-6 if dtype=='float32' else 2e-10)
    else:assert a==b,(path,a,b)


raw=[]
failures=[]
counts={}
for flow in plan['flows']:
    path=Path('/runtime/fixtures')/flow['program']
    tree=ast.parse(path.read_text())
    assert isinstance(tree.body[-1],ast.Expr) and isinstance(tree.body[-1].value,ast.Call)
    assert isinstance(tree.body[-1].value.func,ast.Name) and tree.body[-1].value.func.id=='print'
    tree.body[-1]=ast.Assign(targets=[ast.Name(id='_inventory_json',ctx=ast.Store())],value=tree.body[-1].value.args[0])
    ast.fix_missing_locations(tree)
    namespace={'__name__':'__main__','__file__':str(path)}
    exec(compile(tree,str(path),'exec'),namespace)
    result=json.loads(namespace['_inventory_json'])
    expected=json.loads((Path('/runtime/fixtures')/flow['expected']).read_text())
    assert result['cases']==expected['cases']==flow['cases']
    assert len(result['rows'])==len(expected['rows'])==flow['cases']
    counts[flow['name']]=flow['cases']
    for a,b in zip(expected['rows'],result['rows']):
        try:compare(a,b,a['dtype'].removeprefix('torch.'))
        except (AssertionError,KeyError,TypeError) as error:
            failures.append(dict(flow=flow['name'],error=str(error),expected=a,actual=b))
    raw.append(dict(flow=flow['name'],result=result))
json.dumps(dict(status='failed' if failures else 'success',cases=sum(counts.values()),counts=counts,
                source_hashes=actual,fixture_hashes=plan['fixtures'],failures=failures,raw=raw,
                scope='Cross-runtime replay of separately qualified CPU inventories, including explicit unsupported errors. '
                      'This is not an independent native comparison; source CPU qualification retains the reference exceptions.'))
