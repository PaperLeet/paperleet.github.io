"""Create immutable Node/Chrome fixtures for the complete current JVP inventory."""
from pathlib import Path
import hashlib
import json
import shutil

r=Path(__file__).resolve().parent
p=r/'selected-release/numerical-wasm'
c=p/'chrome';c.mkdir(parents=True)
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
freeze=json.loads((r/'selected-release/source-freeze.json').read_text())
snapshot=r/'selected-release/snapshot/packages/stridetorch/src/stridetorch'
(p/'source').mkdir()
for name,digest in freeze['source_hashes'].items():
    assert sha(snapshot/name)==digest
    shutil.copy2(snapshot/name,p/'source'/name)
(p/'fixtures').mkdir()
flows=[]
for name,directory,cases in [('basic','prototype-proof',480),('advanced','advanced-proof',512),
                             ('models-default','default-model-proof',416),('models-graph','model-proof',416),
                             ('dependencies',None,480)]:
    if directory:
        origin=r/'selected-release/native-cpu'/directory
        program,expected=origin/'probe.py',origin/'candidate.json'
        qualification=json.loads((origin/'qualification.json').read_text())
    else:
        program,expected=r/'probe-functional-jvp-dependencies.py',r/'selected-release/native-cpu/dependencies/candidate-dependencies.json'
        qualification=json.loads((r/'selected-release/native-cpu/dependencies/dependencies-qualification.json').read_text())
    assert qualification['source_hashes']==freeze['source_hashes']
    shutil.copy2(program,p/'fixtures'/(name+'.py'))
    shutil.copy2(expected,p/'fixtures'/(name+'.json'))
    flows.append(dict(name=name,program=name+'.py',expected=name+'.json',cases=cases))
plan=dict(source=freeze['source_hashes'],fixtures={q.name:sha(q) for q in (p/'fixtures').iterdir()},
          version='0.72.0',flows=flows,expected_cases=2304)
(p/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
shutil.copy2(r/'replay-functional-jvp-wasm.py',p/'replay.py')
(c/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>Functional JVP numerical replay</title>')
(p/'node.mjs').write_text('''import fs from 'node:fs';
import assert from 'node:assert/strict';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const repo='/Users/david/Developer/PaperLeet-torch-release';
const plan=JSON.parse(fs.readFileSync(new URL('./plan.json',import.meta.url)));
const py=await loadPyodide({indexURL:repo+'/web/node_modules/pyodide/',packageCacheDir:repo+'/web/public/browser-runtime/pyodide-0.29.4/',stdout:console.log,stderr:console.error});
await loadJudgePackages(py,[]);
for(const [folder,manifest] of [['stridetorch',plan.source],['fixtures',plan.fixtures]]){
 py.FS.mkdirTree('/runtime/'+folder);
 for(const name of Object.keys(manifest))py.FS.writeFile('/runtime/'+folder+'/'+name,fs.readFileSync(new URL('./'+(folder==='stridetorch'?'source':'fixtures')+'/'+name,import.meta.url)));
}
py.globals.set('plan_json',JSON.stringify(plan));
const result=JSON.parse(py.runPython(fs.readFileSync(new URL('./replay.py',import.meta.url),'utf8')));
result.pyodide=py.version;result.node=process.version;
fs.writeFileSync(new URL('./node-result.json',import.meta.url),JSON.stringify(result,null,2)+'\\n');
console.log(JSON.stringify({status:result.status,cases:result.cases,counts:result.counts,failures:result.failures.length}));
assert.equal(result.status,'success');assert.equal(result.cases,2304);
''')
(c/'worker.mjs').write_text('''import {loadJudgePackages} from '../../../../extraction-browser/packages.mjs';
self.onmessage=async()=>{try{
 const plan=await(await fetch('../plan.json')).json();
 const {loadPyodide}=await import('../../../../runtime-0.29.4/pyodide.mjs');
 const py=await loadPyodide({indexURL:new URL('../../../../runtime-0.29.4/',self.location.href).href,stdout:()=>{},stderr:()=>{}});
 await loadJudgePackages(py,[]);
 for(const [folder,manifest] of [['stridetorch',plan.source],['fixtures',plan.fixtures]]){
  py.FS.mkdirTree('/runtime/'+folder);
  for(const name of Object.keys(manifest))py.FS.writeFile('/runtime/'+folder+'/'+name,await(await fetch('../'+(folder==='stridetorch'?'source':'fixtures')+'/'+name)).text());
 }
 py.globals.set('plan_json',JSON.stringify(plan));
 const result=JSON.parse(py.runPython(await(await fetch('../replay.py')).text()));
 self.postMessage({...result,pyodide:py.version});
}catch(error){self.postMessage({error:String(error.stack||error)});}};
''')
(c/'run.mjs').write_text('''import {withFixtureServer} from '../../../../torch-iteration-70/fixture-server.mjs';
import fs from 'node:fs';import assert from 'node:assert/strict';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
await withFixtureServer(async origin=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 try{
  const page=await browser.newPage();
  await page.goto(origin+'/torch-iteration-72/selected-release/numerical-wasm/chrome/');
  const result=await page.evaluate(()=>new Promise((resolve,reject)=>{
   const worker=new Worker('./worker.mjs',{type:'module'});
   const timer=setTimeout(()=>{worker.terminate();reject(Error('JVP replay exceeded180seconds'));},180000);
   worker.onmessage=({data})=>{clearTimeout(timer);worker.terminate();resolve(data);};
   worker.onerror=e=>{clearTimeout(timer);worker.terminate();reject(Error(e.message));};worker.postMessage({});
  }));
  result.browser=browser.version();
  fs.writeFileSync(new URL('./result.json',import.meta.url),JSON.stringify(result,null,2)+'\\n');
  console.log(JSON.stringify({status:result.status,cases:result.cases,counts:result.counts,failures:result.failures?.length,error:result.error}));
  assert(!result.error);assert.equal(result.status,'success');assert.equal(result.cases,2304);
 }finally{await browser.close();}
});
''')
print(json.dumps(dict(status='prepared',cases=2304,source_files=len(plan['source']),fixtures=len(plan['fixtures']))))
