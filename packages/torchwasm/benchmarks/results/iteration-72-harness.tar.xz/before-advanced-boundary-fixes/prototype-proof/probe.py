"""Native-only inventory for the missing functional JVP entry point."""
import hashlib
import itertools
import json
from pathlib import Path
from stridetorch import torch, __version__ as library_version


def record(value):
    if isinstance(value, tuple):
        return [record(item) for item in value]
    return dict(shape=list(value.shape), dtype=str(value.dtype),
                requires_grad=value.requires_grad, values=value.detach().clone().numpy().tolist())


rows = []
cases = ['linear', 'cube', 'sin', 'constant', 'detach', 'no_grad', 'captured',
         'tuple', 'cross', 'repeated', 'scalar_implicit', 'bad_vector',
         'vector_cast', 'empty_tuple', 'empty_output']
for dtype, gx, gv, strict, graph, case in itertools.product(
        [torch.float32, torch.float64], [False, True], [False, True],
        [False, True], [False, True], cases):
    data = [0.2] if case == 'scalar_implicit' else [0.2, -0.4]
    x = torch.tensor(data, dtype=dtype, requires_grad=gx)
    y = torch.tensor([0.7, 0.9], dtype=dtype, requires_grad=gx)
    vector_dtype = torch.float32 if case == 'vector_cast' else dtype
    v = torch.tensor([0.3] if len(data) == 1 else [0.3, 0.5],
                     dtype=vector_dtype, requires_grad=gv)
    w = torch.tensor([-0.2, 0.1], dtype=dtype, requires_grad=gv)
    originals = (x, y, v, w)
    for item in originals:
        item.grad = torch.full_like(item, 17.)
    buffers = tuple(item.grad for item in originals)
    hooks = []
    handles = [item.register_hook(lambda gradient: hooks.append(record(gradient)))
               for item in originals if item.requires_grad]
    calls = []
    def function(*arguments):
        calls.append(dict(objects=[id(item) for item in arguments],
                          distinct=len({id(item) for item in arguments}) == len(arguments),
                          requires_grad=[item.requires_grad for item in arguments]))
        a = arguments[0] if arguments else x
        if case == 'linear': return a * 3
        if case == 'cube': return a.pow(3)
        if case == 'sin': return a.sin()
        if case == 'constant': return torch.ones_like(a)
        if case == 'detach': return a.detach().square()
        if case == 'no_grad':
            with torch.no_grad(): return a.square()
        if case == 'captured': return a * x
        if case == 'tuple': return (a.square(), a.sum())
        if case == 'cross': return (a * arguments[1], arguments[1].sin())
        if case == 'repeated': return a * arguments[1]
        if case == 'empty_output': return a[:0]
        return a.square()
    inputs, vectors = x, v
    if case == 'cross': inputs, vectors = (x, y), (v, w)
    if case == 'repeated': inputs, vectors = (x, x), (v, w)
    if case == 'scalar_implicit': vectors = None
    if case == 'bad_vector': vectors = torch.ones(3, dtype=dtype)
    if case == 'empty_tuple': inputs, vectors = (), ()
    row = dict(case=case, dtype=str(dtype), gx=gx, gv=gv, strict=strict, create_graph=graph)
    try:
        result = torch.autograd.functional.jvp(function, inputs, vectors,
                                               create_graph=graph, strict=strict)
        row.update(status='success', result=record(result))
    except Exception as error:
        row.update(status='error', exception=type(error).__name__, message=str(error))
    row.update(callbacks=len(calls), distinct_callback_inputs=all(item['distinct'] for item in calls),
               callback_flags=[item['requires_grad'] for item in calls], original_hooks=len(hooks),
               buffers_preserved=all(item.grad is buffer for item, buffer in zip(originals, buffers)),
               flags_preserved=[item.requires_grad for item in originals] == [gx, gx, gv, gv],
               gradients=[record(item.grad) for item in originals],
               data_preserved=x.detach().tolist() == torch.tensor(data, dtype=dtype).tolist())
    for handle in handles: handle.remove()
    rows.append(row)
assert len(rows) == 480
print(json.dumps(dict(status='native_inventory', torch=library_version, native_git='adapter-not-native',
                      program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                      cases=len(rows), rows=rows,
                      scope='Native-only functional JVP behavior inventory; no adapter implementation, '
                            'runtime qualification, performance or main adoption claim.'), indent=2))
