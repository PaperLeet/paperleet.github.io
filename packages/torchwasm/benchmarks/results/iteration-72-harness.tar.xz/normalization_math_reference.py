"""Independent scalar objectives/directions and complex-step derivatives."""
import numpy as np


def objective_and_direction(case, values):
    x, weight, bias = (values[name] for name in ['x', 'weight', 'bias'])
    vx, vw, vb = (values[name] for name in ['vx', 'vweight', 'vbias'])
    if case == 'layernorm':
        axes, affine_shape = (-1,), (1, weight.size)
    elif case == 'instancenorm_train':
        axes, affine_shape = (-1,), (1, weight.size, 1)
    elif case == 'batchnorm_train':
        axes, affine_shape = (0, 2), (1, weight.size, 1)
    else:
        raise ValueError(case)
    centered = x - x.mean(axis=axes, keepdims=True)
    centered_direction = vx - vx.mean(axis=axes, keepdims=True)
    variance = (centered * centered).mean(axis=axes, keepdims=True)
    inverse_std = 1 / np.sqrt(variance + 1e-5)
    variance_direction = 2 * (centered * centered_direction).mean(axis=axes, keepdims=True)
    inverse_direction = -.5 * inverse_std ** 3 * variance_direction
    normalized = centered * inverse_std
    normalized_direction = centered_direction * inverse_std + centered * inverse_direction
    output = normalized * weight.reshape(affine_shape) + bias.reshape(affine_shape)
    direction = (normalized_direction * weight.reshape(affine_shape)
                 + normalized * vw.reshape(affine_shape) + vb.reshape(affine_shape))
    return np.array([(output * output).sum(), 2 * (output * direction).sum()])


def complex_step_gradients(case, values, step=1e-20):
    result = {}
    for name, original in values.items():
        gradients = np.empty((2,) + original.shape, dtype=np.float64)
        for index in np.ndindex(original.shape):
            perturbed = {key: np.asarray(value, dtype=np.complex128).copy()
                         for key, value in values.items()}
            perturbed[name][index] += step * 1j
            gradients[(slice(None),) + index] = objective_and_direction(case, perturbed).imag / step
        result[name] = gradients
    return result


def fixture_values(row):
    inputs = [np.asarray(item['values'], dtype=np.float64) for item in row['fixture_inputs']]
    vectors = [np.asarray(item['values'], dtype=np.float64) for item in row['fixture_vectors']]
    if row['case'] == 'batchnorm_train':
        original_dtype = row['dtype']
        weight = (np.sin(np.arange(2) * .13) * .2).astype(original_dtype).astype(np.float64)
        bias = (np.sin(np.arange(2) * .13 + 1) * .2).astype(original_dtype).astype(np.float64)
        return dict(x=inputs[0], weight=weight, bias=bias,
                    vx=vectors[0], vweight=np.zeros_like(weight), vbias=np.zeros_like(bias))
    return dict(zip(['x', 'weight', 'bias', 'vx', 'vweight', 'vbias'], inputs + vectors))
