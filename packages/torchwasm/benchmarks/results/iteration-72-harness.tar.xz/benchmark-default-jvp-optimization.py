"""Six fresh CPU children, balanced A/A/B for a bounded unreleased-prototype optimization."""
from pathlib import Path
import gc
import hashlib
import importlib.util
import itertools
import json
import os
import statistics
import subprocess
import sys
import time
import numpy as np
from normalization_math_reference import objective_and_direction, complex_step_gradients

r = Path(__file__).resolve().parent
p = r / 'default-jvp-optimization-performance'
baseline = r / 'before-default-jvp-graph-optimization/candidate/packages/stridetorch/src/stridetorch'
candidate = r / 'candidate/packages/stridetorch/src/stridetorch'
sha = lambda q: hashlib.sha256(q.read_bytes()).hexdigest()
manifest = lambda q: {f.name:sha(f) for f in q.iterdir() if f.suffix == '.py' or f.name in ['LICENSE','NOTICE']}
labels = ['baseline', 'duplicate', 'candidate']
flows = [('layernorm',False),('instancenorm_train',False),('batchnorm_train',False),('layernorm',True)]

def load(name, directory):
    spec = importlib.util.spec_from_file_location(name, directory/'__init__.py', submodule_search_locations=[str(directory)])
    module = importlib.util.module_from_spec(spec);sys.modules[name] = module;spec.loader.exec_module(module)
    return module.torch

def make(api, case, graph):
    dtype = np.float64 if graph else np.float32
    shape = (16,8) if case == 'layernorm' else (4,4,8)
    width = shape[-1] if case == 'layernorm' else shape[1]
    rng = np.random.default_rng(7233)
    x = (rng.normal(size=shape)*.3).astype(dtype)
    w = (np.sin(np.arange(width)*.17)+1.1).astype(dtype)
    b = (np.cos(np.arange(width)*.23)*.2).astype(dtype)
    arrays = [x,w,b]
    directions = [np.cos(np.arange(a.size)*.11+i).reshape(a.shape).astype(dtype) for i,a in enumerate(arrays)]
    args = tuple(api.tensor(a,requires_grad=True) for a in arrays)
    vectors = tuple(api.tensor(a) for a in directions)
    for item in args+vectors:item.grad=api.full_like(item,17)
    buffers = tuple(item.grad for item in args+vectors)
    hooks=[];handles=[item.register_hook(lambda g:hooks.append(g)) for item in args]
    def function(a,weight,bias):
        if case=='layernorm':output=api.nn.functional.layer_norm(a,(width,),weight,bias)
        elif case=='instancenorm_train':output=api.nn.functional.instance_norm(a,weight=weight,bias=bias)
        else:output=api.nn.functional.batch_norm(a,None,None,weight,bias,training=True)
        return output.square().sum()
    def fn():return api.autograd.functional.jvp(function,args,vectors,create_graph=graph)
    values=dict(zip(['x','weight','bias','vx','vweight','vbias'],[a.astype(np.float64) for a in arrays+directions]))
    expected=objective_and_direction(case,values)
    actual=fn()
    np.testing.assert_allclose([a.detach().item() for a in actual],expected,
        rtol=1e-9 if graph else 1e-4,atol=2e-10 if graph else 3e-6)
    assert all(a.requires_grad==graph for a in actual) and not hooks
    for handle in handles:handle.remove()
    if graph:
        derivatives=api.autograd.grad(actual[1],args,retain_graph=True)
        target=complex_step_gradients(case,values)
        for name,value in zip(['x','weight','bias'],derivatives):
            np.testing.assert_allclose(value.numpy(),target[name][1],rtol=1e-8,atol=2e-10)
    def guard():
        for item,buffer,data in zip(args+vectors,buffers,arrays+directions):
            assert item.grad is buffer
            np.testing.assert_array_equal(item.detach().numpy(),data)
            np.testing.assert_array_equal(item.grad.numpy(),np.full_like(data,17))
        assert all(item.requires_grad for item in args) and not any(item.requires_grad for item in vectors)
    guard()
    return fn,guard

def worker(cycle):
    plan=json.loads((p/'plan.json').read_text())
    order=list(itertools.permutations(labels))[cycle]
    modules={label:load('_jvp_opt_'+label, candidate if label=='candidate' else baseline) for label in order}
    rows=[]
    for case,graph in flows:
        entries={label:make(modules[label],case,graph) for label in labels}
        functions={label:item[0] for label,item in entries.items()}
        gc.collect();calls=1
        for label in order:
            n=1
            while True:
                start=time.perf_counter()
                for _ in range(n):functions[label]()
                if time.perf_counter()-start>=.02:break
                n*=2
            calls=max(calls,n)
        samples={label:[] for label in labels}
        balanced=list(itertools.permutations(labels))
        for sample_order in balanced+list(reversed(balanced)):
            for label in sample_order:
                start=time.perf_counter()
                for _ in range(calls):functions[label]()
                samples[label].append((time.perf_counter()-start)/calls)
        for _,guard in entries.values():guard()
        medians={label:statistics.median(samples[label]) for label in labels}
        rows.append(dict(case=case,create_graph=graph,dtype='float64' if graph else 'float32',calls=calls,
            samples_s=samples,median_s=medians,duplicate_over_baseline=medians['duplicate']/medians['baseline'],
            candidate_over_baseline=medians['candidate']/medians['baseline'],
            candidate_over_duplicate=medians['candidate']/medians['duplicate']))
    assert manifest(baseline)==plan['source_hashes']['baseline'] and manifest(candidate)==plan['source_hashes']['candidate']
    return dict(cycle=cycle,load_order=order,rows=rows,source_hashes=plan['source_hashes'],
                program_sha256=sha(Path(__file__)),numpy=np.__version__,python=sys.version)

if __name__=='__main__' and '--worker' in sys.argv:
    print(json.dumps(worker(int(sys.argv[-1])),indent=2))
elif __name__=='__main__':
    qualification=json.loads((r/'optimized-proof/qualification.json').read_text())
    assert qualification['status']=='cpu_sdk_and_optimized_numerical_controls_passed'
    p.mkdir()
    plan=dict(source_hashes={'baseline':manifest(baseline),'duplicate':manifest(baseline),'candidate':manifest(candidate)},
              program_sha256=sha(Path(__file__)),reference_sha256=sha(r/'normalization_math_reference.py'),
              scope='Unreleased full-graph-default functionalJVP prototype versus scoped-graph prototype. '
                    'Not a released0.71 functionalJVP API comparison. Three float32 default normalization '
                    'flows and one float64 graph control; numerical/graph/caller-state preflight, six load '
                    'orders and12balanced common>=20ms batches with same-source A/A. CPU only.')
    assert plan['source_hashes']['candidate']==qualification['source_hashes']
    (p/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
    receipts=[];children=[]
    for cycle in range(6):
        with (p/f'cpu-{cycle}.json').open('w') as out,(p/f'cpu-{cycle}.log').open('w') as error:
            child=subprocess.run([sys.executable,str(Path(__file__)),'--worker',str(cycle)],env=env,stdout=out,stderr=error)
        receipts.append(dict(cycle=cycle,exit_code=child.returncode));(p/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');child.check_returncode()
        value=json.loads((p/f'cpu-{cycle}.json').read_text());assert value['source_hashes']==plan['source_hashes'] and value['program_sha256']==plan['program_sha256'];children.append(value)
        print('cpu',cycle,'PASS',flush=True)
    rows=[]
    for i in range(4):
        values=[child['rows'][i] for child in children]
        rows.append(dict(case=values[0]['case'],create_graph=values[0]['create_graph'],
            medians={key:statistics.median(value[key] for value in values) for key in ['duplicate_over_baseline','candidate_over_baseline','candidate_over_duplicate']}))
    result=dict(status='completed',fresh_children=6,source_hashes=plan['source_hashes'],rows=rows,scope=plan['scope'])
    (p/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['rows']),flush=True)
