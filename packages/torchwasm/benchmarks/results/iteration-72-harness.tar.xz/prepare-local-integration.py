"""Prepare the full application gates for a separately reviewed selected0.72 candidate."""
from pathlib import Path
import shutil

r=Path(__file__).resolve().parent;p=r/'final-integration';p.mkdir()
old=r.parent/'torch-iteration-71/final-integration'
for name in ['verify-export.py','verify-generated-worker.mjs','release_chain_guard.py','audit-main.py',
             'run-guarded-push.py','run-buffered-http-guarded.py','release-policy-variants.json']:
    code=(old/name).read_text()
    if name=='run-guarded-push.py':code=code.replace('torch-iteration-71','torch-iteration-72')
    (p/name).write_text(code)
code=(old/'integrate-local.py').read_text().replace("r/'production-release'","r/'selected-release'").replace('production-performance','performance').replace('qualified 0.71 snapshot','qualified 0.72 snapshot')
code=code.replace("memory=read(r/'performance/hvp-memory.json')","memory=read(r/'performance/api-memory.json')")
code=code.replace("memory['source_hashes']==candidate","memory['source_hashes']['candidate']==candidate").replace("sha(r/'performance/hvp-memory.json')","sha(r/'performance/api-memory.json')")
code=code.replace('flows_per_child\']==20','flows_per_child\']==27').replace("==8363","==8723").replace("==8350","==8710").replace("==71","==73").replace("'0.71.0'","'0.72.0'")
code=code.replace("selected/'native-wasm-proof'","selected/'legacy-hvp-wasm'")
code=code.replace("assert len(owned)==15 and sources(target/'src/stridetorch')==candidate", "assert owned and len(owned)==len(set(owned)) and sources(target/'src/stridetorch')==candidate")
needle="freeze=read(selected/'source-freeze.json')"
assert needle in code
code=code.replace(needle,needle+'''
core=read(selected/'core-and-package-proof.json')
assert core['status']=='selected_version_cpu_native_wasm_and_package_passed' and core['version']=='0.72.0'
assert core['source_hashes']==freeze['source_hashes'] and core['test_hashes']==freeze['test_hashes']
for name,digest in core['evidence_sha256'].items():assert sha(selected/name)==digest
''')
compile(code,str(p/'integrate-local.py'),'exec');(p/'integrate-local.py').write_text(code)
print('Prepared current-application export,fullCPU,86moduleWASM,frontend,release-policy andtwo buildprofiles; not started')
