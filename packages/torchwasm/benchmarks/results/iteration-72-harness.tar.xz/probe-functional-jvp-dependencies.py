"""Independent inventory of determinant and strict JVP dependency boundaries."""
import hashlib
import itertools
import json
import os
from pathlib import Path
import numpy as np

if os.environ.get('STRIDE_PROBE'):
    from stridetorch import torch
else:
    import torch


def record(value):
    if value is None:
        return None
    if isinstance(value, tuple):
        return [record(item) for item in value]
    return dict(shape=list(value.shape), dtype=str(value.dtype).split('.')[-1],
                requires_grad=value.requires_grad,
                values=value.detach().clone().numpy().tolist())


rows = []
cases = ['det_empty', 'det_empty_batch', 'det_zero1', 'det_rank1_2',
         'det_rank2_3', 'det_rank1_3', 'det_dense3', 'det_squared_rank1_2',
         'empty_sum', 'tuple_capture', 'tuple_capture_added', 'linear',
         'captured_weight', 'cross_inputs', 'hook_in_callback']
for dtype, gx, gv, graph, strict, case in itertools.product(
        [torch.float32, torch.float64], [False, True], [False, True],
        [False, True], [False, True], cases):
    matrices = {'det_empty': np.empty((0, 0)), 'det_empty_batch': np.empty((0, 2, 2)),
                'det_zero1': [[0.]], 'det_rank1_2': [[1., 2.], [2., 4.]],
                'det_squared_rank1_2': [[1., 2.], [2., 4.]],
                'det_rank2_3': [[1., 0., 0.], [0., 1., 0.], [0., 0., 0.]],
                'det_rank1_3': [[1., 0., 0.], [0., 0., 0.], [0., 0., 0.]],
                'det_dense3': [[2., .2, .3], [.1, 1.5, .4], [.7, .1, 1.8]]}
    data = matrices.get(case, [] if case == 'empty_sum' else [.3, -.7])
    x = torch.tensor(data, dtype=dtype, requires_grad=gx)
    v = torch.tensor(np.cos(np.arange(x.numel())).reshape(x.shape), dtype=dtype, requires_grad=gv)
    y = torch.tensor(np.full(x.shape, .6), dtype=dtype, requires_grad=gx)
    w = torch.tensor(np.full(x.shape, -.4), dtype=dtype, requires_grad=gv)
    capture = torch.tensor(np.full(x.shape, 1.7), dtype=dtype, requires_grad=True)
    originals = (x, v, y, w, capture)
    for item in originals:
        item.grad = torch.full_like(item, 17.)
    buffers = [item.grad for item in originals]
    hooks = []
    handles = [item.register_hook(lambda gradient, i=i: hooks.append(i))
               for i, item in enumerate(originals) if item.requires_grad]
    internal_hooks = []

    def function(a, *rest):
        if case.startswith('det_'):
            output = torch.linalg.det(a)
            return output.square() if case.startswith('det_squared') else output
        if case == 'empty_sum': return a.sum()
        if case == 'tuple_capture': return a.sin(), capture.square()
        if case == 'tuple_capture_added': return a.sin(), a + capture.square()
        if case == 'linear': return a * 3.
        if case == 'captured_weight': return a * capture
        if case == 'cross_inputs': return a * rest[0]
        if case == 'hook_in_callback':
            a.register_hook(lambda gradient: internal_hooks.append('hook') or gradient * 2.)
            return a.square()

    inputs = (x, y) if case == 'cross_inputs' else x
    vector = (v, w) if case == 'cross_inputs' else v
    row = dict(case=case, dtype=str(dtype).split('.')[-1], gx=gx, gv=gv,
               create_graph=graph, strict=strict)
    try:
        output, tangent = torch.autograd.functional.jvp(function, inputs, vector,
                                                       create_graph=graph, strict=strict)
        row['result'] = record((output, tangent))
        row['api_hooks'] = list(hooks)
        row['internal_api_hooks'] = list(internal_hooks)
        differentiable = tuple(item for item in originals if item.requires_grad)
        reverse = []
        for value in (output, tangent):
            values = value if isinstance(value, tuple) else (value,)
            scalar = sum(item.sum() for item in values)
            try:
                reverse.append(dict(result=record(torch.autograd.grad(
                    scalar, differentiable, allow_unused=True, retain_graph=True))))
            except Exception as error:
                reverse.append(dict(error=type(error).__name__))
        row['reverse'] = reverse
    except Exception as error:
        row['error'] = type(error).__name__
        row['message'] = str(error)
        row['api_hooks'] = list(hooks)
        row['internal_api_hooks'] = list(internal_hooks)
    row['state'] = dict(flags=[item.requires_grad for item in originals],
                        buffers=[item.grad is buffer for item, buffer in zip(originals, buffers)],
                        gradients=[record(item.grad) for item in originals])
    rows.append(row)

print(json.dumps(dict(cases=len(rows), probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                     rows=rows), allow_nan=True))
