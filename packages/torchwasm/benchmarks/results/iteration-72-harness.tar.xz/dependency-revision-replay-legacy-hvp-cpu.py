"""Replay the adopted0.71 HVP evidence against the isolated refactored runtime."""
from pathlib import Path
import ast
import hashlib
import json
import shutil
import sys

r = Path(__file__).resolve().parent
p = r / 'dependency-revision/legacy-hvp-cpu'
p.mkdir()
source = r / 'candidate/packages/stridetorch/src/stridetorch'
old = r.parent / 'torch-iteration-71/production-release/native-wasm-proof'
sha = lambda q: hashlib.sha256(q.read_bytes()).hexdigest()
freeze = json.loads((r/'dependency-revision/source-freeze.json').read_text())
plan = json.loads((old/'plan.json').read_text())
for name,digest in plan['fixtures'].items():assert sha(old/'fixtures'/name)==digest
runtime = p/'runtime'
shutil.copytree(source,runtime/'stridetorch',ignore=shutil.ignore_patterns('__pycache__'))
shutil.copytree(old/'fixtures',runtime/'fixtures')
plan['source'] = freeze['source_hashes']
plan['version'] = '0.71.0'
(p/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for name,digest in plan['source'].items():assert sha(runtime/'stridetorch'/name)==digest
program = (old/'replay.py').read_text().replace('/runtime',str(runtime))
(p/'replay.py').write_text(program)
tree = ast.parse(program)
assert isinstance(tree.body[-1],ast.Expr)
tree.body[-1] = ast.Assign(targets=[ast.Name(id='result_json',ctx=ast.Store())],value=tree.body[-1].value)
ast.fix_missing_locations(tree)
assert 'stridetorch' not in sys.modules
namespace = {'__name__':'__main__','plan_json':json.dumps(plan)}
exec(compile(tree,str(p/'replay.py'),'exec'),namespace)
assert Path(sys.modules['stridetorch'].__file__).resolve().parent == (runtime/'stridetorch').resolve()
result = json.loads(namespace['result_json'])
assert result['status']=='success' and result['source_hashes']==plan['source']
assert result['cases']==720 and result['direct_native_cases']==676 and not result['failures']
assert len(result['independent_precision_controls'])==4 and len(result['polynomial_extension_controls'])==40
result['scope']='Adopted0.71legacy HVP fixtures replayed on isolated full-forward-graph refactor;676direct+4precision+40polynomial controls. CPU only,version literal0.71.'
result['program_sha256']=sha(p/'replay.py')
(p/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],cases=720,direct=676,precision=4,polynomial=40)),flush=True)
