"""Observe callback mutations of captured input vectors without changing source."""
import json,os
if os.environ.get('STRIDE_PROBE'):
    from stridetorch import torch
else:
    import torch
rows=[]
for graph in [False,True]:
    for when in ['before','after']:
        x=torch.tensor([2.,3.],dtype=torch.float64,requires_grad=True)
        v=torch.tensor([.5,.5],dtype=torch.float64)
        def function(a):
            if when=='before':v.add_(1.)
            y=a.square()
            if when=='after':v.add_(1.)
            return y
        row=dict(graph=graph,when=when)
        try:
            y,d=torch.autograd.functional.jvp(function,x,v,create_graph=graph)
            row.update(value=y.detach().tolist(),direction=d.detach().tolist(),vector=v.tolist())
        except Exception as error:row.update(error=type(error).__name__,message=str(error))
        rows.append(row)
print(json.dumps(rows,indent=2))
