from pathlib import Path
import hashlib,json,subprocess,sys
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');py=sys.executable
baseline=json.loads((r/'integration-proof/context.json').read_text())['upstream']
def call(*args,cwd=r):subprocess.check_call([str(x) for x in args],cwd=cwd)
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
assert git('rev-parse','HEAD')==baseline
call(py,r/'audit-main.py',baseline)
local=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-59.json').read_text())
assert local['status']=='validated_locally' and local['baseline_main']==baseline
for name,digest in local['source_hashes'].items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==digest
for name,digest in local['test_hashes'].items():assert hashlib.sha256((repo/'packages/stridetorch/tests'/name).read_bytes()).hexdigest()==digest
for name,digest in local['additional_root_test_hashes'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
for name,digest in local['owned_inputs'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
assert hashlib.sha256((repo/'packages/stridetorch/benchmarks/results'/local['raw_archive']['name']).read_bytes()).hexdigest()==local['raw_archive']['sha256']
paths=git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
source=json.loads((r/'owned-source-paths.json').read_text())
generated=['docs/validation/torch-runtime-iteration-59.md','packages/stridetorch/benchmarks/results/iteration-59.json','packages/stridetorch/benchmarks/results/iteration-59-harness.tar.gz']
indices=['web/public/data/'+n for n in ['catalog.json','index-v3.json','index.json']]
assets=[n for n in paths if n.startswith(('web/public/data/browser-judge/','web/public/data/modules/'))]
expected=sorted(source+generated+indices+assets)
assert len(assets)==158 and len(expected)==170 and sorted(paths)==expected,(len(paths),set(paths)^set(expected))
call('git','add','--',*expected,cwd=repo)
assert git('diff','--cached','--name-only').splitlines()==expected
call('git','diff','--cached','--check',cwd=repo)
call('git','commit','--quiet','-m','perf(torch): accelerate bounded condensed distance forwards',cwd=repo)
source_head=git('rev-parse','HEAD');print('SOURCE_COMMIT',source_head,flush=True)
call(py,r/'push-main-node.py',baseline)
call(py,r/'record-adoption.py')
proof=['docs/validation/torch-runtime-iteration-59.md','packages/stridetorch/benchmarks/results/iteration-59-main-adoption.json']
call('git','add','--',*proof,cwd=repo)
assert git('diff','--cached','--name-only').splitlines()==proof
call('git','commit','--quiet','-m','docs(torch): record validated 0.59 main adoption',cwd=repo)
print('PROOF_COMMIT',git('rev-parse','HEAD'),flush=True)
call(py,r/'push-main-node.py',source_head)
call(py,r/'verify-adoption.py')
print('ITERATION_59_ADOPTED_GOAL_REMAINS_ACTIVE',flush=True)
