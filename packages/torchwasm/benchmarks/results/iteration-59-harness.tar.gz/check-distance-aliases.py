from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent;p=r/'proof';results=[]
code="""import importlib,importlib.util,json,sys,numpy as np
name=sys.argv[1];m=importlib.import_module(name)
assert importlib.util.find_spec('torch') is None
with m.as_torch():
 import torch
 from torch.nn.functional import pdist
 x=torch.tensor([[0.,0.],[1.,-1.]],dtype=torch.float64,requires_grad=True)
 value=pdist(x,p=3.);np.testing.assert_allclose(value.numpy(),[2**(1/3)],rtol=1e-13,atol=1e-13)
 value.sum().backward();c=2**(-2/3);np.testing.assert_allclose(x.grad.numpy(),[[-c,c],[c,-c]],rtol=1e-13,atol=1e-13)
 np.testing.assert_allclose(torch.cdist(x,x,p=3.).numpy(),[[0,2**(1/3)],[2**(1/3),0]],rtol=1e-13,atol=1e-13)
assert 'torch' not in sys.modules
print(json.dumps(dict(namespace=name,version=m.__version__,distance_alias=True,gradients=True,alias_restored=True)))
"""
for name,python in [('stridetorch',p/'python310-stride059-env/bin/python'),('paperleet._vendor.torch',p/'coinstall-env/bin/python')]:
 result=subprocess.run([str(python),'-I','-c',code,name],cwd=r,capture_output=True,text=True);assert result.returncode==0,result.stderr;row=json.loads(result.stdout);assert row['version']=='0.59.0';results.append(row)
(r/'distance-alias-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results))
