from pathlib import Path
import json,os,shutil,subprocess,time
r=Path(__file__).resolve().parent;i=r/'integration-proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release')
read=lambda n:json.loads((r/n).read_text())
assert read('full-root-receipt.json')['exit_code']==0
assert all(v['exit_code']==0 for v in read('proof/gate-receipts.json').values())
assert len(read('integration-proof/frontend-receipts.json'))==5 and all(v['exit_code']==0 for v in read('integration-proof/frontend-receipts.json'))
args=['/opt/homebrew/bin/node','web/scripts/check-browser-wasm.mjs','--all'];started=time.monotonic()
with (i/'full-wasm.log').open('w') as log:p=subprocess.run(args,cwd=repo,env=dict(os.environ,PAPERLEET_WASM_CONCURRENCY='2'),stdout=log,stderr=subprocess.STDOUT)
rows=read('integration-proof/receipts.json');assert len(rows)==1 and rows[0]['label']=='frontend';rows.append(dict(label='full-wasm',args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-started))
(i/'receipts.json').write_text(json.dumps(rows,indent=2)+'\n');p.check_returncode();shutil.copy2(repo/'reports/browser-wasm.json',i/'full-wasm-result.json')
j=read('integration-proof/full-wasm-result.json');assert j['passed'] and not j['browser_budget_exceeded'],j.get('browser_budget_exceeded');print('full-wasm TERMINAL 0; all browser budgets passed',flush=True)
