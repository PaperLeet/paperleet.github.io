from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;i=r/'integration-proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release');receipts=[];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();env=dict(os.environ,PYTHON=str(r.parent/'torch-iteration-21/stride-dev-env/bin/python'));env['PATH']='/opt/homebrew/bin:'+env['PATH']
def run(args,label,cwd,extra=None):
 started=time.monotonic()
 with (i/('latest-'+label+'.log')).open('w') as log:p=subprocess.run(args,cwd=cwd,env={**env,**(extra or {})},stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(label=label,args=args,cwd=str(cwd),exit_code=p.returncode,elapsed_s=time.monotonic()-started));(i/'latest-ui-qualification.json').write_text(json.dumps(dict(upstream=head,full_suite_baseline='644a8feeeca50c5a70d11a000d1d9d184f854fc9',scope='Affected practice/experience preview, deferred feature and navigation regression checks and driver/policy/build checks after disjoint incoming UI-only commit.',receipts=receipts,status='running'),indent=2)+'\n');p.check_returncode();print(label,'TERMINAL 0',flush=True)
checks=['practice-experiences','interview-source-preview','interview-browse','interview-ui','interview-sharing','source-post-practice','reading-return','practice','practice-views','deferred-features','reading-tabs','achievements','company-preparation','company-directory','company-comparison-practice','workspace-ui','workspace-actions','problem-overview','ui-interactions','paper-detail-loading']
for name in checks:run(['/opt/homebrew/bin/node','scripts/check-'+name+'.mjs'],name,repo/'web')
run(['/opt/homebrew/bin/node','web/scripts/check-wasm-cases.mjs'],'wasm-driver',repo)
run(['/opt/homebrew/bin/node','web/scripts/check-pages-release.cjs'],'pages-policy',repo)
run(['npm','run','build'],'build',repo/'web')
profile=json.loads((i/'pages-profile.json').read_text())['environment'];run(['npm','run','build'],'pages-profile-build',repo/'web',profile)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
path=i/'latest-ui-qualification.json';j=json.loads(path.read_text());j['status']='qualified';path.write_text(json.dumps(j,indent=2)+'\n');print('LATEST UI QUALIFIED',head,flush=True)
