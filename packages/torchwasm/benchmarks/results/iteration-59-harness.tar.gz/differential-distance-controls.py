from pathlib import Path
import json,sys,warnings
import numpy as np
backend=sys.argv[1]
if backend=='native':import torch as t
else:from stridetorch import torch as t
r=Path(__file__).resolve().parent;rows={};arrays={}
class FloatControl:
 def __float__(self):return 2.
controls=[('zero',0),('half',.5),('one',1),('two',2),('three',3),('infinity',float('inf')),('negative',-1.),('nan',float('nan')),('negative_inf',-float('inf')),('string','2'),('bytes',b'2'),('python_complex',2+0j),('numpy_float',np.float32(1.5)),('numpy_int',np.int64(2)),('numpy_bool',np.bool_(True)),('python_bool',True),('numpy_complex64',np.complex64(2+1j)),('numpy_complex128',np.complex128(2+1j)),('numpy_array0',np.array(2.)),('numpy_array1',np.array([2.])),('tensor_scalar',t.tensor(2.)),('tensor_int',t.tensor(2)),('tensor_bool',t.tensor(True)),('tensor_vector',t.tensor([2.])),('tensor_grad',t.tensor(2.,requires_grad=True)),('tensor_complex_real',t.tensor(2+0j)),('tensor_complex_nonreal',t.tensor(2+1j)),('float_protocol',FloatControl()),('list',[2]),('none',None)]
for name,p in controls:
 for kind in ['cdist','pdist']:
  key=kind+'.'+name
  try:
   x=t.tensor([[.5,1.2],[-.3,2.1]],dtype=t.float64)
   with warnings.catch_warnings():warnings.simplefilter('ignore');value=t.cdist(x,x,p=p,compute_mode='donot_use_mm_for_euclid_dist') if kind=='cdist' else t.pdist(x,p=p)
   array=value.numpy();arrays[key]=array;rows[key]=dict(status='ok',dtype=str(array.dtype),shape=list(array.shape))
  except Exception as e:rows[key]=dict(status='error',error=type(e).__name__,message=str(e)[:160])
np.savez_compressed(r/(backend+'-distance-controls.npz'),**arrays);(r/(backend+'-distance-controls.json')).write_text(json.dumps(dict(rows=rows),indent=2)+'\n');print(backend,len(rows),'controls')
