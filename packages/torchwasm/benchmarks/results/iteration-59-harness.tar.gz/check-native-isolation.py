from pathlib import Path
import json,sys
import torch as native

r=Path(__file__).resolve().parent
sys.path.insert(0,'/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src')
import stridetorch as library
before=native.get_default_dtype();old=native
library.torch.set_default_dtype(library.torch.float64)
assert native.get_default_dtype()==before and sys.modules['torch'] is old
with library.as_torch():
 import torch as alias
 assert alias is not old and alias.get_default_dtype()==alias.float64
 alias.set_default_dtype(alias.float16)
 assert alias.tensor([.25]).dtype==alias.float16
assert sys.modules['torch'] is old and native.get_default_dtype()==before
assert library.torch.get_default_dtype()==library.torch.float16
assert native.ones(2).dtype==before
library.torch.set_default_dtype(library.torch.float64)
assert library.torch.ones(2).dtype==library.torch.float64
report=dict(status='success',native_version=native.__version__,library_version=library.__version__,native_default=str(before),alias_restored_identity=True,own_dtype_persists_across_alias_exit=True)
(r/'native-isolation-result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
