from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path('/Users/david/Developer/paperleet-wasm-evaluation-20261015');r=root/'torch-iteration-59';old=root/'torch-iteration-58';repo=Path('/Users/david/Developer/PaperLeet-torch-release');p=r/'proof';c=p/'chrome-contracts';i=r/'integration-proof';c.mkdir(parents=True,exist_ok=True);i.mkdir(exist_ok=True)
root_scripts=['run-full.py','run-gates.py','fixture-server.mjs','prepare-oracle.py','prepare-bench.py','run-bench-final.py','summarize-performance.py','run-front-only.py','run-full-wasm-only.py','check-distance-aliases.py','check-native-isolation.py','fresh-load.py','audit-main.py','push-main-node.py','push-via-node.mjs','record-adoption.py','verify-adoption.py']
files=[old/n for n in root_scripts]+[f for f in (old/'proof').iterdir() if f.suffix in ['.py','.mjs']]+[old/'proof/chrome-contracts'/n for n in ['run.mjs','worker.mjs','index.html']]+list((old/'integration-proof').glob('*.py'))
for f in files:
 dest=r/f.relative_to(old);dest.parent.mkdir(parents=True,exist_ok=True);s=f.read_text().replace('torch-iteration-58','torch-iteration-59').replace('0.58.0','0.59.0').replace('stride058','stride059').replace('7185','7215').replace('7198','7228').replace('40815','40845').replace('12125','12283');dest.write_text(s)
# The baseline is the already adopted 0.58 source, not the current candidate.
for n in ['record-adoption.py','verify-adoption.py']:
 q=r/n;s=q.read_text().replace('torch-iteration-57','torch-iteration-58').replace('0.57.0','0.58.0').replace('12283','12441');q.write_text(s)
source=repo/'packages/stridetorch/src/stridetorch';hashes=lambda paths:{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in paths}
resources=[*source.glob('*.py'),source/'LICENSE',source/'NOTICE'];src=hashes(resources);assert len(src)==60
for dest in [p/'source',c/'source']:
 dest.mkdir(exist_ok=True)
 for f in resources:shutil.copy2(f,dest/f.name)
(p/'source-hashes.json').write_text(json.dumps(src,indent=2)+'\n')
tests=[f for f in (repo/'packages/stridetorch/tests').glob('test_*.py') if f.name!='test_standalone.py'];assert len(tests)==53
(c/'tests').mkdir(exist_ok=True)
for f in tests:shutil.copy2(f,c/'tests'/f.name)
(c/'plan.json').write_text(json.dumps(dict(source=src,tests=hashes(tests),version='0.59.0',expected=7215),indent=2)+'\n')
(p/'test-hashes.json').write_text(json.dumps(hashes(tests),indent=2)+'\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();(i/'context.json').write_text(json.dumps(dict(upstream=head),indent=2)+'\n')
for name in ['release-policy-identity.json','native-catalog-reuse.json']:
 shutil.copy2(old/name,r/name)
for name,digest in json.loads((r/'release-policy-identity.json').read_text())['files'].items():
 actual=(repo/name).read_bytes();assert hashlib.sha256(actual).hexdigest()==digest
 assert actual==subprocess.check_output(['git','show','13d2782a494415ba72bc604a0ef7e4c4f875ba25:'+name],cwd=repo)
for name,digest in json.loads((r/'native-catalog-reuse.json').read_text())['native_input_sha256'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
owned=subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines();assert len(owned)==6
(r/'owned-source-paths.json').write_text(json.dumps(owned,indent=2)+'\n');(r/'owned-input-sha256.json').write_text(json.dumps({name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in owned},indent=2)+'\n')
print(json.dumps(dict(source=len(src),tests=len(tests),owned=len(owned),head=head)))
