// Keep Git's non-force receive-pack protocol, using Node TLS for GitHub only.
// Credential stays in memory; loopback Git never receives it.
import http from 'node:http';
import {execFileSync,spawn} from 'node:child_process';
const repo='/Users/david/Developer/PaperLeet-torch-release';
const git='/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/fallback/git';
const env=Object.fromEntries(Object.entries(process.env).filter(([key])=>!key.startsWith('GIT_TRACE')&&!['GIT_CURL_VERBOSE','GH_DEBUG'].includes(key)));
let token;
try{token=execFileSync('/opt/homebrew/bin/gh',['auth','token'],{encoding:'utf8',env,stdio:['ignore','pipe','pipe']}).trim();if(!token)throw Error();}
catch{console.error('Unable to obtain existing GitHub credential');process.exit(1);}
const authorization='Basic '+Buffer.from('x-access-token:'+token).toString('base64');token='';
const server=http.createServer(async(req,res)=>{
 try{
  const url=new URL(req.url,'http://127.0.0.1');
  const match=url.pathname.match(/^\/PaperLeet\/paperleet\.github\.io(?:\.git)?\/(info\/refs|git-receive-pack)$/);
  if(!match||!(req.method==='GET'&&match[1]==='info/refs'&&url.search==='?service=git-receive-pack'||req.method==='POST'&&match[1]==='git-receive-pack'&&!url.search)){res.writeHead(403);res.end();return;}
  const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>512*1024*1024)throw Error('request limit');chunks.push(chunk);}
  const headers={authorization,'accept-encoding':'identity'};
  for(const name of ['content-type','content-encoding','accept','git-protocol','user-agent'])if(req.headers[name])headers[name]=req.headers[name];
  const response=await fetch('https://github.com'+url.pathname+url.search,{method:req.method,headers,body:req.method==='POST'?Buffer.concat(chunks):undefined,redirect:'manual'});
  if(response.status>=300&&response.status<400)throw Error('unexpected redirect');
  const body=Buffer.from(await response.arrayBuffer());
  const output={};for(const name of ['content-type','cache-control','expires','pragma']){const value=response.headers.get(name);if(value)output[name]=value;}
  output['content-length']=body.length;res.writeHead(response.status,output);res.end(body);
 }catch{if(!res.headersSent)res.writeHead(502);res.end('GitHub transport failure');}
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const port=server.address().port;
try{
 const result=await new Promise((resolve,reject)=>{
  const child=spawn(git,['-c',`url.http://127.0.0.1:${port}/.insteadOf=https://github.com/`,'-c','credential.helper=','-c','http.extraHeader=','-c','push.followTags=false','-c','http.version=HTTP/1.1','-c','http.postBuffer=524288000','push','origin','HEAD:main'],{cwd:repo,env,stdio:'inherit'});
  child.on('error',reject);child.on('exit',(code,signal)=>resolve(code??1));
 });
 process.exitCode=result;
}finally{await new Promise(resolve=>server.close(resolve));}
