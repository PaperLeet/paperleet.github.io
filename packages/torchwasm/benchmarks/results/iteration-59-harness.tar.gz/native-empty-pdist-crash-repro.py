"""Optional native-only probe of an already observed unsafe Torch 2.14.1 path.

The regular differential harness deliberately skips this backward geometry.
This distilled probe is not executed by the validation pipeline.
"""
import sys
if sys.argv[1:]!=['--run-native-crash-probe']:
    raise SystemExit('Opt-in native crash probe; pass --run-native-crash-probe to execute.')
import numpy as np
import torch
x=torch.tensor(np.empty((0,7),dtype='float32'),requires_grad=True)
y=torch.pdist(x,p=.5)
print('native',torch.__version__,'before empty pdist backward',flush=True)
(y*torch.tensor(np.empty((0,),dtype='float32'))).sum().backward()
print('native probe returned',flush=True)
