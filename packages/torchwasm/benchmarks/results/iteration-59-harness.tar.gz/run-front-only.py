from pathlib import Path
import json,subprocess,time
r=Path(__file__).resolve().parent;i=r/'integration-proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release');py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';args=[str(py),str(i/'run-frontend.py')];started=time.monotonic()
assert all(v['exit_code']==0 for v in json.loads((i/'export-receipts.json').read_text()))
with (i/'frontend.log').open('w') as log:p=subprocess.run(args,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
(i/'receipts.json').write_text(json.dumps([dict(label='frontend',args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-started)],indent=2)+'\n');p.check_returncode();print('frontend TERMINAL 0',flush=True)
