from pathlib import Path
import os,subprocess,json,time
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');receipts=[]
plans=[('cpu-distance',[py,r/'differential-distances.py','adapter']),('cpu-qualification',[py,r/'qualify-distances.py']),('node-distance',['/opt/homebrew/bin/node',r/'proof/oracle-node.mjs']),('chrome-distance',['/opt/homebrew/bin/node',r/'proof/chrome-contracts/oracle-run.mjs'])]
for name,args in plans:
 start=time.monotonic()
 with (r/(name+'.log')).open('w') as log:p=subprocess.run([str(v) for v in args],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(name=name,args=[str(v) for v in args],exit_code=p.returncode,elapsed_s=time.monotonic()-start));(r/'oracle-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,'TERMINAL',p.returncode,flush=True);p.check_returncode()
