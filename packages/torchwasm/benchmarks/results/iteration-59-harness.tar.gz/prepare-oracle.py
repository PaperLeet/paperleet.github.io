from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;c=r/'proof/chrome-contracts'
(c/'index.html').write_text('<!doctype html><title>Distance qualification</title>')
files=['differential-distances.py','qualify-distances.py','native-distances.json','native-distances.npz','distance-inputs.npz','distance-inputs.json','differential-distance-controls.py','native-distance-controls.json','native-distance-controls.npz']
for name in files:shutil.copy2(r/name,c/name)
plan=dict(source=json.loads((r/'proof/source-hashes.json').read_text()),files={name:hashlib.sha256((r/name).read_bytes()).hexdigest() for name in files})
(c/'oracle-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
python="""
import sys,json,pathlib,hashlib
sys.path.insert(0,'/runtime')
plan=json.loads(plan_json)
for name,digest in plan['source'].items():assert hashlib.sha256(pathlib.Path('/runtime/stridetorch',name).read_bytes()).hexdigest()==digest
for name,digest in plan['files'].items():assert hashlib.sha256(pathlib.Path('/oracle',name).read_bytes()).hexdigest()==digest
sys.argv=['/oracle/differential-distances.py','adapter']
exec(compile(pathlib.Path(sys.argv[0]).read_text(),sys.argv[0],'exec'),{'__file__':sys.argv[0],'__name__':'__main__'})
sys.argv=['/oracle/differential-distance-controls.py','adapter']
exec(compile(pathlib.Path(sys.argv[0]).read_text(),sys.argv[0],'exec'),{'__file__':sys.argv[0],'__name__':'__main__'})
script='/oracle/qualify-distances.py'
exec(compile(pathlib.Path(script).read_text(),script,'exec'),{'__file__':script,'__name__':'__main__'})
report=json.loads(pathlib.Path('/oracle/distances-qualification.json').read_text())
assert report['source_hashes']==plan['source']
json.dumps(dict(status='success',qualification=report))
"""
worker="""import {loadJudgePackages} from '../../../extraction-browser/packages.mjs';
self.onmessage=async()=>{try{
 const plan=await(await fetch('./oracle-plan.json')).json();
 const {loadPyodide}=await import('../../../runtime-0.29.4/pyodide.mjs');
 const py=await loadPyodide({indexURL:new URL('../../../runtime-0.29.4/',self.location.href).href,stdout(){},stderr(){}});
 await loadJudgePackages(py,[]);py.FS.mkdirTree('/runtime/stridetorch');py.FS.mkdirTree('/oracle');
 for(const name of Object.keys(plan.source))py.FS.writeFile('/runtime/stridetorch/'+name,await(await fetch('./source/'+name)).text());
 for(const name of Object.keys(plan.files))py.FS.writeFile('/oracle/'+name,new Uint8Array(await(await fetch('./'+name)).arrayBuffer()));
 py.globals.set('plan_json',JSON.stringify(plan));
 const report=JSON.parse(py.runPython(PYTHON));
 self.postMessage({...report,pyodide:py.version,numpy:py.runPython('__import__("numpy").__version__')});
}catch(error){self.postMessage({error:String(error.stack||error)});}};
""".replace('PYTHON',json.dumps(python))
(c/'oracle-worker.mjs').write_text(worker)
s=(c/'run.mjs').read_text().replace('./worker.mjs','./oracle-worker.mjs').replace("'result.json'","'oracle-result.json'").replace("['run.mjs','worker.mjs','plan.json']","['oracle-run.mjs','oracle-worker.mjs','oracle-plan.json']")
(c/'oracle-run.mjs').write_text(s)
node="""import fs from 'node:fs';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const root=new URL('./chrome-contracts/',import.meta.url);const plan=JSON.parse(fs.readFileSync(new URL('oracle-plan.json',root)));
const py=await loadPyodide({indexURL:'/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/',packageCacheDir:'/Users/david/Developer/PaperLeet-torch-release/web/public/browser-runtime/pyodide-0.29.4/',stdout(){},stderr(){}});
await loadJudgePackages(py,[]);py.FS.mkdirTree('/runtime/stridetorch');py.FS.mkdirTree('/oracle');
for(const name of Object.keys(plan.source))py.FS.writeFile('/runtime/stridetorch/'+name,fs.readFileSync(new URL('source/'+name,root)));
for(const name of Object.keys(plan.files))py.FS.writeFile('/oracle/'+name,fs.readFileSync(new URL(name,root)));
py.globals.set('plan_json',JSON.stringify(plan));const report=JSON.parse(py.runPython(PYTHON));
report.pyodide=py.version;report.numpy=py.runPython('__import__("numpy").__version__');fs.writeFileSync(new URL('oracle-node-result.json',import.meta.url),JSON.stringify(report,null,2)+'\\n');console.log(JSON.stringify({status:report.status,counts:report.qualification.counts}));
""".replace('PYTHON',json.dumps(python))
(r/'proof/oracle-node.mjs').write_text(node)
