from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
subprocess.check_call([sys.executable,str(r/'audit-main.py'),sys.argv[1]],cwd=repo)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip()
subprocess.check_call(['/opt/homebrew/bin/node',str(r/'push-via-node.mjs')],cwd=repo)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();remote=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/git/ref/heads/main','--jq','.object.sha'],cwd=repo,text=True).strip();assert remote==head;print('EXACT_REMOTE_MAIN',head,flush=True)
