from pathlib import Path
import json,os,subprocess,time,re
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';start=time.monotonic();env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
with (r/'full-native.log').open('w') as log:p=subprocess.run([str(py),'-m','pytest','tests','packages/stridetorch/tests','-q'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt=dict(exit_code=p.returncode,elapsed_s=time.monotonic()-start);m=re.search(r'(\d+) passed, (\d+) skipped, (\d+) warnings in ([\d.]+)s',(r/'full-native.log').read_text())
if m:receipt.update(passed=int(m[1]),skipped=int(m[2]),warnings=int(m[3]),duration_s=float(m[4]))
(r/'full-root-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True);p.check_returncode()
