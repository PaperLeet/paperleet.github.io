from pathlib import Path
import json,warnings,sys
import numpy as np
import torch as native
from stridetorch import torch as candidate

native.set_num_threads(2)
root=Path(__file__).parent;rows=[]
def summary(value):
    a=np.asarray(value)
    return dict(shape=a.shape,dtype=a.dtype.name,head=a.reshape(-1)[:8].tolist(),finite=int(np.isfinite(a).sum()),size=a.size)
def run(api,data,dim,keepdim,target,functional):
    x=api.tensor(data,dtype=getattr(api,data.dtype.name),requires_grad=data.dtype.kind=='f')
    options=dict(dim=dim,keepdim=keepdim)
    if target is not None:options['dtype']=getattr(api,target)
    y=api.mean(x,**options) if functional else x.mean(**options)
    output=y.detach().numpy().copy();gradient=None
    if x.requires_grad:
        seed=np.full(output.shape,.37,dtype=output.dtype)
        y.backward(api.tensor(seed,dtype=getattr(api,output.dtype.name)))
        gradient=x.grad.numpy().copy()
    return output,gradient
with warnings.catch_warnings():
 warnings.simplefilter('ignore')
 for source in ('float16','float32','float64','int64','bool'):
  for shape in [(),(16,),(3,5),(0,3),(65536,)]:
   count=int(np.prod(shape));raw=np.ones(shape) if count==65536 else np.linspace(-.9,1.1,max(1,count))[:count].reshape(shape)
   data=raw.astype(source)
   dims=[None,0,-1,[],list(range(len(shape)))]
   for dim in dims:
    for keepdim in (False,True):
     for target in (None,'float16','float32','float64'):
      for functional in (False,True):
       config=dict(source=source,shape=shape,dim=dim,keepdim=keepdim,target=target,functional=functional)
       values=[];errors=[]
       for api in (native,candidate):
        try:values.append(run(api,data,dim,keepdim,target,functional));errors.append(None)
        except Exception as error:values.append(None);errors.append(type(error).__name__)
       categories=[]
       if errors[0]!=errors[1]:categories.append('exception')
       elif not errors[0]:
        for index,name in enumerate(('value','gradient')):
         a,b=values[0][index],values[1][index]
         if a is None or b is None:
          if a is not b:categories.append(name)
          continue
         tolerance={'float16':(2e-3,2e-5),'float32':(2e-6,2e-7),'float64':(2e-11,1e-12)}[a.dtype.name]
         if a.dtype.name=='float16':tolerance=(2e-3,0.)
         if a.shape!=b.shape or a.dtype!=b.dtype or not np.allclose(a,b,rtol=tolerance[0],atol=tolerance[1],equal_nan=True):categories.append(name)
       rows.append(dict(config=config,differences=categories,errors=errors,results=[None if value is None else [None if a is None else summary(a) for a in value] for value in values]))
 for dim in (True,False,1.,[True],(0,0),3):
  for keepdim in (False,1,None):
   errors=[]
   for api in (native,candidate):
    try:run(api,np.ones((2,3),dtype=np.float64),dim,keepdim,None,False);errors.append(None)
    except Exception as error:errors.append(type(error).__name__)
   rows.append(dict(config=dict(invalid_dim=dim,keepdim=keepdim),differences=['exception'] if errors[0]!=errors[1] else [],errors=errors))
report=dict(native=native.__version__,numpy=np.__version__,cases=len(rows),differences=sum(bool(x['differences']) for x in rows),categories={name:sum(name in x['differences'] for x in rows) for name in ('exception','value','gradient')},rows=rows)
(root/('mean-audit-'+(sys.argv[1] if len(sys.argv)>1 else 'strict-baseline')+'.json')).write_text(json.dumps(report,indent=2)+'\n')
print({k:v for k,v in report.items() if k!='rows'})
