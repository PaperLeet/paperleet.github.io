"""Consolidate exactly the six prespecified processes; preserve every failed gate."""
from pathlib import Path
import hashlib,json,statistics
r=Path(__file__).resolve().parent;b=r.parent
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=read(b/'torch-iteration-421/result.json');continuation=read(b/'torch-iteration-423/result.json')
assert continuation['status']=='completed_four_unrun_processes' and continuation['processes']==4
assert [x['label'] for x in old['receipts']]+[x['label'] for x in continuation['receipts']]==['cpu25-0','node-0','cpu25-1','node-1','cpu25-2','node-2']
config=read(b/'torch-iteration-415/config.json');assert read(b/'torch-iteration-422/config.json')==config
processes=[];failures=[];diagnostics=[]
for receipt in old['receipts']+continuation['receipts']:
 label=receipt['label'];stage=415 if label.endswith('-0') else 422
 path=b/f'torch-iteration-{stage}'/('latency-'+label+'.json');wrapped=read(path);report=wrapped.get('report',wrapped)
 assert sha(path)==receipt['result_sha256'] and report['config']==config and len(report['rows'])==32
 for row in report['rows']:
  aa=[row['aa_ratio'],row['paired_aa_ratio']];candidate=[row['candidate_ratio'],row['paired_candidate_ratio']]
  assert row['aa_passed']==all(.95<=ratio<=1.05 for ratio in aa)
  if not row['aa_passed']:failures.append(dict(label=label,case=row['spec']['key'],gate='aa',ratios=aa))
  if max(candidate)>1.10:failures.append(dict(label=label,case=row['spec']['key'],gate='candidate_regression',ratios=candidate))
  if row['minimum_batch_seconds']<.10:failures.append(dict(label=label,case=row['spec']['key'],gate='minimum_batch',seconds=row['minimum_batch_seconds']))
  diagnostics.append(dict(label=label,case=row['spec']['key'],aa=aa,candidate=candidate,minimum_batch_seconds=row['minimum_batch_seconds'],aa_passed=row['aa_passed']))
 processes.append(dict(label=label,result=str(path),sha256=sha(path),rows=32,minimum_batch_seconds=min(x['minimum_batch_seconds'] for x in report['rows']),aa_failures=sum(not x['aa_passed'] for x in report['rows'])))
result=dict(status='passed_prespecified_precision_protocol' if not failures else 'inconclusive_prespecified_precision_protocol',processes=processes,total_cases=192,failures=failures,diagnostic_rows=diagnostics,first_campaign_preserved=True,original_supervisor_failure_preserved=True,incomplete_node0_stdout_preserved=True,no_measurements_repeated=True,implementation_changed=False,production_changed=False,ci_triggered=False,goal_status='active')
(r/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],processes=6,total_cases=192,aa_failures=sum(x['gate']=='aa' for x in failures),regressions=sum(x['gate']=='candidate_regression' for x in failures),minimum_batch_failures=sum(x['gate']=='minimum_batch' for x in failures))))
