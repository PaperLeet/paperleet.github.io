import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
export async function execute(mode,cycle,plan,read,diagnostic){
 const url=new URL('../torch-iteration-76/runtime/',import.meta.url);
 const py=await loadPyodide({indexURL:url.protocol==='file:'?decodeURIComponent(url.pathname):url.href,stdout:diagnostic,stderr:diagnostic});
 await py.loadPackage('numpy');py.runPython('import sys;sys.dont_write_bytecode=True');
 for(const [name,item] of Object.entries(plan.payload)){
  const bytes=await read(item);py.FS.mkdirTree('/qualification/'+name.split('/').slice(0,-1).join('/'));py.FS.writeFile('/qualification/'+name,bytes);
 }
 const before=py._module.HEAPU8.buffer.byteLength;
 const args=mode==='latency'?['/qualification/benchmark.py','--source-root','/qualification','--config','/qualification/config.json','--cycle',String(cycle),'--output','/result.json']:['/qualification/memory.py','--source-root','/qualification','--output','/result.json','--no-tracemalloc'];
 const report=JSON.parse(py.runPython('import sys,runpy,json;sys.argv='+JSON.stringify(args)+";runpy.run_path(sys.argv[0],run_name='__main__');json.dumps(json.load(open('/result.json')))"));
 const primary_json=py.FS.readFile('/result.json',{encoding:'utf8'});
 const samples_jsonl=mode==='latency'?py.FS.readFile('/result.samples.jsonl',{encoding:'utf8'}):null;
 return {report,primary_json,samples_jsonl,pyodide:py.version,heap_capacity_before:before,heap_capacity_after:py._module.HEAPU8.buffer.byteLength};
}
