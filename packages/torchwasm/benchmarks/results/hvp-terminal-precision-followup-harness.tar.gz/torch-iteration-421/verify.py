from pathlib import Path
import hashlib,json,statistics
r=Path(__file__).resolve().parent;b=r.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
config=read(b/'torch-iteration-415/config.json');receipts=[]
assert read(b/'torch-iteration-416/progress.json')['status']=='failed'
for label in ['cpu25-0','node-0']:
 p=b/'torch-iteration-415'/('latency-'+label+'.json');log=b/'torch-iteration-416'/(label+'.log');wrapped=read(p);report=wrapped.get('report',wrapped)
 assert report['status']=='completed' and report['cycle']==0 and report['config']==config
 assert report['config_sha256']==sha(b/'torch-iteration-415/config.json')
 assert report['workloads_sha256']==sha(b/'torch-iteration-407/workloads.py')
 assert report['native_reference_sha256']==sha(b/'torch-iteration-407/native26.json')
 rows=report['rows'];assert len(rows)==32 and len({x['spec']['key'] for x in rows})==32
 for row in rows:
  assert row['independent_owned_outputs'] and len(row['orders'])==12
  assert all(len(row['samples'][name])==12 for name in ['A0','A1','B'])
  med={name:statistics.median(x['seconds_per_call'] for x in samples) for name,samples in row['samples'].items()};assert med==row['medians']
  for samples in row['samples'].values():
   for x in samples:
    assert x['iterations']==row['count'] and x['batch_seconds']>0
    assert x['seconds_per_call']==x['batch_seconds']/x['iterations']
    assert abs((x['ended_seconds']-x['started_seconds'])-x['batch_seconds'])<1e-8
  ratios=dict(aa_ratio=med['A1']/med['A0'],candidate_ratio=med['B']/med['A0'],paired_aa_ratio=statistics.median(y['seconds_per_call']/x['seconds_per_call'] for x,y in zip(row['samples']['A0'],row['samples']['A1'])),paired_candidate_ratio=statistics.median(y['seconds_per_call']/x['seconds_per_call'] for x,y in zip(row['samples']['A0'],row['samples']['B'])))
  for name,value in ratios.items():assert row[name]==value
  assert row['aa_passed']==all(.95<=row[name]<=1.05 for name in ['aa_ratio','paired_aa_ratio'])
  assert row['minimum_batch_seconds']==min(x['batch_seconds'] for samples in row['samples'].values() for x in samples)
 raw=[json.loads(line[len('HVP_SAMPLE '):]) for line in log.read_text().splitlines() if line.startswith('HVP_SAMPLE ')]
 assert raw==rows[:len(raw)] and len(raw)==(32 if label.startswith('cpu') else 12)
 receipts.append(dict(label=label,result=str(p),result_sha256=sha(p),log=str(log),log_sha256=sha(log),rows=32,diagnostic_stdout_rows=len(raw),diagnostic_stdout_complete=len(raw)==32,aa_failures=[x['spec']['key'] for x in rows if not x['aa_passed']],regressions_above_ten_percent=[x['spec']['key'] for x in rows if max(x['candidate_ratio'],x['paired_candidate_ratio'])>1.1],minimum_batch_failures=[x['spec']['key'] for x in rows if x['minimum_batch_seconds']<config['minimum_batch_seconds']],minimum_batch_seconds=min(x['minimum_batch_seconds'] for x in rows)))
result=dict(status='validated_complete_primary_data_with_incomplete_node_diagnostic_stdout',prior_supervisor_status='failed_preserved',old_stdout_mirror_gate_passed=False,measurements_repeated=False,receipts=receipts,remaining_jobs=['cpu25-1','node-1','cpu25-2','node-2'],strict_timing_qualification_passed=False,production_changed=False)
(r/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
