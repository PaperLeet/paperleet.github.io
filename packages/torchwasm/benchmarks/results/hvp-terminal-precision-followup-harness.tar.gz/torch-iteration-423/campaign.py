"""Continue only four unrun precision processes; preserve two completed measurements and failures."""
from pathlib import Path
import hashlib,json,os,subprocess,time,traceback
r=Path(__file__).resolve().parent;b=r.parent;bench=b/'torch-iteration-422';source=b/'torch-iteration-407'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
plan=read(r/'plan.json');receipts=[]
def verify():
 assert sha(Path(__file__))==plan['runner_sha256']
 for path,h in plan['required_files'].items():assert sha(Path(path))==h,path
 manifest=read(bench/'source-plan.json')
 for name,h in manifest['files'].items():assert sha(bench/name)==h,name
 for item in list(manifest['payload'].values())+manifest['prerequisites']:assert sha((bench/item['source']).resolve())==item['sha256'],item['source']
def progress(status,**details):write(r/'progress.json',dict(status=status,pid=os.getpid(),observed_unix=time.time(),receipts=receipts,**details))
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
for key in ['PYTHONPATH','NODE_OPTIONS','PYTHONTRACEMALLOC','PYTHONPROFILEIMPORTTIME']:env.pop(key,None)
try:
 verify()
 for cycle in [1,2]:
  for runtime in ['cpu25','node']:
   label=f'{runtime}-{cycle}';log=r/(label+'.log');assert not log.exists()
   if runtime.startswith('cpu'):
    target=bench/f'latency-{runtime}-{cycle}.json';args=[plan['pythons'][runtime],'-B',str(bench/'benchmark.py'),'--source-root',str(source),'--config',str(bench/'config.json'),'--cycle',str(cycle),'--output',str(target)]
   else:
    target=bench/f'latency-{runtime}-{cycle}.json';args=[plan['node'],str(bench/'run.mjs'),runtime,'latency',str(cycle)]
   assert not target.exists();verify();started=time.time()
   with log.open('w') as output:
    child=subprocess.Popen(args,cwd=bench,env=env,stdout=output,stderr=subprocess.STDOUT);progress('running',label=label,child_pid=child.pid,command=args);print(json.dumps(dict(status='running',label=label,pid=child.pid)),flush=True);code=child.wait()
   receipt=dict(label=label,exit_code=code,seconds=time.time()-started,log_sha256=sha(log));receipts.append(receipt);write(r/'receipts.json',receipts);assert code==0,receipt
   verify();wrapped=read(target);report=wrapped.get('report',wrapped);assert report['status']=='completed' and len(report['rows'])==32 and report['cycle']==cycle
   raw=[json.loads(line) for line in target.with_suffix('.samples.jsonl').read_text().splitlines()];assert raw==report['rows'] and len(raw)==32
   stdout_rows=[json.loads(line[len('HVP_SAMPLE '):]) for line in log.read_text().splitlines() if line.startswith('HVP_SAMPLE ')]
   assert stdout_rows==raw[:len(stdout_rows)]
   receipt.update(durable_ledger_sha256=sha(target.with_suffix('.samples.jsonl')),diagnostic_stdout_rows=len(stdout_rows))
   assert len({row['spec']['key'] for row in raw})==32
   receipt.update(result_sha256=sha(target),aa_failures=[row['spec']['key'] for row in raw if not row['aa_passed']],regressions_above_ten_percent=[row['spec']['key'] for row in raw if max(row['candidate_ratio'],row['paired_candidate_ratio'])>1.10],minimum_batch_seconds=min(row['minimum_batch_seconds'] for row in raw))
   write(r/'receipts.json',receipts);print(json.dumps(dict(status='completed_process',**receipt)),flush=True)
 result=dict(status='completed_four_unrun_processes',processes=4,flows_per_process=32,receipts=receipts,aa_controls_passed=sum(32-len(x['aa_failures']) for x in receipts),aa_controls_total=128,aa_failures=sum(len(x['aa_failures']) for x in receipts),regressions_above_ten_percent=sum(len(x['regressions_above_ten_percent']) for x in receipts),minimum_batch_seconds=min(x['minimum_batch_seconds'] for x in receipts),production_changed=False,ci_triggered=False,goal_status='active')
 write(r/'result.json',result);progress('completed');print(json.dumps(result),flush=True)
except BaseException as error:progress('failed',error=str(error),traceback=traceback.format_exc());raise
