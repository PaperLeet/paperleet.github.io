from pathlib import Path
import collections,hashlib,io,json,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
result=read(b/'torch-iteration-427/result.json');assert result['status']=='inconclusive_prespecified_precision_protocol' and result['total_cases']==192
counts=collections.Counter(x['gate'] for x in result['failures']);assert counts==dict(aa=12,minimum_batch=2,candidate_regression=1),counts
assert read(b/'torch-iteration-423/progress.json')['status']=='completed' and read(b/'torch-iteration-416/progress.json')['status']=='failed'
dep=out/'hvp-terminal-expanded-first-campaign-harness.tar.gz';assert sha(dep)=='0e95b66a92a207648dd874d423117735ada33dd1b72e136b62bbd1a6beb8e39b'
write(r/'replay-dependencies.json',dict(earlier_archive=dict(path=str(dep.relative_to(repo)),sha256=sha(dep),scope='407frozenworkload,bothimplementations,native32oracle;408/409functionalproofs;410/412firstcampaign;411memory;415/416originalplans;linked394native4480oracles'),external=['ExistingPyodide0.29.4runtime76andSDKpackagehelper','Node22.22.1','Python3.12.11NumPy2.5.4','Pathsandbrowserexecutablesneedadaptation'],scope='Preserveoriginalfailedsupervisorandpartialstdout;continuationonlyfourpreviouslyunrunprocesses;all6completeprimaryrecords;noresultreplacement'))
files=[p for n in [415,416,421,422,423,427,445] for p in (b/f'torch-iteration-{n}').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='archive-receipt.json']
manifest={str(p.relative_to(b)):sha(p) for p in files};target=out/'hvp-terminal-precision-followup-harness.tar.gz';assert not target.exists();seen={}
with tarfile.open(target,'w:gz') as archive:
 for p in sorted(files):
  name=str(p.relative_to(b));h=manifest[name]
  if h in seen:
   info=archive.gettarinfo(str(p),arcname=name);info.type=tarfile.LNKTYPE;info.linkname=seen[h];info.size=0;archive.addfile(info)
  else:archive.add(p,arcname=name,recursive=False);seen[h]=name
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256.json');info.size=len(data);archive.addfile(info,io.BytesIO(data))
with tarfile.open(target) as archive:
 for name,h in manifest.items():assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==h,name
receipt=dict(path=str(target.relative_to(repo)),files=len(files),unique_payloads=len(seen),bytes=target.stat().st_size,sha256=sha(target),all_payloads_verified=True);write(r/'archive-receipt.json',receipt)
write(out/'hvp-terminal-precision-followup.json',dict(result,failed_gate_counts=dict(counts),raw_archive=receipt,replay_dependencies=read(r/'replay-dependencies.json')))
p=repo/'docs/validation/torch-runtime-hvp-terminal-values-expanded.md';s=p.read_text();s=s.replace('Follow-up results, packaging,\napplication/export qualification and any eventual integration remain pending.','The follow-up is now complete and remains inconclusive (see below). The\nterminal-HVP candidate is not adopted; release packaging and application/export\nqualification for this optimization have not been performed.')
s+='''\n## Completed precision follow-up: retain failed gates, no adoption\n\nAll six prespecified processes have complete 32-case primary records. The\noriginal supervisor stopped after its second process: Node's primary JSON\ncontains all 32 cases, but its stdout mirror contains only the first 12.\nExperiment 421 verifies every primary batch, recomputed median, both ratios,\nsource identity and the matching stdout prefix. That failed mirror check is\npreserved. A fresh driver adds a per-case ledger and synchronous host writes;\n423 runs only the four previously unrun processes. All four durable ledgers and\nstdout mirrors match their respective primary records. No completed measurement\nis replaced or repeated.\n\nAcross all 192 precision cases, 12 A/A controls fail (all in Node). Two first-cycle\nbatches fall below the unchanged 100 ms floor: 97.854 ms on CPU and 99.643 ms in\nNode. CPU cycle 2's float64 zero-norm case also exceeds the 10% candidate\nregression limit using the ratio of medians: 1.17359, while its paired-block\nratio is 1.02126. Both estimators were required; the paired diagnostic does not\nwaive that failure. The result remains **inconclusive**, and the canonical\nruntime retains its qualified 0.81 HVP implementation. Numerical and scoped\nmemory evidence remain useful, but do not establish a complete latency benefit.\n\n'''
s+=f'[Machine-readable precision results](../../packages/stridetorch/benchmarks/results/hvp-terminal-precision-followup.json) and [verified raw archive](../../{receipt["path"]}): {receipt["files"]} files, {receipt["bytes"]:,} bytes, SHA-256 `{receipt["sha256"]}`. The replay manifest links the earlier archive for frozen implementations, workload and independent oracle inputs.\n'
p.write_text(s);print(json.dumps(receipt),flush=True)
