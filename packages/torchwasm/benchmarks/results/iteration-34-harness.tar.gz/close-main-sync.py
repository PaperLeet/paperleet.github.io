from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).resolve().parent;p=r/'main-sync-proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
context=json.loads((p/'context.json').read_text());receipts=json.loads((p/'receipts.json').read_text());assert len(receipts)==16 and all(x['exit_code']==0 for x in receipts)
for name,digest in context['incoming_files'].items():assert sha(repo/name)==digest,name
assert all(sha(repo/'packages/stridetorch/src/stridetorch'/k)==v for k,v in context['source_hashes'].items());assert all(sha(repo/'web/public/data'/k)==v for k,v in context['export_sha256'].items())
for name in ('.github/workflows/ci.yml','.github/workflows/pages.yml','web/scripts/check-release-request.cjs','web/scripts/pages-release-gate.cjs','docs/releasing.md'):assert (repo/name).read_bytes()==subprocess.check_output(['git','show',context['upstream']+':'+name],cwd=repo),name
archive=out/'iteration-34-main-sync-harness.tar.gz';files=[f for f in p.rglob('*') if f.is_file()]
with tarfile.open(archive,'w:gz') as tar:
 for f in files:tar.add(f,arcname=str(f.relative_to(p)),recursive=False)
report=dict(status='latest_main_scoped_checks_passed_adoption_pending',version='0.34.0',context=context,receipts=receipts,react_review=json.loads((p/'react-review.json').read_text()),core_report='iteration-34.json',application_report='iteration-34-integration.json',archive=dict(file=archive.name,files=len(files),bytes=archive.stat().st_size,sha256=sha(archive)),retained_failures='First scoped runner used repository root as cwd,but upstream Vite script requires web cwd. SSR could not resolve/src/i18n.tsx. Corrected only runner cwd;all14checks/bothbuilds pass unchanged upstream source. First failure logs retained.',publication='No CI,tag,dispatch or online release triggered.')
(out/'iteration-34-main-sync.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],archive=report['archive']),indent=2))
