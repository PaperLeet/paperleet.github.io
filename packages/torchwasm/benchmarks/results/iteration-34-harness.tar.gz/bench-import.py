from pathlib import Path
import hashlib,importlib.util,json,os,sys,time
source=Path(os.environ['IMPORT_SOURCE']);preloaded=os.environ['IMPORT_PRELOAD']=='1'
if preloaded:import numpy
start=time.perf_counter();spec=importlib.util.spec_from_file_location('cold_stride',source/'__init__.py',submodule_search_locations=[str(source)]);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);namespace=m.torch;elapsed=time.perf_counter()-start
assert namespace.ones(1).item()==1.
print(json.dumps(dict(python=sys.version,numpy=sys.modules['numpy'].__version__,version=m.__version__,numpy_preloaded=preloaded,namespace_import_ms=elapsed*1000,zipfile_imported='zipfile' in sys.modules,source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')})))
