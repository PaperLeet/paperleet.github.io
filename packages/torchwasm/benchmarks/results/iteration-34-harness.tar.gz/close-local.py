from pathlib import Path
import hashlib,json,os,re,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results';proof=r/'proof';i=r/'integration-proof'
def read(name):return json.loads((r/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
actual={p.name:sha(p) for p in (repo/'packages/stridetorch/src/stridetorch').iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};assert len(actual)==47 and actual==read('proof/source-hashes.json')
plan=read('proof/chrome-contracts/plan.json');tests={p.name:sha(p) for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'};assert plan['source']==actual and plan['expected']==1439 and len(tests)==34 and plan['tests']==tests
gates=read('proof/gate-receipts.json');assert len(gates)==6 and all(x['exit_code']==0 for x in gates.values());full=read('full-root-receipt.json');assert full['exit_code']==0;log=(r/'full-native.log').read_text();m=re.search(r'(\d+) passed, (\d+) skipped, (\d+) warnings in ([\d.]+)s',log);assert m and int(m[1])>=32043 and int(m[2])==1;full.update(passed=int(m[1]),optional_skipped=int(m[2]),warnings=int(m[3]),duration_s=float(m[4]))
node=read('proof/source-wasm.json');chrome=read('proof/chrome-contracts/result.json');wheel=read('proof/wheel-stride034-result.json');coinstall=read('proof/coinstall-result.json');assert node['passed']==chrome['passed']==1439 and node['source_hashes']==chrome['source_hashes']==wheel['source_hashes']==coinstall['source_hashes']==actual and chrome['test_hashes']==tests and chrome['status']==wheel['status']==coinstall['status']=='success' and not wheel['native_torch'];assert '1451 passed' in (proof/'python310-stride034-tests.log').read_text();assert '667 passed' in (r/'focus-shared.log').read_text()
performance=read('performance-final-summary.json');imports=read('import-summary.json');assert len(performance['receipts'])==16 and all(x['exit_code']==0 for x in performance['receipts'].values());assert len(imports['receipts'])==16 and all(x['exit_code']==0 for x in imports['receipts'])
for report in (r/'performance-final').glob('*.json'):
 if report.name!='receipts.json':assert json.loads(report.read_text())['source_hashes']['candidate']==actual
native_ci=read('integration-proof/native-ci.json');wasm=read('integration-proof/full-wasm-result.json');setup=read('integration-proof/setup-receipts.json');front=read('integration-proof/frontend-receipts.json');snapshot=read('integration-proof/release-snapshot.json');exports=read('integration-proof/export-identity.json');private=read('integration-proof/distribution-identity.json')
assert native_ci['passed'] and native_ci['problems']==78 and native_ci['tests_executed']==10218 and native_ci['repeats']==3 and native_ci['duration_s']<=600
assert wasm['passed'] and wasm['catalog_modules']==wasm['modules']==78 and not wasm['browser_budget_exceeded'];assert sum(x['mutants'] for x in wasm['results'])==342 and all(x['passed'] and not x['browser_budget_exceeded'] for x in wasm['results'])
assert len(setup)==4 and len(front)==5 and all(x['exit_code']==0 for x in setup+front);assert snapshot['source_hashes']==actual and exports['published_assets_unchanged']==8333 and exports['all_new_assets_reachable'] and private['status']=='success'
for name,digest in read('integration-proof/live-expected-sha256.json').items():assert sha(repo/'web/public/data'/name)==digest,name
native=r/'native-contracts';native.mkdir(exist_ok=True)
for p in (repo/'tests').glob('test_torch_*'):
 if p.is_file():shutil.copy2(p,native/p.name)
metadata=r/'package-metadata';metadata.mkdir(exist_ok=True)
for name in ('README.md','pyproject.toml','LICENSE','NOTICE'):shutil.copy2(repo/'packages/stridetorch'/name,metadata/name)
def archive(name,root,excluded):
 files=[]
 for folder,dirs,names in os.walk(root):
  dirs[:]=[d for d in dirs if not d.endswith('-env') and d not in excluded and d not in ('__pycache__','.pytest_cache')]
  for name2 in names:
   p=Path(folder)/name2
   if p.is_symlink():continue
   if p.name in ('LICENSE','NOTICE') or p.suffix in ('.py','.mjs','.cjs','.json','.log','.txt','.md','.html','.toml'):files.append(p)
 path=out/name
 with tarfile.open(path,'w:gz') as tar:
  for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
 return dict(file=path.name,files=len(files),bytes=path.stat().st_size,sha256=sha(path))
core_archive=archive('iteration-34-harness.tar.gz',r,{'dist-preflight','private-dist','dist-paperleet','integration-proof','integration-proof-first','main-sync-proof','retired-first-assets'})
core=dict(status='complete_local_core_and_application_gates_passed_main_adoption_pending',version='0.34.0',baseline_main='5779d3a1e36ba538bf33eea23eb4fed02c89369c',source_hashes=actual,standalone_test_hashes=tests,native_test_hashes={p.name:sha(p) for p in native.iterdir()},full_cpu=full,focused_passed=667,minimal_passed=1451,minimal_wheel=wheel,node_wasm=node,actual_chrome_worker=chrome,coinstall=coinstall,gate_receipts=gates,initial_performance=read('performance-final-summary-first.json'),final_performance=performance,cold_namespace_imports=imports,archive=core_archive,scope='Finite real narrow Cholesky-solve JVP has one analytical4input pullback through primal result,factor,RHS direction,factor direction;all full unmasked native reverse edges retained. Direction snapshot when input-factor gradients inactive;selective source/output guards;unneeded result arrays released. Float32/64;unchanged complex inference/unsupported boundaries. No cross-call numerical cache or nativeTorch runtime dependency.',retained_failures=['First180native mutation probes:8candidate mismatches vs12in0.33. Native permits DF source edits without factor adjoint;conditional source snapshot resolves all180.','First expanded focused run627pass/4failure:memory test incorrectly consumed graph before a second backward and assumed active gradient leaves could disappear. Corrected retain_graph/leaf ownership expectations and improved real saved-array selectivity;667finalfocuspasses.','First complete16timingchildren exposed20to25percent quarter-width tangent-backward regression vs0.33;source,all6packagegates/full32043proofs and16measurements retained. Old-source exported WASM run intentionally terminated before completion after this finding. Final refinement shares forward/adjoint n-by-k products rather than narrowing supported shapes.','Initial first4timingchildren used frozen candidate-first before selective snapshot/memory refinement and version bump. Final16children hash-check the final47resources and retain unchanged controls.'],primary_sources=['https://github.com/pytorch/pytorch/blob/v2.14.0/torch/csrc/autograd/FunctionsManual.cpp#L4719','https://docs.pytorch.org/docs/2.14/generated/torch.cholesky_solve.html'],release_policy='No agent tag,dispatch or online publication;ordinary main updates trigger no CI;user will tag later.')
save('iteration-34.json',core)
integration_archive=archive('iteration-34-integration-harness.tar.gz',i,{'dist-paperleet'})
integration=dict(status='complete_local_application_gates_passed_main_adoption_pending',version='0.34.0',upstream=read('integration-proof/context.json')['upstream'],source_hashes=actual,core_report='iteration-34.json',native=native_ci,exported_wasm=wasm,setup_receipts=setup,frontend_receipts=front,release_snapshot=snapshot,export_integrity=exports,distribution_identity=private,runtime_sizes=read('integration-proof/runtime-sizes.json'),wasm_harness=read('integration-proof/wasm-harness-identity.json'),context=read('integration-proof/context.json'),archive=integration_archive,publication='Local results do not assert deployment. No CI,tag or dispatch triggered;user will release later.')
save('iteration-34-integration.json',integration);print(json.dumps(dict(core=core_archive,integration=integration_archive,full_cpu=full,native_duration=native_ci['duration_s'],wasm_ms=wasm['elapsed_ms']),indent=2))
