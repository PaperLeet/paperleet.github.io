from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');old=r.parent/'torch-iteration-33/proof-final';p=r/'proof';p.mkdir();source=repo/'packages/stridetorch/src/stridetorch'
for dest in (p/'source',p/'chrome-contracts/source'):shutil.copytree(source,dest,ignore=shutil.ignore_patterns('__pycache__'))
shutil.copytree(repo/'packages/stridetorch/tests',p/'chrome-contracts/tests',ignore=shutil.ignore_patterns('__pycache__'))
hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in source.iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')};tests={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (repo/'packages/stridetorch/tests').glob('test_*.py') if f.name!='test_standalone.py'};assert len(hashes)==47 and len(tests)==34
(p/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n');(p/'chrome-contracts/plan.json').write_text(json.dumps(dict(version='0.34.0',expected=1439,source=hashes,tests=tests),indent=2)+'\n')
for name in ('chrome-contracts/run.mjs','chrome-contracts/worker.mjs','chrome-contracts/index.html','wasm-contracts.mjs','check-wheel.py','check-coinstall.py'):
 s=(old/name).read_text().replace('torch-iteration-33/proof-final','torch-iteration-34/proof').replace('0.33','0.34').replace('stride033','stride034').replace('1375','1439')
 if name=='check-coinstall.py':
  anchor="print('PASS isolated ownership,aliases,ZIP resume,triangular,Cholesky and Cholesky solve VJP/JVP/full tangent reverse')";assert anchor in s
  addition="""for name in NAMES:
 t=importlib.import_module(name).torch
 f=(t.eye(64,dtype=t.float64)*2).requires_grad_();b=t.full((64,2),.2,dtype=t.float64,requires_grad=True)
 db=t.full_like(b,.03,requires_grad=True);df=t.full_like(f,.01,requires_grad=True)
 x,tangent=t.func.jvp(lambda bb,ff:t.cholesky_solve(bb,ff),(b,f),(db,df))
 np.testing.assert_allclose(x.numpy(),.05);np.testing.assert_allclose(tangent.numpy(),-.0245)
 (x.square().sum()+tangent.square().sum()).backward()
 assert all(a.grad is not None and np.isfinite(a.grad.numpy()).all() for a in (b,f,db,df))
"""+anchor;s=s.replace(anchor,addition)
 (p/name).write_text(s)
s=(r.parent/'torch-iteration-33/run-gates-final.py').read_text().replace("r/'proof-final'","r/'proof'");(r/'run-gates.py').write_text(s)
print('Frozen0.34:47 resources,34suites1439checks,minimal1451')
