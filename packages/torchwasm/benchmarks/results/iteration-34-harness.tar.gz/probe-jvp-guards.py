from pathlib import Path
import importlib.util,itertools,json,sys
import numpy as np
import torch as native
from stridetorch import torch as candidate
r=Path(__file__).resolve().parent;p=r/'baseline/stridetorch';spec=importlib.util.spec_from_file_location('old_stride',p/'__init__.py',submodule_search_locations=[str(p)]);old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
rows=[]
for upper,flags,mutated in itertools.product((False,True),list(itertools.product((False,True),repeat=4))[1:],range(6)):
 results={}
 for name,lib in [('native',native),('old',old.torch),('candidate',candidate)]:
  f=np.eye(65);f[1,0]=.04
  if upper:f=f.T.copy()
  arrays=(np.full((65,2),.2),f,np.full((65,2),.03),np.full((65,65),.01));args=tuple(lib.tensor(a,requires_grad=flag) for a,flag in zip(arrays,flags));x,t=lib.func.jvp(lambda b,f:lib.cholesky_solve(b,f,upper),args[:2],args[2:]);targets=(*args,x,t)
  with lib.no_grad():targets[mutated].detach().add_(.1)
  try:t.sum().backward();results[name]='allowed'
  except RuntimeError:results[name]='guarded'
 rows.append(dict(upper=upper,flags=flags,mutated=mutated,results=results))
(r/'jvp-guards.json').write_text(json.dumps(rows,indent=2)+'\n');mismatch=[row for row in rows if row['results']['native']!=row['results']['candidate']];old_mismatch=[row for row in rows if row['results']['native']!=row['results']['old']];print(json.dumps(dict(cases=len(rows),candidate_mismatches=len(mismatch),old_mismatches=len(old_mismatch),details=mismatch[:20]),indent=2))
