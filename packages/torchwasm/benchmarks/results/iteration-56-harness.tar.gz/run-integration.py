from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,os,shutil,subprocess,time
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');i=r/'integration-proof';receipts=[]
def run(args,label):
 start=time.monotonic()
 with (i/(label+'.log')).open('w') as log:p=subprocess.run(args,cwd=repo,env=dict(os.environ,PAPERLEET_WASM_CONCURRENCY='2'),stdout=log,stderr=subprocess.STDOUT)
 return dict(label=label,args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-start)
assert all(v['exit_code']==0 for v in json.loads((i/'export-receipts.json').read_text()))
plans=[(['/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-21/stride-dev-env/bin/python',str(i/'run-frontend.py')],'frontend'),(['/opt/homebrew/bin/node','web/scripts/check-browser-wasm.mjs','--all'],'full-wasm')]
with ThreadPoolExecutor(max_workers=2) as pool:
 for future in as_completed([pool.submit(run,*plan) for plan in plans]):
  receipt=future.result();receipts.append(receipt);(i/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
  print(receipt['label'],'terminal',receipt['exit_code'],flush=True)
  if receipt['label']=='full-wasm' and receipt['exit_code']==0:shutil.copy2(repo/'reports/browser-wasm.json',i/'full-wasm-result.json')
assert len(receipts)==2 and all(v['exit_code']==0 for v in receipts)
