from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');p=r/'proof';i=r/'integration-proof';out=repo/'packages/stridetorch/benchmarks/results'
read=lambda n:json.loads((r/n).read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def save(f,v):f.write_text(json.dumps(v,indent=2)+'\n')
source={f.name:sha(f) for f in (repo/'packages/stridetorch/src/stridetorch').iterdir() if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']};plan=read('proof/chrome-contracts/plan.json')
assert source==read('proof/source-hashes.json')==plan['source'] and len(source)==59
tests={f.name:sha(f) for f in (repo/'packages/stridetorch/tests').glob('test_*.py') if f.name!='test_standalone.py'};assert tests==plan['tests'] and len(tests)==52
cpu=read('full-root-receipt.json');assert cpu['exit_code']==0 and cpu['passed']==40608 and cpu['skipped']==1
node=read('proof/source-wasm.json');chrome=read('proof/chrome-contracts/result.json');wheel=read('proof/wheel-stride056-result.json');co=read('proof/coinstall-result.json')
assert node['passed']==chrome['passed']==6978 and chrome['test_hashes']==tests
assert node['source_hashes']==chrome['source_hashes']==wheel['source_hashes']==co['source_hashes']==source
assert all(v['status']=='success' for v in [chrome,wheel,co]) and not wheel['native_torch']
assert '6991 passed' in (p/'python310-stride056-tests.log').read_text()
qual=read('sequences-qualification.json');oracle_node=read('proof/oracle-node-result.json');oracle_chrome=read('proof/chrome-contracts/oracle-result.json')
for q in [qual,oracle_node['qualification'],oracle_chrome['qualification']]:
 assert q['status']=='qualified' and q['cases']==4215 and q['source_hashes']==source
 assert q['counts']==dict(native_numeric_arrays=2601,native_numeric_cases=2587,error_cases=1514,widened_half_oracle_cases=5,platform_dependent_integer_cast_cases=109)
for name,digest in qual['input_sha256'].items():assert sha(r/name)==digest
front=read('integration-proof/frontend-receipts.json');integration=read('integration-proof/receipts.json');assert len(front)==5 and len(integration)==2 and all(v['exit_code']==0 for v in front+integration)
wasm=read('integration-proof/full-wasm-result.json');assert wasm['passed'] and wasm['modules']==wasm['catalog_modules']==78;assert sum(v['mutants'] for v in wasm['results'])==342 and all(v['passed'] for v in wasm['results'])
budgetq=read('integration-proof/idle-budget-qualification.json');assert budgetq['status']=='qualified' and budgetq['full_catalog_compatibility_passed']==78 and budgetq['original_catalog_sha256']==sha(i/'full-wasm-contended-result.json')
for case in budgetq['idle_requalified_cases']:assert case['input_identity_unchanged'] and case['exit_code']==0 and sha(i/case['artifact'])==case['artifact_sha256']
contracts=next(v for v in wasm['results'] if v['id']=='architecture/attention')['independent_contracts'];assert contracts['passed']==6978 and len(contracts['suites'])==52 and {v['suite']:v['source_sha256'] for v in contracts['suites']}==tests
exports=read('integration-proof/export-identity.json');assert exports['published_assets_unchanged']==11809 and exports['new_assets']==exports['active_assets']==158
live={};data=repo/'web/public/data';index=json.loads((data/'index.json').read_text())
for entry in index['problems']:
 for name in [entry['detail_url'],entry['browser_judge']['bundle_url']]:live[name]=sha(data/name)
 manifest=json.loads((data/entry['browser_judge']['bundle_url']).read_text());name=manifest['runtime_bundle_url'];live[name]=sha(data/name)
for name in ['index.json','index-v3.json','catalog.json']:live[name]=sha(data/name)
assert len(live)==161;save(i/'live-expected-sha256.json',live)
policy=read('release-policy-identity.json')
for name,digest in policy['files'].items():assert sha(repo/name)==digest
native=read('native-catalog-reuse.json');assert native['files']==1152
for name,digest in native['native_input_sha256'].items():assert sha(repo/name)==digest
isolation=read('native-isolation-result.json');assert isolation['status']=='success' and isolation['library_version']=='0.56.0'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head==read('integration-proof/context.json')['upstream']
sync=read('upstream-sync.json');assert sync['after']==head
for name,digest in sync['paths'].items():assert sha(repo/name)==digest
sync['frontend_rerun_pending']=False;save(r/'upstream-sync.json',sync)
perf=read('performance/identity.json');receipts=read('performance/receipts.json');assert perf['status']=='success' and perf['children']==len(receipts)==12 and all(v['exit_code']==0 for v in receipts)
baseline=json.loads((r.parent/'torch-iteration-55/proof/source-hashes.json').read_text());assert perf['source_hashes']==dict(baseline=baseline,candidate=source);assert sha(repo/'packages/stridetorch/benchmarks/bench_sequences.py')==perf['benchmark_sha256']
for runtime in ['cpu','node','chrome']:
 for repeat in range(4):
  j=read(f'performance/{runtime}-{repeat}.json');j=j.get('benchmark',j);assert len(j['rows'])==29 and j['versions']==dict(baseline='0.55.0',candidate='0.56.0') and j['source_hashes']==perf['source_hashes']
memory=read('performance/memory.json');assert memory['source_hashes']==perf['source_hashes']
fresh=[]
for name,python,path in [('stridetorch',p/'python310-stride056-env/bin/python',p/'stridetorch-activation.pkl'),('paperleet._vendor.torch',p/'coinstall-env/bin/python',p/'paperleet-_vendor-torch-activation.pkl')]:
 result=subprocess.run([str(python),'-I',str(r/'fresh-load.py'),name,str(path)],capture_output=True,text=True,cwd=r);assert result.returncode==0,result.stderr;fresh.append(dict(namespace=name,exit_code=0,output=result.stdout.strip()))
 code=f"import importlib,numpy as np;m=importlib.import_module('{name}');\nwith m.as_torch():\n import torch\n np.testing.assert_array_equal(torch.linspace(-1,1,4,dtype=torch.int64).numpy(),[-1,0,0,1]);np.testing.assert_array_equal(torch.logspace(0,2,3).numpy(),[1,10,100]);assert np.unique(torch.arange(1e8,1e8+20,dtype=torch.float32).numpy()).size>1\n"
 subprocess.run([str(python),'-I','-c',code],cwd=r,check=True)
save(r/'fresh-load-result.json',fresh)
metadata=r/'package-metadata';metadata.mkdir(exist_ok=True)
for name in ['README.md','pyproject.toml','LICENSE','NOTICE']:shutil.copy2(repo/'packages/stridetorch'/name,metadata/name)
shutil.copy2(repo/'packages/stridetorch/tests/test_standalone.py',metadata/'test_standalone.py')
footprint={}
for label,folder,names in [('baseline',r/'baseline-source/stridetorch',baseline),('candidate',repo/'packages/stridetorch/src/stridetorch',source)]:
 payload=b''.join((folder/n).read_bytes() for n in sorted(names));footprint[label]=dict(source_license_bytes=len(payload),local_concatenated_gzip_bytes=len(gzip.compress(payload,mtime=0)))
archive=out/'iteration-56-harness.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as target:
 for current,dirs,files in os.walk(r):
  dirs[:]=[d for d in dirs if d not in ['__pycache__','.pytest_cache'] and not d.endswith(('-env','-venv'))]
  for name in sorted(files):
   f=Path(current)/name
   if not f.is_symlink() and (f.name in ['LICENSE','NOTICE'] or f.suffix in ['.py','.mjs','.json','.log','.md','.html','.toml','.npz','.txt','.whl','.pkl'] or f.name.endswith('.tar.gz')):target.add(f,arcname=f.relative_to(r),recursive=False)
assert archive.stat().st_size<95*1024*1024
report=dict(status='validated_locally',version='0.56.0',baseline_main=head,numerical_baseline_main='32359d74e56cda83411cf53183d58dc65d88ee28',source_hashes=source,test_hashes=tests,changed_resources=sorted(n for n in baseline if source[n]!=baseline[n]),added_resources=['_sequences.py'],added_tests=111,full_cpu=cpu,node_wasm=node,chrome_worker=chrome,minimal_wheel=wheel,coinstall=co,fresh_process=fresh,native_qualification=qual,node_sequence_qualification=oracle_node,chrome_sequence_qualification=oracle_chrome,native_catalog_reuse=native,native_dtype_isolation=isolation,export_identity=exports,active_export_sha256=live,frontend=front,upstream_sync=sync,full_wasm=dict(modules=78,mutants=342,contracts=6978,suites=52,passed=True,browser_budget_exceeded=False,initial_budget_exceeded=budgetq['initial_budget_exceeded'],idle_requalified_cases=2),release_policy=policy,idle_budget_qualification=budgetq,performance_identity=perf,performance=read('performance-summary.json'),memory=memory,source_footprint=footprint,limitations=['Five finite wide half spans use widened opmath and rational oracle; not native 2.14.1 numerical passes.','109 undefined floating-to-integer overflow cases excluded from portable numeric claims.','Tensor endpoint linspace/logspace forward AD unsupported; arange ordinary Tensor controls requiring gradients rejected.','Existing dense CPU/WASM, half NN/AD and 0.53 mixed float32 limits retained. No GPU claim.'],raw_archive=dict(name=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)))
save(out/'iteration-56.json',report);save(r/'state.json',dict(status='local_gates_passed',version='0.56.0',main_adoption_pending=True,source_hashes=source,active_export_sha256=live))
print(json.dumps(dict(status=report['status'],cpu=cpu['passed'],wasm=6978,wheel=6991,catalog=78,mutants=342,raw_archive=report['raw_archive'])))
