from pathlib import Path
import json,statistics
r=Path(__file__).resolve().parent;summary={}
for runtime in ['cpu','node','chrome']:
 processes=[]
 for repeat in range(4):
  j=json.loads((r/f'performance/{runtime}-{repeat}.json').read_text());processes.append(j.get('benchmark',j))
 result=[]
 for index,row in enumerate(processes[0]['rows']):
  rows=[p['rows'][index] for p in processes];assert all((v['factory'],v['dtype'],v['size'])==(row['factory'],row['dtype'],row['size']) for v in rows)
  values={k:[v['median_s'][k] for v in rows] for k in row['median_s']};ratios=[v['candidate_over_baseline'] for v in rows if v['candidate_over_baseline'] is not None]
  result.append(dict(factory=row['factory'],dtype=row['dtype'],size=row['size'],median_us={k:statistics.median(v)*1e6 for k,v in values.items()},candidate_over_baseline=statistics.median(ratios) if ratios else None,ratio_range=[min(ratios),max(ratios)] if ratios else None))
 summary[runtime]=result
summary['method']='Four fresh processes per runtime, five samples per case, alternating baseline/candidate order; shared batch counts calibrated outside timing to >=20 ms per variant; median of process medians and full process-ratio range. 23 matched valid arange/linspace rows plus 6 candidate-only logspace rows per process. Known incorrect baseline outputs excluded from speed claims. Construction/destruction included, warmup/correctness/GC outside timing. Same-host measurements, not native Torch or GPU throughput, cold-load, universal speedup or RSS.'
(r/'performance-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({runtime:[{k:(round(v,3) if isinstance(v,float) else v) for k,v in row.items() if k in ['factory','size','candidate_over_baseline','median_us']} for row in summary[runtime] if row['dtype']=='float32'] for runtime in ['cpu','node','chrome']}))
