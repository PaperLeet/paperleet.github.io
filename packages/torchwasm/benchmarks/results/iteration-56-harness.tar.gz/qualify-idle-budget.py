from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent;i=r/'integration-proof';full=json.loads((i/'full-wasm-contended-result.json').read_text());expected=set(full['browser_budget_exceeded']);assert expected=={'diffusion/ddpm_sampling','diffusion/flow_matching'}
assert full['passed'] and full['modules']==78 and all(v['passed'] for v in full['results'])
receipts=json.loads((i/'idle-budget-cli-receipts.json').read_text());cases=[]
for name,id in [('ddpm-sampling','diffusion/ddpm_sampling'),('flow-matching','diffusion/flow_matching')]:
 path=i/(name+'-idle.json');actual=json.loads(path.read_text());prior=next(v for v in full['results'] if v['id']==id)
 assert receipts[id]['exit_code']==0 and receipts[id]['all_children_terminal']
 for k in ['id','pyodide','numpy','backend','tests','mutants','packages','bundle_url','runtime_bundle_url','source_sha256','budgets']:assert actual[k]==prior[k],(id,k)
 assert not actual['browser_budget_exceeded']
 for label,key in [('calibration','calibration_ms'),('run','learner_ms'),('total','elapsed_ms')]:assert actual[key]<=actual['budgets'][label],(id,label)
 cases.append(dict(id=id,exit_code=0,initial_elapsed_ms=prior['elapsed_ms'],initial_calibration_ms=prior['calibration_ms'],idle_elapsed_ms=actual['elapsed_ms'],idle_calibration_ms=actual['calibration_ms'],idle_learner_ms=actual['learner_ms'],budgets=actual['budgets'],artifact=path.name,artifact_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),input_identity_unchanged=True))
assert {v['id'] for v in full['results'] if v['browser_budget_exceeded']}==expected
report=dict(status='qualified',original_catalog_sha256=hashlib.sha256((i/'full-wasm-contended-result.json').read_bytes()).hexdigest(),full_catalog_compatibility_passed=78,initial_budget_exceeded=sorted(expected),idle_requalified_cases=cases,scope='Original full catalog passed compatibility, with two budget flags while CPU/wheel gates overlapped. Exactly those two cases were rerun sequentially after all heavy gates and benchmarks were terminal. CLI success exit codes establish individual correctness; input and budget fields are identical. Original full-run timings and flags are preserved; this is not a claim that the initial full run had no budget flags.')
(i/'idle-budget-qualification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status='qualified',cases=cases)))
