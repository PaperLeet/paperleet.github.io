from pathlib import Path
import json,subprocess,time
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';i=r/'integration-proof';args=[str(py),str(i/'run-frontend.py')];start=time.monotonic()
with (i/'frontend-after-f180.log').open('w') as log:p=subprocess.run(args,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
rows=json.loads((i/'receipts.json').read_text());rows=[v for v in rows if v['label']!='frontend'];rows.append(dict(label='frontend',args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-start,upstream='f180057b1fefcb5e5bec37bd2b0f8f63ba25fb8b'))
(i/'receipts.json').write_text(json.dumps(rows,indent=2)+'\n');p.check_returncode();print('frontend-after-f180 TERMINAL 0',flush=True)
