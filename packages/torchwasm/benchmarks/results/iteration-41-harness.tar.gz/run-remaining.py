from pathlib import Path
import hashlib,json,os,subprocess,time

r=Path(__file__).resolve().parent;i=r/'integration-proof'
py=r.parent/'torch-iteration-21/stride-dev-env/bin/python'
repo=Path('/Users/david/Developer/PaperLeet-torch-release')
env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
receipts=[];start=time.monotonic()
def run(name,args,cwd=r):
    begin=time.monotonic()
    with (r/(name+'.log')).open('w') as log:
        result=subprocess.run([str(x) for x in args],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
    receipts.append(dict(name=name,exit_code=result.returncode,elapsed_s=time.monotonic()-begin,args=[str(x) for x in args],cwd=str(cwd)))
    (r/'remaining-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
    print('TERMINAL',name,result.returncode,round(time.monotonic()-begin,2),flush=True)
    result.check_returncode()
while not (r/'full-root-receipt.json').exists():
    if time.monotonic()-start>1200:raise RuntimeError('Full-root receipt not available after 20 minutes; inspect original handle')
    time.sleep(5)
full=json.loads((r/'full-root-receipt.json').read_text())
assert full['exit_code']==0 and full['passed']==35782 and full['skipped']==1,full
gates=json.loads((r/'proof/gate-receipts.json').read_text());assert len(gates)==6 and all(v['exit_code']==0 for v in gates.values())
run('frontend-final',[py,i/'run-frontend.py'],repo)
setup=json.loads((i/'setup-receipts.json').read_text());assert len(setup)==3 and all(v['exit_code']==0 for v in setup)
setup.append(dict(script='run-frontend.py',exit_code=0,elapsed_s=receipts[-1]['elapsed_s'],environment={'PYTHON':str(py)}))
(i/'setup-receipts.json').write_text(json.dumps(setup,indent=2)+'\n')
run('native-original',[py,i/'run-native.py'],repo)
out=r/'pooling-performance';out.mkdir()
for repeat in range(4):
    for runtime in (('cpu','node','chrome') if repeat%2==0 else ('chrome','node','cpu')):
        name=f'{runtime}-{repeat}';result=out/(name+'.json')
        if runtime=='cpu':args=[py,r/'bench_average_pooling_1d.py','--baseline-source',r/'baseline-source/stridetorch','--candidate-source',r/'proof/source','--samples','7','--iterations','40','--output',result]
        else:args=['/opt/homebrew/bin/node',r/('bench-wasm.mjs' if runtime=='node' else 'bench-chrome.mjs'),result]
        if repeat%2:args+=['--reverse']
        run('pooling-'+name,args)
        report=json.loads(result.read_text());assert report['status']=='success' and len(report['results'])==34
        assert report['source_hashes']['candidate']==json.loads((r/'proof/source-hashes.json').read_text())
        assert report['source_hashes']['baseline']==json.loads((r/'baseline.json').read_text())['source']
run('legacy-performance',[py,r/'run-performance-final.py'])
run('imports',[py,r/'run-imports.py'])
run('exported-wasm-all',[py,i/'run-wasm.py'],repo)
print('All sequential validation and performance children terminal0',flush=True)
