from pathlib import Path
import gzip,hashlib,json,os,shutil,statistics,tarfile

r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
out=repo/'packages/stridetorch/benchmarks/results'
def read(name):return json.loads((r/name).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(name,value):(out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
actual={p.name:sha(p) for p in (repo/'packages/stridetorch/src/stridetorch').iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
tests={p.name:sha(p) for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'}
plan=read('proof/chrome-contracts/plan.json')
assert len(actual)==49 and actual==read('proof/source-hashes.json')==plan['source']
assert len(tests)==40 and tests==plan['tests'] and plan['expected']==2858
full=read('full-root-receipt.json');assert full['exit_code']==0 and full['passed']==35782 and full['skipped']==1
assert '2615 passed' in (r/'focus-final.log').read_text()
gates=read('proof/gate-receipts.json');assert len(gates)==6 and all(v['exit_code']==0 for v in gates.values())
node=read('proof/source-wasm.json');chrome=read('proof/chrome-contracts/result.json')
wheel=read('proof/wheel-stride041-result.json');coinstall=read('proof/coinstall-result.json')
assert node['passed']==chrome['passed']==2858 and chrome['test_hashes']==tests
assert node['source_hashes']==chrome['source_hashes']==wheel['source_hashes']==coinstall['source_hashes']==actual
assert all(v['status']=='success' for v in (chrome,wheel,coinstall)) and not wheel['native_torch']
assert '2871 passed' in (r/'proof/python310-stride041-tests.log').read_text()
assert node['numpy']=='2.2.5' and node['library']=='0.41.0'
sequential=read('remaining-receipts.json');assert len(sequential)==17 and all(v['exit_code']==0 for v in sequential)
performance={}
for runtime in ('cpu','node','chrome'):
    rows=[read(f'pooling-performance/{runtime}-{repeat}.json') for repeat in range(4)]
    for row in rows:
        assert row['status']=='success' and len(row['results'])==34
        assert row['source_hashes']['candidate']==actual and row['source_hashes']['baseline']==read('baseline.json')['source']
    results=[]
    for position,case in enumerate(rows[0]['results']):
        samples=[row['results'][position]['timings'] for row in rows]
        medians={name:[sample[name]['median_us'] for sample in samples] for name in samples[0]}
        reductions=[100*(1-a/b) for a,b in zip(medians['candidate_direct'],medians['baseline_composition'])]
        within=[100*(1-a/b) for a,b in zip(medians['candidate_direct'],medians['candidate_composition'])]
        drift=[100*(a/b-1) for a,b in zip(medians['candidate_composition'],medians['baseline_composition'])]
        results.append(dict(dtype=case['dtype'],kind=case['kind'],mode=case['mode'],
                            median_us=medians,direct_vs_baseline_reductions_percent=reductions,
                            median_reduction_percent=statistics.median(reductions),
                            direct_vs_same_source_reductions_percent=within,composition_control_drift_percent=drift))
    performance[runtime]=dict(fresh_processes=4,results=results)
regression=read('performance-final-summary.json');imports=read('import-summary.json')
assert len(regression['receipts'])==8 and all(v['exit_code']==0 for v in regression['receipts'].values())
assert len(imports['receipts'])==16 and all(v['exit_code']==0 for v in imports['receipts'])
for path in (r/'performance-final').glob('*.json'):
    if path.name=='receipts.json':continue
    row=json.loads(path.read_text());assert row['source_hashes']['candidate']==actual and len(row['results'])==21
native=read('integration-proof/native-ci.json');wasm=read('integration-proof/full-wasm-result.json')
assert native['passed'] and native['problems']==78 and native['tests_executed']==10218 and native['duration_s']<=600 and native['repeats']==3 and not native['issues']
assert sum(map(len,native['mutation'].values()))==342 and all(hits for rows in native['mutation'].values() for hits in rows.values())
assert wasm['passed'] and wasm['catalog_modules']==wasm['modules']==78 and not wasm['browser_budget_exceeded']
assert sum(v['mutants'] for v in wasm['results'])==342 and all(v['passed'] and not v['browser_budget_exceeded'] for v in wasm['results'])
contracts=next(v for v in wasm['results'] if v['id']=='architecture/attention')['independent_contracts']
assert contracts['passed']==2858 and len(contracts['suites'])==40
assert {v['suite']:v['source_sha256'] for v in contracts['suites']}==tests
assert contracts['runtime_profiles'][0]['supplemented_files']==[]
assert contracts['runtime_profiles'][1]['supplemented_files']==[dict(name='stridetorch/_legacy.py',source_sha256=actual['_legacy.py'])]
setup=read('integration-proof/setup-receipts.json');front=read('integration-proof/frontend-receipts.json')
assert len(setup)==4 and len(front)==5 and all(v['exit_code']==0 for v in setup+front)
exports=read('integration-proof/export-identity.json');snapshot=read('integration-proof/release-snapshot.json')
assert exports['published_assets_unchanged']==9439 and exports['active_assets']==exports['new_assets']==158 and exports['all_new_assets_reachable']
assert snapshot['source_hashes']==actual and read('integration-proof/distribution-identity.json')['status']=='success'
live=read('integration-proof/live-expected-sha256.json');assert len(live)==161
for name,digest in live.items():assert sha(repo/'web/public/data'/name)==digest
harness=read('integration-proof/wasm-harness-identity.json')
assert sha(repo/harness['file'])==harness['sha256'] and sha(repo/harness['driver_file'])==harness['driver_sha256']
assert read('existing-source-audit.json')['source_hashes']==actual
assert read('canonical-policy-identity.json')['status']=='success'
for name,digest in read('canonical-policy-identity.json')['hashes'].items():assert sha(repo/name)==digest
native_dir=r/'native-contracts';native_dir.mkdir(exist_ok=True)
for path in (repo/'tests').glob('test_torch_*'):shutil.copy2(path,native_dir/path.name)
metadata=r/'package-metadata';metadata.mkdir(exist_ok=True)
for name in ('README.md','pyproject.toml','LICENSE','NOTICE'):shutil.copy2(repo/'packages/stridetorch'/name,metadata/name)
shutil.copy2(repo/'packages/stridetorch/tests/test_standalone.py',metadata/'test_standalone.py')
def archive(name,root,excluded):
    files=[]
    for folder,dirs,names in os.walk(root):
        dirs[:]=[d for d in dirs if not d.endswith(('-env','-venv')) and d not in excluded and d not in ('__pycache__','.pytest_cache')]
        for filename in names:
            path=Path(folder)/filename
            if not path.is_symlink() and (path.name in ('LICENSE','NOTICE') or path.suffix in ('.py','.mjs','.cjs','.json','.log','.txt','.md','.html','.toml','.diff')):files.append(path)
    target=out/name
    with tarfile.open(target,'w:gz') as tar:
        for path in sorted(files):tar.add(path,arcname=str(path.relative_to(root)),recursive=False)
    return dict(file=target.name,files=len(files),bytes=target.stat().st_size,sha256=sha(target))
core_archive=archive('iteration-41-harness.tar.gz',r,{'dist-preflight','private-dist','dist-paperleet','integration-proof','main-sync-proof'})
footprint={}
for name,folder in [('baseline',r/'baseline-source/stridetorch'),('candidate',r/'proof/source')]:
    raw=b''.join(p.read_bytes() for p in sorted(folder.iterdir()) if p.suffix=='.py' or p.name in ('LICENSE','NOTICE'))
    footprint[name]=dict(raw_bytes=len(raw),local_gzip_estimate_bytes=len(gzip.compress(raw,mtime=0)))
save('iteration-41.json',dict(status='complete_local_validation_main_adoption_pending',version='0.41.0',baseline_main=read('baseline.json')['head'],source_hashes=actual,standalone_test_hashes=tests,
    full_cpu=full,focused_passed=2615,minimal_passed=2871,minimal_wheel=wheel,node_wasm=node,actual_chrome_worker=chrome,coinstall=coinstall,gate_receipts=gates,
    source_audit=read('existing-source-audit.json'),native_seeded_random_trials=240,native_seeded_random_output_comparisons=1200,
    pooling_workflows=performance,source_footprint=footprint,existing_workflows=regression,cold_namespace_imports=imports,archive=core_archive,
    retained_findings=['A first 35710-pass candidate still had empty-output stride mismatches: twelve explicit native probes exposed them. Added sixty standalone/WASM route checks and twelve native checks, refreshed all source-bound gates, artifacts and exports. First candidate evidence retained separately.',
       'Initial concurrent frontend check timed out in the maintained five-second Python syntax subprocess. Focused owned-Python rerun passed; final full frontend and both builds run sequentially with explicit owned PYTHON. Original terminal failure retained; timeout policy and maintained frontend scripts unchanged.',
       'Four fresh processes per CPU/Node/Chrome runtime, seven samples per flow; alternate order. The supported 0.40 baseline is the 2D composition. Same-candidate composition is retained as a control. Shared-host variance and per-case regressions remain visible; no uniform speedup, native Torch or GPU claim.'],
    scope='CL/NCL fixed/adaptive average pooling, direct one-node reverse and linear JVP tapes, common ordered kernels, module/root/functional aliases, dtype and empty-shape rules, native constructor normalization, serialization and Conv1d-pools-linear-SGD checkpoint continuation. CPU/NumPy and Pyodide WASM; no GPU backend.',
    release_policy='No GitHub CI,tag,dispatch,package upload or online publication;user will explicitly release later.'))
app_archive=archive('iteration-41-integration-harness.tar.gz',r/'integration-proof',{'dist-paperleet'})
save('iteration-41-integration.json',dict(status='complete_local_application_validation_main_adoption_pending',version='0.41.0',upstream=read('baseline.json')['head'],source_hashes=actual,
    native=native,exported_wasm=wasm,setup_receipts=setup,frontend_receipts=front,release_snapshot=snapshot,export_integrity=exports,distribution_identity=read('integration-proof/distribution-identity.json'),
    runtime_sizes=read('integration-proof/runtime-sizes.json'),wasm_harness=harness,archive=app_archive,publication='Local verification; no online deployment or remote Actions run.'))
print(json.dumps(dict(status='local_closed',native_s=native['duration_s'],wasm_ms=wasm['elapsed_ms'],core_archive=core_archive,integration_archive=app_archive)))
