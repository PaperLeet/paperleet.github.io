"""Archive verified 0.80 evidence without environments or test temporaries."""
from pathlib import Path
import gzip, hashlib, io, json, os, subprocess, tarfile, time

r=Path(__file__).resolve().parent
b=r.parent
repo=Path('/Users/david/Developer/PaperLeet-torch-release')
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
encode=lambda value:(json.dumps(value,indent=2)+'\n').encode()
write=lambda p,value:p.write_bytes(encode(value))
plan=read(r/'execution-plan.json')
assert sha(Path(__file__))==plan['archiver_sha256']
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head==plan['head']

core=read(b/'torch-iteration-328/result.json')
assert sha(repo/core['archive'])==core['archive_sha256']
required={}
for relative,expected_status in plan['required_results'].items():
    source=b/relative
    value=read(source)
    assert value.get('status')==expected_status,(relative,value.get('status'))
    required[relative]=sha(source)
application=read(b/'torch-iteration-332/result.json')
assert application['head']==head and application['source']==284 and application['resources']==65
assert all(row['exit_code']==0 for row in application['receipts'])
expected=read(b/'torch-iteration-299/expected.json')
folder=repo/'packages/stridetorch/src/stridetorch'
assert {p.name:sha(p) for p in folder.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']}==expected

skip={'minimum-env','native-env','application-env','.venv','pytest-tmp','__pycache__','node_modules','installed','build'}
suffixes={'.json','.py','.mjs','.tsx','.md','.xml','.log','.patch','.toml','.txt','.npz','.npy','.js','.ts','.cjs','.html','.yaml','.yml','.whl','.gz'}
files={}
for number in plan['iterations']:
    parent=b/f'torch-iteration-{number}'
    assert parent.is_dir(),parent
    for directory,dirs,names in os.walk(parent,followlinks=False):
        dirs[:]=[name for name in dirs if name not in skip and not name.endswith(('.egg-info','.dist-info'))
                 and not (Path(directory)/name).is_symlink()]
        for name in names:
            source=Path(directory)/name
            if source.is_symlink() or not source.is_file():continue
            if source.suffix not in suffixes and name not in ['LICENSE','NOTICE']:continue
            # Push outputs and the evolving handoff are not immutable qualification inputs.
            if number==314 and (name.startswith(('latest-main-audit','adoption-push','proof-push','qualification-grant'))
                                or name in ['continuation-state.json','working-review-inventory.json']):continue
            files[str(source.relative_to(b))]=source
for name in expected:files['current-runtime/stridetorch/'+name]=folder/name
for name,source in {
    'current-benchmarks/core_workloads.py':repo/'packages/stridetorch/benchmarks/core_workloads.py',
    'current-benchmarks/webgpu_rpc/torch_workload.py':repo/'packages/stridetorch/benchmarks/webgpu_rpc/torch_workload.py',
    'archive/archive.py':Path(__file__),
    'archive/execution-plan.json':r/'execution-plan.json',
}.items():files[name]=source

entries={name:dict(sha256=sha(source),bytes=source.stat().st_size) for name,source in sorted(files.items())}
manifest=dict(version='0.80.0',source=284,head=head,runtime_resources=expected,
              required_results=required,entries=entries,
              exclusions=sorted(skip)+['*.egg-info','*.dist-info','installed dependency/runtime environments'],
              scope='Frozen candidate code, harnesses, raw results, failed attempts and exact current runtime. '
                    'Dependencies are identified by the included plans; environments and temporary pytest trees are excluded. '
                    'Absolute paths in original harnesses require configuration when replayed elsewhere. '
                    'The retained raw WASM/native norm-HVP point failure is not converted to a pass.',
              main_adopted=False,ci_triggered=False,published=False,goal_status='active')
write(r/'manifest.json',manifest)
output=repo/'packages/stridetorch/benchmarks/results/qualification-0.80-followups-harness.tar.gz'
assert not output.exists(),output
write(r/'progress.json',dict(status='archiving',pid=os.getpid(),files=len(entries),observed_unix=time.time()))
with output.open('wb') as raw,gzip.GzipFile(fileobj=raw,filename='',mtime=0,compresslevel=6) as compressed:
    with tarfile.open(fileobj=compressed,mode='w|') as archive:
        body=encode(manifest)
        info=tarfile.TarInfo('MANIFEST.json');info.size=len(body);info.mode=0o644
        archive.addfile(info,io.BytesIO(body))
        for name,source in sorted(files.items()):
            assert sha(source)==entries[name]['sha256'],name
            info=tarfile.TarInfo(name);info.size=entries[name]['bytes'];info.mode=0o644
            with source.open('rb') as stream:archive.addfile(info,stream)
            assert sha(source)==entries[name]['sha256'],name

observed={}
with tarfile.open(output,'r|gz') as archive:
    for member in archive:
        assert member.isfile()
        stream=archive.extractfile(member)
        if member.name=='MANIFEST.json':assert json.load(stream)==manifest;continue
        assert member.name in entries and member.name not in observed,member.name
        digest=hashlib.file_digest(stream,'sha256').hexdigest()
        assert digest==entries[member.name]['sha256'] and member.size==entries[member.name]['bytes'],member.name
        observed[member.name]=digest
assert set(observed)==set(entries)
for relative,digest in required.items():assert sha(b/relative)==digest
result=dict(status='verified_candidate080_followups_evidence_archive',head=head,version='0.80.0',source=284,
            archive=str(output.relative_to(repo)),archive_sha256=sha(output),archive_bytes=output.stat().st_size,
            files=len(entries),manifest_sha256=sha(r/'manifest.json'),all_member_hashes_verified=True,
            runtime_resources=65,main_adopted=False,ci_triggered=False,published=False,goal_status='active')
write(r/'result.json',result);write(r/'progress.json',dict(status='completed',result=result))
print(json.dumps(result),flush=True)
