from pathlib import Path
import hashlib,io,json,shutil,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
assert not (r/'webgpu-package-harness.tar.gz').exists()
audit=read(b/'torch-iteration-599/result.json');assert audit['status']=='passed_final_packaged_webgpu_audit'
packages=read(b/'torch-iteration-595/result.json');assert len(packages['artifacts'])==6
sdk=read(b/'torch-iteration-596/result.json');assert sdk['status']=='passed_installed_final_full_sdk'
for value in sdk['receipts']:assert value['exit_code']==0 and value['totals']['tests']==12322 and value['totals']['failures']==value['totals']['errors']==0
plan=read(b/'torch-iteration-595/source-plan.json')
for n,h in plan['inputs'].items():assert sha(Path(n))==h,n
for n,h in plan['staged'].items():assert sha(b/'torch-iteration-595'/n)==h,n
performance=read(b/'torch-iteration-592/result.json');assert performance['all_overhead_gates_passed'] and audit['resident_hotpath_matches_measured_binding']
portable={}
for name,cases in [('negotiation',39),('program',63),('protocol',9),('primitive',39),('cancel-drain',4)]:
 value=json.loads((b/'torch-iteration-586'/(name+'.log')).read_text().splitlines()[-1]);assert value['status']=='passed' and value['cases']==cases;portable[name]=dict(cases=cases,log_sha256=sha(b/'torch-iteration-586'/(name+'.log')))
for name in ['gpu-service.mjs','rpc-client.mjs','rpc-protocol.mjs','plan-program.mjs']:
 assert sha(repo/'packages/stridetorch/src/stridetorch/experimental/webgpu'/name)==sha(b/'torch-iteration-586/public/src/stridetorch/experimental/webgpu'/name),name
summary=dict(status='qualified_installed_experimental_webgpu_package',version='0.83.0',version_scope='Unpublished development distribution; CPU root66 and default autograd62 remain byte-identical',public_namespace='stridetorch.experimental.webgpu',public_package_files=77,core_root_resources_unchanged=66,default_autograd_embed_unchanged=62,schedules_embed_unchanged=6,public_sdist_sdk_files=94,public_private_artifacts=packages['artifacts'],targeted_native=audit['native'],full_installed_sdk=sdk,portable_checks=portable,actual_gpu=audit['gpu'],resident_performance=performance,hotpath_identity_audit=audit,package_inputs={n:h for n,h in plan['inputs'].items() if n in read(b/'torch-iteration-515/source-plan.json')['inputs'] or '/packages/stridetorch/src/stridetorch/experimental/' in n or n.endswith('/packages/stridetorch/tests/test_webgpu_package.py')},all_qualification_inputs=len(plan['inputs']),active_export_identities_unchanged=183,borrowed_client_pinned=True,default_gpu_dispatch_enabled=False,public_gpu_tensor_storage=False,stable_gpu_api=False,ci_triggered=False,tags_pushed=False,published=False,deployed=False,goal_status='active')
assert len(summary['package_inputs'])==218
write(r/'result.json',summary)
write(r/'replay-dependencies.json',dict(entrypoints=['595/run.py builds six artifacts and installed smoke','596/run.py runs both full installed SDK suites','597/tree/tests holds the original12 ROOT-relative packaging checks','598/run-browser.mjs installs the final wheel in Pyodide and runs four hosts','591/run-all.py is the full six-process resident timing campaign','592/analyze.py and599/audit.py establish thresholds and final hotpath identity'],external=['Pyodide0.29.4/NumPy2.2.5 runtime assets from76, not included','Node22, Chrome155/Apple metal-3 and Playwright','Py3.12/NumPy2.5.4/Torch2.14.1 and Py3.10/NumPy1.26.4/Torch2.6','Historical absolute paths/HEAD guards require adaptation in fresh replay copies'],preserved=['588 retains full SDK passes and9 missing ROOT-layout fixture errors;590 fixes only the snapshot layout and final597 reruns12 cases','594 reproduces cross-client retargeting on the initial candidate;595/596/598 qualify fixed constructor/first-submission client binding','One individual performance A/A flag remains; no favorable process reruns','591 measures client-bound resident paths.599 proves the final non-constructor resident path identical to its bound method; no stateless latency claim'],omitted=['Generated test/build temporary trees are retained externally but not duplicated here; relevant wheel artifacts, exact frozen inputs, logs, XML and manifests are included','No default runtime/worker export mutation, CI, tag, publication or deployment']))
files=[r/'aggregate.py',r/'result.json',r/'replay-dependencies.json']
def include(path,folder):
 relative=path.relative_to(folder)
 return not any(part in ('__pycache__','.pytest_cache','build','root-tmp') or part.endswith(('-tmp','.egg-info')) for part in relative.parts)
for stage in range(585,600):
 folder=b/f'torch-iteration-{stage}'
 files.extend(path for path in folder.rglob('*') if path.is_file() and include(path,folder))
for item in audit['root_wheels']:files.append(b/item['path'])
files=sorted(set(files));manifest={str(p.relative_to(b)):sha(p) for p in files};seen={};target=r/'webgpu-package-harness.tar.gz'
with tarfile.open(target,'w:gz') as stream:
 for p in files:
  n=str(p.relative_to(b));h=manifest[n]
  if h in seen:
   item=stream.gettarinfo(str(p),arcname=n);item.type=tarfile.LNKTYPE;item.linkname=seen[h];item.size=0;stream.addfile(item)
  else:stream.add(p,arcname=n,recursive=False);seen[h]=n
 data=(json.dumps(manifest,indent=2)+'\n').encode();item=tarfile.TarInfo('sha256.json');item.size=len(data);stream.addfile(item,io.BytesIO(data))
with tarfile.open(target) as stream:
 for n,h in manifest.items():assert hashlib.sha256(stream.extractfile(n).read()).hexdigest()==h,n
receipt=dict(path='packages/stridetorch/benchmarks/results/'+target.name,sha256=sha(target),files=len(files),unique_payloads=len(seen),bytes=target.stat().st_size,all_payloads_verified=True);write(r/'archive-receipt.json',receipt);summary['raw_archive']=receipt
write(repo/'packages/stridetorch/benchmarks/results/webgpu-package.json',summary);shutil.copy2(target,repo/receipt['path']);print(json.dumps(receipt))
