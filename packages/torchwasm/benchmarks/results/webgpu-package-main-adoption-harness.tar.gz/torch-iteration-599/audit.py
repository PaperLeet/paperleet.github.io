from pathlib import Path
import ast,hashlib,json,zipfile,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
assert not (r/'result.json').exists()
before=b/'torch-iteration-587/public/src/stridetorch/experimental/webgpu';after=b/'torch-iteration-595/public/src/stridetorch/experimental/webgpu'
def functions(source):
 result={}
 def visit(body,prefix=''):
  for node in body:
   if isinstance(node,ast.ClassDef):visit(node.body,prefix+node.name+'.')
   if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):result[prefix+node.name]=ast.dump(node,include_attributes=False)
 visit(ast.parse(source).body);return result
changes={}
for name,excluded in [('torch_bridge.py',{'MatmulOffload.__init__','MatmulOffload._rpc_submit'}),('resident_bridge.py',{'_RpcBackend.__init__','ResidentMatmulOffload.__init__'})]:
 previous=(before/name).read_text();current=(after/name).read_text()
 if name=='resident_bridge.py':previous=previous.replace('program = MatrixProgram()','program = MatrixProgram(client=self.client)')
 a,c=functions(previous),functions(current);assert set(a)==set(c)
 assert all(a[key]==c[key] for key in a if key not in excluded),name
 changes[name]=sorted(key for key in a if a[key]!=c[key])
for name in ['matrix_client.py','_pyodide.py','resources.py']:assert sha(before/name)==sha(after/name),name
for name in ['gpu-service.mjs','plan-program.mjs','rpc-client.mjs','rpc-protocol.mjs']:
 assert sha(after/name)==sha(b/'torch-iteration-585/baseline/packages/stridetorch/benchmarks/webgpu_rpc'/name),name
for n,h in read(b/'torch-iteration-595/source-plan.json')['inputs'].items():assert sha(Path(n))==h,n
for n,h in read(b/'torch-iteration-511/source-hashes.json').items():assert sha(repo/'packages/stridetorch/src/stridetorch'/n)==h,n
for n,h in read(b/'torch-iteration-511/live-export-sha256.json').items():assert sha(repo/'web/public/data'/n)==h,n
gpu=read(b/'torch-iteration-598/browser-result-0.json');assert gpu['status']=='passed' and gpu['numerical']['cases']==51 and len(gpu['numerical']['controls'])==31 and gpu['numerical']['compatibility']['cases']==7
assert gpu['numerical']['installed_package']['files']==77 and all(v['stats']['closed'] and v['stats']['total_bytes']==v['stats']['resident_handles']==v['stats']['allocations']==0 for v in gpu['host_disposals'])
assert read(b/'torch-iteration-596/result.json')['status']=='passed_installed_final_full_sdk'
native={}
for label,path in [('numpy25',b/'torch-iteration-595/native25.xml'),('numpy126',b/'torch-iteration-595/native126.xml'),('root_packages',b/'torch-iteration-597/root-tests.xml')]:
 suites=list(ET.parse(path).getroot().iter('testsuite'));native[label]={k:sum(int(v.attrib.get(k,0)) for v in suites) for k in ['tests','failures','errors','skipped']}
 assert native[label]==dict(tests=12 if label=='root_packages' else 150,failures=0,errors=0,skipped=0)
root_wheels=[]
for distribution,prefix,expected in [('paperleet','paperleet/_vendor/torch/',read(b/'torch-iteration-511/source-hashes.json')),('stridetorch','stridetorch/',read(b/'torch-iteration-595/source-plan.json')['expected_public'])]:
 wheel=next((b/'torch-iteration-597/root-tmp/runtime-wheels0/wheels').glob(distribution+'-*.whl'))
 with zipfile.ZipFile(wheel) as archive:actual={name[len(prefix):]:hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist() if name.startswith(prefix)}
 assert actual==expected,distribution;root_wheels.append(dict(path=str(wheel.relative_to(b)),sha256=sha(wheel),package_files=len(actual)))
performance=read(b/'torch-iteration-592/result.json');assert performance['all_preplanned_controls_passed'] and performance['all_overhead_gates_passed']
write(r/'result.json',dict(status='passed_final_packaged_webgpu_audit',native=native,root_wheels=root_wheels,public_package_files=77,private_core_files=66,default_exports_unchanged=183,js_shader_planner_protocol_unchanged=True,full_sdk=read(b/'torch-iteration-596/result.json'),gpu=dict(browser=gpu['browser'],gpu_info=gpu['gpu_info'],worker=gpu['worker'],cases=51,state_controls=31,compatibility=gpu['numerical']['compatibility'],installed_package=gpu['numerical']['installed_package'],host_disposals=gpu['host_disposals']),resident_hotpath_matches_measured_binding=True,performance_source='torch-iteration-591',source_identity_changes=changes,unmeasured_stateless_scope='Client selection now pins at first submission; numerical/VJP tests pass, no stateless latency claim',global_rebinding_negative_control='594 fails on initial586 candidate, final595 SDK and598 real browser pass',earlier588_fixture_failure_preserved=True,ci_triggered=False,goal_status='active'))
print(json.dumps(dict(status='passed_final_packaged_webgpu_audit',public_files=77,root_cases=12,targeted_each=150,gpu_cases=51,gpu_controls=31,compatibility_cases=7)))
