"""Rebuild current public/private package snapshots without publishing."""
from pathlib import Path
import hashlib, json, os, subprocess, tarfile, time, traceback, zipfile

r = Path(__file__).resolve().parent
b = r.parent
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
python = b / 'torch-iteration-82/application-env/bin/python'
uv = Path('/Users/david/.local/bin/uv')
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, value: p.write_text(json.dumps(value, indent=2) + '\n')
plan = read(r / 'source-plan.json')
expected = plan['expected']
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='2',
           MKL_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', VECLIB_MAXIMUM_THREADS='2')
env.pop('PYTHONPATH', None)
receipts = []

def verify():
    execution = read(r / 'execution-plan.json')
    assert sha(Path(__file__)) == execution['runner_sha256']
    assert sha(r / 'source-plan.json') == execution['source_plan_sha256']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == plan['head']
    for name, digest in plan['inputs'].items():
        assert sha(Path(name)) == digest, name
    for name, digest in plan['staged'].items():
        assert sha(r / name) == digest, name

def run(label, command, cwd=r):
    verify()
    log = r / (label + '.log')
    with log.open('w') as stream:
        child = subprocess.Popen(list(map(str, command)), cwd=cwd, env=env,
                                 stdout=stream, stderr=subprocess.STDOUT)
        write(r / 'progress.json', dict(status='running', label=label, pid=child.pid,
              supervisor_pid=os.getpid(), observed_unix=time.time(), receipts=receipts))
        code = child.wait()
    receipt = dict(label=label, command=list(map(str, command)), cwd=str(cwd),
                   exit_code=code, log_sha256=sha(log))
    receipts.append(receipt)
    write(r / 'receipts.json', receipts)
    print(json.dumps(dict(label=label, exit_code=code)), flush=True)
    assert code == 0, (label, log.read_text()[-3000:])
    verify()

def build(label, source, output, sdist=True):
    output.mkdir()
    script = 'from setuptools import build_meta;import sys;target=sys.argv[1];'
    if sdist:
        script += 'build_meta.build_sdist(target);'
    script += 'build_meta.build_wheel(target)'
    run(label, [python, '-B', '-c', script, output], source)
    return next(output.glob('*.whl'))

def inspect(wheel, prefix):
    with zipfile.ZipFile(wheel) as archive:
        files = archive.namelist()
        actual = {name[len(prefix):]: hashlib.sha256(archive.read(name)).hexdigest()
                  for name in files if name.startswith(prefix)}
        assert actual == (plan['expected_public'] if prefix=='stridetorch/' else expected), wheel
        if prefix == 'stridetorch/':
            assert not any(name.startswith(('torch/', 'paperleet/')) for name in files)
            metadata = archive.read('stridetorch-0.83.0.dist-info/METADATA').decode()
            assert 'License-Expression: Apache-2.0' in metadata
            assert metadata.split('\n\n',1)[1].rstrip('\n') == (r/'public/README.md').read_text().rstrip('\n')
            assert [line for line in metadata.splitlines() if line.startswith('Requires-Dist:')] == ['Requires-Dist: numpy>=1.26']
            assert archive.read('stridetorch-0.83.0.dist-info/entry_points.txt').decode().find('stridetorch = stridetorch._cli:main') >= 0
        else:
            for name in plan['private_source_files']:
                if name.startswith('paperleet/') and (name.endswith('.py') or name.endswith(('interview_catalog.json','daily_challenges.json'))):
                    assert hashlib.sha256(archive.read(name)).hexdigest() == plan['inputs'][str(repo / name)], name
    return dict(path=str(wheel.relative_to(r)), sha256=sha(wheel), runtime_resources=len(actual))

try:
    assert read(b/'torch-iteration-501/result.json')['status']=='passed_full_application_cpu'
    assert read(b/'torch-iteration-494/result.json')['status']=='qualified_preplanned_owned_flow_latency_and_allocation_gates'
    public = build('build-public', r / 'public', r / 'public-dist')
    private = build('build-private', r / 'private', r / 'private-dist')
    artifacts = [inspect(public, 'stridetorch/'), inspect(private, 'paperleet/_vendor/torch/')]
    for kind, prefix in [('public', 'stridetorch/'), ('private', 'paperleet/_vendor/torch/')]:
        archive = next((r / (kind + '-dist')).glob('*.tar.gz'))
        destination = r / (kind + '-sdist')
        destination.mkdir()
        with tarfile.open(archive) as stream:
            stream.extractall(destination, filter='data')
        if kind=='public':
            test_files={p.name:sha(p) for p in (next(destination.iterdir())/'tests').glob('*.py')};assert test_files=={p.name:sha(p) for p in (r/'public/tests').glob('*.py')} and len(test_files)==94
        wheel = build(kind + '-sdist-rebuild', next(destination.iterdir()), r / (kind + '-rebuild'), False)
        artifacts.extend([dict(path=str(archive.relative_to(r)), sha256=sha(archive)), inspect(wheel, prefix)])
    run('install-both', [uv, 'pip', 'install', '--python', python, '--target', r / 'installed',
                        '--no-deps', '--offline', public, private])
    smoke = '''
from pathlib import Path
import hashlib, importlib, json, sys
import numpy as np
prefix=Path(sys.argv[1]).resolve();sys.path.insert(0,str(prefix))
expected=json.load(open(sys.argv[2]))['expected']
import stridetorch as public
import paperleet
import paperleet._vendor.torch as private
assert Path(paperleet.__file__).resolve().is_relative_to(prefix)
for module in [public, private]:
    folder=Path(module.__file__).resolve().parent
    assert folder.is_relative_to(prefix) and module.__version__=='0.83.0'
    assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']}==expected
    api=module.torch
    x=api.tensor([3.,4.],dtype=api.float64,requires_grad=True)
    buffer=api.full_like(x,7.);x.grad=buffer
    value,product=api.autograd.functional.hvp(api.linalg.vector_norm,x,api.ones_like(x))
    assert value.item()==5. and x.grad is buffer
    np.testing.assert_allclose(product.numpy(),[.032,-.024],rtol=1e-9,atol=1e-12)
    np.testing.assert_array_equal(x.grad.numpy(),[7.,7.])
    backend=importlib.import_module(module.__name__+'._tensor')
    previous_flag=backend._WASM_MATMUL;backend._WASM_MATMUL=True
    try:
        a=api.ones(128,64,dtype=api.float64,requires_grad=True)
        b=api.ones(64,128,dtype=api.float64,requires_grad=True)
        y=a@b;da,db=api.autograd.grad(y,(a,b),api.ones_like(y))
        np.testing.assert_array_equal(y.numpy(),np.full((128,128),64.))
        np.testing.assert_array_equal(da.numpy(),np.full((128,64),128.))
        np.testing.assert_array_equal(db.numpy(),np.full((64,128),128.))
    finally:backend._WASM_MATMUL=previous_flag

for module in [public,private]:
    with module.as_torch() as api:
        clips=importlib.import_module('torch.nn.utils.clip_grad')
        p=api.tensor([3.,4.],dtype=api.float64,requires_grad=True)
        optimizer=api.optim.SGD([p],lr=.1);p.square().sum().backward();buffer=p.grad
        total=clips.clip_grad_norm_(p,1.);clips.clip_grad_value_([p],.7);optimizer.step()
        assert p.grad is buffer and total.item()==10.
        np.testing.assert_allclose(p.detach().numpy(),np.array([3.,4.])-.1*np.minimum(np.array([6.,8.])/(10+1e-6),.7),rtol=1e-12)

from stridetorch.experimental.webgpu import MatmulOffload,MatrixProgram,service_sources,source_files
assert len(service_sources())==6 and len(source_files())==77
assert not (Path(private.__file__).parent/'experimental').exists()
from paperleet.daily_challenges import schedule, challenge
_calendar=schedule()
assert challenge(_calendar['starts_on'])['problem_id']==_calendar['modules'][0]

native=importlib.import_module('torch')
saved={name:module for name,module in sys.modules.items() if name=='torch' or name.startswith('torch.')}
with public.as_torch():
    assert importlib.import_module('torch').Tensor is public.torch.Tensor
    with private.as_torch():
        assert importlib.import_module('torch').Tensor is private.torch.Tensor
    assert importlib.import_module('torch').Tensor is public.torch.Tensor
assert importlib.import_module('torch') is native
assert {name:module for name,module in sys.modules.items() if name=='torch' or name.startswith('torch.')}==saved
print(json.dumps(dict(status='passed_installed_current_package_paths_hvp_and_alias_restoration',public=str(public.__file__),private=str(private.__file__),numpy=np.__version__,native_torch=native.__version__)))
'''
    (r / 'installed-smoke.py').write_text(smoke)
    run('installed-smoke', [python, '-I', '-B', r / 'installed-smoke.py', r / 'installed', r / 'source-plan.json'])
    run('installed-smoke-numpy126', [b/'torch-iteration-137/native26-env/bin/python', '-I', '-B', r/'installed-smoke.py', r/'installed', r/'source-plan.json'])
    result = dict(status='passed_experimental_gpu_public_private_package_rebuilds',
                  version='0.83.0', resources=66, artifacts=artifacts, receipts=receipts,
                  source_plan_sha256=sha(r / 'source-plan.json'), runner_sha256=sha(Path(__file__)),
                  head=plan['head'], current_private_application_sources_verified=True,
                  previous_ownership_and_uninstall_proof='torch-iteration-307/result.json',
                  public_package_files=77,private_package_files=66,public_sdist_sdk_files=94,default_browser_exports_unchanged=183, main_adopted=False, ci_triggered=False, published=False, goal_status='active')
    write(r / 'result.json', result)
    write(r / 'progress.json', dict(status='completed', result_status=result['status']))
    print(json.dumps(dict(status=result['status'], artifacts=len(artifacts))), flush=True)
except BaseException as error:
    write(r / 'progress.json', dict(status='failed', error=str(error), traceback=traceback.format_exc(), receipts=receipts))
    raise
