from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
def gh(path):return json.loads(subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/'+path],cwd=repo,text=True))
def blob(name,ref):return subprocess.check_output(['git','show',ref+':'+name],cwd=repo)
assert not (r/'result.json').exists();grant=read(b/'torch-iteration-603/qualification-grant.json');head=grant['head'];push=read(b/'torch-iteration-603/adoption-push-receipt.json');assert push['exit_code']==0
remote=gh('git/ref/heads/main')['object']['sha'];assert remote==head,(remote,head);subprocess.run(['git','fetch','origin',head],cwd=repo,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
resources=grant['runtime_resources'];exports=read(b/'torch-iteration-603/live-export-sha256.json');policies=read(b/'torch-iteration-603/release-policy-identity.json')['files'];plan=read(b/'torch-iteration-602/execution-plan.json')
for prefix,mapping in [('packages/stridetorch/src/stridetorch/',resources),('web/public/data/',exports),('',policies),('packages/stridetorch/src/stridetorch/',read(b/'torch-iteration-603/public-package-sha256.json')),('',plan['our_files'])]:
 for name,h in mapping.items():assert hashlib.sha256(blob(prefix+name,head)).hexdigest()==h,name
for name,h in plan['qualified_inputs'].items():assert hashlib.sha256(blob(str(Path(name).relative_to(repo)),head)).hexdigest()==h,name
runs=gh('actions/runs?head_sha='+head+'&per_page=100');assert runs['total_count']==0
by_commit={head:runs['total_count']}
feature=read(b/'torch-iteration-601/commit-receipt.json')['head'];feature_runs=gh('actions/runs?head_sha='+feature+'&per_page=100');assert feature_runs['total_count']==0;by_commit[feature]=0
pages=gh('pages');assert pages['source']==dict(branch='gh-pages',path='/') and pages['build_type']=='legacy'
assert gh('git/ref/heads/main')['object']['sha']==head
write(r/'result.json',dict(status='verified_main_installed_experimental_webgpu_without_ci',adopted_commit=head,verified_remote_sha=remote,verified_utc=datetime.now(timezone.utc).isoformat(),remote_tree=subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=repo,text=True).strip(),optional_namespace_sha256=plan['our_files']['packages/stridetorch/src/stridetorch/experimental/webgpu/__init__.py'],prototype_and_own_files_verified_from_remote=True,qualified_runtime_version='0.83.0',default_runtime_unchanged=True,runtime_resources_verified=66,export_identities_verified=183,release_policies_verified=7,qualification_inputs_verified=len(plan['qualified_inputs']),public_package_inputs_verified=218,public_package_files_verified=77,own_delta=read(b/'torch-iteration-602/result.json')['own_delta'],workflow_runs_by_commit=by_commit,workflow_runs_for_adopted_commit=0,pages_source=pages['source'],ordinary_guarded_push=True,mandatory_wrapper_unchanged=True,successful_push_seconds=push['seconds'],successful_push_log_sha256=push['log_sha256'],experimental_packaged_webgpu_on_main=True,production_gpu_dispatch_enabled=False,resident_torch_gpu_storage=False,ci_triggered=False,tags_pushed=False,published=False,deployed=False,goal_status='active'));write(r/'remote-workflows.json',runs);write(r/'pages-source.json',dict(build_type=pages['build_type'],source=pages['source']));print(json.dumps(dict(status='verified_main_installed_experimental_webgpu_without_ci',head=head)))
