from pathlib import Path
import hashlib,json,os,subprocess,time,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent;b=r.parent;p=b/'torch-iteration-595';read=lambda path:json.loads(path.read_text());sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest();write=lambda path,value:path.write_text(json.dumps(value,indent=2)+'\n')
assert read(p/'result.json')['status']=='passed_experimental_gpu_public_private_package_rebuilds'
installed=p/'installed';sdk=next((p/'public-sdist').iterdir())/'tests';assert len(list(sdk.glob('*.py')))==94
inputs={str(path):sha(path) for folder in [installed/'stridetorch',installed/'paperleet',sdk,p/'root-tests'] for path in folder.rglob('*') if path.is_file()}
write(r/'source-plan.json',dict(inputs=inputs,runner_sha256=sha(Path(__file__)),installed=str(installed),sdk=str(sdk),scope='Final94-file SDK suite from sdist against final per-session-bound wheel; both supported NumPy baselines'))
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(installed),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
script="import sys;sys.path.insert(0,sys.argv[1]);import pytest;raise SystemExit(pytest.main(sys.argv[2:]))"
jobs=[]
for label,python,targets in [('numpy25',b/'torch-iteration-82/application-env/bin/python',[sdk]),('numpy126',b/'torch-iteration-137/native26-env/bin/python',[sdk])]:
 command=[str(python),'-I','-B','-c',script,str(installed),*[str(value) for value in targets],'-q','-p','no:cacheprovider','--basetemp='+str(r/(label+'-tmp')),'--junitxml='+str(r/(label+'.xml'))]
 output=(r/(label+'.log')).open('w');child=subprocess.Popen(command,cwd=r,env=env,stdout=output,stderr=subprocess.STDOUT);jobs.append((label,child,output,command,time.monotonic()))
 write(r/'progress.json',dict(status='running',supervisor_pid=os.getpid(),jobs=[dict(label=key,pid=process.pid) for key,process,*_ in jobs]))
receipts=[]
for label,child,output,command,start in jobs:
 code=child.wait();output.close();suites=list(ET.parse(r/(label+'.xml')).getroot().iter('testsuite'));totals={k:sum(int(v.attrib.get(k,0)) for v in suites) for k in ['tests','failures','errors','skipped']};receipt=dict(label=label,exit_code=code,totals=totals,command=command,seconds=time.monotonic()-start,log_sha256=sha(r/(label+'.log')));receipts.append(receipt);write(r/'receipts.json',receipts);print(json.dumps(receipt),flush=True)
for n,h in inputs.items():assert sha(Path(n))==h,n
assert all(v['exit_code']==0 and v['totals']['failures']==v['totals']['errors']==0 for v in receipts)
write(r/'result.json',dict(status='passed_installed_final_full_sdk',receipts=receipts,public_sdk_files=94,source_checkout_on_import_path=False,ci_triggered=False,goal_status='active'));write(r/'progress.json',dict(status='completed',receipts=receipts))
