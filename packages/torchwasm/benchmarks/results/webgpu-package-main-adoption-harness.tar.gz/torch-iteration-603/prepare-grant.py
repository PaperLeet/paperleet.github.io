from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
assert not (r/'qualification-grant.json').exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip()
integration=read(b/'torch-iteration-602/result.json');assert integration['status']=='passed_current_main_opt_in_package_integration' and all(v['exit_code']==0 for v in integration['receipts'])
plan=read(b/'torch-iteration-602/execution-plan.json')
for n,h in plan['frontend_inputs'].items():assert sha(repo/n)==h,n
for n,h in plan['our_files'].items():
 if not n.startswith('docs/validation/'):assert sha(repo/n)==h,n
for n,h in plan['qualified_inputs'].items():assert sha(Path(n))==h,n
summary=read(repo/'packages/stridetorch/benchmarks/results/webgpu-package.json');assert summary['status']=='qualified_installed_experimental_webgpu_package'
assert summary['targeted_native']['numpy25']==dict(tests=150,failures=0,errors=0,skipped=0)
assert summary['resident_performance']['all_overhead_gates_passed'] and summary['hotpath_identity_audit']['resident_hotpath_matches_measured_binding']
public=read(b/'torch-iteration-595/source-plan.json')['expected_public'];assert len(public)==77
for n,h in public.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/n)==h,n
write(r/'public-package-sha256.json',public)
assert len(summary['package_inputs'])==218
for n,h in summary['package_inputs'].items():assert sha(Path(n))==h,n
for n,h in read(b/'torch-iteration-601/commit-receipt.json')['paths'].items():
 if not n.startswith('docs/validation/'):assert sha(repo/n)==h,n
assert summary['core_root_resources_unchanged']==66 and summary['public_package_files']==77 and not summary['default_gpu_dispatch_enabled']
delta=subprocess.check_output(['git','diff','--name-only',integration['remote_baseline'],'HEAD'],cwd=repo,text=True).splitlines()
assert all(n in integration['own_delta'] or n.startswith(('docs/validation/','packages/stridetorch/benchmarks/results/')) for n in delta),delta
resources=read(b/'torch-iteration-511/source-hashes.json');exports=read(b/'torch-iteration-511/live-export-sha256.json');assert len(resources)==66 and len(exports)==183
for n,h in resources.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/n)==h,n
for n,h in exports.items():assert sha(repo/'web/public/data'/n)==h,n
write(r/'source-hashes.json',resources);write(r/'live-export-sha256.json',exports)
for n,h in read(r/'release-policy-identity.json')['files'].items():assert sha(repo/n)==h,n
required={}
for n in ['operand-lifetime-jspi-followup.json','operand-lifetime-owned-flow.json','qualification-0.83.json','qualification-0.83-main-adoption.json','post083-shape-jspi.json','webgpu-tensor-offload.json','webgpu-tensor-offload-main-adoption.json','resident-session.json','resident-session-main-adoption.json','protocol-negotiation.json','protocol-negotiation-main-adoption.json','webgpu-package.json']:
 aggregate=read(repo/'packages/stridetorch/benchmarks/results'/n);receipt=aggregate.get('raw_archive',aggregate.get('archive'));archive=repo/receipt['path'];assert sha(archive)==receipt['sha256']
 with tarfile.open(archive) as stream:manifest=json.load(stream.extractfile('sha256.json'))
 for name,h in manifest.items():assert sha(b/name)==h,name;required[str(b/name)]=h
for stage in [595,596,599,600,601,602]:
 for p in (b/f'torch-iteration-{stage}').iterdir():
  if p.is_file():required[str(p)]=sha(p)
wrapper=b/'torch-iteration-67/final-integration/push-main-native.py';assert sha(wrapper)=='4b51422c5533ca6177a4a29a557cf37d1c6727d7530908e444be5833588c2882'
for p in list(r.glob('*.py'))+[r/'guard-provenance.json',r/'release-policy-identity.json',r/'release-policy-variants.json',r/'commit-receipt.json',r/'public-package-sha256.json',wrapper]:required[str(p)]=sha(p)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();names=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0');reviewed={n:sha(repo/n) for n in names if n}
write(r/'qualification-grant.json',dict(head=head,source_resources=66,runtime_resources=resources,ci_triggered=False,version='0.83.0',local_qualification_complete=True,public_package_resources=77,scope='Qualified opt-in installed experimental GPU package; default CPU root66, exports183 and private application unchanged',required_files=[dict(path=n,sha256=h) for n,h in required.items()],reviewed_commit_files=reviewed))
write(r/'grant-receipt.json',dict(head=head,remote_baseline=integration['remote_baseline'],tracked_files=len(reviewed),required_files=len(required),own_delta=delta,default_runtime_unchanged=True,public_package_inputs_unchanged=False,public_package_inputs_verified=218,public_package_files_verified=77,ci_triggered=False,goal_status='active'));print(json.dumps(dict(head=head,tracked_files=len(reviewed),required_files=len(required))))
