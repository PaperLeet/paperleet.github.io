from pathlib import Path
import hashlib, json, shutil, tarfile

r = Path(__file__).resolve().parent
s = r/'main-sync-proof'
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
out = repo/'packages/stridetorch/benchmarks/results'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
context = json.loads((s/'context.json').read_text())
front = json.loads((s/'frontend-receipts.json').read_text())
assert len(front) == 5 and all(v['exit_code'] == 0 for v in front)
assert len(context['source_hashes']) == 49 and len(context['active_export_sha256']) == 161
for n, v in context['changed_files'].items(): assert sha(repo/n) == sha(s/'incoming'/n) == v
for n, v in context['source_hashes'].items(): assert sha(repo/'packages/stridetorch/src/stridetorch'/n) == v
for n, v in context['active_export_sha256'].items(): assert sha(repo/'web/public/data'/n) == v
shutil.copy2(Path(__file__), s/'close-main-sync.py')
archive = out/'iteration-39-main-sync-harness.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for path in sorted(s.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            tar.add(path, arcname=str(path.relative_to(s)), recursive=False)
report = dict(status='complete_local_latest_frontend_passed_runtime_identity_unchanged',
    version='0.39.0', context=context, frontend_receipts=front,
    archive=dict(file=archive.name, bytes=archive.stat().st_size, sha256=sha(archive)),
    scope='Incoming changes are frontend/styles/checks/documentation only; no Python,package,problem,catalog,runtime,export or release-policy input changed. Existing full numerical and real WASM evidence retains exact source and payload identities.',
    publication='No GitHub CI,tag,dispatch,package upload or online publication.')
(out/'iteration-39-main-sync.json').write_text(json.dumps(report, indent=2)+'\n')
doc = repo/'docs/validation/torch-runtime-iteration-39.md'
doc.write_text(doc.read_text()+f'\nFinal synchronization preserves all ten incoming frontend/style/check/documentation\nfiles through `{context["upstream"]}` byte-for-byte. The complete current\nfrontend checks and both typed builds pass again. All 49 computational/license\nresources and 161 active exports retain their full-test identities. Python,\npackage,problem and catalog inputs did not change. See `iteration-39-main-sync.json`.\n')
print(json.dumps(dict(upstream=context['upstream'], source_unchanged=49, exports_unchanged=161, archive=report['archive'])))
