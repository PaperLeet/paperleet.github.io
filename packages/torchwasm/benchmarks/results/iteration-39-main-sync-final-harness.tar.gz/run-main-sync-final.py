from pathlib import Path
import hashlib, json, os, shutil, subprocess, time, tarfile

r = Path(__file__).resolve().parent
s = r/'main-sync-final'; s.mkdir(exist_ok=True)
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
old = '33eacaa33ecfaeec0df638a4664ac0ae98938a73'
upstream = subprocess.check_output(['git','rev-parse','HEAD^'], cwd=repo, text=True).strip()
files = subprocess.check_output(['git','diff','--name-only', old+'..'+upstream], cwd=repo, text=True).splitlines()
assert len(files) == 6 and all(n.startswith(('web/','docs/')) for n in files)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
source = json.loads((r/'proof/source-hashes.json').read_text())
exports = json.loads((r/'integration-proof/live-expected-sha256.json').read_text())
for n, h in source.items(): assert sha(repo/'packages/stridetorch/src/stridetorch'/n) == h
for n, h in exports.items(): assert sha(repo/'web/public/data'/n) == h
for name in files:
    target = s/'incoming'/name; target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(repo/name,target)
context = dict(previous_upstream=old,upstream=upstream,changed_files={n:sha(repo/n) for n in files},source_hashes=source,active_export_sha256=exports,
    scope='Six late sequential-study frontend/check/style/documentation files. Complete frontend passed on33eacaa3; affected full preparation-guide interactions and both current typed builds are repeated. No numerical/package/catalog/problem/export/release-policy input changed.')
(s/'context.json').write_text(json.dumps(context,indent=2)+'\n')
value = subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED','--jq','.value'],cwd=repo,text=True).strip()
profile = dict(VITE_PUBLIC_SITE='0',VITE_APP_EDITION='hosted',VITE_API_ORIGIN='https://app.paperleet.com',VITE_HOSTED_APP_AVAILABLE='1',VITE_HOSTED_APP_URL='https://app.paperleet.com') if value=='1' else dict(VITE_PUBLIC_SITE='1',VITE_APP_EDITION='public',VITE_API_ORIGIN='',VITE_HOSTED_APP_AVAILABLE='1',VITE_HOSTED_APP_URL='https://app.paperleet.com')
(s/'pages-profile.json').write_text(json.dumps(dict(observed_value=value,environment=profile),indent=2)+'\n')
env = dict(os.environ,PATH='/opt/homebrew/bin:'+os.environ['PATH']);receipts=[]
plans = [('preparation-guides',['/opt/homebrew/bin/node','scripts/check-preparation-guides.mjs'],repo/'web',{}),
         ('frontend-build',['npm','run','build'],repo/'web',{}),
         ('pages-profile-build',['npm','run','build'],repo/'web',profile)]
for name,args,cwd,overrides in plans:
    start=time.monotonic()
    with (s/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=cwd,env={**env,**overrides},stdout=log,stderr=subprocess.STDOUT)
    receipts.append(dict(name=name,args=args,cwd=str(cwd),exit_code=p.returncode,elapsed_s=time.monotonic()-start))
    (s/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,p.returncode,flush=True);p.check_returncode()
for n,h in source.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/n)==h
for n,h in exports.items():assert sha(repo/'web/public/data'/n)==h
for n,h in context['changed_files'].items():assert sha(repo/n)==sha(s/'incoming'/n)==h
shutil.copy2(Path(__file__),s/Path(__file__).name)
out=repo/'packages/stridetorch/benchmarks/results';archive=out/'iteration-39-main-sync-final-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for p in sorted(s.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:tar.add(p,arcname=str(p.relative_to(s)),recursive=False)
report=dict(runner_note='First focused invocation used repository rather than web working directory and could not locate test data. Corrected runner cwd;no product changes. Original invocation retained in first-attempt.',status='complete_local_late_frontend_sync_passed_runtime_identity_unchanged',version='0.39.0',context=context,receipts=receipts,
    archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),publication='No GitHub CI,tag,dispatch,package upload or online publication.')
(out/'iteration-39-main-sync-final.json').write_text(json.dumps(report,indent=2)+'\n')
doc=repo/'docs/validation/torch-runtime-iteration-39.md'
doc.write_text(doc.read_text()+f'\nA later synchronization preserves six sequential-study UI/check/style/documentation\nfiles through `{upstream}`. The affected preparation-guide interaction suite and\nboth typed builds pass on this final tree. All 49 runtime/license resources and\n161 active exports remain byte-identical. See `iteration-39-main-sync-final.json`.\n')
print('Late main synchronization closed',upstream,flush=True)
