import {loadJudgePackages} from '../../../extraction-browser/packages.mjs';
self.onmessage=async({data})=>{try{
 const plan=await(await fetch('./bench-plan.json')).json();
 const {loadPyodide}=await import('../../../runtime-0.29.4/pyodide.mjs');
 const py=await loadPyodide({indexURL:new URL('../../../runtime-0.29.4/',self.location.href).href,stdout(){},stderr(){}});await loadJudgePackages(py,[]);
 for(const [name,relative,hashes] of [['candidate','source',plan.source],['baseline','baseline',plan.baseline]]){py.FS.mkdirTree('/'+name);for(const file of Object.keys(hashes))py.FS.writeFile('/'+name+'/'+file,await(await fetch('./'+relative+'/'+file)).text());}
 py.FS.writeFile('/bench.py',await(await fetch('./bench.py')).text());py.globals.set('plan_json',JSON.stringify(plan));py.globals.set('reverse_order',data.reverse);
 const report=JSON.parse(py.runPython(`import json,pathlib,hashlib,runpy
plan=json.loads(plan_json)
for folder,key in [('candidate','source'),('baseline','baseline')]:
 actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path('/'+folder).iterdir() if p.is_file()}
 assert actual==plan[key]
assert hashlib.sha256(pathlib.Path('/bench.py').read_bytes()).hexdigest()==plan['benchmark_sha256']
report=runpy.run_path('/bench.py')['run']('/baseline','/candidate',reverse_order=reverse_order)
report.update(runtime='Chrome/Pyodide',benchmark_sha256=plan['benchmark_sha256'])
json.dumps(report)`));self.postMessage({...report,pyodide:py.version});
 }catch(error){self.postMessage({error:String(error.stack||error)});}};
