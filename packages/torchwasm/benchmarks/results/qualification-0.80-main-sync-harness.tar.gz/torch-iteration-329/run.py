from pathlib import Path
import hashlib,json,os,subprocess,tarfile,traceback,zipfile
r=Path(__file__).resolve().parent;b=r.parent
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
plan=read(r/'source-plan.json');receipts=[]
python=b/'torch-iteration-82/application-env/bin/python'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONPATH',None)
def verify():
 execution=read(r/'execution-plan.json');assert sha(Path(__file__))==execution['runner_sha256'];assert sha(r/'source-plan.json')==execution['source_plan_sha256']
 for name,h in plan['inputs'].items():assert sha(Path(name))==h,name
 for name,h in plan['staged'].items():assert sha(r/name)==h,name
def build(label,source,output,sdist):
 verify();output.mkdir();code='from setuptools import build_meta;import sys;target=sys.argv[1];'+('build_meta.build_sdist(target);' if sdist else '')+'build_meta.build_wheel(target)'
 with (r/(label+'.log')).open('w') as log:
  child=subprocess.run([str(python),'-B','-c',code,str(output)],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(label=label,exit_code=child.returncode,log_sha256=sha(r/(label+'.log'))));child.check_returncode();verify();return next(output.glob('*.whl'))
def inspect(wheel):
 with zipfile.ZipFile(wheel) as archive:
  prefix='stridetorch/';actual={name[len(prefix):]:hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist() if name.startswith(prefix)};assert actual==plan['expected']
  metadata=archive.read('stridetorch-0.80.0.dist-info/METADATA').decode();assert 'License-Expression: Apache-2.0' in metadata
  assert [line for line in metadata.splitlines() if line.startswith('Requires-Dist:')]==['Requires-Dist: numpy>=1.26']
  assert metadata.split('\n\n',1)[1].rstrip('\n')==(r/'public/README.md').read_text().rstrip('\n')
 return dict(path=str(wheel.relative_to(r)),sha256=sha(wheel),resources=len(actual))
try:
 public=build('public',r/'public',r/'dist',True);artifacts=[inspect(public)];sdist=next((r/'dist').glob('*.tar.gz'));destination=r/'sdist';destination.mkdir()
 with tarfile.open(sdist) as stream:stream.extractall(destination,filter='data')
 rebuilt=build('sdist-rebuild',next(destination.iterdir()),r/'rebuilt',False);artifacts.extend([inspect(rebuilt),dict(path=str(sdist.relative_to(r)),sha256=sha(sdist))])
 result=dict(status='passed_public_metadata_refresh_runtime_unchanged',artifacts=artifacts,receipts=receipts,runtime_resources=65,readme_sha256=sha(r/'public/README.md'),runtime_unchanged=True,previous_installed_package_proof=plan['previous_package_proof_sha256'],ci_triggered=False,published=False,main_adopted=False,goal_status='active');write(r/'result.json',result);write(r/'progress.json',dict(status='completed'));print(json.dumps(result),flush=True)
except BaseException as error:
 write(r/'progress.json',dict(status='failed',error=str(error),traceback=traceback.format_exc(),receipts=receipts));raise
