import json, os, sys
import numpy as np
if os.environ.get('STRIDE_PROBE'):
 from stridetorch import torch
else: import torch
rng=np.random.default_rng(4710)
results=[]
def array(x): return x.detach().numpy().tolist() if x is not None else None
for dtype in [torch.float32,torch.float64]:
 for shape in [(2,3,7),(2,3,3,4),(2,3,2,3,2),(2,3),(2,3,0)]:
  for training in [False,True]:
   if training and len(shape)==2:continue
   for layout in ['C','F','strided']:
    raw=rng.normal(size=shape).astype(np.float32 if dtype==torch.float32 else np.float64)
    if layout=='F': raw=np.asfortranarray(raw)
    if layout=='strided':
     base=np.empty((*shape[:-1],shape[-1]*2),dtype=raw.dtype);base[...,::2]=raw;raw=base[...,::2]
    x=torch.from_numpy(raw).requires_grad_();w=torch.tensor(rng.normal(size=shape[1]),dtype=dtype,requires_grad=True);b=torch.tensor(rng.normal(size=shape[1]),dtype=dtype,requires_grad=True)
    rm=torch.tensor(rng.normal(size=shape[1]),dtype=dtype);rv=torch.tensor(rng.uniform(.3,2,size=shape[1]),dtype=dtype)
    seed=torch.tensor(rng.normal(size=shape),dtype=dtype)
    f=lambda a,c,d:torch.nn.functional.instance_norm(a,rm,rv,c,d,use_input_stats=training,momentum=.25)
    y=f(x,w,b);y.backward(seed)
    result={'id':f'{dtype}-{shape}-{training}-{layout}','value':array(y),'grads':[array(z.grad) for z in (x,w,b)],'state':[array(rm),array(rv)],'versions':[rm._version,rv._version]}
    vals=[torch.tensor(rng.normal(size=shape),dtype=dtype,requires_grad=True),torch.tensor(rng.normal(size=shape[1]),dtype=dtype,requires_grad=True),torch.tensor(rng.normal(size=shape[1]),dtype=dtype,requires_grad=True)]
    dx=[torch.tensor(rng.normal(size=z.shape),dtype=dtype,requires_grad=True) for z in vals]
    a,t=torch.func.jvp(f,tuple(vals),tuple(dx));(a*seed+t*seed.square()).sum().backward()
    result.update(jvp=array(t),reverse_tangent=[array(z.grad) for z in (*vals,*dx)])
    results.append(result)
print(json.dumps(results,allow_nan=True))
