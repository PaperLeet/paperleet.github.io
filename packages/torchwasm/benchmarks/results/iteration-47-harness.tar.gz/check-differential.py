from pathlib import Path
import json,numpy as np,hashlib
r=Path(__file__).resolve().parent;fail=[];checks=0
reference=json.loads((r/'reference.json').read_text());candidate=json.loads((r/'candidate.json').read_text())
assert len(reference)==len(candidate)==54
for a,b in zip(reference,candidate):
 assert a['id'].replace('torch.','')==b['id'].replace('torch.','')
 for key in ['value','grads','state','versions','jvp','reverse_tangent']:
  pairs=zip(a[key],b[key]) if key in ['grads','state','reverse_tangent'] else [(a[key],b[key])]
  for i,(left,right) in enumerate(pairs):
   checks+=1
   try:np.testing.assert_allclose(right,left,rtol=8e-6 if 'float32' in a['id'] else 3e-12,atol=8e-6 if 'float32' in a['id'] else 3e-12,equal_nan=True)
   except AssertionError:fail.append([a['id'],key,i])
semantic_cases=0
def compare(a,b):
 global checks
 if isinstance(a,dict):
  assert a.keys()==b.keys()
  for key in a: compare(a[key],b[key])
 elif isinstance(a,str) or a is None:assert a==b,(a,b)
 elif isinstance(a,list):
  assert len(a)==len(b)
  for x,y in zip(a,b):compare(x,y)
 else:
  checks+=1;np.testing.assert_allclose(b,a,rtol=3e-12,atol=3e-12,equal_nan=True)
for a,b in zip(json.loads((r/'semantics-reference.json').read_text()),json.loads((r/'semantics-candidate.json').read_text())):
 compare(a,b);semantic_cases+=1
assert not fail,fail
expected=json.loads((r/'proof/source-hashes.json').read_text());source=Path('/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src/stridetorch')
assert expected=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']}
report=dict(status='success',numeric_cases=54,semantic_cases=semantic_cases,array_state_checks=checks,source_hashes=expected,native_version='2.14.1',candidate_version='0.47.0',tolerances=dict(float32=dict(rtol=8e-6,atol=8e-6),float64=dict(rtol=3e-12,atol=3e-12)),scope='Float32/64 C/F/strided values, VJP, JVP, reverse-over-forward, state values/versions; mutation snapshots/guards; partial/empty state; epsilon boundaries. Native and candidate separate Python processes.')
(r/'native-differential-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k!='source_hashes'})
