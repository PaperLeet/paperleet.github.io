from pathlib import Path
import inspect,json,torch,warnings
import numpy as np
torch.set_num_threads(2)
F=torch.nn.functional;records=[]
def record(name,fn):
 try:
  with warnings.catch_warnings(record=True) as ws:
   warnings.simplefilter('always');result=fn()
  records.append(dict(name=name,result=result,warnings=[str(w.message) for w in ws]))
 except Exception as e:records.append(dict(name=name,error=type(e).__name__,message=str(e)[:240]))
for shape in [(2,3),(2,3,4),(0,3,4),(2,0,4),(2,3,0),(2,3,1),(0,3,1),(2,3,2,3),(2,3,2,3,4)]:
 for training in (False,True):
  for buffers in ('both','none','mean','var'):
   def run(shape=shape,training=training,buffers=buffers):
    x=torch.arange(int(np.prod(shape)),dtype=torch.float64).reshape(shape).requires_grad_();c=shape[1]
    rm=torch.zeros(c) if buffers in ('both','mean') else None;rv=torch.ones(c) if buffers in ('both','var') else None
    rm=rm.double() if rm is not None else None;rv=rv.double() if rv is not None else None
    versions=[a._version if a is not None else None for a in (rm,rv)];y=F.instance_norm(x,rm,rv,use_input_stats=training);y.sum().backward()
    return dict(shape=list(y.shape),stride=list(y.stride()),mean=rm.tolist() if rm is not None else None,var=rv.tolist() if rv is not None else None,version_before=versions,version_after=[a._version if a is not None else None for a in (rm,rv)],grad_shape=list(x.grad.shape))
   record(str((shape,training,buffers)),run)
for layout in ('C','F','strided','channels_last'):
 for changed in ('x','w','b','rm','rv','out'):
  for training in (False,True):
   def run(layout=layout,changed=changed,training=training):
    a=np.arange(2*3*4*5,dtype=np.float64).reshape(2,3,4,5)/17
    if layout=='F':a=np.asfortranarray(a)
    if layout=='strided':a=np.repeat(a,2,axis=-1)[...,::2]
    if layout=='channels_last':a=a.transpose(0,2,3,1).copy().transpose(0,3,1,2)
    x=torch.from_numpy(a).requires_grad_();w=torch.ones(3,dtype=torch.float64,requires_grad=True);b=torch.zeros_like(w,requires_grad=True);rm=torch.zeros(3,dtype=torch.float64);rv=torch.ones_like(rm)
    y=F.instance_norm(x,rm,rv,w,b,training);loss=y.square().sum()
    with torch.no_grad():dict(x=x,w=w,b=b,rm=rm,rv=rv,out=y)[changed].add_(1)
    loss.backward();return dict(dx=x.grad.flatten()[:3].tolist(),dw=w.grad.tolist(),stride=list(y.stride()))
   record(str(('mutation',layout,changed,training)),run)
for eps in (0.,-1.,float('nan'),float('inf')):
 for training in (False,True):
  record(str(('eps',eps,training)),lambda eps=eps,training=training:F.instance_norm(torch.ones(2,3,4),torch.zeros(3),torch.ones(3),use_input_stats=training,eps=eps).tolist())
for training in (False,True):
 for tracking in (False,True):
  def run(training=training,tracking=tracking):
   m=torch.nn.InstanceNorm1d(3,affine=True,track_running_stats=tracking,dtype=torch.float64).train(training);x=torch.randn(2,3,4,dtype=torch.float64,requires_grad=True)
   y,j=torch.func.jvp(m,(x,),(torch.ones_like(x),));j.square().sum().backward()
   return dict(value_shape=list(y.shape),tangent=j.flatten()[:3].tolist(),batches=m.num_batches_tracked.item() if tracking else None,versions=[a._version if a is not None else None for a in (m.running_mean,m.running_var)])
  record(str(('module_jvp',training,tracking)),run)
for dtype in (torch.float16,torch.float32,torch.float64,torch.int64):
 record(str(('dtype',str(dtype))),lambda dtype=dtype:F.instance_norm(torch.ones(2,3,4,dtype=dtype)).dtype.__str__())
record('module_bias_false',lambda:list(torch.nn.InstanceNorm2d(3,affine=True,bias=False).state_dict()))
record('module_none_momentum',lambda:vars(torch.nn.InstanceNorm1d(3,momentum=None,track_running_stats=True))['momentum'])
Path(__file__).with_name('native-probe.json').write_text(json.dumps(dict(torch=torch.__version__,records=records),indent=2)+'\n')
print('Native probe cases',len(records),'errors',sum('error' in r for r in records))
