from pathlib import Path
import shutil,json,hashlib
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-46';repo=Path('/Users/david/Developer/PaperLeet-torch-release');p=r/'proof';p.mkdir(exist_ok=True);chrome=p/'chrome-contracts';chrome.mkdir(exist_ok=True)
for folder in [p/'source',chrome/'source']:
 folder.mkdir(exist_ok=True)
 for f in (repo/'packages/stridetorch/src/stridetorch').iterdir():
  if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']:shutil.copy2(f,folder/f.name)
tests=chrome/'tests';tests.mkdir(exist_ok=True)
for f in (repo/'packages/stridetorch/tests').glob('test_*.py'):
 if f.name!='test_standalone.py':shutil.copy2(f,tests/f.name)
hashes=lambda d:{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in d.iterdir() if f.is_file()}
source=hashes(p/'source');assert len(source)==52
(p/'source-hashes.json').write_text(json.dumps(source,indent=2)+'\n')
(chrome/'plan.json').write_text(json.dumps(dict(version='0.47.0',expected=5085,source=source,tests=hashes(tests)),indent=2)+'\n')
assert len(hashes(tests))==44
for name in ['run.mjs','worker.mjs','index.html']:
 (chrome/name).write_text((old/'proof/chrome-contracts'/name).read_text().replace('torch-iteration-46','torch-iteration-47'))
for name in ['wasm-contracts.mjs','check-wheel.py','check-coinstall.py']:
 s=(old/'proof'/name).read_text().replace('torch-iteration-46','torch-iteration-47').replace('0.46.0','0.47.0').replace('stride046','stride047')
 if name=='wasm-contracts.mjs':s=s.replace("'batchnorm','groupnorm'","'batchnorm','groupnorm','instancenorm'").replace('record.passed==4902','record.passed==5085')
 if name=='check-wheel.py':s=s.replace('len(names)==49','len(names)==50').replace('package_modules=49','package_modules=50')
 if name=='check-coinstall.py':
  pos=s.index('for name in NAMES:\n t=importlib.import_module(name).torch')
  s=s[:pos]+'''for name in NAMES:
 t=importlib.import_module(name).torch
 layer=t.nn.InstanceNorm2d(3,affine=True,track_running_stats=True,dtype=t.float64)
 value=t.tensor(np.sin(np.arange(72)).reshape(2,3,3,4),requires_grad=True)
 y,dy=t.func.jvp(layer,(value,),(t.ones_like(value),))
 (y.square().sum()+dy.square().sum()).backward()
 assert layer.num_batches_tracked.item()==0 and np.isfinite(value.grad.numpy()).all()
 assert layer.running_mean._version==2
''' +s[pos:]
 (p/name).write_text(s)
for name in ['run-full.py','run-gates.py','run-setup-final.py']:
 (r/name).write_text((old/name).read_text().replace('torch-iteration-46','torch-iteration-47'))
i=r/'integration-proof';i.mkdir(exist_ok=True)
for name in ['run-setup.py','run-export.py','freeze.py','verify-private.py','verify-export.py','run-native.py','run-frontend.py','run-wasm.py']:
 s=(old/'integration-proof'/name).read_text().replace('torch-iteration-46','torch-iteration-47').replace('0.46.0','0.47.0')
 if name=='freeze.py':s=s.replace('len(tests)==43','len(tests)==44').replace("plan['expected']==4902","plan['expected']==5085").replace('expected_passed=4902','expected_passed=5085').replace('expected_suites=43','expected_suites=44')
 if name=='verify-export.py':s=s.replace('10229','10387')
 if name=='verify-private.py':s=s.replace('==51','==52').replace('==49','==50')
 if name=='run-wasm.py':s=s.replace('4902','5085').replace('==43','==44')
 (i/name).write_text(s)
(i/'context.json').write_text(json.dumps(dict(upstream='2b2795fd6de3d36986c4d90963dcc2d614c0a73f',version='0.47.0',source_hashes=source),indent=2)+'\n')
print({'resources':len(source),'suites':len(hashes(tests)),'expected_contracts':5085})
