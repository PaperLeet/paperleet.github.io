from pathlib import Path
import json,statistics
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
a=json.loads((out/'iteration-47.json').read_text());b=json.loads((out/'iteration-47-integration.json').read_text());perf=a['performance'];full=a['full_cpu'];native=b['native'];wasm=b['wasm'];size=a['source_footprint']
rows=[]
for runtime,label in [('cpu','NumPy CPU'),('node','Node/Pyodide'),('chrome','Chrome Worker')]:
 for mode in ['forward','reverse','jvp','cnn_sgd']:
  values=[v['time_reduction_percent'] for v in perf['summary'][runtime] if v['mode']==mode]
  rows.append(f'| {label} | {mode} | {statistics.median(values):.1f}% | {min(values):.1f}% to {max(values):.1f}% |')
text=f'''# Torch runtime iteration 47 — InstanceNorm

Version 0.47.0 adds independent per-instance normalization to the standalone and
private PaperLeet runtimes. Main adoption is recorded separately after local gates.
The broader independent-library, efficiency and optional GPU-backend goal remains active.

## Behavior and implementation

- Add `nn.InstanceNorm1d/2d/3d`, `nn.functional.instance_norm`, the low-level
  `torch.instance_norm` entry and ordinary `torch.nn.modules.instancenorm` aliases.
  Batched/unbatched inputs, optional affine parameters and `bias=False` work.
- Extract shared module state into `_NormBase`; InstanceNorm inherits that base
  rather than BatchNorm. Existing BatchNorm adds its native keyword-only `bias`
  option while retaining its counter and cumulative-average behavior.
- Normalize each sample/channel over spatial axes. Update running means and
  unbiased variances across samples, with native buffer-version increments.
  InstanceNorm does not increment `num_batches_tracked`; `momentum=None` means
  zero update momentum, rather than BatchNorm's cumulative average.
- Direct NumPy math and one shared analytical VJP avoid repeated affine tensors
  and extra graph nodes. JVP and reverse-over-forward use native saved-statistic
  conventions. Evaluation statistics and affine values are snapshotted.
- Contiguous input storage is guarded; noncontiguous inputs are copied before
  normalization. Later original affine/running-buffer edits preserve backward
  values. Detached output edits do not invalidate this operator's own tape.
- Retain native functional spatial-singleton errors, low-level singleton behavior,
  empty/partial-buffer state updates, zero-channel affine errors, epsilon edge
  behavior, shared running storage, version-2 and legacy checkpoint handling.

## Local evidence

| Check | Result |
|---|---|
| Complete repository and library CPU suite | {full['passed']:,} passed, {full['skipped']} skipped; {full['duration_s']:.2f}s |
| Focused independent InstanceNorm tests | 182 passed |
| Native PyTorch 2.14.1 differential | 54 numeric + 64 state/boundary cases; 2,142 comparison assertions |
| Node/Pyodide 0.29.4, NumPy 2.2.5 | 5,085 contracts across 44 suites |
| Actual Chrome {a['chrome_worker']['browser']} Worker | 5,085 contracts, same exact source/test hashes |
| Installed standalone wheel, Python 3.10.19 / NumPy 1.26.4 | 5,098 passed; native Torch absent |
| Standalone/private wheels and source archives | Exact 52 source/license resources, disjoint installation paths |
| Both installed packages, independent uninstall | Alias, checkpoint/optimizer resume, InstanceNorm JVP/VJP pass |
| Original native PaperLeet catalog | 78 problems, 10,218 executions, 342 mutants, three repeats; {native['duration_s']:.3f}s / 600s |
| Complete exported browser WASM catalog | 78/78, 342 mutants, 5,085 contracts; {wasm['elapsed_ms']/1000:.3f}s |
| Maintained frontend and both build profiles | Five successful local receipts |
| Release policy | Seven files byte-identical to canonical `13d2782a494415ba72bc604a0ef7e4c4f875ba25` |

The native oracle and candidate run in separate Python processes. Numeric cases
check float32/64 C/F/strided outputs, all affine/input VJPs, JVPs and their reverse
pullbacks, plus state values/versions. A separate native probe checks mutation
snapshots, input guards, empty/partial state and epsilon boundaries. Independent
NumPy and finite-difference tests cover every active-gradient subset, retained
backward, module lifecycle and a convolution/InstanceNorm/GELU/SGD checkpoint resume.

The maintained exported-catalog driver runs at concurrency two. The original
native catalog is capped at two numerical-library threads; its runtime is not a
speedup comparison against earlier uncapped runs. No browser budget is exceeded.

## Performance

All figures compare direct InstanceNorm with the existing BatchNorm composition
in the same final source; 0.46 did not expose an InstanceNorm API. Four fresh
processes for each CPU/Node/Chrome runtime, alternating method/runtime order,
five samples per flow and 12 ordinary calls (three SGD steps) retain every sample.
Each child checks values, JVPs, reverse-over-forward and three matching SGD updates
before timing. The 26 flows cover 1D/2D/3D, two dtypes and full convolution training.

Positive percentages mean less elapsed time. Each row aggregates the per-flow
medians of the four fresh children; ranges retain regressions and variation.

| Runtime | Flow | Median time reduction | Range across shapes/dtypes |
|---|---|---:|---:|
{chr(10).join(rows)}

This is a shared-host, same-runtime composition comparison. It does not establish
native PyTorch or GPU speed, peak-memory savings, cold-start behavior, or uniform
improvements for other shapes. No WebGPU execution or backend is claimed here.

## Identity, packaging and integration

The candidate has 50 Python modules plus LICENSE/NOTICE: 48 old resources remain
unchanged, three old resources change (`__init__.py`, `_api.py`, `_batchnorm.py`),
and `_instancenorm.py` is added. Sorted source/license bytes change from
{size['baseline']['raw_source_license_bytes']:,} to {size['candidate']['raw_source_license_bytes']:,};
local concatenated gzip changes from {size['baseline']['local_concatenated_gzip_bytes']:,} to
{size['candidate']['local_concatenated_gzip_bytes']:,}. These are source-footprint
estimates, not wheel/network bytes or measured process memory.

All 10,387 previously published immutable payloads are preserved; 158 new payloads
are reachable, yielding 10,545 total. The 161 active export identities match the
final source. Public/private wheel and source archive payloads match that source;
both packages work outside the checkout without native Torch. No dependency or
lockfile changes are included. Existing owned runtime and lockfile hashes were
rechecked before the exported-browser run.

Float16/complex normalization, general differentiable non-leaf mutation, storage
rebinding across saved normalization graphs and a persistent WebGPU tensor backend
remain outside this version's validated support. Floating-point accumulation is
not a bitwise equivalence promise for ill-conditioned or exceptional input.

Evidence: `packages/stridetorch/benchmarks/results/iteration-47.json`,
`iteration-47-integration.json` and four matching raw harness archives preserve
source/test identities, native reference/candidate outputs, all timing samples,
command receipts and logs. `bench_instance_norm.py` is the portable public benchmark.
Prototype runs are not counted as final verification; an unversioned partial CPU
run was explicitly stopped after source changes and replaced with the frozen run.

No tag, workflow dispatch, release, PyPI upload or deployment is initiated by this work.
'''
(repo/'docs/validation/torch-runtime-iteration-47.md').write_text(text)
p=repo/'packages/stridetorch/ROADMAP.md';s=p.read_text();s=s.replace('4. Neural-network coverage: expand instance normalization, attention options,','4. Neural-network coverage: expand attention options,')
s+='''\n## InstanceNorm milestone (0.47)\n\n- Add batched/unbatched InstanceNorm1d/2d/3d, functional/root entries, native\n  shared `_NormBase` state and optional bias. Preserve running snapshots,\n  counters, mutation guards, empty boundaries, analytical VJP/JVP and mixed AD.\n- Validate 182 focused tests, 118 native differential cases, 38,714 CPU passes,\n  5,085 actual Node/Chrome contracts and all 78 exported PaperLeet problems.\n- Compare 26 direct/composed flows across 12 fresh CPU/Node/Chrome processes,\n  including complete convolution/SGD steps; retain every timing sample.\n- Preserve 10,387 prior payloads and seven release-policy files. See the\n  [iteration 47 record](../../docs/validation/torch-runtime-iteration-47.md).\n  Broader core APIs, efficiency and optional persistent GPU backend work remain active.\n''';p.write_text(s)
p=repo/'packages/stridetorch/benchmarks/README.md';s=p.read_text()+'''\n## Instance normalization (0.47)\n\n`bench_instance_norm.py` checks direct InstanceNorm against an existing BatchNorm\ncomposition before timing 26 forward/reverse/JVP and convolution/SGD flows.\n`run(samples=5, calls=12, reverse_order=False)` also works when mounted in a\nPyodide Worker. The formal record retains four fresh children per CPU/Node/Chrome\nruntime, every sample and exact source hashes. This is a same-source composition\ncomparison, since 0.46 did not expose InstanceNorm. See the\n[0.47 validation record](../../../docs/validation/torch-runtime-iteration-47.md).\n''';p.write_text(s)
print('WROTE47 report/roadmap/benchmark documentation')
