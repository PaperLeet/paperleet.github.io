from pathlib import Path
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-46'
s=(old/'close-local.py').read_text().replace('0.46.0','0.47.0').replace('iteration-46','iteration-47').replace('stride046','stride047')
s=s.replace('len(actual)==51','len(actual)==52').replace('len(tests)==43','len(tests)==44').replace('len(contracts[\'suites\'])==43','len(contracts[\'suites\'])==44').replace('==4902','==5085').replace("==38530","==38713").replace("'4915 passed'","'5098 passed'").replace("'925 passed'","'182 passed'")
start=s.index("numeric=read('native-differential-receipt.json')")
end=s.index("native=read('integration-proof/native-ci.json')",start)
s=s[:start]+'''numeric=read('native-differential-receipt.json');assert numeric['status']=='success' and numeric['numeric_cases']==54 and numeric['semantic_cases']==64 and numeric['array_state_checks']==2142 and numeric['source_hashes']==actual
performance=read('performance-summary.json');assert performance['status']=='success' and performance['children']==12 and performance['all_children_terminal'] and all(v['exit_code']==0 for v in performance['receipts'].values())
baseline=read('baseline.json');assert len(baseline['source'])==51
assert (r/'bench_instance_norm.py').read_bytes()==(repo/'packages/stridetorch/benchmarks/bench_instance_norm.py').read_bytes()
for runtime in ('cpu','node','chrome'):
 for repeat in range(4):
  row=read(f'performance/{runtime}-{repeat}.json');assert row['status']=='success' and len(row['flows'])==26 and row['source_hashes']==actual and row['library']=='0.47.0'
  assert row['benchmark_sha256']==sha(r/'bench_instance_norm.py')
''' +s[end:]
s=s.replace("==10229","==10387")
s=s.replace("changed=={'__init__.py','_average_pooling3d.py'} and set(actual)==set(baseline['source'])", "changed=={'__init__.py','_api.py','_batchnorm.py'} and set(actual)-set(baseline['source'])=={'_instancenorm.py'}")
s=s.replace('unchanged_resources=49','unchanged_resources=48').replace('added_resources=[]',"added_resources=['_instancenorm.py']").replace('focused_pooling3d=925','focused_instance_norm=182')
s=s.replace("'candidate-source'}","'candidate-source','prototype-proof'}")
s=s.replace("print('PASS0.46 exact local proof:51resources,4902Node/Chrome,38530CPU,4915minimum,3715native arrays,78/342catalog,46flowsx12children',flush=True)","print('PASS0.47 exact local proof:52resources,5085Node/Chrome,38713CPU,5098minimum,118native cases,78/342catalog,26flowsx12children',flush=True)")
(r/'close-local.py').write_text(s)
