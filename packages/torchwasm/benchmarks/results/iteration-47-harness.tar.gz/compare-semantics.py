import json,os
import numpy as np
if os.environ.get('STRIDE_PROBE'):
 from stridetorch import torch
else:import torch
out=[]
for training in [False,True]:
 for layout in ['C','F','strided']:
  for changed in ['input','weight','bias','mean','variance','output']:
   raw=np.arange(24,dtype=np.float64).reshape(2,3,4)/7
   if layout=='F':raw=np.asfortranarray(raw)
   if layout=='strided':raw=np.repeat(raw,2,axis=-1)[...,::2]
   x=torch.from_numpy(raw).requires_grad_();w=torch.tensor([.7,1.2,-.4],dtype=torch.float64,requires_grad=True);b=torch.tensor([.2,.4,-.3],dtype=torch.float64,requires_grad=True)
   rm=torch.tensor([.1,.3,-.2],dtype=torch.float64);rv=torch.tensor([.4,1.2,.7],dtype=torch.float64)
   y=torch.nn.functional.instance_norm(x,rm,rv,w,b,training)
   target={'input':x,'weight':w,'bias':b,'mean':rm,'variance':rv,'output':y}[changed]
   target.detach().add_(1)
   try:
    y.backward(torch.tensor(np.sin(np.arange(24)).reshape(2,3,4)))
    value=[z.grad.detach().numpy().tolist() for z in (x,w,b)]
   except RuntimeError:value='RuntimeError'
   out.append({'id':f'mutation:{training}:{layout}:{changed}','result':value})
for shape in [(0,3,4),(0,3,0),(2,3,0),(2,0,4)]:
 for training in [False,True]:
  for partial in ['both','mean','variance']:
   rm=torch.zeros(shape[1],dtype=torch.float64) if partial!='variance' else None
   rv=torch.ones(shape[1],dtype=torch.float64) if partial!='mean' else None
   x=torch.empty(shape,dtype=torch.float64,requires_grad=True)
   try:
    y=torch.nn.functional.instance_norm(x,rm,rv,use_input_stats=training);y.sum().backward()
    result={'shape':list(y.shape),'state':[None if v is None else v.numpy().tolist() for v in (rm,rv)],'versions':[None if v is None else v._version for v in (rm,rv)],'gradshape':list(x.grad.shape)}
   except RuntimeError:result='RuntimeError'
   out.append({'id':f'empty:{shape}:{training}:{partial}','result':result})
for eps in [0.,-1.,float('nan'),float('inf')]:
 x=torch.ones(2,3,4,dtype=torch.float64,requires_grad=True)
 with np.errstate(all='ignore'):
  y=torch.nn.functional.instance_norm(x,eps=eps);y.sum().backward()
 out.append({'id':f'eps:{eps}','result':[y.numpy().tolist() if os.environ.get('STRIDE_PROBE') else y.detach().numpy().tolist(),x.grad.numpy().tolist()]})
print(json.dumps(out,allow_nan=True))
