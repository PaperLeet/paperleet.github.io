from pathlib import Path
import hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
assert not (r/'qualification-0.83-harness.tar.gz').exists()
current=read(b/'torch-iteration-518/result.json');assert current['status']=='passed_current_083_frontend_followup'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert current['head']==head
cpu=read(b/'torch-iteration-501/result.json');assert cpu['totals']==dict(tests=45943,failures=0,errors=0,skipped=1) and cpu['exit_code']==0
minimum=read(b/'torch-iteration-503/result.json');assert minimum['installed_minimum_totals']==dict(tests=12308,failures=0,errors=0,skipped=3)
node=read(b/'torch-iteration-504/result.json');chrome=read(b/'torch-iteration-505/result.json');assert node['passed']==chrome['report']['passed']==12295 and not node['failures'] and not chrome['report']['failures']
assert node['source_version']==chrome['report']['source_version']=='0.83.0'
application=read(b/'torch-iteration-511/result.json');assert application['status']=='passed_local_application_catalog_export_frontend_worker_gates' and application['version']=='0.83.0'
metadata=read(b/'torch-iteration-516/result.json');assert metadata['root_package_test_totals']==dict(tests=12,failures=0,errors=0,skipped=0)
package=read(b/'torch-iteration-515/result.json');assert package['resources']==66 and len(package['artifacts'])==6
resources=read(b/'torch-iteration-511/source-hashes.json');assert len(resources)==66
for n,h in resources.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/n)==h,n
for n,h in read(b/'torch-iteration-515/source-plan.json')['inputs'].items():assert sha(Path(n))==h,n
for n,h in read(b/'torch-iteration-518/execution-plan.json')['static_inputs'].items():assert sha(repo/n)==h,n
for p in (b/'torch-iteration-491/candidate/stridetorch').iterdir():
 if p.is_file():
  q=repo/'packages/stridetorch/src/stridetorch'/p.name
  if p.name=='__init__.py':assert p.read_text().replace("__version__ = '0.82.0'","__version__ = '0.83.0'")==q.read_text()
  else:assert sha(p)==sha(q),p.name
exports=read(b/'torch-iteration-511/live-export-sha256.json');assert len(exports)==183
for n,h in exports.items():assert sha(repo/'web/public/data'/n)==h,n
for n,h in read(b/'torch-iteration-511/immutable-assets.json').items():assert sha(repo/n)==h,n
identity=read(b/'torch-iteration-511/export-identity.json');assert identity['preserved_assets']==16407 and identity['new_assets']==180 and identity['all_new_assets_reachable']
native=read(b/'torch-iteration-511/native-catalog-result.json');wasm=read(b/'torch-iteration-511/full-wasm-result.json');assert native['passed'] and native['problems']==89 and native['repeats']==3 and native['tests_executed']==12360
assert wasm['passed'] and wasm['modules']==89 and not wasm['browser_budget_exceeded'] and sum(v['mutants'] for v in wasm['results'])==406
worker=read(b/'torch-iteration-518/nested-wasm-result.json');assert worker['status']=='passed' and worker['verified_runtime_resources']==62 and not worker['page_errors'] and worker['feedback']=='Tests passed\n7 / 7 tests passed'
performance=read(b/'torch-iteration-494/result.json');assert performance['status']=='qualified_preplanned_owned_flow_latency_and_allocation_gates' and not performance['issues']
all_receipts=application['receipts']+current['receipts'];assert all(v['exit_code']==0 for v in all_receipts)
summary=dict(status='qualified_083_runtime_packages_current_application_and_scoped_frontend_followup',version='0.83.0',qualified_application_head=head,base_application_head=application['head'],cpu_qualified_head=cpu['head'],runtime_resources=resources,cpu=dict(passed=45942,failures=0,errors=0,existing_optional_skips=cpu['skips']),sdk=dict(native_numpy25_passed=12308,installed_numpy126_passed=12305,installed_numpy126_existing_skips=3,node_wasm_passed=12295,chrome_wasm_passed=12295,wasm_failed=0,wasm_skipped=0,pyodide='0.29.4',numpy_wasm='2.2.5',final_version='0.83.0',public_sdist_sdk_files=93),independent_clipping_oracle_cases=478,owned_flow_qualification=dict(result='operand-lifetime-owned-flow.json',result_sha256=sha(repo/'packages/stridetorch/benchmarks/results/operand-lifetime-owned-flow.json'),qualification_status=performance['status'],latency_processes=12,aggregate_contexts=96,all_aggregate_gates_passed=True,individual_flagged_contexts=performance['individual_process_flags'],maximum_aggregate_cpu_cost=0.0791218350563991,representative_allocation_reduction_about=.83,metric='verifiedNumPy/Pythontracedallocationpeaks;notRSS',performance_source_equivalent_except_package_version_literal=True),package=dict(artifacts=package['artifacts'],resources=66,public_readme_exact=True,apache2=True,numpy_sole_runtime_dependency=True,coinstall_both_numpy_environments=True,private_application_bytes_verified=True),post_application_metadata_delta=metadata['metadata_delta'],catalog=dict(modules=89,native_repeats=3,native_test_records=12360,wasm_modules=89,wasm_mutants=406,browser_budget_exceeded=[]),exports=dict(active_identities=183,new_assets=180,preserved_immutable_assets=16407,all_new_assets_reachable=True,hashes=exports),completed_application_receipts=all_receipts,late_frontend_merge=read(b/'torch-iteration-518/merge-receipt.json'),cpu_source_equivalence=read(b/'torch-iteration-511/cpu-source-equivalence.json'),actual_generated_worker=dict(status=worker['status'],browser=worker['browser'],feedback=worker['feedback'],verified_runtime_resources=62,lifetime_probe_executed=True,page_errors=worker['page_errors'],result_sha256=sha(b/'torch-iteration-518/nested-wasm-result.json')),known_precision_boundary='Sixexistingmixedfloat64-scalar/float32-nonlinearcotangentcontextsfrom479remainflagged;binarypullbacksmatchwithidenticalnativecotangents;nofullTorchparityclaim',terminal_hvp_optimization_adopted=False,parent_shape_reuse_prototype_512_adopted=False,production_webgpu_enabled=False,main_adopted=False,ci_triggered=False,tags_pushed=False,published=False,deployed=False,goal_status='active')
write(r/'qualification.json',summary)
files=[]
for stage in [498,501,502,503,504,505,506,508,510,511,514,515,516,518]:
 folder=b/f'torch-iteration-{stage}';files.extend(p for p in folder.iterdir() if p.is_file())
 if stage==511:files.extend(p for p in (folder/'native-references').rglob('*') if p.is_file())
 if stage in [502,515]:
  for item in read(folder/'result.json')['artifacts']:
   p=folder/item['path'];assert sha(p)==item['sha256'];files.append(p)
 if stage==504:files.extend(p for sub in ['candidate','contracts','oracle'] for p in (folder/sub).rglob('*') if p.is_file())
for folder,target in [(repo/'packages/stridetorch/src/stridetorch',r/'canonical/stridetorch'),(repo/'packages/stridetorch/tests',r/'contracts')]:
 target.mkdir(parents=True)
 for p in folder.iterdir():
  if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']:shutil.copy2(p,target/p.name);files.append(target/p.name)
for name in ['README.md','pyproject.toml','ROADMAP.md','LICENSE','NOTICE']:
 p=repo/'packages/stridetorch'/name;q=r/name;shutil.copy2(p,q);files.append(q)
for n in exports:
 q=r/'exports'/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/'web/public/data'/n,q);files.append(q)
proof=read(b/'torch-iteration-518/generated-worker-proof.json')
for n in [proof['generated_module'],proof['asset']]:
 q=r/'generated'/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/n,q);files.append(q)
write(r/'replay-dependencies.json',dict(external=['QualifiedGitheadsforfullapplication,problemdefinitionsandfrontend;staticinputhashesretained','owned-flow-harnessarchivecontainsfrozenperformancebaseline/candidateandall12measurements','Python3.12NumPy2.5.4Torch2.14.1;Python3.10NumPy1.26.4Torch2.6','Node22.22.1Chrome155Playwright','Pyodide0.29.4Python3.13.2NumPy2.2.5andpytestclosure76;fixture70notbundled'],notes=['Adaptabsolutepathstoreplay','All93SDKsourcesand66runtimefiles,currentmetadataandsixartifactsareincluded','Standalone508backupisincludedandrecoverstheoriginalgeneratedCPUtesttree;runtimeenvironmentsunchanged','Originalper-processNodeAA/regressionflagisretainedinowned-flowevidence;predefinedaggregatequalificationisexplicit','Alloldimmutablepublicassetsremaininplace;current183derivedexportsincluded;noCI/tag/deploy']))
files.extend([r/'aggregate.py',r/'qualification.json',r/'replay-dependencies.json']);files=sorted(set(files));assert all('__pycache__' not in p.parts for p in files)
manifest={str(p.relative_to(b)):sha(p) for p in files};seen={};target=r/'qualification-0.83-harness.tar.gz'
with tarfile.open(target,'w:gz') as archive:
 for p in files:
  name=str(p.relative_to(b));h=manifest[name]
  if h in seen:
   info=archive.gettarinfo(str(p),arcname=name);info.type=tarfile.LNKTYPE;info.linkname=seen[h];info.size=0;archive.addfile(info)
  else:archive.add(p,arcname=name,recursive=False);seen[h]=name
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256.json');info.size=len(data);archive.addfile(info,io.BytesIO(data))
with tarfile.open(target) as archive:
 for n,h in manifest.items():assert hashlib.sha256(archive.extractfile(n).read()).hexdigest()==h,n
receipt=dict(path='packages/stridetorch/benchmarks/results/'+target.name,files=len(files),unique_payloads=len(seen),bytes=target.stat().st_size,sha256=sha(target),all_payloads_verified=True);write(r/'archive-receipt.json',receipt);summary['raw_archive']=receipt
write(repo/'packages/stridetorch/benchmarks/results/qualification-0.83.json',summary);shutil.copy2(target,repo/receipt['path']);print(json.dumps(receipt))
