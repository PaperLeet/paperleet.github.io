from pathlib import Path
import hashlib,json,os,subprocess,time,traceback,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n');plan=read(r/'plan.json');receipts=[]
try:
 assert not (r/'progress.json').exists();write(r/'progress.json',dict(status='waiting_for_canonical_application_cpu',supervisor_pid=os.getpid(),receipts=[]))
 while True:
  p=b/'torch-iteration-501/progress.json';status=read(p);assert status['status']!='failed','CanonicalCPUsupervisorfailed;inspectoriginalresultbeforecontinuing'
  if status['status']=='completed':assert read(b/'torch-iteration-501/result.json')['status']=='passed_full_application_cpu';break
  time.sleep(5)
 for n,h in plan['inputs'].items():assert sha(Path(n))==h,n
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');env.pop('PYTHONPATH',None)
 command=[str(b/'torch-iteration-82/application-env/bin/python'),'-B',str(b/'torch-iteration-502/run.py')]
 with (r/'packaging.log').open('w') as log:
  child=subprocess.Popen(command,env=env,cwd=repo,stdout=log,stderr=subprocess.STDOUT);write(r/'progress.json',dict(status='running',label='six-artifacts-and-installed-smoke',pid=child.pid,supervisor_pid=os.getpid(),receipts=receipts));code=child.wait()
 receipts.append(dict(label='packaging',exit_code=code,log_sha256=sha(r/'packaging.log')));assert code==0
 public=b/'torch-iteration-502/public';rebuilt=next((b/'torch-iteration-502/public-sdist').iterdir());tests=rebuilt/'tests';original={p.name:sha(p) for p in (public/'tests').glob('*.py')};assert len(original)==93
 assert {p.name:sha(p) for p in tests.glob('*.py')}==original
 write(r/'sdist-test-identity.json',dict(status='verified_all93SDKfiles_in_actual_public_sdist',files=original))
 prefix=b/'torch-iteration-502/installed';python=b/'torch-iteration-137/native26-env/bin/python';env['PYTHONPATH']=str(prefix);env['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1';env['PYTHONHASHSEED']='0'
 smoke="from pathlib import Path;import stridetorch;assert stridetorch.__version__=='0.83.0';assert Path(stridetorch.__file__).resolve().is_relative_to(Path(__import__('sys').argv[1]).resolve());print(stridetorch.__file__)"
 subprocess.run([str(python),'-B','-c',smoke,str(prefix)],env=env,cwd=r,check=True)
 command=[str(python),'-B','-m','pytest',str(tests),'-q','-p','no:cacheprovider','--junitxml='+str(r/'installed-minimum-sdk.xml')]
 with (r/'installed-minimum-sdk.log').open('w') as log:
  child=subprocess.Popen(command,env=env,cwd=r,stdout=log,stderr=subprocess.STDOUT);write(r/'progress.json',dict(status='running',label='installed-minimum-sdk',pid=child.pid,supervisor_pid=os.getpid(),receipts=receipts));code=child.wait()
 suites=list(ET.parse(r/'installed-minimum-sdk.xml').getroot().iter('testsuite'));totals={k:sum(int(s.attrib.get(k,0)) for s in suites) for k in ['tests','failures','errors','skipped']};assert code==0 and totals==dict(tests=12308,failures=0,errors=0,skipped=3),(code,totals)
 receipts.append(dict(label='installed-minimum-sdk',exit_code=code,totals=totals,log_sha256=sha(r/'installed-minimum-sdk.log')))
 for n,h in plan['inputs'].items():assert sha(Path(n))==h,n
 write(r/'result.json',dict(status='passed_final083_packages_sdist_tests_and_installed_minimum_sdk',version='0.83.0',public_sdist_sdk_files=93,installed_minimum_totals=totals,packaging_result_sha256=sha(b/'torch-iteration-502/result.json'),receipts=receipts,ci_triggered=False,published=False,goal_status='active'));write(r/'progress.json',dict(status='completed',receipts=receipts))
except BaseException as error:write(r/'progress.json',dict(status='failed',error=str(error),traceback=traceback.format_exc(),receipts=receipts));raise
