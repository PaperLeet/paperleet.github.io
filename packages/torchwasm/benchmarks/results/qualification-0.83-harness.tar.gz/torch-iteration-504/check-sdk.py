import hashlib
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import runpy
sys.path.insert(0, '/oracle')
sys.argv=['/oracle/check.py','--source','/candidate/stridetorch','--oracle','/oracle/native26.json','--output','/oracle-result.json']
runpy.run_path('/oracle/check.py',run_name='__main__')
oracle=json.load(open('/oracle-result.json'))
assert oracle['status']=='passed' and oracle['cases']==478 and not oracle['version_differences']
sys.path.insert(0, '/candidate')
import pytest
import numpy as np
import stridetorch
assert sys.platform == 'emscripten'
assert stridetorch.__file__ == '/candidate/stridetorch/__init__.py'
assert stridetorch.__version__ == '0.83.0'

class Record:
    def __init__(self):
        self.passed = 0
        self.skipped = 0
        self.failed = []
    def pytest_runtest_logreport(self, report):
        if report.when == 'call' and report.passed:
            self.passed += 1
            if self.passed % 1000 == 0:
                print('SDK_PROGRESS '+str(self.passed), flush=True)
        if report.skipped:
            self.skipped += 1
        if report.failed:
            self.failed.append(dict(nodeid=report.nodeid, phase=report.when, error=str(report.longrepr)))

record=Record()
status=pytest.main(['/contracts','-q','--noconftest','-p','no:cacheprovider','--import-mode=importlib'],plugins=[record])
report=dict(exit_code=int(status),passed=record.passed,skipped=record.skipped,failures=record.failed,
            expected_passed=12295,source_version=stridetorch.__version__,numpy=np.__version__,
            status='passed_full_node_wasm_sdk' if int(status)==0 and record.passed==12295 and record.skipped==0 else 'failed')

report['gradient_oracle']=dict(status=oracle['status'],cases=oracle['cases'],mismatches=len(oracle['mismatches']),version_differences=len(oracle['version_differences']))
