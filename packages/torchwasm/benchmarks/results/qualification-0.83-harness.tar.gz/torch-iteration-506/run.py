from pathlib import Path
import hashlib,json,os,subprocess,time,traceback
r=Path(__file__).resolve().parent;b=r.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n');receipts=[];node='/Users/david/.local/share/fnm/node-versions/v22.22.1/installation/bin/node'
try:
 assert not (r/'plan.json').exists();write(r/'plan.json',dict(runner_sha256=sha(Path(__file__)),node_plan_sha256=sha(b/'torch-iteration-504/source-plan.json'),chrome_plan_sha256=sha(b/'torch-iteration-505/source-plan.json'),scope='AftercanonicalCPU/packages/minimumSDK;final0.83actualNodeandChromeSDK12295cases',ci_triggered=False))
 write(r/'progress.json',dict(status='waiting_for_final_packages_and_minimum_sdk',supervisor_pid=os.getpid(),receipts=[]))
 while True:
  status=read(b/'torch-iteration-503/progress.json');assert status['status']!='failed','Package/minimumSDKgatefailed;hold'
  if status['status']=='completed':break
  time.sleep(5)
 for stage,label in [(504,'node'),(505,'chrome')]:
  with (r/(label+'.log')).open('w') as log:
   child=subprocess.Popen([node,str(b/f'torch-iteration-{stage}/run.mjs')],cwd=r,stdout=log,stderr=subprocess.STDOUT);write(r/'progress.json',dict(status='running',label=label,pid=child.pid,supervisor_pid=os.getpid(),receipts=receipts));code=child.wait()
  receipts.append(dict(label=label,exit_code=code,log_sha256=sha(r/(label+'.log'))));write(r/'receipts.json',receipts);print(json.dumps(receipts[-1]),flush=True);assert code==0
 write(r/'result.json',dict(status='passed_final083_full_node_and_chrome_sdk',node_result_sha256=sha(b/'torch-iteration-504/result.json'),chrome_result_sha256=sha(b/'torch-iteration-505/result.json'),passed_per_runtime=12295,ci_triggered=False,goal_status='active'));write(r/'progress.json',dict(status='completed',receipts=receipts))
except BaseException as error:write(r/'progress.json',dict(status='failed',error=str(error),traceback=traceback.format_exc(),receipts=receipts));raise
