"""Refresh public release metadata only after current application checks finish."""
from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
plan=read(r/'plan.json');assert not (r/'result.json').exists();assert sha(Path(__file__))==plan['runner_sha256']
application=read(b/'torch-iteration-511/result.json');assert application['status']=='passed_local_application_catalog_export_frontend_worker_gates'
assert application['version']=='0.83.0' and application['resources']==66
for name,h in application['source_hashes'].items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==h,name
for name,h in read(b/'torch-iteration-511/live-export-sha256.json').items():assert sha(repo/'web/public/data'/name)==h,name
p=repo/'packages/stridetorch/README.md';assert sha(p)==plan['readme_before_sha256'];text=p.read_text()
old="""Version **0.83** is a development candidate that releases unused operand arrays
from ordinary multiplication and direct-division pullbacks. Gradient arithmetic,
saved-value guards and higher-order rules retain their qualified 0.82 behavior.
The [development record](../../docs/validation/torch-runtime-0.83-development.md)
separates measured allocation/timing scope from application integration, which
remains pending. Production WebGPU remains disabled.
"""
new="""Version **0.83** releases unused operand arrays from ordinary multiplication
and direct-division pullbacks. A measured large scalar chain reduces traced
peak allocation by about 83%; the scoped latency costs are retained in the
[qualification record](../../docs/validation/torch-runtime-0.83-qualification.md).
Gradient arithmetic, saved-value guards and higher-order rules retain their
qualified 0.82 behavior. CPU/Pyodide package and current PaperLeet application
checks pass locally. Production WebGPU remains disabled.
"""
assert text.count(old)==1;p.write_text(text.replace(old,new))
p=repo/'docs/validation/torch-runtime-0.83-development.md';text=p.read_text();needle='# Torch runtime 0.83 development candidate\n';assert text.startswith(needle)
p.write_text(text.replace(needle,needle+'\nThis is the historical development-stage record. The subsequent\n[0.83 qualification](torch-runtime-0.83-qualification.md) resolves its pending\nSDK/package/application gates while preserving the original measurements.\n',1))
# Both prior qualification inputs may differ only in the public README.
for stage,filename in [(501,'plan.json'),(502,'source-plan.json')]:
 before=read(b/f'torch-iteration-{stage}'/filename)['inputs'];different=[]
 for name,h in before.items():
  path=Path(name) if Path(name).is_absolute() else repo/name
  if sha(path)!=h:different.append(str(path.relative_to(repo)))
 assert different==['packages/stridetorch/README.md'],(stage,different)
write(r/'result.json',dict(status='updated_readme_after_application_qualification_new_package_metadata_required',version='0.83.0',qualified_application_head=application['head'],readme_before_sha256=plan['readme_before_sha256'],readme_after_sha256=sha(repo/'packages/stridetorch/README.md'),only_changed_existing_qualification_input='packages/stridetorch/README.md',runtime_resources_unchanged=66,active_exports_unchanged=183,needs_fresh_package_artifacts=True,main_adopted=False,ci_triggered=False,published=False));print(json.dumps(read(r/'result.json')))
