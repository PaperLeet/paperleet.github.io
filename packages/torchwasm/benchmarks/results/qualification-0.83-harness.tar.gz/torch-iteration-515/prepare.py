from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
assert read(b/'torch-iteration-511/result.json')['status']=='passed_local_application_catalog_export_frontend_worker_gates'
assert read(b/'torch-iteration-514/result.json')['needs_fresh_package_artifacts']
old=read(b/'torch-iteration-502/source-plan.json');different=[str(Path(n).relative_to(repo)) for n,h in old['inputs'].items() if sha(Path(n))!=h];assert different==['packages/stridetorch/README.md'],different
inputs={}
for name in old['staged']:
 source=repo/'packages/stridetorch'/name[len('public/'):] if name.startswith('public/') else repo/name[len('private/'):]
 target=r/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target);inputs[str(source)]=sha(source)
expected=read(b/'torch-iteration-511/source-hashes.json')
for n,h in expected.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/n)==h,n
plan=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),expected=expected,inputs=inputs,staged={str(p.relative_to(r)):sha(p) for folder in ['public','private'] for p in (r/folder).rglob('*') if p.is_file()},private_source_files=old['private_source_files'],version='0.83.0',scope='PostapplicationpublicREADMEmetadatarefreshonly;runtime66andSDK93bytesunchanged;freshsixartifactsandcoinstallsmokebothNumPys',prior_package_source_plan_sha256=sha(b/'torch-iteration-502/source-plan.json'),only_existing_input_delta=different)
write(r/'source-plan.json',plan);(r/'run.py').write_bytes((b/'torch-iteration-502/run.py').read_bytes());write(r/'execution-plan.json',dict(runner_sha256=sha(r/'run.py'),source_plan_sha256=sha(r/'source-plan.json')))
print(json.dumps(dict(status='prepared_metadata_refresh',resources=66,sdk_files=93)))
