from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
assert read(b/'torch-iteration-506/result.json')['status']=='passed_final083_full_node_and_chrome_sdk'
merge=read(b/'torch-iteration-510/merge-receipt.json');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head==merge['head']
for n,h in read(b/'torch-iteration-501/plan.json')['inputs'].items():assert sha(repo/n)==h,n
for n,h in read(b/'torch-iteration-502/source-plan.json')['inputs'].items():assert sha(Path(n))==h,n
write(r/'cpu-source-equivalence.json',dict(status='qualified_computation_and_existing_application_sources_unchanged',cpu_head=merge['cpu_qualified_head'],merged_head=head,unchanged_cpu_inputs=merge['unchanged_cpu_inputs'],unchanged_package_inputs=merge['unchanged_package_inputs'],upstream_changes=merge['upstream_source_files'],no_old_tests_removed=True,no_backend_or_problem_changes=True))
s=(b/'torch-iteration-462/run.py').read_text().replace('0.82.0','0.83.0').replace('45933','45943').replace("application=b/'torch-iteration-460'","application=b/'torch-iteration-501'").replace("b/'torch-iteration-457/receipt.json'","b/'torch-iteration-508/receipt.json'").replace("b/'torch-iteration-463/result.json'","b/'torch-iteration-502/result.json'").replace("['head']==context['head']","['head']==context['cpu_head']")
line=" run('merged-app-imports',[python,'-B','-m','pytest','tests/test_lightweight_torch.py','tests/test_torch_gradient_utilities.py','-q','-p','no:cacheprovider','--basetemp='+str(r/'merged-app-tmp'),'--junitxml='+str(r/'merged-app.xml')])\n";assert line in s;s=s.replace(line," assert read(b/'torch-iteration-506/result.json')['passed_per_runtime']==12295\n")
s=s.replace("run('custom-cases-wasm',[node,'web/scripts/check-custom-cases-wasm.mjs'])","run('custom-cases-wasm',[node,'scripts/check-custom-cases-wasm.mjs'],repo/'web')")
(r/'run.py').write_text(s)
(r/'verify-export.py').write_text((b/'torch-iteration-462/verify-export.py').read_text().replace('0.82.0','0.83.0'))
(r/'verify-generated-worker.mjs').write_bytes((b/'torch-iteration-470/verify-generated-worker.mjs').read_bytes())
s=(b/'torch-iteration-470/check-nested-wasm.mjs').read_text().replace('0.82.0','0.83.0').replace('v082','v083').replace('_pl82','_pl83').replace("../torch-iteration-462/source-hashes.json","./source-hashes.json")
needle="const source=original+'\\n'+probe+'\\n'+packedProbe+'\\n'+clippingProbe+'\\n# '+completionMarker+'\\n';"
extra="""const lifetimeProbe=`
import gc as _pl83_gc, weakref as _pl83_weakref
for _pl83_kind in ['scalar_chain', 'tensor_left', 'tensor_right', 'divide_left']:
    _pl83_x = torch.tensor([[1.], [2.], [3.]], dtype=torch.float64, requires_grad=True)
    _pl83_g = _pl83_x + .25
    _pl83_reference = _pl83_weakref.ref(_pl83_g._data)
    _pl83_c = torch.tensor([[2., 4.]], dtype=torch.float64)
    if _pl83_kind == 'scalar_chain':
        _pl83_value = _pl83_g
        for _pl83_factor in [2., .5] * 8:
            _pl83_value = _pl83_value * _pl83_factor
        _pl83_expected = [[1.], [1.], [1.]]
    elif _pl83_kind == 'tensor_left':
        _pl83_value = _pl83_g * _pl83_c
        _pl83_expected = [[6.], [6.], [6.]]
    elif _pl83_kind == 'tensor_right':
        _pl83_value = _pl83_c * _pl83_g
        _pl83_expected = [[6.], [6.], [6.]]
    else:
        _pl83_value = _pl83_g / _pl83_c
        _pl83_expected = [[.75], [.75], [.75]]
    _pl83_loss = _pl83_value.sum()
    del _pl83_g, _pl83_value
    _pl83_gc.collect()
    assert _pl83_reference() is None
    _pl83_gradient, = torch.autograd.grad(_pl83_loss, _pl83_x)
    assert _pl83_gradient.tolist() == _pl83_expected and _pl83_x.grad is None
`;
const source=original+'\\n'+probe+'\\n'+packedProbe+'\\n'+clippingProbe+'\\n'+lifetimeProbe+'\\n# '+completionMarker+'\\n';"""
assert needle in s;s=s.replace(needle,extra).replace("clipping_probe_source:clippingProbe,", "clipping_probe_source:clippingProbe,lifetime_probe_source:lifetimeProbe,");(r/'check-nested-wasm.mjs').write_text(s)
paths=subprocess.check_output(['git','ls-files','paperleet','tests','problems','packages/stridetorch/src','packages/stridetorch/tests','packages/stridetorch/README.md','packages/stridetorch/pyproject.toml','pyproject.toml','web/src','web/scripts','web/package.json','web/package-lock.json','web/tsconfig.json','web/vite.config.ts','.github/workflows'],cwd=repo,text=True).splitlines();write(r/'static-inputs.json',{n:sha(repo/n) for n in paths if (repo/n).is_file()})
assets={str(p.relative_to(repo)):sha(p) for folder in ['web/public/data/browser-judge','web/public/data/modules'] for p in (repo/folder).glob('*.json')};write(r/'immutable-assets.json',assets)
resources={p.name:sha(p) for p in (repo/'packages/stridetorch/src/stridetorch').iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']};assert len(resources)==66;write(r/'source-hashes.json',resources)
write(r/'context.json',dict(head=head,cpu_head=merge['cpu_qualified_head'],catalog_modules=89,version='0.83.0',merged_upstream=merge['merged_upstream']))
write(r/'prerequisites.json',dict(cpu_plan_sha256=sha(b/'torch-iteration-501/plan.json'),package_result_sha256=sha(b/'torch-iteration-502/result.json'),installed_minimum_sdk_sha256=sha(b/'torch-iteration-503/result.json'),full_wasm_sdk_sha256=sha(b/'torch-iteration-506/result.json'),performance_qualification_sha256=sha(b/'torch-iteration-494/result.json')))
write(r/'execution-plan.json',dict(files={p.name:sha(p) for p in r.iterdir() if p.is_file() and p.name!='execution-plan.json'},scope='Currentmerged0.83nativecatalog3repeats/export/all89WASM/fullfrontend/bothbuilds/generatedWorker/actualnested62-resourceandlifetimeprobe;all1655CPUand206packageinputbytesunchangedafterfrontend-onlymerge;noCIorpublication'))
print(json.dumps(dict(status='prepared',head=head,resources=66,preserved_assets=len(assets))))
