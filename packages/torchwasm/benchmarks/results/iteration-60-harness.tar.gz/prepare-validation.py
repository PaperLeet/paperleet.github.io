from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-59';repo=Path('/Users/david/Developer/PaperLeet-torch-release');p=r/'proof';c=p/'chrome-contracts';i=r/'integration-proof';c.mkdir(parents=True,exist_ok=True);i.mkdir(exist_ok=True)
root_scripts=['run-full.py','run-gates.py','fixture-server.mjs','prepare-oracle.py','prepare-bench.py','run-bench-final.py','summarize-performance.py','run-front-only.py','run-full-wasm-only.py','check-distance-aliases.py','check-native-isolation.py','fresh-load.py','audit-main.py','push-main-node.py','push-via-node.mjs','record-adoption.py','verify-adoption.py']
files=[old/n for n in root_scripts]+[f for f in (old/'proof').iterdir() if f.suffix in ['.py','.mjs']]+[old/'proof/chrome-contracts'/n for n in ['run.mjs','worker.mjs','index.html']]+[old/'integration-proof'/n for n in ['run-frontend.py','run-export.py','verify-export.py']]
for f in files:
 dest=r/f.relative_to(old);s=f.read_text().replace('torch-iteration-59','torch-iteration-60').replace('0.59.0','0.60.0').replace('stride059','stride060').replace('7215','7251').replace('7228','7264').replace('40845','40881').replace('==62','==78').replace('flows=62','flows=78').replace('62 matched rows against 0.58','78 matched rows against 0.59')
 if f.name=='verify-export.py':s=s.replace('12283','12441')
 if f.name in ['record-adoption.py','verify-adoption.py']:
  s=s.replace('iteration-59-main-adoption','iteration-60-main-adoption').replace('torch-runtime-iteration-59.md','torch-runtime-iteration-60.md').replace('12441','12599').replace('12,441','12,599').replace('1008 distance','1152 distance').replace('All 62 distance workflows','All 78 distance workflows').replace('compared with 0.58','compared with 0.59')
 dest.write_text(s)
source=repo/'packages/stridetorch/src/stridetorch';resources=[*source.glob('*.py'),source/'LICENSE',source/'NOTICE'];hashes=lambda fs:{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in fs};src=hashes(resources);assert len(src)==60
for dest in [p/'source',c/'source']:
 dest.mkdir(exist_ok=True)
 for f in resources:shutil.copy2(f,dest/f.name)
(p/'source-hashes.json').write_text(json.dumps(src,indent=2)+'\n')
tests=[f for f in (repo/'packages/stridetorch/tests').glob('test_*.py') if f.name!='test_standalone.py'];assert len(tests)==53;(c/'tests').mkdir(exist_ok=True)
for f in tests:shutil.copy2(f,c/'tests'/f.name)
(c/'plan.json').write_text(json.dumps(dict(source=src,tests=hashes(tests),version='0.60.0',expected=7251),indent=2)+'\n');(p/'test-hashes.json').write_text(json.dumps(hashes(tests),indent=2)+'\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();(i/'context.json').write_text(json.dumps(dict(upstream=head),indent=2)+'\n')
for n in ['release-policy-identity.json','native-catalog-reuse.json','native-empty-pdist-crash.json','native-empty-pdist-crash-repro.py','native-distances.log','native-distances-trace.log']:shutil.copy2(old/n,r/n)
for name,digest in json.loads((r/'release-policy-identity.json').read_text())['files'].items():
 raw=(repo/name).read_bytes();assert hashlib.sha256(raw).hexdigest()==digest;assert raw==subprocess.check_output(['git','show','13d2782a494415ba72bc604a0ef7e4c4f875ba25:'+name],cwd=repo)
reuse=json.loads((r/'native-catalog-reuse.json').read_text())
for name,digest in reuse['native_input_sha256'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
reuse['revalidated_for']='0.60.0';reuse['revalidation']='prepare-validation.py and close-local.py verify all 1152 native catalog input hashes.';(r/'native-catalog-reuse.json').write_text(json.dumps(reuse,indent=2)+'\n')
owned=subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines();assert len(owned)==6 and all(n.startswith('packages/stridetorch/') for n in owned);(r/'owned-source-paths.json').write_text(json.dumps(owned,indent=2)+'\n');(r/'owned-input-sha256.json').write_text(json.dumps({n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in owned},indent=2)+'\n')
qual=json.loads((r/'distances-qualification.json').read_text());assert qual['source_hashes']==src and qual['cases']==1152 and qual['status']=='qualified'
print(dict(source=len(src),suites=len(tests),owned=len(owned),head=head))
