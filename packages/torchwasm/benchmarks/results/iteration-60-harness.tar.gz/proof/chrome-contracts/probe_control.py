import importlib,inspect,json,statistics,time
from bench_distances import load,_data,_method

def run(baseline_source,candidate_source):
 old,oh=load('_control_baseline',baseline_source);new,nh=load('_control_candidate',candidate_source);old.torch;new.torch
 od=importlib.import_module('_control_baseline._distance');nd=importlib.import_module('_control_candidate._distance');identity={}
 for name in ['_small_cdist','_small_pdist','_direction','_unbroadcast','_order','_budget','_check']:
  identity[name]=inspect.getsource(getattr(od,name))==inspect.getsource(getattr(nd,name))
 identity['_run_small_prefix']=inspect.getsource(od._run).split('    sources=')[0]==inspect.getsource(nd._run).split('    sources=')[0];assert all(identity.values())
 rows=[]
 for kind,dtype,p,left,right,backward in [('cdist','float32',1.,(4,7),(5,7),True),('pdist','float32',2.,(5,7),(5,7),True),('cdist','float64',2.,(64,64),(80,64),False)]:
  a=_data(left,dtype,.2);b=_data(right,dtype,.7);functions={label:_method(m,a,b,p,kind,backward)[0] for label,m in [('baseline',old),('candidate',new)]};samples={k:[] for k in functions};calls=512
  for fn in functions.values():
   for _ in range(128):fn()
  for repeat in range(12):
   for label in (['baseline','candidate'] if repeat%2==0 else ['candidate','baseline']):
    start=time.perf_counter()
    for _ in range(calls):functions[label]()
    samples[label].append((time.perf_counter()-start)/calls)
  med={k:statistics.median(v) for k,v in samples.items()};rows.append(dict(factory=kind,dtype=dtype,p=p,left_shape=left,right_shape=right,mode='full_step' if backward else 'forward',samples_s=samples,median_s=med,candidate_over_baseline=med['candidate']/med['baseline']))
 return dict(versions=dict(baseline=old.__version__,candidate=new.__version__),source_hashes=dict(baseline=oh,candidate=nh),unchanged_source_paths=identity,rows=rows,scope='Targeted follow-up for noisy unchanged controls; 12 alternating paired batches of 512 calls in each fresh Node process. Supplemental evidence; original 78-row results and unfavorable samples remain unchanged.')
