from pathlib import Path
import json,sys,time,statistics,importlib
import numpy as np
repo=Path('/Users/david/Developer/PaperLeet-torch-release');r=Path(__file__).resolve().parent;sys.path.insert(0,str(repo/'packages/stridetorch/benchmarks'))
from bench_distances import load,_data,_method
old,_=load('_forward_old',r/'baseline-source/stridetorch');new,_=load('_forward_new',r/'prototype-source/stridetorch');new.torch;d=importlib.import_module('_forward_new._distance');norm=d._norm_chunk;finish=d._finish;original=d._pdist_forward

def packed(factor):
 def run(source,p,width):
  n,m=source.shape;dtype=source.dtype;count=n*(n-1)//2;out=np.zeros(count,dtype=dtype);chunk=max(1,d._WORKSPACE_BYTES//(factor*width*dtype.itemsize+64))
  for start in range(0,count,chunk):
   end=min(start+chunk,count);k=np.arange(start,end);i=((2*n-1-np.sqrt((2*n-1)**2-8*k))*.5).astype(np.intp);j=k-i*(2*n-i-1)//2+i+1;v=np.zeros(end-start,dtype=dtype)
   for f in range(0,m,width):
    span=slice(f,min(f+width,m));delta=source[i,span];np.subtract(delta,source[j,span],out=delta);part=norm(delta,p,triangular=True)
    if np.isinf(p):np.maximum(v,part,out=v)
    else:np.add(v,part,out=v)
    del delta,part
   out[start:end]=finish(v,p)
  return out
 return run

def hybrid(source,p,width):
 n,m=source.shape;out=np.zeros(n*(n-1)//2,dtype=source.dtype);plan=d._plan(1,n,n,m,source.dtype,True);side=plan[1]
 for start in range(0,n,side):
  end=min(start+side,n);i,j=np.triu_indices(end-start,1);i+=start;j+=start
  v=np.zeros(len(i),dtype=source.dtype)
  for f in range(0,m,width):
   span=slice(f,min(f+width,m));delta=source[i,span];np.subtract(delta,source[j,span],out=delta);part=norm(delta,p,triangular=True)
   if np.isinf(p):np.maximum(v,part,out=v)
   else:np.add(v,part,out=v)
   del delta,part
  index=i*(2*n-i-1)//2+j-i-1;out[index]=finish(v,p)
  for right in range(end,n,side):
   stop=min(right+side,n);v=np.zeros((end-start,stop-right),dtype=source.dtype)
   for f in range(0,m,width):
    span=slice(f,min(f+width,m));delta=source[start:end,None,span]-source[None,right:stop,span];part=norm(delta,p,triangular=True)
    if np.isinf(p):np.maximum(v,part,out=v)
    else:np.add(v,part,out=v)
    del delta,part
   ii=np.arange(start,end)[:,None];jj=np.arange(right,stop)[None,:];index=ii*(2*n-ii-1)//2+jj-ii-1;out[index]=finish(v,p)
 return out

rows=[]
for dtype in ['float32','float64']:
 for shape in [(128,128),(256,64),(64,512),(128,512)]:
  a=_data(shape,dtype,.2);old_call,old_capture,_=_method(old,a,a,2.,'pdist',False);expected=old_capture()[0]
  variants={'baseline':old_call}
  for name,fn in [('original',original),('packed2',packed(2)),('packed3',packed(3)),('packed4',packed(4)),('packed8',packed(8)),('hybrid',hybrid)]:
   d._pdist_forward=fn;call,capture,_=_method(new,a,a,2.,'pdist',False)
   # Bind the selected kernel to each measurement, preserving outer execution costs.
   def chosen(call=call,fn=fn):d._pdist_forward=fn;return call()
   np.testing.assert_allclose(chosen().numpy(),expected,rtol=3e-6,atol=3e-6);variants[name]=chosen
  timings={k:[] for k in variants};calls=64
  for repeat in range(5):
   names=list(variants);names=names if repeat%2==0 else names[::-1]
   for name in names:
    start=time.perf_counter()
    for _ in range(calls):variants[name]()
    timings[name].append((time.perf_counter()-start)/calls)
  med={k:statistics.median(v) for k,v in timings.items()};rows.append(dict(dtype=dtype,shape=shape,seconds=timings,ratios={k:med[k]/med['baseline'] for k in med}));print(dtype,shape,{k:round(v,3) for k,v in rows[-1]['ratios'].items()},flush=True)
(r/'forward-plan-cpu.json').write_text(json.dumps(dict(rows=rows,scope='Single-process prototype screen, five alternating batches of 64 forward calls; not formal final performance evidence.'),indent=2)+'\n')
