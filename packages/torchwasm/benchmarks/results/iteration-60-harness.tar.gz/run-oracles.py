from pathlib import Path
import os,json,subprocess,time
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');receipts=[];env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
for label,path in [('node-distance',r/'proof/oracle-node.mjs'),('chrome-distance',r/'proof/chrome-contracts/oracle-run.mjs')]:
 start=time.monotonic();args=['/opt/homebrew/bin/node',str(path)]
 with (r/(label+'.log')).open('w') as log:p=subprocess.run(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(label=label,args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-start));(r/'oracle-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(label,'TERMINAL',p.returncode,flush=True);p.check_returncode()
