from pathlib import Path
import json,sys,math,importlib
import numpy as np,torch as native
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sys.path.insert(0,str(repo/'packages/stridetorch/benchmarks'));from bench_distances import load
a=np.cos(np.arange(17*71)*.19+.2).reshape(17,71).astype('float32');seed=np.sin(np.arange(136)+.3).astype('float32');terms=[[[] for _ in range(71)] for _ in range(17)];position=0
for i in range(17):
 for j in range(i+1,17):
  delta=[float(x)-float(y) for x,y in zip(a[i],a[j])];length=math.fsum(math.sqrt(abs(d)) for d in delta)**2
  for f,d in enumerate(delta):
   v=math.copysign(math.sqrt(length/abs(d)),d)*float(seed[position]) if d else 0.;terms[i][f].append(v);terms[j][f].append(-v)
  position+=1
ref=np.array([[math.fsum(v) for v in row] for row in terms]);outputs={};x=native.from_numpy(a.copy()).requires_grad_();(native.pdist(x,p=.5)*native.from_numpy(seed)).sum().backward();outputs['native']=x.grad.numpy()
for label,source in [('baseline',r/'baseline-source/stridetorch'),('candidate',repo/'packages/stridetorch/src/stridetorch')]:
 m,_=load('_fractional_'+label,source);t=m.torch;importlib.import_module('_fractional_'+label+'._distance')._WORKSPACE_BYTES=4096;x=t.tensor(a,requires_grad=True);(t.pdist(x,p=.5)*t.tensor(seed)).sum().backward();outputs[label]=x.grad.numpy()
np.testing.assert_array_equal(outputs['baseline'],outputs['candidate'])
rows={}
for label,value in outputs.items():
 error=value.astype('float64')-ref;rows[label]=dict(per_element_failures=int(np.count_nonzero(np.abs(error)>8e-6+3e-5*np.abs(ref))),relative_l2=float(np.linalg.norm(error)/np.linalg.norm(ref)),relative_linf=float(np.max(np.abs(error))/np.max(np.abs(ref))))
(r/'fractional-feature-tile.json').write_text(json.dumps(dict(rows=rows,candidate_exact_baseline=True,native_version=native.__version__,scope='Independent compensated scalar FP64 gradient for exact frozen float32 inputs; existing fractional-gradient norm qualification versus per-element tolerance.'),indent=2)+'\n');print(json.dumps(rows))
