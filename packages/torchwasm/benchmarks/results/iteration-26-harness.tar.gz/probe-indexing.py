import torch as t,numpy as np
from stridetorch import torch as s
for api in (t,s):
 print('\nAPI',api.__name__ if api is t else 'StrideTorch')
 for opname in ('gather','sort','topk'):
  for mutation in ('input','output','indices'):
   x=api.tensor([[3.,1.,2.],[6.,4.,5.]],requires_grad=True);idx=api.tensor([[1,1],[0,2]],dtype=api.int64)
   y=x.gather(1,idx) if opname=='gather' else x.sort(1).values if opname=='sort' else x.topk(2,1).values
   if opname!='gather':
    pair=x.sort(1) if opname=='sort' else x.topk(2,1);y,idx=pair
   with api.no_grad():(x if mutation=='input' else y if mutation=='output' else idx).detach().fill_(0)
   try:y.sum().backward();print(opname,mutation,'OK',x.grad.tolist())
   except Exception as e:print(opname,mutation,type(e).__name__,str(e)[:110])
 for dtype in ('int64','int32','int16','uint64','float32'):
  for empty in (False,True):
   try:
    idx=api.tensor([[]] if empty else [[1,1]],dtype=getattr(api,dtype));x=api.tensor([[1.,2.,3.]],requires_grad=True);y=x.gather(1,idx);y.sum().backward();print('gatherdtype',dtype,empty,'OK',y.shape,x.grad.tolist())
   except Exception as e:print('gatherdtype',dtype,empty,type(e).__name__)
 for xdata,indexdata in [(3.,0),(3.,[0]),([3.],0),([[1.,2.]],[]),([[1.,2.]],[[[]]])]:
  try:
   x=api.tensor(xdata,requires_grad=True);i=api.tensor(indexdata,dtype=api.int64);y=x.gather(0,i);y.sum().backward();print('gathershape',x.shape,i.shape,'OK',y.shape,x.grad.tolist())
  except Exception as e:print('gathershape',xdata,indexdata,type(e).__name__,str(e)[:80])
 for name,func in [('gather',lambda x:x.gather(0,api.tensor([0,0],dtype=api.int64))),('sort',lambda x:x.sort()),('topk',lambda x:x.topk(2))]:
  try:
   p=api.tensor([3.,1.,2.],requires_grad=True);v=api.tensor([.2,.4,.8],requires_grad=True);a,b=api.func.jvp(func,(p,),(v,));out=b if name=='gather' else b.values;out.sum().backward();print('jvp',name,a,b,None if p.grad is None else p.grad.tolist(),v.grad.tolist())
  except Exception as e:print('jvp',name,type(e).__name__,str(e)[:100])
 print('half repeated gather')
 x=api.ones(1,dtype=api.float16,requires_grad=True);y=x.gather(0,api.zeros(1000,dtype=api.int64));y.backward(api.full(y.shape,.1,dtype=api.float16));print(x.grad.tolist())
 for name in ('argsort','sort','topk'):
  for dim in (None,True,3,-3):
   try:r=getattr(api.tensor([3.,1.,2.]),name)(2,dim=dim) if name=='topk' else getattr(api.tensor([3.,1.,2.]),name)(dim=dim);print(name,dim,'OK')
   except Exception as e:print(name,dim,type(e).__name__)
