import json,numpy as np,torch as native,stridetorch
from stridetorch import torch
rows=[]
for api in (native,torch):
 x=api.from_numpy(np.array([[1.,2.],[3.,4.]],order='F')).requires_grad_();i=api.tensor([[0,1],[1,0]])
 g=api.autograd.grad(x.gather(1,i).sum(),x)[0];x.gather(1,i).sum().backward()
 rows.append(dict(api=api.__name__,input_stride=x.stride(),returned_grad_stride=g.stride(),leaf_grad_stride=x.grad.stride()))
print(json.dumps(dict(library=stridetorch.__version__,module=stridetorch.__file__,native=native.__version__,rows=rows,scope='Existing leaf accumulation C-copy differs from native dense leaf layout;not repaired by the indexing change')))
