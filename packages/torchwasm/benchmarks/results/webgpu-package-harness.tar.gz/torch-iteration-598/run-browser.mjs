import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const repo='/Users/david/Developer/PaperLeet-torch-release';
const runtime=path.resolve(root,'../torch-iteration-76/runtime');
const sha=file=>createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const config={mode:'yield-semantics-probe',cycle:0};
const frozen=JSON.parse(fs.readFileSync(path.join(root,'source-plan.json'),'utf8'));
const source=frozen.files;
for(const [name,digest] of Object.entries(source))assert.equal(sha(path.join(root,name)),digest,name);
const loadPlan=JSON.parse(fs.readFileSync(path.join(root,'load-plan.json'),'utf8'));
for(const item of Object.values(loadPlan.files))assert.equal(sha(path.join(root,item.source)),item.sha256,item.source);
const requests=[];
const server=http.createServer(async(req,res)=>{
  try{
    const name=new URL(req.url,'http://localhost').pathname;requests.push({path:name,origin:req.headers.origin||null});
    if(name==='/'){res.writeHead(200,{'content-type':'text/html'});res.end('<!doctype html><title>Local bounded GPU service experiment</title>');return;}
    const base=name.startsWith('/runtime/')?runtime:root;
    const relative=name.startsWith('/runtime/')?name.slice('/runtime/'.length):name.startsWith('/rpc/')?name.slice('/rpc/'.length):null;
    assert(relative!==null);const file=path.resolve(base,relative);assert(file.startsWith(base+path.sep));
    const bytes=await fs.promises.readFile(file);
    res.writeHead(200,{'content-type':/\.m?js$/.test(file)?'text/javascript':file.endsWith('.wasm')?'application/wasm':'application/octet-stream','access-control-allow-origin':'*','cache-control':'no-store'});res.end(bytes);
  }catch{res.writeHead(404);res.end();}
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const origin='http://127.0.0.1:'+server.address().port;

async function workerMain(base,config){
 self.onmessage=async event=>{
  if(event.data?.type!=='attach'||event.ports.length!==4)return;
  self.onmessage=null;
  try{
   const {MatrixRpc}=await import(base+'/rpc/rpc-client.mjs');
   const {MatrixRpc:OldClient}=await import(base+'/rpc/legacy-rpc-client.mjs');
   const client=new MatrixRpc(event.ports[0]),legacy=new MatrixRpc(event.ports[1]),old=new OldClient(event.ports[2]),future=new MatrixRpc(event.ports[3]);
   const refused=future.ready.then(()=>{throw Error('Future protocol was accepted');},error=>{if(error.code!=='IncompatibleProtocol')throw error;return error.code;});
   await Promise.all([client.ready,legacy.ready,old.ready,refused]);
   self.matrix_rpc=client;self.legacy_matrix_rpc=legacy;self.old_matrix_rpc=old;
   self.capabilities={modern:client.protocol,legacy:legacy.protocol,future_error:await refused,future_closed:future.closed};
   if(client.nextId!==1||legacy.nextId!==1||old.nextId!==1)throw Error('Negotiation used a math RPC');
   self.postMessage({type:'phase',phase:'Default-limit GPU service ready'});
   const {loadPyodide}=await import(base+'/runtime/pyodide.mjs');
   const py=await loadPyodide({indexURL:base+'/runtime/',stdout(message){self.postMessage({type:'phase',phase:message});},stderr(message){self.postMessage({type:'phase',phase:message});}});await py.loadPackage('numpy');
   py.runPython("import sys;sys.dont_write_bytecode=True;sys.path.insert(0,'/')");
   const response=await fetch(base+'/rpc/load-plan.json');if(!response.ok)throw Error('Missing load plan');const plan=await response.json();
   const wheelResponse=await fetch(base+'/rpc/'+plan.wheel.source);if(!wheelResponse.ok)throw Error('Missing wheel');
   py.FS.writeFile('/library.whl',new Uint8Array(await wheelResponse.arrayBuffer()));py.globals.set('_wheel_sha256',plan.wheel.sha256);
   py.runPython("import hashlib,zipfile\nassert hashlib.sha256(open('/library.whl','rb').read()).hexdigest()==_wheel_sha256\nzipfile.ZipFile('/library.whl').extractall('/')");
   for(const [name,item] of Object.entries(plan.files)){
    const fetched=await fetch(base+'/rpc/'+item.source);if(!fetched.ok)throw Error('Missing payload '+name);
    const bytes=new Uint8Array(await fetched.arrayBuffer());
    py.FS.mkdirTree('/'+name.split('/').slice(0,-1).join('/'));py.FS.writeFile('/'+name,bytes);
    py.globals.set('_payload_path','/'+name);
    const digest=py.runPython("import hashlib\nhashlib.sha256(open(_payload_path,'rb').read()).hexdigest()");
    if(digest!==item.sha256)throw Error('Payload changed '+name);
   }
   py.globals.set('_limits_json',JSON.stringify(client.limits));py.globals.set('_cycle',config.cycle);
   self.postMessage({type:'phase',phase:'Actual Tensor forward/autograd/optimizer and suspension guards starting'});
   const numerical=JSON.parse(await py.runPythonAsync("exec(compile(open('/probe.py').read(),'/probe.py','exec'))\njson.dumps(report)"));
   numerical.compatibility=JSON.parse(await py.runPythonAsync("exec(compile(open('/compatibility.py').read(),'/compatibility.py','exec'))\njson.dumps(compatibility_report)"));
   const peerStats=[await legacy.stats(),await old.stats()];if(peerStats.some(value=>value.total_bytes!==0||value.resident_handles!==0))throw Error('Compatibility hosts leaked buffers');
   await legacy.close();await old.close();
   const stats=await client.stats();if(stats.total_bytes!==0||stats.resident_handles!==0)throw Error('GPU allocations leaked');
   const info=client.info,limits=client.limits,requestsSent=client.nextId-1;await client.close();
   self.postMessage({type:'result',result:{status:'passed',worker:{secure_context:isSecureContext,origin:self.origin,gpu_exposed:!!navigator.gpu,pyodide:py.version},numerical,capabilities:self.capabilities,before_close:[stats,...peerStats],gpu_info:info,limits,requests_sent:requestsSent}});
  }catch(error){self.postMessage({type:'failure',error:String(error.stack||error)});}
 };
}
let browser;
try{
  browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
  const page=await browser.newPage();await page.goto(origin);
  page.on('console',message=>{console.log('BROWSER',message.text().slice(0,500));});
  const sourceText='('+workerMain.toString()+')('+JSON.stringify(origin)+','+JSON.stringify(config)+')';
  const result=await page.evaluate(async({base,sourceText,hostCount})=>{
    const hosts=[],disposals=[],frame=document.createElement('iframe');frame.setAttribute('sandbox','allow-scripts');
    const nonce=crypto.randomUUID();let resultResolve,resultReject,stoppedResolve;
    const stopped=new Promise(resolve=>stoppedResolve=resolve);
    const completed=new Promise((resolve,reject)=>{resultResolve=resolve;resultReject=reject;});
    const timer=setTimeout(()=>resultReject(Error('Fixture total timeout')),100000);
    for(let i=0;i<hostCount;i++){
      const worker=new Worker(base+'/rpc/'+(i===1?'legacy-gpu-service.mjs':i===3?'incompatible-host.mjs':'gpu-service.mjs'),{type:'module'}),channel=new MessageChannel();
      const host={worker,port:channel.port2,events:[]};
      host.disposed=new Promise(resolve=>host.disposedResolve=resolve);
      worker.onmessage=event=>{host.events.push(event.data);if(event.data?.type==='disposed')host.disposedResolve(event.data);if(event.data?.type==='unavailable')resultReject(Error(event.data.error));};
      worker.onerror=event=>resultReject(Error('Host worker: '+event.message));hosts.push(host);worker.postMessage({type:'connect'},[channel.port1]);
    }
    function receive(event){
      if(event.source!==frame.contentWindow||event.data?.nonce!==nonce)return;
      const data=event.data;
      if(data.type==='frame_ready'){
        if(event.origin!=='null'||!data.parent_blocked){resultReject(Error('Isolation boundary changed'));return;}
        frame.contentWindow.postMessage({nonce,type:'attach'},'*',hosts.map(host=>host.port));
      }
      if(data.type==='result'){if(!data.worker_terminated){resultReject(Error('Learner worker not terminated'));return;}resultResolve(data.result);}
      if(data.type==='failure')resultReject(Error(data.error));
      if(data.type==='phase')console.info(data.phase);
      if(data.type==='stopped')stoppedResolve();
    }
    window.addEventListener('message',receive);
    const csp="default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval' blob: "+base+"/; worker-src blob:; connect-src "+base+'/;';
    const program='const nonce='+JSON.stringify(nonce)+';const hostCount='+hostCount+';let attached=false;let blocked=false;try{parent.document.body}catch{blocked=true;}const url=URL.createObjectURL(new Blob(['+JSON.stringify(sourceText)+'],{type:"text/javascript"}));const worker=new Worker(url);const stop=()=>{worker.terminate();URL.revokeObjectURL(url);};worker.onmessage=e=>{const terminal=e.data?.type==="result"||e.data?.type==="failure";if(terminal)stop();parent.postMessage({nonce,...e.data,worker_terminated:terminal},"*");};worker.onerror=e=>{stop();parent.postMessage({nonce,type:"failure",error:e.message,worker_terminated:true},"*");};addEventListener("message",e=>{if(e.source!==parent||e.data?.nonce!==nonce)return;if(e.data.type==="stop"){stop();parent.postMessage({nonce,type:"stopped"},"*");return;}if(!attached&&e.data.type==="attach"&&e.ports.length===hostCount){attached=true;worker.postMessage({type:"attach"},e.ports);}});parent.postMessage({nonce,type:"frame_ready",parent_blocked:blocked},"*");';
    frame.srcdoc='<meta http-equiv="Content-Security-Policy" content="'+csp.replaceAll('"','&quot;')+'"><script>'+program.replaceAll('</script','<\\/script')+'</script>';document.body.append(frame);
    try{
      const value=await completed;
      for(const host of hosts)host.worker.postMessage({type:'dispose'});
      for(const host of hosts)disposals.push(await Promise.race([host.disposed,new Promise((_,reject)=>setTimeout(()=>reject(Error('Device disposal timeout')),5000))]));
      return {...value,host_events:hosts.map(host=>host.events),host_disposals:disposals,isolation:{sandbox:frame.getAttribute('sandbox'),csp,parent_document_blocked:true,learner_worker_terminated_before_result:true}};
    }finally{
      clearTimeout(timer);frame.contentWindow?.postMessage({nonce,type:'stop'},'*');
      await Promise.race([stopped,new Promise(resolve=>setTimeout(resolve,500))]);window.removeEventListener('message',receive);frame.remove();
      for(const host of hosts){host.worker.postMessage({type:'dispose'});await Promise.race([host.disposed,new Promise(resolve=>setTimeout(resolve,1000))]);host.worker.terminate();host.port.close();}
    }
  },{base:origin,sourceText,hostCount:4});
  for(const [name,digest] of Object.entries(source))assert.equal(sha(path.join(root,name)),digest,name);
  for(const item of Object.values(loadPlan.files))assert.equal(sha(path.join(root,item.source)),item.sha256,item.source);
  assert.equal(result.status,'passed');assert.equal(result.worker.secure_context,false);assert.equal(result.worker.gpu_exposed,false);
  assert.equal(result.numerical.status,'passed_guarded_resident_tensor_offload');assert.equal(result.numerical.cases,51);
  assert.equal(result.numerical.installed_package.files,77);assert(result.numerical.installed_package.compatibility_aliases_share_canonical_modules);
  assert.equal(result.numerical.compatibility.cases,7);assert.equal(result.capabilities.future_error,'IncompatibleProtocol');assert.equal(result.capabilities.future_closed,true);assert.equal(result.capabilities.legacy.legacy,true);assert.equal(result.capabilities.modern.major,1);
  assert(result.host_disposals.every(value=>value.stats.total_bytes===0&&value.stats.closed));
  const report={...result,observed_utc:new Date().toISOString(),browser:browser.version(),launch:{headless:true,extra_flags:[]},source_sha256:source,load_plan_sha256:sha(path.join(root,'load-plan.json')),runtime_module_sha256:sha(runtime+'/pyodide.mjs'),requests,fixture_enables_torch_gpu_backend:false,latency_measured:false,scope:'Explicit opt-in CPU-Tensor GPU matmul offload with real first-order autograd; independent native value/gradient and optimizer controls, tracked mutation/mode/reentry rejection, existing default host quotas and cleanup. No resident Torch GPU storage, dispatch threshold or performance qualification.'};
  fs.writeFileSync(path.join(root,'browser-result-'+config.cycle+'.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({status:report.status,cases:report.numerical.cases,cycle:config.cycle,requests_sent:report.requests_sent,disposals:report.host_disposals}));
}catch(error){fs.writeFileSync(path.join(root,'failure-'+config.cycle+'.json'),JSON.stringify({error:String(error.stack||error),observed_utc:new Date().toISOString()},null,2)+'\n');throw error;}finally{if(browser)await browser.close();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
