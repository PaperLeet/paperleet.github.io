import json
import numpy as np
from js import legacy_matrix_rpc,old_matrix_rpc
from matrix_client import MatrixProgram
import resident_bridge

rows=[]
def basic(client,label):
    program=MatrixProgram(client);a=program.input(np.array([[1,2],[3,4]],dtype='float32'));b=program.input(np.array([[5,6],[7,8]],dtype='float32'));output=program.matmul(a,b)
    with program.run([output],retain=True) as result:
        np.testing.assert_array_equal(result.arrays[0],np.array([[19,22],[43,50]],dtype='float32'))
        assert result.matrices[0] is not None
    rows.append(dict(kind=label,passed=True))
basic(legacy_matrix_rpc,'new_client_old_service_actual_program_and_release')
basic(old_matrix_rpc,'old_client_new_service_actual_program_and_release')
class NoConvert:
    def __array__(self,*args,**kwargs):raise AssertionError('Unsupported retention copied input')
program=MatrixProgram(legacy_matrix_rpc);a=program.input(NoConvert());b=program.input(NoConvert());output=program.matmul(a,b);before=int(legacy_matrix_rpc.nextId)
try:program.run([output],retain_inputs=[a])
except BaseException as error:assert 'does not support program-retain-inputs' in str(error),str(error)
else:raise AssertionError('Legacy retention was accepted')
assert int(legacy_matrix_rpc.nextId)==before
rows.append(dict(kind='python_retention_refused_before_conversion_and_rpc',passed=True))
import js
saved=js.matrix_rpc;js.matrix_rpc=legacy_matrix_rpc
try:
    try:resident_bridge.ResidentMatmulOffload()
    except BaseException as error:assert 'does not support program-retain-inputs' in str(error),str(error)
    else:raise AssertionError('Legacy resident session was accepted')
finally:js.matrix_rpc=saved
assert int(legacy_matrix_rpc.nextId)==before
rows.append(dict(kind='python_resident_session_refused_before_ownership',passed=True))


from stridetorch.experimental.webgpu import ResidentMatmulOffload,MatmulOffload
from stridetorch import torch
saved=js.matrix_rpc;legacy_before=int(legacy_matrix_rpc.nextId)
a=torch.tensor([[1.,2.],[3.,4.]],dtype=torch.float32,requires_grad=True)
b=torch.tensor([[5.,6.],[7.,8.]],dtype=torch.float32,requires_grad=True)
def check_call(call):
    with torch.enable_grad():
        y=call(a,b);da,db=torch.autograd.grad(y,(a,b),torch.ones_like(y))
    for actual,expected in [(y,[[19.,22.],[43.,50.]]),(da,[[11.,15.],[11.,15.]]),(db,[[4.,4.],[6.,6.]])]:np.testing.assert_array_equal(actual.numpy(),np.array(expected,dtype='float32'))
resident=ResidentMatmulOffload()
try:
    js.matrix_rpc=legacy_matrix_rpc
    check_call(resident);resident.close()
    assert not saved.closed
    rows.append(dict(kind='resident_constructor_client_pinned_across_global_replacement',passed=True))
    with ResidentMatmulOffload(client=saved) as explicit:check_call(explicit)
    assert not saved.closed
    rows.append(dict(kind='explicit_resident_borrows_client_without_using_global',passed=True))
    js.matrix_rpc=saved;stateless=MatmulOffload();check_call(stateless)
    js.matrix_rpc=legacy_matrix_rpc;check_call(stateless);check_call(MatmulOffload(client=saved))
    assert not saved.closed
    rows.append(dict(kind='stateless_default_and_explicit_client_remain_pinned_for_forward_and_vjp',passed=True))
finally:
    js.matrix_rpc=saved;resident.close()
assert int(legacy_matrix_rpc.nextId)==legacy_before
compatibility_report=dict(status='passed_real_browser_protocol_compatibility_and_client_binding',cases=len(rows),rows=rows)
