import inspect,textwrap

def bind_backend(kind,client):
    source=textwrap.dedent(inspect.getsource(kind.program))
    assert source.count('program = MatrixProgram()')==1
    source=source.replace('program = MatrixProgram()','program = MatrixProgram(client=self.client)')
    namespace=dict(kind.program.__globals__)
    exec(compile(source,'<bound-client-'+kind.__module__+'>','exec'),namespace)
    def setup(self):self.client=client
    cls=type('BoundClientBackend',(kind,),dict(__init__=setup,program=namespace['program']))
    return cls()
