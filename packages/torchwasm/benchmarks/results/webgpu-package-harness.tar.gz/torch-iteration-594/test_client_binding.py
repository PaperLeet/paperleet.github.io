from types import SimpleNamespace
import sys
import numpy as np
from stridetorch.experimental.webgpu import resident_bridge,matrix_client


def test_resident_backend_keeps_constructor_client_after_global_replacement(monkeypatch):
    first=SimpleNamespace(requireFeatures=lambda *args:None)
    second=SimpleNamespace(requireFeatures=lambda *args:None)
    monkeypatch.setitem(sys.modules,'js',SimpleNamespace(matrix_rpc=first))
    backend=resident_bridge._RpcBackend()
    monkeypatch.setitem(sys.modules,'js',SimpleNamespace(matrix_rpc=second))
    used=[]
    class Program:
        def __init__(self,client=None):
            used.append(matrix_client.default_client() if client is None else client)
            self.inputs=[]
        def input(self,value):self.inputs.append(value);return len(self.inputs)-1
        def matmul(self,*args):return 2
        def run(self,*args,**kwargs):
            return SimpleNamespace(arrays=[self.inputs[0]@self.inputs[1]],matrices=[None],input_matrices={})
    monkeypatch.setattr(matrix_client,'MatrixProgram',Program)
    a=np.ones((2,2),dtype='float32');b=np.ones((2,2),dtype='float32')
    backend.program([(a,b,False,False)],{id(a):a,id(b):b},(False,),())
    assert used[0] is first
