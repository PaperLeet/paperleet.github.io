from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile,time

r=Path(__file__).resolve().parent;s=r/'main-sync-final';repo=Path('/Users/david/Developer/PaperLeet-torch-release')
context=json.loads((s/'context.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads(subprocess.check_output(['git','show',context['previous_upstream']+':web/package.json'],cwd=repo,text=True))
current=json.loads((repo/'web/package.json').read_text())
assert {k:v for k,v in old.items() if k!='scripts'}=={k:v for k,v in current.items() if k!='scripts'}
value=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED','--jq','.value'],cwd=repo,text=True).strip()
profile=dict(VITE_PUBLIC_SITE='0',VITE_APP_EDITION='hosted',VITE_API_ORIGIN='https://app.paperleet.com',VITE_HOSTED_APP_AVAILABLE='1',VITE_HOSTED_APP_URL='https://app.paperleet.com') if value=='1' else dict(VITE_PUBLIC_SITE='1',VITE_APP_EDITION='public',VITE_API_ORIGIN='',VITE_HOSTED_APP_AVAILABLE='1',VITE_HOSTED_APP_URL='https://app.paperleet.com')
(s/'pages-profile.json').write_text(json.dumps(dict(observed_value=value,environment=profile),indent=2)+'\n')
env=dict(os.environ,PATH='/opt/homebrew/bin:'+os.environ['PATH']);receipts=[]
plans=[(name,['/opt/homebrew/bin/node','scripts/check-'+name+'.mjs'],{}) for name in ['feed-outlines','post-preview','discussion-reading','community-navigation','interview-ui']]
plans.extend([('frontend-build',['npm','run','build'],{}),('pages-profile-build',['npm','run','build'],profile)])
for name,args,extra in plans:
    start=time.monotonic()
    with (s/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=repo/'web',env={**env,**extra},stdout=log,stderr=subprocess.STDOUT)
    receipts.append(dict(name=name,args=args,cwd=str(repo/'web'),exit_code=p.returncode,elapsed_s=time.monotonic()-start))
    (s/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,p.returncode,flush=True);p.check_returncode()
for n,h in context['source_hashes'].items():assert sha(repo/'packages/stridetorch/src/stridetorch'/n)==h
for n,h in context['active_export_sha256'].items():assert sha(repo/'web/public/data'/n)==h
for n,h in context['changed_files'].items():assert sha(repo/n)==sha(s/'incoming'/n)==h
shutil.copy2(Path(__file__),s/Path(__file__).name)
out=repo/'packages/stridetorch/benchmarks/results';archive=out/'iteration-40-main-sync-final-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for p in sorted(s.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:tar.add(p,arcname=str(p.relative_to(s)),recursive=False)
report=dict(status='complete_local_late_frontend_sync_passed_runtime_identity_unchanged',version='0.40.0',context=context,receipts=receipts,archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),publication='No GitHub CI,tag,dispatch,package upload or online publication.')
(out/'iteration-40-main-sync-final.json').write_text(json.dumps(report,indent=2)+'\n')
doc=repo/'docs/validation/torch-runtime-iteration-40.md';doc.write_text(doc.read_text()+f'\nA later synchronization preserves twelve feed-outline frontend/check/style/docs\nfiles through `{context["upstream"]}`. Package dependencies and the lockfile\ndid not change. Five affected interaction/reading suites and both typed builds\npass. All 49 runtime/license resources and 161 active exports remain unchanged.\nSee `iteration-40-main-sync-final.json`.\n')
print('Late sync closed',context['upstream'],flush=True)
