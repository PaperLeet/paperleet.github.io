from pathlib import Path
import gzip,json,os,statistics,subprocess,time
r=Path(__file__).resolve().parent;out=r/'performance-final';out.mkdir(exist_ok=True);receipts={};py=r.parent/'torch-iteration-21/stride-dev-env/bin/python'
sources=dict(baseline=str(r/'baseline/stridetorch'),candidate=str(r/'proof/source'))
for repeat in (1,2):
    for runtime in (('cpu','wasm') if repeat==1 else ('wasm','cpu')):
        for dtype in ('float32','float64'):
            name=f'{runtime}-{dtype}-{repeat}';args=[str(py),str(r/'bench-library.py')] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(r/'bench-library-wasm.mjs')]
            env=dict(os.environ,BENCH_SOURCES=json.dumps(sources),BENCH_DTYPE=dtype,BENCH_LANE='inverse',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');start=time.monotonic()
            with (out/(name+'.json')).open('w') as stdout,(out/(name+'.stderr.log')).open('w') as stderr:p=subprocess.run(args,cwd=r,env=env,stdout=stdout,stderr=stderr)
            receipts[name]=dict(exit_code=p.returncode,elapsed_s=time.monotonic()-start,args=args);(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode()
            report=json.loads((out/(name+'.json')).read_text());assert report['source_hashes']['candidate']==json.loads((r/'proof/source-hashes.json').read_text());assert report['versions']==dict(baseline='0.35.0',candidate='0.36.0')
            print(name,{k:round(v['median_time_reduction_percent'],1) for k,v in report['results'].items()},flush=True)
summary={}
for runtime in ('cpu','wasm'):
    rows=[json.loads((out/f'{runtime}-{dtype}-{repeat}.json').read_text()) for dtype in ('float32','float64') for repeat in (1,2)]
    summary[runtime]={key:dict(median_reductions_percent=[v['results'][key]['median_time_reduction_percent'] for v in rows],baseline_median_us=[statistics.median(statistics.mean(b['samples_us']['baseline']) for b in v['results'][key]['blocks']) for v in rows],candidate_median_us=[statistics.median(statistics.mean(b['samples_us']['candidate']) for b in v['results'][key]['blocks']) for v in rows]) for key in rows[0]['results']}
footprint={}
for label,folder in [('previous_035',r/'baseline/stridetorch'),('candidate_036',r/'proof/source')]:
    raw=b''.join(p.read_bytes() for p in sorted(folder.iterdir()) if p.suffix=='.py' or p.name in ('LICENSE','NOTICE'));footprint[label]=dict(raw_bytes=len(raw),local_gzip_estimate_bytes=len(gzip.compress(raw,mtime=0)))
(r/'performance-final-summary.json').write_text(json.dumps(dict(summary=summary,source_footprint=footprint,receipts=receipts,scope='Eight sequential children after heavy compatibility/application/native gates. Two dtypes and two fresh processes per CPU/WASM; 18 workflows, nine ABBA/BAAB blocks, GC enabled and actual SGD. Baseline reuses an identity Tensor with existing 0.35 cholesky_solve; inverse API includes per-call structural RHS generation and singular-diagonal validation. Ordered native inverse JVP used on both sides. Shared host; no verified vendor thread count or cross-runtime throughput claim.'),indent=2)+'\n')
