from pathlib import Path
import hashlib,importlib.util,json,os,shutil,subprocess,tarfile,time,zipfile

root=Path(__file__).parent;repo=Path.cwd();source=repo/'packages/stridetorch/src/stridetorch'
files=sorted([*source.glob('*.py'),source/'LICENSE',source/'NOTICE'])
expected={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
wheel=next((root/'dist-preflight').glob('*.whl'));sdist=next((root/'dist-preflight').glob('*.tar.gz'))
with zipfile.ZipFile(wheel) as archive:
    names=[n for n in archive.namelist() if n.startswith('stridetorch/') and n.endswith('.py')]
    assert len(names)==45
    for name,digest in expected.items():assert hashlib.sha256(archive.read('stridetorch/'+name)).hexdigest()==digest,name
    assert archive.read('stridetorch-0.36.0.dist-info/licenses/LICENSE')==(source/'LICENSE').read_bytes()
    assert (repo/'packages/stridetorch/README.md').read_text() in archive.read('stridetorch-0.36.0.dist-info/METADATA').decode()
with tarfile.open(sdist) as archive:
    assert archive.extractfile('stridetorch-0.36.0/README.md').read()==(repo/'packages/stridetorch/README.md').read_bytes()
    names=[n for n in archive.getnames() if '/src/stridetorch/' in n and n.endswith('.py')]
    assert len(names)==45
    for name,digest in expected.items():assert hashlib.sha256(archive.extractfile('stridetorch-0.36.0/src/stridetorch/'+name).read()).hexdigest()==digest,name
venv=root/'python310-stride036-env';python=venv/'bin/python';uv='/Users/david/.local/bin/uv'
env=dict(os.environ);env.pop('PYTHONPATH',None)
receipts={}
def run(args,name):
    start=time.monotonic()
    with (root/name).open('w') as log:
        result=subprocess.run([str(x) for x in args],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    receipts[name]=dict(exit_code=result.returncode,elapsed_s=time.monotonic()-start,args=[str(x) for x in args])
    (root/'wheel-stride036-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
    print('TERMINAL',name,result.returncode,flush=True);result.check_returncode()
run([uv,'venv','--clear',venv,'--python','/Users/david/.local/share/uv/python/cpython-3.10.19-macos-aarch64-none/bin/python3.10'],'python310-stride036-venv.log')
run([uv,'pip','install','--python',python,'numpy==1.26.4','pytest',wheel],'python310-stride036-install.log')
tests=root/'python310-stride036-tests';shutil.copytree(repo/'packages/stridetorch/tests',tests,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
run([python,'-m','pytest',tests,'-q','--noconftest'],'python310-stride036-tests.log')
identity=json.loads(subprocess.check_output([str(python),'-c',"import sys,numpy,stridetorch,pathlib,hashlib,importlib.util,json;p=pathlib.Path(stridetorch.__file__).parent;print(json.dumps(dict(python=sys.version,numpy=numpy.__version__,library=stridetorch.__version__,native_torch=importlib.util.find_spec('torch') is not None,source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in p.iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')})))"],cwd=root,env=env,text=True))
assert identity['python'].startswith('3.10.19') and identity['numpy']=='1.26.4' and identity['library']=='0.36.0' and not identity['native_torch']
assert identity['source_hashes']==expected
assert expected=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
identity.update(status='success',all_children_terminal=True,package_modules=45,license='Apache-2.0',artifacts={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (wheel,sdist)},receipts=receipts)
(root/'wheel-stride036-result.json').write_text(json.dumps(identity,indent=2)+'\n');print('PASS isolated StrideTorch0.36 wheel and source archive identity')
