from pathlib import Path
import hashlib,json,tarfile
r=Path(__file__).resolve().parent;s=r/'main-sync-proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
context=json.loads((s/'context.json').read_text());receipts=json.loads((s/'frontend-receipts.json').read_text());assert len(receipts)==5 and all(v['exit_code']==0 for v in receipts)
for path,row in context['incoming'].items():assert hashlib.sha256((repo/path).read_bytes()).hexdigest()==row['validated_sha256']
for name,digest in context['source_hashes'].items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==digest
for name,digest in context['live_exports'].items():assert hashlib.sha256((repo/'web/public/data'/name).read_bytes()).hexdigest()==digest
archive=out/'iteration-36-main-sync-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for p in sorted(s.rglob('*')):
        if p.is_file():tar.add(p,arcname=str(p.relative_to(s)),recursive=False)
report=dict(status='complete_local_latest_frontend_and_both_builds_passed',context=context,frontend_receipts=receipts,archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),publication='No CI, tag, workflow dispatch or online release requested.')
(out/'iteration-36-main-sync.json').write_text(json.dumps(report,indent=2)+'\n')
doc=repo/'docs/validation/torch-runtime-iteration-36.md';doc.write_text(doc.read_text()+f'\nFinal synchronization preserves all five incoming UI/docs/check files through\n`{context["upstream"]}`, with only the separately recorded bounded navigation\ntest waits differing from upstream. The complete frontend check and both typed\nbuilds pass again. All 47 computational resources and 161 exports remain\nunchanged; see `iteration-36-main-sync.json`.\n')
print(json.dumps(dict(upstream=context['upstream'],frontend='full check and both builds passed',source_unchanged=47,exports_unchanged=161)))
