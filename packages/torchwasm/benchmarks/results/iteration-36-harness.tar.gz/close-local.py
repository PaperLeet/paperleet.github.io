from pathlib import Path
import hashlib,json,os,re,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results';proof=r/'proof';i=r/'integration-proof'
def read(name):return json.loads((r/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
actual={p.name:sha(p) for p in (repo/'packages/stridetorch/src/stridetorch').iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};assert len(actual)==47 and actual==read('proof/source-hashes.json')
tests={p.name:sha(p) for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'};plan=read('proof/chrome-contracts/plan.json');assert len(tests)==35 and plan['tests']==tests and plan['source']==actual and plan['expected']==1532
gates=read('proof/gate-receipts.json');assert len(gates)==6 and all(v['exit_code']==0 for v in gates.values())
full=read('full-root-receipt.json');assert full['exit_code']==0 and full['passed']>=32463 and full['skipped']==1
assert '1314 passed' in (r/'focus-final.log').read_text()
node=read('proof/source-wasm.json');chrome=read('proof/chrome-contracts/result.json');wheel=read('proof/wheel-stride036-result.json');coinstall=read('proof/coinstall-result.json')
assert node['passed']==chrome['passed']==1532 and node['source_hashes']==chrome['source_hashes']==wheel['source_hashes']==coinstall['source_hashes']==actual
assert chrome['test_hashes']==tests and chrome['status']==wheel['status']==coinstall['status']=='success' and not wheel['native_torch']
assert '1544 passed' in (proof/'python310-stride036-tests.log').read_text()
performance=read('performance-final-summary.json');imports=read('import-summary.json')
assert len(performance['receipts'])==8 and all(v['exit_code']==0 for v in performance['receipts'].values())
assert len(imports['receipts'])==16 and all(v['exit_code']==0 for v in imports['receipts'])
for p in (r/'performance-final').glob('*.json'):
    if p.name!='receipts.json':assert json.loads(p.read_text())['source_hashes']['candidate']==actual
native=read('integration-proof/native-ci.json');wasm=read('integration-proof/full-wasm-result.json');setup=read('integration-proof/setup-receipts.json');front=read('integration-proof/frontend-receipts.json');snapshot=read('integration-proof/release-snapshot.json');exports=read('integration-proof/export-identity.json');private=read('integration-proof/distribution-identity.json')
assert native['passed'] and native['problems']==78 and native['tests_executed']==10218 and native['repeats']==3 and native['duration_s']<=600 and not native['issues']
assert len(native['mutation'])==78 and sum(map(len,native['mutation'].values()))==342 and all(hits for mutants in native['mutation'].values() for hits in mutants.values())
assert wasm['passed'] and wasm['catalog_modules']==wasm['modules']==78 and not wasm['browser_budget_exceeded'] and sum(v['mutants'] for v in wasm['results'])==342
assert all(v['passed'] and not v['browser_budget_exceeded'] for v in wasm['results'])
assert len(setup)==4 and len(front)==5 and all(v['exit_code']==0 for v in setup+front)
assert snapshot['source_hashes']==actual and exports['published_assets_unchanged']==8649 and exports['active_assets']==exports['new_assets']==158 and exports['all_new_assets_reachable'] and private['status']=='success'
live=read('integration-proof/live-expected-sha256.json');assert len(live)==161
for name,digest in live.items():assert sha(repo/'web/public/data'/name)==digest
for folder,paths in [('native-contracts',(repo/'tests').glob('test_torch_*')),('package-metadata',[(repo/'packages/stridetorch'/name) for name in ('README.md','pyproject.toml','LICENSE','NOTICE')])]:
    dest=r/folder;dest.mkdir(exist_ok=True)
    for p in paths:
        if p.is_file():shutil.copy2(p,dest/p.name)
def archive(name,root,excluded):
    files=[]
    for folder,dirs,names in os.walk(root):
        dirs[:]=[d for d in dirs if not d.endswith('-env') and d not in excluded and d not in ('__pycache__','.pytest_cache')]
        for name2 in names:
            p=Path(folder)/name2
            if p.is_symlink():continue
            if p.name in ('LICENSE','NOTICE') or p.suffix in ('.py','.mjs','.cjs','.json','.log','.txt','.md','.html','.toml','.diff'):files.append(p)
    path=out/name
    with tarfile.open(path,'w:gz') as tar:
        for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
    return dict(file=path.name,files=len(files),bytes=path.stat().st_size,sha256=sha(path))
core_archive=archive('iteration-36-harness.tar.gz',r,{'dist-preflight','private-dist','dist-paperleet','integration-proof','main-sync-proof'})
core=dict(status='complete_local_core_and_application_gates_passed_main_adoption_pending',version='0.36.0',baseline_main='cc5694bf360674369a14042a73635ed85e3bf49c',source_hashes=actual,standalone_test_hashes=tests,native_test_hashes={p.name:sha(p) for p in (r/'native-contracts').iterdir()},full_cpu=full,focused_passed=1314,minimal_passed=1544,minimal_wheel=wheel,node_wasm=node,actual_chrome_worker=chrome,coinstall=coinstall,gate_receipts=gates,pilot_reports={name:read(name+'/receipts.json') for name in ('performance-first','performance-optimized','performance-small')},final_performance=performance,cold_namespace_imports=imports,archive=core_archive,scope='New torch.cholesky_inverse and Tensor method; real float32/64 full VJP, native-ordered JVP and reverse through both channels; complex inference with real factor diagonals. Scalar formulas, small LAPACK inverse, CPU Gram and large Emscripten two-solve primal dispatch. Native mutation guards, explicit singular errors and empty strides. No cached tensor/factor/inverse/seed values or native Torch runtime dependency.',retained_findings=['Native 2.14.1 inverse JVP matches its ordered source expression but differs from mathematical inverse-system differentiation for noncommuting factors. Both contracts are distinguished in independent and native tests.','First inference prototype regressed small CPU/WASM by up to48percent and large WASM by34percent. Three whole-flow pilots and source snapshots retain these regressions and measured refinements; final data includes remaining inference costs.','Initial native tests found zero-batch tangent strides, overly conservative direction guards, upper nonfinite contamination and invalid complex-diagonal backend-dependent results. Empty C tangent metadata, selective analytical tangent pullback and structural nonfinite solves fix valid contracts. Non-real complex diagonals are invalid Cholesky factors; their vendor-dependent POTRI artifacts are explicitly unsupported.','First standalone collection omitted two parameter names; corrected test signatures, original error retained.'],primary_sources=['https://docs.pytorch.org/docs/2.14/generated/torch.cholesky_inverse.html','https://github.com/pytorch/pytorch/blob/v2.14.0/torch/csrc/autograd/FunctionsManual.cpp#L2170','https://github.com/pytorch/pytorch/blob/v2.14.0/tools/autograd/derivatives.yaml#L391'],release_policy='No CI, agent tag, dispatch, package upload or online publication. User will explicitly release later.')
save('iteration-36.json',core)
app_archive=archive('iteration-36-integration-harness.tar.gz',i,{'dist-paperleet'})
app=dict(status='complete_local_application_gates_passed_main_adoption_pending',version='0.36.0',upstream=read('integration-proof/context.json')['upstream'],source_hashes=actual,core_report='iteration-36.json',native=native,exported_wasm=wasm,setup_receipts=setup,frontend_receipts=front,release_snapshot=snapshot,export_integrity=exports,distribution_identity=private,runtime_sizes=read('integration-proof/runtime-sizes.json'),wasm_harness=read('integration-proof/wasm-harness-identity.json'),context=read('integration-proof/context.json'),frontend_repair=read('integration-proof/frontend-repair-context.json'),frontend_repair_receipt=read('integration-proof/frontend-repair-receipt.json'),archive=app_archive,publication='Local results do not assert remote Linux CI or online deployment. No CI/tag/dispatch requested.')
save('iteration-36-integration.json',app);print(json.dumps(dict(core=core_archive,integration=app_archive,full_cpu=full,native_s=native['duration_s'],wasm_ms=wasm['elapsed_ms']),indent=2))
