from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;out=r/'performance-small';out.mkdir(exist_ok=True);receipts={}
for runtime in ('cpu','wasm'):
 for dtype in ('float32','float64'):
  name=runtime+'-'+dtype;args=[str(r.parent/'torch-iteration-21/stride-dev-env/bin/python'),str(r/'bench-library.py')] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(r/'bench-library-wasm.mjs')]
  env=dict(os.environ,BENCH_DTYPE=dtype,BENCH_LANE='inverse',BENCH_SOURCES=json.dumps(dict(baseline=str(r/'baseline/stridetorch'),candidate=str(r/'candidate-small'))),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');start=time.monotonic()
  with (out/(name+'.json')).open('w') as stdout,(out/(name+'.stderr.log')).open('w') as stderr:p=subprocess.run(args,cwd=r,env=env,stdout=stdout,stderr=stderr)
  receipts[name]=dict(exit_code=p.returncode,elapsed_s=time.monotonic()-start);(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode();v=json.loads((out/(name+'.json')).read_text());print(name,{k:round(x['median_time_reduction_percent'],1) for k,x in v['results'].items()},flush=True)
