from pathlib import Path
import json,subprocess,time
r=Path(__file__).resolve().parent;py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';receipts=[]
for folder,script,logname in [(r/'main-sync-proof','run-frontend.py','runner.log'),(r,'run-final-sequential.py','final-sequential.log')]:
    start=time.monotonic()
    with (folder/logname).open('w') as log:p=subprocess.run([str(py),str(folder/script)],cwd=folder,stdout=log,stderr=subprocess.STDOUT)
    receipts.append(dict(folder=folder.name,script=script,exit_code=p.returncode,elapsed_s=time.monotonic()-start))
    (r/'main-sync-and-final-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
    print(folder.name,script,'terminal',p.returncode,flush=True);p.check_returncode()
