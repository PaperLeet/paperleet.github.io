from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;i=r/'integration-proof';i.mkdir();repo=Path('/Users/david/Developer/PaperLeet-torch-release');old=r.parent/'torch-iteration-35/integration-proof'
upstream=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
for name in ('verify-export.py','run-export.py','freeze.py','verify-private.py','run-frontend.py','run-setup.py','run-native.py','run-wasm.py'):
    text=(old/name).read_text().replace('0.35.0','0.36.0').replace('==8491','==8649').replace('1495','1532').replace('len(tests)==34','len(tests)==35').replace('expected_suites=34','expected_suites=35').replace('iteration35 integration','iteration36 integration')
    text=text.replace('torch-iteration-34/integration-proof/owned-dependencies.json','torch-iteration-35/integration-proof/owned-dependencies.json')
    (i/name).write_text(text)
source=json.loads((r/'proof/source-hashes.json').read_text());assert len(source)==47 and all(hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/k).read_bytes()).hexdigest()==v for k,v in source.items())
(i/'context.json').write_text(json.dumps(dict(upstream=upstream,source_hashes=source,core_report='iteration-36.json',release_policy='No CI, tag, workflow dispatch or online publication. The user will explicitly tag later.',scope='All8649 prior immutable assets retained; fresh full exported WASM, frontend and both builds. Native original catalog and paired timing children run in isolation after heavy gates.'),indent=2)+'\n')
(i/'dist-paperleet').mkdir()
for p in (r/'proof/private-dist').iterdir():shutil.copy2(p,i/'dist-paperleet'/p.name)
print('Prepared application integration',upstream,'8649 prior assets')
