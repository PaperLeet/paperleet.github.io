from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');old=r.parent/'torch-iteration-35/proof';p=r/'proof';p.mkdir()
source=repo/'packages/stridetorch/src/stridetorch'
for dest in (p/'source',p/'chrome-contracts/source'):shutil.copytree(source,dest,ignore=shutil.ignore_patterns('__pycache__'))
shutil.copytree(repo/'packages/stridetorch/tests',p/'chrome-contracts/tests',ignore=shutil.ignore_patterns('__pycache__'))
hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in source.iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')}
tests={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (repo/'packages/stridetorch/tests').glob('test_*.py') if f.name!='test_standalone.py'}
assert len(hashes)==47 and len(tests)==35
(p/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n');(p/'chrome-contracts/plan.json').write_text(json.dumps(dict(version='0.36.0',expected=1532,source=hashes,tests=tests),indent=2)+'\n')
for name in ('chrome-contracts/run.mjs','chrome-contracts/worker.mjs','chrome-contracts/index.html','wasm-contracts.mjs','check-wheel.py','check-coinstall.py'):
    text=(old/name).read_text().replace('torch-iteration-35/proof','torch-iteration-36/proof').replace('0.35','0.36').replace('stride035','stride036').replace('1495','1532').replace('1507','1544')
    if name=='wasm-contracts.mjs':text=text.replace("'cholesky_solve','linalg_failures'","'cholesky_solve','cholesky_inverse','linalg_failures'")
    if name=='check-coinstall.py':
        marker="print('PASS isolated ownership,aliases,ZIP resume,triangular,Cholesky and Cholesky solve VJP/JVP/full tangent reverse')"
        assert marker in text
        addition="""for name in NAMES:
 t=importlib.import_module(name).torch
 f=t.tensor([[2.,0.],[.4,3.]],dtype=t.float64,requires_grad=True);df=t.full_like(f,.13,requires_grad=True)
 x,tangent=t.func.jvp(lambda f:f.cholesky_inverse(),(f,),(df,))
 expected=np.linalg.inv(f.numpy()@f.numpy().T);np.testing.assert_allclose(x.numpy(),expected)
 partial=-expected@df.numpy()@expected@f.numpy().T
 np.testing.assert_allclose(tangent.numpy(),partial+partial.T)
 (x.square().sum()+tangent.square().sum()).backward()
 assert np.isfinite(f.grad.numpy()).all() and np.isfinite(df.grad.numpy()).all()
"""
        text=text.replace(marker,addition+marker)
    (p/name).write_text(text)
for name in ('run-gates.py','run-full.py'):(r/name).write_text((r.parent/'torch-iteration-35'/name).read_text())
print('Frozen0.36:47 resources,35 suites/1532 browser checks,1544 minimal wheel checks')
