from pathlib import Path
import hashlib,json,os,subprocess,time

r=Path(__file__).resolve().parent;out=r/'performance-fairness-followup';out.mkdir(exist_ok=True)
py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';receipts={};rows=[]
plans=[]
for runtime in ('cpu','wasm'):
    for dtype in ('float32','float64'):
        for reverse in ('0','1'):plans.append(('identical040',runtime,dtype,reverse))
for dtype in ('float32','float64'):
    for reverse in ('0','1'):plans.append(('jvp_real','cpu',dtype,reverse))
for mode,runtime,dtype,reverse in plans:
    sources=dict(baseline=str(r/('proof/source' if mode=='identical040' else 'baseline/stridetorch')),candidate=str(r/'proof/source'))
    name=f'{mode}-{runtime}-{dtype}-{reverse}'
    script='bench-jvp-followup.py' if mode=='jvp_real' else 'bench-library-targeted.py'
    args=[str(py),str(r/script)] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(r/'bench-library-targeted-wasm.mjs')]
    env=dict(os.environ,BENCH_SOURCES=json.dumps(sources),BENCH_DTYPE=dtype,BENCH_REVERSE=reverse,BENCH_LANE='inverse',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
    start=time.monotonic()
    with (out/(name+'.json')).open('w') as stdout,(out/(name+'.stderr.log')).open('w') as stderr:
        p=subprocess.run(args,cwd=r,env=env,stdout=stdout,stderr=stderr)
    receipts[name]=dict(exit_code=p.returncode,elapsed_s=time.monotonic()-start)
    (out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode()
    report=json.loads((out/(name+'.json')).read_text())
    assert report['source_hashes']['candidate']==json.loads((r/'proof/source-hashes.json').read_text())
    if mode=='identical040':assert report['source_hashes']['baseline']==report['source_hashes']['candidate']
    rows.append(dict(mode=mode,runtime=runtime,dtype=dtype,reverse=reverse,report=report))
    print(name,{k:round(v['median_time_reduction_percent'],1) for k,v in report['results'].items()},flush=True)
(r/'fairness-followup-summary.json').write_text(json.dumps(dict(receipts=receipts,reports=rows,
    scope='Diagnostic calibration,not replacement data. Eight same-source0.40 A/A children for four unchanged workflows;four longer/reversed-init CPU children for the old reverse-through-JVP outlier. Original21-flow and prespecified4-flow samples retained.'),indent=2)+'\n')
