import fs from 'node:fs';import path from 'node:path';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const repo='/Users/david/Developer/PaperLeet-torch-release';const root=path.dirname(new URL(import.meta.url).pathname);
const py=await loadPyodide({indexURL:path.join(repo,'web/node_modules/pyodide/'),packageCacheDir:path.join(repo,'web/public/browser-runtime/pyodide-0.29.4/'),stdout(){},stderr:console.error});await loadJudgePackages(py,[]);
const virtual={};for(const [name,folder] of Object.entries(JSON.parse(process.env.BENCH_SOURCES))){const dest='/bench/'+name;virtual[name]=dest;py.FS.mkdirTree(dest);for(const n of fs.readdirSync(folder).filter(n=>n.endsWith('.py')||['LICENSE','NOTICE'].includes(n)))py.FS.writeFile(dest+'/'+n,fs.readFileSync(path.join(folder,n)));}
py.globals.set('paths_json',JSON.stringify(virtual));py.globals.set('bench_dtype',process.env.BENCH_DTYPE);py.runPython('import json\nbench_sources=json.loads(paths_json)');py.runPython(fs.readFileSync(path.join(root,'bench-average.py'),'utf8'));console.log(py.runPython('json.dumps(dict(result,pyodide="'+py.version+'"))'));
