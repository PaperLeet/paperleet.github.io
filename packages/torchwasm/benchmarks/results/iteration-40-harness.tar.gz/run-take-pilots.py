from pathlib import Path
import json, os, subprocess, time

r = Path(__file__).resolve().parent
py = r.parent/'torch-iteration-21/stride-dev-env/bin/python'
sources = dict(baseline=str(r/'baseline/stridetorch'),candidate=str(r/'prototype-take/stridetorch'))
receipts = {}
for runtime, dtype in [('cpu','float32'),('cpu','float64'),('wasm','float32'),('wasm','float64')]:
    name=f'take-{runtime}-{dtype}'
    args=[str(py),str(r/'bench-average.py')] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(r/'bench-average-wasm.mjs')]
    env=dict(os.environ,BENCH_SOURCES=json.dumps(sources),BENCH_DTYPE=dtype,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
    start=time.monotonic()
    with (r/(name+'.json')).open('w') as out,(r/(name+'.stderr.log')).open('w') as err:
        p=subprocess.run(args,cwd=r,env=env,stdout=out,stderr=err)
    receipts[name]=dict(exit_code=p.returncode,elapsed_s=time.monotonic()-start)
    (r/'take-pilot-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
    p.check_returncode()
    report=json.loads((r/(name+'.json')).read_text());assert len(report['results'])==36
    assert all(v['baseline']=='previous' for v in report['results'].values())
    print(name,'terminal0',flush=True)
