from pathlib import Path
import json, os, subprocess, time

r = Path(__file__).resolve().parent
out = r/'performance-targeted-followup'; out.mkdir(exist_ok=True)
py = r.parent/'torch-iteration-21/stride-dev-env/bin/python'
sources = dict(baseline=str(r/'baseline/stridetorch'), candidate=str(r/'proof/source'))
receipts = {}; reports = []
for runtime in ('cpu', 'wasm'):
    for dtype in ('float32', 'float64'):
        for reverse in ('0', '1'):
            name = f'{runtime}-{dtype}-reverse{reverse}'
            args = [str(py), str(r/'bench-library-targeted.py')] if runtime == 'cpu' else ['/opt/homebrew/bin/node', str(r/'bench-library-targeted-wasm.mjs')]
            env = dict(os.environ, BENCH_SOURCES=json.dumps(sources), BENCH_DTYPE=dtype,
                       BENCH_REVERSE=reverse, BENCH_LANE='inverse', OMP_NUM_THREADS='2',
                       MKL_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', VECLIB_MAXIMUM_THREADS='2')
            start = time.monotonic()
            with (out/(name+'.json')).open('w') as output, (out/(name+'.stderr.log')).open('w') as error:
                p = subprocess.run(args, cwd=r, env=env, stdout=output, stderr=error)
            receipts[name] = dict(exit_code=p.returncode, elapsed_s=time.monotonic()-start)
            (out/'receipts.json').write_text(json.dumps(receipts, indent=2)+'\n')
            p.check_returncode()
            report = json.loads((out/(name+'.json')).read_text())
            assert report['source_hashes']['candidate'] == json.loads((r/'proof/source-hashes.json').read_text())
            assert len(report['results']) == 4 and report['reverse_source_initialization'] == (reverse == '1')
            reports.append(dict(runtime=runtime, dtype=dtype, reverse=reverse, report=report))
            print(name, {k: round(v['median_time_reduction_percent'], 1) for k, v in report['results'].items()}, flush=True)
(r/'targeted-followup-summary.json').write_text(json.dumps(dict(
    scope='Diagnostic follow-up only:four old workflows,longer100-call samples,15ABBA/BAAB blocks,GC enabled,explicit collection outside each block,normal/reversed package initialization. Does not replace or discard original21-flow results.',
    receipts=receipts, reports=reports), indent=2)+'\n')
