from pathlib import Path
import cProfile,pstats,numpy as np
from stridetorch import torch
x=torch.tensor(np.random.default_rng(4002).normal(size=(2,4,17,23)).astype(np.float32),requires_grad=True)
def inference():return torch.nn.functional.adaptive_avg_pool2d(x,(5,3))
def backward():
 x.grad=None;inference().square().mean().backward()
for name,fn in [('forward',inference),('backward',backward)]:
 for _ in range(10):fn()
 profiler=cProfile.Profile();profiler.enable()
 for _ in range(300):fn()
 profiler.disable();print('PROFILE',name);pstats.Stats(profiler).sort_stats('tottime').print_stats(22)
