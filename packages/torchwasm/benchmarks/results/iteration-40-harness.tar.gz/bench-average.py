from pathlib import Path
import gc,hashlib,importlib.util,json,os,statistics,sys,time
import numpy as np
r=Path(__file__).resolve().parent if '__file__' in globals() else None
sources=globals().get('bench_sources') or json.loads(os.environ['BENCH_SOURCES'])
dtype=np.dtype(globals().get('bench_dtype') or os.getenv('BENCH_DTYPE','float32'));rng=np.random.default_rng(3907)
packages={}
for label,key in [('previous','baseline'),('current','candidate'),('scan','candidate')]:
 folder=Path(sources[key]);name='average_bench_'+label;spec=importlib.util.spec_from_file_location(name,folder/'__init__.py',submodule_search_locations=[str(folder)]);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);packages[label]=m
apis={k:v.torch for k,v in packages.items()}
scan_module=sys.modules[packages['scan'].__name__+'._average_pooling'];scan_module._ALGORITHM='scan';scan_module._BACKWARD_ALGORITHM='loop'

def flat(value):
 if value is None:return []
 if hasattr(value,'numpy'):return [value.detach().numpy()]
 return [x for v in value for x in flat(v)]
def check(left,right):
 a,b=flat(left),flat(right);assert len(a)==len(b)
 for x,y in zip(a,b):
  assert x.dtype==y.dtype and x.shape==y.shape
  np.testing.assert_allclose(x,y,rtol=1e-4 if dtype==np.float32 else 3e-10,atol=3e-6 if dtype==np.float32 else 3e-12,equal_nan=True)
  np.testing.assert_array_equal(np.isnan(x),np.isnan(y));np.testing.assert_array_equal(np.isinf(x),np.isinf(y))

def factory(shape,kw,mode,kind='adaptive',stress=None):
 a=rng.normal(size=shape).astype(dtype);v=rng.normal(size=shape).astype(dtype)
 if stress=='nonfinite':a.flat[::17]=np.inf
 if stress=='overflow':a[:]=1e38 if dtype==np.float32 else 1e308
 def build(label):
  api=apis[label];x=api.tensor(a,requires_grad=mode!='inference');direction=api.tensor(v,requires_grad=mode=='jvp')
  if kind=='adaptive':fn=lambda z:api.nn.functional.adaptive_avg_pool2d(z,**kw)
  elif kind=='area':fn=lambda z:api.nn.functional.interpolate(z,mode='area',**kw)
  else:fn=lambda z:api.nn.functional.avg_pool2d(z,**kw)
  def run():
   x.grad=None;direction.grad=None
   if mode=='jvp':p,t=api.func.jvp(fn,(x,),(direction,));t.square().mean().backward();return p,t,direction.grad
   y=fn(x)
   if mode=='backward':y.square().mean().backward();return y,x.grad
   return y
  return run
 return build

def cnn(size,training,fixed=False):
 n,c,h,w=(1,2,8,8) if size=='tiny' else (2,3,16,16);channels=3 if size=='tiny' else 6;classes=4
 a=rng.normal(size=(n,c,h,w)).astype(dtype);labels=rng.normal(size=(n,classes)).astype(dtype)
 spatial=(h//2)*(w//2) if fixed else 1;shapes=[(channels,c,3,3),(channels,),(classes,channels*spatial),(classes,)];weights=[rng.normal(size=s).astype(dtype)*.04 for s in shapes]
 def build(label):
  api=apis[label]
  class Head(api.nn.Module):
   def forward(self,x):return api.nn.functional.avg_pool2d(x,2) if fixed else api.nn.functional.adaptive_avg_pool2d(x,1)
  model=api.nn.Sequential(api.nn.Conv2d(c,channels,3,padding=1),api.nn.ReLU(),Head(),api.nn.Flatten(),api.nn.Linear(shapes[2][1],classes)).to(dtype=dtype);params=list(model.parameters())
  with api.no_grad():
   for p,value in zip(params,weights):p.copy_(api.tensor(value))
  x=api.tensor(a,requires_grad=training);target=api.tensor(labels);optimizer=api.optim.SGD(params,lr=.0001,momentum=.7)
  def run():
   if not training:
    with api.no_grad():return model(x)
   x.grad=None;optimizer.zero_grad(set_to_none=True);y=model(x);loss=api.nn.functional.mse_loss(y,target);loss.backward();optimizer.step()
   return y,loss,x.grad,*params,*[p.grad for p in params]
  return run
 return build

def paired(build,baseline):
 calibrate=build(baseline);calibrate();start=time.perf_counter();calibrate();elapsed=time.perf_counter()-start;loops=max(1,min(64,int(.003/max(elapsed,1e-7))))
 runs={label:build(label) for label in (baseline,'current')};last={}
 for label,run in runs.items():
  for _ in range(3):last[label]=run()
 check(*last.values());blocks=[]
 for block in range(9):
  order=(baseline,'current','current',baseline) if block%2==0 else ('current',baseline,baseline,'current');times={k:[] for k in runs};last={};gc.collect()
  for label in order:
   start=time.perf_counter()
   for _ in range(loops):value=runs[label]()
   times[label].append((time.perf_counter()-start)/loops);last[label]=value
  check(*last.values());a=statistics.mean(times[baseline]);b=statistics.mean(times['current']);blocks.append(dict(order=order,baseline_s=a,candidate_s=b,time_reduction_percent=100*(a-b)/a))
 return dict(baseline=baseline,loops=loops,blocks=blocks,median_time_reduction_percent=statistics.median(v['time_reduction_percent'] for v in blocks),baseline_median_us=statistics.median(v['baseline_s'] for v in blocks)*1e6,candidate_median_us=statistics.median(v['candidate_s'] for v in blocks)*1e6)

results={}
for name,shape,size in [('global',(2,8,16,16),1),('blocks',(2,8,16,16),4),('irregular',(2,4,17,23),(5,3)),('upsample',(1,2,5,7),(12,14)),('identity',(1,2,32,32),(32,32))]:
 for mode in ['inference','backward']:results['legacy-'+name+'-'+mode]=paired(factory(shape,dict(output_size=size),mode),'previous')
for mode in ['inference','backward']:results['legacy-area-'+mode]=paired(factory((2,4,17,23),dict(size=(5,3)),mode,'area'),'previous')
for size in ['tiny','image']:
 for train in [False,True]:results['legacy-cnn-'+size+('-sgd' if train else '-inference')]=paired(cnn(size,train),'previous')
for name,kw in [('block',dict(kernel_size=2)),('overlap',dict(kernel_size=3,stride=1,padding=1)),('ceil',dict(kernel_size=3,stride=2,padding=1,ceil_mode=True)),('divisor',dict(kernel_size=3,stride=2,padding=1,divisor_override=-3))]:
 for mode in ['inference','backward','jvp']:results['new-avg-'+name+'-'+mode]=paired(factory((2,4,16,18),kw,mode,'fixed'),'previous')
for mode in ['inference','backward']:
 for stress in ['nonfinite','overflow']:results['new-ieee-'+stress+'-'+mode]=paired(factory((1,2,8,10),dict(output_size=(3,2)),mode,stress=stress),'previous')
for size in ['tiny','image']:
 for train in [False,True]:results['new-cnn-'+size+('-sgd' if train else '-inference')]=paired(cnn(size,train,True),'previous')
result=dict(scope='Finite legacy adaptive/area/CNN flows compare0.39 with candidate. All existing avg/IEEE/CNN flows compare0.39 with candidate.9ABBA blocks,GC enabled,real SGD and output/dtype/gradient/updated-parameter checks. Shared host;requested vendor threads unverified;no nativeTorch or cross-runtime speed claim.',dtype=dtype.name,gc_enabled=gc.isenabled(),versions={k:v.__version__ for k,v in packages.items()},source_hashes={k:{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(m.__file__).parent.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')} for k,m in packages.items()},results=results)
if '__file__' in globals():print(json.dumps(result))
