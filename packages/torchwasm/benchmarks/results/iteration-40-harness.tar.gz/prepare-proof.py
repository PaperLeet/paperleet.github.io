from pathlib import Path
import hashlib, json, shutil, subprocess

r = Path(__file__).resolve().parent
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
old = r.parent/'torch-iteration-39/proof'
p = r/'proof'; p.mkdir()
source = repo/'packages/stridetorch/src/stridetorch'
for dest in (p/'source',p/'chrome-contracts/source'):
    shutil.copytree(source,dest,ignore=shutil.ignore_patterns('__pycache__'))
shutil.copytree(repo/'packages/stridetorch/tests',p/'chrome-contracts/tests',ignore=shutil.ignore_patterns('__pycache__'))
hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in source.iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')}
tests={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (repo/'packages/stridetorch/tests').glob('test_*.py') if f.name!='test_standalone.py'}
assert len(hashes)==49 and len(tests)==39
(p/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
(p/'chrome-contracts/plan.json').write_text(json.dumps(dict(version='0.40.0',expected=2243,source=hashes,tests=tests),indent=2)+'\n')
for name in ('chrome-contracts/run.mjs','chrome-contracts/worker.mjs','chrome-contracts/index.html','wasm-contracts.mjs','check-wheel.py','check-coinstall.py'):
    text=(old/name).read_text().replace('torch-iteration-39/proof','torch-iteration-40/proof').replace('0.39','0.40').replace('stride039','stride040').replace('2154','2243').replace('2167','2256')
    if name=='wasm-contracts.mjs':text=text.replace("'pooling','average_pooling'","'pooling','average_pooling','average_pooling_plans'")
    if name=='check-coinstall.py':
        marker="print('PASS isolated ownership,aliases,ZIP resume,triangular,Cholesky and Cholesky solve VJP/JVP/full tangent reverse')"
        assert marker in text
        extra="""plans=[]
for name in NAMES:
 m=importlib.import_module(name);api=m.torch
 a=np.arange(17*23,dtype=np.float64).reshape(1,1,17,23);a[...,::2]*=-1
 x=api.tensor(a,requires_grad=True);y=api.nn.functional.adaptive_avg_pool2d(x,(5,3));y.sum().backward()
 assert np.isfinite(x.grad.numpy()).all() and not np.shares_memory(x.numpy(),y.numpy())
 module=importlib.import_module(name+'._average_pooling');plan=module._cached_pack_plan(17,23,5,3,np.dtype('float64').str,False)
 assert plan is not None and plan.flat is not None and not plan.flat.flags.writeable
 plans.append(module._cached_pack_plan)
assert len({id(value) for value in plans}) == len(plans)
"""
        text=text.replace(marker,extra+marker)
    (p/name).write_text(text)
for name in ('run-gates.py','run-full.py'):
    (r/name).write_text((r.parent/'torch-iteration-39'/name).read_text())
state=json.loads((r/'state.json').read_text())
state.update(phase='Frozen0.40 candidate:49resources,39suites/2243browser/2256minimal.2027 focused final-source tests pass;prototypeWASM/random/performance passed,formal final-source gates pending.',version='0.40.0',upstream=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),source_hashes=hashes,expected_browser=2243,expected_minimal=2256,expected_full_minimum=34976)
(r/'state.json').write_text(json.dumps(state,indent=2)+'\n')
print('Frozen0.40:49resources,39suites/2243browser/2256minimum')
