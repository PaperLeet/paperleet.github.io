from pathlib import Path
import json

r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
out=repo/'packages/stridetorch/benchmarks/results'
core=json.loads((out/'iteration-40.json').read_text());app=json.loads((out/'iteration-40-integration.json').read_text())
full=core['full_cpu'];native=app['native'];wasm=app['exported_wasm']
def bounds(values):return f'{min(values):.1f} to {max(values):.1f}%'
t=f"""# StrideTorch 0.40: cached ordered average-pooling plans

Version 0.40 reduces repeated geometry work in 0.39's ordered kernels. Public
operators and supported numerical boundaries are unchanged; no GPU backend is
added. The independent package keeps its current name while browser-oriented
naming is under discussion. Main adoption has its own verification record;
package publication remains separate.

## Numerical behavior, ownership and bounded plans

Plans contain only readonly indices, masks and dtype-specific divisors. They
never retain user tensors, input arrays, gradient seeds or computed values.
The LRU holds at most 64 plans, each with at most 64 KiB of array data: 4 MiB
of array data across this new cache, excluding Python metadata. Existing
geometry/matrix caches retain their separate capacities.

Contiguous input can use flat spatial gathering; other layouts keep coordinate
gathering without copying the entire input to contiguous storage. Flat indices
are optional when they would exceed the per-plan byte cap. Large plans retain
the earlier bounded coordinate/tiled/streaming/scan paths, and huge inverse
indices still have a preallocation guard. The separate 32 MiB packing estimate
is not a total-process or output-allocation limit.

Both gathers own their new storage. Ordered accumulation, sum before scaling,
height-then-width division, local NaN/Inf behavior and cancellation residuals
are preserved. Mixed-sign planes still avoid matrix reassociation. The output
copies the final accumulated values so it retains no packed prefixes; final
+0 preserves native zero signs. Identity pullbacks skip redundant copying and
divisions by one. Storage-version and alias semantics remain covered.

## Final local validation

- Targeted native/independent/spatial/graph checks: **2,027 passes**.
- Full Python suite: **{full['passed']:,} passes, {full['skipped']} optional skip**,
  {full['duration_s']:.2f}s.
- Actual Node Pyodide and Chrome Worker: **2,243 checks in 39 suites each**,
  Pyodide 0.29.4 / NumPy 2.2.5, without native Torch in the browser runtime.
- Isolated Python 3.10 / NumPy 1.26 wheel: **2,256 passes**. Public/private
  wheels and source archives match all **49** source/license resources.
  Both namespaces retain cached-pooling ownership and independently survive
  the other's uninstall. An added test initially assumed two namespaces even
  after uninstall; its assertion was corrected, with no runtime/artifact change.
  The first failure is retained in the harness archive.
- Native random oracles: **720 trials / 8,575 gradient comparisons**, five
  forward and five backward paths, including dtype/geometry/IEEE boundaries.
- Original native catalog: **78 problems, 10,218 executions, 342 mutants,
  3 repeats**, {native['duration_s']:.2f}s, unchanged 600s budget.
- Actual exported WASM: **78/78 modules, 342 mutants**, {wasm['elapsed_ms']}ms,
  concurrency 2, no budget exceeded. Its attention runtime also executes the
  **2,243 independent contracts/39 suites** against the actual exported code.
- All **9,281** prior immutable payloads remain byte-identical, all **158** new
  payloads are reachable, and **161** active files are SHA-256 frozen. The
  smaller Schedules profile remains six resources. Full frontend checks and
  both typed builds pass on the recorded integration input.

Source comparison finds **47 byte-identical shared resources**; only version
metadata and average-pooling implementation change. Public API bytes and the
rest of the averaging AST are unchanged outside forward/backward dispatch,
three plan helpers, three globals and the namedtuple import. This supports,
but does not replace, the regression checks.

## Complete-flow timings against 0.39

All 36 averaging/area/CNN flows compare supported 0.39 APIs with 0.40. Eight
sequential fresh children cover two dtypes and two processes per CPU/WASM,
nine ABBA/BAAB blocks, warmups, GC enabled and equal call counts. Each block
checks outputs, gradients, dtypes and actual updated SGD/momentum parameters.
Negative time reductions mean slower. These measurements do not establish
native-Torch or cross-runtime throughput, nor recovery of every earlier
regression against 0.38's numerically incorrect weighted path.

| Complete flow | CPU time reduction | WASM time reduction |
| --- | ---: | ---: |
"""
for name,row in core['final_average_workflows']['summary']['cpu'].items():
    other=core['final_average_workflows']['summary']['wasm'][name]
    t+=f"| {name} | {bounds(row['median_time_reductions_percent'])} | {bounds(other['median_time_reductions_percent'])} |\n"
t+='\n## Other existing numerical controls\n\nTwenty-one old solve/inverse/JVP/SGD/Schedules flows use the same APIs and\noptional-feature lookup on both sides. Raw reports retain absolute times and\nall paired blocks, including outliers.\n\n| Existing flow | CPU time reduction | WASM time reduction |\n| --- | ---: | ---: |\n'
for name,row in core['final_existing_workflows']['summary']['cpu'].items():
    other=core['final_existing_workflows']['summary']['wasm'][name]
    t+=f"| {name} | {bounds(row['median_reductions_percent'])} | {bounds(other['median_reductions_percent'])} |\n"
t+='''
Prespecified longer-sample four-flow diagnostics and separate identical-source
A/A calibration retain all original measurements. Normal/reversed namespace
initialization and explicit GC collection outside paired blocks help inspect
sampling effects; they do not replace the main reports or establish a uniform
latency bound. Reverse-through-JVP also has a separate CPU follow-up. Shared
host activity and effective vendor thread counts remain uncontrolled. See
`diagnostic_existing_flow_followup` and `diagnostic_fairness` in the core report.

Sixteen alternating fresh CPU processes record cold namespace imports, with
NumPy included/preloaded reported separately. Raw source and gzip estimates
are separate from wire size, browser cold start and retained memory.

## Tracked allocation samples

Two warmed repeats cover each dtype and case. Forward samples include output;
the huge-adjoint case includes forward/backward. Persistent prewarmed cache
metadata is excluded. These are not process RSS, WASM memory or throughput.

| Case / dtype | 0.39 tracked peak bytes | 0.40 tracked peak bytes |
| --- | ---: | ---: |
'''
memory=core['pooling_memory']['rows']
for dtype in ('float32','float64'):
    for case in ('irregular','upsample','coordinate','huge-adjoint'):
        a=[v['traced_peak_bytes'] for v in memory if v['label']=='baseline' and v['dtype']==dtype and v['case']==case]
        b=[v['traced_peak_bytes'] for v in memory if v['label']=='candidate' and v['dtype']==dtype and v['case']==case]
        t+=f'| {case} / {dtype} | {min(a):,}–{max(a):,} | {min(b):,}–{max(b):,} |\n'
t+='''
The existing huge-narrow-input allocation bound remains verified. The new
cache's separately capped metadata is a deliberate memory/latency tradeoff.

## Reproduction and publication boundary

Both earlier prototypes, all pilot/final timing samples, random-oracle drivers,
exact source/test identities, package/runtime harnesses and retained failures
are in `iteration-40.json`, `iteration-40-integration.json` and their SHA-256
identified harness archives. See any later main-synchronization and adoption
records for their exact incoming files and verified commits.

This iteration uses NumPy CPU/Pyodide WASM. WebGPU still needs resident storage,
explicit transfers, compatible gradients and a measured whole-flow benefit
before it can become a backend. No GitHub CI, tag, workflow dispatch, package
upload or online publication was performed.
'''
(repo/'docs/validation/torch-runtime-iteration-40.md').write_text(t)
print('Wrote complete0.40 local validation record;main adoption separate')
