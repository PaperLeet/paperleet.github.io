from pathlib import Path
import hashlib,json,runpy,stridetorch
r=Path(__file__).resolve().parent;source=Path(stridetorch.__file__).parent
expected={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'prototype-take/stridetorch').iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
def actual():return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
for kind in ('integers','floats'):
 assert actual()==expected
 runpy.run_path(str(r/f'fuzz-plans-{kind}.py'),run_name='__main__')
 assert actual()==expected
 p=r/f'fuzz-plans-{kind}.json';s=json.loads(p.read_text());s.update(version=stridetorch.__version__,source_hashes=expected,algorithms=dict(forward=['scan','packed','auto','matrix','block'],backward=['loop','scatter','auto','packed','block']));p.write_text(json.dumps(s,indent=2)+'\n')
 print('HASHED RANDOM',kind,s['counts'],flush=True)
