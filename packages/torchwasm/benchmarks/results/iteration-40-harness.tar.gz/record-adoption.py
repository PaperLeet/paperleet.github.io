from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

r = Path(__file__).resolve().parent
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
def command(*args):
    return subprocess.check_output(args, cwd=repo, text=True).strip()
head = command('git', 'rev-parse', 'HEAD')
remote = command('git', 'ls-remote', '--exit-code', 'origin', 'refs/heads/main').split()[0]
assert head == remote
runs = json.loads(command('gh', 'api', f'repos/PaperLeet/paperleet.github.io/actions/runs?head_sha={head}&per_page=100'))
assert runs['total_count'] == 0 and not runs['workflow_runs']
expected = json.loads((r / 'proof/source-hashes.json').read_text())
actual = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo / 'packages/stridetorch/src/stridetorch').iterdir() if p.suffix == '.py' or p.name in ('LICENSE', 'NOTICE')}
assert actual == expected and len(actual) == 49
for name, digest in json.loads((r / 'integration-proof/live-expected-sha256.json').read_text()).items():
    assert hashlib.sha256((repo / 'web/public/data' / name).read_bytes()).hexdigest() == digest
policy = ['.github/workflows/ci.yml', '.github/workflows/pages.yml', 'web/scripts/check-release-request.cjs', 'web/scripts/pages-release-gate.cjs', 'web/scripts/check-pages-release.cjs', 'web/scripts/check-pages-backfill.cjs', 'docs/releasing.md']
for path in policy:
    assert command('git', 'diff', '13d2782a494415ba72bc604a0ef7e4c4f875ba25', 'HEAD', '--', path) == ''
record = dict(status='adopted_on_remote_main_without_actions', version='0.40.0',
              source_commit=head, verified_remote_main=remote,
              verified_at=datetime.now(timezone.utc).isoformat(), actions_total_count=0,
              source_hashes=actual, active_exports=161, policy_unchanged=policy,
              publication='No tag, workflow dispatch, package upload or online publication requested. The user will explicitly release later.')
path = repo / 'packages/stridetorch/benchmarks/results/iteration-40-main-adoption.json'
assert not path.exists()
path.write_text(json.dumps(record, indent=2)+'\n')
doc = repo / 'docs/validation/torch-runtime-iteration-40.md'
doc.write_text(doc.read_text()+f'\nValidated source was adopted non-force on remote `main` at `{head}`.\nA read-only query found zero Actions runs for this commit. See\n`iteration-40-main-adoption.json`; no tag, dispatch or online release was created.\n')
(r / 'actions-after-adoption.json').write_text(json.dumps(dict(head_sha=head, total_count=runs['total_count']), indent=2)+'\n')
print(json.dumps(dict(source_commit=head, actions=0)))
