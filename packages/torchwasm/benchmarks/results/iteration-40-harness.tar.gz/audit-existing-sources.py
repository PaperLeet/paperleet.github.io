from pathlib import Path
import ast, hashlib, json

r=Path(__file__).resolve().parent;old=r/'baseline/stridetorch';new=r/'proof/source'
def hashes(folder):return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
previous,candidate=hashes(old),hashes(new)
assert len(previous)==len(candidate)==49 and set(previous)==set(candidate)
changed={name for name in previous if previous[name]!=candidate[name]}
assert changed=={'__init__.py','_average_pooling.py'}
class Normalize(ast.NodeTransformer):
    def visit_ImportFrom(self,node):
        if node.module=='collections':return None
        return node
    def visit_FunctionDef(self,node):
        if node.name in ('_cached_pack_plan','_pack_plan','_packed_from_plan','_forward','_backward'):return None
        return self.generic_visit(node)
    def visit_Assign(self,node):
        if any(isinstance(v,ast.Name) and v.id in ('_PackingPlan','_PLAN_CACHE_BYTES','_CACHE_PLANS','__version__') for v in node.targets):return None
        return self.generic_visit(node)
for name in changed:
    left=ast.dump(Normalize().visit(ast.parse((old/name).read_text())),include_attributes=False)
    right=ast.dump(Normalize().visit(ast.parse((new/name).read_text())),include_attributes=False)
    assert left==right,name
report=dict(status='success',unchanged_resources=47,changed_existing=sorted(changed),new_resources=[],source_hashes=candidate,
    scope='Public API and all other47resources byte-identical. Existing average-pooling AST identical outside forward/backward dispatch,three new plan helpers,three cache globals and namedtuple import. Version assignment is the only init change.')
(r/'existing-source-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print('Verified47 unchanged resources;all public API bytes and other averaging AST preserved')
