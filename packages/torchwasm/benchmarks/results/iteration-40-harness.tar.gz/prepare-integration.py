from pathlib import Path
import hashlib, json, shutil, subprocess

r=Path(__file__).resolve().parent
repo=Path('/Users/david/Developer/PaperLeet-torch-release')
old=r.parent/'torch-iteration-39/integration-proof'
i=r/'integration-proof';i.mkdir()
upstream=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',upstream,'--','web/public/data/browser-judge','web/public/data/modules'],cwd=repo,text=True).splitlines()
assert len(paths)==9281,len(paths)
for name in ('verify-export.py','run-export.py','freeze.py','verify-private.py','run-frontend.py','run-setup.py','run-native.py','run-wasm.py'):
    text=(old/name).read_text().replace('0.39.0','0.40.0').replace('==9123','==9281').replace('2154','2243').replace('len(tests)==38','len(tests)==39').replace('expected_suites=38','expected_suites=39').replace('iteration39 integration','iteration40 integration').replace('torch-iteration-38/integration-proof/owned-dependencies.json','torch-iteration-39/integration-proof/owned-dependencies.json')
    (i/name).write_text(text)
source=json.loads((r/'proof/source-hashes.json').read_text());assert len(source)==49
for n,h in source.items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/n).read_bytes()).hexdigest()==h
(i/'context.json').write_text(json.dumps(dict(upstream=upstream,source_hashes=source,core_report='iteration-40.json',release_policy='No GitHub CI,tag,dispatch,package upload or online publication;user will tag later.',scope='All9281 prior immutable assets retained. Cache bounded readonly ordered pooling plans and use flat gather only for contiguous data;preserve IEEE/cancellation/ownership and huge-inverse preallocation guards. No new API or GPU backend. Fresh packages,current frontend,two builds,native/all exported WASM and complete-flow timings required.'),indent=2)+'\n')
shutil.copytree(r/'proof/private-dist',i/'dist-paperleet')
for name in ('bench-library.py','bench-library-wasm.mjs','bench-import.py','run-performance-final.py','run-imports.py','run-average-final.py','bench-library-targeted.py','bench-library-targeted-wasm.mjs','run-targeted-followup.py'):
    text=(r.parent/'torch-iteration-39'/name).read_text().replace('candidate_039','candidate_040').replace('previous_038','previous_039').replace('0.39.0','0.40.0').replace('0.38.0','0.39.0').replace('Same0.38/0.39','Same0.39/0.40')
    (r/name).write_text(text)
text=(r.parent/'torch-iteration-39/run-final-sequential.py').read_text().replace('34887','34976')
text=text.replace("('run-wasm.py',i,'wasm-runner.log')", "('run-targeted-followup.py',r,'targeted-followup-runner.log'),('run-wasm.py',i,'wasm-runner.log')")
text=text.replace('All5 final gates','All6 final gates')
(r/'run-final-sequential.py').write_text(text)
print('Prepared0.40 integration and sequential final comparisons against0.39')
