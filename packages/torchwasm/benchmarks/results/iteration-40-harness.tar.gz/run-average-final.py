from pathlib import Path
import json,os,shutil,subprocess,time,hashlib
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');folder=r/'proof/source';out=r/'average-performance-final';out.mkdir(exist_ok=True);receipts={};py=r.parent/'torch-iteration-21/stride-dev-env/bin/python'
sources=json.dumps(dict(baseline=str(r/'baseline/stridetorch'),candidate=str(folder)))
for repeat in (1,2):
 for runtime,dtype in ([('cpu','float32'),('cpu','float64'),('wasm','float32'),('wasm','float64')] if repeat==1 else [('wasm','float64'),('wasm','float32'),('cpu','float64'),('cpu','float32')]):
  name=f'average-final-{runtime}-{dtype}-{repeat}';args=[str(py),str(r/'bench-average.py')] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(r/'bench-average-wasm.mjs')];start=time.monotonic()
  with (out/(name+'.json')).open('w') as output,(out/(name+'.stderr.log')).open('w') as err:p=subprocess.run(args,cwd=r,env=dict(os.environ,BENCH_SOURCES=sources,BENCH_DTYPE=dtype,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2'),stdout=output,stderr=err)
  receipts[name]=dict(exit_code=p.returncode,elapsed_s=time.monotonic()-start);(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode()
  report=json.loads((out/(name+'.json')).read_text());assert report['source_hashes']['current']==report['source_hashes']['scan']==json.loads((r/'proof/source-hashes.json').read_text());assert report['versions']==dict(previous='0.39.0',current='0.40.0',scan='0.40.0');assert len(report['results'])==36
  print(name,'terminal0',flush=True)
summary={}
for runtime in ('cpu','wasm'):
 rows=[json.loads((out/f'average-final-{runtime}-{dtype}-{repeat}.json').read_text()) for dtype in ('float32','float64') for repeat in (1,2)]
 summary[runtime]={key:dict(baseline=rows[0]['results'][key]['baseline'],median_time_reductions_percent=[v['results'][key]['median_time_reduction_percent'] for v in rows],baseline_median_us=[v['results'][key]['baseline_median_us'] for v in rows],candidate_median_us=[v['results'][key]['candidate_median_us'] for v in rows]) for key in rows[0]['results']}
(r/'average-final-summary.json').write_text(json.dumps(dict(summary=summary,receipts=receipts,scope='Eight sequential paired children after heavy gates;float32/64,two fresh processes per runtime,36 complete workflows,nine ABBA/BAAB blocks,GC enabled,SGD output/gradient/updated-parameter parity. Legacy finite adaptive/area/CNN compares0.38;new fixed/IEEE/CNN compares same-source scan+loop. Shared host,unverified effective vendor threads,no uniform speedup or cross-runtime throughput claim.'),indent=2)+'\n')
