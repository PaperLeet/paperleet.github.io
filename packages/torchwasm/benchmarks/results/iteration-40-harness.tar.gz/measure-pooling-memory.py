from pathlib import Path
import gc, hashlib, importlib.util, json, sys, tracemalloc
import numpy as np

r=Path(__file__).resolve().parent;rows=[];hashes={}
cases=[('irregular',(2,4,17,23),(5,3),'forward'),
       ('upsample',(1,2,5,7),(12,14),'forward'),
       ('coordinate',(1,1,96,96),(23,25),'forward'),
       ('huge-adjoint',(1,1,2_000_000,1),(2,2),'backward')]
for label,folder in [('baseline',r/'baseline/stridetorch'),('candidate',r/'proof/source')]:
    name='memory40_'+label;spec=importlib.util.spec_from_file_location(name,folder/'__init__.py',submodule_search_locations=[str(folder)])
    package=importlib.util.module_from_spec(spec);sys.modules[name]=package;spec.loader.exec_module(package);api=package.torch
    hashes[label]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
    for dtype in [np.float32,np.float64]:
        for case,shape,size,mode in cases:
            data=np.random.default_rng(4006).normal(size=shape).astype(dtype)
            x=api.tensor(data,requires_grad=mode=='backward')
            def run():
                x.grad=None;y=api.nn.functional.adaptive_avg_pool2d(x,size)
                if mode=='backward':y.sum().backward()
                return y
            for _ in range(2):run()
            for repeat in range(2):
                gc.collect();tracemalloc.start();y=run();current,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
                if mode=='backward':np.testing.assert_array_equal(x.grad.numpy(),dtype(2e-6))
                assert y._data.base is None
                rows.append(dict(label=label,dtype=np.dtype(dtype).name,case=case,repeat=repeat,traced_peak_bytes=peak))
                del y
            del x,data;gc.collect()
assert hashes['candidate']==json.loads((r/'proof/source-hashes.json').read_text())
for dtype in ['float32','float64']:
    previous=[v['traced_peak_bytes'] for v in rows if v['label']=='baseline' and v['dtype']==dtype and v['case']=='huge-adjoint']
    current=[v['traced_peak_bytes'] for v in rows if v['label']=='candidate' and v['dtype']==dtype and v['case']=='huge-adjoint']
    assert max(current)<=max(previous)+16384,(dtype,previous,current)
(r/'pooling-memory.json').write_text(json.dumps(dict(status='success',source_hashes=hashes,rows=rows,
    scope='Two warmed repeats per dtype/case;forward allocation includes output,huge-adjoint case includes forward/backward. Tracked allocations exclude prewarmed persistent metadata and are not processRSS,WASM memory or throughput. New plan array cache remains separately capped at64x64KiB.'),indent=2)+'\n')
print('Verified tracked allocation samples and unchanged huge-adjoint allocation bound')
