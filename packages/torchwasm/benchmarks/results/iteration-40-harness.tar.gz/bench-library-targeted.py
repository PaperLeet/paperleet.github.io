"""Whole inverse-factor flows versus the existing 0.35 public solve composition."""
import gc, hashlib, importlib.util, json, os, statistics, sys, time
from pathlib import Path
import numpy as np
paths=globals().get('bench_sources') or json.loads(os.environ['BENCH_SOURCES'])
if globals().get('bench_reverse') or os.getenv('BENCH_REVERSE')=='1':paths=dict(reversed(list(paths.items())))
dtype=globals().get('bench_dtype',os.environ.get('BENCH_DTYPE','float64'))
packages={};hashes={}
for label,folder in paths.items():
    root=Path(folder);name='inverse_'+label
    spec=importlib.util.spec_from_file_location(name,root/'__init__.py',submodule_search_locations=[str(root)])
    package=importlib.util.module_from_spec(spec);sys.modules[name]=package;spec.loader.exec_module(package);packages[label]=package
    hashes[label]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
configs=[('tiny-inference',2,(),False),('small-inference',16,(),False),('large-inference',128,(),False),('upper-inference',128,(),True),('batch-inference',64,(4,),False),('tiny-backward',2,(),False),('small-backward',16,(),False),('large-backward',128,(),False),('sgd-factor',16,(),True),('optional-sgd',16,(),False),('spd-chain',64,(),False),('jvp',16,(),False),('large-jvp',128,(),True),('jvp-backward',16,(),True),('large-jvp-backward',64,(),False),('fixed-factor-jvp',128,(),False),('legacy-inference',32,(),False),('legacy-optional-inference',32,(),False),('generic-control',16,(),False),('cholesky-control',7,(),False),('unary-control',8,(),False)]
configs=[v for v in configs if v[0] in ('tiny-backward','jvp','generic-control','unary-control')]
results={}
for operation,n,batch,upper in configs:
    calls={};checks={}
    for label,package in packages.items():
        lib=importlib.import_module(package.__name__+'._legacy').install() if operation.startswith('legacy') else package.torch;tdtype=getattr(lib,dtype);rng=np.random.default_rng(36)
        raw=(rng.normal(size=batch+(n,n))*.02).astype(dtype);raw[...,np.arange(n),np.arange(n)]=2
        if operation.startswith('legacy'):raw=np.linspace(.0001,.02,n*n,dtype=dtype).reshape(n,n)
        active=not operation.endswith('inference') and operation!='fixed-factor-jvp'
        parameter=lib.tensor(raw,requires_grad=active);identity=lib.tensor(np.eye(n,dtype=dtype)) if operation.startswith('legacy') else lib.eye(n,dtype=tdtype);inputs=[parameter]
        def inverse(f,lib=lib,label=label,upper=upper,identity=identity):
            return lib.cholesky_inverse(f,upper)
        if 'jvp' in operation:
            direction=lib.full_like(parameter,.03,requires_grad=operation.endswith('backward') or operation=='fixed-factor-jvp');inputs.append(direction)
            def call(parameter=parameter,direction=direction,lib=lib,label=label,upper=upper,operation=operation,inverse=inverse):
                parameter.grad=direction.grad=None;f=parameter.triu() if upper else parameter.tril();df=direction.triu() if upper else direction.tril()
                x,t=lib.func.jvp(inverse,(f,),(df,))
                if operation.endswith('backward') or operation=='fixed-factor-jvp':(.17*x.square().mean()+.23*t.square().mean()).backward()
                return x,t
        else:
            optimizer=lib.optim.SGD([parameter],lr=.00001) if operation in ('sgd-factor','optional-sgd') else None
            def call(parameter=parameter,lib=lib,operation=operation,inverse=inverse,upper=upper,identity=identity,optimizer=optimizer,label=label,package_error=lib._browser_unsupported):
                parameter.grad=None
                if operation in ('optional-sgd','legacy-optional-inference'):
                    optional=getattr(lib,'not_a_real_torch_symbol_37',None)
                    assert optional is None
                if operation.startswith('legacy'):
                    alpha=(1-parameter).cumprod(0);x=alpha.sqrt()*identity+(1-alpha).sqrt()
                elif operation=='generic-control':x=lib.linalg.solve(parameter,identity)
                elif operation=='cholesky-control':x=lib.linalg.cholesky(parameter@parameter.transpose(-1,-2)+identity)
                elif operation=='unary-control':x=parameter.sin().exp().tanh()
                else:
                    f=lib.linalg.cholesky(parameter@parameter.transpose(-1,-2)+identity) if operation=='spd-chain' else parameter.triu() if upper else parameter.tril()
                    x=inverse(f)
                if not operation.endswith('inference'):x.square().mean().backward()
                if optimizer is not None:optimizer.step()
                return (x,)
        calls[label]=call
        def check(call=call,inputs=inputs):
            outputs=call()
            return [x.detach().numpy().copy() for x in outputs]+[None if x.grad is None else x.grad.numpy().copy() for x in inputs]+[x.numpy().copy() for x in inputs]
        checks[label]=check
    loops=100;warmup=50
    for call in calls.values():
        for _ in range(warmup):call()
    gc.collect();before=gc.get_stats();blocks=[]
    for block in range(15):
        gc.collect()
        order=('baseline','candidate','candidate','baseline') if block%2==0 else ('candidate','baseline','baseline','candidate');times={'baseline':[],'candidate':[]}
        for label in order:
            start=time.perf_counter()
            for _ in range(loops):calls[label]()
            times[label].append((time.perf_counter()-start)*1e6/loops)
        blocks.append(dict(samples_us=times,time_reduction_percent=100*(1-statistics.mean(times['candidate'])/statistics.mean(times['baseline']))))
    values={label:check() for label,check in checks.items()}
    for a,b in zip(values['candidate'],values['baseline']):
        if b is None:assert a is None
        else:
            assert a.dtype==b.dtype==np.dtype(dtype);np.testing.assert_allclose(a,b,rtol=8e-5,atol=6e-6)
    results[operation]=dict(n=n,batch=batch,upper=upper,loops_per_sample=loops,warmup=warmup,blocks=blocks,median_time_reduction_percent=statistics.median(x['time_reduction_percent'] for x in blocks),gc_before=before,gc_after=gc.get_stats(),checks='All output channels, dtypes, gradients and updated parameter states matched')
result=dict(reverse_source_initialization=bool(globals().get('bench_reverse') or os.getenv('BENCH_REVERSE')=='1'),versions={k:v.__version__ for k,v in packages.items()},python=sys.version,numpy=np.__version__,dtype=dtype,source_hashes=hashes,results=results,scope='Targeted follow-up:4 existing workflows,15 ABBA/BAAB blocks,100 iterations/sample,explicit GC collection outside each block,normal/reversed package initialization order, GC enabled and real SGD. Same0.39/0.40inverse APIs and native ordered JVPs on both sides. Optional-SGD and optional legacy inference use identical Python default lookup in both namespaces; all numerical/state checks match. Shared host; requested thread limits unverified; no CPU/WASM or nativeTorch throughput comparison.')
if 'bench_sources' not in globals():print(json.dumps(result))
