from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent;i=r/'integration-proof';py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';receipts=[];start=time.monotonic()
while True:
 front=json.loads((i/'frontend-receipts.json').read_text()) if (i/'frontend-receipts.json').exists() else []
 setup=json.loads((i/'setup-receipts.json').read_text()) if (i/'setup-receipts.json').exists() else []
 full=json.loads((r/'full-root-receipt.json').read_text()) if (r/'full-root-receipt.json').exists() else None
 assert all(v['exit_code']==0 for v in front+setup)
 if full is not None:assert full['exit_code']==0 and full['passed']>=34976 and full['skipped']==1
 if len(front)==5 and len(setup)==4 and full:break
 if time.monotonic()-start>1200:raise RuntimeError('Heavy local gates not complete within20minutes')
 time.sleep(5)
gates=json.loads((r/'proof/gate-receipts.json').read_text());assert len(gates)==6 and all(v['exit_code']==0 for v in gates.values())
print('All heavy/package gates terminal0; sequential native,old controls,new averaging,imports,all WASM',flush=True)
for script,folder,logname in [('run-native.py',i,'native-runner.log'),('run-performance-final.py',r,'performance-final-runner.log'),('run-average-final.py',r,'average-final-runner.log'),('run-imports.py',r,'imports-runner.log'),('run-targeted-followup.py',r,'targeted-followup-runner.log'),('run-wasm.py',i,'wasm-runner.log')]:
 started=time.monotonic();env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
 with (folder/logname).open('w') as log:p=subprocess.run([str(py),str(folder/script)],cwd=folder,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(script=script,exit_code=p.returncode,elapsed_s=time.monotonic()-started));(r/'final-sequential-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(script,'terminal',p.returncode,flush=True);p.check_returncode()
print('All6 final gates terminal0',flush=True)
