import fs from 'node:fs';import path from 'node:path';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const repo='/Users/david/Developer/PaperLeet-torch-release';const root=path.dirname(new URL(import.meta.url).pathname);
const py=await loadPyodide({indexURL:path.join(repo,'web/node_modules/pyodide/'),packageCacheDir:path.join(repo,'web/public/browser-runtime/pyodide-0.29.4/'),stdout:console.error,stderr:console.error});await loadJudgePackages(py,[]);
const paths=JSON.parse(process.env.BENCH_SOURCES);const virtual={};
for(const [label,folder] of Object.entries(paths)){
 const dest='/bench/'+label;py.FS.mkdirTree(dest);virtual[label]=dest;
 for(const name of fs.readdirSync(folder).filter(n=>n.endsWith('.py')||['LICENSE','NOTICE'].includes(n)))py.FS.writeFile(dest+'/'+name,fs.readFileSync(path.join(folder,name)));
}
py.globals.set('bench_paths_json',JSON.stringify(virtual));py.globals.set('bench_dtype',process.env.BENCH_DTYPE);py.globals.set('bench_lane',process.env.BENCH_LANE);
py.globals.set('bench_reverse',process.env.BENCH_REVERSE==='1');py.runPython('import json\nbench_sources=json.loads(bench_paths_json)');py.runPython(fs.readFileSync(path.join(root,'bench-library-targeted.py'),'utf8'));
console.log(py.runPython('json.dumps(dict(result,pyodide="'+py.version+'"))'));
