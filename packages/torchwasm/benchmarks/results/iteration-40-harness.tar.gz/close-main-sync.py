from pathlib import Path
import hashlib, json, shutil, tarfile, subprocess

r = Path(__file__).resolve().parent
s = r/'main-sync-proof'
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
out = repo/'packages/stridetorch/benchmarks/results'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
context = json.loads((s/'context.json').read_text())
front = json.loads((s/'frontend-receipts.json').read_text())
assert len(front) == 5 and all(v['exit_code'] == 0 for v in front)
assert len(context['source_hashes']) == 49 and len(context['active_export_sha256']) == 161
late = json.loads((out/'iteration-40-main-sync-final.json').read_text())
assert all(v['exit_code'] == 0 for v in late['receipts'])
subprocess.check_call(['git','merge-base','--is-ancestor',context['upstream'],late['context']['upstream']],cwd=repo)
superseded = {}
for n, v in context['changed_files'].items():
    assert sha(s/'incoming'/n) == v
    blob = subprocess.check_output(['git','show',context['upstream']+':'+n],cwd=repo)
    assert hashlib.sha256(blob).hexdigest() == v
    if sha(repo/n) != v:
        assert late['context']['changed_files'].get(n) == sha(repo/n)
        superseded[n] = dict(validated_snapshot=v,later_validated=sha(repo/n),upstream=late['context']['upstream'])

for n, v in context['source_hashes'].items(): assert sha(repo/'packages/stridetorch/src/stridetorch'/n) == v
for n, v in context['active_export_sha256'].items(): assert sha(repo/'web/public/data'/n) == v
shutil.copy2(Path(__file__), s/'close-main-sync.py')
archive = out/'iteration-40-main-sync-harness.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for path in sorted(s.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            tar.add(path, arcname=str(path.relative_to(s)), recursive=False)
report = dict(status='complete_local_latest_frontend_passed_runtime_identity_unchanged',
    version='0.40.0', context=context, frontend_receipts=front, later_validated_updates=superseded,
    archive=dict(file=archive.name, bytes=archive.stat().st_size, sha256=sha(archive)),
    scope='Incoming changes are frontend/styles/checks/documentation only; no Python,package,problem,catalog,runtime,export or release-policy input changed. Existing full numerical and real WASM evidence retains exact source and payload identities.',
    publication='No GitHub CI,tag,dispatch,package upload or online publication.')
(out/'iteration-40-main-sync.json').write_text(json.dumps(report, indent=2)+'\n')
doc = repo/'docs/validation/torch-runtime-iteration-40.md'
doc.write_text(doc.read_text()+f'''
Initial synchronization retains the validated six incoming frontend/style/check/
documentation files through `{context["upstream"]}`. Later changes to overlapping
files are identified and verified in the supplementary record. Full frontend
checks and both typed builds pass on this snapshot. All 49 computational/license
resources and 161 active exports retain their full-test identities. Python,
package,problem and catalog inputs did not change. See `iteration-40-main-sync.json`.
''')
print(json.dumps(dict(upstream=context['upstream'], source_unchanged=49, exports_unchanged=161, archive=report['archive'])))
