from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip()
remote=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/git/ref/heads/main','--jq','.object.sha'],cwd=repo,text=True).strip();subprocess.run(['git','fetch','origin',remote],cwd=repo,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
changes=subprocess.check_output(['git','diff','--name-only','a97c4966a716d69ed41e7495391b2092521227ad',remote],cwd=repo,text=True).splitlines();assert all(n.startswith(('web/src/','web/scripts/','docs/')) for n in changes),changes
before=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();subprocess.run(['git','merge','--no-edit',remote,'-m','Merge current main before GPU protocol negotiation adoption [skip ci]'],cwd=repo,check=True,stdout=subprocess.PIPE,text=True);head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
allowed=set(read(b/'torch-iteration-578/commit-receipt.json')['paths']);delta=subprocess.check_output(['git','diff','--name-only',remote,head],cwd=repo,text=True).splitlines();assert set(delta)==allowed,(delta,allowed)
inputs=read(b/'torch-iteration-515/source-plan.json')['inputs']
def verify():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
 for n,h in inputs.items():assert sha(Path(n))==h,n
 for n,h in read(b/'torch-iteration-511/live-export-sha256.json').items():assert sha(repo/'web/public/data'/n)==h,n
 for n,h in read(b/'torch-iteration-525/release-policy-identity.json')['files'].items():assert sha(repo/n)==h,n
verify();write(r/'merge-receipt.json',dict(head=head,previous_local_head=before,remote_baseline=remote,remote_existing_frontend_changes=changes,our_delta=delta,our_scope='Only developer benchmark/helper/tests/docs/evidence; no application/default runtime delta from current remote',runtime_resources_unchanged=66,exports_unchanged=183,package_inputs_unchanged=len(inputs),prototype_sha256=sha(repo/'packages/stridetorch/benchmarks/webgpu_rpc/rpc-protocol.mjs'),ci_triggered=False))
node='/Users/david/.local/share/fnm/node-versions/v22.22.1/installation/bin/node';env=dict(os.environ);env['PATH']=str(Path(node).parent)+':'+env['PATH'];receipts=[]
checks={n for n in changes if n.startswith('web/scripts/check-') and n.endswith('.mjs')};checks.update({'web/scripts/check-community-card-actions.mjs','web/scripts/check-card-comment-search.mjs'})
write(r/'execution-plan.json',dict(head=head,runner_sha256=sha(Path(__file__)),checks=sorted(checks),package_inputs=inputs,our_files={n:sha(repo/n) for n in delta},frontend_inputs={n:sha(repo/n) for n in changes}))
for script in sorted(checks):
 verify();label=Path(script).stem;start=time.monotonic();command=[node,str(Path(script).relative_to('web'))]
 with (r/(label+'.log')).open('w') as log:code=subprocess.run(command,cwd=repo/'web',env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 receipt=dict(label=label,exit_code=code,seconds=time.monotonic()-start,command=command,log_sha256=sha(r/(label+'.log')));receipts.append(receipt);write(r/'receipts.json',receipts);print(json.dumps(receipt),flush=True);assert code==0,label
verify();write(r/'result.json',dict(status='passed_current_main_benchmark_only_integration',head=head,remote_baseline=remote,own_delta=delta,package_inputs_unchanged=len(inputs),runtime_resources_unchanged=66,exports_unchanged=183,receipts=receipts,new_application_build_claimed=False,ci_triggered=False,goal_status='active'));print(head)
