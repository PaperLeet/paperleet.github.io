from pathlib import Path
import hashlib,io,json,shutil,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((r/'result.json').read_text())['status']=='verified_main_experimental_matrix_rpc_negotiation_without_ci'
files=sorted(p for folder in [r,b/'torch-iteration-576',b/'torch-iteration-577',b/'torch-iteration-578',b/'torch-iteration-579',b/'torch-iteration-580',b/'torch-iteration-582'] for p in folder.iterdir() if p.is_file() and p.name!='archive-receipt.json' and p.suffix!='.gz')
manifest={str(p.relative_to(b)):sha(p) for p in files};target=r/'protocol-negotiation-main-adoption-harness.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as stream:
 for p in files:stream.add(p,arcname=str(p.relative_to(b)),recursive=False)
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256.json');info.size=len(data);stream.addfile(info,io.BytesIO(data))
with tarfile.open(target) as stream:
 for n,h in manifest.items():assert hashlib.sha256(stream.extractfile(n).read()).hexdigest()==h,n
receipt=dict(path='packages/stridetorch/benchmarks/results/'+target.name,sha256=sha(target),bytes=target.stat().st_size,files=len(files),all_payloads_verified=True);(r/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');summary=json.loads((r/'result.json').read_text());summary['raw_archive']=receipt
(repo/'packages/stridetorch/benchmarks/results/protocol-negotiation-main-adoption.json').write_text(json.dumps(summary,indent=2)+'\n');shutil.copy2(target,repo/receipt['path']);print(json.dumps(receipt))
