from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;s=r/'main-sync-final-proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
context=json.loads((s/'context.json').read_text());receipts=json.loads((s/'receipts.json').read_text())
assert len(receipts)==7 and all(v['exit_code']==0 for v in receipts)
earlier=json.loads((out/'iteration-41-main-sync.json').read_text());superseded={}
for name,digest in context['changed_files'].items():
    assert sha(s/'incoming'/name)==sha(repo/name)==digest
    assert hashlib.sha256(subprocess.check_output(['git','show',context['upstream']+':'+name],cwd=repo)).hexdigest()==digest
for name,digest in earlier['context']['changed_files'].items():
    assert sha(r/'main-sync-proof/incoming'/name)==digest
    assert hashlib.sha256(subprocess.check_output(['git','show',earlier['context']['upstream']+':'+name],cwd=repo)).hexdigest()==digest
    if sha(repo/name)!=digest:
        assert context['changed_files'][name]==sha(repo/name)
        superseded[name]=dict(previous_validated=digest,current_validated=sha(repo/name))
for name,digest in context['source_hashes'].items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==digest
for name,digest in context['active_export_sha256'].items():assert sha(repo/'web/public/data'/name)==digest
for name,digest in json.loads((r/'canonical-policy-identity.json').read_text())['hashes'].items():assert sha(repo/name)==digest
shutil.copy2(Path(__file__),s/'close-main-sync-final.py')
archive=out/'iteration-41-main-sync-final-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for path in sorted(s.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:tar.add(path,arcname=str(path.relative_to(s)),recursive=False)
report=dict(status='complete_local_later_frontend_passed_runtime_identity_unchanged',version='0.41.0',context=context,receipts=receipts,superseded_earlier_files=superseded,
            archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),
            scope='Three subsequent frontend/check/documentation updates. Five affected UI suites and both typed builds pass; all49 computational/license and161 active-export identities retain the full CPU/native/WASM proof. Earlier25-file frontend validation retained with explicit one-file supersession.',
            publication='Local validation only; externally dispatched quality/Pages chain must finish before non-force main adoption. No tag,dispatch,package upload or online publication by this task.')
(out/'iteration-41-main-sync-final.json').write_text(json.dumps(report,indent=2)+'\n')
doc=repo/'docs/validation/torch-runtime-iteration-41.md'
doc.write_text(doc.read_text()+f'\nThree later frontend/check/documentation changes through `{context["upstream"]}`\nwere retained by a local rebase. Five affected suites and both typed builds pass;\nall 49 source/license and 161 active-export hashes remain exact. The earlier\nCommunity.tsx snapshot is explicitly superseded by this tested snapshot. See\n`iteration-41-main-sync-final.json` and its harness. No numerical/catalog input\nchanged, and no numerical gate was replaced by frontend-only evidence.\n')
print(json.dumps(dict(upstream=context['upstream'],changed=3,superseded=len(superseded),source_unchanged=49,exports_unchanged=161,archive=report['archive'])))
