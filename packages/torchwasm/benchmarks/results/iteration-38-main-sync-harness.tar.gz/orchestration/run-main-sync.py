from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;s=r/'main-sync-proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release');py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';receipts=[]
plans=[('fresh-private',['/Users/david/.local/bin/uv','build','--out-dir',str(s/'dist-paperleet')],repo),('verify-private',[str(py),str(s/'verify-private.py')],repo),('fresh-coinstall',[str(py),str(s/'check-coinstall.py')],repo),('backend-catalog',[str(py),'-m','pytest','tests/test_catalog.py','tests/test_interview_catalog.py','-q'],repo),('frontend',[str(py),str(s/'run-frontend.py')],repo)]
for name,args,cwd in plans:
 start=time.monotonic()
 with (s/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=cwd,env=dict(os.environ,PATH='/opt/homebrew/bin:'+os.environ['PATH'],OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2'),stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(name=name,args=args,cwd=str(cwd),exit_code=p.returncode,elapsed_s=time.monotonic()-start));(s/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,'terminal',p.returncode,flush=True);p.check_returncode()
