from pathlib import Path
import hashlib,json,re,shutil,tarfile
r=Path(__file__).resolve().parent;s=r/'main-sync-proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(name):return json.loads((s/name).read_text())
context=read('context.json');receipts=read('receipts.json');front=read('frontend-receipts.json');private=read('distribution-identity.json');coinstall=read('coinstall-result.json')
assert len(receipts)==5 and len(front)==5 and all(v['exit_code']==0 for v in receipts+front)
assert private['status']==coinstall['status']=='success' and coinstall['source_hashes']==context['source_hashes']
for n,v in context['changed_files'].items():assert sha(repo/n)==sha(s/'incoming'/n)==v
for n,v in context['source_hashes'].items():assert sha(repo/'packages/stridetorch/src/stridetorch'/n)==v
for n,v in context['active_export_sha256'].items():assert sha(repo/'web/public/data'/n)==v
count=re.search(r'(\d+) passed',(s/'backend-catalog.log').read_text());assert count and int(count[1])==25
for name in ('prepare-main-sync.py','run-main-sync.py','close-main-sync.py'):
 target=s/'orchestration'/name;target.parent.mkdir(exist_ok=True);shutil.copy2(r/name,target)
archive=out/'iteration-38-main-sync-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for f in sorted(s.rglob('*')):
  if f.is_file() and not any(p.endswith('-env') or p in ('dist-paperleet','__pycache__') for p in f.relative_to(s).parts):tar.add(f,arcname=str(f.relative_to(s)),recursive=False)
report=dict(status='complete_local_latest_catalog_private_package_backend_and_frontend_passed',version='0.38.0',context=context,receipts=receipts,frontend_receipts=front,backend_catalog_passed=25,distribution_identity=private,fresh_coinstall=coinstall,archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),publication='No CI, tag, workflow dispatch or online release requested.')
(out/'iteration-38-main-sync.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
doc=repo/'docs/validation/torch-runtime-iteration-38.md';doc.write_text(doc.read_text()+f'\nFinal main synchronization preserves all eight incoming preparation/catalog/UI\nfiles through `{context["upstream"]}` byte-for-byte. A freshly rebuilt private\nwheel/source archive contains the current interview catalog, passes source and\npublic/private ownership checks, and survives coinstall/uninstall. Affected\nbackend catalog tests pass 25 cases; the complete frontend check and both typed\nbuilds pass again. All 48 computational resources and 161 current exports remain\nunchanged. The full numerical/WASM gates above retain their original source and\nexport identities. See `iteration-38-main-sync.json`.\n')
print(json.dumps(dict(upstream=context['upstream'],backend=25,source_unchanged=48,exports_unchanged=161,archive=report['archive'])))
