from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;s=r/'main-sync-proof';s.mkdir();repo=Path('/Users/david/Developer/PaperLeet-torch-release')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();files=subprocess.check_output(['git','diff','--name-only','d06cf1d9..HEAD'],cwd=repo,text=True).splitlines();assert len(files)==8
source=json.loads((r/'proof/source-hashes.json').read_text());exports=json.loads((r/'integration-proof/live-expected-sha256.json').read_text());assert len(source)==48 and len(exports)==161
for n,v in source.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/n)==v
for n,v in exports.items():assert sha(repo/'web/public/data'/n)==v
for n in files:
 target=s/'incoming'/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/n,target)
(s/'context.json').write_text(json.dumps(dict(previous_upstream='d06cf1d9e65e8694cf89dddc364f0b7780231556',upstream=head,changed_files={n:sha(repo/n) for n in files},source_hashes=source,active_export_sha256=exports,scope='Incoming generation-targets/gradients preparation catalog and UI; fresh private package/catalog and coinstall plus affected backend tests, full frontend and two typed builds. No numerical/runtime/export input changes.'),indent=2)+'\n')
(s/'source-hashes.json').write_text(json.dumps(source,indent=2)+'\n')
for name in ['verify-private.py','run-frontend.py']:shutil.copy2(r/'integration-proof'/name,s/name)
text=(r/'proof/check-coinstall.py').read_text().replace("r/'dist-preflight'","r.parent/'proof/dist-preflight'").replace("r/'private-dist'","r/'dist-paperleet'");(s/'check-coinstall.py').write_text(text)
print('Prepared main-sync',head,'8files; source48/export161 unchanged')
