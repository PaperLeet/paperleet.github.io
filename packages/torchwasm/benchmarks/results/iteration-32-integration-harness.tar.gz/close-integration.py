from pathlib import Path
import hashlib,json,os,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
def read(name):return json.loads((r/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
context=read('context.json');expected=context['source_hashes'];assert len(expected)==47 and expected==json.loads((r.parent/'proof-refined/source-hashes.json').read_text())
for name,h in expected.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==h
native=read('native-ci.json');assert native['passed'] and not native['issues'] and native['problems']==78 and native['tests_executed']==10218 and native['repeats']==3 and native['duration_s']<=600 and sum(map(len,native['mutation'].values()))==342
wasm=read('full-wasm-result.json');assert wasm['passed'] and wasm['scope']=='catalog' and wasm['modules']==wasm['catalog_modules']==78 and len(wasm['results'])==78 and not wasm['browser_budget_exceeded'] and sum(c['mutants'] for c in wasm['results'])==342
for c in wasm['results']:
 b=c['budgets'];assert c['passed'] and not c['browser_budget_exceeded'] and c['calibration_ms']<=b['calibration'] and c['learner_ms']<=b['run'] and c['preparation_ms']+c['calibration_ms']+c['learner_ms']<=b['total']
contracts=next(c['independent_contracts'] for c in wasm['results'] if 'independent_contracts' in c);harness=read('wasm-harness-identity.json');assert contracts['passed']==1128 and len(contracts['suites'])==32 and {c['suite']:c['source_sha256'] for c in contracts['suites']}==harness['test_hashes']
assert sha(repo/harness['file'])==harness['sha256'] and sha(repo/harness['driver_file'])==harness['driver_sha256']
exports=read('live-expected-sha256.json');assert len(exports)==161
for name,h in exports.items():assert sha(repo/'web/public/data'/name)==h and sha(r/'live-expected'/name)==h
subprocess.run([str(r.parent.parent/'torch-iteration-21/stride-dev-env/bin/python'),str(r/'verify-export.py')],cwd=repo,stdout=subprocess.DEVNULL,check=True)
identity=read('export-identity.json');assert identity['published_assets_unchanged']==7862 and identity['all_new_assets_reachable'] and identity['new_assets']==158 and identity['active_assets']==158
private=read('distribution-identity.json');assert private['status']=='success' and private['core_modules']==45 and private['all_47_core_license_hashes_identical'] and private['installed_paths_disjoint'] and private['latest_application_catalog_and_server_identical']
front=read('frontend-receipts.json');setup=read('setup-receipts.json');assert len(front)==5 and len(setup)==4 and all(v['exit_code']==0 for v in front+setup)
assert read('native-receipt.json')['exit_code']==read('wasm-receipt.json')['exit_code']==0
profile=read('pages-profile.json');assert profile['observed_value'] in ('0','1')
for name in ('web/package.json','web/package-lock.json'):assert (repo/name).read_bytes()==subprocess.check_output(['git','show',context['upstream']+':'+name],cwd=repo)
files=[]
for directory,dirs,names in os.walk(r):
 dirs[:]=[d for d in dirs if d not in ('__pycache__','dist-paperleet')]
 for name in names:
  p=Path(directory)/name
  if p.suffix in ('.py','.json','.mjs','.log'):files.append(p)
archive=out/'iteration-32-integration-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
report=dict(status='complete_local_application_gates_passed_main_adoption_pending',version='0.32.0',upstream=context['upstream'],source_hashes=expected,core_report='iteration-32.json',native=native,wasm={k:v for k,v in wasm.items() if k!='results'},independent_contracts=contracts,export_identity=identity,export_sha256=exports,distributions=private,runtime_sizes=read('runtime-sizes.json'),owned_dependencies=read('owned-dependencies.json'),frontend_receipts=front,setup_receipts=setup,pages_profile=profile,archive=dict(file=archive.name,files=len(files),bytes=archive.stat().st_size,sha256=sha(archive)),scope='Original catalog,all tests/mutants,three native repeats and original600s/per-module WASM budgets retained. All7862 prior immutable assets retained;all158 new assets reachable. No TSX,judge/problem,backend,dependency or lock edits;full frontend and default/actual Pages-profile builds pass. Source47 hashes match refined core,minimal wheel,Node/Chrome and paired performance. Remote deployment remains a separate gate.')
(out/'iteration-32-integration.json').write_text(json.dumps(report,indent=2)+'\n');(r.parent/'integration-gates.json').write_text(json.dumps(report,indent=2)+'\n');s=json.loads((r.parent/'state.json').read_text());s.update(phase='0.32 complete local app integration validated;main adoption next',integration_report='iteration-32-integration.json',integration_archive=report['archive']);(r.parent/'state.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(dict(status=report['status'],native_s=native['duration_s'],wasm_ms=wasm['elapsed_ms'],archive=report['archive']),indent=2))
