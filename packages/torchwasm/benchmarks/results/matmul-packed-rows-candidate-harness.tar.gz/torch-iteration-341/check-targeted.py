import hashlib
import json
from pathlib import Path
import sys
import time

root = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(root/'runtime'))
import stridetorch
import numpy as np
import pytest
assert Path(stridetorch.__file__).resolve().parent == root.parent/'torch-iteration-340/candidate'
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
tests = [repo/'packages/stridetorch/tests'/name for name in
         ('test_matmul_wasm.py','test_matrix_products.py','test_vector_products.py','test_batched_matmul_wasm.py')]
hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in tests}
source = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(stridetorch.__file__).parent.iterdir() if p.is_file()}
start=time.perf_counter()
status=pytest.main([*(str(p) for p in tests), '-q', '-p', 'no:cacheprovider', '--basetemp='+str(root/('pytest-tmp-'+sys.argv[1]))])
assert hashes == {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in tests}
assert source == {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(stridetorch.__file__).parent.iterdir() if p.is_file()}
report=dict(status=int(status), python=sys.version, numpy=np.__version__, source=str(Path(stridetorch.__file__).resolve()),
            runtime_sha256=source, test_sha256=hashes, elapsed_seconds=time.perf_counter()-start,
            scope='Existing four matrix suites, forced WASM kernel controls with random values/VJP/JVP/HVP, layouts, exceptional fallback and saved mutation guards. No full SDK/application/performance gate.')
(root/(sys.argv[1]+'-result.json')).write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(int(status))
