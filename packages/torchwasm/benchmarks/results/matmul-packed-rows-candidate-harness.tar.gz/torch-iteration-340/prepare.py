import hashlib
import json
from pathlib import Path
import shutil

root=Path(__file__).resolve().parent
source=Path('/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src/stridetorch')
for label in ('baseline','candidate'):
    (root/label).mkdir()
    for p in source.iterdir():
        if p.is_file() and (p.suffix=='.py' or p.name in ('LICENSE','NOTICE')):
            shutil.copy2(p,root/label/p.name)
p=root/'candidate/_matmul.py'
s=p.read_text()
before="return np.ascontiguousarray(np.einsum('ik,kj->ij', a, b, optimize=False))"
after="return np.ascontiguousarray(np.einsum('ik,jk->ij', np.ascontiguousarray(a), np.ascontiguousarray(b.T), optimize=False))"
assert s.count(before)==1
p.write_text(s.replace(before,after))
hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
plan=dict(source_commit='a09b33b0',source_version='0.80.0',files=hashes,
          change='Only eligible2D WASM contraction: pack both reduction rows, then einsum ik,jk; all guards and native CPU routing unchanged.',
          purpose='One-process exploratory scan, full Torch forward/twoVJP/threecopies. Compare identical A0/A1baseline with packed candidate B. All6 orders; no favorable reruns. No runtime adoption.',
          cases='128/256 float32/float64 C/F/strided plus512float32C and64float32C;14finite dyadic cases.',
          next='If promising, extend native/random/exceptional/layout and wholelibrary plus Chrome repeated-process qualification before changing main.')
(root/'source-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps(dict(status='prepared',files=len(hashes))))
