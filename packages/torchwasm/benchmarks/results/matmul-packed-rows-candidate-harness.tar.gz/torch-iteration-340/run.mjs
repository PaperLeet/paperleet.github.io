import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const plan=JSON.parse(fs.readFileSync(root+'/source-plan.json','utf8'));
for(const [name,digest] of Object.entries(plan.files))assert.equal(hash(root+'/'+name),digest,name);
const py=await loadPyodide({indexURL:path.resolve(root,'../torch-iteration-76/runtime'),stdout:console.log,stderr:console.error});
await py.loadPackage('numpy');
py.runPython('import sys;sys.dont_write_bytecode=True');
for(const [name,digest] of Object.entries(plan.files)){
 if(name.startsWith('baseline/')||name.startsWith('candidate/')){
  py.FS.mkdirTree('/'+path.dirname(name));py.FS.writeFile('/'+name,fs.readFileSync(root+'/'+name));
 }
}
py.FS.writeFile('/scan.py',fs.readFileSync(root+'/scan.py'));
try{
 const report=JSON.parse(py.runPython("exec(compile(open('/scan.py').read(),'/scan.py','exec'))\njson.dumps(report)"));
 for(const [name,digest] of Object.entries(plan.files))assert.equal(hash(root+'/'+name),digest,name);
 fs.writeFileSync(root+'/result.json',JSON.stringify({...report,pyodide:py.version,plan_sha256:hash(root+'/source-plan.json')},null,2)+'\n');
}catch(error){fs.writeFileSync(root+'/failure.json',JSON.stringify({error:String(error.stack||error)},null,2)+'\n');throw error;}
