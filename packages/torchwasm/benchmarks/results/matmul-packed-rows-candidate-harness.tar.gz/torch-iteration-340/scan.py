import gc
import hashlib
import importlib.util
import itertools
import json
import math
import statistics
import sys
import time
import numpy as np


def load(root, name):
    spec = importlib.util.spec_from_file_location(name, root+'/__init__.py', submodule_search_locations=[root])
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module.torch


apis = {label: load('/baseline' if label != 'B' else '/candidate', '_pack_scan_'+label) for label in ('A0', 'A1', 'B')}
assert sys.platform == 'emscripten'


def arrange(value, layout):
    if layout in ('C', 'F'):
        return value.copy(order=layout)
    storage = np.empty((value.shape[0]*2, value.shape[1]*2), dtype=value.dtype)
    storage[::2, ::2] = value
    return storage[::2, ::2]


def operation(api, values):
    a, b, g = [api.from_numpy(value).requires_grad_(i < 2) for i, value in enumerate(values)]
    def call():
        y = a @ b
        da, db = api.autograd.grad(y, (a,b), g)
        assert a.grad is None and b.grad is None
        return tuple(value.detach().numpy().copy() for value in (y, da, db))
    return call


def timed(call, count):
    start = time.perf_counter()
    for _ in range(count):
        result = call()
    return time.perf_counter()-start, result


specs = [(size, dtype, layout) for size in (128,256) for dtype in ('float32','float64') for layout in ('C','F','stride')]
specs += [(512,'float32','C'), (64,'float32','C')]
rows=[]
for size, dtype, layout in specs:
    values = [arrange(((np.arange(size*size)%mod-center)/8).astype(dtype).reshape(size,size), layout)
              for mod,center in ((17,8),(13,6),(11,5))]
    for value in values:
        value.flags.writeable=False
    fingerprints = [hashlib.sha256(value.tobytes()).hexdigest() for value in values]
    calls={label: operation(api,values) for label,api in apis.items()}
    expected=(values[0]@values[1], values[2]@values[1].T, values[0].T@values[2])
    for call in calls.values():
        for actual, target in zip(call(),expected):
            np.testing.assert_array_equal(actual,target)
    gc.collect();gc.disable()
    try:
        counts={};calibration={}
        for label,call in calls.items():
            count=1; samples=[]
            while True:
                elapsed,_=timed(call,count)
                samples.append(dict(count=count,elapsed=elapsed))
                if elapsed>=.05 or count>=1024:
                    break
                count=min(1024,max(count+1,math.ceil(count*.06/max(elapsed,1e-6))))
            counts[label]=max(1,math.ceil(count*.025/elapsed))
            calibration[label]=samples
        raw=[]
        for order in itertools.permutations(('A0','A1','B')):
            sample={}
            for label in order:
                elapsed,result=timed(calls[label],counts[label])
                sample[label]=dict(count=counts[label],elapsed=elapsed,seconds=elapsed/counts[label])
                for actual,target in zip(result,expected):
                    np.testing.assert_array_equal(actual,target)
            raw.append(dict(order=order,samples=sample))
    finally:
        gc.enable()
    assert fingerprints==[hashlib.sha256(value.tobytes()).hexdigest() for value in values]
    aa=statistics.median(r['samples']['A1']['seconds']/r['samples']['A0']['seconds'] for r in raw)
    ba=statistics.median(r['samples']['B']['seconds']/r['samples']['A0']['seconds'] for r in raw)
    row=dict(size=size,dtype=dtype,layout=layout,raw=raw,calibration=calibration,aa_ratio=aa,
             packed_over_original=ba,aa_passed=.95<=aa<=1.05,
             median_ms={label:1000*statistics.median(r['samples'][label]['seconds'] for r in raw) for label in calls})
    rows.append(row)
    print(json.dumps({key:row[key] for key in ('size','dtype','layout','aa_ratio','packed_over_original','median_ms')}),flush=True)
report=dict(status='completed_exploratory_scan',numpy=np.__version__,rows=rows,
            all_aa_passed=all(row['aa_passed'] for row in rows),runtime_adopted=False,
            scope='One fresh Node/Pyodide process;14 full forward/two-VJP/copy flows. Dyadic finite numerical controls only. No full library, exceptional-value, layout or application qualification.')
