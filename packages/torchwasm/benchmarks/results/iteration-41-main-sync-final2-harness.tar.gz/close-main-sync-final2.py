from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;s=r/'main-sync-final2-proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
context=json.loads((s/'context.json').read_text());receipts=json.loads((s/'receipts.json').read_text())
assert len(receipts)==7 and all(v['exit_code']==0 for v in receipts)
validated={}
for name in ('iteration-41-main-sync.json','iteration-41-main-sync-final.json'):
    report=json.loads((out/name).read_text())
    for path,digest in report['context']['changed_files'].items():
        assert hashlib.sha256(subprocess.check_output(['git','show',report['context']['upstream']+':'+path],cwd=repo)).hexdigest()==digest
        validated[path]=digest
for path,digest in context['changed_files'].items():
    assert sha(s/'incoming'/path)==sha(repo/path)==digest
    assert hashlib.sha256(subprocess.check_output(['git','show',context['upstream']+':'+path],cwd=repo)).hexdigest()==digest
    validated[path]=digest
for path,digest in validated.items():assert sha(repo/path)==digest
for name,digest in context['source_hashes'].items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==digest
for name,digest in context['active_export_sha256'].items():assert sha(repo/'web/public/data'/name)==digest
for name,digest in json.loads((r/'canonical-policy-identity.json').read_text())['hashes'].items():assert sha(repo/name)==digest
shutil.copy2(Path(__file__),s/'close-main-sync-final2.py')
archive=out/'iteration-41-main-sync-final2-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for path in sorted(s.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:tar.add(path,arcname=str(path.relative_to(s)),recursive=False)
report=dict(status='complete_local_latest_interview_frontend_passed_runtime_identity_unchanged',version='0.41.0',context=context,receipts=receipts,validated_frontend_files=len(validated),
            archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),
            scope='Five subsequent frontend/check/style/documentation updates. Five affected interview suites and both typed builds pass. Earlier25+3-file snapshots verified against their Git blobs and latest validated supersessions;all49 computational/license and161 active-export identities unchanged.',
            publication='No tag,dispatch,package upload or online publication by this task;non-force main adoption requires no active external quality/Pages release.')
(out/'iteration-41-main-sync-final2.json').write_text(json.dumps(report,indent=2)+'\n')
doc=repo/'docs/validation/torch-runtime-iteration-41.md'
doc.write_text(doc.read_text()+f'\nFive later interview frontend/check/style/documentation updates through\n`{context["upstream"]}` were retained. Five affected interview suites and both\ntyped builds pass. All {len(validated)} latest frontend file snapshots and the\nearlier snapshots/supersessions are verified against Git. All 49 source/license\nand 161 active-export hashes remain exact. See `iteration-41-main-sync-final2.json`\nand its harness. Earlier numerical/native/full-WASM evidence remains applicable.\n')
print(json.dumps(dict(upstream=context['upstream'],changed=5,validated_frontend=len(validated),archive=report['archive'])))
