from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
env=dict(os.environ,PYTHON='/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-21/stride-dev-env/bin/python')
env['PATH']='/opt/homebrew/bin:'+env['PATH'];receipts=[]
plans=[(['/opt/homebrew/bin/node','scripts/'+name],name+'.log',{}) for name in ('check-interview-practice-group.mjs','check-interview-ranking.mjs','check-interview-continuation.mjs','check-interview-study.mjs','check-interview-report-practice.mjs')]
profile=json.loads((r.parent/'main-sync-proof/pages-profile.json').read_text())['environment']
plans += [(['npm','run','build'],'build-default.log',{}),(['npm','run','build'],'build-pages.log',profile)]
for args,name,overrides in plans:
    start=time.monotonic()
    with (r/name).open('w') as log:result=subprocess.run(args,cwd=repo/'web',env={**env,**overrides},stdout=log,stderr=subprocess.STDOUT)
    receipts.append(dict(args=args,log=name,cwd=str(repo/'web'),environment=overrides,exit_code=result.returncode,elapsed_s=time.monotonic()-start))
    (r/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
    print(name,'terminal',result.returncode,flush=True);result.check_returncode()
