from pathlib import Path
import json,torch,numpy as np
rng=np.random.default_rng(4900);rows=[]
for dim in [1,2,3]:
 raw=rng.normal(size=(1,2,*([3]*dim)));weights=rng.normal(size=(3,2,*([3]*dim)))
 x=torch.tensor(raw,requires_grad=True);w=torch.tensor(weights,requires_grad=True)
 y=getattr(torch.nn.functional,f'conv{dim}d')(x,w,padding=31,dilation=31)
 seed=torch.tensor(rng.normal(size=y.shape));y.backward(seed)
 expected=np.einsum('bi...,oi->bo...',raw,weights[(slice(None),slice(None),*([1]*dim))])
 np.testing.assert_allclose(y.detach().numpy(),expected,atol=3e-12)
 rows.append(dict(dim=dim,dilation=31,padding=31,input=raw.tolist(),weight=weights.tolist(),seed=seed.numpy().tolist(),output=y.detach().numpy().tolist(),dx=x.grad.numpy().tolist(),dw=w.grad.numpy().tolist()))
r=Path(__file__).resolve().parent;(r/'next-padding-native.json').write_text(json.dumps(dict(native=torch.__version__,scope='Safe modest halo oracle for the next regular-convolution allocation iteration; huge forecast spans not executed',cases=rows),indent=2)+'\n');print('NEXT regular-padding oracle3 dimensions; finite output equals center-tap channel contraction')
