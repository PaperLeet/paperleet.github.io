from pathlib import Path
import subprocess,shutil,json,hashlib
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');p=r/'integration-proof';py=r.parent/'torch-iteration-21/stride-dev-env/bin/python'
gates=json.loads((r/'proof/gate-receipts.json').read_text());assert len(gates)==6 and all(v['exit_code']==0 for v in gates.values())
shutil.copytree(r/'proof/private-dist',p/'dist-paperleet',dirs_exist_ok=True)
subprocess.check_call([str(py),str(p/'run-setup.py')],cwd=repo)
expected=json.loads((r/'proof/source-hashes.json').read_text())
for name,digest in expected.items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==digest
receipts=json.loads((p/'setup-receipts.json').read_text());assert len(receipts)==3 and all(v['exit_code']==0 for v in receipts)
receipts.append(dict(script='exact-source-recheck',exit_code=0,resources=len(expected)));(p/'setup-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
print('SETUP4_TERMINAL0',flush=True)
