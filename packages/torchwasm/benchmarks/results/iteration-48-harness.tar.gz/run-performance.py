from pathlib import Path
import hashlib,json,os,statistics,subprocess,time
r=Path(__file__).resolve().parent;out=r/'performance';py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';expected=json.loads((r/'proof/source-hashes.json').read_text());receipts={}
assert json.loads((r/'full-root-receipt.json').read_text())['exit_code']==0
assert json.loads((r/'integration-proof/wasm-receipt.json').read_text())['exit_code']==0
assert json.loads((r/'native-differential-receipt.json').read_text())['source_hashes']==expected
for f in ['proof/source-wasm.json','proof/chrome-contracts/result.json']:assert json.loads((r/f).read_text())['source_hashes']==expected
env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');load_before=os.getloadavg()
for repeat in range(4):
 for runtime in (('cpu','node','chrome') if repeat%2==0 else ('chrome','node','cpu')):
  name=f'{runtime}-{repeat}';output=out/(name+'.json');reverse=['--reverse'] if repeat%2 else []
  args=([str(py),str(r/'bench-cpu.py'),str(output)] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(r/('bench-wasm.mjs' if runtime=='node' else 'bench-chrome.mjs')),str(output)])+reverse
  start=time.monotonic()
  with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  receipts[name]=dict(args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-start)
  (out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode()
  j=json.loads(output.read_text());assert j['status']=='success' and j['library']=='0.48.0' and len(j['flows'])==38 and j['source_hashes']==expected
  for flow in j['flows']:
   if 'qualification' in flow:
    q=flow['qualification'];assert q['composed']==dict(selected=0,fallback=0) and q['direct']['selected']==0 and q['matrix']['selected']>0
    assert bool(q['auto']['selected'])==(flow['kind'] not in ['sequence','point'])
  print(name,'PASS38',round(receipts[name]['elapsed_s'],2),flush=True)
summary={}
for runtime in ['cpu','node','chrome']:
 reports=[json.loads((out/f'{runtime}-{i}.json').read_text()) for i in range(4)];rows=[]
 for case in range(38):
  first=reports[0]['flows'][case];row={k:first[k] for k in ['kind','shape','dtype','mode']}
  times={name:[j['flows'][case]['median_s'][name] for j in reports] for name in ['composed','auto','direct','matrix']}
  medians={name:statistics.median(v) for name,v in times.items()}
  row.update(median_s=medians,all_child_median_s=times,time_reduction_percent=100*(1-medians['auto']/medians['composed']))
  rows.append(row)
 summary[runtime]=rows
report=dict(status='success',children=len(receipts),all_children_terminal=True,summary=summary,receipts=receipts,source_hashes=expected,load_before=load_before,load_after=os.getloadavg(),scope='Same final source direct transposed convolution versus zero insertion plus flipped grouped regular convolution (0.47 had no transposed-convolution API); forced direct and matrix controls retained. Four fresh processes per runtime, alternating first method and runtime order, five samples/12 ordinary calls or3SGD steps. Every value/JVP/reverse-over-forward and three decoder SGD updates checked before timings. All samples retained. Shared host; not a native Torch, GPU, memory or universal speed comparison.')
(r/'performance-summary.json').write_text(json.dumps(report,indent=2)+'\n')
