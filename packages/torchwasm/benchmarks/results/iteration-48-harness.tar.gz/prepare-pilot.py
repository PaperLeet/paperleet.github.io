from pathlib import Path
import json,hashlib,shutil
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-47';repo=Path('/Users/david/Developer/PaperLeet-torch-release');p=r/'proof';p.mkdir(exist_ok=True);chrome=p/'chrome-contracts';chrome.mkdir(exist_ok=True)
for dest in [p/'source',chrome/'source']:
 dest.mkdir(exist_ok=True)
 for f in (repo/'packages/stridetorch/src/stridetorch').iterdir():
  if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']:shutil.copy2(f,dest/f.name)
source={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (p/'source').iterdir() if f.is_file()}
shutil.copy2(repo/'packages/stridetorch/benchmarks/bench_transpose_convolution.py',r/'bench_transpose_convolution.py');shutil.copy2(r/'bench_transpose_convolution.py',chrome/'bench_transpose_convolution.py')
plan=dict(source=source,benchmark_sha256=hashlib.sha256((r/'bench_transpose_convolution.py').read_bytes()).hexdigest())
(r/'performance-plan.json').write_text(json.dumps(plan,indent=2)+'\n');(chrome/'bench-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for name in ['bench-wasm.mjs','bench-chrome.mjs']:
 (r/name).write_text((old/name).read_text().replace('torch-iteration-47','torch-iteration-48').replace('bench_instance_norm','bench_transpose_convolution'))
(chrome/'index.html').write_text('<!doctype html><title>Transpose convolution prototype benchmark</title>')
(chrome/'bench-worker.mjs').write_text((old/'proof/chrome-contracts/bench-worker.mjs').read_text().replace('bench_instance_norm','bench_transpose_convolution'))
