import json,torch,numpy as np
from pathlib import Path
out=[]
def record(id,fn):
 try:result=fn();out.append(dict(id=id,result=result))
 except Exception as e:out.append(dict(id=id,error=type(e).__name__,message=str(e).splitlines()[0]))
for dim in [1,2,3]:
 f=getattr(torch.nn.functional,f'conv_transpose{dim}d')
 for n,ci,co,s in [(1,2,3,3),(0,2,3,3),(1,0,3,3),(1,2,0,3),(0,0,3,3),(1,2,3,0)]:
  def run(n=n,ci=ci,co=co,s=s):
   x=torch.ones(n,ci,*([s]*dim),dtype=torch.float64,requires_grad=True);w=torch.ones(ci,co,*([2]*dim),dtype=x.dtype,requires_grad=True);b=torch.ones(co,dtype=x.dtype,requires_grad=True)
   y=f(x,w,b);y.sum().backward();return dict(shape=list(y.shape),stride=list(y.stride()),grads=[list(t.grad.shape) for t in [x,w,b]],values=y.flatten()[:3].tolist())
  record(f'empty:{dim}:{n}:{ci}:{co}:{s}',run)
 for stride,dilation,op in [(1,1,1),(1,3,2),(2,1,1),(2,1,2),(2,3,2),(2,3,3),(1,1,-1)]:
  def run(stride=stride,dilation=dilation,op=op):
   x=torch.arange(3,dtype=torch.float64).reshape(1,1,*([1]*(dim-1)),3);w=torch.ones(1,1,*([2]*dim),dtype=x.dtype)
   y=f(x,w,stride=stride,dilation=dilation,output_padding=op)
   return dict(shape=list(y.shape),value=y.flatten().tolist())
  record(f'output_padding:{dim}:{stride}:{dilation}:{op}',run)
 for changed in ['input','weight','bias','output']:
  def run(changed=changed):
   x=torch.ones(1,2,*([3]*dim),dtype=torch.float64,requires_grad=True);w=torch.ones(2,3,*([2]*dim),dtype=x.dtype,requires_grad=True);b=torch.ones(3,dtype=x.dtype,requires_grad=True)
   y=f(x,w,b);t={'input':x,'weight':w,'bias':b,'output':y}[changed];t.detach().add_(1);y.sum().backward();return 'allowed'
  record(f'mutation:{dim}:{changed}',run)
 for mode,padding in [('zeros','same'),('zeros','valid'),('reflect',0),('circular',0),('zeros',-1)]:
  def run(mode=mode,padding=padding):
   m=getattr(torch.nn,f'ConvTranspose{dim}d')(2,4,2,padding=padding,padding_mode=mode,dtype=torch.float64)
   return dict(repr=repr(m),weight=list(m.weight.shape),bound=float(m.weight.abs().max()))
  record(f'constructor:{dim}:{mode}:{padding}',run)
p=Path(__file__).resolve().parent/'native-probe.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(cases=len(out),errors=sum('error'in v for v in out))))
for v in out:
 if v['id'].startswith(('empty','constructor')):print({k:v[k] for k in ['id','error','message'] if k in v},v.get('result'))
