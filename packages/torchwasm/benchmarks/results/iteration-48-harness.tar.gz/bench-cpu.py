from pathlib import Path
import sys,json,runpy,hashlib
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'performance/frozen'))
import stridetorch,numpy
plan=json.loads((r/'performance-plan.json').read_text());source=Path(stridetorch.__file__).parent
actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.is_file() and (p.suffix=='.py' or p.name in ['LICENSE','NOTICE'])}
assert actual==plan['source']
assert hashlib.sha256((r/'bench_transpose_convolution.py').read_bytes()).hexdigest()==plan['benchmark_sha256']
report=runpy.run_path(str(r/'bench_transpose_convolution.py'))['run'](reverse_order='--reverse' in sys.argv)
report.update(runtime='CPU',library=stridetorch.__version__,numpy=numpy.__version__,source_hashes=actual,benchmark_sha256=plan['benchmark_sha256'])
Path(sys.argv[1]).write_text(json.dumps(report,indent=2)+'\n');print('CPU PASS',len(report['flows']))
