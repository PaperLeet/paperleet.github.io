from pathlib import Path
import json,numpy as np
from stridetorch import torch
r=Path(__file__).resolve().parent;j=json.loads((r/'next-padding-native.json').read_text())
for row in j['cases']:
 x=torch.tensor(row['input'],dtype=torch.float64,requires_grad=True);w=torch.tensor(row['weight'],dtype=torch.float64,requires_grad=True)
 y=getattr(torch.nn.functional,f"conv{row['dim']}d")(x,w,padding=31,dilation=31);y.backward(torch.tensor(row['seed'],dtype=torch.float64))
 for actual,key in [(y,'output'),(x.grad,'dx'),(w.grad,'dw')]:np.testing.assert_allclose(actual.numpy(),row[key],rtol=5e-12,atol=5e-12)
(r/'next-padding-baseline.json').write_text(json.dumps(dict(status='success',library='0.48.0',cases=3,checks=9,scope='Existing regular-convolution modest-halo value/VJP baseline against native; no huge arrays allocated',prototype_note='Initial JSON-list roundtrip omitted explicit dtype, yielding float32 versus float64 reference; corrected explicit float64 without a library change.'),indent=2)+'\n');print('NEXT baseline9 native value/VJP comparisons pass at safe dilation/padding31')
