import os,json
import numpy as np
if os.environ.get('STRIDE_PROBE'):
 from stridetorch import torch,_transpose_convolution
 algorithm=os.environ.get('STRIDE_ALGORITHM','auto')
 _transpose_convolution._ALGORITHM=algorithm.split('_')[0]
 if algorithm.endswith('_no_pad'):_transpose_convolution._PAD_WORKSPACE_BYTES=0
else:import torch
rng=np.random.default_rng(4810);results=[]
for dim in [1,2,3]:
 for dtype in [torch.float32,torch.float64]:
  for groups in [1,2]:
   for case in ['regular','stride','dilation','op_beyond_stride','cropped','anisotropic']:
    for unbatched in [False,True]:
     shape=(2,4,*([3]*dim));kernel=(2,)*dim
     raw=rng.normal(size=shape).astype(np.float32 if dtype==torch.float32 else np.float64)
     raw=np.asfortranarray(raw) if case=='dilation' else raw
     if case=='cropped':raw=np.repeat(raw,2,axis=-1)[...,::2]
     x=torch.from_numpy(raw).requires_grad_();w=torch.tensor(rng.normal(size=(4,6//groups,*kernel)),dtype=dtype,requires_grad=True);b=torch.tensor(rng.normal(size=6),dtype=dtype,requires_grad=True)
     if unbatched:
      raw=raw[0];x=torch.from_numpy(raw).requires_grad_()
     options=dict(stride=2 if case in ['stride','op_beyond_stride'] else 1,padding=1 if case=='cropped' else 0,dilation=3 if case=='op_beyond_stride' else 2 if case=='dilation' else 1,output_padding=2 if case=='op_beyond_stride' else 1 if case=='stride' else 0,groups=groups)
     if case=='anisotropic':options.update(stride=(2,1,3)[:dim],padding=(1,0,2)[:dim],output_padding=(1,2,0)[:dim],dilation=(1,3,1)[:dim])
     f=lambda a,c,d:getattr(torch.nn.functional,f'conv_transpose{dim}d')(a,c,d,**options)
     y=f(x,w,b);seed=torch.tensor(rng.normal(size=y.shape),dtype=dtype);y.backward(seed)
     array=lambda v:v.detach().numpy().tolist() if v is not None else None
     result=dict(id=f'{dim}:{str(dtype).replace("torch.","")}:{groups}:{case}:{unbatched}',value=array(y),stride=list(y.stride()),grads=[array(z.grad) for z in (x,w,b)])
     vals=[torch.tensor(z.detach().numpy(),requires_grad=True) for z in (x,w,b)]
     directions=[torch.tensor(rng.normal(size=z.shape),dtype=dtype,requires_grad=True) for z in vals]
     p,t=torch.func.jvp(f,tuple(vals),tuple(directions));(p*seed+t*seed.square()).sum().backward()
     result.update(jvp=array(t),mixed=[array(z.grad) for z in (*vals,*directions)])
     results.append(result)
print(json.dumps(results))
