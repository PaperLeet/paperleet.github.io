import fs from 'node:fs';import path from 'node:path';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const root=path.dirname(new URL(import.meta.url).pathname),repo='/Users/david/Developer/PaperLeet-torch-release';
const plan=JSON.parse(fs.readFileSync(root+'/performance-plan.json'));
const py=await loadPyodide({indexURL:repo+'/web/node_modules/pyodide/',packageCacheDir:repo+'/web/public/browser-runtime/pyodide-0.29.4/',stdout(){},stderr(){}});await loadJudgePackages(py,[]);
py.FS.mkdirTree('/runtime/stridetorch');
for(const name of Object.keys(plan.source))py.FS.writeFile('/runtime/stridetorch/'+name,fs.readFileSync(root+'/proof/source/'+name));
py.FS.writeFile('/bench.py',fs.readFileSync(root+'/bench_transpose_convolution.py'));py.globals.set('plan_json',JSON.stringify(plan));py.globals.set('reverse_order',process.argv.includes('--reverse'));
const result=JSON.parse(py.runPython(`import sys,json,pathlib,hashlib,runpy
sys.path.insert(0,'/runtime')
plan=json.loads(plan_json)
actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path('/runtime/stridetorch').iterdir() if p.is_file()}
assert actual==plan['source']
assert hashlib.sha256(pathlib.Path('/bench.py').read_bytes()).hexdigest()==plan['benchmark_sha256']
import stridetorch,numpy
report=runpy.run_path('/bench.py')['run'](reverse_order=reverse_order)
report.update(runtime='Node/Pyodide',library=stridetorch.__version__,numpy=numpy.__version__,source_hashes=actual,benchmark_sha256=plan['benchmark_sha256'])
json.dumps(report)`));result.pyodide=py.version;
fs.writeFileSync(process.argv[2],JSON.stringify(result,null,2)+'\n');console.log('NODE PASS',result.flows.length);
