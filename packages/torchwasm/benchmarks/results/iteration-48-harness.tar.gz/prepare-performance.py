from pathlib import Path
import shutil,json,hashlib
r=Path(__file__).resolve().parent;p=r/'performance';p.mkdir(exist_ok=True);f=p/'frozen/stridetorch';shutil.copytree(r/'proof/source',f,dirs_exist_ok=True)
repo=Path('/Users/david/Developer/PaperLeet-torch-release');shutil.copy2(repo/'packages/stridetorch/benchmarks/bench_transpose_convolution.py',r/'bench_transpose_convolution.py')
plan={'source':json.loads((r/'proof/source-hashes.json').read_text()),'benchmark_sha256':hashlib.sha256((r/'bench_transpose_convolution.py').read_bytes()).hexdigest()}
(r/'performance-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(r/'proof/chrome-contracts/bench-plan.json').write_text(json.dumps(plan,indent=2)+'\n');shutil.copy2(r/'bench_transpose_convolution.py',r/'proof/chrome-contracts/bench_transpose_convolution.py')
