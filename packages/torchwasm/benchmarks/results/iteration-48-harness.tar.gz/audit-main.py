from pathlib import Path
import hashlib,json,subprocess,sys
repo=Path('/Users/david/Developer/PaperLeet-torch-release');r=Path(__file__).resolve().parent
expected=sys.argv[1];remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=repo,text=True).split()[0]
runs=json.loads(subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/runs?per_page=100'],cwd=repo,text=True))['workflow_runs']
active=[dict(id=v['id'],name=v['name'],event=v['event'],status=v['status'],head_sha=v['head_sha'],url=v['html_url']) for v in runs if v['status']!='completed' and v['name'] in ('PaperLeet quality gate','Publish PaperLeet public site')]
pending_pages=[];observed=[]
# A successful quality run may finish before its workflow_run child appears.
# Hold current main through that event-delivery gap too.
chain_ids={39004189139,39005098435}
chain_ids.update(v['id'] for v in runs if v['name']=='PaperLeet quality gate' and v['head_sha']==remote)
for run_id in sorted(chain_ids):
 quality=next((v for v in runs if v['id']==run_id),None)
 if quality is None:quality=json.loads(subprocess.check_output(['gh','api',f'repos/PaperLeet/paperleet.github.io/actions/runs/{run_id}'],cwd=repo,text=True))
 pages=[v for v in runs if v['name']=='Publish PaperLeet public site' and v['head_sha']==quality['head_sha'] and ((v['event']=='workflow_run' and v['created_at']>=quality['created_at']) or (quality['status']=='completed' and v['event']=='workflow_dispatch' and v['created_at']>=quality['updated_at']))]
 observed.append(dict(quality_id=run_id,status=quality['status'],conclusion=quality['conclusion'],head_sha=quality['head_sha'],pages=[dict(id=v['id'],status=v['status'],conclusion=v['conclusion']) for v in pages]))
 if quality['status']=='completed' and quality['conclusion']=='success' and quality['head_sha']==remote and not pages:
  pending_pages.append(run_id)
policy=json.loads((r/'release-policy-identity.json').read_text())
for name,digest in policy['files'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
source=json.loads((r/'proof/source-hashes.json').read_text())
for name,digest in source.items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==digest
for name,digest in json.loads((r/'integration-proof/live-expected-sha256.json').read_text()).items():assert hashlib.sha256((repo/'web/public/data'/name).read_bytes()).hexdigest()==digest
report=dict(expected_remote=expected,actual_remote=remote,active_release_chains=active,pending_pages_event=pending_pages,observed_chains=observed,allowed=remote==expected and not active and not pending_pages,source_resources=len(source),release_policies=len(policy['files']),export_identities=161)
(r/'latest-main-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));sys.exit(0 if report['allowed'] else 2)
