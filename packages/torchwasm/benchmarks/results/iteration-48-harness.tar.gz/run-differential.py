from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import os,json,hashlib,subprocess,time
import numpy as np
r=Path(__file__).resolve().parent;py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';native=Path('/Users/david/Developer/PaperLeet-public/.venv/bin/python');env=dict(os.environ,OMP_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2',OPENBLAS_NUM_THREADS='2');receipts={}
def run(label,python,script,options):
 start=time.monotonic()
 with (r/(label+'.json')).open('w') as out,(r/(label+'.log')).open('w') as log:
  p=subprocess.run([str(python),str(r/script)],env={**env,**options},cwd=r,stdout=out,stderr=log)
 return label,dict(exit_code=p.returncode,elapsed_s=time.monotonic()-start)
plans=[('reference',native,'differential.py',{}),('semantics-reference',native,'semantics.py',{}),('semantics-candidate',py,'semantics.py',{'STRIDE_PROBE':'1'})]
for route in ['auto','direct','matrix','direct_no_pad','matrix_no_pad']:plans.append(('candidate-'+route,py,'differential.py',{'STRIDE_PROBE':'1','STRIDE_ALGORITHM':route}))
with ThreadPoolExecutor(max_workers=4) as pool:
 for future in as_completed([pool.submit(run,*plan) for plan in plans]):
  name,result=future.result();receipts[name]=result
assert all(v['exit_code']==0 for v in receipts.values()),receipts
ref=json.loads((r/'reference.json').read_text());assert len(ref)==144
checks=0;worst={}
for route in ['auto','direct','matrix','direct_no_pad','matrix_no_pad']:
 rows=json.loads((r/f'candidate-{route}.json').read_text());assert len(rows)==144
 for a,b in zip(ref,rows):
  assert a['id']==b['id']
  for key in ['value','stride','grads','jvp','mixed']:
   pairs=zip(a[key],b[key]) if key in ['grads','mixed'] else [(a[key],b[key])]
   for left,right in pairs:
    checks+=1;left=np.asarray(left);right=np.asarray(right)
    worst[key]=max(worst.get(key,0),float(np.max(np.abs(right-left))) if left.size else 0)
    np.testing.assert_allclose(right,left,rtol=2e-5 if 'float32' in a['id'] else 5e-12,atol=3e-5 if 'float32' in a['id'] else 5e-12)
semantic=json.loads((r/'semantics-reference.json').read_text());other=json.loads((r/'semantics-candidate.json').read_text());assert len(semantic)==len(other)==68
semantic_checks=0
def compare(a,b,path=''):
 global semantic_checks
 if isinstance(a,dict):
  assert a.keys()==b.keys(),(path,a.keys(),b.keys())
  for key in a:compare(a[key],b[key],path+'/'+key)
 elif isinstance(a,str) or a is None:assert a==b,(path,a,b)
 elif isinstance(a,list):
  assert len(a)==len(b),(path,len(a),len(b))
  for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+'/'+str(i))
 else:
  semantic_checks+=1;np.testing.assert_allclose(b,a,rtol=5e-12,atol=5e-12,equal_nan=True)
for a,b in zip(semantic,other):compare(a,b,a['id'])
source=json.loads((r/'proof/source-hashes.json').read_text());repo=Path('/Users/david/Developer/PaperLeet-torch-release')
for name,digest in source.items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==digest
identity=json.loads(subprocess.check_output([str(native),'-c','import json,torch,numpy,sys;print(json.dumps(dict(torch=torch.__version__,numpy=numpy.__version__,python=sys.version)))'],text=True));assert identity['torch']=='2.14.1'
report=dict(status='success',version='0.48.0',native=identity,numeric_cases=144,routes=5,numeric_checks=checks,semantic_cases=68,semantic_checks=semantic_checks,max_absolute_errors=worst,source_hashes=source,receipts=receipts,harness_sha256={name:hashlib.sha256((r/name).read_bytes()).hexdigest() for name in ['differential.py','semantics.py','run-differential.py']},scope='Independent native/candidate processes; float32/64 grouped batched/unbatched regular, strided, dilated, clipped and anisotropic values/VJP/JVP/mixed derivatives and strides. Empty metadata, saved versions, module output_size/checkpoints/config, nonfinite implicit padding and channels-last layouts. Mutation error checks compare the RuntimeError base class, preserving the adapter typed-unsupported subtype policy.')
(r/'native-differential-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k not in ['source_hashes','receipts','harness_sha256','scope','native']})
