from pathlib import Path
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-47'
s=(old/'close-local.py').read_text().replace('0.47.0','0.48.0').replace('iteration-47','iteration-48').replace('stride047','stride048')
s=s.replace('len(actual)==52','len(actual)==53').replace('len(tests)==44','len(tests)==45').replace("len(contracts['suites'])==44","len(contracts['suites'])==45").replace('==5085','==5600').replace('==38714','==39229').replace("'5098 passed'","'5613 passed'").replace("'182 passed'","'722 passed'")
s=s.replace("numeric['numeric_cases']==54 and numeric['semantic_cases']==64 and numeric['array_state_checks']==2142", "numeric['numeric_cases']==144 and numeric['routes']==5 and numeric['numeric_checks']==8640 and numeric['semantic_cases']==68 and numeric['semantic_checks']==22436")
s=s.replace("len(baseline['source'])==51","len(baseline['source'])==52")
s=s.replace('bench_instance_norm','bench_transpose_convolution').replace("len(row['flows'])==26","len(row['flows'])==38")
s=s.replace('==10387','==10545')
s=s.replace("changed=={'__init__.py','_api.py','_batchnorm.py'} and set(actual)-set(baseline['source'])=={'_instancenorm.py'}", "changed=={'__init__.py','_api.py','_convolution.py'} and set(actual)-set(baseline['source'])=={'_transpose_convolution.py'}")
s=s.replace('unchanged_resources=48','unchanged_resources=49').replace("added_resources=['_instancenorm.py']","added_resources=['_transpose_convolution.py']").replace('focused_instance_norm=182','focused_transposed_convolution=515,focused_regular_convolution=207')
s=s.replace('PASS0.47 exact local proof:52resources,5085Node/Chrome,38714CPU,5098minimum,118native cases,78/342catalog,26flowsx12children','PASS0.48 exact local proof:53resources,5600Node/Chrome,39229CPU,5613minimum,144x5native plus68semantic cases,78/342catalog,38flowsx12children')
(r/'close-local.py').write_text(s)
