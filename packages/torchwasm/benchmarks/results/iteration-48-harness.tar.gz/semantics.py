import os,json
import numpy as np
if os.environ.get('STRIDE_PROBE'):
 from stridetorch import torch
else:import torch
rows=[]
def record(id,fn):
 try:rows.append(dict(id=id,result=fn()))
 except (RuntimeError,ValueError,TypeError,IndexError) as e:rows.append(dict(id=id,error='RuntimeError' if isinstance(e,RuntimeError) else type(e).__name__))
for dim in [1,2,3]:
 fn=getattr(torch.nn.functional,f'conv_transpose{dim}d');cls=getattr(torch.nn,f'ConvTranspose{dim}d')
 for shape in [(0,2,*([3]*dim)),(0,2,*([0]*dim)),(1,0,*([3]*dim)),(1,2,*([0]*dim))]:
  def run(shape=shape):
   x=torch.ones(shape,dtype=torch.float64,requires_grad=True);w=torch.ones(shape[1],3,*([2]*dim),dtype=torch.float64,requires_grad=True);b=torch.ones(3,dtype=torch.float64,requires_grad=True)
   y=fn(x,w,b);y.sum().backward();return dict(shape=list(y.shape),stride=list(y.stride()),grads=[v.grad.numpy().tolist() for v in [x,w,b]])
  record(f'empty:{dim}:{shape}',run)
 for changed in ['input','weight','bias','output']:
  def run(changed=changed):
   x=torch.ones(1,2,*([3]*dim),dtype=torch.float64,requires_grad=True);w=torch.ones(2,3,*([2]*dim),dtype=torch.float64,requires_grad=True);b=torch.ones(3,dtype=torch.float64,requires_grad=True)
   y=fn(x,w,b);{'input':x,'weight':w,'bias':b,'output':y}[changed].detach().add_(1);y.sum().backward();return [v.grad.numpy().tolist() for v in [x,w,b]]
  record(f'mutation:{dim}:{changed}',run)
 for unbatched in [False,True]:
  for output_size in ['default','minimum','maximum','full','invalid']:
   def run(unbatched=unbatched,output_size=output_size):
    m=cls(4,6,2,stride=2,padding=1,dilation=2,groups=2,output_padding=1,dtype=torch.float64)
    with torch.no_grad():m.weight.fill_(.2);m.bias.fill_(.1)
    x=torch.ones((4,*([3]*dim)) if unbatched else (2,4,*([3]*dim)),dtype=torch.float64,requires_grad=True)
    size=None if output_size=='default' else [5 if output_size=='minimum' else 6 if output_size in ['maximum','full'] else 7]*dim
    if output_size=='full':size=[999]*(1 if unbatched else 2)+size
    y=m(x,output_size=size);y.sum().backward()
    return dict(shape=list(y.shape),stride=list(y.stride()),values=y.detach().numpy().tolist(),grads=[v.grad.numpy().tolist() for v in [x,m.weight,m.bias]],repr=repr(m),keys=list(m.state_dict()),metadata=m.state_dict()._metadata)
   record(f'module:{dim}:{unbatched}:{output_size}',run)
 for which in ['input','weight']:
  def run(which=which):
   x=torch.ones(1,1,*([3]*dim),dtype=torch.float64,requires_grad=True);w=torch.ones(1,1,*([3]*dim),dtype=x.dtype,requires_grad=True)
   with torch.no_grad():
    (x if which=='input' else w)[(0,0,*([0]*dim))]=float('inf')
   y=fn(x,w,padding=10000,dilation=10000);y.sum().backward();return [y.detach().numpy().tolist(),x.grad.numpy().tolist(),w.grad.numpy().tolist()]
  record(f'IEEE:{dim}:{which}',run)
for ci in [1,4]:
 for which in ['input','weight']:
  for unbatched in [False,True]:
   def run(ci=ci,which=which,unbatched=unbatched):
    a=np.ones((2,3,3,ci),dtype=np.float64).transpose(0,3,1,2) if which=='input' else np.ones((2,ci,3,3),dtype=np.float64)
    if unbatched:a=a[0]
    w=np.ones((ci,2,2,3),dtype=np.float64).transpose(0,3,1,2) if which=='weight' else np.ones((ci,3,2,2),dtype=np.float64)
    y=torch.nn.functional.conv_transpose2d(torch.from_numpy(a),torch.from_numpy(w),stride=2);return dict(shape=list(y.shape),stride=list(y.stride()),values=y.numpy().tolist())
   record(f'channels_last:{ci}:{which}:{unbatched}',run)
print(json.dumps(rows,allow_nan=True))
