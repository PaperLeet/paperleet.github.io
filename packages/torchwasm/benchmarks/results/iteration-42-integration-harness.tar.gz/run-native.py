from pathlib import Path
import json,shutil,subprocess,time
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');args=[str(r.parent.parent/'torch-iteration-21/stride-dev-env/bin/paperleet'),'ci','--repeats','3','--budget','600'];start=time.monotonic()
with (r/'native-ci.log').open('w') as log:p=subprocess.run(args,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
(r/'native-receipt.json').write_text(json.dumps(dict(args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-start),indent=2)+'\n');p.check_returncode();shutil.copy2(repo/'reports/ci.json',r/'native-ci.json');print('NATIVE ORIGINAL CATALOG TERMINAL0',flush=True)
