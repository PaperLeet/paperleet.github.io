from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';receipts={}
for runtime,dtype in [('cpu','float64'),('wasm','float32'),('wasm','float64')]:
 name=f'pool-pilot-{runtime}-{dtype}';args=[str(py),str(r/'bench-pooling.py')] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(r/'bench-pooling-wasm.mjs')]
 start=time.monotonic()
 with (r/(name+'.json')).open('w') as stdout,(r/(name+'.stderr.log')).open('w') as stderr:p=subprocess.run(args,cwd=r,env=dict(os.environ,BENCH_DTYPE=dtype,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2'),stdout=stdout,stderr=stderr)
 receipts[name]=dict(exit_code=p.returncode,elapsed_s=time.monotonic()-start);(r/'pool-pilot-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode();print(name,'terminal0',flush=True)
