from pathlib import Path
import json
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
core=json.loads((out/'iteration-38.json').read_text());app=json.loads((out/'iteration-38-integration.json').read_text());pool=core['final_pooling_workflows'];reg=core['final_existing_workflows'];full=core['full_cpu'];imports=core['cold_namespace_imports']['summary'];footprint=reg['source_footprint']
def limits(v):return f'{min(v):.1f} to {max(v):.1f}%'
def table(report,key):
 return '\n'.join(f'| {name} | {limits(report["summary"]["cpu"][name][key])} | {limits(report["summary"]["wasm"][name][key])} |' for name in report['summary']['cpu'])
pool_table=table(pool,'median_time_reductions_percent');reg_table=table(reg,'median_reductions_percent')
text=f'''# StrideTorch 0.38: max pooling with measured NumPy kernels

Version 0.38 adds `nn.MaxPool2d`, functional `max_pool2d` and
`max_pool2d_with_indices`, plus the values-only root `torch.max_pool2d` entry
point. Existing `import torch` aliases and launcher behavior remain available.
The independent NumPy package retains its current name while the user's
browser-oriented naming decision is pending.

## Values, indices and derivatives

The implementation handles CHW/NCHW input, noncontiguous arrays and empty
batches. Kernel/stride/padding/dilation tuples, default and empty stride, ceil
rounding and dropped windows starting entirely in right padding follow the
native-reference probes. Functional and Module argument orders retain their
respective public conventions. The pooling child namespace also supports
ordinary `from torch.nn.modules.pooling import MaxPool2d`.

Returned indices are int64 spatial offsets within each input channel. Ordinary
finite ties select the first input sample; NaNs select the last NaN encountered.
Padding cannot win an all-negative-infinity or integer-minimum tie over a real
input. Selected zero signs are preserved. Overlapping pullbacks accumulate in
native output order; nonoverlapping updates still add into zero so negative-zero
seeds have the native gradient sign. Tests cover float16/float32/float64 and
int8/int16/int32/int64/uint8 inference. Bool/complex and other unavailable modes
retain typed unsupported failures. Float16 autograd remains outside the
library's existing real float32/float64 AD boundary.

Float32/float64 support VJP, retained backward, JVP and reverse-over-forward.
The primal pullback saves input/index storage versions and does not save output
values. The tangent pullback saves tangent/index versions, with no false reverse
edge to the primal input. Detached output writes are allowed; saved input/index
writes invalidate the relevant tape. Existing restrictions on direct mutation
of differentiable non-leaf tensors still apply. Geometry is snapshotted and
no sampling Jacobian is materialized. Module state/training/forward hooks,
standard imports, pickle and graph ownership are covered independently.

Extreme dilated/padded windows may have no real sampled input. Actual native
probes return negative infinity and an index outside the input for examples
such as H=W=1, kernel=2, padding=1, dilation=2. Inference reproduces these values
and indices. Derivatives for that geometry are explicitly unsupported rather
than gathering/scattering invalid indices. This is a documented boundary, not a
claim that every native pooling mode or general higher-order reverse AD works.
Public geometry/parameter descriptions are available in the official
[MaxPool2d](https://docs.pytorch.org/docs/2.14/generated/torch.nn.MaxPool2d.html)
and [functional documentation](https://docs.pytorch.org/docs/2.14/generated/torch.nn.functional.max_pool2d.html);
selection, mutation and AD details also have recorded native CPU probes.

## Kernel choice and bounded packing

The first prototype compared generic offset scanning and vectorized packed
windows. Pure window selection helped large kernels and index/AD paths, but
slowed common 2x2 CNN inference on both CPU and WASM. Those original sources,
measurements and both refined pilots are retained.

The default uses a direct 2x2 path for unpadded, unit-dilation, stride-two windows
without a partial ceil tail. Other index/AD paths and larger inference kernels
can use window packing. A conservative 32 MiB temporary-workspace estimate
limits packing; other cases scan the kernel positions. Both implementations
share first-tie/last-NaN semantics. Unpadded windows avoid unnecessary coordinate
validation and inference avoids retaining full spatial indices. All private
algorithm overrides, including fallback cases, are covered against the same
oracles; they are not public API parameters.

This change retains NumPy CPU/Pyodide WASM execution and introduces no dependency
or GPU backend. The measurements below establish benefits for the tested flows;
they do not establish a WebGPU benefit or cross-runtime/native-Torch throughput.
A GPU route would need a complete resident tensor/AD path and a measured
end-to-end advantage, including transfers, before becoming a default backend.

## Local correctness and application gates

- Focused native pooling, independent contracts and feature discovery:
  **703 passes**.
- Full merged Python suite: **{full['passed']:,} passes, 1 optional skip,
  {full['warnings']} warnings, {full['duration_s']:.2f}s**.
- Final random oracle: **450 geometry/dtype trials**, all four algorithm
  selections, with values/indices/signs and valid reverse gradients compared
  against native Torch. Original prototype trials remain separate.
- Actual Node Pyodide and Chrome Worker: **1,730 checks in 37 suites each**,
  pinned Pyodide 0.29.4 / NumPy 2.2.5 without native Torch.
- Independent Python 3.10.19 / NumPy 1.26.4 wheel: **1,743 passes**.
  All **48** source/license resources match public/private wheels and source
  archives. Both installed namespaces run pooling VJP/JVP, module pickle,
  aliases and earlier checkpoint/optimizer workflows, then survive independent
  uninstall without native Torch installed.
- Original native catalog: **78 problems, 10,218 executions, 342 mutants,
  3 repeats, {app['native']['duration_s']:.2f}s** with unchanged deadlines.
- Actual exported WASM: **78/78 modules, 342 mutants,
  {app['exported_wasm']['elapsed_ms']}ms**, concurrency 2, no budget exceeded.
  Its attention test VM also executes all **1,730 checks/37 suites**, supplementing
  only the actual exported Schedules legacy module after production checks.
- Fresh catalog/private packaging, complete frontend checks and both typed
  builds pass on upstream `{app['upstream']}`. All **8,965** prior immutable
  payloads are retained byte-for-byte; **158** new assets are reachable and all
  **161** active index/payload files are SHA-256 frozen. The smaller Schedules
  profile remains six resources with its prior no-AD boundary.

Source comparison finds **45 unchanged shared resources**, one new pooling
module and version/API registration changes. Existing API AST is identical after
removing only the pooling additions. This supports, but does not replace, the
old-function regression measurements and full runtime tests.

The first independent test run incorrectly attempted direct mutation of
non-leaf tensors outside the library's supported mutation API and expected
leaves to disappear while their graph still owned them. Tests now use detached
storage aliases and require collection after discarding the graph, matching the
native ownership/version contract. The first 12 failures remain available.

## Complete new pooling and CNN workflows

Eight sequential fresh children cover two dtypes and two processes per CPU/WASM.
Each workflow uses nine ABBA/BAAB blocks, warmups, GC enabled and equal loop
counts. Every block checks outputs, gradient routes, dtypes and zero signs;
CNN training performs real SGD/momentum updates and checks updated parameters.
The table reports time reduction of the **default automatic path versus the
same version's generic scan**, not a comparison with version 0.37, which lacks
pooling. Negative values mean slower. Raw times, samples, first/refined pilots
and source identities remain in the reports.

| Complete workflow | CPU time reduction | WASM time reduction |
| --- | ---: | ---: |
{pool_table}

## Existing 0.37 to 0.38 workflow controls

A separate eight paired children retain the 21 old inverse/solve/JVP/autograd,
SGD and Schedules flows. Both versions use the same public APIs and the same
Python optional-feature default lookup. This table measures complete-flow
regressions; it does not claim a uniform numerical speedup from adding pooling.

| Existing workflow | CPU time reduction vs 0.37 | WASM time reduction vs 0.37 |
| --- | ---: | ---: |
{reg_table}

Cold CPU namespace import uses 16 fresh alternating children, reporting four
samples per version with/without preloaded NumPy. Median including NumPy:
{imports['0']['previous_037']['median_ms']:.2f} → {imports['0']['candidate_038']['median_ms']:.2f}ms;
preloaded: {imports['1']['previous_037']['median_ms']:.2f} → {imports['1']['candidate_038']['median_ms']:.2f}ms.
Source bytes: {footprint['previous_037']['raw_bytes']} → {footprint['candidate_038']['raw_bytes']};
local gzip estimates: {footprint['previous_037']['local_gzip_estimate_bytes']} →
{footprint['candidate_038']['local_gzip_estimate_bytes']}. Shared-host variation
and requested, unverified vendor thread counts limit interpretation. These are
not browser wire sizes, statistical guarantees or native-Torch import/throughput
comparisons. Raw outliers remain in the tables and archives.

## Reproduction and adoption

[`iteration-38.json`](../../packages/stridetorch/benchmarks/results/iteration-38.json)
and [`iteration-38-integration.json`](../../packages/stridetorch/benchmarks/results/iteration-38-integration.json)
contain exact source/test/artifact hashes, child receipts, full measurements and
hashed reproduction archives. Native-reference tests are test oracles, not
runtime dependencies. Later main synchronization/adoption is recorded separately.

The [explicit-release policy](../releasing.md) is unchanged: no CI, tag, workflow
dispatch, package upload or online publication is requested. The user will tag
later. Local results do not establish remote Linux CI or an online deployment.
Other pooling dimensions, average pooling, transpose convolution, normalization
coverage and measured backend improvements remain active work toward independent
library readiness.
'''
(repo/'docs/validation/torch-runtime-iteration-38.md').write_text(text)
roadmap=repo/'packages/stridetorch/ROADMAP.md';content=roadmap.read_text();marker='## Next implementation areas';assert marker in content and '## Version 0.38:' not in content
addition=f'''## Version 0.38: native-compatible 2D max pooling and CNN paths

- Add functional/root max_pool2d, with-indices and MaxPool2d with native
  geometry, int64 indices, finite/NaN/zero selection, noncontiguous inputs,
  empty batches, VJP/JVP, saved-storage guards, imports and Module lifecycle.
- Use measured 2x2 blocks, bounded packing and scan fallback. Complete CNN
  inference/SGD checks compare values, gradients and updated parameters;
  existing numerical workflows have a separate 0.37 regression comparison.
- Full suite {full['passed']:,} passes; actual Node/Chrome 1,730 each;
  minimum wheel 1,743. Native/exported catalogs and frontend/builds pass.
  Raw controls, compatibility limits and measurements are in the
  [validation record](../../docs/validation/torch-runtime-iteration-38.md).
- Quiet main adoption remains separate from publication. No CI/tag/dispatch
  or online release. Broader pooling/convolution/normalization remains active.

'''
roadmap.write_text(content.replace(marker,addition+marker));print('Wrote0.38 validation report and roadmap from exact receipts')
