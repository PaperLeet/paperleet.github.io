from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');old=r.parent/'torch-iteration-37/proof';p=r/'proof';p.mkdir()
source=repo/'packages/stridetorch/src/stridetorch'
for dest in (p/'source',p/'chrome-contracts/source'):shutil.copytree(source,dest,ignore=shutil.ignore_patterns('__pycache__'))
shutil.copytree(repo/'packages/stridetorch/tests',p/'chrome-contracts/tests',ignore=shutil.ignore_patterns('__pycache__'))
hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in source.iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')}
tests={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (repo/'packages/stridetorch/tests').glob('test_*.py') if f.name!='test_standalone.py'}
assert len(hashes)==48 and len(tests)==37
(p/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n');(p/'chrome-contracts/plan.json').write_text(json.dumps(dict(version='0.38.0',expected=1730,source=hashes,tests=tests),indent=2)+'\n')
for name in ('chrome-contracts/run.mjs','chrome-contracts/worker.mjs','chrome-contracts/index.html','wasm-contracts.mjs','check-wheel.py','check-coinstall.py'):
 text=(old/name).read_text().replace('torch-iteration-37/proof','torch-iteration-38/proof').replace('0.37','0.38').replace('stride037','stride038').replace('1581','1730').replace('1594','1743')
 if name=='wasm-contracts.mjs':text=text.replace("'linalg_failures','feature_detection'","'linalg_failures','feature_detection','pooling'")
 if name=='check-wheel.py':text=text.replace('len(names)==45','len(names)==46').replace('package_modules=45','package_modules=46')
 if name=='check-coinstall.py':
  marker="print('PASS isolated ownership,aliases,ZIP resume,triangular,Cholesky and Cholesky solve VJP/JVP/full tangent reverse')";assert marker in text
  addition="""for name in NAMES:
 m=importlib.import_module(name);t=m.torch
 x=t.tensor([[[[1.,2.,3.],[4.,9.,6.],[7.,8.,5.]]]],dtype=t.float64,requires_grad=True)
 p,i=t.nn.functional.max_pool2d(x,2,1,return_indices=True)
 assert p.tolist()==[[[[9.,9.],[9.,9.]]]] and i.tolist()==[[[[4,4],[4,4]]]]
 p.sum().backward();assert x.grad.tolist()==[[[[0.,0.,0.],[0.,4.,0.],[0.,0.,0.]]]]
 v=t.ones_like(x,requires_grad=True)
 p,dual=t.func.jvp(lambda z:t.nn.functional.max_pool2d(z,2,1),(x,),(v,));dual.sum().backward()
 assert v.grad.tolist()==[[[[0.,0.,0.],[0.,4.,0.],[0.,0.,0.]]]]
 model=t.nn.MaxPool2d(2);restored=pickle.loads(pickle.dumps(model));assert restored(x).shape==model(x).shape
 with m.as_torch():
  from torch.nn.modules.pooling import MaxPool2d
  assert MaxPool2d is t.nn.MaxPool2d
"""
  text=text.replace(marker,addition+marker)
 (p/name).write_text(text)
for name in ('run-gates.py','run-full.py'):(r/name).write_text((r.parent/'torch-iteration-37'/name).read_text())
state=dict(previous_goal_turn='progress:0.37 source724b7e8a/proof07df8e50 quietly adopted with0Actions; broad goal active.',version='0.38.0',baseline_main='07df8e50858d5108f2b49c3e1b3b2c18802e370f',upstream=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),phase='Frozen48resources/37suites for full1730 browser and1743 min wheel;703 focusednative+independent+feature checks passed;450random comparisons and two-stage4-childCPU/WASM pilots retained. Launch full/root and6 package gates next.',expected_full_minimum=33167,expected_browser=1730,expected_minimal=1743,focused=703,source_hashes=hashes,policy='No CI/tag/dispatch/package upload/online publication; name pending user selection; goal active.')
(r/'state.json').write_text(json.dumps(state,indent=2)+'\n')
print('Frozen0.38:48resources,37suites/1730browser,1743minimumwheel',state['upstream'])
