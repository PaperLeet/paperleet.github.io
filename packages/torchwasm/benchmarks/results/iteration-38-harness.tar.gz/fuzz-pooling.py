from pathlib import Path
import json,traceback,numpy as np,torch
from stridetorch import torch as lite,_pooling
rng=np.random.default_rng(3801);rows=[];counts=dict(valid=0,invalid=0,derivatives=0)
for trial in range(450):
 h,w=rng.integers(1,10,size=2).tolist();k=rng.integers(1,6,size=2).tolist();s=rng.integers(1,5,size=2).tolist();d=rng.integers(1,4,size=2).tolist();pad=[int(rng.integers(v//2+1)) for v in k]
 kw=dict(kernel_size=k,stride=s,dilation=d,padding=pad,ceil_mode=bool(trial%2),return_indices=True)
 dtype=[np.float32,np.float64,np.float16,np.int8,np.int16,np.int32,np.int64,np.uint8][trial%8]
 a=rng.integers(0,7,size=(2,3,h,w)).astype(dtype)
 if trial%11==0 and np.dtype(dtype).kind=='f':a.flat[::3]=np.nan
 if trial%13==0 and np.dtype(dtype).kind=='f':a[:]=-np.inf
 if trial%17==0 and np.dtype(dtype).kind=='f':a[:]=0;a.flat[::2]=-0.
 if trial%3==0:a=a[0]
 if trial%7==0:a=np.repeat(a,2,axis=-1)[...,::2]
 try:ny,ni=torch.nn.functional.max_pool2d(torch.from_numpy(a),**kw)
 except Exception as ne:
  for algorithm in ['scan','window','auto']:
   _pooling._ALGORITHM=algorithm
   try:lite.nn.functional.max_pool2d(lite.from_numpy(a),**kw)
   except Exception:pass
   else:raise AssertionError(('native invalid accepted',trial,kw,a.shape))
  counts['invalid']+=1;continue
 for algorithm in ['scan','window','auto']:
  _pooling._ALGORITHM=algorithm
  y,i=lite.nn.functional.max_pool2d(lite.from_numpy(a),**kw)
  np.testing.assert_array_equal(i.numpy(),ni.numpy());np.testing.assert_allclose(y.numpy(),ny.numpy(),rtol=0,atol=0,equal_nan=True)
  if np.dtype(dtype).kind=='f':np.testing.assert_array_equal(np.signbit(y.numpy()),np.signbit(ny.numpy()))
  if dtype in (np.float32,np.float64) and bool(((ni>=0)&(ni<h*w)).all()):
   # Geometric holes may alias another row's valid flattened index. Exclude
   # those inference-only cases using the actual sampled-coordinate domain.
   geometry=_pooling._geometry(lite.from_numpy(a),**{key:value for key,value in kw.items() if key!='return_indices'})
   _,first=_pooling._coordinates(a.shape,geometry)
   if np.any(first[0]>=h) or np.any(first[1]>=w):continue
   x=lite.from_numpy(a).requires_grad_();nx=torch.from_numpy(a).requires_grad_();yy,ii=lite.nn.functional.max_pool2d(x,**kw);nny,nni=torch.nn.functional.max_pool2d(nx,**kw)
   seed=rng.normal(size=yy.shape).astype(dtype);yy.backward(lite.tensor(seed));nny.backward(torch.tensor(seed));np.testing.assert_allclose(x.grad.numpy(),nx.grad.numpy(),rtol=0,atol=0,equal_nan=True);counts['derivatives']+=1
 counts['valid']+=1
_pooling._ALGORITHM='auto';Path(__file__).with_suffix('.json').write_text(json.dumps(dict(status='success',seed=3801,trials=450,algorithms=['scan','window','auto'],counts=counts),indent=2)+'\n');print(counts)
