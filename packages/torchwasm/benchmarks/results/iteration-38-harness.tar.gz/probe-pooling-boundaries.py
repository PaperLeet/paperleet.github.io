from pathlib import Path
import json,torch
from torch.nn import functional as F
rows=[]
for shape,kw in [((1,1,1,1),dict(kernel_size=2,dilation=2,padding=1)),((1,1,2,2),dict(kernel_size=2,dilation=3,padding=1,ceil_mode=True)),((1,1,3,3),dict(kernel_size=(2,),stride=[]))]:
 x=torch.ones(shape);y,i=F.max_pool2d(x,return_indices=True,**kw);rows.append(dict(kind='holes',shape=shape,kw=kw,value=y.tolist(),indices=i.tolist()))
for mutation in ['input','indices','output','none']:
 x=torch.arange(9,dtype=torch.float64).reshape(1,1,3,3).requires_grad_();y,i=F.max_pool2d(x,2,1,return_indices=True)
 with torch.no_grad():
  if mutation=='input':x.add_(1)
  elif mutation=='indices':i.add_(1)
  elif mutation=='output':y.add_(1)
 try:y.sum().backward();rows.append(dict(kind='mutation',target=mutation,status='success',gradient=x.grad.tolist()))
 except Exception as e:rows.append(dict(kind='mutation',target=mutation,error=type(e).__name__,message=str(e)))
for args in [dict(kernel_size=True),dict(kernel_size=(2,)),dict(kernel_size=[2]),dict(kernel_size=(2,2,2)),dict(kernel_size=2,stride=()),dict(kernel_size=2,return_indices=1),dict(kernel_size=2,padding=True),dict(kernel_size=2,dilation=True)]:
 try:r=F.max_pool2d(torch.ones(1,1,4,4),**args);rows.append(dict(kind='arguments',args=args,result_type=type(r).__name__))
 except Exception as e:rows.append(dict(kind='arguments',args=args,error=type(e).__name__,message=str(e)))
p=Path(__file__).with_suffix('.json');p.write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
