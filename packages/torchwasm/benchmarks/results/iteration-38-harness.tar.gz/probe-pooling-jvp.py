from pathlib import Path
import json,torch
F=torch.nn.functional;rows=[]
for target in ['none','input','tangent','indices','primal_output','tangent_output']:
 x=torch.arange(9,dtype=torch.float64).reshape(1,1,3,3).requires_grad_();v=torch.ones_like(x,requires_grad=True)
 (p,idx),(t,ti)=torch.func.jvp(lambda z:F.max_pool2d(z,2,1,return_indices=True),(x,),(v,))
 with torch.no_grad():
  if target=='input':x.add_(1)
  if target=='tangent':v.add_(1)
  if target=='indices':idx.add_(1)
  if target=='primal_output':p.add_(1)
  if target=='tangent_output':t.add_(1)
 try:t.sum().backward();rows.append(dict(target=target,indices_tangent_dtype=str(ti.dtype),x_grad=None if x.grad is None else x.grad.tolist(),v_grad=None if v.grad is None else v.grad.tolist()))
 except Exception as e:rows.append(dict(target=target,error=type(e).__name__,message=str(e)))
rows.append(dict(root_pool=hasattr(torch,'max_pool2d'),root_indices=hasattr(torch,'max_pool2d_with_indices'),functional_indices=hasattr(F,'max_pool2d_with_indices')))
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
