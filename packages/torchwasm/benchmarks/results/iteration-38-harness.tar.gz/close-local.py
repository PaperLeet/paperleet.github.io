from pathlib import Path
import hashlib,json,os,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results';p=r/'proof';i=r/'integration-proof'
def read(name):return json.loads((r/name).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(name,value):(out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
actual={f.name:sha(f) for f in (repo/'packages/stridetorch/src/stridetorch').iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')};assert len(actual)==48 and actual==read('proof/source-hashes.json')
tests={f.name:sha(f) for f in (repo/'packages/stridetorch/tests').glob('test_*.py') if f.name!='test_standalone.py'};plan=read('proof/chrome-contracts/plan.json');assert len(tests)==37 and plan['tests']==tests and plan['source']==actual and plan['expected']==1730
full=read('full-root-receipt.json');assert full['exit_code']==0 and full['passed']>=33167 and full['skipped']==1
assert '703 passed' in (r/'focus-pool-final.log').read_text()
gates=read('proof/gate-receipts.json');assert len(gates)==6 and all(v['exit_code']==0 for v in gates.values())
node=read('proof/source-wasm.json');chrome=read('proof/chrome-contracts/result.json');wheel=read('proof/wheel-stride038-result.json');coinstall=read('proof/coinstall-result.json')
assert node['passed']==chrome['passed']==1730 and node['source_hashes']==chrome['source_hashes']==wheel['source_hashes']==coinstall['source_hashes']==actual
assert chrome['test_hashes']==tests and chrome['status']==wheel['status']==coinstall['status']=='success' and not wheel['native_torch']
assert '1743 passed' in (p/'python310-stride038-tests.log').read_text()
audit=read('existing-source-audit.json');assert audit['status']=='success' and audit['unchanged_resources']==45 and audit['source_hashes']==actual
fuzz=read('fuzz-pooling-final.json');assert fuzz['status']=='success' and fuzz['trials']==450 and fuzz['algorithms']==['scan','window','block','auto'] and fuzz['source_hashes']==actual
regression=read('performance-final-summary.json');pooling=read('pooling-final-summary.json');imports=read('import-summary.json')
assert len(regression['receipts'])==len(pooling['receipts'])==8 and all(v['exit_code']==0 for v in [*regression['receipts'].values(),*pooling['receipts'].values()])
assert len(imports['receipts'])==16 and all(v['exit_code']==0 for v in imports['receipts'])
for folder,field in [('performance-final','candidate'),('pool-performance-final',None)]:
 for f in (r/folder).glob('*.json'):
  if f.name=='receipts.json':continue
  record=json.loads(f.read_text());assert (record['source_hashes'][field] if field else record['source_hashes'])==actual
  assert len(record['results'])==(21 if field else 24)
receipts=read('final-sequential-receipts.json');assert len(receipts)==5 and all(v['exit_code']==0 for v in receipts)
native=read('integration-proof/native-ci.json');wasm=read('integration-proof/full-wasm-result.json');setup=read('integration-proof/setup-receipts.json');front=read('integration-proof/frontend-receipts.json');snapshot=read('integration-proof/release-snapshot.json');exports=read('integration-proof/export-identity.json');private=read('integration-proof/distribution-identity.json')
assert native['passed'] and native['problems']==78 and native['tests_executed']==10218 and native['repeats']==3 and native['duration_s']<=600 and not native['issues']
assert len(native['mutation'])==78 and sum(map(len,native['mutation'].values()))==342 and all(hits for rows in native['mutation'].values() for hits in rows.values())
assert wasm['passed'] and wasm['catalog_modules']==wasm['modules']==78 and not wasm['browser_budget_exceeded'] and sum(v['mutants'] for v in wasm['results'])==342
assert all(v['passed'] and not v['browser_budget_exceeded'] for v in wasm['results'])
attention=next(v for v in wasm['results'] if v['id']=='architecture/attention')['independent_contracts'];assert attention['passed']==1730 and len(attention['suites'])==37 and {v['suite']:v['source_sha256'] for v in attention['suites']}==tests
profiles=attention['runtime_profiles'];assert len(profiles)==2 and profiles[0]['supplemented_files']==[] and profiles[1]['supplemented_files']==[dict(name='stridetorch/_legacy.py',source_sha256=actual['_legacy.py'])]
assert len(setup)==4 and len(front)==5 and all(v['exit_code']==0 for v in setup+front)
assert snapshot['source_hashes']==actual and exports['published_assets_unchanged']==8965 and exports['active_assets']==exports['new_assets']==158 and exports['all_new_assets_reachable'] and private['status']=='success'
assert next(v for v in exports['runtimes'].values() if v['backend']=='numpy-wasm')['package_files']==6
harness=read('integration-proof/wasm-harness-identity.json');assert sha(repo/harness['file'])==harness['sha256'] and sha(repo/harness['driver_file'])==harness['driver_sha256']
live=read('integration-proof/live-expected-sha256.json');assert len(live)==161
for name,digest in live.items():assert sha(repo/'web/public/data'/name)==digest
for folder,paths in [('native-contracts',(repo/'tests').glob('test_torch_*')),('package-metadata',[(repo/'packages/stridetorch'/name) for name in ('README.md','pyproject.toml','LICENSE','NOTICE')])]:
 dest=r/folder;dest.mkdir(exist_ok=True)
 for f in paths:
  if f.is_file():shutil.copy2(f,dest/f.name)
shutil.copy2(repo/'tests/test_browser_judge.py',r/'native-contracts/test_browser_judge.py')
shutil.copy2(repo/'packages/stridetorch/tests/test_standalone.py',r/'package-metadata/test_standalone.py')
def archive(name,root,excluded):
 files=[]
 for folder,dirs,names in os.walk(root):
  dirs[:]=[d for d in dirs if not d.endswith('-env') and d not in excluded and d not in ('__pycache__','.pytest_cache')]
  for name2 in names:
   f=Path(folder)/name2
   if not f.is_symlink() and (f.name in ('LICENSE','NOTICE') or f.suffix in ('.py','.mjs','.cjs','.json','.log','.txt','.md','.html','.toml','.diff')):files.append(f)
 path=out/name
 with tarfile.open(path,'w:gz') as tar:
  for f in sorted(files):tar.add(f,arcname=str(f.relative_to(root)),recursive=False)
 return dict(file=path.name,files=len(files),bytes=path.stat().st_size,sha256=sha(path))
core_archive=archive('iteration-38-harness.tar.gz',r,{'dist-preflight','private-dist','dist-paperleet','integration-proof','main-sync-proof','main-sync-final'})
core=dict(status='complete_local_core_and_application_gates_passed_main_adoption_pending',version='0.38.0',baseline_main='07df8e50858d5108f2b49c3e1b3b2c18802e370f',source_hashes=actual,standalone_test_hashes=tests,native_test_hashes={f.name:sha(f) for f in (r/'native-contracts').iterdir()},full_cpu=full,focused_passed=703,minimal_passed=1743,minimal_wheel=wheel,node_wasm=node,actual_chrome_worker=chrome,coinstall=coinstall,gate_receipts=gates,existing_source_audit=audit,final_random_oracle=fuzz,final_existing_workflows=regression,final_pooling_workflows=pooling,cold_namespace_imports=imports,pilots=dict(first_receipts=read('pool-pilot-receipts.json'),refined_receipts=read('pool-refined-receipts.json'),first_cpu_float32='pool-pilot-cpu-float32.json'),archive=core_archive,scope='Functional/root max_pool2d, functional with-indices and nn.MaxPool2d with imports, geometry, stride/dilation/ceil/padding, noncontiguous arrays, empty batches, native index/tie/NaN/signed-zero choices, VJP/JVP/reverse-over-forward, version guards, Module lifecycle/pickle and real CNN SGD parity. Default2x2 blocks; bounded window packing for index/AD or large kernels; scan fallback. No new dependency or GPU backend.',retained_findings=['First independent test assumptions attempted direct differentiable non-leaf mutation, which the existing library deliberately rejects, and required early leaf release while its tape still owned it. Tests now use detached storage aliases and check native-compatible release after discarding the graph; all first12 failures retained.','Initial pure-window prototype improved large kernels/index routing but slowed common CNN inference. Preserve both dtype/runtime pilots and first sources; default uses measured specialized2x2/conditional windows/scans.','Native empty dilated sampling windows can expose indices outside the input. Inference values/indices agree with native; derivative paths are explicitly unsupported rather than gathering invalid memory.','Pooling speed comparisons are within0.38 against its generic scan implementation. Version0.37 has no pooling;21 separate same-API old numerical workflows measure regressions.'],primary_sources=['https://docs.pytorch.org/docs/2.14/generated/torch.nn.MaxPool2d.html','https://docs.pytorch.org/docs/2.14/generated/torch.nn.functional.max_pool2d.html'],release_policy='No CI, tag, dispatch, package upload or online publication; user will explicitly release later.')
save('iteration-38.json',core)
app_archive=archive('iteration-38-integration-harness.tar.gz',i,{'dist-paperleet'})
app=dict(status='complete_local_application_gates_passed_main_adoption_pending',version='0.38.0',upstream=read('integration-proof/context.json')['upstream'],source_hashes=actual,core_report='iteration-38.json',native=native,exported_wasm=wasm,setup_receipts=setup,frontend_receipts=front,release_snapshot=snapshot,export_integrity=exports,distribution_identity=private,runtime_sizes=read('integration-proof/runtime-sizes.json'),wasm_harness=harness,context=read('integration-proof/context.json'),archive=app_archive,publication='Local results do not assert remote Linux CI or online deployment. No CI/tag/dispatch requested.')
save('iteration-38-integration.json',app);print(json.dumps(dict(core=core_archive,integration=app_archive,native_s=native['duration_s'],wasm_ms=wasm['elapsed_ms']),indent=2))
