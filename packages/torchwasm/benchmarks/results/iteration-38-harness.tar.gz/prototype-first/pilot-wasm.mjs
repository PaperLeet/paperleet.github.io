import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const repo='/Users/david/Developer/PaperLeet-torch-release';
const source=path.join(repo,'packages/stridetorch/src/stridetorch');
const py=await loadPyodide({indexURL:path.join(repo,'web/node_modules/pyodide/'),packageCacheDir:path.join(repo,'web/public/browser-runtime/pyodide-0.29.4/'),stdout:console.log,stderr:console.error});
await loadJudgePackages(py,[]);py.FS.mkdirTree('/runtime/stridetorch');
const hashes={};
for(const name of fs.readdirSync(source).filter(n=>n.endsWith('.py')||['LICENSE','NOTICE'].includes(n))){
 const bytes=fs.readFileSync(path.join(source,name));py.FS.writeFile('/runtime/stridetorch/'+name,bytes);hashes[name]=crypto.createHash('sha256').update(bytes).digest('hex');
}
py.FS.writeFile('/runtime/test_pooling.py',fs.readFileSync(path.join(repo,'packages/stridetorch/tests/test_pooling.py')));
const result=JSON.parse(py.runPython(`
import sys,json
sys.path.insert(0,'/runtime')
import pytest,numpy,stridetorch
class Results:
    passed=0
    def pytest_runtest_logreport(self,report):
        if report.when=='call' and report.passed:self.passed+=1
record=Results()
code=pytest.main(['/runtime/test_pooling.py','-q','--noconftest','-p','no:cacheprovider','--import-mode=importlib'],plugins=[record])
assert int(code)==0 and record.passed==99,(code,record.passed)
json.dumps(dict(status='success',scope='Pre-freeze prototype pooling pilot; not final release evidence.',passed=record.passed,numpy=numpy.__version__,python=sys.version,library=stridetorch.__version__))
`));
assert.equal(result.numpy,'2.2.5');result.source_hashes=hashes;fs.writeFileSync(new URL('pilot-wasm.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
