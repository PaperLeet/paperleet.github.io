"""Complete pooling/CNN paths: paired scan/window timings plus value/state checks."""
from pathlib import Path
import gc,hashlib,json,os,statistics,time
import numpy as np
import stridetorch
from stridetorch import torch as api,_pooling
DTYPE=np.dtype(os.getenv('BENCH_DTYPE','float32'));rng=np.random.default_rng(3805)
BLOCKS=9
CASES=[('tiny',(1,2,8,8),dict(kernel_size=2)),('image',(2,8,32,32),dict(kernel_size=2)),('overlap',(2,8,24,24),dict(kernel_size=3,stride=1,padding=1)),('dilated',(1,4,24,24),dict(kernel_size=3,stride=2,padding=1,dilation=2)),('large-kernel',(1,8,32,32),dict(kernel_size=5,stride=2,padding=2)),('workspace-fallback',(2,16,64,64),dict(kernel_size=7,stride=1,padding=3))]

def arrays(value):
 if isinstance(value,api.Tensor):return [value.detach().numpy()]
 return [item for v in value for item in arrays(v)]

def check(a,b):
 for x,y in zip(arrays(a),arrays(b)):
  assert x.dtype==y.dtype and x.shape==y.shape
  np.testing.assert_array_equal(x,y)
  if x.dtype.kind=='f':np.testing.assert_array_equal(np.signbit(x),np.signbit(y))

def pooling_factory(shape,kw,mode):
 data=rng.normal(size=shape).astype(DTYPE);direction=rng.normal(size=shape).astype(DTYPE)
 def build():
  x=api.tensor(data,requires_grad=mode in ('backward','jvp'));v=api.tensor(direction,requires_grad=mode=='jvp')
  def run():
   if mode=='jvp':
    x.grad=None;v.grad=None;p,t=api.func.jvp(lambda z:api.nn.functional.max_pool2d(z,**kw),(x,),(v,));t.square().mean().backward();return p,t,v.grad
   y=api.nn.functional.max_pool2d(x,**kw,return_indices=mode=='indices')
   if mode=='backward':x.grad=None;y.square().mean().backward();return y,x.grad
   return y
  return run
 return build

def cnn_factory(size,training):
 n,c,h,w=(1,2,8,8) if size=='tiny' else (2,3,16,16)
 channels=3 if size=='tiny' else 6;classes=4 if size=='tiny' else 8
 data=rng.normal(size=(n,c,h,w)).astype(DTYPE);target=rng.normal(size=(n,classes)).astype(DTYPE)
 shapes=[(channels,c,3,3),(channels,),(classes,channels*(h//2)*(w//2)),(classes,)]
 weights=[rng.normal(size=s).astype(DTYPE)*.04 for s in shapes]
 def build():
  model=api.nn.Sequential(api.nn.Conv2d(c,channels,3,padding=1),api.nn.ReLU(),api.nn.MaxPool2d(2),api.nn.Flatten(),api.nn.Linear(shapes[2][1],classes)).to(dtype=DTYPE)
  parameters=list(model.parameters())
  with api.no_grad():
   for p,a in zip(parameters,weights):p.copy_(api.tensor(a))
  x=api.tensor(data,requires_grad=training);label=api.tensor(target);optimizer=api.optim.SGD(parameters,lr=.0001,momentum=.7)
  def run():
   if not training:
    with api.no_grad():return model(x)
   x.grad=None;optimizer.zero_grad(set_to_none=True);y=model(x);loss=api.nn.functional.mse_loss(y,label);loss.backward();optimizer.step()
   return y,loss,x.grad,*parameters,*[p.grad for p in parameters]
  return run
 return build


def paired(factory):
 _pooling._ALGORITHM='scan';calibrate=factory();calibrate();start=time.perf_counter();calibrate();elapsed=time.perf_counter()-start
 loops=max(1,min(128,int(.003/max(elapsed,1e-7))))
 runs={mode:factory() for mode in ('scan','window')}
 for mode,run in runs.items():
  _pooling._ALGORITHM=mode
  for _ in range(3):last=run()
  if mode=='scan':first=last
  else:check(first,last)
 samples=[]
 for block in range(BLOCKS):
  order=('scan','window','window','scan') if block%2==0 else ('window','scan','scan','window')
  times={'scan':[],'window':[]};last={};gc.collect()
  for mode in order:
   _pooling._ALGORITHM=mode;start=time.perf_counter()
   for _ in range(loops):value=runs[mode]()
   times[mode].append((time.perf_counter()-start)/loops);last[mode]=value
  check(last['scan'],last['window'])
  base=statistics.mean(times['scan']);candidate=statistics.mean(times['window'])
  samples.append(dict(order=order,scan_s=base,window_s=candidate,time_reduction_percent=100*(base-candidate)/base))
 return dict(loops=loops,blocks=samples,median_time_reduction_percent=statistics.median(v['time_reduction_percent'] for v in samples),scan_median_us=statistics.median(v['scan_s'] for v in samples)*1e6,window_median_us=statistics.median(v['window_s'] for v in samples)*1e6)

results={}
for name,shape,kw in CASES:
 for mode in ('inference','indices','backward'):
  results[f'{name}-{mode}']=paired(pooling_factory(shape,kw,mode))
 if name in ('tiny','overlap'):results[f'{name}-jvp']=paired(pooling_factory(shape,kw,'jvp'))
for size in ('tiny','image'):
 for training in (False,True):results[f'cnn-{size}-'+('sgd' if training else 'inference')]=paired(cnn_factory(size,training))
_pooling._ALGORITHM='auto'
source=Path(stridetorch.__file__).parent
BENCH_REPORT=dict(scope='Prototype candidate scan versus bounded window packing, not a speedup against0.37 which lacks pooling. Window label includes scan fallback when32MiB bound is exceeded. Complete inference/indices/backward/JVP and CNN SGDs check equal outputs, gradients, dtypes, zero signs and updated parameters after every paired block.',dtype=DTYPE.name,gc_enabled=gc.isenabled(),blocks=BLOCKS,results=results,source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')})
print(json.dumps(BENCH_REPORT))
