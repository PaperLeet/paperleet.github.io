from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;i=r/'integration-proof';i.mkdir();repo=Path('/Users/david/Developer/PaperLeet-torch-release');old=r.parent/'torch-iteration-37/integration-proof'
upstream=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
for name in ('verify-export.py','run-export.py','freeze.py','verify-private.py','run-frontend.py','run-setup.py','run-native.py','run-wasm.py'):
 text=(old/name).read_text().replace('0.37.0','0.38.0').replace('==8807','==8965').replace('1581','1730').replace('len(tests)==36','len(tests)==37').replace('expected_suites=36','expected_suites=37').replace('core_modules=45','core_modules=46').replace('all_47_core_license_hashes_identical','all_48_core_license_hashes_identical').replace('iteration37 integration','iteration38 integration').replace('torch-iteration-36/integration-proof/owned-dependencies.json','torch-iteration-37/integration-proof/owned-dependencies.json')
 (i/name).write_text(text)
source=json.loads((r/'proof/source-hashes.json').read_text());assert len(source)==48 and all(hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/k).read_bytes()).hexdigest()==v for k,v in source.items())
(i/'context.json').write_text(json.dumps(dict(upstream=upstream,source_hashes=source,core_report='iteration-38.json',release_policy='No CI, tag, dispatch, package upload or online publication. User will explicitly tag later.',scope='All8965 prior immutable assets retained. Add actual max_pool2d/MaxPool2d and native selection/VJP/JVP; Schedules retains six resources and no-AD behavior. Fresh current private catalog, full native/exported WASM/frontend/both builds required; timings run after heavy gates.'),indent=2)+'\n')
(i/'dist-paperleet').mkdir()
for p in (r/'proof/private-dist').iterdir():shutil.copy2(p,i/'dist-paperleet'/p.name)
print('Prepared0.38 integration',upstream,'8965prior assets')
