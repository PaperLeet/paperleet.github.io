from pathlib import Path
import json,os,subprocess,time,statistics
r=Path(__file__).resolve().parent;out=r/'pool-performance-final';out.mkdir();py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';receipts={};rows={}
expected=json.loads((r/'proof/source-hashes.json').read_text())
for repeat in (1,2):
 for runtime in (('cpu','wasm') if repeat==1 else ('wasm','cpu')):
  for dtype in ('float32','float64'):
   name=f'{runtime}-{dtype}-{repeat}';args=[str(py),str(r/'bench-pooling.py')] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(r/'bench-pooling-wasm.mjs')]
   env=dict(os.environ,BENCH_LIBRARY_SOURCE=str(r/'proof/source'),BENCH_DTYPE=dtype,POOL_BASELINE='scan',POOL_CANDIDATE='auto',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');start=time.monotonic()
   with (out/(name+'.json')).open('w') as stdout,(out/(name+'.stderr.log')).open('w') as stderr:p=subprocess.run(args,cwd=r,env=env,stdout=stdout,stderr=stderr)
   receipts[name]=dict(exit_code=p.returncode,elapsed_s=time.monotonic()-start,args=args);(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode()
   row=json.loads((out/(name+'.json')).read_text());assert row['source_hashes']==expected and row['gc_enabled'] and row['blocks']==9 and len(row['results'])==24 and row['baseline_algorithm']=='scan' and row['candidate_algorithm']=='auto'
   if runtime=='wasm':assert row['runtime']['numpy']=='2.2.5'
   rows[name]=row;print(name,'terminal0',flush=True)
summary={runtime:{key:dict(median_time_reductions_percent=[rows[f'{runtime}-{dtype}-{repeat}']['results'][key]['median_time_reduction_percent'] for dtype in ('float32','float64') for repeat in (1,2)],scan_median_us=[rows[f'{runtime}-{dtype}-{repeat}']['results'][key]['scan_median_us'] for dtype in ('float32','float64') for repeat in (1,2)],auto_median_us=[rows[f'{runtime}-{dtype}-{repeat}']['results'][key]['window_median_us'] for dtype in ('float32','float64') for repeat in (1,2)]) for key in next(iter(rows.values()))['results']} for runtime in ('cpu','wasm')}
(r/'pooling-final-summary.json').write_text(json.dumps(dict(scope='Eight fresh sequential children/two dtypes/two repeats per CPU-WASM;24 complete workflows,9 ABBA-BAAB blocks and GC enabled. Compare default automatic pooling to generic scan within0.38, not to nonexistent0.37 pooling or native Torch. All block outputs/gradients/dtypes/zero signs and actual CNN updated parameters match. Shared host, requested vendor thread limits unverified.',summary=summary,receipts=receipts,source_hashes=expected),indent=2)+'\n')
