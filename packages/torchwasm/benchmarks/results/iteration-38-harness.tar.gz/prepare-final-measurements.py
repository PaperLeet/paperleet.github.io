from pathlib import Path
import shutil
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-37'
(r/'baseline').mkdir();shutil.copytree(old/'proof/source',r/'baseline/stridetorch')
for name in ('bench-library.py','bench-library-wasm.mjs','bench-import.py','run-performance-final.py','run-imports.py'):
 text=(old/name).read_text().replace('candidate_037','candidate_038').replace('previous_036','previous_037').replace('0.37.0','0.38.0').replace('0.36.0','0.37.0')
 if name=='bench-library.py':
  begin="                    if label=='candidate':optional=getattr(lib,'not_a_real_torch_symbol_37',None)\n                    else:\n                        try:optional=getattr(lib,'not_a_real_torch_symbol_37')\n                        except package_error:optional=None"
  assert begin in text;text=text.replace(begin,"                    optional=getattr(lib,'not_a_real_torch_symbol_37',None)")
  text=text.replace('Same 0.36/0.37 inverse APIs','Same0.37/0.38inverse APIs').replace('Optional-SGD and optional legacy inference use Python default lookup in candidate and an explicit legacy UnsupportedOperation catch in baseline','Optional-SGD and optional legacy inference use identical Python default lookup in both namespaces')
 if name=='run-performance-final.py':text=text.replace('Optional-probe workloads compare Python default lookup to the explicit legacy unsupported-error workaround.','Optional-probe workloads use the same Python default lookup on both sides.')
 (r/name).write_text(text)
# Freeze the library used by the final pooling benchmarks; prototypes remain in prior reports.
p=r/'bench-pooling.py';text=p.read_text();text=text.replace('import stridetorch\n',"import importlib.util,sys\nif os.getenv('BENCH_LIBRARY_SOURCE'):\n folder=Path(os.environ['BENCH_LIBRARY_SOURCE']);spec=importlib.util.spec_from_file_location('stridetorch',folder/'__init__.py',submodule_search_locations=[str(folder)]);stridetorch=importlib.util.module_from_spec(spec);sys.modules['stridetorch']=stridetorch;spec.loader.exec_module(stridetorch)\nelse:import stridetorch\n")
p.write_text(text)
p=r/'bench-pooling-wasm.mjs';text=p.read_text().replace("const source=path.join(repo,'packages/stridetorch/src/stridetorch');","const source=process.env.BENCH_LIBRARY_SOURCE||path.join(repo,'packages/stridetorch/src/stridetorch');");p.write_text(text)
print('Prepared same-API0.37/0.38 controls and frozen-source pooling measurements')
