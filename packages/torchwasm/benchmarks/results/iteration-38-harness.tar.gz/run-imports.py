from pathlib import Path
import json,os,subprocess,time,statistics,shutil
r=Path(__file__).resolve().parent;p=r/'performance-imports';p.mkdir(exist_ok=True);shutil.copy2(r.parent/'torch-iteration-31/bench-import.py',r/'bench-import.py');receipts=[];rows={};sources=dict(previous_037=r/'baseline/stridetorch',candidate_038=r/'proof/source')
for preload in ('0','1'):
 for repeat in range(4):
  for label in (list(sources) if repeat%2==0 else list(reversed(sources))):
   name=f'{preload}-{repeat}-{label}';args=[str(r.parent/'torch-iteration-21/stride-dev-env/bin/python'),str(r/'bench-import.py')];env=dict(os.environ,IMPORT_SOURCE=str(sources[label]),IMPORT_PRELOAD=preload);start=time.monotonic()
   with (p/(name+'.json')).open('w') as output,(p/(name+'.stderr.log')).open('w') as error:proc=subprocess.run(args,env=env,cwd=r,stdout=output,stderr=error)
   receipts.append(dict(name=name,exit_code=proc.returncode,elapsed_s=time.monotonic()-start));(p/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');proc.check_returncode();row=json.loads((p/(name+'.json')).read_text());assert not row['zipfile_imported'];assert row['version']==('0.37.0' if label=='previous_037' else '0.38.0');rows.setdefault(preload,{}).setdefault(label,[]).append(row)
expected=json.loads((r/'proof/source-hashes.json').read_text());assert all(row['source_hashes']==expected for v in rows.values() for row in v['candidate_038'])
summary={preload:{label:dict(samples_ms=[row['namespace_import_ms'] for row in samples],median_ms=statistics.median(row['namespace_import_ms'] for row in samples)) for label,samples in sets.items()} for preload,sets in rows.items()}
(r/'import-summary.json').write_text(json.dumps(dict(scope='16fresh alternating CPU processes after all compatibility gates;NumPy included/preloaded reported separately;shared host;no browser wire-size or nativeTorch import comparison.',summary=summary,receipts=receipts),indent=2)+'\n');print(json.dumps(summary))
