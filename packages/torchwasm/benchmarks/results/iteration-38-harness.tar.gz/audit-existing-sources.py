from pathlib import Path
import ast,hashlib,json
r=Path(__file__).resolve().parent;old=r/'baseline/stridetorch';new=r/'proof/source'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
previous={p.name:sha(p) for p in old.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};candidate={p.name:sha(p) for p in new.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
assert len(previous)==47 and len(candidate)==48 and set(candidate)-set(previous)=={'_pooling.py'}
changed=[n for n in previous if previous[n]!=candidate[n]];assert set(changed)=={'__init__.py','_api.py'}
class Normalize(ast.NodeTransformer):
 def visit_ImportFrom(self,node):
  node.names=[v for v in node.names if v.name!='_pooling'];return node
 def visit_Tuple(self,node):
  node=self.generic_visit(node);node.elts=[v for v in node.elts if not (isinstance(v,ast.Constant) and v.value=='nn.modules.pooling') and not (isinstance(v,ast.Tuple) and v.elts and isinstance(v.elts[0],ast.Name) and v.elts[0].id=='_pooling')];return node
 def visit_Dict(self,node):
  node=self.generic_visit(node);pairs=[(k,v) for k,v in zip(node.keys,node.values) if not (isinstance(k,ast.Constant) and k.value=='pooling')];node.keys=[p[0] for p in pairs];node.values=[p[1] for p in pairs];return node
 def visit_Expr(self,node):
  if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and isinstance(node.value.func.value,ast.Name) and node.value.func.value.id=='registry' and any(isinstance(n,ast.Name) and n.id=='_pooling' for n in ast.walk(node)):return None
  return self.generic_visit(node)
a=ast.dump(ast.parse((old/'_api.py').read_text()),include_attributes=False);b=ast.dump(Normalize().visit(ast.parse((new/'_api.py').read_text())),include_attributes=False);assert a==b
report=dict(status='success',unchanged_resources=45,changed_existing=changed,new_resources=['_pooling.py'],existing_registration_ast='Identical after removing only new pooling namespace/classes/category/functions/import; all existing registrations and numerical kernels unchanged.',source_hashes=candidate)
(r/'existing-source-audit.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified45 unchanged resources; existing API AST unchanged outside new pooling registrations')
