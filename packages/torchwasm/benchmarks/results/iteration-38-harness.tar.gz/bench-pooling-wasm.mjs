import fs from 'node:fs';
import path from 'node:path';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const repo='/Users/david/Developer/PaperLeet-torch-release';
const py=await loadPyodide({indexURL:path.join(repo,'web/node_modules/pyodide/'),packageCacheDir:path.join(repo,'web/public/browser-runtime/pyodide-0.29.4/'),stdout(){},stderr:console.error});
await loadJudgePackages(py,[]);py.FS.mkdirTree('/runtime/stridetorch');
const source=process.env.BENCH_LIBRARY_SOURCE||path.join(repo,'packages/stridetorch/src/stridetorch');
for(const name of fs.readdirSync(source).filter(n=>n.endsWith('.py')||['LICENSE','NOTICE'].includes(n)))py.FS.writeFile('/runtime/stridetorch/'+name,fs.readFileSync(path.join(source,name)));
py.FS.writeFile('/runtime/bench-pooling.py',fs.readFileSync(new URL('bench-pooling.py',import.meta.url)));
py.globals.set('requested_dtype',process.env.BENCH_DTYPE||'float32');
const result=py.runPython(`
import sys,os,json,runpy
sys.path.insert(0,'/runtime');os.environ['BENCH_DTYPE']=requested_dtype
values=runpy.run_path('/runtime/bench-pooling.py',run_name='__main__')
report=values['BENCH_REPORT'];report['runtime']=dict(python=sys.version,numpy=__import__('numpy').__version__,platform=sys.platform)
json.dumps(report)
`);
console.log(result);
