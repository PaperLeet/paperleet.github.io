"""Native oracle inventory for the next core-coverage iteration; no SDK changes."""
from pathlib import Path
import json,torch
from torch.nn import functional as F
rows=[]
def run(name,x,**options):
 row=dict(name=name,shape=list(x.shape),dtype=str(x.dtype),options=options)
 try:
  y,index=F.max_pool2d(x,return_indices=True,**options)
  row.update(output=y.tolist(),indices=index.tolist(),output_shape=list(y.shape),indices_dtype=str(index.dtype))
  if x.requires_grad:
   y.sum().backward();row['gradient']=x.grad.tolist()
   tangent=torch.arange(x.numel(),dtype=x.dtype).reshape(x.shape)/10
   _,jvp=torch.func.jvp(lambda z:F.max_pool2d(z,**options),(x.detach(),),(tangent,));row['jvp']=jvp.tolist()
 except Exception as error:row.update(error=type(error).__name__,message=str(error))
 rows.append(row)
for dtype in (torch.float32,torch.float64,torch.float16,torch.bfloat16,torch.int64,torch.int32,torch.uint8,torch.bool):
 x=torch.arange(16).reshape(1,1,4,4).to(dtype);x.requires_grad_(dtype in (torch.float32,torch.float64));run('dtype',x,kernel_size=2)
for values in ([2.,2.,2.,2.],[float('nan'),1.,float('nan'),0.],[-float('inf')]*4,[-0.,0.,0.,-0.]):
 x=torch.tensor(values,dtype=torch.float64).reshape(1,1,2,2).requires_grad_();run('ties_nan_negative_inf',x,kernel_size=2,stride=1,padding=1)
for shape in ((2,3,5,7),(3,5,7),(0,3,5,7),(2,0,5,7),(2,3,0,7)):
 x=torch.arange(torch.Size(shape).numel(),dtype=torch.float64).reshape(shape).requires_grad_();run('geometry',x,kernel_size=(2,3),stride=(2,2),padding=(1,1),ceil_mode=True)
for options in (dict(kernel_size=3,dilation=2,padding=1,ceil_mode=True),dict(kernel_size=2,dilation=2,padding=2),dict(kernel_size=2,stride=0),dict(kernel_size=0),dict(kernel_size=(2,)),dict(kernel_size=2,ceil_mode=1)):
 run('validation',torch.ones((1,1,5,7),requires_grad=True),**options)
x=torch.arange(90,dtype=torch.float64).reshape(2,3,3,5).transpose(-1,-2).detach().requires_grad_();run('noncontiguous',x,kernel_size=2,stride=1)
result=dict(scope='Native CPU oracle inventory for max_pool2d; input/shape/tie/NaN/index/VJP/JVP validation. Not an implemented compatibility claim or performance benchmark.',torch_version=torch.__version__,cases=rows)
path=Path(__file__).with_name('native-pooling-probe.json');path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(torch=torch.__version__,cases=len(rows),successes=sum('error' not in row for row in rows),dtype_support={row['dtype']:row.get('error','supported') for row in rows if row['name']=='dtype'})))
