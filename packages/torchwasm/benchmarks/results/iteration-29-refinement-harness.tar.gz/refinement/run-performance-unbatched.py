from pathlib import Path
import os,sys,json,subprocess,time,statistics
r=Path(__file__).parent.parent;out=r/'performance-unbatched';out.mkdir(exist_ok=True);receipts=[]
env={**os.environ,'OMP_NUM_THREADS':'2','MKL_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2'}
for runtime in ('cpu','wasm'):
 for dtype in ('float32','float64'):
  for i,variant in enumerate(('baseline','candidate','candidate','baseline')):
   source=r/('baseline' if variant=='baseline' else 'refinement/trial-unbatched')/'stridetorch';command=[sys.executable,str(r/'bench.py')] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(r/'bench-wasm.mjs')];command += [str(source),dtype];name=f'{runtime}-{dtype}-{i}-{variant}';start=time.monotonic()
   with (out/(name+'.json')).open('w') as log,(out/(name+'.stderr.log')).open('w') as err:p=subprocess.run(command,env=env,stdout=log,stderr=err)
   receipts.append(dict(name=name,exit_code=p.returncode,elapsed_s=time.monotonic()-start,command=command));(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode();print(name,'terminal0',flush=True)
summary={}
for runtime in ('cpu','wasm'):
 for dtype in ('float32','float64'):
  reports={v:[json.loads(p.read_text()) for p in out.glob(f'{runtime}-{dtype}-*-{v}.json')] for v in ('baseline','candidate')};assert all(len(v)==2 for v in reports.values());cases={}
  for case in reports['baseline'][0]['records']:
   times={v:statistics.median(x['records'][case]['median_us'] for x in reports[v]) for v in reports};cases[case]=dict(**times,reduction_percent=(1-times['candidate']/times['baseline'])*100)
  summary[runtime+'/'+dtype]=cases
(r/'performance-unbatched-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
