from pathlib import Path
import json,os,statistics,subprocess,sys,time
r=Path(__file__).parent;root=r.parent;out=r/'performance-paired';out.mkdir(exist_ok=True);receipts=[];env={**os.environ,'OMP_NUM_THREADS':'2','MKL_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2'};sources=dict(baseline=str(root/'baseline/stridetorch'),candidate=str(r/'trial-unbatched/stridetorch'))
for runtime in ('cpu','wasm'):
 for dtype in ('float32','float64'):
  for repeat in range(2):
   name=f'{runtime}-{dtype}-{repeat}';command=[sys.executable,str(r/'bench-paired.py')] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(r/'bench-paired-wasm.mjs'),sources['baseline'],sources['candidate'],dtype];start=time.monotonic()
   with (out/(name+'.json')).open('w') as log,(out/(name+'.stderr.log')).open('w') as err:p=subprocess.run(command,env={**env,'BENCH_SOURCES':json.dumps(sources),'BENCH_DTYPE':dtype},stdout=log,stderr=err)
   receipts.append(dict(name=name,command=command,exit_code=p.returncode,elapsed_s=time.monotonic()-start));(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode();print(name,'terminal0',flush=True)
summary={}
for runtime in ('cpu','wasm'):
 for dtype in ('float32','float64'):
  reports=[json.loads((out/f'{runtime}-{dtype}-{i}.json').read_text()) for i in range(2)];summary[runtime+'/'+dtype]={case:dict(median_reduction_percent=statistics.median(x['results'][case]['median_paired_time_reduction_percent'] for x in reports),process_reductions=[x['results'][case]['median_paired_time_reduction_percent'] for x in reports]) for case in reports[0]['results']}
(r/'paired-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
