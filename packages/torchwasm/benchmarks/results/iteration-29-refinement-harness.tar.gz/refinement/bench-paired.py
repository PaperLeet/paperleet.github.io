"""Paired blocks for solve, complete updates and generic graph-construction controls."""
import contextlib,gc,hashlib,importlib.util,json,os,statistics,sys,time
from pathlib import Path
import numpy as np
bench_dtype=globals().get('bench_dtype',os.environ.get('BENCH_DTYPE','float64'))
paths=globals().get('bench_sources') or json.loads(os.environ['BENCH_SOURCES']);packages={};hashes={}
for label,path in paths.items():
 root=Path(path);name='paired_'+label;spec=importlib.util.spec_from_file_location(name,root/'__init__.py',submodule_search_locations=[str(root)]);p=importlib.util.module_from_spec(spec);sys.modules[name]=p;spec.loader.exec_module(p);packages[label]=p
 hashes[label]={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in root.iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')}
assert packages['baseline'].__version__=='0.28.0' and packages['candidate'].__version__=='0.29.0'
rows={};configs=[('solve-matrix',2,'both'),('solve-matrix',2,'b'),('solve-matrix',16,'both'),('solve-vector',2,'both'),('solve-vector',16,'both'),('solve-matrix',2,'off'),('solve-vector',2,'off'),('sgd-update',2,'both'),('sgd-update',16,'both'),('layernorm',0,'both'),('attention',0,'both'),('unary-chain',0,'both'),('exp-control',0,'off')]
for operation,n,mode in configs:
 name=f'{operation}/{n}/{mode}';callbacks={};validations={};outputs={}
 for label,package in packages.items():
  lib=package.torch;dtype=getattr(lib,bench_dtype);inputs=[];f=lib.nn.functional
  def tensor(x,grad=True):return lib.tensor(np.asarray(x,dtype=bench_dtype),dtype=dtype,requires_grad=grad)
  if operation.startswith('solve') or operation=='sgd-update':
   raw=np.eye(n)*3+np.arange(n*n).reshape(n,n)/(n*n*20);rhs=np.linspace(.3,1.2,n if operation=='solve-vector' else n*2);rhs=rhs if operation=='solve-vector' else rhs.reshape(n,2)
   a=tensor(raw,mode=='both');b=tensor(rhs,mode!='off');inputs=[a,b];forward=lambda a=a,b=b,lib=lib:lib.linalg.solve(a,b)
   expected=np.linalg.solve(raw.astype(bench_dtype),rhs.astype(bench_dtype))
  elif operation=='layernorm':
   raw=np.arange(32).reshape(4,8)/29-.3;x=tensor(raw);weight=tensor(np.linspace(.8,1.2,8));bias=tensor(np.linspace(-.1,.2,8));inputs=[x,weight,bias];forward=lambda x=x,w=weight,b=bias,f=f:f.layer_norm(x,(8,),w,b)
   expected=(raw-raw.mean(-1,keepdims=True))/np.sqrt(raw.var(-1,keepdims=True)+1e-5)*weight.numpy()+bias.numpy()
  elif operation=='attention':
   rng=np.random.default_rng(29);q=tensor(rng.normal(size=(2,4,8))*.2);k=tensor(rng.normal(size=(2,4,8))*.2);v=tensor(rng.normal(size=(2,4,8))*.2);inputs=[q,k,v];forward=lambda q=q,k=k,v=v,f=f:f.scaled_dot_product_attention(q,k,v)
   logits=q.numpy()@k.numpy().swapaxes(-1,-2)/np.sqrt(8);logits-=logits.max(-1,keepdims=True);prob=np.exp(logits);expected=(prob/prob.sum(-1,keepdims=True))@v.numpy()
  else:
   raw=np.linspace(-.7,.9,32).reshape(4,8);x=tensor(raw,mode!='off');inputs=[x];forward=(lambda x=x:x.sin().exp().tanh()) if operation=='unary-chain' else (lambda x=x:x.exp());expected=np.tanh(np.exp(np.sin(raw))) if operation=='unary-chain' else np.exp(raw)
  initial=forward();np.testing.assert_allclose(initial.numpy(),expected,rtol=3e-5,atol=2e-6);assert str(initial.dtype)==bench_dtype
  optimizer=lib.optim.SGD(inputs,lr=.0001) if operation=='sgd-update' else None
  if mode=='off':call=forward
  else:
   def call(inputs=inputs,forward=forward,optimizer=optimizer):
    for value in inputs:value.grad=None
    loss=forward().square().mean();loss.backward()
    if optimizer is not None:optimizer.step()
  callbacks[label]=call
  validations[label]=lambda inputs=inputs,forward=forward:([value.numpy().copy() for value in inputs],forward().detach().numpy().copy(),[str(value.dtype) for value in inputs])
 with contextlib.ExitStack() as stack:
  if mode=='off':
   for p in packages.values():stack.enter_context(p.torch.no_grad())
  for call in callbacks.values():
   for _ in range(1000):call()
  gc.collect();before_gc=gc.get_stats();blocks=[];loops=1500 if mode=='off' else 200
  for i in range(13):
   order=('baseline','candidate','candidate','baseline') if i%2==0 else ('candidate','baseline','baseline','candidate');samples={'baseline':[],'candidate':[]}
   for label in order:
    call=callbacks[label];start=time.perf_counter()
    for _ in range(loops):call()
    samples[label].append((time.perf_counter()-start)*1e6/loops)
   blocks.append(dict(samples_us=samples,time_reduction_percent=100*(1-statistics.mean(samples['candidate'])/statistics.mean(samples['baseline']))))
  states={label:validate() for label,validate in validations.items()}
  for arrays in zip(states['baseline'][0],states['candidate'][0]):np.testing.assert_allclose(*arrays,rtol=3e-5,atol=2e-6)
  np.testing.assert_allclose(states['baseline'][1],states['candidate'][1],rtol=3e-5,atol=2e-6)
  assert all(dtype==bench_dtype for s in states.values() for dtype in s[2])
 rows[name]=dict(median_paired_time_reduction_percent=statistics.median(b['time_reduction_percent'] for b in blocks),blocks=blocks,loops_per_sample=loops,final_values={k:dict(inputs=[x.tolist() for x in s[0]],output=s[1].tolist(),input_dtypes=s[2]) for k,s in states.items()},gc_before=before_gc,gc_after=gc.get_stats())
result=dict(dtype=bench_dtype,python=sys.version,numpy=np.__version__,source_hashes=hashes,results=rows,scope='Isolated package namespaces share one NumPy interpreter.13 ABBA/BAAB paired blocks;1000warmups;GC enabled.200calls per full-flow sample,1500per no-grad sample. Additional evidence;original fresh-process regressions and anomalies retained. SGD case includes real updates;other flows do not. Shared host and unverified BLAS thread count.')
if 'bench_sources' not in globals():print(json.dumps(result))
