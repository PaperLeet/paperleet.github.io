from pathlib import Path
import json,shutil,hashlib
r=Path(__file__).parent.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');proof=r/'proof-refined';proof.mkdir(exist_ok=True);old=r.parent/'torch-iteration-28/proof-final';source=repo/'packages/stridetorch/src/stridetorch'
for dest in (proof/'source',proof/'chrome-contracts/source'):shutil.copytree(source,dest,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
tests={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'};assert len(tests)==29
shutil.copytree(repo/'packages/stridetorch/tests',proof/'chrome-contracts/tests',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};(proof/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
plan=dict(version='0.29.0',expected=904,source=hashes,tests=tests);(proof/'chrome-contracts/plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for name in ('run.mjs','worker.mjs','index.html'):
 s=(old/'chrome-contracts'/name).read_text().replace('torch-iteration-28/proof-final','torch-iteration-29/proof-refined');(proof/'chrome-contracts'/name).write_text(s)
s=(old/'wasm-contracts.mjs').read_text().replace('torch-iteration-28/proof-final','torch-iteration-29/proof-refined').replace("'axis_transforms']","'axis_transforms','solve']").replace('0.28.0','0.29.0').replace('==881','==904');(proof/'wasm-contracts.mjs').write_text(s)
s=(old/'check-wheel.py').read_text().replace('0.28','0.29').replace('stride028','stride029');(proof/'check-wheel.py').write_text(s)
print('frozen45 source/license hashes and29 standalone suites')
