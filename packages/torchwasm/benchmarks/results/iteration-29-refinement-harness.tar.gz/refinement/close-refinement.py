from pathlib import Path
import hashlib,json,re,subprocess,tarfile
r=Path(__file__).parent;root=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');proof=root/'proof-refined';out=repo/'packages/stridetorch/benchmarks/results'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def hashes(folder):return {p.name:sha(p) for p in folder.iterdir() if p.is_file() and (p.suffix=='.py' or p.name in ('LICENSE','NOTICE'))}
source=hashes(repo/'packages/stridetorch/src/stridetorch');assert len(source)==45 and source==hashes(r/'trial-vector/stridetorch')==hashes(proof/'source')==hashes(proof/'chrome-contracts/source')
node=read(proof/'source-wasm.json');chrome=read(proof/'chrome-contracts/result.json');wheel=read(proof/'wheel-stride029-result.json');coinstall=read(proof/'coinstall-result.json');plan=read(proof/'chrome-contracts/plan.json');private=read(proof/'private-artifact-identity.json')
for item in (node,chrome,wheel,coinstall):assert item['source_hashes']==source
assert node['passed']==chrome['passed']==904 and node['library']==chrome['library']=='0.29.0'
assert chrome['status']==wheel['status']==coinstall['status']==private['status']=='success' and not wheel['native_torch']
assert '916 passed' in (proof/'python310-stride029-tests.log').read_text()
base=re.search(r'29853 passed, 1 skipped, (\d+) warnings in ([\d.]+)s',(r/'full-native.log').read_text());assert base
assert '2084 passed' in (r/'focused-vector.log').read_text()
assert chrome['test_hashes']==plan['tests']=={p.name:sha(p) for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'} and len(plan['tests'])==29
phases={};all_receipts=[]
for phase in ('metadata','joint','result','unbatched','vector'):
 folder=root/('performance-'+phase);receipts=read(folder/'receipts.json');assert len(receipts)==16 and all(x['exit_code']==0 for x in receipts)
 trial=hashes(r/('trial-'+phase)/'stridetorch')
 for receipt in receipts:
  data=read(folder/(receipt['name']+'.json'));assert data['source_hashes']==(hashes(root/'baseline/stridetorch') if receipt['name'].endswith('-baseline') else trial)
  assert len(data['records'])==14 and all(len(case['batches_us'])==9 for case in data['records'].values())
 phases[phase]=dict(summary=read(root/('performance-'+phase+'-summary.json')),source_hashes=trial,receipts=receipts);all_receipts+=receipts
paired={}
for folder,summary,trial in [('performance-paired','paired-summary.json','trial-unbatched'),('performance-paired-vector','paired-vector-summary.json','trial-vector')]:
 receipts=read(r/folder/'receipts.json');assert len(receipts)==8 and all(x['exit_code']==0 for x in receipts)
 for receipt in receipts:
  data=read(r/folder/(receipt['name']+'.json'));assert data['source_hashes']['candidate']==hashes(r/trial/'stridetorch') and data['source_hashes']['baseline']==hashes(root/'baseline/stridetorch');assert len(data['results'])==13
  assert all(len(case['blocks'])==13 for case in data['results'].values())
 paired[folder]=dict(summary=read(r/summary),receipts=receipts);all_receipts+=receipts
report=dict(status='refined_local_core_gates_passed_application_integration_pending',version='0.29.0',baseline_commit='0fb0bdc57732aadb8233d3ec9d246570ce088c58',initial_candidate_commit='fd8f3ee839ed96f8f368115066195eb861436320',source_hashes=source,adopted_source='refinement/trial-vector/stridetorch',adopted_proof='proof-refined',base=dict(passed=29853,optional_skips=1,warnings=int(base[1]),elapsed_s=float(base[2])),focused_passed=2084,minimum=dict(passed=916,python=wheel['python'],numpy=wheel['numpy'],native_torch=wheel['native_torch'],artifacts=wheel['artifacts']),node=node,chrome=chrome,coinstall=coinstall,private_artifacts=private,performance=phases,paired=paired,timing_children=len(all_receipts),prior_evidence='iteration-29.json and immutable original iteration-29-harness.tar.gz retain earlier48 timingchildren,original candidate proof and failures',scope='Same batched/right solve and real AD contracts. ndarray metadata and native result-layout specialization;single/shared graph construction;no new value/seed/gradient caches. Some tiny pure solve flows still slower.',timing_scope='Fresh original recipe retained with outliers. Same-interpreter paired ABBA/BAAB uses two isolated namespaces sharing NumPy,GC enabled,1000warmups,13blocks;200full-flow/1500no-grad calls per sample. Real SGD updates and final value/dtype checks included. Shared host;actual BLAS thread count unverified. No universal speedup or causal explanation of fresh-process anomalies.',processes=dict(complete_base=dict(session=3220,exit_code=0),focused=dict(session=9710,exit_code=0),node=dict(session=79332,exit_code=0),chrome=dict(session=14746,exit_code=0),minimum=dict(session=64322,exit_code=0),coinstall=dict(session=55841,exit_code=0),final_public_build=dict(chunk='f9b08b',exit_code=0),private_build=dict(chunk='58eab9',exit_code=0),private_identity=dict(chunk='b1d591',exit_code=0),metadata_timing=dict(session=7751,exit_code=0),joint_timing=dict(session=61735,exit_code=0),result_timing=dict(session=56504,exit_code=0),unbatched_timing=dict(session=50280,exit_code=0),vector_timing=dict(session=48537,exit_code=0),paired_unbatched=dict(session=84097,exit_code=0),paired_vector=dict(session=56434,exit_code=0)),remaining=['Original native catalog and exported-source/full actual WASM gates','Latest-main revalidation and full frontend/default/actual Pages-profile builds','Current application distribution identity after any upstream changes','Non-force stable main adoption only after all integration gates pass','Actual exact-main remote Quality,eligible Pages and frozen live verification'])
(r/'local-gates.json').write_text(json.dumps(report,indent=2)+'\n');(r/'implementation.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=repo))
files={}
def add(p,name=None):
 if p.is_file():files[name or str(p.relative_to(root))]=p
for folder in [root/'baseline/stridetorch',*(r/('trial-'+phase)/'stridetorch' for phase in phases),*(root/('performance-'+phase) for phase in phases),r/'performance-paired',r/'performance-paired-vector',proof/'source',proof/'chrome-contracts',proof/'dist-preflight',proof/'private-dist',proof/'python310-stride029-tests']:
 for p in folder.rglob('*'):
  if '__pycache__' not in p.parts and '.pytest_cache' not in p.parts:add(p)
for folder in (r,proof):
 for p in folder.iterdir():
  if p.suffix in ('.py','.mjs','.json','.log','.patch'):add(p)
for name in ('tests/test_torch_solve.py','packages/stridetorch/tests/test_solve.py','packages/stridetorch/README.md','packages/stridetorch/pyproject.toml','docs/validation/torch-runtime-iteration-29.md'):add(repo/name,'maintained/'+name)
archive=out/'iteration-29-refinement-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
report['archive']=dict(file=archive.name,files=len(files),bytes=archive.stat().st_size,sha256=sha(archive));(out/'iteration-29-refinement.json').write_text(json.dumps(report,indent=2)+'\n')
state=read(root/'state.json');state.setdefault('initial_candidate_source_hashes',state['source_hashes']);state.update(phase=report['status'],source_hashes=source,adopted_source=report['adopted_source'],final_proof=report['adopted_proof'],refinement_report=str(out/'iteration-29-refinement.json'),refinement_archive=report['archive'],refinement_processes=report['processes'],next=report['remaining'],turn_classification='progress:solve/vector metadata and graph-constructor refinement validated;96additional timingchildren;fullbase/minimum/realNodeChrome/public-private proof refreshed;app integration still pending');(root/'state.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(dict(status=report['status'],base=report['base'],archive=report['archive']),indent=2))
