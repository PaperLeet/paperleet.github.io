# StrideTorch0.29 candidate: batched linear systems

This candidate expands the former unbatched-only `torch.linalg.solve` to dense
batched and broadcast systems, vector/matrix right-hand sides and `left=False`.
It is not yet adopted on main. Initial performance regressions prompted the
metadata/graph refinements documented below; complete application gates remain
separate. The verified stable runtime on main/site remains0.28.

## Compatibility and differentiation

The public signature uses native `A/B`, keyword-only `left/out`, strict Tensor
inputs and boolean `left`. Float32/64 differentiation and complex64/128 inference
are supported. Native vector classification is matched: a one-dimensional B, or
an exact A.shape[:-1] shape, is a vector; rank alone is insufficient. Right solves
reject vector B as native does. Broadcast inputs are views, and explicit matrix
promotion works under both NumPy1.26 and2.x. Singular matrices raise RuntimeError,
including empty right-hand-side matrices. Output strides follow native CPU
geometry, including scalar-sized axes, batched vectors and empty outputs.

The real VJP solves one adjoint system per traversal, sharing it when A and B
both need gradients. Broadcast dimensions reduce into original input shapes;
repeated seeds are recomputed rather than cached. Frozen-input cases use one
ordinary graph edge. Native saved-value guards include A and the output, while
B may change after forward. Detached aliases trigger the same storage guards.
Intermediate arrays release after nonretained backward. Existing module dtype
rebinding continues to use original saved arrays as before this change.

JVP implements dX=solve(A,dB-dA@X), or its right-sided form. Its reverse behavior
matches native's constant saved-factor rule: the outer coefficient is detached,
while X and residual retain reverse edges. A materialized zero coefficient
direction preserves native zero-versus-None gradients when only B is dual.
NumPy still refactorizes each solve; no reusable LU factorization is claimed.
Complex AD, half-precision factorization, sparse systems and out buffers retain
explicit unsupported boundaries. Lazy conjugate metadata is not implemented;
complex values are compared against native resolve_conj() results.

Native-reference tests cover values/strides, three input layouts, both sides,
broadcast reductions, all gradient-input combinations, dynamic retained seeds,
JVP/reverse-of-tangent and saved-value mutation policy. Independent tests use
closed-form2x2 inverses and residual identities, analytical derivatives and five
SGD steps with checkpoint restoration, rather than another adapter implementation.

## Measurements and candidate status

Three fresh-process ABBA phases preserve48 child receipts: CPython/Pyodide,
float32/64,2x2 and16x16 matrices, both or one input gradient, retained backward,
complete forward/square/mean/backward and no-grad forward. Each case uses100
warmups and nine batches; small cases use500 calls, larger derivative cases100.
Timing excludes import, which is recorded separately. CPU thread counts are
requested through environment variables; actual BLAS threading is not verified.
The host is shared, and results are not a general throughput claim.

The first broad implementation regresses complete small-system paths by roughly
20–50%, while no-grad forward more than doubles. Removing unnecessary broadcast
views, caching adjoint/transposed-output metadata and selecting ordinary graph
edges for frozen inputs reduces this cost. The final selective trial generally
saves about9–18% in double-input retained backward on WASM; one CPUfloat32 small
sample is0.9% slower and CPUfloat64 large samples show larger savings. Complete
forward/backward is still mostly slower, with final observed regressions up to
23.5%; no-grad forward is up to35.6% slower. These results are retained, not hidden
by the reduced number of mathematical solves. Those results motivated the subsequent refinement below and do not describe
the adopted refined source.

Initial native failures exposed vector result layout and the native JVP saved
factor/zero-edge rules, plus two test-fixture errors: complex lazy-conjugate NumPy
conversion and direct mutation of unsupported nonleaf tensors. Later a capability
attribute typo was corrected. All original failing logs and prototype sources
remain in the evidence archive; corrected tests use resolve_conj and detached
writes without expanding general in-place AD.

Core CPython, minimum wheel and real Node/Chrome proofs are recorded in the
[machine-readable candidate evidence](../../packages/stridetorch/benchmarks/results/iteration-29.json).
Full exported-catalog/frontend/application distribution checks and main adoption
are separate later gates, not implied by independent-package compatibility.


## Original candidate core gates

The original selective source passes29853 root/independent tests with one optional
Docker skip in194.91s. Focused solve/model-conversion/joint-pullback tests pass574.
The actual public wheel installs without native Torch in Python3.10.19 /
NumPy1.26.4 and passes916 tests. Pinned Pyodide0.29.4 / NumPy2.2.5 under Node and
real headless Chrome155 Worker each pass904 tests in29 suites. All45 core/license
hashes match the timed selective source, both WASM executions and installed wheel.
These gates establish local core compatibility. They do not waive the measured
complete-flow performance concern or substitute for application adoption gates.


## Metadata and graph refinement

The refined implementation validates array metadata directly, uses ndarray axis
methods, specializes ordinary result layouts and avoids column promotion for an
unbatched vector. Ordinary unbatched left-solve pullbacks avoid constructing
broadcast/reduction callbacks. All batched/right-side and native layout/guard
contracts remain. The general result constructor builds a single active edge
without temporary lists/generators; the joint constructor builds its shared
node once. No numeric values, gradients or seeds are added to a cache.

Five additional fresh-process ABBA phases preserve80 child receipts for metadata,
joint-node, single-edge, unbatched and vector trials. They use the original
14-case matrix-RHS recipe and retain every anomaly. The final fresh phase includes
large outliers, including26% slower CPUfloat64 small full-flow and25% slower
WASMfloat32 large single-input full-flow samples, alongside implausibly broad
float64 WASM wins up to64%. These are not used to infer a general speedup or a
particular cause of timing variance.

Two additional paired phases preserve16 fresh processes. Each loads two isolated
package namespaces in the same NumPy interpreter, alternates13 ABBA/BAAB blocks,
warms1000 calls and leaves GC enabled. The final phase uses200 calls per full-flow
sample and1500 per no-grad sample, includes vectors and real SGD updates, and
checks final input/output values and dtypes across implementations. It supplements
rather than replaces the original fresh-process evidence.

Final paired process medians show no-grad small-vector solve about7–11% faster,
LayerNorm about1.5–4.1%, attention2–3%, unary chains3.8–6.1% and no-grad exp27–29%.
Actual SGD update flows range from1.5% slower to11.9% faster, depending on runtime,
dtype and matrix size. Some tiny solve-only flows remain2–5.3% slower; no claim
that every operation or training run accelerates is made. Both numerical runtimes
and float32/64 are measured; actual BLAS threading remains unverified.

The candidate's broad library value is native batch/right/JVP coverage plus reduced
shared graph overhead. App adoption still requires complete final-source package,
exported-WASM, catalog and frontend gates; the coarse fresh-process outliers and
small paired regressions are retained for later performance work.


The refined final source separately passes29853 tests/one optional Docker skip
in185.67s, plus the2084 focused contracts. Its actual wheel/sdist match current
README metadata and45 core/license hashes. The NumPy-only Python3.10.19 /
NumPy1.26.4 installation passes916 tests; Node and real Chrome155 Worker each
pass904 in29 unchanged standalone suites. Both public and private wheels execute
batched right solve/VJP/JVP, matrix views, gradient retention and NaN workflows;
each remains usable after uninstalling the other. The private wheel/sdist also
match current application server/catalog bytes. Original proof folders remain
separate; the adopted refined proof is `proof-refined`, source `trial-vector`.

[Refinement evidence](../../packages/stridetorch/benchmarks/results/iteration-29-refinement.json)
and its receipt archive preserve all96 additional timing children, five source
trials, both paired recipes, original anomalies and exact final-source proofs.
The broader main-branch adoption gates are still pending at this core milestone.
