import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
const r=path.dirname(fileURLToPath(import.meta.url)),b=path.dirname(r);
const hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const plan=JSON.parse(fs.readFileSync(r+'/execution-plan.json','utf8'));
assert.equal(hash(r+'/benchmark.py'),plan.runner_sha256);
assert.equal(hash(import.meta.filename),JSON.parse(fs.readFileSync(r+'/driver-plan.json','utf8')).runner_sha256);
assert.equal(JSON.parse(fs.readFileSync(b+'/torch-iteration-386/result.json','utf8')).status,'passed_full_node_wasm_sdk');
const py=await loadPyodide({indexURL:b+'/torch-iteration-76/runtime',stdout:console.log,stderr:console.error});
await py.loadPackage('numpy');py.runPython('import sys;sys.dont_write_bytecode=True');
const put=(name,data)=>{py.FS.mkdirTree(path.dirname(name));py.FS.writeFile(name,data);};
for(const [name,digest] of Object.entries(plan.inputs)){
 const local=b+name;assert.equal(hash(local),digest,name);put(name,fs.readFileSync(local));
}
for(const name of ['benchmark.py','execution-plan.json'])put('/torch-iteration-391/'+name,fs.readFileSync(r+'/'+name));
put('/torch-iteration-380/source-plan.json',fs.readFileSync(b+'/torch-iteration-380/source-plan.json'));
fs.writeFileSync(r+'/progress.json',JSON.stringify({status:'running',pid:process.pid})+'\n');
try{
 py.runPython("__file__='/torch-iteration-391/benchmark.py';exec(compile(open('/torch-iteration-391/benchmark.py').read(),'/torch-iteration-391/benchmark.py','exec'))");
 for(const name of ['result.json','performance.json','progress.json'])fs.writeFileSync(r+'/'+name,py.FS.readFile('/torch-iteration-391/'+name));
 for(const [name,digest] of Object.entries(plan.inputs))assert.equal(hash(b+name),digest,name);
 const result=JSON.parse(fs.readFileSync(r+'/result.json','utf8'));result.pyodide=py.version;result.node=process.version;result.driver_sha256=hash(import.meta.filename);result.execution_plan_sha256=hash(r+'/execution-plan.json');fs.writeFileSync(r+'/result.json',JSON.stringify(result,null,2)+'\n');
}catch(error){fs.writeFileSync(r+'/failure.json',JSON.stringify({error:String(error.stack||error)},null,2)+'\n');throw error;}
