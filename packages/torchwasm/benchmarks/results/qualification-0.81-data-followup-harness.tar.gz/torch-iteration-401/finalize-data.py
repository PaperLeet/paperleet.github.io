from pathlib import Path
import hashlib,io,json,subprocess,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
application=read(b/'torch-iteration-398/result.json');assert application['status']=='passed_local_application_catalog_export_frontend_worker_gates'
assert application['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
for name,h in read(b/'torch-iteration-398/static-inputs.json').items():assert sha(repo/name)==h,name
for receipt in read(b/'torch-iteration-398/receipts.json'):
 assert receipt['exit_code']==0
 assert sha(b/'torch-iteration-398'/(receipt['label']+'.log'))==receipt['log_sha256']
for n in [394,395]:assert read(b/f'torch-iteration-{n}'/'hvp-comparison.json')['status']=='passed'
assert read(b/'torch-iteration-388/adoption-push-receipt.json')['exit_code']!=0
assert (b/'torch-iteration-400/negotiation-probe.log').read_text().strip()=='de22a49f54167f1f0eb8f01601769f2f5657571b'
files=[]
for n in [388,390,391,392,394,395,396,397,398,400,401]:
 for p in (b/f'torch-iteration-{n}').rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and p.name not in ['archive-receipt.json','harness.tar.gz']:files.append(p)
manifest={str(p.relative_to(b)):sha(p) for p in sorted(files)};destination=out/'qualification-0.81-data-followup-harness.tar.gz';assert not destination.exists()
seen={}
with tarfile.open(destination,'w:gz') as stream:
 for p in sorted(files):
  name=str(p.relative_to(b));digest=manifest[name]
  if digest in seen:
   info=stream.gettarinfo(str(p),arcname=name);info.type=tarfile.LNKTYPE;info.linkname=seen[digest];info.size=0;stream.addfile(info)
  else:stream.add(p,arcname=name,recursive=False);seen[digest]=name
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256.json');info.size=len(data);stream.addfile(info,io.BytesIO(data))
with tarfile.open(destination) as stream:
 for name,h in manifest.items():assert hashlib.sha256(stream.extractfile(name).read()).hexdigest()==h,name
receipt=dict(path=str(destination.relative_to(repo)),files=len(files),unique_payloads=len(seen),bytes=destination.stat().st_size,sha256=sha(destination),verified_all_payloads=True);write(r/'archive-receipt.json',receipt)
result=dict(status='passed_append_only_current_main_data_followup',version='0.81.0',qualified_head=application['head'],incoming_main='9104986dfd91734d7a7097e86685a6b2727f842f',data_proof=read(b/'torch-iteration-396/data-proof.json'),full_frontend_baseline=dict(stage=385,commands=204),fresh_data_commands=2,both_current_builds_passed=True,current_actual_chrome_worker_passed=True,application_result_sha256=sha(b/'torch-iteration-398/result.json'),archive=receipt,previous_push=dict(stage=388,seconds=590.4811112500029,terminal='ordinaryrefCASrejectionafterremoteadvanced;nooverwrite',server_acknowledged_existing_commit='de22a49f54167f1f0eb8f01601769f2f5657571b'),retained_early_launch_failure=397,main_adopted=False,ci_triggered=False,published=False,deployed=False,goal_status='active');write(out/'qualification-0.81-data-followup.json',result)
doc=repo/'docs/validation/torch-runtime-0.81-qualification.md';doc.write_text(doc.read_text()+f'\n## Append-only study-data follow-up\n\nMain subsequently advanced to `9104986dfd91734d7a7097e86685a6b2727f842f`.\nOnly the guide JSON, its existing check and its documentation change. All 89\nmodule identities, 267 core prompts, previous 50 follow-ups and root metadata\nare preserved; seven guides gain two follow-ups each (64 total). Experiment\n396 records that parsed-object proof. No production UI, backend, problem, judge\nor Worker code changes.\n\nAt `{application["head"]}`, experiment 398 passes both current\ndata checks, both complete build profiles, Pages assets/retention/generated\nWorker checks and the actual Chrome Worker. The full 204-command source-code\nqualification remains experiment 385; this is not a claim of a fresh full 204\non the data-only delta. Canonical 0.81 resources, installed metadata and export\nidentities remain unchanged. An early launch (397) started before preparation\nfinished and failed before any gate; its original error is retained. Fresh\n398 waits for the prepared frozen plan and passes all gates unchanged.\n\nThe 388 upload reached a terminal ordinary ref-lock rejection after 590 seconds\nbecause main had advanced; no new content was overwritten. A subsequent\nread-only Git negotiation acknowledges the already received `de22a49f` commit.\nFuture attempts can use standard `push.negotiate=true` through the same native\nwrapper and release guards, reusing objects without a force push.\n[Data-follow-up evidence](../../packages/stridetorch/benchmarks/results/qualification-0.81-data-followup.json)\nand [raw archive](../../{receipt["path"]}): {receipt["files"]} verified files\n({receipt["unique_payloads"]} unique payloads, tar hard links for identical bytes),\n{receipt["bytes"]:,} bytes, SHA-256 `{receipt["sha256"]}`.\n')
pilot=repo/'docs/validation/torch-runtime-hvp-terminal-values-pilot.md';pilot.write_text(pilot.read_text()+'\n## Further isolated evidence\n\nExperiment 391 repeats the same 14-flow pilot in one actual Node/Pyodide process.\nAll baseline/candidate outputs match exactly before timing. Norm B/A0 medians\nare 0.864–0.896 (about 10–14% lower); non-norm controls are 1.002–1.004. All\n14 A/A medians remain within 5%. This is still one-process exploratory evidence,\nnot repeated WASM or Chrome performance qualification. Original attempt 390\nfailed before measurements because execution globals lacked `__file__`; 391\nfixes that bridge field without changing workloads, candidates or thresholds.\n\nExperiments 394/395 run the unchanged 4,480-case norm-HVP boundary corpus on\nNumPy 2.5.4 and 1.26.4. Each matches all 4,480 cases against both preserved\nindependent Torch 2.6 and 2.14 observations, including the 320 older composition\ncontrols. All 4,480 select the Tensor three-reverse path; no missing rule or\ncontext leak is observed. These are comparisons with frozen native references,\nnot fresh native runs. The expanded raw corpus has not yet been rerun on the\nnew candidate in WASM; the previously retained phase discrepancy is not fixed\nby this evidence. Sources, exact comparers/references, path observations and\nraw outputs are retained in the 0.81 data-follow-up archive linked above.\n')
print(json.dumps(receipt),flush=True)
