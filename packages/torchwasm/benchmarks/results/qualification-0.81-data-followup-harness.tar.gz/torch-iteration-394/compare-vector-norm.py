"""Compare every recorded stage and expose all divergences for repair."""
from pathlib import Path
import json
import math

import numpy as np

r = Path(__file__).resolve().parent
read = lambda name: json.loads((r / name).read_text())
candidate = read('probe-prototype.json')
findings = []
counts = {}


def compare(actual, expected, path):
    if isinstance(expected, dict):
        if not isinstance(actual, dict) or set(actual) != set(expected):
            return [dict(path=path, reason='mapping structure', actual=actual, expected=expected)]
        differences = []
        for key in expected:
            differences.extend(compare(actual[key], expected[key], path + '/' + key))
        return differences
    if isinstance(expected, list):
        if not isinstance(actual, list) or len(actual) != len(expected):
            return [dict(path=path, reason='sequence structure', actual=actual, expected=expected)]
        if path.endswith('/values') or path.endswith('/imaginary'):
            def number(v):
                return float(v) if isinstance(v, str) else v
            a, b = np.asarray([number(v) for v in actual]), np.asarray([number(v) for v in expected])
            if not np.allclose(a, b, rtol=5e-5, atol=3e-6, equal_nan=True):
                return [dict(path=path, reason='numerical value', actual=actual, expected=expected)]
            return []
        differences = []
        for i, (a, b) in enumerate(zip(actual, expected)):
            differences.extend(compare(a, b, path + '/' + str(i)))
        return differences
    if actual != expected:
        return [dict(path=path, reason='metadata or discrete value', actual=actual, expected=expected)]
    return []


for version in ['26', '214']:
    native = read('probe-native-' + version + '.json')
    assert native['probe_sha256'] == candidate['probe_sha256']
    assert len(native['rows']) == len(candidate['rows']) == 780
    matched = errors_matched = 0
    for actual, expected in zip(candidate['rows'], native['rows']):
        assert actual['key'] == expected['key'] and set(actual) == set(expected)
        for stage in set(actual) - {'key'}:
            a, b = actual[stage], expected[stage]
            if a['status'] == b['status'] == 'error':
                # Exception messages are backend-specific, but exception types
                # and successful-versus-error behavior remain observable.
                differences = compare(a['type'], b['type'], stage + '/type')
                errors_matched += not bool(differences)
            else:
                differences = compare(a, b, stage)
            if differences:
                findings.append(dict(native_version=version, key=actual['key'], stage=stage, differences=differences))
            else:
                matched += 1
    counts[version] = dict(cases=780, matched_stages=matched, matched_error_stages=errors_matched,
                           mismatched_stages=sum(f['native_version'] == version for f in findings),
                           native_torch=native['torch'])
report = dict(status='needs_repair' if findings else 'native_numerical_and_ad_comparison_passed',
              counts=counts, findings=findings,
              production_source_changed=False, wasm_qualification='pending')
(r / 'native-comparison.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(status=report['status'], counts=counts, findings=len(findings))))
