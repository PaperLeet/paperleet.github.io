"""Compare every higher-derivative boundary and retain old native controls."""
from pathlib import Path
import ast
import json
import numpy as np

r = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_text())
source = r / 'compare-vector-norm.py'
function = next(node for node in ast.parse(source.read_text()).body if isinstance(node, ast.FunctionDef) and node.name == 'compare')
namespace = dict(np=np)
exec(compile(ast.Module(body=[function], type_ignores=[]), str(source), 'exec'), namespace)
compare = namespace['compare']
actual = read(r / 'hvp-prototype.json')
counts, findings = {}, []
for version in ['26', '214']:
    native = read(r / ('hvp-native-' + version + '.json'))
    assert actual['probe_sha256'] == native['probe_sha256']
    assert len(actual['rows']) == len(native['rows']) == 4480
    old = {row['key']: row for row in read(r / ('composition-native-' + version + '.json'))['rows']}
    overlaps = 0
    matched = 0
    for a, b in zip(actual['rows'], native['rows']):
        assert a['key'] == b['key']
        key = a['key']
        if key in old:
            overlaps += 1
            assert old[key]['hvp'] == b['hvp'], key
        a, b = a['hvp'], b['hvp']
        differences = compare(a['type'], b['type'], 'type') if a['status'] == b['status'] == 'error' else compare(a, b, 'hvp')
        if differences:
            findings.append(dict(version=version, key=key, differences=differences))
        else:
            matched += 1
    assert overlaps == 320
    counts[version] = dict(cases=4480, matched=matched, mismatched=4480 - matched, preserved_native_composition_controls=overlaps)
record = dict(status='needs_repair' if findings else 'passed', counts=counts, findings=findings)
(r / 'hvp-comparison.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(dict(status=record['status'], counts=counts)))
