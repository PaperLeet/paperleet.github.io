from pathlib import Path
import hashlib,json,tarfile,zipfile
root=Path(__file__).parent;repo=Path.cwd();expected=json.loads((root/'source-hashes.json').read_text());artifacts={};members={}
for folder,prefix,sdist_prefix in [('dist-preflight','stridetorch/','stridetorch-0.21.0/src/stridetorch/'),('dist-paperleet','paperleet/_vendor/torch/','paperleet-0.1.0/packages/stridetorch/src/stridetorch/')]:
 wheel=next((root/folder).glob('*.whl'));sdist=next((root/folder).glob('*.tar.gz'))
 with zipfile.ZipFile(wheel) as arc:
  modules=[n for n in arc.namelist() if n.startswith(prefix) and n.endswith('.py')];assert len(modules)==40
  for name,digest in expected.items():assert hashlib.sha256(arc.read(prefix+name)).hexdigest()==digest,(folder,name)
  members[folder]={n for n in arc.namelist() if n.endswith('.py')}
 with tarfile.open(sdist) as arc:
  for name,digest in expected.items():assert hashlib.sha256(arc.extractfile(sdist_prefix+name).read()).hexdigest()==digest,(folder,name)
 for p in [wheel,sdist]:artifacts[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
catalog=(repo/'paperleet/interview_catalog.json').read_bytes()
with zipfile.ZipFile(next((root/'dist-paperleet').glob('*.whl'))) as arc:assert arc.read('paperleet/interview_catalog.json')==catalog
with tarfile.open(next((root/'dist-paperleet').glob('*.tar.gz'))) as arc:assert arc.extractfile('paperleet-0.1.0/paperleet/interview_catalog.json').read()==catalog
assert not members['dist-preflight'].intersection(members['dist-paperleet'])
assert expected==json.loads((root/'wheel-stride021-result.json').read_text())['source_hashes']
assert expected==json.loads((root/'source-wasm.json').read_text())['source_hashes']
assert expected==json.loads((root/'chrome-contracts/result.json').read_text())['source_hashes']
assert expected=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'packages/stridetorch/src/stridetorch').iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']}
r=dict(status='success',version='0.21.0',modules=40,source_hashes=expected,artifacts=artifacts,installed_paths_disjoint=True,minimum_environment='Python3.10.19 NumPy1.26.4 without native Torch;741 tests',license='Apache-2.0')
(root/'distribution-identity.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(dict(status=r['status'],modules=40,artifacts=artifacts)))
