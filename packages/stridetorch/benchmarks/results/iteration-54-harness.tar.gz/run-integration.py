from pathlib import Path
import json,os,shutil,subprocess,time
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
i=r/'integration-proof';receipts=[]
def run(args,label,cwd):
 start=time.monotonic()
 with (i/(label+'.log')).open('w') as log:p=subprocess.run(args,cwd=cwd,env=dict(os.environ,PAPERLEET_WASM_CONCURRENCY='2'),stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(label=label,args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-start))
 (i/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(label,'terminal',p.returncode,flush=True);p.check_returncode()
shutil.copy2(r.parent/'torch-iteration-53/integration-proof/run-frontend.py',i/'run-frontend.py')
run(['/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-21/stride-dev-env/bin/python',str(i/'run-frontend.py')],'frontend',repo)
run(['/opt/homebrew/bin/node','web/scripts/check-browser-wasm.mjs','--all'],'full-wasm',repo)
shutil.copy2(repo/'reports/browser-wasm.json',i/'full-wasm-result.json')
