from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
out=repo/'packages/stridetorch/benchmarks/results';i=r/'integration-proof';p=r/'proof'
def read(path):return json.loads((r/path).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
source={f.name:sha(f) for f in (repo/'packages/stridetorch/src/stridetorch').iterdir() if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']}
assert source==read('proof/source-hashes.json') and len(source)==57
plan=read('proof/chrome-contracts/plan.json')
tests={f.name:sha(f) for f in (repo/'packages/stridetorch/tests').glob('test_*.py') if f.name!='test_standalone.py'}
assert plan['source']==source and plan['tests']==tests and plan['expected']==6696
baseline=json.loads((r.parent/'torch-iteration-53/proof/source-hashes.json').read_text())
assert {n for n in source if source[n]!=baseline[n]}=={'__init__.py','_registry.py','_transformer.py'}
cpu=read('full-root-receipt.json');assert cpu['exit_code']==0 and cpu['passed']==40326 and cpu['skipped']==1
gates=read('proof/gate-receipts.json');assert len(gates)==6 and all(x['exit_code']==0 for x in gates.values())
node=read('proof/source-wasm.json');chrome=read('proof/chrome-contracts/result.json');wheel=read('proof/wheel-stride054-result.json');co=read('proof/coinstall-result.json')
assert node['passed']==chrome['passed']==6696
assert node['source_hashes']==chrome['source_hashes']==wheel['source_hashes']==co['source_hashes']==source
assert chrome['test_hashes']==tests and all(x['status']=='success' for x in [chrome,wheel,co])
assert '6709 passed' in (p/'python310-stride054-tests.log').read_text() and not wheel['native_torch']
comparison=read('native-comparison.json');assert comparison['status']=='success' and comparison['cases']==60 and comparison['arrays']==4008
for name,digest in comparison['sha256'].items():assert sha(r/name)==digest
receipts=read('integration-proof/receipts.json');assert len(receipts)==2 and all(x['exit_code']==0 for x in receipts)
front=read('integration-proof/frontend-receipts.json');assert len(front)==5 and all(x['exit_code']==0 for x in front)
sync=read('upstream-sync.json')
assert sync['after']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
for name,digest in sync['paths'].items():
 assert sha(repo/name)==digest
 assert hashlib.sha256(subprocess.check_output(['git','show',sync['after']+':'+name],cwd=repo)).hexdigest()==digest
sync.update(frontend_rerun_pending=False,frontend_receipts='integration-proof/frontend-receipts.json')
save(r/'upstream-sync.json',sync)
wasm=read('integration-proof/full-wasm-result.json');assert wasm['passed'] and wasm['modules']==wasm['catalog_modules']==78 and not wasm['browser_budget_exceeded']
assert sum(x['mutants'] for x in wasm['results'])==342 and all(x['passed'] and not x['browser_budget_exceeded'] for x in wasm['results'])
contracts=next(x for x in wasm['results'] if x['id']=='architecture/attention')['independent_contracts']
assert contracts['passed']==6696 and len(contracts['suites'])==50
assert {x['suite']:x['source_sha256'] for x in contracts['suites']}==tests
exports=read('integration-proof/export-identity.json');assert exports['published_assets_unchanged']==11493 and exports['new_assets']==exports['active_assets']==158
live=read('integration-proof/live-expected-sha256.json');assert len(live)==161
for name,digest in live.items():assert sha(repo/'web/public/data'/name)==digest
policy=read('release-policy-identity.json')
for name,digest in policy['files'].items():assert sha(repo/name)==digest
native=read('native-catalog-reuse.json');assert native['files']==1152
for name,digest in native['native_input_sha256'].items():assert sha(repo/name)==digest
fresh=[]
for namespace,python,path in [('stridetorch',p/'python310-stride054-env/bin/python',p/'stridetorch-activation.pkl'),('paperleet._vendor.torch',p/'coinstall-env/bin/python',p/'paperleet-_vendor-torch-activation.pkl')]:
 result=subprocess.run([str(python),'-I',str(r/'fresh-load.py'),namespace,str(path)],capture_output=True,text=True,cwd=r)
 assert result.returncode==0,result.stderr
 fresh.append(dict(namespace=namespace,exit_code=0,output=result.stdout.strip()))
save(r/'fresh-load-result.json',fresh)
metadata=r/'package-metadata';metadata.mkdir(exist_ok=True)
for name in ['README.md','pyproject.toml','LICENSE','NOTICE']:shutil.copy2(repo/'packages/stridetorch'/name,metadata/name)
shutil.copy2(repo/'packages/stridetorch/tests/test_standalone.py',metadata/'test_standalone.py')
archive=out/'iteration-54-harness.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as target:
 for current,dirs,files in os.walk(r):
  dirs[:]=[d for d in dirs if d not in ['__pycache__','.pytest_cache'] and not d.endswith(('-env','-venv'))]
  for name in sorted(files):
   f=Path(current)/name
   if not f.is_symlink() and (f.name in ['LICENSE','NOTICE'] or f.suffix in ['.py','.mjs','.json','.log','.md','.html','.toml','.npz','.txt','.whl','.pkl'] or f.name.endswith('.tar.gz')):
    target.add(f,arcname=f.relative_to(r),recursive=False)
assert archive.stat().st_size<95*1024*1024
report=dict(status='validated_locally',version='0.54.0',baseline_main='dc6570257c654d3a8751b12bec3890d7dd7a3601',source_hashes=source,test_hashes=tests,
 changed_resources=['__init__.py','_registry.py','_transformer.py'],added_tests=61,transformer_tests=293,
 full_cpu=cpu,node_wasm=node,chrome_worker=chrome,minimal_wheel=wheel,coinstall=co,fresh_process=fresh,
 native_comparison=comparison,native_catalog_reuse=native,export_identity=exports,active_export_sha256=live,frontend=front,upstream_sync=sync,
 full_wasm=dict(modules=78,mutants=342,contracts=6696,suites=50,passed=True,browser_budget_exceeded=False),release_policy=policy,
 performance='No numerical kernel change or speedup claimed; live operator calls retain their existing guards and implementation. This iteration validates serialization and model lifecycle.',
 limitations=['Direct registered activation functions only; arbitrary closures and nested callable objects retain their existing Python serialization restrictions.','Full-model Python pickle requires trusted input and is separate from weights-only torch.load.','Existing 0.53 float32 mixed-AD qualification and dense CPU/WASM backend limits remain.'],
 raw_archive=dict(name=archive.name,sha256=sha(archive),bytes=archive.stat().st_size))
save(out/'iteration-54.json',report)
save(r/'state.json',dict(status='local_gates_passed',version='0.54.0',main_adoption_pending=True,source_hashes=source,active_export_sha256=live))
print(json.dumps(dict(status=report['status'],cpu=cpu['passed'],wasm=6696,wheel=6709,catalog=78,mutants=342,raw_archive=report['raw_archive'])))
