from pathlib import Path
import json,pickle,sys
import numpy as np

backend=sys.argv[1]
if backend=='native':
 import torch as t
 t.backends.cuda.enable_flash_sdp(False)
 t.backends.cuda.enable_mem_efficient_sdp(False)
 t.backends.cuda.enable_math_sdp(True)
else:from stridetorch import torch as t
r=Path(__file__).resolve().parent
arrays={};rows=[]
for kind in ['encoder_layer','decoder_layer','encoder','decoder','full']:
 for name in ['sin','relu','tanh','sigmoid','nn.functional.silu','nn.functional.softplus']:
  activation=t
  for part in name.split('.'):activation=getattr(activation,part)
  opts=dict(dim_feedforward=7,dropout=0.,activation=activation,batch_first=True,norm_first=True,dtype=t.float64)
  if kind=='encoder_layer':model=t.nn.TransformerEncoderLayer(4,2,**opts)
  elif kind=='decoder_layer':model=t.nn.TransformerDecoderLayer(4,2,**opts)
  elif kind=='encoder':model=t.nn.TransformerEncoder(t.nn.TransformerEncoderLayer(4,2,**opts),2,enable_nested_tensor=False)
  elif kind=='decoder':model=t.nn.TransformerDecoder(t.nn.TransformerDecoderLayer(4,2,**opts),2)
  else:model=t.nn.Transformer(4,2,2,2,**opts)
  rng=np.random.default_rng(5401)
  with t.no_grad():
   for key,p in model.named_parameters():p.copy_(t.tensor(rng.normal(1 if 'norm' in key and key.endswith('weight') else 0,.1,p.shape)))
  for protocol in [2,pickle.HIGHEST_PROTOCOL]:
   restored=pickle.loads(pickle.dumps(model,protocol=protocol))
   for m in restored.modules():
    if isinstance(m,(t.nn.TransformerEncoderLayer,t.nn.TransformerDecoderLayer)):assert m.activation is activation
   xs=[t.tensor(rng.normal(0,.3,(2,3,4)),requires_grad=True)]
   if kind not in ['encoder_layer','encoder']:xs.append(t.tensor(rng.normal(0,.3,(2,4,4)),requires_grad=True))
   def fn(*inputs):return restored(inputs[1],inputs[0]) if kind=='full' else restored(*inputs)
   directions=tuple(t.tensor(rng.normal(0,.2,x.shape)) for x in xs)
   output,tangent=t.func.jvp(fn,tuple(xs),directions)
   seed=t.tensor(rng.normal(0,.3,output.shape));active=xs+list(restored.parameters())
   first=t.autograd.grad((output*seed).sum(),active,retain_graph=True)
   mixed=t.autograd.grad((tangent*seed).sum(),active,allow_unused=True)
   mixed=[t.zeros_like(x) if g is None else g for x,g in zip(active,mixed)]
   values=[output,tangent,*first,*mixed];prefix=f'{kind}.{name}.{protocol}'
   for i,value in enumerate(values):arrays[f'{prefix}.{i}']=value.detach().numpy().copy()
   rows.append(dict(kind=kind,activation=name,protocol=protocol,arrays=len(values)))
np.savez_compressed(r/(backend+'-pickle.npz'),**arrays)
(r/(backend+'-pickle.json')).write_text(json.dumps(dict(backend=backend,cases=len(rows),arrays=len(arrays),rows=rows),indent=2)+'\n')
print(backend,len(rows),'cases',len(arrays),'arrays')
