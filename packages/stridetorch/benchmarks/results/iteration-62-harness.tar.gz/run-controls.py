from pathlib import Path
import json,subprocess,time,statistics
r=Path(__file__).resolve().parent;rows=[];receipts=[]
for i in range(4):
 start=time.monotonic()
 with (r/f'control-node-{i}.log').open('w') as log:p=subprocess.run(['/opt/homebrew/bin/node',str(r/'proof/control-node.mjs')],stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(repeat=i,exit_code=p.returncode,elapsed_s=time.monotonic()-start));p.check_returncode();j=json.loads((r/'proof/control-node-result.json').read_text());(r/f'control-node-{i}.json').write_text(json.dumps(j,indent=2)+'\n');rows.append(j);print('control',i,'terminal0',flush=True)
assert all(v['source_hashes']==rows[0]['source_hashes'] for v in rows)
summary=[]
for i,first in enumerate(rows[0]['rows']):
 ratios=[v['rows'][i]['candidate_over_baseline'] for v in rows];summary.append(dict(operation=first['operation'],dtype=first['dtype'],input_shape=first['input_shape'],median=statistics.median(ratios),range=[min(ratios),max(ratios)],ratios=ratios))
j=dict(status='measured',children=4,all_children_terminal=True,source_hashes=rows[0]['source_hashes'],source_identity=json.loads((r/'control-source-identity.json').read_text()),rows=summary,receipts=receipts,scope=rows[0]['scope']);(r/'control-summary.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(summary))
