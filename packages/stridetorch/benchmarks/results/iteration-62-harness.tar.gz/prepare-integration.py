from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-61';repo=Path('/Users/david/Developer/PaperLeet-torch-release');i=r/'integration-proof';i.mkdir(exist_ok=True)
for name in ['integration-proof/run-export.py','integration-proof/run-frontend.py','integration-proof/verify-export.py','run-front-only.py','run-full-wasm-only.py']:
 text=(old/name).read_text().replace('torch-iteration-61','torch-iteration-62').replace('len(published)==12599','len(published)==12757');(r/name).write_text(text)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();(i/'context.json').write_text(json.dumps(dict(upstream=head),indent=2)+'\n')
policy=json.loads((old/'release-policy-identity.json').read_text())
for name,h in policy['files'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==h
(r/'release-policy-identity.json').write_text(json.dumps(policy,indent=2)+'\n')
owned=[line[3:] for line in subprocess.check_output(['git','status','--short'],cwd=repo,text=True).splitlines()];assert len(owned)==6 and all(n.startswith('packages/stridetorch/') for n in owned)
(r/'owned-source-paths.json').write_text(json.dumps(owned,indent=2)+'\n');(r/'owned-input-sha256.json').write_text(json.dumps({n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in owned},indent=2)+'\n')
print('Integration baseline',head,'; six owned source paths; seven policy files unchanged')
