# WebGPU integration assessment — 2026-10-17

This is source/documentation evidence and a follow-up experiment boundary, not a
GPU implementation or throughput result. CPU/WASM remains the production path.

The current Tensor constructor stores `np.asarray(data)` in `_data`; `.numpy()`
returns an ndarray view. The `_backend.py` file is a compatibility facade, not a
storage/device abstraction. Therefore, replacing a NumPy call with asynchronous
GPU work would not by itself preserve current synchronous values, aliases and
saved-gradient storage. This is an inference from the current repository source.

Pyodide 0.29.4 offers a JS typed-array view of Python buffer memory through
`getBuffer`, whereas `toJs` copies buffer data. A view of WASM memory is useful
for transfer preparation; it does not establish shared GPU allocation or remove
GPU readback. Shape/stride and buffer lifetime still need explicit handling.
[Pyodide 0.29.4 buffer translation](https://pyodide.org/en/0.29.4/usage/type-conversions.html#buffers)

The current WGSL concrete floating-point runtime types are f32 and f16; the scalar
list provides no concrete f64 data type. Half precision requires its extension.
Thus a portable initial backend cannot silently narrow the library's float64
contract. Keep an explicit CPU/WASM fallback and qualify floating-point behavior
separately before offering GPU execution.
[WGSL types](https://www.w3.org/TR/WGSL/#scalar-types)

GPUBuffer mapping resolves a Promise before mapped content may be accessed.
Consequently, a synchronously observable Python ndarray is not supplied merely
by submitting a shader. Host-to-device preparation, command submission and
readback/synchronization must be included in any end-to-end comparison.
[WebGPU buffer mapping](https://www.w3.org/TR/webgpu/#dom-gpubuffer-mapasync)

Working hypothesis for a future isolated experiment: opt-in contiguous f32
GEMM/linear sequences with GPU-resident intermediate storage. Compare cold
initialization and warm repeated forward/weighted-backward paths separately,
including transfer and observable-result costs. Retain CPU/WASM for float64,
unsupported layouts/dtypes/operations and cases without measured end-to-end gain.
No crossover size is selected without measurement, and no WebGPU work is inserted
into the NumPy path in this iteration. The synchronous Python/async GPU boundary
and GPU lifetime model need a tested design before general API integration.
