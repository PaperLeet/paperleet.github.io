from pathlib import Path
import json
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');j=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-62.json').read_text());rows=j['performance']['rows']
def table(selected):
 text='| Runtime | Operation | Dtype | Shape | Mode | Candidate / 0.61 | Four-child range |\n|---|---|---|---|---|---:|---:|\n'
 for v in selected:
  a,b=v['ratio_range'];text+=f"| {v['runtime']} | {v['operation']} | {v['dtype']} | {v['input_shape']} | {v['mode']} | {v['ratio_median']:.3f} | {a:.3f}–{b:.3f} |\n"
 return text
forward=[v for v in rows if v['operation']=='logdet' and v['dtype'] in ['float32','float64'] and v['shape'] in ['scalar','small','larger'] and v['mode']=='forward']
controls=[v for v in rows if v['operation']=='graph']
worst=sorted(rows,key=lambda v:v['ratio_median'],reverse=True)[:8]
backward=[v for v in rows if v['operation']=='logdet' and v['shape']=='larger' and v['mode']=='full_step']
mem='| Variant | Operation | Dtype | Newly retained forward | Forward peak | Backward peak |\n|---|---|---|---:|---:|---:|\n'
for v in j['memory']['rows']:
 if v['operation']=='logdet' and v['input_shape']==[64,64]:mem+=f"| {v['variant']} | logdet | {v['dtype']} | {v['new_retained_bytes']:,} | {v['forward_peak_bytes']:,} | {v['backward_peak_bytes']:,} |\n"
a=j['raw_archive'];b=j['source_footprint']['baseline'];c=j['source_footprint']['candidate'];stages=j['ui_qualification_stages'];ui='; '.join(f"{len(v['checks'])} affected checks at `{v['upstream']}` plus driver/policy/two-build gates" for v in stages) if stages else 'No later UI sync was needed.'
text=f'''# Torch runtime iteration 62 — cheaper log determinant common paths

Version **0.62.0** reduces correction-array and predicate overhead in existing
logdet/slogdet implementations. It retains the 0.61 API, derivative, singular,
mutation and graph-lifetime contracts. Final integration base is
`{j['baseline_main']}`; the full CPU/frontend/catalog baseline is
`{j['full_validation_baseline']}`. {ui}

## Changes and preserved behavior

Real ordinary inputs no longer construct unused NaN-sign corrections. Runtimes
whose LAPACK misclassifies NaN pivots still scan the input, but construct
correction arrays only for batches that actually contain NaN. A scalar mask
already has a truth value, so single-matrix predicates avoid a second NumPy
reduction. Positive real logdet reuses the factorization's logabs value instead
of making an unnecessary `where` result. Negative masks are computed once and
used by backward/JVP only when needed. There is no approximate factorization,
clipping, regularization, cross-call tensor cache or relaxed numerical threshold.

The ordinary reverse-graph loop again uses one combined no-gradient/pruning
condition. Unused-edge release and grad-frontier handling remain unchanged;
None gradients are not converted into zero arrays. Existing saved-value guards,
shared slogdet-output lifetime, immutable JVP factor snapshots and column-major
raw VJP layouts remain in force.

Complex forward, real negative/singular/nonfinite values, batches and empty
layouts retain the same validated behavior. Native reference is frozen PyTorch
2.14.1, git `5c4886908584029761b579af026dcfb627c84070`. The scope and intentional
limits are documented in the
[0.61 report](torch-runtime-iteration-61.md): real first-order VJP/JVP, complex
forward only, pinned saved-factor reverse-over-JVP semantics, separate legacy
det cofactor/nonfinite-input contracts, and equivalent positive singleton
leaf-gradient strides. Complex AD, output buffers, arbitrary higher derivatives
and live-autograd-graph standard pickle remain outside the supported scope.
The existing strict NumPy-error-policy det diagnostic from 0.61 is also unchanged.

## Verification

- Frozen final numerical source: **40,970 CPU passes, 1 skip**; source hashes
  captured before and checked after the process.
- Actual Node/Pyodide and Chrome Worker: **7,340 independent contracts each**,
  all 54 suites, Pyodide 0.29.4 / NumPy 2.2.5. Installed wheel on Python 3.10.19 /
  NumPy 1.26.4: **7,353 passes**, native Torch absent.
- Public wheel/sdist and vendored wheel match all **59 Python modules plus two
  license resources**. Coexistence, uninstalling either owner, aliases, fresh
  process serialization and native Torch isolation pass.
- Identical 600-case qualification on CPU, Node, Chrome and the installed minimum
  environment. Each checks 1,764 numeric arrays and 360 None-gradient fields:
  480 native log cases, 54 ordinary native det cases, 48 separate legacy det
  cases and 18 retained restriction cases. Legacy cases are not labeled native
  passes. Complex NaN/Inf components are checked separately. Ten stored-gradient
  arrays use the documented equivalent singleton-stride contract.
- All **78 exported modules and 342 mutants** pass the original browser budgets;
  embedded contracts include all 54 suites. All 1,152 native catalog input hashes
  remain unchanged. The 12,757 earlier immutable payloads are byte-identical;
  158 new assets are reachable and all 161 active export/index hashes are recorded.
- Full frontend checks, policy checks and both build profiles pass at the recorded
  baseline; any later disjoint UI changes have explicit staged qualification above.
- Seven release-policy files remain byte-identical to canonical
  `13d2782a494415ba72bc604a0ef7e4c4f875ba25`. No CI trigger, tag, dispatch, release,
  package upload or deployment is initiated.

Development prototypes and their source snapshots are retained. No new tests
are added merely to mirror these implementation branches: existing independent
scalar/native oracles, saved-storage/lifetime tests, layout tests and full
application checks verify the unchanged contract.

## Paired performance against actual 0.61 APIs

Twelve fresh children (four CPU, four Node, four Chrome), **100 matched workflows
per child**: real determinant/log forward and weighted backward, complex forward
and graph controls. Both sides invoke their actual logdet/slogdet APIs. The old
0.60 `det.log` composition is not the baseline here. Common calibrated batches
last at least 20 ms, with five alternating samples. Tables show the median of
four child ratios and their range; below 1 is faster. Inputs/conversions/seeds
are outside timing; dispatch, graph construction, kernels, weighted backward,
gradient clearing and result destruction are inside. Heavy correctness checks
finish before timing. CPU thread caps are two. No native-Torch, GPU, cold-start
or host-wide-isolation claim is made.

Real logdet forward:

{table(forward)}
64×64 logdet forward plus weighted backward:

{table(backward)}
Unchanged graph controls:

{table(controls)}
Largest matched ratios, including losses:

{table(worst)}
All 300 runtime/workflow aggregate rows, 1,200 child workflow results, calibration
values and samples are retained. Float32 old/new gradients retain the separately
labeled 1e-5 normwise benchmark check; independent native qualification retains
its existing elementwise/special-value/schema checks without relaxed limits.

The original full-matrix Node float32 64×64 det full-step median is 1.073,
with a 0.989–1.152 child range. Four additional fresh Node diagnostic children
isolate that unchanged numerical path: median 0.993, range 0.986–1.006.
The determinant module, layout/Tensor/autograd support modules and solve-helper
ASTs are verified unchanged; the generic graph condition ordering is the
remaining relevant implementation difference. This isolated diagnostic does not
replace or relabel the original full-matrix result and does not prove universal
absence of regression. Both datasets, source-identity checks and the first
metadata-only diagnostic-harness failure are retained. Graph medians/ranges above
remain visible; no blanket graph speedup is claimed.

## Allocation and footprint

Warm CPU tracemalloc incremental tracked bytes for 64×64 logdet below. The
archived `warm-memory.py` primes both actual API paths before tracing. Inputs
and seeds predate the trace. First-cold diagnostics are separate. Forward
retained/peak and backward peak are distinct measurements, not process RSS,
LAPACK workspace, total tape bytes or WASM heap size.

{mem}
The complete 24-row allocation table is in the machine report. Source/license
bytes change from {b['source_license_bytes']:,} to {c['source_license_bytes']:,};
local concatenated gzip from {b['local_concatenated_gzip_bytes']:,} to
{c['local_concatenated_gzip_bytes']:,} bytes. Gzip is a footprint diagnostic, not
wheel or transfer size. There are no additional runtime dependencies.

## Backend assessment

Source/documentation review confirms that the current Tensor owns a synchronous
NumPy ndarray. Pyodide can expose a JS view of that WASM memory, but GPU mapping
is asynchronous and portable WGSL has no concrete f64 type. An initial opt-in
f32 GEMM/linear experiment therefore needs storage/lifetime and synchronization
boundaries, explicit fallbacks and end-to-end transfer/readback measurements.
This is an architectural inference, not a measured GPU speedup; CPU/WASM remains
the production path. Sources: [pinned Pyodide buffers](https://pyodide.org/en/0.29.4/usage/type-conversions.html#buffers),
[WGSL scalar types](https://www.w3.org/TR/WGSL/#scalar-types),
[WebGPU buffer mapping](https://www.w3.org/TR/webgpu/#dom-gpubuffer-mapasync).
The full review is archived as `webgpu-backend-notes.md`.

## Reproduction

[Machine report](../../packages/stridetorch/benchmarks/results/iteration-62.json)
and [raw harness](../../packages/stridetorch/benchmarks/results/iteration-62-harness.tar.gz).
Archive: {a['bytes']:,} bytes; SHA-256 `{a['sha256']}`. Frozen baseline/candidate
sources, programs, native inputs/results, runtime plans, package artifacts,
receipts, prototypes and samples are included. The repository benchmark is
`packages/stridetorch/benchmarks/bench_determinants.py`.

The broader independent-library/core-coverage/backend objective remains active.
'''
(repo/'docs/validation/torch-runtime-iteration-62.md').write_text(text);print('Wrote iteration-62 validation report')
