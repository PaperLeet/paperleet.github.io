from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-61';repo=Path('/Users/david/Developer/PaperLeet-torch-release');p=r/'proof';c=p/'chrome-contracts';c.mkdir(parents=True,exist_ok=True)
source=repo/'packages/stridetorch/src/stridetorch';tests=repo/'packages/stridetorch/tests'
for f in [*source.glob('*.py'),source/'LICENSE',source/'NOTICE']:
 (p/'source').mkdir(exist_ok=True);shutil.copy2(f,p/'source'/f.name)
prior=json.loads((old/'proof/chrome-contracts/plan.json').read_text());(c/'tests').mkdir(exist_ok=True)
for name in prior['tests']:shutil.copy2(tests/name,c/'tests'/name)
shutil.copytree(p/'source',c/'source',dirs_exist_ok=True)
hashes=lambda paths:{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in paths}
plan=dict(source=hashes((p/'source').iterdir()),tests=hashes((c/'tests').glob('*.py')),version='0.62.0',expected=7340)
assert len(plan['source'])==61 and len(plan['tests'])==54
for target,value in [(c/'plan.json',plan),(p/'source-hashes.json',plan['source']),(p/'test-hashes.json',plan['tests'])]:target.write_text(json.dumps(value,indent=2)+'\n')
for name in ['fixture-server.mjs','run-gates.py','run-full.py','prepare-oracle.py','prepare-bench.py','run-bench-final.py','run-oracles.py','check-native-isolation.py','fresh-load.py','run-minimum-oracle.py','post-performance.py','warm-memory.py','summarize-performance.py','proof/wasm-contracts.mjs','proof/chrome-contracts/run.mjs','proof/chrome-contracts/worker.mjs','proof/chrome-contracts/index.html','proof/check-wheel.py','proof/check-coinstall.py']:
 text=(old/name).read_text().replace('torch-iteration-61','torch-iteration-62').replace('0.61.0','0.62.0').replace('stride061','stride062')
 if name=='summarize-performance.py':text=text.replace('matched_rows=88,candidate_only_rows=12','matched_rows=100,candidate_only_rows=0')
 (r/name).write_text(text)
print('Prepared 61 resources, 54 suites and direct 0.61 baseline benchmark harness')
