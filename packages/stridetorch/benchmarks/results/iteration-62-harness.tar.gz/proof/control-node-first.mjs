import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const base=new URL('./chrome-contracts/',import.meta.url);const plan=JSON.parse(fs.readFileSync(new URL('bench-plan.json',base)));
const py=await loadPyodide({indexURL:'/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/',packageCacheDir:'/Users/david/Developer/PaperLeet-torch-release/web/public/browser-runtime/pyodide-0.29.4/',stdout(){},stderr(){}});
await loadJudgePackages(py,[]);
for(const [name,dir] of [['baseline','baseline'],['candidate','source']]){
 py.FS.mkdirTree('/'+name+'/stridetorch');
 for(const file of Object.keys(plan[name]))py.FS.writeFile('/'+name+'/stridetorch/'+file,fs.readFileSync(new URL(dir+'/'+file,base)));
}
py.FS.writeFile('/bench_determinants.py',fs.readFileSync(new URL('bench_determinants.py',base)));
py.globals.set('plan_json',JSON.stringify(plan));
const result=JSON.parse(py.runPython(`
import sys,json,pathlib,hashlib
sys.path.insert(0,'/')
plan=json.loads(plan_json)
for label in ['baseline','candidate']:
 actual={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in pathlib.Path('/'+label+'/stridetorch').iterdir() if f.is_file()}
 assert actual==plan[label]
assert hashlib.sha256(pathlib.Path('/bench_determinants.py').read_bytes()).hexdigest()==plan['benchmark_sha256']
import gc,json,time,statistics
from bench_determinants import load,_data,_method,_compare
old,oh=load('_control_baseline','/baseline/stridetorch');new,nh=load('_control_candidate','/candidate/stridetorch');rows=[]
for dtype in ['float32','float64']:
 for op,shape in [('det',(64,64)),('graph',(1,)),('graph',(32,))]:
  import numpy as np
  data=_data(shape,dtype) if op=='det' else np.full(shape,.3,dtype=dtype)
  variants={label:_method(module,data,op,True,False) for label,module in [('baseline',old),('candidate',new)]}
  _compare(variants['candidate'][1](),variants['baseline'][1](),dtype,True)
  calls=1;calibration={};samples={label:[] for label in variants}
  for label,(fn,_) in variants.items():
   batch=1
   while True:
    start=time.perf_counter()
    for _ in range(batch):fn()
    elapsed=time.perf_counter()-start
    if elapsed>=.02:break
    batch*=2
   calls=max(calls,batch);calibration[label]=dict(calls=batch,elapsed_s=elapsed)
  for repeat in range(5):
   for label in (list(variants) if repeat%2==0 else list(reversed(variants))):
    fn=variants[label][0];start=time.perf_counter()
    for _ in range(calls):fn()
    samples[label].append((time.perf_counter()-start)/calls)
  medians={k:statistics.median(v) for k,v in samples.items()}
  rows.append(dict(operation=op,dtype=dtype,input_shape=list(shape),calls=calls,calibration=calibration,samples_s=samples,median_s=medians,candidate_over_baseline=medians['candidate']/medians['baseline']))
json.dumps(dict(status='success',source_hashes=dict(baseline=oh,candidate=nh),rows=rows,scope='Supplemental isolated unchanged-det and generic-graph diagnostic; original full-matrix timing remains authoritative and is not replaced.'))
`));result.pyodide=py.version;assert.equal(result.numpy,'2.2.5');
fs.writeFileSync(new URL("control-node-result.json",import.meta.url),JSON.stringify(result,null,2)+String.fromCharCode(10));
console.log(JSON.stringify({status:result.status,flows:result.rows.length,pyodide:result.pyodide,numpy:result.numpy}));
