import {loadJudgePackages} from '../../../extraction-browser/packages.mjs';
self.onmessage=async()=>{try{
 const plan=await(await fetch('./bench-plan.json')).json();
 const {loadPyodide}=await import('../../../runtime-0.29.4/pyodide.mjs');
 const py=await loadPyodide({indexURL:new URL('../../../runtime-0.29.4/',self.location.href).href,stdout(){},stderr(){}});
 await loadJudgePackages(py,[]);
 for(const [name,dir] of [['baseline','baseline'],['candidate','source']]){
  py.FS.mkdirTree('/'+name+'/stridetorch');
  for(const file of Object.keys(plan[name]))py.FS.writeFile('/'+name+'/stridetorch/'+file,await(await fetch('./'+dir+'/'+file)).text());
 }
 py.FS.writeFile('/bench_determinants.py',await(await fetch('./bench_determinants.py')).text());
 py.globals.set('plan_json',JSON.stringify(plan));
 const result=JSON.parse(py.runPython(`
import sys,json,pathlib,hashlib
sys.path.insert(0,'/')
plan=json.loads(plan_json)
for label in ['baseline','candidate']:
 actual={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in pathlib.Path('/'+label+'/stridetorch').iterdir() if f.is_file()}
 assert actual==plan[label]
assert hashlib.sha256(pathlib.Path('/bench_determinants.py').read_bytes()).hexdigest()==plan['benchmark_sha256']
import numpy
from bench_determinants import run
bench=run('/baseline/stridetorch','/candidate/stridetorch')
assert bench['source_hashes']==dict(baseline=plan['baseline'],candidate=plan['candidate'])
json.dumps(dict(status='success',numpy=numpy.__version__,benchmark_sha256=plan['benchmark_sha256'],benchmark=bench))
`));self.postMessage({...result,pyodide:py.version});
}catch(error){self.postMessage({error:String(error.stack||error)});}};
