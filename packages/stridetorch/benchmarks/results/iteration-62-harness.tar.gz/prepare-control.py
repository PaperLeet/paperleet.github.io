from pathlib import Path
import hashlib,json,ast
r=Path(__file__).resolve().parent;c=r/'proof/chrome-contracts';repo=Path('/Users/david/Developer/PaperLeet-torch-release')
old=r/'baseline-source/stridetorch';new=repo/'packages/stridetorch/src/stridetorch'
unchanged={name:hashlib.sha256((old/name).read_bytes()).hexdigest()==hashlib.sha256((new/name).read_bytes()).hexdigest() for name in ['_linalg.py','_layout.py','_tensor.py','_autograd.py','_state.py']};assert all(unchanged.values())
def function(path,name):return ast.dump(next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef) and n.name==name),include_attributes=False)
functions={name:function(old/'_determinants.py',name)==function(new/'_determinants.py',name) for name in ['_diagonal_solve','_solve_values','_ieee_solve']};assert all(functions.values())
(r/'control-source-identity.json').write_text(json.dumps(dict(unchanged_files=unchanged,unchanged_solve_functions=functions,remaining_difference='Generic graph skip-condition ordering; log-value mask optimizations are not called by det.'),indent=2)+'\n')
program='''import gc,json,time,statistics
from bench_determinants import load,_data,_method,_compare
old,oh=load('_control_baseline','/baseline/stridetorch');new,nh=load('_control_candidate','/candidate/stridetorch');rows=[]
for dtype in ['float32','float64']:
 for op,shape in [('det',(64,64)),('graph',(1,)),('graph',(32,))]:
  import numpy as np
  data=_data(shape,dtype) if op=='det' else np.full(shape,.3,dtype=dtype)
  variants={label:_method(module,data,op,True,False) for label,module in [('baseline',old),('candidate',new)]}
  _compare(variants['candidate'][1](),variants['baseline'][1](),dtype,True)
  calls=1;calibration={};samples={label:[] for label in variants}
  for label,(fn,_) in variants.items():
   batch=1
   while True:
    start=time.perf_counter()
    for _ in range(batch):fn()
    elapsed=time.perf_counter()-start
    if elapsed>=.02:break
    batch*=2
   calls=max(calls,batch);calibration[label]=dict(calls=batch,elapsed_s=elapsed)
  for repeat in range(5):
   for label in (list(variants) if repeat%2==0 else list(reversed(variants))):
    fn=variants[label][0];start=time.perf_counter()
    for _ in range(calls):fn()
    samples[label].append((time.perf_counter()-start)/calls)
  medians={k:statistics.median(v) for k,v in samples.items()}
  rows.append(dict(operation=op,dtype=dtype,input_shape=list(shape),calls=calls,calibration=calibration,samples_s=samples,median_s=medians,candidate_over_baseline=medians['candidate']/medians['baseline']))
json.dumps(dict(status='success',numpy=np.__version__,source_hashes=dict(baseline=oh,candidate=nh),rows=rows,scope='Supplemental isolated unchanged-det and generic-graph diagnostic; original full-matrix timing remains authoritative and is not replaced.'))
'''
# Reuse the exact source/runtime loader; replace only the benchmark invocation.
s=(r/'proof/bench-node.mjs').read_text();start=s.index('const result=JSON.parse(py.runPython(`');end=s.index('`));result.pyodide=',start)
loader=s[start:end];header=loader[:loader.index('import numpy\nfrom bench_determinants import run')];s=s[:start]+header+program+s[end:];s=s.replace('bench-node-result.json','control-node-result.json');s=s.replace('flows:result.benchmark.rows.length','flows:result.rows.length');(r/'proof/control-node.mjs').write_text(s)
print('Prepared supplemental controls; numeric determinant/solve source identity verified')
