from pathlib import Path
import argparse,hashlib,importlib.util,json,sys,warnings
import numpy as np
from cases import exercise,unpacked
parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,required=True);parser.add_argument('--oracle',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
r=Path(__file__).resolve().parent;reference=json.loads(args.oracle.read_text());assert reference['cases_sha256']==hashlib.sha256((r/'cases.py').read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('_gradient_probe',args.source/'__init__.py',submodule_search_locations=[str(args.source)]);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
rows=[];mismatches=[];version_differences=[]
with warnings.catch_warnings():
 warnings.simplefilter('ignore')
 for expected in reference['rows']:
  actual=exercise(module.torch,expected['spec']);rows.append(actual);issues=[]
  if (actual['error'] is None)!=(expected['error'] is None):issues.append('error_presence')
  elif expected['error'] is not None and actual['error']['type']!=expected['error']['type']:issues.append('error_class')
  for name in ['mode_restored','identities_preserved','result_detached','events','gradient_requires_grad']:
   if actual[name]!=expected[name]:issues.append(name)
  if actual['version_deltas']!=expected['version_deltas']:version_differences.append(dict(key=actual['spec']['key'],native=expected['version_deltas'],candidate=actual['version_deltas']))
  for name in ['value','gradients']:
   aa=[actual[name]] if name=='value' else actual[name];ee=[expected[name]] if name=='value' else expected[name]
   if len(aa)!=len(ee):issues.append(name+'_length');continue
   for index,(a,e) in enumerate(zip(aa,ee)):
    if a is None or e is None:
     if (a is None)!=(e is None):issues.append(name+'_none')
     continue
    x,y=unpacked(a),unpacked(e)
    if x.dtype!=y.dtype or x.shape!=y.shape:issues.append(name+'_metadata');continue
    try:np.testing.assert_allclose(x,y,rtol=4e-3 if x.dtype.itemsize<=2 else 6e-6 if x.dtype in [np.dtype('float32'),np.dtype('complex64')] else 4e-12,atol=3e-5 if x.dtype.itemsize<=2 else 1e-7 if x.dtype in [np.dtype('float32'),np.dtype('complex64')] else 1e-12,equal_nan=True)
    except AssertionError:issues.append(name+'_values:'+str(index))
    if x.dtype.kind=='f' and np.any(np.signbit(x[(x==0)&(y==0)])!=np.signbit(y[(x==0)&(y==0)])):issues.append(name+'_signed_zero:'+str(index))
  if issues:mismatches.append(dict(key=actual['spec']['key'],issues=issues,native=expected,candidate=actual))
result=dict(status='passed' if not mismatches else 'needs_repair',cases=len(rows),mismatches=mismatches,version_differences=version_differences,rows=rows,oracle_torch=reference['torch'],oracle_sha256=hashlib.sha256(args.oracle.read_bytes()).hexdigest(),numpy=np.__version__,production_changed=False)
args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(status=result['status'],cases=len(rows),mismatches=len(mismatches),version_differences=len(version_differences))))
