from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copytree(b/'torch-iteration-464/candidate',r/'candidate')
(r/'contracts').mkdir()
for p in (repo/'packages/stridetorch/tests').iterdir():
 if p.suffix=='.py':shutil.copy2(p,r/'contracts'/p.name)
(r/'oracle').mkdir()
for folder,name in [(425,'cases.py'),(425,'check.py'),(428,'native26.json')]:shutil.copy2(b/f'torch-iteration-{folder}'/name,r/'oracle'/name)
s=(b/'torch-iteration-442/run.py').read_text();s=s.replace("b/'torch-iteration-441/prototype'","r/'candidate'").replace("b/'torch-iteration-441/prototype/stridetorch'","r/'candidate/stridetorch'")
s=s.replace("for name,h in read(b/'torch-iteration-441/source-plan.json')['inputs'].items():assert sha(b/'torch-iteration-441'/name)==h,name", "for name,h in plan['inputs'].items():assert sha(r/name)==h,name")
s=s.replace("b/'torch-iteration-425/check.py'","r/'oracle/check.py'").replace("b/'torch-iteration-428/native26.json'","r/'oracle/native26.json'")
s=s.replace("str(repo/'packages/stridetorch/tests'),str(b/'torch-iteration-429/test_gradient_clipping.py'),str(b/'torch-iteration-436/test_binary_saved_values.py')","str(r/'contracts')")
(r/'run.py').write_text(s)
files=[p for p in r.rglob('*') if p.is_file()]
plan=dict(runner_sha256=sha(r/'run.py'),files={},inputs={str(p.relative_to(r)):sha(p) for p in files},pythons=dict(numpy25=str(b/'torch-iteration-82/application-env/bin/python'),numpy126=str(b/'torch-iteration-137/native26-env/bin/python')),scope='Isolatedoperand-lifetimecandidate;fullunalteredSDKtestsandindependentclippingoracle;productionunchanged')
(r/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps(dict(status='prepared',sdk_files=len(list((r/'contracts').glob('*.py'))))))
