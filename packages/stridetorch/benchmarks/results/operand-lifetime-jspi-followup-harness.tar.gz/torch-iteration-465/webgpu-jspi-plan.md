# Deferred JSPI/WebGPU transport investigation

The pinned Pyodide 0.29.4 [FFI documentation](https://pyodide.org/en/0.29.4/usage/api/python-api/ffi.html#pyodide.ffi.run_sync) provides run_sync for awaiting a promise from synchronous Python, with an async Python entry point; it is labelled experimental. The [JavaScript API](https://pyodide.org/en/0.29.4/usage/api/js-api.html#PyodideConfig.enableRunUntilComplete) documents stack-switching configuration. The [official JSPI article](https://blog.pyodide.org/posts/jspi/) explains runPythonAsync/callPromising and runtime capability requirements.

Local source evidence: current browserWorker.mjs enters calibration and run_suite through synchronous runPython calls. A GPU request cannot simply await a JavaScript promise on that existing entry path.

Hypothesis, not a qualified backend: an optional asynchronous host entry plus run_sync may preserve ordinary synchronous torch code while a trusted host performs WebGPU work outside an opaque learner Worker.

Deferred checks, after current catalog budgets finish:

1. Probe actual async-entry capability and a MessageChannel echo; retain synchronous-entry failure as a control.
2. Record GPU adapter/device availability in both host and real opaque Worker; do not infer support from Chrome version alone.
3. Verify cancellation, device loss, late replies, exception/gradient-state restoration and CPU fallback.
4. Use trusted fixed kernels, bounded shapes and copied arrays across suspension; never submit learner shader/code to the host.
5. Compare full forward/backward plus owned output copies against current 0.82 CPU/WASM, including cold setup, uploads, readback and retained resources. Pipeline caching is distinct from input-value caching.
6. Preserve float64/unsupported-device CPU routing and existing numerical/caller-buffer contracts.

No GPU production code is changed. No JSPI/GPU numerical experiment has run from this plan.
