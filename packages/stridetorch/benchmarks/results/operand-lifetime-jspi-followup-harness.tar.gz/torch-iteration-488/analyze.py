from pathlib import Path
import hashlib,json,sys
import numpy as np
r=Path(__file__).resolve().parent;b=r.parent;sys.path.insert(0,str(b/'torch-iteration-479'));from corpus import unpacked
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=read(b/'torch-iteration-479/result.json');assert original['status']=='needs_review' and len(original['failures'])==12
assert all(v['baseline_candidate_exact'] for v in original['comparisons'])
native=read(b/'torch-iteration-486/native26.json');baseline=read(b/'torch-iteration-486/baseline.json');candidate=read(b/'torch-iteration-486/candidate.json');assert baseline==candidate
rows=[]
for n,a in zip(native['rows'],baseline['rows']):
 assert n['index']==a['index'] and n['value']==a['value']
 assert n['seed']!=a['seed']
 assert n['native_seed_gradient']==a['native_seed_gradient']
 x,y=unpacked(n['gradient'][0]),unpacked(a['gradient'][0]);assert x.dtype==y.dtype==np.float64
 rows.append(dict(index=n['index'],spec=n['spec'],output_values_bitwise_equal=True,nonlinear_cotangent_dtype=unpacked(n['seed']).dtype.name,nonlinear_cotangents_identical=False,native_scalar_gradient=float(x),runtime_scalar_gradient=float(y),absolute_difference=float(abs(x-y)),fixed_native_cotangent_all_gradients_bitwise_equal=True))
result=dict(status='localized_existing_mixed_precision_differences_without_changing_tolerances',original_corpus_status_preserved=original['status'],cases_per_environment=882,baseline_candidate_bitwise_identical=True,complete_native_matches_per_environment=876,existing_precision_contexts=6,rows=rows,interpretation='Differencesalreadyexistinthe0.82baseline:float32nonlinearcotangentsdifferbeforethebinarypullback;withidenticalnativecotangentsallcomparedbinarygradientsmatchbitwise.Thefloat64scalargradientdoesnotmakeupstreamfloat32mathfloat64accurate.Originalstrictfloat64comparisonsremainfailed;nofullnativeparityclaim.',original_result_sha256=sha(b/'torch-iteration-479/result.json'),production_changed=False,precision_fix_adopted=False)
assert not (r/'result.json').exists();(r/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],existing_precision_contexts=6)))
