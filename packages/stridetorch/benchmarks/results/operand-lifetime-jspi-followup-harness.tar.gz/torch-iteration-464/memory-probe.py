"""Deferred operand-lifetime experiment; not a latency or RSS measurement."""
from pathlib import Path
import argparse,gc,hashlib,importlib.util,json,sys,weakref
import numpy as np
parser=argparse.ArgumentParser();parser.add_argument('--variant',choices=['baseline','candidate'],required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
r=Path(__file__).resolve().parent;plan=json.loads((r/'source-plan.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,h in plan['inputs'].items():assert sha(r/name)==h,name
source=r/args.variant/'stridetorch';spec=importlib.util.spec_from_file_location('_retain464_'+args.variant,source/'__init__.py',submodule_search_locations=[str(source)]);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module);api=module.torch
def owner(a):
 while isinstance(a.base,np.ndarray):a=a.base
 return a
def buffered_operands(root,excluded):
 found={};seen=set();stack=[root._grad_node]
 while stack:
  node=stack.pop()
  if node is None or id(node) in seen:continue
  seen.add(id(node))
  functions=[getattr(node,'joint',None)]
  for parent,function,_ in node._parents:stack.append(parent);functions.append(function)
  for function in functions:
   for cell in getattr(function,'__closure__',None) or ():
    value=cell.cell_contents
    if isinstance(value,np.ndarray):
     value=owner(value)
     if value.size>1 and id(value) not in excluded:found[id(value)]=value.nbytes
 return dict(owners=len(found),bytes=sum(found.values()))
rows=[]
for dtype in ['float32','float64']:
 for layout in ['C','F']:
  for kind in ['chain1','chain8','chain32','tensor_left','tensor_right','divide_left','mixed_left','multiply_both','divide_both']:
   raw=np.linspace(2.,3.,4096,dtype=dtype).reshape(64,64);other=np.linspace(.5,1.,4096,dtype=dtype).reshape(64,64)
   if layout=='F':raw=np.asfortranarray(raw);other=np.asfortranarray(other)
   x=api.from_numpy(raw).requires_grad_();y=api.from_numpy(other).requires_grad_();g=x+y;h=x-y
   references=[weakref.ref(g._data)];excluded={id(owner(x._data)),id(owner(y._data))}
   c=api.full(g.shape,4.,dtype=api.float64 if kind=='mixed_left' else getattr(api,dtype));excluded.add(id(owner(c._data)))
   if kind.startswith('chain'):
    count=int(kind[5:]);value=g
    for index in range(count):value=value*(2. if index%2==0 else .5)
    factor=2. if count%2 else 1.;expected=[np.full(raw.shape,factor),np.full(raw.shape,factor)]
   elif kind in ['tensor_left','mixed_left']:value=g*c;expected=[np.full(raw.shape,4.),np.full(raw.shape,4.)]
   elif kind=='tensor_right':value=c*g;expected=[np.full(raw.shape,4.),np.full(raw.shape,4.)]
   elif kind=='divide_left':value=g/c;expected=[np.full(raw.shape,.25),np.full(raw.shape,.25)]
   elif kind=='multiply_both':value=g*h;references.append(weakref.ref(h._data));expected=[2*raw,-2*other]
   else:value=g/h;references.append(weakref.ref(h._data));expected=[-2*other/(raw-other)**2,2*raw/(raw-other)**2]
   loss=value.sum();del g,h,c,value;gc.collect()
   before=buffered_operands(loss,excluded);alive_before=[reference() is not None for reference in references]
   gradients=api.autograd.grad(loss,(x,y))
   for actual,wanted in zip(gradients,expected):np.testing.assert_allclose(actual.numpy(),wanted,rtol=6e-6 if dtype=='float32' else 3e-12,atol=1e-7 if dtype=='float32' else 1e-12)
   gc.collect();alive_after=[reference() is not None for reference in references];assert not any(alive_after),(dtype,layout,kind)
   rows.append(dict(dtype=dtype,layout=layout,kind=kind,before_backward_non_scalar_captured_operands=before,intermediate_arrays_alive_before=alive_before,intermediate_arrays_alive_after=alive_after,loss=float(loss.item()),gradient_checks_passed=True))
assert not args.output.exists();args.output.write_text(json.dumps(dict(status='observed_operand_lifetime',variant=args.variant,numpy=np.__version__,rows=rows,production_changed=False),indent=2)+'\n');print(json.dumps(dict(variant=args.variant,cases=len(rows),gradient_checks_passed=True)))
