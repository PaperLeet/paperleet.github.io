from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent;b=r.parent;experiment=b/'torch-iteration-464';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
assert not (r/'plan.json').exists()
write(r/'plan.json',dict(sources=read(experiment/'source-plan.json'),probe_sha256=sha(experiment/'memory-probe.py'),runner_sha256=sha(Path(__file__)),scope='Smallfrozenoperand-lifetimeandanalyticgradientprobe;noRSSorlatencyclaim;productionunchanged'))
receipts=[];env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');env.pop('PYTHONPATH',None)
for environment,python in [('numpy25',b/'torch-iteration-82/application-env/bin/python'),('numpy126',b/'torch-iteration-137/native26-env/bin/python')]:
 for variant in ['baseline','candidate']:
  label=environment+'-'+variant;output=r/(label+'.json');log=r/(label+'.log')
  assert sha(experiment/'memory-probe.py')==read(r/'plan.json')['probe_sha256']
  with log.open('w') as stream:child=subprocess.run([str(python),'-I','-B',str(experiment/'memory-probe.py'),'--variant',variant,'--output',str(output)],env=env,stdout=stream,stderr=subprocess.STDOUT)
  receipts.append(dict(label=label,exit_code=child.returncode,log_sha256=sha(log)));write(r/'progress.json',dict(status='running',receipts=receipts));child.check_returncode()
rows=[]
for environment in ['numpy25','numpy126']:
 old=read(r/(environment+'-baseline.json'));new=read(r/(environment+'-candidate.json'));assert len(old['rows'])==len(new['rows'])==36
 for left,right in zip(old['rows'],new['rows']):
  assert all(left[k]==right[k] for k in ['dtype','layout','kind','loss','gradient_checks_passed','intermediate_arrays_alive_after'])
  before=left['before_backward_non_scalar_captured_operands'];after=right['before_backward_non_scalar_captured_operands'];assert after['bytes']<=before['bytes']
  rows.append(dict(environment=environment,dtype=left['dtype'],layout=left['layout'],kind=left['kind'],baseline=before,candidate=after,baseline_intermediate_alive=left['intermediate_arrays_alive_before'],candidate_intermediate_alive=right['intermediate_arrays_alive_before']))
write(r/'result.json',dict(status='passed_small_operand_lifetime_and_gradient_probe',comparisons=len(rows),rows=rows,production_changed=False,latency_qualified=False,rss_measured=False,next='Broadenbroadcasting/mixed/layout/alias/mutation/JVP/HVPfunctionalchecksandmeasureallocation/fullcalllatencybeforeadoption'))
write(r/'progress.json',dict(status='completed',receipts=receipts));print(json.dumps(dict(status='passed',comparisons=len(rows))))
