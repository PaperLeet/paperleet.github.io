from pathlib import Path
import argparse,hashlib,importlib.util,json,sys
import numpy as np
b=Path(__file__).resolve().parent.parent;r=Path(__file__).resolve().parent;sys.path.insert(0,str(b/'torch-iteration-479'))
from corpus import array,packed,unpacked,specifications
parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--native-reference',type=Path);args=parser.parse_args()
if args.source:
 spec=importlib.util.spec_from_file_location('_precision486',args.source/'__init__.py',submodule_search_locations=[str(args.source)]);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module);api=module.torch
else:import torch as api
reference=json.loads(args.native_reference.read_text()) if args.native_reference else None
failed={644,648,742,746,840,844};rows=[]
for index,spec in enumerate(specifications()):
 if index not in failed:continue
 x=api.from_numpy(array(spec['shapes'][0],spec['dtype'],spec['layout'],1.25)).requires_grad_()
 y=api.from_numpy(array(spec['shapes'][1],'float32',spec['layout'],2.5)).requires_grad_(spec['activity']=='both')
 a=x+.25;other=y-.125;value=a*other;loss=(value.sin()+value.square()*.1).sum();targets=(x,y) if spec['activity']=='both' else (x,)
 seed=api.autograd.grad(loss,value,retain_graph=True)[0];full=api.autograd.grad(loss,targets,retain_graph=True)
 common=unpacked(next(row for row in reference['rows'] if row['index']==index)['seed']).copy() if reference else seed.detach().numpy().copy()
 seeded=api.autograd.grad(value,targets,api.from_numpy(common),retain_graph=True)
 # Independently record both NumPy reduction orders without changing the runtime.
 product=np.asarray(common*other.detach().numpy(),dtype=common.dtype)
 rows.append(dict(index=index,spec=spec,value=packed(value),loss=packed(loss),seed=packed(seed),gradient=[packed(g) for g in full],native_seed_gradient=[packed(g) for g in seeded],numpy_full_reduce=float(product.sum()),numpy_axiswise_reduce=float(product.sum(axis=0).sum(axis=0))))
assert len(rows)==6 and not args.output.exists();args.output.write_text(json.dumps(dict(status='observed_precision_diagnostic',rows=rows,production_changed=False),indent=2)+'\n');print(json.dumps(dict(status='observed',cases=6)))
