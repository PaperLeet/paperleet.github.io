import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const root=path.dirname(new URL(import.meta.url).pathname),runtime=path.resolve(root,'../torch-iteration-76/runtime');
const hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
assert(!fs.existsSync(root+'/plan.json'));
const inputs=Object.fromEntries([import.meta.url.slice(7),...['pyodide.mjs','pyodide.asm.js','pyodide.asm.wasm','python_stdlib.zip','pyodide-lock.json'].map(n=>runtime+'/'+n)].map(p=>[p,hash(p)]));
fs.writeFileSync(root+'/plan.json',JSON.stringify({inputs,scope:'ExperimentalopaqueWorkerJSPIMessageChanneltofixedtrustedhostWebGPUkernel;noAPIintegration,latencyorbackendqualification',sources:['https://pyodide.org/en/0.29.4/usage/api/python-api/ffi.html#pyodide.ffi.run_sync','https://blog.pyodide.org/posts/jspi/']},null,2)+'\n');
const requests=[],diagnostics=[];
const server=http.createServer((req,res)=>{
 const pathname=new URL(req.url,'http://127.0.0.1').pathname;requests.push({path:pathname,origin:req.headers.origin??null});
 if(pathname==='/'){res.writeHead(200,{'content-type':'text/html'});res.end('<!doctype html><title>Isolated JSPI transport probe</title>');return;}
 if(!pathname.startsWith('/runtime/')||!['GET','HEAD'].includes(req.method)){res.writeHead(404);res.end();return;}
 const name=pathname.slice('/runtime/'.length);if(!/^[\w.-]+$/.test(name)){res.writeHead(404);res.end();return;}
 const p=path.join(runtime,name);if(!fs.existsSync(p)){res.writeHead(404);res.end();return;}
 res.writeHead(200,{'content-type':name.endsWith('.mjs')||name.endsWith('.js')?'text/javascript':name.endsWith('.wasm')?'application/wasm':'application/octet-stream','access-control-allow-origin':'*'});fs.createReadStream(p).pipe(res);
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));let browser;
try{
 browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 const page=await browser.newPage();page.on('console',event=>diagnostics.push({type:event.type(),text:event.text()}));page.on('pageerror',error=>diagnostics.push({pageerror:String(error)}));page.on('requestfailed',request=>diagnostics.push({requestfailed:request.url(),error:request.failure()}));const origin='http://127.0.0.1:'+server.address().port;await page.goto(origin);
 const result=await page.evaluate(async origin=>{
  const adapter=await navigator.gpu?.requestAdapter();const info=adapter?{vendor:adapter.info.vendor,architecture:adapter.info.architecture,fallback:adapter.info.isFallbackAdapter}:null;
  const device=adapter?await adapter.requestDevice():null;let created=0,destroyed=0;const calls=[];
  async function fixedMatmul(){
   if(!device)throw Error('HostGPUUnavailable');
   const code=`@group(0) @binding(0) var<storage,read> a:array<f32>; @group(0) @binding(1) var<storage,read> b:array<f32>; @group(0) @binding(2) var<storage,read_write> c:array<f32>; @compute @workgroup_size(4) fn main(@builtin(global_invocation_id) id:vec3<u32>){let i=id.x;if(i>=4u){return;}let row=i/2u;let col=i%2u;c[i]=a[row*2u]*b[col]+a[row*2u+1u]*b[2u+col];}`;
   const buffers=[];function buffer(usage){const b=device.createBuffer({size:16,usage});buffers.push(b);created++;return b;}
   try{
    const a=buffer(GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST),b=buffer(GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST),c=buffer(GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC),read=buffer(GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ);
    device.queue.writeBuffer(a,0,new Float32Array([1,2,3,4]));device.queue.writeBuffer(b,0,new Float32Array([5,6,7,8]));
    const pipeline=await device.createComputePipelineAsync({layout:'auto',compute:{module:device.createShaderModule({code}),entryPoint:'main'}});
    const bind=device.createBindGroup({layout:pipeline.getBindGroupLayout(0),entries:[a,b,c].map((b,binding)=>({binding,resource:{buffer:b}}))});
    const encoder=device.createCommandEncoder(),pass=encoder.beginComputePass();pass.setPipeline(pipeline);pass.setBindGroup(0,bind);pass.dispatchWorkgroups(1);pass.end();encoder.copyBufferToBuffer(c,0,read,0,16);device.queue.submit([encoder.finish()]);await read.mapAsync(GPUMapMode.READ);const copy=new Float32Array(read.getMappedRange()).slice();read.unmap();return Array.from(copy);
   }finally{for(const b of buffers){b.destroy();destroyed++;}}
  }
  async function probeWorker(){
   self.onmessage=async({data,ports})=>{
    const port=ports[0],pending=new Map();let seq=0,lateReplies=0;port.onmessage=({data})=>{const item=pending.get(data.id);if(!item){lateReplies++;return;}pending.delete(data.id);clearTimeout(item.timer);data.error?item.reject(Error(data.error)):item.resolve(data.value);};port.start();
    const request=kind=>new Promise((resolve,reject)=>{const id=++seq;const timer=setTimeout(()=>{pending.delete(id);reject(Error('TransportTimeout'));},5000);pending.set(id,{resolve,reject,timer});port.postMessage({id,kind});});
    try{
     const {loadPyodide}=await import(data.base+'runtime/pyodide.mjs');const py=await loadPyodide({indexURL:data.base+'runtime/',stdout(){},stderr(){}});py.registerJsModule('fixed_host',{request});py.runPython('import sys;sys.dont_write_bytecode=True\nfrom pyodide.ffi import run_sync\nfrom fixed_host import request\nimport json');
     let synchronousError='';try{py.runPython("run_sync(request('echo'))");}catch(error){synchronousError=String(error);}
     const echo=await py.runPythonAsync("run_sync(request('echo'))");
     const gpu=data.hostGPU?JSON.parse(await py.runPythonAsync("json.dumps(run_sync(request('matmul2')).to_py())")):null;
     const rejected=JSON.parse(await py.runPythonAsync("try:\n    run_sync(request('unregistered_shader'))\n    rejected = False\nexcept Exception as exc:\n    rejected = 'UnsupportedFixedOperation' in str(exc)\njson.dumps(rejected)"));
     await new Promise(resolve=>setTimeout(resolve,30));
     self.postMessage({type:'complete',result:{origin:self.origin,secure_context:self.isSecureContext,gpu_exposed:!!self.navigator.gpu,jspi:{suspending:typeof WebAssembly.Suspending,promising:typeof WebAssembly.promising},pyodide:py.version,synchronous_error:synchronousError,async_echo:echo,host_gpu_result:gpu,unknown_operation_rejected:rejected,pending:pending.size,late_replies:lateReplies}});
    }catch(error){self.postMessage({type:'error',error:String(error.stack||error)});}finally{port.close();}
   };
  }
  const frame=document.createElement('iframe');frame.sandbox='allow-scripts';
  const bootstrap=`self.onmessage=({data,ports})=>{const u=URL.createObjectURL(new Blob([data.source],{type:'text/javascript'}));const w=new Worker(u,{type:'module'});w.onmessage=({data})=>{URL.revokeObjectURL(u);parent.postMessage(data,'*');};w.onerror=e=>{URL.revokeObjectURL(u);parent.postMessage({type:'error',error:JSON.stringify({message:e.message,filename:e.filename,lineno:e.lineno,colno:e.colno})},'*');};w.postMessage(data,[ports[0]]);};`;
  frame.srcdoc='<script>'+bootstrap+'<\/script>';document.body.append(frame);await new Promise(resolve=>frame.onload=resolve);
  const channel=new MessageChannel();channel.port1.onmessage=async({data})=>{
   calls.push({id:data.id,kind:data.kind});let response;
   try{if(data.kind==='echo')response={value:37};else if(data.kind==='matmul2')response={value:await fixedMatmul()};else throw Error('UnsupportedFixedOperation');}
   catch(error){response={error:String(error)};}
   channel.port1.postMessage({id:data.id,...response});
  };channel.port1.start();
  try{
   const response=await new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>reject(Error('OpaqueWorkerDeadline')),45000);
    const listen=e=>{if(e.source!==frame.contentWindow)return;if(e.data.type!=='complete'&&e.data.type!=='error')return;clearTimeout(timer);window.removeEventListener('message',listen);e.data.type==='error'?reject(Error(e.data.error)):resolve(e.data.result);};window.addEventListener('message',listen);
    frame.contentWindow.postMessage({source:'('+probeWorker.toString()+')()',base:origin+'/',hostGPU:!!device},'*',[channel.port2]);
   });return {host:{secure_context:window.isSecureContext,gpu_exposed:!!navigator.gpu,adapter_info:info,device_available:!!device},worker:response,calls,buffers_created:created,buffers_destroyed:destroyed};
  }finally{channel.port1.close();frame.remove();device?.destroy();}
 },origin);
 for(const [p,h]of Object.entries(inputs))assert.equal(hash(p),h,p);
 fs.writeFileSync(root+'/result.json',JSON.stringify({status:'observed_experimental_transport',browser:browser.version(),diagnostics,launch:{headless:true,extra_flags:[]},result,requests,production_changed:false,numerical_backend_qualified:false,performance_qualified:false},null,2)+'\n');
 assert.equal(result.worker.origin,'null');assert.equal(result.worker.secure_context,false);assert.equal(result.worker.gpu_exposed,false);assert.match(result.worker.synchronous_error,/synchronous/);assert.equal(result.worker.async_echo,37);assert.equal(result.worker.unknown_operation_rejected,true);assert.equal(result.worker.pending,0);assert.equal(result.buffers_created,result.buffers_destroyed);
 if(result.host.device_available)assert.deepEqual(result.worker.host_gpu_result,[19,22,43,50]);
 console.log(JSON.stringify({status:'passed_experimental_jspi_fixed_host_transport',hostGPU:result.host.device_available,result:result.worker.host_gpu_result}));
}catch(error){fs.writeFileSync(root+'/failure.json',JSON.stringify({error:String(error.stack||error),diagnostics,requests},null,2)+'\n');throw error;}
finally{if(browser)await browser.close();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
