import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
import {loadJudgePackages} from '../torch-iteration-76/chrome-sdk/packages.mjs';
self.onmessage=async()=>{
 try{
  const plan=await(await fetch('./source-plan.json')).json();
  const py=await loadPyodide({indexURL:new URL('../torch-iteration-76/runtime/',self.location.href).href,
   stdout(message){if(message.startsWith('SDK_PROGRESS'))self.postMessage({status:'progress',message});},stderr(message){self.postMessage({status:'diagnostic',message});}});
  await loadJudgePackages(py,[]);py.runPython('import sys;sys.dont_write_bytecode=True');
  for(const [name,item] of Object.entries(plan.payload)){
   const response=await fetch(item.source);if(!response.ok)throw Error('Missing '+name);
   const bytes=new Uint8Array(await response.arrayBuffer());
   const actual=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),v=>v.toString(16).padStart(2,'0')).join('');
   if(actual!==item.sha256)throw Error('Changed '+name);
   py.FS.mkdirTree('/'+name.split('/').slice(0,-1).join('/'));py.FS.writeFile('/'+name,bytes);
  }
  const report=JSON.parse(py.runPython("exec(compile(open('/check-sdk.py').read(),'/check-sdk.py','exec'))\njson.dumps(report)"));
  const memory={};
  for(const variant of ['baseline','candidate']){
   py.globals.set('_memory_variant',variant);
   py.runPython("import runpy,sys\nsys.argv=['/experiment/memory-probe.py','--variant',_memory_variant,'--output','/memory-'+_memory_variant+'.json']\nrunpy.run_path('/experiment/memory-probe.py',run_name='__main__')");
   memory[variant]=JSON.parse(py.FS.readFile('/memory-'+variant+'.json',{encoding:'utf8'}));
  }
  self.postMessage({status:'completed',report,memory,oracleRaw:py.FS.readFile('/oracle-result.json',{encoding:'utf8'}),pyodide:py.version});
 }catch(error){self.postMessage({status:'failed',error:String(error.stack||error)});}
};
