"""Independent native arithmetic reference; all returned arrays are owned copies."""
from pathlib import Path
import argparse,base64,hashlib,importlib.util,json,sys,warnings
import numpy as np
r=Path(__file__).resolve().parent

def specifications():
 for dtype in ['float16','float32','float64']:
  for layout in ['C','F','sliced']:
   for shapes in [((3,4),(3,4)),((3,4),(4,)),((3,1),(3,4)),((),(3,4)),((0,4),(1,4)),((2,3,4),(1,3,1))]:
    for kind in ['tensor','mixed','alias','python_float','python_reverse']:
     if kind=='alias' and shapes[0]!=shapes[1]:continue
     for activity in (['left'] if kind.startswith('python') or kind=='alias' else ['left','right','both']):
      for operation in ['multiply','divide']:
       yield dict(dtype=dtype,layout=layout,shapes=shapes,kind=kind,activity=activity,operation=operation)

def array(shape,dtype,layout,offset):
 n=int(np.prod(shape));x=(np.arange(n,dtype='float64')*.013+offset).reshape(shape).astype(dtype)
 if layout=='F':return np.array(x,order='F',copy=True)
 if layout=='sliced' and len(shape):
  base=np.empty(shape[:-1]+(shape[-1]*2,),dtype=dtype);base[...,::2]=x;return base[...,::2]
 return np.array(x,order='C',copy=True)
def packed(value):
 a=value.detach().numpy().copy();return dict(dtype=a.dtype.str,shape=list(a.shape),bytes=base64.b64encode(a.tobytes(order='C')).decode())
def unpacked(value):return np.frombuffer(base64.b64decode(value['bytes']),dtype=value['dtype']).reshape(value['shape'])
def exercise(api,spec):
 dtype,layout,shapes,kind,activity,op=(spec[k] for k in ['dtype','layout','shapes','kind','activity','operation'])
 x=api.from_numpy(array(shapes[0],dtype,layout,1.25));x.requires_grad_(activity in ['left','both'])
 if kind=='alias':y=x
 elif kind.startswith('python'):y=2.25
 else:
  other_dtype='float64' if kind=='mixed' and dtype!='float64' else 'float32' if kind=='mixed' else dtype
  y=api.from_numpy(array(shapes[1],other_dtype,layout,2.5));y.requires_grad_(activity in ['right','both'])
 targets=[t for t in [x,y] if not isinstance(t,float) and t.requires_grad];saved=[]
 for target in targets:
  target.grad=api.full_like(target,7.);saved.append(target.grad)
 a=x+.25;b=y-.125 if not isinstance(y,float) else y
 if kind=='python_reverse':a,b=b,a
 value=a*b if op=='multiply' else a/b
 loss=(value.sin()+value.square()*.1).sum()
 gradients=api.autograd.grad(loss,tuple(targets))
 assert all(target.grad is sentinel for target,sentinel in zip(targets,saved))
 assert all(np.all(target.grad.numpy()==7) for target in targets)
 return dict(spec=spec,value=packed(value),loss=packed(loss),gradients=[packed(g) for g in gradients],leaf_versions=[int(t._version) for t in targets],gradients_detached=all(not g.requires_grad for g in gradients),leaf_buffers_preserved=True)

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
 if args.source:
  spec=importlib.util.spec_from_file_location('_arithmetic478',args.source/'__init__.py',submodule_search_locations=[str(args.source)]);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module);api=module.torch;version=module.__version__
 else:
  import torch as api
  version=api.__version__
 rows=[]
 with warnings.catch_warnings():
  warnings.simplefilter('ignore')
  for spec in specifications():rows.append(exercise(api,spec))
 assert not args.output.exists();args.output.write_text(json.dumps(dict(version=version,numpy=np.__version__,cases=len(rows),corpus_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows),indent=2)+'\n');print(json.dumps(dict(status='recorded',cases=len(rows),version=version)))
if __name__=='__main__':main()
