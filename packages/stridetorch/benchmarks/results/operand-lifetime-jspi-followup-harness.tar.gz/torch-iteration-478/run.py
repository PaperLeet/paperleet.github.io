from pathlib import Path
import hashlib,json,os,subprocess,sys
import numpy as np
from corpus import unpacked
r=Path(__file__).resolve().parent;b=r.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
assert not (r/'plan.json').exists()
write(r/'plan.json',dict(corpus_sha256=sha(r/'corpus.py'),runner_sha256=sha(Path(__file__)),sources=read(b/'torch-iteration-464/source-plan.json'),scope='Native2.6arithmeticreferenceplusbitwisebaseline/candidate;ownedvalues/loss/gradientoutputs,leafstate,layouts,broadcast,mixeddtypes,duplicatealias,scalarreverse;nomemoryortimingclaim'))
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');env.pop('PYTHONPATH',None)
python26=b/'torch-iteration-137/native26-env/bin/python';python25=b/'torch-iteration-82/application-env/bin/python'
jobs=[('native26',python26,None)]+[(label+'-'+variant,python,b/'torch-iteration-464'/variant/'stridetorch') for label,python in [('numpy25',python25),('numpy126',python26)] for variant in ['baseline','candidate']]
for label,python,source in jobs:
 assert sha(r/'corpus.py')==read(r/'plan.json')['corpus_sha256']
 args=[str(python),'-I','-B',str(r/'corpus.py'),'--output',str(r/(label+'.json'))]
 if source:args+=['--source',str(source)]
 with (r/(label+'.log')).open('w') as log:child=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 write(r/'progress.json',dict(status='running' if child.returncode==0 else 'failed',label=label,exit_code=child.returncode));child.check_returncode()
reference=read(r/'native26.json');failures=[];comparisons=[]
for label in ['numpy25','numpy126']:
 old=read(r/(label+'-baseline.json'));new=read(r/(label+'-candidate.json'));assert old['cases']==new['cases']==reference['cases']
 for index,(expected,left,right) in enumerate(zip(reference['rows'],old['rows'],new['rows'])):
  if left!=right:failures.append(dict(environment=label,case=index,kind='baseline_candidate_difference',spec=left['spec']))
  issues=[]
  for name in ['leaf_versions','leaf_buffers_preserved','gradients_detached']:
   if right[name]!=expected[name]:issues.append(name)
  for name in ['value','loss','gradients']:
   actual=right[name] if name=='gradients' else [right[name]];wanted=expected[name] if name=='gradients' else [expected[name]]
   if len(actual)!=len(wanted):issues.append(name+'_length');continue
   for a,e in zip(actual,wanted):
    x,y=unpacked(a),unpacked(e)
    if x.dtype!=y.dtype or x.shape!=y.shape:issues.append(name+'_metadata');continue
    tolerance=(8e-3,4e-3) if x.dtype.itemsize==2 else (1e-5,2e-6) if x.dtype.itemsize==4 else (3e-12,1e-12)
    try:np.testing.assert_allclose(x,y,rtol=tolerance[0],atol=tolerance[1],equal_nan=True)
    except AssertionError:issues.append(name+'_values')
  if issues:failures.append(dict(environment=label,case=index,kind='native_difference',spec=right['spec'],issues=issues))
 comparisons.append(dict(environment=label,cases=new['cases'],baseline_candidate_exact=not any(v['environment']==label and v['kind']=='baseline_candidate_difference' for v in failures)))
write(r/'result.json',dict(status='passed' if not failures else 'needs_review',cases=reference['cases'],comparisons=comparisons,failures=failures,native_torch=reference['version'],production_changed=False));write(r/'progress.json',dict(status='completed',failures=len(failures)));print(json.dumps(dict(status='passed' if not failures else 'needs_review',cases=reference['cases'],failures=len(failures))))
assert not failures
