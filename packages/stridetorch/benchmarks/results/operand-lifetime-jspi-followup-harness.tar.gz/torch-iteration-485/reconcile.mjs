import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
import {loadJudgePackages} from '../torch-iteration-76/chrome-sdk/packages.mjs';
const root=new URL('./',import.meta.url),old=new URL('../torch-iteration-480/',root),read=url=>JSON.parse(fs.readFileSync(url,'utf8')),hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const original=read(new URL('result.json',old));assert.equal(original.exit_code,1);assert.equal(original.passed,12295);assert.equal(original.skipped,0);assert.equal(original.failures.length,3);assert(original.failures.every(v=>v.nodeid.startsWith('test_standalone.py::')&&v.error.includes('emscripten does not support processes')));
const previous=new URL('../torch-iteration-443/contracts/',root),current=new URL('contracts/',old),previousFiles=fs.readdirSync(previous).filter(n=>n.endsWith('.py')).sort(),currentFiles=fs.readdirSync(current).filter(n=>n.endsWith('.py')).sort();
assert.deepEqual(currentFiles.filter(n=>!previousFiles.includes(n)),['test_standalone.py']);assert(previousFiles.every(n=>hash(new URL(n,previous))===hash(new URL(n,current))));
const plan=read(new URL('source-plan.json',old));for(const[n,h]of Object.entries(plan.files))assert.equal(hash(new URL(n,old)),h,n);
const py=await loadPyodide({indexURL:new URL('../torch-iteration-76/runtime/',root).pathname,stdout:()=>{},stderr:()=>{}});await loadJudgePackages(py,[]);
for(const n of Object.keys(plan.files)){if(!n.startsWith('candidate/')&&!n.startsWith('contracts/'))continue;py.FS.mkdirTree('/'+n.split('/').slice(0,-1).join('/'));py.FS.writeFile('/'+n,fs.readFileSync(new URL(n,old)));}
const collection=JSON.parse(py.runPython(`import sys,json,io,contextlib
sys.dont_write_bytecode=True
sys.path.insert(0,'/candidate')
import pytest
class Collection:
 def __init__(self):self.nodeids=[]
 def pytest_collection_finish(self,session):self.nodeids=[item.nodeid for item in session.items]
c=Collection()
with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
 code=pytest.main(['/contracts','--collect-only','-q','--noconftest','-p','no:cacheprovider','--import-mode=importlib'],plugins=[c])
open('/collection.json','w').write(json.dumps(dict(exit_code=int(code),nodeids=c.nodeids)))
json.dumps(dict(exit_code=int(code),nodeids=c.nodeids))`));
fs.writeFileSync(new URL('collection.json',root),py.FS.readFile('/collection.json',{encoding:'utf8'}));assert.equal(collection.exit_code,0);assert.equal(collection.nodeids.length,12298);const hosts=collection.nodeids.filter(n=>n.startsWith('test_standalone.py::')),browser=collection.nodeids.filter(n=>!n.startsWith('test_standalone.py::'));assert.equal(hosts.length,13);assert.equal(browser.length,12285);
const result={status:'verified_browser_sdk_subset_from_preserved_superset_run',browser_sdk_passed:12285,browser_sdk_failures:0,browser_sdk_skips:0,additional_host_test_passes:10,host_subprocess_failures:original.failures.map(v=>v.nodeid),original_invocation_passed:false,original_result_sha256:hash(new URL('result.json',old)),browser_contract_files:previousFiles.length,all_browser_contract_bytes_unchanged:true,full_actual_wasm_collection:collection,gradient_oracle:original.gradient_oracle,production_changed:false};
fs.writeFileSync(new URL('result.json',root),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({status:result.status,browser_sdk_passed:12285}));
