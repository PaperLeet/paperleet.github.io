from pathlib import Path
import json,sys
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'proof/chrome-contracts'))
import bench_determinants
import bench_inverse
result=bench_determinants.run(sys.argv[1],sys.argv[2]);result['inverse_benchmark']=bench_inverse.run(sys.argv[1],sys.argv[2]);print(json.dumps(result,indent=2))
