from pathlib import Path
import hashlib,json
import numpy as np
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-64';prior=json.loads((old/'jvp-inputs.json').read_text());data=np.load(old/'jvp-inputs.npz');arrays={};cases=[]
with np.errstate(all='ignore'):
 for item in prior['cases']:
  key=item['key'];a=data[key+'.a'];e=data[key+'.e'];seed=(np.cos(np.arange(a.size)*.13).reshape(a.shape)*.2+.7).astype(a.dtype)
  for suffix,value in [('a',a),('e',e),('seed',seed)]:arrays[key+'.'+suffix]=value.copy()
  cases.append(dict(**item,mode='jvp'))
 for dtype in ['float32','float64']:
  for offset,shape in enumerate([(1,2,2),(2,1,2,2),(2,3,1,1)]):
   a=np.broadcast_to(np.eye(shape[-1])*2,shape).astype(dtype).copy();e=np.ones(shape,dtype=dtype)*.3;key=f'{dtype}.{29+offset}'
   for suffix,value in [('a',a),('e',e),('seed',np.ones(shape,dtype=dtype)*.7)]:arrays[key+'.'+suffix]=value
   cases.append(dict(key=key,dtype=dtype,index=29+offset,name='extra_batch_'+str(offset),shape=list(shape),mode='jvp'))
 for dtype in ['complex64','complex128']:
  real=np.dtype('float32' if dtype=='complex64' else 'float64');f=np.finfo(real);a2=np.array([[2.+.2j,.3-.1j],[.4+.3j,3.-.2j]],dtype=dtype)
  examples=[('scalar',np.array([[2.+.1j]])),('scalar_zero',np.zeros((1,1))),('scalar_max_real',np.array([[complex(f.max,0)]])),('scalar_max_both',np.array([[complex(f.max,f.max)]])),('scalar_tiny',np.array([[complex(f.tiny,f.tiny)]])),('scalar_subnormal',np.array([[complex(np.nextafter(real.type(0),real.type(1)),0)]])),('regular2',a2),('diagonal2',np.diag([1.+1j,2.-2j])),('zero2',np.zeros((2,2))),('rank_one2',np.array([[1.+1j,2.+2j],[2.+2j,4.+4j]])),('regular3',np.eye(3)*3+np.sin(np.arange(9).reshape(3,3))*.1j),('batch3',np.broadcast_to(np.eye(3)*(2.+.1j),(2,3,3))),('empty0',np.empty((0,0))),('batch_empty0',np.empty((2,0,0))),('empty_batch2',np.empty((0,2,2))),('regular32',np.eye(32)*3+np.sin(np.arange(32*32).reshape(32,32))*.01j)]
  for index,(name,value) in enumerate(examples):
   a=np.asarray(value,dtype=dtype);key=f'{dtype}.{index}';arrays[key+'.a']=a
   cases.append(dict(key=key,dtype=dtype,index=index,name=name,shape=list(a.shape),mode='forward'))
np.savez_compressed(r/'inverse-inputs.npz',**arrays)
(r/'inverse-inputs.json').write_text(json.dumps(dict(cases=cases,arrays=len(arrays),sha256=hashlib.sha256((r/'inverse-inputs.npz').read_bytes()).hexdigest()),indent=2)+'\n')
print(len(cases),'matrix groups;',len(arrays),'frozen arrays')
