from pathlib import Path
import json,os,subprocess,sys
r=Path(__file__).resolve().parent;identity=json.loads((r/'performance/identity.json').read_text());assert identity['all_children_terminal'] and identity['children']==12
for name in ['post-performance.py','warm-memory.py','summarize-inverse-performance.py']:
 with (r/(name+'.log')).open('w') as log:subprocess.run([sys.executable,str(r/name)],stdout=log,stderr=subprocess.STDOUT,check=True,env={**os.environ,**identity['thread_caps']})
 print(name,'TERMINAL 0',flush=True)
args=[sys.executable,str(r/'bench_inverse.py'),str(r/'baseline-source/stridetorch'),'/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src/stridetorch','--memory']
with (r/'performance/inverse-memory.json').open('w') as log:subprocess.run(args,stdout=log,stderr=subprocess.PIPE,check=True,env={**os.environ,**identity['thread_caps']})
print('Inverse allocation diagnostic TERMINAL 0',flush=True)
