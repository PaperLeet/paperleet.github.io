from pathlib import Path
import hashlib,json
import numpy as np
r=Path(__file__).resolve().parent;reference=json.loads((r/'native-inverse.json').read_text());candidate=json.loads((r/'adapter-inverse.json').read_text())
assert reference['version'].startswith('2.14.1') and reference['native_git']=='5c4886908584029761b579af026dcfb627c84070'
assert reference['input_sha256']==candidate['input_sha256']==hashlib.sha256((r/'inverse-inputs.npz').read_bytes()).hexdigest()
assert reference['driver_sha256']==candidate['driver_sha256']==hashlib.sha256((r/'differential-inverse.py').read_bytes()).hexdigest()
expected=json.loads((r/'inverse-expected-source.json').read_text());assert candidate['source_hashes']==expected and len(expected)==61 and candidate['version']=='0.65.0'
a=np.load(r/'native-inverse.npz');b=np.load(r/'adapter-inverse.npz');arrays=none_fields=singular=real_cases=complex_cases=0;layouts=[];normwise=[];maximum_scaled_errors={}
assert reference['rows'].keys()==candidate['rows'].keys() and len(reference['rows'])==864
for key,row in reference['rows'].items():
 other=candidate['rows'][key];assert row['status']==other['status'],(key,row.get('message'),other.get('message'))
 if row['status']=='error':
  assert row['category']==other['category']=='singular',(key,row,other);singular+=1;continue
 if row['mode']=='jvp':real_cases+=1
 else:complex_cases+=1
 assert {k:v for k,v in row.items() if k not in ['values','error','message']}=={k:v for k,v in other.items() if k not in ['values','error','message']},key
 for field,meta in row['values'].items():
  found=other['values'][field]
  if meta is None:assert found is None,(key,field);none_fields+=1;continue
  assert found is not None,(key,field)
  assert {k:v for k,v in meta.items() if k!='stride'}=={k:v for k,v in found.items() if k!='stride'},(key,field)
  if meta['stride']!=found['stride']:
   assert field in ['stored_a','stored_e'] and meta['shape']==[1,1] and all(v>0 for v in meta['stride']+found['stride']),(key,field,meta,found)
   layouts.append(dict(case=key,field=field,native=meta['stride'],candidate=found['stride']))
  name=key+'.'+field;x=a[name];y=b[name];arrays+=1
  for part,xx,yy in [('real',x.real,y.real),('imag',x.imag,y.imag)] if np.iscomplexobj(x) else [('real',x,y)]:
   for predicate in [np.isnan,np.isposinf,np.isneginf]:np.testing.assert_array_equal(predicate(yy),predicate(xx),err_msg=name+'.'+part)
   finite=np.isfinite(xx)
   if row['shape'][-1]>=8 and xx.ndim>=2:
    for index in np.ndindex(xx.shape[:-2]):
     mask=finite[index];ref=xx[index][mask].astype('float64');value=yy[index][mask].astype('float64');scale=float(np.max(np.abs(ref),initial=0));error=float(np.max(np.abs(ref-value),initial=0));assert error<=(1e-5 if row['dtype'] in ['float32','complex64'] else 3e-12)*scale,(name,part,index,error,scale)
     label=row['dtype']+'.'+field+'.'+part;maximum_scaled_errors[label]=max(maximum_scaled_errors.get(label,0),error/scale if scale else 0)
    normwise.append(name+'.'+part)
   else:np.testing.assert_allclose(yy[finite],xx[finite],rtol=3e-5 if row['dtype'] in ['float32','complex64'] else 3e-12,atol=0,err_msg=name+'.'+part)
assert arrays==2454 and none_fields==2376 and singular==258 and real_cases==528 and complex_cases==78 and len(layouts)==32
mutation_native=json.loads((r/'mutation-layouts-native.json').read_text());mutation_actual=json.loads((r/'mutation-layouts-adapter.json').read_text());assert mutation_native==mutation_actual and len(mutation_actual)==1080
matmul_native=json.loads((r/'matmul-native.json').read_text());matmul_actual=json.loads((r/'matmul-adapter.json').read_text());assert matmul_native==matmul_actual and len(matmul_actual)==105
api_reference=json.loads((r/'api-native.json').read_text());api_actual=json.loads((r/'api-adapter.json').read_text());legacy=0
for native,actual in zip(api_reference['rows'],api_actual['rows']):
 assert actual['status']=='ok',actual
 if native['alias']=='input_keyword':
  assert native['status']=='error';legacy+=1;continue
 assert native['status']=='ok' and native['dtype']==actual['dtype'] and native['shape']==actual['shape'] and native['alias']==actual['alias'] and native['stride']==actual['stride'] and native['dtype_out']==actual['dtype_out']
 if native['value'] is not None:np.testing.assert_allclose(actual['value'],native['value'],rtol=3e-6,atol=0,equal_nan=True)
assert legacy==24 and api_reference['mutations']==api_actual['mutations']
result=dict(status='success',version='0.65.0',source_hashes=expected,cases=864,successful_real_jvp_cases=real_cases,successful_complex_forward_cases=complex_cases,native_singular_rejections=singular,numeric_arrays=arrays,none_fields=none_fields,positive_singleton_stored_layout_qualifications=layouts,normwise_matrix_arrays=normwise,maximum_scaled_errors=maximum_scaled_errors,inverse_mutation_layout_cases=1080,matmul_guard_cases=105,native_alias_cases=96,legacy_input_keyword_cases=24,input_sha256=reference['input_sha256'],driver_sha256=reference['driver_sha256'],native_version=reference['version'],native_git=reference['native_git'],scope='Inverse real JVP and both reverse channels, complex forward, native final-axis strides, empty/singleton/extreme inputs, exact nonfinite masks, native mutation states and legacy input= alias. Matrix components at n>=8 use per-matrix/component max-norm float32/complex64 1e-5 or float64/complex128 3e-12; other finite values use componentwise float32 3e-5 / float64 3e-12, atol=0. No complex AD or output buffers.')
(r/'inverse-qualification.json').write_text(json.dumps(result,indent=2)+'\n');print('Inverse:',arrays,'arrays;',singular,'native singular errors; 1080 mutation/layout cases; 105 matmul guards; 96 native + 24 legacy aliases')
