from pathlib import Path
import hashlib,json,statistics,sys,time,gc
import numpy as np
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r));import bench_inverse as bench
a,ah=bench.common.load('_layout_prototype_a','/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src/stridetorch')
b,bh=bench.common.load('_layout_prototype_b',r/'optimized-inverse-source/stridetorch');rows=[]
for dtype in ['float32','float64']:
 for shape in [(1,1),(2,2),(64,64)]:
  data=bench.common._data(shape,dtype);direction=np.eye(shape[-1],dtype=dtype)*.2
  for operation in ['inverse','inverse_jvp']:
   for backward in [False,True]:
    methods={};captures={}
    for name,module in [('a',a),('b',b)]:methods[name],captures[name]=bench.method(module,data,direction,operation,backward,True)
    bench.compare(captures['b'](),captures['a'](),dtype,2 if operation=='inverse_jvp' else 1);gc.collect();calls=1
    for fn in methods.values():
     count=1
     while True:
      start=time.perf_counter()
      for _ in range(count):fn()
      if time.perf_counter()-start>=.02:break
      count*=2
     calls=max(calls,count)
    times={name:[] for name in methods}
    for repeat in range(3):
     for name in ['a','b'] if repeat%2==0 else ['b','a']:
      start=time.perf_counter()
      for _ in range(calls):methods[name]()
      times[name].append((time.perf_counter()-start)/calls)
    med={name:statistics.median(v) for name,v in times.items()};rows.append(dict(dtype=dtype,shape=shape,operation=operation,backward=backward,calls=calls,samples_s=times,median_us={k:v*1e6 for k,v in med.items()},b_over_a=med['b']/med['a']))
result=dict(scope='Development-only direct API comparison between two same-version prototypes, three alternating >=20ms batches. Not final host-isolated timing.',source_hashes=dict(prototype_a=ah,prototype_b=bh),rows=rows,program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());(r/'layout-optimization-pilot.json').write_text(json.dumps(result,indent=2)+'\n')
print('Layout optimization pilot complete:',len(rows),'paired workflows')
