from pathlib import Path
import json,sys
import numpy as np
if sys.argv[1]=='native':import torch as t
else:from stridetorch import torch as t
def tensor(data,layout):
 if layout=='F':value=t.from_numpy(data.swapaxes(-1,-2).copy()).transpose(-1,-2)
 elif layout=='S':
  backing=np.zeros((*data.shape[:-2],data.shape[-2]*2,data.shape[-1]*2));backing[...,::2,::2]=data;value=t.from_numpy(backing)[...,::2,::2]
 else:value=t.from_numpy(data.copy())
 return value.detach().requires_grad_()
rows=[]
for shape in [(2,2),(2,2,2),(0,0),(2,0,0),(0,2,2),(2,0,1,1),(2,3,1,1)]:
 for a_layout in ['C','F','S']:
  for e_layout in ['C','F','S']:
   data=np.broadcast_to(np.eye(shape[-1])*2,shape).copy();x=tensor(data,a_layout);e=tensor(np.ones(shape),e_layout)
   p,v=t.func.jvp(t.linalg.inv,(x,),(e,));ga,ge=t.autograd.grad(v.sum(),(x,e))
   rows.append(dict(shape=shape,a_layout=a_layout,e_layout=e_layout,strides={name:list(value.stride()) for name,value in [('a',x),('e',e),('p',p),('t',v),('ga',ga),('ge',ge)]}))
r=Path(__file__).resolve().parent;(r/('layouts-'+sys.argv[1]+'.json')).write_text(json.dumps(rows,indent=2)+'\n');print(sys.argv[1],len(rows),'layouts')
