from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');archive=r/'prototype-a';archive.mkdir()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert json.loads((r/'full-root-receipt.json').read_text())['exit_code']==0
assert all(x['exit_code']==0 for x in json.loads((r/'proof/gate-receipts.json').read_text()).values())
assert all(x['exit_code']==0 for x in json.loads((r/'integration-proof/frontend-receipts.json').read_text()))
source=repo/'packages/stridetorch/src/stridetorch';old_source=json.loads((r/'proof/source-hashes.json').read_text())
for name,digest in old_source.items():assert sha(source/name)==digest
with (archive/'export-recheck.log').open('w') as log:subprocess.run([str(r.parent/'torch-iteration-21/stride-dev-env/bin/python'),str(r/'integration-proof/verify-export.py')],cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
for path in list(r.iterdir()):
 if path.is_file() and path.suffix in ['.py','.json','.npz','.log','.txt']:shutil.copy2(path,archive/path.name)
root_snapshot=archive/'root-test-snapshot/tests/test_browser_quadrature.py';root_snapshot.parent.mkdir(parents=True);shutil.copy2(repo/'tests/test_browser_quadrature.py',root_snapshot)
new_assets=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z','--','web/public/data/browser-judge','web/public/data/modules'],cwd=repo).decode().split('\0');new_assets=[name for name in new_assets if name];assert len(new_assets)==158
for name in new_assets:
 path=repo/name;target=archive/'generated'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target);assert sha(path)==sha(target);path.unlink()
for filename in ['index.json','index-v3.json','catalog.json']:
 name='web/public/data/'+filename;path=repo/name;target=archive/'generated'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
 path.write_bytes(subprocess.check_output(['git','show','HEAD:'+name],cwd=repo))
(r/'proof').rename(archive/'proof');(r/'integration-proof').rename(archive/'integration-proof')
candidate=r/'optimized-inverse-source/stridetorch/_linalg.py';text=candidate.read_text()
text=text.replace("    try:value=np.linalg.inv(source.swapaxes(-1,-2)).swapaxes(-1,-2)","    # Transposed factorization exposes native column-major cores directly.\n    try:value=np.linalg.inv(source.swapaxes(-1,-2)).swapaxes(-1,-2)")
text=text.replace("    value=_layout.contiguous_empty(np.ascontiguousarray(value)) if input.shape[-1]==1 else _solve_layout(value,True) if not value.size else value", "    if input.shape[-1]==1:value=_layout.contiguous_empty(np.ascontiguousarray(value))\n    elif not value.size:value=_solve_layout(value,True)")
(source/'_linalg.py').write_text(text)
readme=repo/'packages/stridetorch/README.md';text=readme.read_text().replace('when flattening a layout that cannot be represented by `view`.','when flattening a layout that cannot be represented by `view`. General inverses\nand JVP final products generate transposed output buffers directly, avoiding a\nsecond full-matrix layout copy.');readme.write_text(text)
owned_paths=json.loads((r/'owned-source-paths.json').read_text());assert len(owned_paths)==10
owned={name:sha(repo/name) for name in owned_paths}
subprocess.run(['git','fetch','--no-tags','origin','main'],cwd=repo,check=True,stdout=subprocess.DEVNULL)
before=git('rev-parse','HEAD');after=git('rev-parse','origin/main');paths=git('diff','--name-only',before,after).splitlines()
assert all(name.startswith('web/') and not name.startswith('web/public/') for name in paths) and not set(paths)&owned.keys(),paths
if before!=after:subprocess.run(['git','merge','--ff-only','origin/main'],cwd=repo,check=True,stdout=subprocess.DEVNULL)
for name,digest in owned.items():assert sha(repo/name)==digest
(r/'owned-input-sha256.json').write_text(json.dumps(owned,indent=2)+'\n')
proof=r/'proof';chrome=proof/'chrome-contracts';chrome.mkdir(parents=True)
for name in ['wasm-contracts.mjs','check-wheel.py','check-coinstall.py','chrome-contracts/run.mjs','chrome-contracts/worker.mjs','chrome-contracts/index.html']:
 target=proof/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(archive/'proof'/name,target)
for folder in [proof/'source',chrome/'source']:
 folder.mkdir()
 for path in [*source.glob('*.py'),source/'LICENSE',source/'NOTICE']:shutil.copy2(path,folder/path.name)
tests=chrome/'tests';tests.mkdir()
old_plan=json.loads((archive/'proof/chrome-contracts/plan.json').read_text())
for name in old_plan['tests']:shutil.copy2(repo/'packages/stridetorch/tests'/name,tests/name)
plan=dict(source={p.name:sha(p) for p in (proof/'source').iterdir()},tests={p.name:sha(p) for p in tests.iterdir()},version='0.65.0',expected=7966)
assert len(plan['source'])==61 and len(plan['tests'])==58
for path,data in [(chrome/'plan.json',plan),(proof/'source-hashes.json',plan['source']),(proof/'test-hashes.json',plan['tests']),(r/'inverse-expected-source.json',plan['source']),(r/'jvp-expected-source.json',plan['source'])]:path.write_text(json.dumps(data,indent=2)+'\n')
integration=r/'integration-proof';integration.mkdir()
for name in ['run-export.py','run-frontend.py','verify-export.py']:shutil.copy2(archive/'integration-proof'/name,integration/name)
for name in ['context.json','full-suite-baseline.json']:(integration/name).write_text(json.dumps(dict(upstream=after),indent=2)+'\n')
for name,digest in json.loads((r/'release-policy-identity.json').read_text())['files'].items():assert sha(repo/name)==digest
(r/'layout-optimization-adoption.json').write_text(json.dumps(dict(status='candidate_applied_for_revalidation',prototype_archive=str(archive),before=before,after=after,ui_paths=paths,source_resources=plan['source'],owned_inputs=owned,scope='Prior source/results and 158 generated assets preserved outside Git; only owned untracked generated assets removed. Transposed inverse/product outputs eliminate layout copies. All final-source gates must rerun.'),indent=2)+'\n')
print('Applied optimized layout candidate; previous prototype preserved; final-source validation plans refreshed')
