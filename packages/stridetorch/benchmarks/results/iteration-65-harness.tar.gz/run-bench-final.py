from pathlib import Path
import hashlib,json,os,subprocess,time

r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
py=r.parent/'torch-iteration-21/stride-dev-env/bin/python'
bench=repo/'packages/stridetorch/benchmarks/bench_determinants.py'
plan=json.loads((r/'proof/chrome-contracts/bench-plan.json').read_text())
env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
for name,h in plan['candidate'].items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==h
assert hashlib.sha256(bench.read_bytes()).hexdigest()==plan['benchmark_sha256']
dest=r/'performance';dest.mkdir();receipts=[]
for repeat in range(4):
    for runtime in (['cpu','node','chrome'] if repeat%2==0 else ['chrome','node','cpu']):
        label=f'{runtime}-{repeat}'
        if runtime=='cpu':args=[str(py),str(r/'bench-combined.py'),str(r/'baseline-source/stridetorch'),str(repo/'packages/stridetorch/src/stridetorch')]
        elif runtime=='node':args=['/opt/homebrew/bin/node',str(r/'proof/bench-node.mjs')]
        else:args=['/opt/homebrew/bin/node',str(r/'proof/chrome-contracts/bench-run.mjs')]
        load_before=list(os.getloadavg());started=time.monotonic()
        with (dest/(label+'.log')).open('w') as log:
            child=subprocess.run(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
        receipts.append(dict(label=label,args=args,exit_code=child.returncode,elapsed_s=time.monotonic()-started,host_load_before=load_before,host_load_after=list(os.getloadavg())))
        (dest/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
        print(label,'TERMINAL',child.returncode,flush=True);child.check_returncode()
        if runtime=='cpu':data=json.loads((dest/(label+'.log')).read_text())
        else:
            path=r/('proof/bench-node-result.json' if runtime=='node' else 'proof/chrome-contracts/bench-result.json')
            data=json.loads(path.read_text());assert data['numpy']=='2.2.5'
            assert data['benchmark_sha256']==plan['benchmark_sha256']
        actual=data.get('benchmark',data)
        assert actual['source_hashes']==dict(baseline=plan['baseline'],candidate=plan['candidate'])
        assert len(actual['rows'])==100
        extra=actual['inverse_benchmark'];assert len(extra['rows'])==44 and extra['source_hashes']==actual['source_hashes'] and extra['program_sha256']==plan['inverse_benchmark_sha256']
        (dest/(label+'.json')).write_text(json.dumps(data,indent=2)+'\n')
(dest/'identity.json').write_text(json.dumps(dict(status='success',all_children_terminal=True,children=12,
    source_hashes=dict(baseline=plan['baseline'],candidate=plan['candidate']),benchmark_sha256=plan['benchmark_sha256'],inverse_benchmark_sha256=plan['inverse_benchmark_sha256'],
    thread_caps={k:env[k] for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS']}),indent=2)+'\n')
