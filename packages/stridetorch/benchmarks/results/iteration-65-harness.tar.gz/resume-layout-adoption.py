from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');archive=r/'prototype-a'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
source=repo/'packages/stridetorch/src/stridetorch';owned_paths=json.loads((r/'owned-source-paths.json').read_text());owned={name:sha(repo/name) for name in owned_paths}
assert len(owned)==10 and (archive/'proof').is_dir() and not (r/'proof').exists()
subprocess.run(['git','fetch','--no-tags','origin','main'],cwd=repo,check=True,stdout=subprocess.DEVNULL)
before=git('rev-parse','HEAD');after=git('rev-parse','origin/main');paths=git('diff','--name-only',before,after).splitlines()
assert all((name.startswith('web/') and not name.startswith('web/public/')) or name=='docs/organization-affiliations.md' for name in paths) and not set(paths)&owned.keys(),paths
if before!=after:subprocess.run(['git','merge','--ff-only','origin/main'],cwd=repo,check=True,stdout=subprocess.DEVNULL)
for name,digest in owned.items():assert sha(repo/name)==digest
(r/'owned-input-sha256.json').write_text(json.dumps(owned,indent=2)+'\n')
proof=r/'proof';chrome=proof/'chrome-contracts';chrome.mkdir(parents=True)
for name in ['wasm-contracts.mjs','check-wheel.py','check-coinstall.py','chrome-contracts/run.mjs','chrome-contracts/worker.mjs','chrome-contracts/index.html']:
 target=proof/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(archive/'proof'/name,target)
for folder in [proof/'source',chrome/'source']:
 folder.mkdir()
 for path in [*source.glob('*.py'),source/'LICENSE',source/'NOTICE']:shutil.copy2(path,folder/path.name)
tests=chrome/'tests';tests.mkdir()
old_plan=json.loads((archive/'proof/chrome-contracts/plan.json').read_text())
for name in old_plan['tests']:shutil.copy2(repo/'packages/stridetorch/tests'/name,tests/name)
plan=dict(source={p.name:sha(p) for p in (proof/'source').iterdir()},tests={p.name:sha(p) for p in tests.iterdir()},version='0.65.0',expected=7966)
assert len(plan['source'])==61 and len(plan['tests'])==58
for path,data in [(chrome/'plan.json',plan),(proof/'source-hashes.json',plan['source']),(proof/'test-hashes.json',plan['tests']),(r/'inverse-expected-source.json',plan['source']),(r/'jvp-expected-source.json',plan['source'])]:path.write_text(json.dumps(data,indent=2)+'\n')
integration=r/'integration-proof';integration.mkdir()
for name in ['run-export.py','run-frontend.py','verify-export.py']:shutil.copy2(archive/'integration-proof'/name,integration/name)
for name in ['context.json','full-suite-baseline.json']:(integration/name).write_text(json.dumps(dict(upstream=after),indent=2)+'\n')
for name,digest in json.loads((r/'release-policy-identity.json').read_text())['files'].items():assert sha(repo/name)==digest
(r/'layout-optimization-adoption.json').write_text(json.dumps(dict(status='candidate_applied_for_revalidation',prototype_archive=str(archive),before=before,after=after,ui_paths=paths,source_resources=plan['source'],owned_inputs=owned,scope='Prior source/results and 158 generated assets preserved outside Git; only owned untracked generated assets removed. Transposed inverse/product outputs eliminate layout copies. All final-source gates must rerun.'),indent=2)+'\n')
print('Applied optimized layout candidate; previous prototype preserved; final-source validation plans refreshed')
