from pathlib import Path
import json,sys
import numpy as np
if sys.argv[1]=='native':import torch as t
else:from stridetorch import torch as t
r=Path(__file__).resolve().parent;rows=[]
for dtype in ['float32','float64']:
 d=np.dtype(dtype);f=np.finfo(d)
 cases={'regular':[[2.,.3],[.4,3.]],'negative':[[-2.,-.3],[.4,3.]],'rank_one':[[1.,2.],[2.,4.]],'diagonal_zero':[[0.,0.],[0.,2.]],'zero':[[0.,0.],[0.,0.]],'empty':np.empty((0,0)), 'empty_batch':np.empty((0,2,2))}
 for name,a in [('zero',0.),('negative_zero',-0.),('one',1.),('maximum',f.max),('tiny',f.tiny),('subnormal',np.nextafter(d.type(0),d.type(1)))]:cases['scalar_'+name]=[[a]]
 for name,data in cases.items():
  for layout in ['C','F']:
   a=np.array(data,dtype=d);e=np.arange(a.size,dtype=d).reshape(a.shape)*d.type(.1)+d.type(1)
   def tensor(data):
    x=t.from_numpy(data.swapaxes(-1,-2).copy()).transpose(-1,-2) if layout=='F' else t.from_numpy(data.copy())
    return x.detach().requires_grad_()
   x=tensor(a);direction=tensor(e);row=dict(dtype=dtype,case=name,layout=layout)
   try:
    p,v=t.func.jvp(t.linalg.inv,(x,),(direction,));ga,ge=t.autograd.grad(v.sum(),(x,direction),allow_unused=True)
    row.update(status='ok',primal=p.detach().numpy().tolist(),tangent=v.detach().numpy().tolist(),gradient_a=None if ga is None else ga.detach().numpy().tolist(),gradient_e=None if ge is None else ge.detach().numpy().tolist(),strides=dict(primal=p.stride(),tangent=v.stride(),ga=None if ga is None else ga.stride(),ge=None if ge is None else ge.stride()))
   except Exception as error:row.update(status='error',error=type(error).__name__,message=str(error)[:160])
   rows.append(row)
(r/('probe-'+sys.argv[1]+'.json')).write_text(json.dumps(rows,indent=2)+'\n')
print(sys.argv[1],len(rows),'cases;',sum(x['status']=='error' for x in rows),'errors')
for row in rows:
 if row['dtype']=='float64' and row['layout']=='C':print({k:row.get(k) for k in ['case','primal','tangent','gradient_a','gradient_e','error']})
