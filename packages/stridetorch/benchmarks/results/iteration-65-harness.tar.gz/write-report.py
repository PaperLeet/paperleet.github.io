from pathlib import Path
import json

r=Path(__file__).resolve().parent
repo=Path('/Users/david/Developer/PaperLeet-torch-release')
j=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-65.json').read_text())

def table(rows):
    text='| Runtime | Operation | Dtype | Shape | Mode | Candidate / comparator | Four-child range |\n|---|---|---|---|---|---:|---:|\n'
    for row in rows:
        ratio=row['ratio_median']; span=row['ratio_range']
        ratio_text='—' if ratio is None else f'{ratio:.3f}'
        span_text='—' if span is None else f'{span[0]:.3f}–{span[1]:.3f}'
        text+=f"| {row['runtime']} | {row['operation']} | {row['dtype']} | {row['input_shape']} | {row['mode']} | {ratio_text} | {span_text} |\n"
    return text

old=j['performance']['rows']; extra=j['inverse_performance']['rows']
worst_old=sorted(old,key=lambda row:row['ratio_median'],reverse=True)[:10]
inverse_steps=[row for row in extra if row['operation']=='inverse' and row['matched'] and row['mode']=='full_step']
jvp_steps=[row for row in extra if row['operation']=='inverse_jvp' and row['mode']=='full_step']
worst_extra=sorted([row for row in extra if row['matched']],key=lambda row:row['ratio_median'],reverse=True)[:10]
complex_rows=[row for row in extra if not row['matched']]
complex_table='| Runtime | Dtype | Shape | Candidate median µs |\n|---|---|---|---:|\n'
for row in complex_rows:complex_table+=f"| {row['runtime']} | {row['dtype']} | {row['input_shape']} | {row['candidate_median_us']:.2f} |\n"
allocation='| Operation | Dtype | Shape | Prior retained / peak | New retained / peak | Prior / new backward peak |\n|---|---|---|---:|---:|---:|\n'
memory=j['inverse_memory']
for old_m,new_m in zip(memory['rows'][::2],memory['rows'][1::2]):
    assert old_m['variant']=='baseline' and new_m['variant']=='candidate'
    allocation+=f"| {old_m['operation']} | {old_m['dtype']} | {old_m['input_shape']} | {old_m['new_retained_bytes']:,} / {old_m['forward_peak_bytes']:,} | {new_m['new_retained_bytes']:,} / {new_m['forward_peak_bytes']:,} | {old_m['backward_peak_bytes']:,} / {new_m['backward_peak_bytes']:,} |\n"
stages=j['ui_qualification_stages']
ui='; '.join(f"{len(s['checks'])} affected checks plus driver/policy/two builds at `{s['upstream']}`" for s in stages) if stages else 'No later UI sync was required.'
archive=j['raw_archive']
text=f'''# Torch runtime iteration 65 — inverse APIs and saved-value guards

Version **0.65.0** adds `torch.inverse`, `Tensor.inverse()`, native-style
`torch.linalg.inv(A=...)`, real inverse forward AD and complex inverse forward
calculation. Existing `torch.linalg.inv(input=...)` calls remain supported.
Final integration baseline is `{j['baseline_main']}`; full CPU/frontend/catalog
validation baseline is `{j['full_validation_baseline']}`. {ui}

## Behavior and numerical scope

Real float32/64 inverse supports ordinary reverse AD and `torch.func.jvp`.
Complex64/128 supports forward calculation; the existing constructor boundary
continues to reject complex AD. Singular matrices raise `RuntimeError`.
Nonfinite matrix inputs and `out` buffers remain unsupported. Empty matrices,
empty batches, C/F/sliced inputs, mixed batches and finite extreme values are
covered. Directions and reverse seeds retain the separately tested IEEE rules.

Inverse outputs now have native column-major final axes instead of the previous
row-major result. Singleton inverses use a dtype-preserving reciprocal, with an
explicit zero check, avoiding observed complex LAPACK overflow/subnormal errors.
For larger matrices, inversion of the transposed input exposes the desired
transposed output buffer directly. The final JVP product similarly creates its
column-major result without a second full-matrix layout copy.

The native reference is **PyTorch 2.14.1**, git
`5c4886908584029761b579af026dcfb627c84070`. Its
[pinned inverse differentiation rules](https://github.com/pytorch/pytorch/blob/5c4886908584029761b579af026dcfb627c84070/tools/autograd/derivatives.yaml#L831)
specify a right-associated inverse VJP and a JVP with two matrix products.
The implementation preserves these associations and saves the computed inverse
for reverse propagation instead of recomputing a factorization. This is a
first-order compatibility target, including the tested reverse paths through
the JVP; arbitrary higher derivatives are not promised.

The original input is not retained for inverse backward. Its later mutation is
allowed; mutation of the saved inverse is guarded. A direction whose feature
strides differ from the primal is copied when the primal reverse path needs it,
following measured native forward-AD behavior. Otherwise the needed direction
storage is guarded. The returned primal is a separate metadata alias, so its
hook and retained gradient do not intercept the tangent's private inverse path.
Independent edges let the graph engine prune unrequested reverse branches.

Matrix multiplication also stops guarding outputs and operands that its active
derivatives never read. It still guards each saved operand needed by an active
derivative, including shared operands. Of 105 native guard controls, the prior
version falsely rejected 55 permitted mutation cases; the new version matches
all 105. These are observable compatibility fixes as well as graph improvements.

## Verification

- **41,596 CPU tests pass, 1 skip** with exact source hashes checked before and
  after the run. **343 new SDK tests** include independent scalar/2×2 derivative
  formulas, aliases, both reverse paths, layouts, dtype extremes, mutations,
  NumPy error policy, hooks, saved-source lifetime and shared operands.
- **7,966 contracts / 58 suites** pass independently on Node/Pyodide and Chrome
  Worker. The isolated Python 3.10.19 / NumPy 1.26.4 installed wheel passes
  **7,979 tests**, with native Torch absent.
- The inverse frozen corpus has **96 input groups / 224 arrays**, expanded to
  **864 contexts**: 528 successful real JVP cases, 78 successful complex forwards
  and 258 native singular rejections. It compares **2,454 numerical arrays** and
  **2,376 None-gradient/hook fields** on CPU, Node, Chrome and the minimum wheel.
- Another **1,080 mutation/layout cases**, **105 matmul guard cases** and **120
  API calls** pass on all four environments. The API set separates 96 native
  canonical successes from 24 intentionally preserved legacy `input=` calls.
- IEEE NaN/+Inf/-Inf masks, dtype and geometry are exact. Matrices of size >=8
  use per-matrix/component max-norm bounds of `1e-5` for float32/complex64 and
  `3e-12` for float64/complex128. Smaller finite values use componentwise
  `rtol=3e-5` or `3e-12`, `atol=0`. The 32 equivalent positive singleton
  stored-gradient layouts follow the existing owned-buffer contract; raw and
  meaningful nonsingleton strides remain exact.
- The prior **600 determinant/log**, **398 singleton** and **696 determinant
  JVP** controls remain passing on all four environments. Native, legacy
  singular cofactor and unsupported-input expectations remain separately named.
- One old root test expected complex inverse rejection. It now checks complex
  forward values and column-major strides against native Torch and retains
  singular/shape/out and complex-AD-boundary checks. The initial failed run is
  preserved; the final full suite passes.
- Public wheel/sdist, vendored wheel, coinstallation/uninstall isolation,
  native-Torch alias restoration and fresh-process serialization pass. Both
  package forms contain the same 59 Python modules and LICENSE/NOTICE files.
- All **78 exported modules and 342 mutants** pass the original browser budgets,
  with all 58 SDK suites embedded. The **1,152 native catalog input hashes** and
  **13,231 prior immutable payloads** are unchanged. This iteration adds 158
  reachable assets and records 161 active export/index hashes.
- Full frontend checks and both build profiles pass. All 18 public/fixture
  runtime assets, 13 lock-pinned package wheels and five Node core identities
  are revalidated. Pyodide is 0.29.4 / NumPy 2.2.5; development CPU uses Python
  3.12.11 / NumPy 2.5.4 on Apple M4 arm64. Exact host metadata is archived.
- Seven release-policy files remain byte-identical to canonical
  `13d2782a494415ba72bc604a0ef7e4c4f875ba25`. No CI trigger, tag, workflow dispatch,
  release, package upload or deployment is initiated.

## Performance against actual 0.64

Twelve fresh children, four each CPU/Node/Chrome, alternate runtime order and
run five alternating common calibrated batches of at least 20 ms. Supported
CPU thread caps are two. Owned correctness/build jobs finish before formal
timing; per-child host load averages are retained. This is host measurement
without machine-wide isolation, and unrelated host work may run concurrently.

The original regression program has **100 matched actual 0.64 API workflows
per child** (1,200 results / 300 aggregates): real/complex determinant and log
forward, weighted reverse and graph controls. The largest median ratios,
including losses, are:

{table(worst_old)}
An additional **44 workflows per child** (528 results / 132 aggregates) comprise
16 actual prior real-inverse workflows, eight actual matmul controls, 16 new
inverse JVPs versus explicit old-API composition, and four candidate-only complex
inverse forwards. All samples and losses are retained. Ratios below one mean
less measured time. Existing inverse full steps:

{table(inverse_steps)}
The prior version has no inverse JVP API. Its explicit comparator is
`P=inv(A); -(P @ E @ P)` on finite nonsingular inputs. Value and weighted
matrix/direction reverse gradients are checked, while alias/hook/layout/copy
semantics are qualified separately against native controls. JVP full steps:

{table(jvp_steps)}
The largest additional matched median ratios, including forward-only losses:

{table(worst_extra)}
Complex forwards have no prior supported API and therefore have no speedup ratio:

{complex_table}
Inputs/directions/weights precede timing. Dispatch, transform, graph construction,
kernels, optional weighted backward, clearing and result destruction are timed.
No native-Torch, GPU, cold-start or universal speedup claim is made.

The four-child medians show a mixed result. WASM singleton/small inverse JVP
full steps take about 4–11% less time than the old composition. Larger/batched
WASM JVP full steps take about 7–10% more time. CPU larger float64 JVP improves
about 4%, while float32 is about 4% slower. Actual ordinary inverse CPU full
steps at sizes >=2 cost about 3–7% more; the corresponding WASM costs are about
0–3%. These native layout/guard/API corrections are adopted with their measured
costs, not described as a universal performance improvement. The largest median
regression among the 100 prior determinant/log/graph workflows is about 2.3%.
A subsequent optimization candidate is sharing the repeated upstream-gradient
matrix product between the inverse JVP reverse branches via `joint_result`;
that candidate is not implemented or measured in this version.

## Allocations, prototypes and reproduction

The 24 prior determinant/log allocation diagnostics retain separate warm and
cold-first results. Sixteen additional CPU tracemalloc rows record warm inverse
forward retained/peak bytes and a separately traced weighted-backward peak.
Inputs/directions/weights predate tracing; C inputs need no direction copy.
These are incremental tracked allocations, not total tape bytes, process RSS,
LAPACK workspace or WASM heap. New native layout and saved-value semantics differ
from the old composition, so time and allocation results must be assessed together.

{allocation}
In these warm CPU diagnostics, ordinary inverse allocations are nearly unchanged.
JVP backward peaks are about 1–2% lower, but batched JVP retained bytes increase
about 27–30%; the float64 batch forward peak increases about 21%. The retained
intermediate and corrected layout semantics have measurable costs. No universal
memory saving is claimed.

The earlier layout-copy prototype's full tests, initial root-test failure,
packages, generated assets and source snapshots remain in `prototype-a` inside
the harness. Its isolated 24-flow A/B layout pilot is development evidence only.
The final source was frozen again and every final-source gate rerun after the
copy-elimination change; the formal timing above uses those exact source hashes.
The initial adoption helper stopped safely on newly advanced affiliation docs;
the reviewed disjoint UI/docs were subsequently fast-forwarded before final
full tests. Setup-failure logs and the resumed transition are retained.

[Machine report](../../packages/stridetorch/benchmarks/results/iteration-65.json)
and [raw harness](../../packages/stridetorch/benchmarks/results/iteration-65-harness.tar.gz)
contain source/test snapshots, frozen native values/inputs, programs, failed
pilots, package artifacts, receipts and every sample. Archive: {archive['bytes']:,}
bytes; SHA-256 `{archive['sha256']}`.

CPU/WASM is the only backend changed this iteration. Prior WebGPU prototype and
design evidence remains separate; no new GPU performance is claimed here.
The wider independent-library/core-coverage/backend objective remains active.
'''
(repo/'docs/validation/torch-runtime-iteration-65.md').write_text(text)
print('Wrote iteration-65 validation report')
