from pathlib import Path
import datetime,hashlib,json,subprocess

r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
def command(*args):return subprocess.check_output(args,cwd=repo,text=True).strip()
identity=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-65-main-adoption.json').read_text())
source=identity['source_commit'];proof=command('git','rev-parse','HEAD')
assert command('gh','api','repos/PaperLeet/paperleet.github.io/git/ref/heads/main','--jq','.object.sha')==proof
assert not command('git','status','--porcelain') and command('git','rev-parse','HEAD^')==source
resources=json.loads((r/'proof/source-hashes.json').read_text());exports=json.loads((r/'integration-proof/live-expected-sha256.json').read_text())
policy=json.loads((r/'release-policy-identity.json').read_text())
for name,h in resources.items():
    path='packages/stridetorch/src/stridetorch/'+name
    assert hashlib.sha256((repo/path).read_bytes()).hexdigest()==h
    assert hashlib.sha256(subprocess.check_output(['git','show',source+':'+path],cwd=repo)).hexdigest()==h
for name,h in exports.items():assert hashlib.sha256((repo/'web/public/data'/name).read_bytes()).hexdigest()==h
for name,h in policy['files'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==h
immutable=len(subprocess.check_output(['git','ls-files','-z','--','web/public/data/browser-judge','web/public/data/modules'],cwd=repo).split(b'\0'))-1
assert immutable==13389 and len(resources)==61 and len(exports)==161 and len(policy['files'])==7
counts={}
for head in [source,proof]:
    data=json.loads(command('gh','api',f'repos/PaperLeet/paperleet.github.io/actions/runs?head_sha={head}&per_page=100'))
    assert data['total_count']==0;counts[head]=0
assert command('git','diff','--name-only',source,proof).splitlines()==[
    'docs/validation/torch-runtime-iteration-65.md','packages/stridetorch/benchmarks/results/iteration-65-main-adoption.json']
assert identity['source_resources']==resources and identity['active_export_sha256']==exports
report=dict(status='adopted_on_main',version='0.65.0',source_commit=source,proof_commit=proof,observed_remote_main=proof,
    observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actions_runs_by_sha=counts,
    source_resources=61,active_export_identities=161,immutable_payloads=immutable,canonical_release_policies=7,
    clean_worktree=True,all_owned_children_terminal=True,
    scope='Final source/proof/main identity; no tag,dispatch,release,upload or deployment initiated. Overall independent-library efficiency/core-coverage/backend goal remains active.')
(r/'final-adoption-verification.json').write_text(json.dumps(report,indent=2)+'\n')
state=json.loads((r/'state.json').read_text());state.update(report,main_adoption_pending=False)
(r/'state.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(report),flush=True)
