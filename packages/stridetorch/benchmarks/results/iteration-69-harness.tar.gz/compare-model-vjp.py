from pathlib import Path
import json,hashlib
import numpy as np
r=Path(__file__).resolve().parent;native=json.loads((r/'model-native.json').read_text());candidate=json.loads((r/'model-candidate.json').read_text());assert native['program_sha256']==candidate['program_sha256'] and len(native['rows'])==len(candidate['rows'])==368
failures=[];max_error=0.
def compare(a,b,path,dtype):
 global max_error
 assert a.keys()==b.keys(),path
 if a['kind']=='tensor':
  for key in ['dtype','shape','requires_grad']:assert a[key]==b[key],(path,key,a[key],b[key])
  x=np.asarray(a['values'],dtype=np.float64);y=np.asarray(b['values'],dtype=np.float64);assert x.shape==y.shape
  if x.size:max_error=max(max_error,float(np.max(np.abs(x-y))))
  np.testing.assert_allclose(y,x,rtol=8e-5 if dtype=='float32' else 2e-9,atol=1e-5 if dtype=='float32' else 1e-10,err_msg=path)
 else:
  assert len(a['items'])==len(b['items'])
  for i,(x,y) in enumerate(zip(a['items'],b['items'])):compare(x,y,path+'/'+str(i),dtype)
for a,b in zip(native['rows'],candidate['rows']):
 assert a['id']==b['id']
 try:
  assert a['success']==b['success'],(a.get('error_type'),b.get('error_type'),b.get('message'))
  if a['success']:
   compare(a['output'],b['output'],a['id']+'/output',a['dtype']);compare(a['gradient'],b['gradient'],a['id']+'/gradient',a['dtype'])
   for key in ['caller_state_preserved','output_input_aliases','output_output_aliases']:assert a[key]==b[key],(key,a[key],b[key])
  else:assert a['error_type']==b['error_type'],(a['error_type'],b['error_type'])
 except Exception as error:failures.append(dict(id=a['id'],message=str(error)[:2000],native_success=a['success'],candidate_success=b['success'],candidate_stage=b.get('stage'),candidate_error=b.get('error_type')))
report=dict(status='passed' if not failures else 'failed',cases=len(native['rows']),native_success=sum(v['success'] for v in native['rows']),failures=failures,max_abs_difference=max_error,native_torch=native['version'],native_git=native['torch_git'],source_hashes=json.loads((r/'guarded-candidate-source-hashes.json').read_text()),input_hashes={name:hashlib.sha256((r/name).read_bytes()).hexdigest() for name in ['model-native.json','model-candidate.json','probe-model-vjp.py']})
(r/'model-qualification.json').write_text(json.dumps(report,indent=2)+'\n');print('cases',report['cases'],'failures',len(failures),'max_abs_difference',max_error)
for f in failures[:14]:print(f['id'],f['message'][:400])
raise SystemExit(1 if failures else 0)
