import importlib,pickle,sys,types
from pathlib import Path

name=sys.argv[1]
assert name not in sys.modules and name+'._api' not in sys.modules
host=types.ModuleType('torch');sys.modules['torch']=host
model=pickle.loads(Path(sys.argv[2]).read_bytes())
m=importlib.import_module(name)
assert model.activation is m.torch.sin and sys.modules['torch'] is host
x=m.torch.ones(3,1,4,requires_grad=True)
y,j=m.torch.func.jvp(model,(x,),(m.torch.ones_like(x),))
(y.square().sum()+j.square().sum()).backward()
assert x.grad is not None and sys.modules['torch'] is host
print('PASS lazy fresh-process restore',name,m.__version__)

assert model.vjp_operator is m.torch.autograd.functional.vjp
value=m.torch.tensor([2.,3.],requires_grad=True)
primal,derivative=model.vjp_operator(lambda a:a.square().sum(),value)
assert primal.item()==13 and derivative.tolist()==[4.,6.] and value.grad is None
assert sys.modules['torch'] is host
print('PASS lazy functional VJP operator restore',name)
