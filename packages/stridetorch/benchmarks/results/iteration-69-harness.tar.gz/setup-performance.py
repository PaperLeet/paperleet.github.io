from pathlib import Path
import shutil,json,hashlib
r=Path(__file__).resolve().parent;p=r/'performance';assets=p/'assets';repo=Path('/Users/david/Developer/PaperLeet-torch-release');sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
for label,source in [('baseline',repo/'packages/stridetorch/src/stridetorch'),('candidate',r/'versioned-release/snapshot/packages/stridetorch/src/stridetorch')]:shutil.copytree(source,assets/label/'stridetorch',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
hashes={label:{q.name:sha(q) for q in (assets/label/'stridetorch').iterdir() if q.suffix=='.py' or q.name in ['LICENSE','NOTICE']} for label in ['baseline','candidate']};hashes['duplicate']=hashes['baseline'];plan=dict(source_hashes=hashes,programs={'bench_vjp.py':sha(assets/'bench_vjp.py')});(assets/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');(assets/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>Matched VJP and legacy benchmarks</title>')
code="""import sys,json,pathlib,hashlib
sys.path.insert(0,'/')
plan=json.loads(plan_json)
for name,digest in plan['programs'].items():assert hashlib.sha256(pathlib.Path('/'+name).read_bytes()).hexdigest()==digest
from bench_vjp import run
result=run('/baseline/stridetorch','/candidate/stridetorch',cycle)
assert result['source_hashes']==plan['source_hashes']
json.dumps(result)"""
old=r.parent/'torch-iteration-68/performance';node=(old/'bench-node.mjs').read_text();node=node[:node.index('const code=`')]+"py.globals.set('cycle',Number(process.env.CYCLE));\nconst code="+json.dumps(code)+";\nconst result=JSON.parse(py.runPython(code));assert.equal(result.rows.length,9);assert.equal(result.numpy,'2.2.5');fs.writeFileSync(process.argv[2],JSON.stringify({runtime:'node',pyodide:py.version,benchmark:result},null,2)+'\\n');\n";(p/'bench-node.mjs').write_text(node)
worker=(old/'assets/worker.mjs').read_text();prefix=worker[:worker.index('const result=JSON.parse')];prefix=prefix.replace('async()=>','async({data})=>').replace("py.globals.set('plan_json',JSON.stringify(plan));","py.globals.set('plan_json',JSON.stringify(plan));py.globals.set('cycle',data.cycle);")
(assets/'worker.mjs').write_text(prefix+'const result=JSON.parse(py.runPython('+json.dumps(code)+"));self.postMessage({runtime:'chrome',pyodide:py.version,benchmark:result});\n}catch(error){self.postMessage({error:String(error.stack||error)});}};\n")
chrome=(old/'bench-chrome.mjs').read_text().replace('torch-iteration-68/performance/','torch-iteration-69/performance/').replace('page.evaluate(()=>new Promise','page.evaluate((cycle)=>new Promise').replace('worker.postMessage({});}));','worker.postMessage({cycle});}),Number(process.env.CYCLE));').replace('result.benchmark.rows.length,30','result.benchmark.rows.length,9');(p/'bench-chrome.mjs').write_text(chrome)
print('Prepared actual0.68/0.69 source identities for9-workflow CPU/Node/Chrome A/A/B timing.')
