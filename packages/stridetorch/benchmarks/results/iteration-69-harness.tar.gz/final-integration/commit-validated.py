"""Commit only payloads backed by the completed local gates; never push here."""
from pathlib import Path
import hashlib, json, subprocess

p = Path(__file__).resolve().parent
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
read = lambda q: json.loads(q.read_text())
sha = lambda q: hashlib.sha256(q.read_bytes()).hexdigest()
local = read(p / 'local-validation.json')
report = read(repo / 'packages/stridetorch/benchmarks/results/iteration-69.json')
assert local['status'] == 'passed' and report['status'] == 'validated_locally'
assert local['source_hashes'] == report['source_hashes']
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert head == local['upstream']
owned = read(p / 'owned-input-sha256.json')
assets = read(p / 'new-assets-sha256.json')
expected = {**owned, **assets}
expected.update({'web/public/data/' + name: digest for name, digest in
    read(p / 'live-export-sha256.json').items() if name in ['index.json', 'index-v3.json', 'catalog.json']})
for name in ['docs/validation/torch-runtime-iteration-69.md',
             'packages/stridetorch/benchmarks/results/iteration-69.json',
             'packages/stridetorch/benchmarks/results/iteration-69-harness.tar.gz']:
    expected[name] = sha(repo / name)
assert expected['packages/stridetorch/benchmarks/results/iteration-69-harness.tar.gz'] == report['raw_archive']['sha256']
for name, digest in expected.items():
    assert sha(repo / name) == digest, name
rows = subprocess.check_output(['git', 'status', '--porcelain', '-z'], cwd=repo).decode().split('\0')
actual = {row[3:] for row in rows if row}
assert actual == set(expected), (actual - set(expected), set(expected) - actual)
pathspec = p / 'source-commit-pathspec.bin'
pathspec.write_bytes(b''.join(name.encode() + b'\0' for name in sorted(expected)))
subprocess.run(['git', 'add', '--pathspec-from-file=' + str(pathspec), '--pathspec-file-nul'], cwd=repo, check=True)
staged = set(subprocess.check_output(['git', 'diff', '--cached', '--name-only', '-z'], cwd=repo).decode().split('\0')) - {''}
assert staged == set(expected)
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=repo, check=True)
subprocess.run(['git', 'commit', '-m', 'feat(torch): add isolated first-order functional VJP'], cwd=repo, check=True)
after = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain', '-z'], cwd=repo)
record = dict(source_commit=after, parent=head, changed_paths=expected, main_adopted=False,
              ci_triggered=False, scope='Exact validated source/tests/exports/report/archive committed locally; no push or release.')
(p / 'own-commits.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(dict(source_commit=after, paths=len(expected), pushed=False)), flush=True)
