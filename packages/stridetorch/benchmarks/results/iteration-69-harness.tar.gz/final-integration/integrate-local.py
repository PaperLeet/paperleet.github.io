"""Adopt the qualified 0.69 snapshot locally and test the current application."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess, time

p = Path(__file__).resolve().parent
r = p.parent
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
python = r / 'integration-dev-env/bin/python'
read = lambda q: json.loads(q.read_text())
sha = lambda q: hashlib.sha256(q.read_bytes()).hexdigest()
def save(name, data):
    (p / name).write_text(json.dumps(data, indent=2) + '\n')
def sources(q):
    return {f.name: sha(f) for f in q.iterdir() if f.suffix == '.py' or f.name in ['LICENSE', 'NOTICE']}

candidate = read(r / 'versioned-release/package-proof/source-hashes.json')
baseline = read(r / 'baseline-source-hashes.json')
performance = read(r / 'performance-selected/summary.json')
review = read(p / 'performance-reviewed.json')
assert performance['status'] == 'completed' and performance['fresh_children'] == 18
assert performance['source_hashes'] == dict(baseline=baseline, candidate=candidate, duplicate=baseline)
assert review['performance_sha256'] == sha(r / 'performance-selected/summary.json')
assert review['proceed_local_validation']
assert not subprocess.check_output(['git', 'status', '--porcelain', '-z'], cwd=repo)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
target = repo / 'packages/stridetorch'
snapshot = r / 'versioned-release/snapshot/packages/stridetorch'
assert sources(target / 'src/stridetorch') == baseline
assert sources(snapshot / 'src/stridetorch') == candidate
package = read(r / 'versioned-release/package-proof/package-identity.json')
assert package['status'] == 'success' and package['source_hashes'] == candidate
assert package['standalone_installed_tests'] == 8178
for name in ['source-wasm.json', 'chrome-contracts/result.json']:
    proof = read(r / 'versioned-release/wasm-proof' / name)
    assert proof['source_hashes'] == candidate and proof['passed'] == 8165

catalog_modules = len(read(repo / 'web/public/data/index.json')['problems'])
immutable = {str(f.relative_to(repo)): sha(f) for directory in ['browser-judge', 'modules']
             for f in (repo / 'web/public/data' / directory).glob('*.json')}
save('baseline-immutable-sha256.json', immutable)
inputs = {str(f.relative_to(repo)): sha(f) for directory in ['paperleet', 'tests', 'problems', 'scripts']
          for f in (repo / directory).rglob('*') if f.is_file() and '__pycache__' not in f.parts}
for name in ['pyproject.toml', 'papers.yaml']:
    inputs[name] = sha(repo / name)
save('application-input-sha256.json', inputs)
frontend = {str(f.relative_to(repo)): sha(f) for directory in ['web/src', 'web/scripts']
            for f in (repo / directory).rglob('*') if f.is_file()}
frontend.update({str(f.relative_to(repo)): sha(f) for f in (repo / 'web').iterdir()
                 if f.is_file() and f.suffix in ['.json', '.ts', '.js', '.mjs']})
save('frontend-input-sha256.json', frontend)
policy_names = ['.github/workflows/ci.yml', '.github/workflows/pages.yml',
                'web/scripts/check-release-request.cjs', 'web/scripts/pages-release-gate.cjs',
                'web/scripts/check-pages-release.cjs', 'web/scripts/check-pages-backfill.cjs', 'docs/releasing.md']
policy = {name: sha(repo / name) for name in policy_names}
for name, digest in policy.items():
    assert hashlib.sha256(subprocess.check_output(['git', 'show',
        '4db2b71b8948eb4fe8156fc80a97461431c412d8:' + name], cwd=repo)).hexdigest() == digest
save('release-policy-identity.json', dict(files=policy,
    workflows={str(f.relative_to(repo)): sha(f) for f in (repo / '.github/workflows').glob('*')}))
save('context.json', dict(upstream=head, catalog_modules=catalog_modules, preserved_assets=len(immutable)))
save('source-hashes.json', candidate)
save('baseline-source-sha256.json', baseline)

owned = []
for source in snapshot.rglob('*'):
    if not source.is_file() or '__pycache__' in source.parts:
        continue
    if not (source.suffix == '.py' or source.name in ['pyproject.toml', 'README.md', 'LICENSE', 'NOTICE']):
        continue
    dest = target / source.relative_to(snapshot)
    if not dest.exists() or sha(source) != sha(dest):
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, dest)
        owned.append(str(dest.relative_to(repo)))
assert len(owned) == 12
assert sources(target / 'src/stridetorch') == candidate
save('owned-input-sha256.json', {name: sha(repo / name) for name in owned})
save('test-hashes.json', {f.name: sha(f) for f in (target / 'tests').glob('test_*.py')})

env = dict(os.environ, PYTHON=str(python), PYTHONDONTWRITEBYTECODE='1',
           PYTHONPATH=os.pathsep.join([str(target / 'src'), str(repo)]),
           OMP_NUM_THREADS='2', MKL_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', VECLIB_MAXIMUM_THREADS='2')
env['PATH'] = '/Users/david/.npm/_npx/d18f28baf1132559/node_modules/node/bin:/opt/homebrew/bin:' + str(python.parent) + ':' + env['PATH']
assert subprocess.check_output(['node', '--version'], env=env, text=True).strip() == 'v22.23.3'
receipts = []
def run(label, args, cwd=repo, extra=None):
    started = time.monotonic()
    with (p / (label + '.log')).open('w') as log:
        child = subprocess.run(args, cwd=cwd, env={**env, **(extra or {})}, stdout=log, stderr=subprocess.STDOUT)
    receipt = dict(label=label, exit_code=child.returncode, seconds=time.monotonic()-started,
                   args=args, cwd=str(cwd), log_sha256=sha(p / (label + '.log')),
                   summary=(p / (label + '.log')).read_text().splitlines()[-1:])
    receipts.append(receipt)
    save('receipts.json', receipts)
    child.check_returncode()
    assert sources(target / 'src/stridetorch') == candidate
    print(label, 'TERMINAL0', receipt['summary'], flush=True)
    return receipt

run('editable-environment', ['/Users/david/.local/bin/uv', 'pip', 'install', '--python', str(python),
    '--no-deps', '-e', str(repo), '-e', str(target)])
run('export', [str(python), '-m', 'paperleet.cli', 'export'])
run('verify-export', [str(python), str(p / 'verify-export.py')])
cpu = run('cpu', [str(python), '-m', 'pytest', 'tests', 'packages/stridetorch/tests', '-q',
    '-p', 'no:cacheprovider', '--basetemp', str(p / 'pytest-tmp')])
save('cpu-receipt.json', dict(**cpu, source_hashes=candidate))
run('wasm', ['node', 'web/scripts/check-browser-wasm.mjs', '--all'])
wasm = read(repo / 'reports/browser-wasm.json')
assert wasm['passed'] and wasm['catalog_modules'] == wasm['modules'] == catalog_modules
assert len(wasm['results']) == catalog_modules and not wasm['browser_budget_exceeded']
assert all(v['passed'] and not v['browser_budget_exceeded'] for v in wasm['results'])
save('full-wasm-result.json', wasm)
run('full-frontend-check', ['npm', 'run', 'check'], repo / 'web')
run('wasm-driver', ['node', 'web/scripts/check-wasm-cases.mjs'])
run('pages-policy', ['node', 'web/scripts/check-pages-release.cjs'])
run('build', ['npm', 'run', 'build'], repo / 'web')
value = subprocess.check_output(['gh', 'api', 'repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED', '--jq', '.value'], cwd=repo, text=True).strip()
assert value in ['0', '1']
profile = dict(PAPERLEET_MAIN_SITE_ENABLED=value, VITE_PUBLIC_SITE='0' if value == '1' else '1',
    VITE_APP_EDITION='hosted' if value == '1' else 'local',
    VITE_API_ORIGIN='https://app.paperleet.com' if value == '1' else '',
    VITE_HOSTED_APP_AVAILABLE='1', VITE_HOSTED_APP_URL='https://app.paperleet.com')
save('current-pages-profile.json', profile)
run('pages-profile-build', ['npm', 'run', 'build'], repo / 'web', profile)
for manifest in [immutable, inputs, frontend, policy]:
    for name, digest in manifest.items():
        assert sha(repo / name) == digest, name
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == head
save('local-validation.json', dict(status='passed', source_hashes=candidate, upstream=head,
    receipts=receipts, catalog_modules=catalog_modules, mutants=sum(v['mutants'] for v in wasm['results']),
    original_immutable_assets=len(immutable), frontend_commands=len(read(repo / 'web/package.json')['scripts']['check'].split(' && ')),
    main_adopted=False, ci_triggered=False, deployed=False))
print('CURRENT APPLICATION LOCAL INTEGRATION GATES PASSED; NO PUSH OR RELEASE', flush=True)
