"""Verify terminal evidence, then publish the local validation report and raw harness."""
from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, tarfile

p = Path(__file__).resolve().parent
r = p.parent
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
out = repo / 'packages/stridetorch/benchmarks/results'
read = lambda q: json.loads(q.read_text())
sha = lambda q: hashlib.sha256(q.read_bytes()).hexdigest()
def save(q, value):
    q.write_text(json.dumps(value, indent=2) + '\n')

source = read(p / 'source-hashes.json')
tests = read(p / 'test-hashes.json')
assert len(source) == 61 and len(tests) == 67
for name, digest in source.items():
    assert sha(repo / 'packages/stridetorch/src/stridetorch' / name) == digest
for name, digest in tests.items():
    assert sha(repo / 'packages/stridetorch/tests' / name) == digest
for name, prefix in [('application-input-sha256.json', repo), ('frontend-input-sha256.json', repo),
                     ('owned-input-sha256.json', repo), ('baseline-immutable-sha256.json', repo),
                     ('new-assets-sha256.json', repo), ('live-export-sha256.json', repo / 'web/public/data')]:
    for filename, digest in read(p / name).items():
        assert sha(prefix / filename) == digest, (name, filename)
policy = read(p / 'release-policy-identity.json')
for manifest in [policy['files'], policy['workflows']]:
    for name, digest in manifest.items():
        assert sha(repo / name) == digest
local = read(p / 'local-validation.json')
assert local['status'] == 'passed' and local['source_hashes'] == source
assert len(local['receipts']) == 10 and all(v['exit_code'] == 0 for v in local['receipts'])
for receipt in local['receipts']:
    assert sha(p / (receipt['label'] + '.log')) == receipt['log_sha256']
cpu = read(p / 'cpu-receipt.json')
assert cpu['exit_code'] == 0 and cpu['source_hashes'] == source
count = int(re.search(r'(\d+) passed', cpu['summary'][0]).group(1))
assert count > 41716 and '1 skipped' in cpu['summary'][0]
wasm = read(p / 'full-wasm-result.json')
assert wasm['passed'] and wasm['modules'] == wasm['catalog_modules'] == 86
assert len(wasm['results']) == 86 and not wasm['browser_budget_exceeded']
assert all(v['passed'] and not v['browser_budget_exceeded'] for v in wasm['results'])
contracts = next(v for v in wasm['results'] if v['id'] == 'architecture/attention')['independent_contracts']
assert contracts['passed'] == 8165 and len(contracts['suites']) == 66
assert {v['suite']: v['source_sha256'] for v in contracts['suites']} == {
    name: digest for name, digest in tests.items() if name != 'test_standalone.py'}
package = read(r / 'final-package-release/package-proof/package-identity.json')
assert package['status'] == 'success' and package['source_hashes'] == source
assert package['standalone_installed_tests'] == 8178 and package['native_torch'] is False
for name, digest in package['artifacts'].items():
    assert sha(r / 'final-package-release/package-proof' / name) == digest
for name, digest in package['application_source_hashes'].items():
    assert sha(repo / name) == digest
runtime_contracts = {}
for label, name in [('node', 'source-wasm.json'), ('chrome', 'chrome-contracts/result.json')]:
    proof = read(r / 'versioned-release/wasm-proof' / name)
    assert proof['source_hashes'] == source and proof['passed'] == 8165 and proof['library'] == '0.69.0'
    model = proof['model_qualification']
    assert model['status'] == 'passed' and model['cases'] == 368 and not model['failures']
    assert model['source_hashes'] == source
    runtime_contracts[label] = {k: v for k, v in proof.items() if k != 'model_candidate'}
native = read(r / 'versioned-release/model-proof/model-qualification.json')
assert native['source_hashes'] == source and native['cases'] == 368 and not native['failures']
performance = read(r / 'performance-selected/summary.json')
assert performance['status'] == 'completed' and performance['fresh_children'] == 18
assert performance['source_hashes'] == dict(baseline=read(p / 'baseline-source-sha256.json'),
                                         duplicate=read(p / 'baseline-source-sha256.json'), candidate=source)
assert read(p / 'performance-reviewed.json')['performance_sha256'] == sha(r / 'performance-selected/summary.json')
export = read(p / 'export-identity.json')
assert export['source_hashes'] == source and export['version'] == '0.69.0'
assert export['catalog_modules'] == 86 and export['preserved_assets'] == 13909
assert export['new_assets'] == 174 and export['active_export_and_index_hashes'] == 177
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert head == local['upstream']
snapshot = p / 'published-inputs'
snapshot.mkdir(exist_ok=True)
shutil.copytree(repo / 'packages/stridetorch/src/stridetorch', snapshot / 'runtime-source',
                ignore=shutil.ignore_patterns('__pycache__'), dirs_exist_ok=True)
shutil.copytree(repo / 'packages/stridetorch/tests', snapshot / 'runtime-tests',
                ignore=shutil.ignore_patterns('__pycache__', '.pytest_cache'), dirs_exist_ok=True)
for name in ['README.md', 'pyproject.toml', 'LICENSE', 'NOTICE']:
    shutil.copy2(repo / 'packages/stridetorch' / name, snapshot / name)
save(p / 'state.json', dict(status='all_local_gates_passed', source_hashes=source,
                           upstream=head, main_adopted=False, ci_triggered=False))

archive = out / 'iteration-69-harness.tar.gz'
assert not archive.exists()
seen = {}
payloads = {}
logical_bytes = 0
hardlinks = 0
excluded = {'__pycache__', '.pytest_cache', '.git', 'pytest-tmp', 'node_modules', 'build', 'dist'}
allowed = {'.py', '.mjs', '.json', '.log', '.md', '.html', '.toml', '.npz', '.txt', '.whl', '.pkl', '.patch'}
with tarfile.open(archive, 'w:gz') as target:
    for current, dirs, files in os.walk(r):
        dirs[:] = sorted(name for name in dirs if name not in excluded and not name.endswith(('-env', '-venv', '.egg-info')))
        for name in sorted(files):
            q = Path(current) / name
            if q.is_symlink() or not (q.name in ['LICENSE', 'NOTICE'] or q.suffix in allowed or q.name.endswith('.tar.gz')):
                continue
            arc = str(q.relative_to(r))
            digest = sha(q)
            payloads[arc] = digest
            info = target.gettarinfo(str(q), arcname=arc)
            logical_bytes += q.stat().st_size
            key = (digest, info.mode, info.uid, info.gid, info.uname, info.gname)
            if key in seen:
                info.type = tarfile.LNKTYPE
                info.linkname = seen[key]
                info.size = 0
                target.addfile(info)
                hardlinks += 1
            else:
                seen[key] = arc
                with q.open('rb') as content:
                    target.addfile(info, content)
with tarfile.open(archive, 'r:gz') as target:
    assert len(target.getmembers()) == len(payloads)
    for member in target.getmembers():
        assert hashlib.sha256(target.extractfile(member).read()).hexdigest() == payloads[member.name]
record = dict(name=archive.name, bytes=archive.stat().st_size, sha256=sha(archive),
    files=len(payloads), unique_payloads=len(seen), hardlinks=hardlinks, logical_bytes=logical_bytes,
    all_logical_payloads_verified=True, filesystem_timestamps_not_comparison_inputs=True)
assert record['bytes'] < 95 * 1024 * 1024
save(p / 'archive-identity.json', record)
report = dict(status='validated_locally', version='0.69.0', baseline_version='0.68.0', upstream=head,
    source_hashes=source, test_hashes=tests, owned_inputs=read(p / 'owned-input-sha256.json'),
    full_cpu=cpu, full_wasm=wasm, independent_package=package, versioned_runtime_contracts=runtime_contracts,
    native_model_vjp=native, local_integration=local, export_identity=export,
    full_catalog_node='v22.23.3',
    active_export_sha256=read(p / 'live-export-sha256.json'), release_policies=policy,
    performance=performance, performance_review=read(p / 'performance-reviewed.json'),
    timing_interruption=read(r / 'performance-selected/interruption.json'), raw_archive=record,
    limitations=['First-order real functional VJP only; no torch.func.vjp, create_graph=True, complex inputs or nested forward AD support.',
        'Default Tensor.numpy has a measurable relative overhead despite a small absolute overhead. No universal performance improvement claim.',
        'VJP timing reference is an unchecked manual0.68AD wrapper, not a preexisting functional API.',
        'The timing environment disappeared after11children. Those results are preserved;7remainingchildren use the samePython and identical sharedNumPy files in a newly recorded environment.',
        'Earlier prototype failures, initial slower implementation and intermediate optimizations are archived as historical evidence, not relabeled as final-source runs.',
        'Module operator serialization covers direct registered function attributes. Arbitrary nested user functions retain ordinary Python pickle limitations.',
        'No GPU backend or new WebGPU throughput claim. Previously qualified opaqueWorker/hostbroker feasibility is separate from this CPU/WASM change.',
        'Archived scripts retain original workspace paths and need the documented dependencies and path adjustment for replay.',
        'Local validation does not imply main adoption, CI execution, release or deployment.'])
save(out / 'iteration-69.json', report)
ratios = '\n'.join('| ' + ' | '.join([row['runtime'], row['case'],
    f"{row['medians']['duplicate_over_baseline']:.4f}", f"{row['medians']['candidate_over_baseline']:.4f}"]) + ' |'
    for row in performance['rows'])
doc = f'''# Torch runtime iteration 69: first-order functional VJP

Version 0.69 adds `torch.autograd.functional.vjp` for supported real first-order
operators. The callback runs once with distinct detached input objects. Existing
caller gradient flags, accumulated gradients and hooks remain intact; results
and derivatives are detached. Tensor/tuple structure, implicit scalar seeds,
unused-input zeros and strict-mode rejection are checked against native Torch.
An implicit NumPy escape inside the recorded callback raises an error; explicit
`detach()`, `no_grad()` and `numpy(force=True)` preserve deliberate disconnection.
Higher-order graphs, complex inputs, forward-AD nesting and `torch.func.vjp`
remain unsupported. This release adds no GPU backend.

Registered function attributes on `nn.Module` now survive shallow/deep copy and
pickle, including functional VJP and Transformer activations. Operator references
resolve to their owning distribution in a fresh process. Ordinary payloads do not
have arbitrary `__class__` properties evaluated during state handling. General
user-lambda serialization is outside this contract.

## Verification

- Full application and standalone CPU suite: **{cpu['summary'][0]}**.
- Current catalog: **86 modules**, **{sum(v['mutants'] for v in wasm['results'])} mutants** in actual Pyodide/WASM, no budget exceedance.
- Standalone SDK: **8,165 cases / 66 suites** in Node and Chrome WASM; full exported application also checks the current SDK suite.
- Native model qualification: **368 cases** (336 successful,32 expected rejections), independently replayed on CPU, Node WASM and Chrome WASM. Coverage includes strided/aliased inputs, float32/float64, opposite seed dtype, linear/normalization/convolution/attention/linalg, mixed constant outputs and caller-state preservation. Maximum observed absolute difference: `{native['max_abs_difference']}`.
- Actual wheel/sdist and private application wheel: exact61source/license identities, **8,178 installed tests** on Python3.10.19 / NumPy1.26.4 without native Torch; independent uninstall ownership, checkpoint resume and fresh-process callable restoration checked.
- **{local['frontend_commands']} frontend checks**, WASM-driver and release-policy checks, and both local Node22.23.3 build profiles. The full catalog WASM gate also uses Node22.23.3; iteration68usedNode25, so their aggregate gate times are not a matched performance comparison.
- Preserved **13,909** immutable cached assets; added **174** reachable assets; checked **177** live export/index identities.
- Baseline application commit: `{head}`. No CI workflow or deployment was requested by these local checks. Main adoption is recorded separately.

## Performance and tradeoffs

18fresh processes (6 per runtime), all6source-load permutations,12balanced
common batches of at least20ms per flow and an identical-source A/A control.
Lower B/A means faster. Ratios below are medians of per-process ratios; they
are not ratios of independently pooled absolute times. The new VJP reference
is an **unchecked manual0.68AD wrapper**, not an existing functional-VJP API.

| Runtime | Flow | A/A | B/A |
| --- | --- | --- | --- |
{ratios}

The initial candidate regressed copy/pickle latency by12–29%. Moving registered
function conversion to a type-filtered state path reduced those medians to
roughly0–3% versus0.68. Initial and intermediate results remain in the raw archive.
Default `Tensor.numpy()` still incurs approximately21%CPU /34%Node /36%Chrome
relative overhead; the difference between absolute per-runtime medians is about
25ns /110ns /101ns. `np.asarray` medians differ by about-0.6% /+4.4% /+1.3%.
Public functional VJP costs about6–12% more than the unchecked manual wrapper,
including validation and caller-state isolation. Training and A/A outliers are
retained. No universal speedup or native-Torch/GPU performance claim is made.

The original timing environment disappeared after11successful children, before
the next process launched. Those11results were preserved. The remaining7ran in
a new environment with the samePython3.12.11 and identical NumPy2.5.4 files;
the interruption and resume runner are archived. No timing child overlapped
our package or full application gates.

## Reproducible evidence

Machine report: `packages/stridetorch/benchmarks/results/iteration-69.json`.
Raw archive: `{record['name']}` ({record['bytes']:,} bytes), SHA256
`{record['sha256']}`. All{record['files']}logical payloads were verified after
writing; identical-content hardlinks preserve permissions/ownership. File
timestamps are not comparison inputs. Rejected prototypes and their logs are
historical evidence. Scripts retain original absolute paths and require path
adjustment, Python/NumPy/nativeTorch, pinned Pyodide and browser dependencies.
The selected source is under `versioned-release/snapshot`; final timing is
`performance-selected`, while `performance` records the slower initial candidate.
The independently named library remains StrideTorch pending a naming decision.
'''
(repo / 'docs/validation/torch-runtime-iteration-69.md').write_text(doc)
print(json.dumps(dict(status='validated_locally', cpu=cpu['summary'], wasm_modules=86,
    mutants=sum(v['mutants'] for v in wasm['results']), raw_archive=record)), flush=True)
