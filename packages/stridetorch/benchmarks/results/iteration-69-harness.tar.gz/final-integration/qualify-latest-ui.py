"""Qualify reviewed UI-only upstream changes while retaining numerical proofs."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile, time

p = Path(__file__).resolve().parent
r = p.parent
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
q = r / 'post-validation-ui'
q.mkdir(exist_ok=True)
read = lambda f: json.loads(f.read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
sync = read(p / 'post-validation-ui-sync.json')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert head == sync['after']
source = read(p / 'source-hashes.json')
owned = read(p / 'own-commits.json')['changed_paths']
def verify_preserved():
    for name, digest in owned.items():
        assert sha(repo / name) == digest, name
    for manifest in ['application-input-sha256.json', 'baseline-immutable-sha256.json']:
        for name, digest in read(p / manifest).items():
            assert sha(repo / name) == digest, name
    for name, digest in read(p / 'release-policy-identity.json')['files'].items():
        assert sha(repo / name) == digest, name
    for name, digest in source.items():
        assert sha(repo / 'packages/stridetorch/src/stridetorch' / name) == digest
    for name, digest in read(p / 'live-export-sha256.json').items():
        assert sha(repo / 'web/public/data' / name) == digest
verify_preserved()
files = [f for directory in ['web/src', 'web/scripts'] for f in (repo / directory).rglob('*') if f.is_file()]
files.extend(f for f in (repo / 'web').iterdir() if f.is_file() and f.suffix in ['.json', '.ts', '.js', '.mjs'])
inputs = {str(f.relative_to(repo)): sha(f) for f in files}
(q / 'frontend-input-sha256.json').write_text(json.dumps(inputs, indent=2) + '\n')
value = subprocess.check_output(['gh', 'api', 'repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED', '--jq', '.value'], cwd=repo, text=True).strip()
assert value in ['0', '1']
profile = dict(PAPERLEET_MAIN_SITE_ENABLED=value, VITE_PUBLIC_SITE='0' if value == '1' else '1',
    VITE_APP_EDITION='hosted' if value == '1' else 'local', VITE_API_ORIGIN='https://app.paperleet.com' if value == '1' else '',
    VITE_HOSTED_APP_AVAILABLE='1', VITE_HOSTED_APP_URL='https://app.paperleet.com')
python = r / 'integration-dev-env/bin/python'
env = dict(os.environ, PYTHON=str(python), PYTHONDONTWRITEBYTECODE='1',
    PYTHONPATH=os.pathsep.join([str(repo / 'packages/stridetorch/src'), str(repo)]),
    OMP_NUM_THREADS='2', MKL_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', VECLIB_MAXIMUM_THREADS='2')
env['PATH'] = '/Users/david/.npm/_npx/d18f28baf1132559/node_modules/node/bin:/opt/homebrew/bin:' + str(python.parent) + ':' + env['PATH']
node = subprocess.check_output(['node', '--version'], env=env, text=True).strip()
assert node == 'v22.23.3'
receipts = []
for label, args, cwd, extra in [
    ('full-frontend-check', ['npm', 'run', 'check'], repo / 'web', {}),
    ('wasm-driver', ['node', 'web/scripts/check-wasm-cases.mjs'], repo, {}),
    ('pages-policy', ['node', 'web/scripts/check-pages-release.cjs'], repo, {}),
    ('build', ['npm', 'run', 'build'], repo / 'web', {}),
    ('pages-profile-build', ['npm', 'run', 'build'], repo / 'web', profile)]:
    started = time.monotonic()
    with (q / (label + '.log')).open('w') as log:
        child = subprocess.run(args, cwd=cwd, env={**env, **extra}, stdout=log, stderr=subprocess.STDOUT)
    receipts.append(dict(label=label, args=args, cwd=str(cwd), exit_code=child.returncode,
        seconds=time.monotonic()-started, log_sha256=sha(q / (label + '.log')),
        last_line=(q / (label + '.log')).read_text().splitlines()[-1:]))
    report = dict(status='running' if child.returncode == 0 else 'failed', source_commit=sync['source_commit'],
        qualified_tree_commit=head, upstream=sync['merged_upstream'], source_hashes=source,
        frontend_input_hashes=inputs, pages_profile=profile, node=node, receipts=receipts,
        frontend_commands=len(read(repo / 'web/package.json')['scripts']['check'].split(' && ')),
        scope='Complete latest frontend/driver/release-policy and bothlocalbuildprofiles after reviewed UI-only upstream merge. Numerical source, application/test inputs and all validated source/export/archive payloads remain unchanged. No CI, tag, release or deployment.')
    (q / 'qualification.json').write_text(json.dumps(report, indent=2) + '\n')
    child.check_returncode()
    print(label, 'TERMINAL0', flush=True)
verify_preserved()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == head
for name, digest in inputs.items():
    assert sha(repo / name) == digest
report.update(status='qualified', preserved_validated_payloads=len(owned))
(q / 'qualification.json').write_text(json.dumps(report, indent=2) + '\n')
shutil.copy2(Path(__file__), q / 'qualify-latest-ui.py')
shutil.copy2(p / 'post-validation-ui-sync.json', q / 'upstream-sync.json')
archive = repo / 'packages/stridetorch/benchmarks/results/iteration-69-current-ui-harness.tar.gz'
assert not archive.exists()
payloads = {str(f.relative_to(q)): sha(f) for f in q.rglob('*') if f.is_file()}
with tarfile.open(archive, 'w:gz') as target:
    for name in sorted(payloads): target.add(q / name, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as target:
    assert len(target.getmembers()) == len(payloads)
    for member in target.getmembers():
        assert hashlib.sha256(target.extractfile(member).read()).hexdigest() == payloads[member.name]
report['raw_archive'] = dict(name=archive.name, bytes=archive.stat().st_size, sha256=sha(archive),
                             files=len(payloads), all_payloads_verified=True)
(repo / 'packages/stridetorch/benchmarks/results/iteration-69-current-ui.json').write_text(json.dumps(report, indent=2) + '\n')
print('LATEST UI QUALIFIED; VALIDATED NUMERICAL PAYLOADS PRESERVED', head, flush=True)
