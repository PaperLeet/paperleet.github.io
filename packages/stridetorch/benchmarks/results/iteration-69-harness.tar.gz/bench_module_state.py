from pathlib import Path
import sys,json,time,statistics,itertools,gc
import numpy as np
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'performance/assets'))
from bench_vjp import load,build
cycle=int(sys.argv[1]);labels=['baseline','duplicate','initial','optimized'];paths=dict(baseline=Path('/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src/stridetorch'),duplicate=Path('/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src/stridetorch'),initial=r/'versioned-release/snapshot/packages/stridetorch/src/stridetorch',optimized=r/'module-opt-source/stridetorch');order=labels[cycle:]+labels[:cycle];modules={};hashes={};aliases=dict(baseline='_copy_a',duplicate='_copy_d',initial='_copy_b',optimized='_copy_c')
for label in order:modules[label],hashes[label]=load(aliases[label],paths[label])
orders=[labels[i:]+labels[:i] for i in range(4)];orders+=list(reversed(orders));rows=[]
for case in ['linear_deepcopy','transformer_deepcopy','transformer_pickle']:
 functions={};captures={}
 for label in order:functions[label],captures[label],dtype=build(modules[label],case,False)
 expected=captures['baseline']()
 for label in labels:
  actual=captures[label]();assert len(actual)==len(expected)
  for a,b in zip(actual,expected):np.testing.assert_allclose(a,b,rtol=3e-5 if dtype=='float32' else 3e-11,atol=3e-6 if dtype=='float32' else 3e-11)
 gc.collect();calls=1
 for label in order:
  batch=1
  while True:
   start=time.perf_counter()
   for _ in range(batch):functions[label]()
   if time.perf_counter()-start>=.03:break
   batch*=2
  calls=max(calls,batch)
 samples={label:[] for label in labels}
 for sample_order in orders:
  for label in sample_order:
   fn=functions[label];start=time.perf_counter()
   for _ in range(calls):fn()
   samples[label].append((time.perf_counter()-start)/calls)
 medians={label:statistics.median(v) for label,v in samples.items()};rows.append(dict(case=case,calls=calls,samples_s=samples,median_s=medians,over_baseline={label:medians[label]/medians['baseline'] for label in labels},optimized_over_initial=medians['optimized']/medians['initial']))
print(json.dumps(dict(cycle=cycle,source_hashes=hashes,load_order=order,rows=rows,scope='Four fresh source-load rotations, duplicate A/A, initial0.69 and module-state fast-path variant, eight balanced common >=30ms batches. CPU only, matched copy/pickle data; no application/WASM/universal speedup claim.'),indent=2))
