from pathlib import Path
import sys,time,statistics,json,gc
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'torch-iteration-68/performance/assets'))
from bench_determinants import load
r=Path(__file__).resolve().parent;cycle=int(sys.argv[1]);labels=['baseline','duplicate','guarded','optimized'];paths=dict(baseline=Path('/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src/stridetorch'),duplicate=Path('/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src/stridetorch'),guarded=r/'candidate-source/stridetorch',optimized=r/'export-opt-source/stridetorch');order=labels[cycle:]+labels[:cycle];modules={};hashes={}
for label in order:modules[label],hashes[label]=load('_exports_'+label,paths[label])
rows=[];orders=[labels[i:]+labels[:i] for i in range(4)];orders+=list(reversed(orders))
for kind,dtype,strided in [('numpy','float32',False),('numpy','float64',True),('asarray','float64',False),('asarray','float32',True)]:
 data=np.arange(24,dtype=dtype).reshape(4,6);data=data.T[:,::2] if strided else data;functions={}
 for label in order:
  value=modules[label].torch.from_numpy(data)
  functions[label]=(lambda x=value:x.numpy()) if kind=='numpy' else (lambda x=value:np.asarray(x))
  result=functions[label]();np.testing.assert_array_equal(result,data);assert result.dtype==data.dtype and result.strides==data.strides and np.shares_memory(result,data)
 gc.collect();calls=1
 for label in order:
  batch=1
  while True:
   start=time.perf_counter()
   for _ in range(batch):functions[label]()
   if time.perf_counter()-start>=.03:break
   batch*=2
  calls=max(calls,batch)
 samples={label:[] for label in labels}
 for sampling_order in orders:
  for label in sampling_order:
   fn=functions[label];start=time.perf_counter()
   for _ in range(calls):fn()
   samples[label].append((time.perf_counter()-start)/calls)
 medians={name:statistics.median(values) for name,values in samples.items()};rows.append(dict(kind=kind,dtype=dtype,strided=strided,calls=calls,samples_s=samples,median_s=medians,over_baseline={name:medians[name]/medians['baseline'] for name in labels},optimized_over_guarded=medians['optimized']/medians['guarded']))
print(json.dumps(dict(cycle=cycle,load_order=order,source_hashes=hashes,numpy=np.__version__,rows=rows,scope='CPU export-only matched loops; four module-load rotations and balanced common >=30ms batches. Same-source duplicate, current functional-boundary guard and optional fast-path variant. No training, WASM or universal speedup claim.'),indent=2))
