import torch,numpy as np,json
x=torch.tensor([2.,3.],requires_grad=True);rows=[]
for force in [True,False,1,0,None,'x',np.bool_(True)]:
 try:rows.append(dict(force=repr(force),success=True,value=x.numpy(force=force).tolist()))
 except Exception as error:rows.append(dict(force=repr(force),success=False,error_type=type(error).__name__))
print(json.dumps(rows,indent=2))
