import json,torch
x=torch.tensor([2.,3.]);y=torch.tensor([4.,5.]);rows=[]
cases=[('empty_inputs',lambda:torch.autograd.functional.vjp(lambda:torch.tensor(2.),())),('empty_output_none',lambda:torch.autograd.functional.vjp(lambda z:(),x)),('empty_output_tuple_seed',lambda:torch.autograd.functional.vjp(lambda z:(),x,())),('integer_output',lambda:torch.autograd.functional.vjp(lambda z:torch.ones(2,dtype=torch.int64),x,torch.ones(2))),('float16',lambda:torch.autograd.functional.vjp(lambda z:z.square().sum(),x.to(torch.float16))),('one_tuple_output',lambda:torch.autograd.functional.vjp(lambda z:(z.sum(),),x)),('mixed_constant',lambda:torch.autograd.functional.vjp(lambda z:(z.square(),torch.ones(2)),x,(torch.ones(2),torch.ones(2)))),('mixed_constant_strict',lambda:torch.autograd.functional.vjp(lambda z:(z.square(),torch.ones(2)),x,(torch.ones(2),torch.ones(2)),strict=True)),('duplicate_inputs',lambda:torch.autograd.functional.vjp(lambda a,b:a*2+b*3,(x,x),torch.ones(2))),('captured_original',lambda:torch.autograd.functional.vjp(lambda z:z*x,x,torch.ones(2))),('unused_input',lambda:torch.autograd.functional.vjp(lambda a,b:a*2,(x,y),torch.ones(2))),('unused_strict',lambda:torch.autograd.functional.vjp(lambda a,b:a*2,(x,y),torch.ones(2),strict=True))]
def encode(value):
 if isinstance(value,torch.Tensor):return dict(value=value.tolist(),dtype=str(value.dtype),shape=list(value.shape),requires_grad=value.requires_grad)
 return [encode(v) for v in value]
for name,call in cases:
 try:rows.append(dict(name=name,success=True,result=encode(call())))
 except Exception as e:rows.append(dict(name=name,success=False,error_type=type(e).__name__,message=str(e)))
print(json.dumps(dict(torch=torch.__version__,torch_git=torch.version.git_version,rows=rows),indent=2))
