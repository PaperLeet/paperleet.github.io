from pathlib import Path
import json,subprocess,os,time,statistics,hashlib
p=Path(__file__).resolve().parent;r=p.parent;assets=p/'assets';out=p/'results';out.mkdir(exist_ok=True);python=r.parent/'torch-iteration-21/stride-dev-env/bin/python';env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');plan=json.loads((assets/'plan.json').read_text());receipts=[]
for cycle in range(6):
 for runtime in ['cpu','node','chrome'] if cycle%2==0 else ['chrome','node','cpu']:
  name=f'{runtime}-{cycle}';file=out/(name+'.json');args=[str(python),str(assets/'bench_vjp.py'),str(assets/'baseline/stridetorch'),str(assets/'candidate/stridetorch'),str(cycle)] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(p/f'bench-{runtime}.mjs'),str(file)];started=time.monotonic()
  with (out/(name+'.log')).open('w') as log:
   if runtime=='cpu':
    with file.open('w') as output:child=subprocess.run(args,cwd=assets,env={**env,'CYCLE':str(cycle)},stdout=output,stderr=log)
   else:child=subprocess.run(args,cwd=assets,env={**env,'CYCLE':str(cycle)},stdout=log,stderr=subprocess.STDOUT)
  receipts.append(dict(runtime=runtime,cycle=cycle,exit_code=child.returncode,seconds=time.monotonic()-started));(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');child.check_returncode();raw=json.loads(file.read_text());b=raw.get('benchmark',raw);assert len(b['rows'])==9 and b['source_hashes']==plan['source_hashes'] and b['program_sha256']==plan['programs']['bench_vjp.py'];print(name,'PASS',flush=True)
rows=[]
for runtime in ['cpu','node','chrome']:
 children=[]
 for cycle in range(6):
  raw=json.loads((out/f'{runtime}-{cycle}.json').read_text());children.append(raw.get('benchmark',raw))
 for i in range(9):
  samples=[v['rows'][i] for v in children];assert all(v['case']==samples[0]['case'] for v in samples);keys=['duplicate_over_baseline','candidate_over_baseline','candidate_over_duplicate'];rows.append(dict(runtime=runtime,case=samples[0]['case'],dtype=samples[0]['dtype'],reference=samples[0]['reference'],ratios={k:[v[k] for v in samples] for k in keys},medians={k:statistics.median(v[k] for v in samples) for k in keys},median_ns={label:statistics.median(v['median_s'][label] for v in samples)*1e9 for label in ['baseline','duplicate','candidate']}))
report=dict(status='completed',fresh_children=18,flows_per_child=9,source_hashes=plan['source_hashes'],programs=plan['programs'],rows=rows,scope='Six fresh processes per runtime and all source-load permutations. Twelve balanced common >=20ms batches per workflow, same-source duplicate, pre-timing numerical/alias/caller-state checks. ExistingAPI and unchecked manual-reference newVJP comparisons are labeled separately. No nativeTorch/GPU/cold-start/universal speedup claim.');(p/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print('ALL18 FRESH9-FLOW AA/B CHILDREN PASS',flush=True)
