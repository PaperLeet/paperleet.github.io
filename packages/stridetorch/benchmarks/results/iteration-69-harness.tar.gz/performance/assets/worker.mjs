import {loadJudgePackages} from '../../../extraction-browser/packages.mjs';
self.onmessage=async({data})=>{try{
const plan=await(await fetch('./plan.json')).json();const {loadPyodide}=await import('../../../runtime-0.29.4/pyodide.mjs');const py=await loadPyodide({indexURL:new URL('../../../runtime-0.29.4/',self.location.href).href,stdout(){},stderr(){}});await loadJudgePackages(py,[]);
for(const label of ['baseline','candidate']){py.FS.mkdirTree('/'+label+'/stridetorch');for(const name of Object.keys(plan.source_hashes[label]))py.FS.writeFile('/'+label+'/stridetorch/'+name,await(await fetch('./'+label+'/stridetorch/'+name)).text());}
for(const name of Object.keys(plan.programs))py.FS.writeFile('/'+name,await(await fetch('./'+name)).text());py.globals.set('plan_json',JSON.stringify(plan));py.globals.set('cycle',data.cycle);
const result=JSON.parse(py.runPython("import sys,json,pathlib,hashlib\nsys.path.insert(0,'/')\nplan=json.loads(plan_json)\nfor name,digest in plan['programs'].items():assert hashlib.sha256(pathlib.Path('/'+name).read_bytes()).hexdigest()==digest\nfrom bench_vjp import run\nresult=run('/baseline/stridetorch','/candidate/stridetorch',cycle)\nassert result['source_hashes']==plan['source_hashes']\njson.dumps(result)"));self.postMessage({runtime:'chrome',pyodide:py.version,benchmark:result});
}catch(error){self.postMessage({error:String(error.stack||error)});}};
