"""Matched legacy/control flows, serialization, exports and first-order VJP reference."""
from pathlib import Path
import copy,gc,hashlib,importlib.util,itertools,json,pickle,statistics,sys,time
import numpy as np

def load(name,path):
 p=Path(path);spec=importlib.util.spec_from_file_location(name,p/'__init__.py',submodule_search_locations=[str(p)]);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m)
 return m,{q.name:hashlib.sha256(q.read_bytes()).hexdigest() for q in p.iterdir() if q.suffix=='.py' or q.name in ['LICENSE','NOTICE']}

def flatten(value):
 if isinstance(value,(tuple,list)):return [a for v in value for a in flatten(v)]
 return [value.numpy().copy()]

def model(t,linear=False):
 dtype=t.float32 if linear else t.float64
 m=t.nn.Linear(32,16,dtype=dtype) if linear else t.nn.TransformerEncoderLayer(4,2,8,dropout=0.,batch_first=True,dtype=dtype,activation=t.sin)
 with t.no_grad():
  for i,p in enumerate(m.parameters()):p.copy_(t.tensor((np.sin(np.arange(p.numel())*.13+i)*.1).reshape(tuple(p.shape)),dtype=dtype))
 x=t.tensor(np.cos(np.arange(128 if linear else 24)*.17).reshape((4,32) if linear else (2,3,4)),dtype=dtype)
 return m,x

def build(module,case,candidate):
 t=module.torch;rng=np.random.default_rng(7427)
 if case.startswith('export_'):
  data=np.arange(24,dtype='float32' if case=='export_numpy' else 'float64').reshape(4,6)
  if case=='export_asarray':data=data.T[:,::2]
  value=t.from_numpy(data);fn=(lambda:value.numpy()) if case=='export_numpy' else(lambda:np.asarray(value))
  def capture():
   out=fn();assert out.dtype==data.dtype and out.strides==data.strides and np.shares_memory(out,data);return[out.copy()]
  return fn,capture,'float32' if case=='export_numpy' else 'float64'
 if case in ['linear_deepcopy','transformer_deepcopy','transformer_pickle']:
  m,x=model(t,case=='linear_deepcopy');fn=(lambda:pickle.loads(pickle.dumps(m))) if case=='transformer_pickle' else(lambda:copy.deepcopy(m))
  def capture():
   cloned=fn()
   with t.no_grad():return[cloned(x).numpy().copy()]
  return fn,capture,'float32' if case=='linear_deepcopy' else 'float64'
 if case in ['vjp_scalar','vjp_linear']:
  if case=='vjp_scalar':values=(t.tensor(np.sin(np.arange(64)*.17),dtype=t.float64),);function=lambda a:(a.sin()*a.square()).sum();seed=None;dtype='float64'
  else:
   values=tuple(t.tensor(rng.normal(size=shape).astype('float32')) for shape in [(16,32),(8,32),(8,)]);function=lambda a,w,b:t.nn.functional.linear(a,w,b).tanh();seed=t.tensor(rng.normal(size=(16,8)).astype('float32'));dtype='float32'
  if candidate:fn=lambda:t.autograd.functional.vjp(function,values,seed)
  else:
   def fn():
    # Unchecked reference assembled from existing0.68 public AD, for pure Torch callbacks.
    with t.enable_grad():
     args=tuple(value.detach().requires_grad_(True) for value in values);out=function(*args);g=t.autograd.grad(out,args,seed,allow_unused=True)
     return out.detach(),tuple(value.detach() for value in g)
  def capture():
   out=fn();assert all(v.grad is None and not v.requires_grad for v in values);return flatten(out)
  return fn,capture,dtype
 if case=='mha_step':
  m=t.nn.MultiheadAttention(32,4,batch_first=True,dropout=0.,dtype=t.float32);x=t.tensor(rng.normal(size=(2,16,32)).astype('float32'),requires_grad=True)
  with t.no_grad():
   for p in m.parameters():p.copy_(t.tensor((rng.normal(size=tuple(p.shape))*.04).astype('float32')))
  params=list(m.parameters())
  def fn():
   m.zero_grad(set_to_none=True);x.grad=None;y,_=m(x,x,x,need_weights=False);loss=y.square().mean();loss.backward();return loss
  def capture():
   out=fn();return [out.numpy().copy(),x.grad.numpy().copy(),*[p.grad.numpy().copy() for p in params]]
  return fn,capture,'float32'
 if case=='groupnorm_step':
  values=[t.tensor(rng.normal(size=shape).astype('float64'),requires_grad=True) for shape in [(2,8,8,8),(8,),(8,)]]
  def fn():
   for x in values:x.grad=None
   loss=t.nn.functional.group_norm(values[0],4,values[1],values[2]).square().mean();loss.backward();return loss
  def capture():
   out=fn();return[out.numpy().copy(),*[v.grad.numpy().copy() for v in values]]
  return fn,capture,'float64'
 raise AssertionError(case)

def run(baseline,candidate,cycle):
 labels=['baseline','duplicate','candidate'];orders=list(itertools.permutations(labels));load_order=orders[cycle%6];modules={};hashes={};paths=dict(baseline=baseline,duplicate=baseline,candidate=candidate);aliases=dict(baseline='_perf_a',duplicate='_perf_d',candidate='_perf_b')
 for label in load_order:modules[label],hashes[label]=load(aliases[label],paths[label])
 assert hashes['baseline']==hashes['duplicate'];rows=[]
 for case in ['mha_step','groupnorm_step','linear_deepcopy','transformer_deepcopy','transformer_pickle','export_numpy','export_asarray','vjp_scalar','vjp_linear']:
  functions={};captures={}
  for label in load_order:functions[label],captures[label],dtype=build(modules[label],case,label=='candidate')
  expected=captures['baseline']()
  for label in ['duplicate','candidate']:
   actual=captures[label]();assert len(actual)==len(expected)
   for a,b in zip(actual,expected):assert a.shape==b.shape and a.dtype==b.dtype;np.testing.assert_allclose(a,b,rtol=3e-5 if dtype=='float32' else 3e-11,atol=3e-6 if dtype=='float32' else 3e-11)
  del expected,actual;gc.collect();calls=1
  for label in load_order:
   batch=1
   while True:
    start=time.perf_counter()
    for _ in range(batch):functions[label]()
    if time.perf_counter()-start>=.02:break
    batch*=2
   calls=max(calls,batch)
  samples={label:[] for label in labels}
  for order in orders+list(reversed(orders)):
   for label in order:
    fn=functions[label];start=time.perf_counter()
    for _ in range(calls):fn()
    samples[label].append((time.perf_counter()-start)/calls)
  medians={label:statistics.median(values) for label,values in samples.items()};rows.append(dict(case=case,dtype=dtype,calls=calls,samples_s=samples,median_s=medians,duplicate_over_baseline=medians['duplicate']/medians['baseline'],candidate_over_baseline=medians['candidate']/medians['baseline'],candidate_over_duplicate=medians['candidate']/medians['duplicate'],reference='Unchecked0.68AD wrapper for this new API' if case.startswith('vjp_') else 'Existing0.68 API'))
 return dict(cycle=cycle,load_order=list(load_order),source_hashes=hashes,rows=rows,python=sys.version,numpy=np.__version__,program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Six source-load permutations per runtime;12 balanced common >=20ms batches, duplicate A/A controls and numerical/alias/caller-state checks before timing. Serialization/export overhead is included. The new VJP is compared with an unchecked manual0.68 AD wrapper; not a preexisting0.68 functional API. No nativeTorch, GPU, cold-start or universal speedup claim.')
if __name__=='__main__':print(json.dumps(run(sys.argv[1],sys.argv[2],int(sys.argv[3])),indent=2))
