from pathlib import Path
import shutil,json,hashlib
r=Path(__file__).resolve().parent;release=r/'versioned-release';old=r/'guarded-proof/wasm-proof';out=release/'wasm-proof';chrome=out/'chrome-contracts';chrome.mkdir(parents=True,exist_ok=True);source=release/'snapshot/packages/stridetorch/src/stridetorch';tests=release/'snapshot/packages/stridetorch/tests';sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
for name in ['index.html','run.mjs','worker.mjs']:shutil.copy2(old/'chrome-contracts'/name,chrome/name)
shutil.copytree(source,chrome/'source',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
(chrome/'tests').mkdir(exist_ok=True)
for q in tests.glob('test_*.py'):
 if q.name!='test_standalone.py':shutil.copy2(q,chrome/'tests'/q.name)
for name in ['probe-model-vjp.py','compare-model-vjp.py','model-native.json']:shutil.copy2(r/name,chrome/name)
shutil.copy2(release/'package-proof/source-hashes.json',chrome/'guarded-candidate-source-hashes.json')
(chrome/'model-run.py').write_text("""import runpy,sys,json,pathlib
previous_args=sys.argv[:]
try:
 sys.argv=['/runtime/probe-model-vjp.py','candidate','/runtime/model-candidate.json']
 runpy.run_path('/runtime/probe-model-vjp.py',run_name='__main__')
 try:runpy.run_path('/runtime/compare-model-vjp.py',run_name='__main__')
 except SystemExit as error:
  if error.code not in (0,None):raise RuntimeError('Native model VJP qualification failed')
finally:sys.argv=previous_args
model_qualification=json.loads(pathlib.Path('/runtime/model-qualification.json').read_text())
assert model_qualification['status']=='passed' and model_qualification['cases']==368
""")
model_files={name:sha(chrome/name) for name in ['probe-model-vjp.py','compare-model-vjp.py','model-native.json','guarded-candidate-source-hashes.json','model-run.py']};plan=dict(source=json.loads((release/'package-proof/source-hashes.json').read_text()),tests={q.name:sha(q) for q in sorted((chrome/'tests').glob('*.py'))},version='0.69.0',expected=8165,model_files=model_files);(chrome/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
p=chrome/'run.mjs';p.write_text(p.read_text().replace('/guarded-proof/','/versioned-release/'))
p=chrome/'worker.mjs';s=p.read_text();needle=" py.globals.set('plan_json',JSON.stringify(plan));";extra=" for(const name of Object.keys(plan.model_files))py.FS.writeFile('/runtime/'+name,await(await fetch('./'+name)).text());\n";assert needle in s;s=s.replace(needle,extra+needle)
s=s.replace("import pytest,stridetorch,numpy", "for name,expected in plan['model_files'].items():assert hashlib.sha256(pathlib.Path('/runtime',name).read_bytes()).hexdigest()==expected\nimport pytest,stridetorch,numpy")
s=s.replace("json.dumps(dict(status='success',library=", "exec(compile(pathlib.Path('/runtime/model-run.py').read_text(),'/runtime/model-run.py','exec'))\njson.dumps(dict(status='success',model_qualification=model_qualification,model_candidate=json.loads(pathlib.Path('/runtime/model-candidate.json').read_text()),library=");p.write_text(s)
s=(old/'wasm-contracts.mjs').read_text().replace('/guarded-proof/','/versioned-release/').replace('/torch-iteration-69/candidate-source/stridetorch','/torch-iteration-69/versioned-release/snapshot/packages/stridetorch/src/stridetorch').replace("__version__=='0.68.0'","__version__=='0.69.0'").replace('==8147','==8165')
needle="py.globals.set('expected_hashes',JSON.stringify(hashes));";extra="const modelPlan=JSON.parse(fs.readFileSync(new URL('chrome-contracts/plan.json',import.meta.url)));for(const name of Object.keys(modelPlan.model_files))py.FS.writeFile('/runtime/'+name,fs.readFileSync(new URL('chrome-contracts/'+name,import.meta.url)));py.globals.set('model_plan_json',JSON.stringify(modelPlan));\n";assert needle in s;s=s.replace(needle,extra+needle)
s=s.replace("previous_error_mode=numpy.seterr(all='raise')", "model_plan=json.loads(model_plan_json)\nfor name,expected in model_plan['model_files'].items():assert hashlib.sha256(pathlib.Path('/runtime',name).read_bytes()).hexdigest()==expected\nexec(compile(pathlib.Path('/runtime/model-run.py').read_text(),'/runtime/model-run.py','exec'))\nprevious_error_mode=numpy.seterr(all='raise')")
s=s.replace('json.dumps(dict(numpy_fenv_traps=', "json.dumps(dict(model_qualification=model_qualification,model_candidate=json.loads(pathlib.Path('/runtime/model-candidate.json').read_text()),numpy_fenv_traps=")
(out/'wasm-contracts.mjs').write_text(s)
s=(old/'run.py').read_text().replace("r.parent.parent/'guarded-candidate-source-hashes.json'","r.parent/'package-proof/source-hashes.json'").replace('==8147','==8165').replace("=='0.68.0'","=='0.69.0'")
s=s.replace("result['library']=='0.69.0'", "result['library']=='0.69.0'\n assert result['model_qualification']['status']=='passed' and result['model_qualification']['cases']==368")
(out/'run.py').write_text(s);print('Prepared versioned0.69 real Node/Chrome:',len(plan['tests']),'SDK suites and368 independent native-model fixtures.')
