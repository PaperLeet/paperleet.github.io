import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const repo='/Users/david/Developer/PaperLeet-torch-release';
const source="/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-69/versioned-release/snapshot/packages/stridetorch/src/stridetorch";
const py=await loadPyodide({indexURL:path.join(repo,'web/node_modules/pyodide/'),packageCacheDir:path.join(repo,'web/public/browser-runtime/pyodide-0.29.4/'),stdout:console.log,stderr:console.error});
await loadJudgePackages(py,[]);py.FS.mkdirTree('/runtime/stridetorch');
const hashes={};
for(const name of fs.readdirSync(source).filter(name=>name.endsWith('.py')||['LICENSE','NOTICE'].includes(name))){
 const bytes=fs.readFileSync(path.join(source,name));
 py.FS.writeFile('/runtime/stridetorch/'+name,bytes);
 hashes[name]=crypto.createHash('sha256').update(bytes).digest('hex');
}
const suites=fs.readdirSync('/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-69/versioned-release/wasm-proof/chrome-contracts/tests').filter(n=>n.endsWith('.py')).map(n=>n.slice(5,-3)).sort();
for(const name of suites)py.FS.writeFile('/runtime/test_'+name+'.py',fs.readFileSync(path.join("/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-69/versioned-release/wasm-proof/chrome-contracts/tests",'test_'+name+'.py'),'utf8'));
const modelPlan=JSON.parse(fs.readFileSync(new URL('chrome-contracts/plan.json',import.meta.url)));for(const name of Object.keys(modelPlan.model_files))py.FS.writeFile('/runtime/'+name,fs.readFileSync(new URL('chrome-contracts/'+name,import.meta.url)));py.globals.set('model_plan_json',JSON.stringify(modelPlan));
py.globals.set('expected_hashes',JSON.stringify(hashes));py.globals.set('test_paths',suites.map(name=>'/runtime/test_'+name+'.py').join('|'));
const result=JSON.parse(py.runPython(`
import sys,json,pathlib,hashlib
sys.path.insert(0,'/runtime')
actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path('/runtime/stridetorch').iterdir() if p.is_file()}
assert actual==json.loads(expected_hashes)
import pytest,stridetorch,numpy
assert stridetorch.__version__=='0.69.0'
class Results:
    passed=0
    def pytest_runtest_logreport(self,report):
        if report.when=='call' and report.passed:self.passed+=1
record=Results()
code=pytest.main([*test_paths.split('|'),'-q','--noconftest','-p','no:cacheprovider','--import-mode=importlib'],plugins=[record])
assert int(code)==0 and record.passed==8163,(code,record.passed)
model_plan=json.loads(model_plan_json)
for name,expected in model_plan['model_files'].items():assert hashlib.sha256(pathlib.Path('/runtime',name).read_bytes()).hexdigest()==expected
exec(compile(pathlib.Path('/runtime/model-run.py').read_text(),'/runtime/model-run.py','exec'))
previous_error_mode=numpy.seterr(all='raise')
try:
    try: numpy.divide(1.,0.)
    except FloatingPointError: numpy_fenv_traps=True
    else: numpy_fenv_traps=False
finally: numpy.seterr(**previous_error_mode)
json.dumps(dict(model_qualification=model_qualification,model_candidate=json.loads(pathlib.Path('/runtime/model-candidate.json').read_text()),numpy_fenv_traps=numpy_fenv_traps,library=stridetorch.__version__,numpy=numpy.__version__,passed=record.passed,source_hashes=actual))
`));
assert.equal(result.numpy,'2.2.5');fs.writeFileSync(new URL('source-wasm.json',import.meta.url),JSON.stringify(result,null,2));
console.log('PASS actual Pyodide',py.version,result.library,result.passed,'contracts and source hashes');
