import runpy,sys,json,pathlib
previous_args=sys.argv[:]
try:
 sys.argv=['/runtime/probe-model-vjp.py','candidate','/runtime/model-candidate.json']
 runpy.run_path('/runtime/probe-model-vjp.py',run_name='__main__')
 try:runpy.run_path('/runtime/compare-model-vjp.py',run_name='__main__')
 except SystemExit as error:
  if error.code not in (0,None):raise RuntimeError('Native model VJP qualification failed')
finally:sys.argv=previous_args
model_qualification=json.loads(pathlib.Path('/runtime/model-qualification.json').read_text())
assert model_qualification['status']=='passed' and model_qualification['cases']==368
