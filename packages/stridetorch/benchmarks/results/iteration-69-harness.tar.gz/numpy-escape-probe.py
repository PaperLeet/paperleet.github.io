import json,sys,numpy as np
if sys.argv[1]=='native':import torch
else:from stridetorch import torch
x=torch.tensor([2.,3.]);rows=[]
def permitted_without_grad(a):
 with torch.no_grad():data=np.sin(a.numpy())
 return torch.tensor(data)
for name,fn in [('numpy_escape',lambda a:torch.tensor(np.sin(a.numpy()))),('asarray_escape',lambda a:torch.tensor(np.sin(np.asarray(a)))),('detached_numpy',lambda a:torch.tensor(np.sin(a.detach().numpy()))),('numpy_under_no_grad',permitted_without_grad)]:
 try:
  out,g=torch.autograd.functional.vjp(fn,x,torch.ones_like(x));rows.append(dict(case=name,success=True,output=out.tolist(),gradient=g.tolist()))
 except Exception as error:rows.append(dict(case=name,success=False,error_type=type(error).__name__,message=str(error)))
print(json.dumps(dict(backend=sys.argv[1],rows=rows),indent=2))
