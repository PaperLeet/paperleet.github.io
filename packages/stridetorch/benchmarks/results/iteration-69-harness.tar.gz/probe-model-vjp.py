"""Shared exact-input functional VJP fixtures, run in distinct native/candidate processes."""
from pathlib import Path
import sys,json,hashlib,warnings
import numpy as np
if sys.argv[1]=='native':
 import torch as t
 version=t.__version__;engine_git=t.version.git_version
else:
 import stridetorch
 t=stridetorch.torch;version=stridetorch.__version__;engine_git=None
warnings.filterwarnings('ignore',message='To copy construct from a tensor')

names=['linear','layernorm','groupnorm','conv2d','attention','mha_captured','inverse','cholesky','slogdet','cross_entropy','mixed_outputs','tensor_copy','as_tensor_identity','as_tensor_dtype','clone','view_slice','zero_connected','scalar','empty','same_output_twice','aliased_inputs','from_numpy_detached','integer_output']

def build(name,dtype,requires,strided,rng):
 td=getattr(t,dtype);dt=np.dtype(dtype);params=[]
 def array(shape):return (rng.normal(size=shape)*.3).astype(dt)
 def tensor(data):
  data=np.asarray(data,dtype=dt)
  if strided and data.ndim>=2:
   return t.tensor(data.swapaxes(-1,-2).copy(),dtype=td,requires_grad=requires).transpose(-1,-2)
  return t.tensor(data,dtype=td,requires_grad=requires)
 def args(*shapes):return tuple(tensor(array(shape)) for shape in shapes)
 f=t.nn.functional
 if name=='linear':return lambda a,w,b:f.linear(a,w,b),args((2,3),(4,3),(4,)),params
 if name=='layernorm':return lambda a,w,b:f.layer_norm(a,(4,),w,b,eps=1e-5),args((2,3,4),(4,),(4,)),params
 if name=='groupnorm':return lambda a,w,b:f.group_norm(a,2,w,b,eps=1e-5),args((2,4,3),(4,),(4,)),params
 if name=='conv2d':return lambda a,w,b:f.conv2d(a,w,b,padding=1),args((1,2,4,5),(3,2,3,3),(3,)),params
 if name=='attention':return lambda q,k,v:f.scaled_dot_product_attention(q,k,v,dropout_p=0),args((1,2,3,4),(1,2,5,4),(1,2,5,4)),params
 if name=='mha_captured':
  model=t.nn.MultiheadAttention(4,2,batch_first=True,dropout=0,dtype=td);params=list(model.parameters())
  with t.no_grad():
   for index,p in enumerate(params):p.copy_(t.tensor((np.sin(np.arange(p.numel())*.37+index)*.2).reshape(tuple(p.shape)),dtype=td))
  return lambda a:model(a,a,a,need_weights=False)[0],args((2,3,4),),params
 if name in ['inverse','slogdet']:
  a=array((3,3));a=a@a.T+np.eye(3,dtype=dt)*1.7
  return (t.linalg.inv if name=='inverse' else t.linalg.slogdet),(tensor(a),),params
 if name=='cholesky':return lambda a:t.linalg.cholesky(a@a.T+t.eye(3,dtype=td)*1.7),args((3,3),),params
 if name=='cross_entropy':
  labels=t.tensor([0,3,1],dtype=t.int64)
  return lambda a:f.cross_entropy(a,labels,label_smoothing=.17),args((3,5),),params
 if name=='mixed_outputs':return lambda a,b:((a*b).sin(),(a.square()+b).mean(),a.detach()*2),args((2,3),(3,)),params
 if name=='tensor_copy':return lambda a:t.tensor(a),args((2,3),),params
 if name=='as_tensor_identity':return lambda a:t.as_tensor(a),args((2,3),),params
 if name=='as_tensor_dtype':return lambda a:t.as_tensor(a,dtype=t.float64 if dtype=='float32' else t.float32),args((2,3),),params
 if name=='clone':return lambda a:a.clone(),args((2,3),),params
 if name=='view_slice':return lambda a:a.T[:,::2],args((2,3),),params
 if name=='zero_connected':return lambda a:(a*0).sum(),args((2,3),),params
 if name=='scalar':return lambda a:a.sin()*a.square(),(tensor(np.array(.43,dtype=dt)),),params
 if name=='empty':return lambda a,b:(a*b).sum(0),args((0,3),(3,)),params
 if name=='same_output_twice':
  def function(a):
   y=a.sin();return y,y
  return function,args((2,3),),params
 if name=='aliased_inputs':
  a=tensor(array((2,3)));return lambda a,b:a@b,(a,a.T),params
 if name=='from_numpy_detached':return lambda a:t.from_numpy(np.cos(a.detach().numpy())),args((2,3),),params
 if name=='integer_output':return lambda a:t.ones_like(a,dtype=t.int64),args((2,3),),params
 raise AssertionError(name)

def encode(value):
 if isinstance(value,t.Tensor):return dict(kind='tensor',dtype=str(value.dtype).replace('torch.',''),shape=list(value.shape),requires_grad=bool(value.requires_grad),values=value.detach().cpu().numpy().tolist())
 return dict(kind='tuple',items=[encode(item) for item in value])

def arrays(value):return [value] if isinstance(value,t.Tensor) else list(value)
rows=[]
for ni,name in enumerate(names):
 for di,dtype in enumerate(['float32','float64']):
  for requires in [False,True]:
   for strided in [False,True]:
    for strict in [False,True]:
     ident=f'{name}/{dtype}/requires{int(requires)}/strided{int(strided)}/strict{int(strict)}';stage='build';rng=np.random.default_rng(5937+ni*97+di*13+int(requires)*7+int(strided)*3);row=dict(id=ident,operation=name,dtype=dtype,strict=strict)
     try:
      fn,inputs,params=build(name,dtype,requires,strided,rng);saved=[];hooks=[]
      for i,x in enumerate([*inputs,*params]):
       x.grad=t.full_like(x,19+i);saved.append((x,x.detach().cpu().numpy().copy(),x.grad.detach().cpu().numpy().copy(),bool(x.requires_grad),tuple(x.stride())))
       if x.requires_grad:x.register_hook(lambda gradient:hooks.append('caller'))
      stage='seed_metadata'
      with t.no_grad():meta=fn(*inputs)
      seed_dtype='float64' if dtype=='float32' else 'float32';seeds=[t.tensor(rng.normal(size=tuple(out.shape)).astype(seed_dtype),dtype=getattr(t,seed_dtype)) for out in arrays(meta)];v=tuple(seeds) if isinstance(meta,tuple) else seeds[0];calls=[]
      def function(*args):calls.append(1);return fn(*args)
      stage='vjp';outputs,gradients=t.autograd.functional.vjp(function,inputs,v,strict=strict)
      assert calls==[1] and hooks==[]
      for x,data,gradient,flag,strides in saved:
       np.testing.assert_array_equal(x.detach().cpu().numpy(),data);np.testing.assert_array_equal(x.grad.detach().cpu().numpy(),gradient);assert bool(x.requires_grad)==flag and tuple(x.stride())==strides
      out_arrays=[value.detach().cpu().numpy() for value in arrays(outputs)];in_arrays=[value.detach().cpu().numpy() for value in inputs]
      row.update(success=True,output=encode(outputs),gradient=encode(gradients),caller_state_preserved=True,output_input_aliases=[[bool(np.shares_memory(a,b)) for b in in_arrays] for a in out_arrays],output_output_aliases=[[bool(np.shares_memory(a,b)) for b in out_arrays] for a in out_arrays])
     except Exception as error:row.update(success=False,stage=stage,error_type=type(error).__name__,message=str(error))
     rows.append(row)
report=dict(backend=sys.argv[1],version=version,torch_git=engine_git,numpy=np.__version__,program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows,scope='Deterministic exact-input first-order functional VJP fixtures across23 operations, float32/64, original grad flags, strided inputs and strict modes. Opposite seed dtype; output/input storage relationships, caller hooks/gradients/flags/strides and one invocation checked. Not a latency, higher-derivative or full-Torch compatibility claim.')
Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n');print(sys.argv[1],len(rows),'cases',sum(row['success'] for row in rows),'success',sum(not row['success'] for row in rows),'rejections',flush=True)
