import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {createGpuEngine,servePort,LIMITS} from './candidate/gpu-service.mjs';
import {MatrixRpc} from './candidate/rpc-client.mjs';
const rows=[];
function request({retain=true,read=true}={}){return {id:1,op:'program',inputs:[{rows:2,cols:2,data:new Float32Array([1,2,3,4]).buffer},{rows:2,cols:2,data:new Float32Array([1,0,0,1]).buffer}],nodes:[{a:0,b:1,transposeA:false,transposeB:false}],outputs:[{ref:2,read,retain}]};}
function fakeGpu(){
  const controls={point:null,allocation:0,trace:[],live:new Set(),held:null,failDrain:false,triggered:false};
  const hit=name=>{controls.trace.push(name);if(controls.point===name){controls.triggered=true;controls.point=null;throw new Error('Injected '+name);}};
  let lostResolve;const lost=new Promise(resolve=>lostResolve=resolve);
  const device={lost,
    pushErrorScope(){hit('push');},async popErrorScope(){hit('pop');if(controls.point==='validation'){controls.point=null;controls.triggered=true;return {message:'Injected validation'};}return null;},
    createShaderModule(){return {};},async createComputePipelineAsync(){return {getBindGroupLayout:()=>({})};},createBindGroup(){hit('bind');return {};},
    createBuffer({size}){hit('allocate:'+ ++controls.allocation);const buffer={memory:new ArrayBuffer(size),destroyed:false,
      destroy(){if(!buffer.destroyed){buffer.destroyed=true;controls.live.delete(buffer);controls.trace.push('destroy');}},
      async mapAsync(){hit('map');if(controls.held)await controls.held.promise;},
      getMappedRange(){hit('range');return buffer.memory;},unmap(){hit('unmap');}};controls.live.add(buffer);return buffer;},
    createCommandEncoder(){hit('encode');return {beginComputePass(){hit('pass');return {setPipeline(){},setBindGroup(){},dispatchWorkgroups(){hit('dispatch');},end(){}};},copyBufferToBuffer(){hit('copy');},finish(){hit('finish');return {};}};},
    queue:{writeBuffer(buffer,offset,data){hit('write');new Uint8Array(buffer.memory).set(new Uint8Array(data.buffer||data,data.byteOffset||0,data.byteLength),offset);},
      submit(){hit('submit');},async onSubmittedWorkDone(){hit('fence');if(controls.failDrain)throw new Error('Injected fence failure');if(controls.held)await controls.held.promise;}},
    destroy(){for(const buffer of [...controls.live])buffer.destroy();controls.held?.reject(new Error('Destroyed'));lostResolve({reason:'destroyed'});}};
  return {device,controls,gpu:{requestAdapter:async()=>({info:{vendor:'fake'},requestDevice:async()=>device})}};
}
async function fixture(test,{changes={}}={}){
  const fake=fakeGpu(),names=['navigator','GPUBufferUsage','GPUMapMode','isSecureContext'];
  const old=Object.fromEntries(names.map(name=>[name,Object.getOwnPropertyDescriptor(globalThis,name)]));
  const globals={navigator:{gpu:fake.gpu},GPUBufferUsage:{STORAGE:1,COPY_SRC:2,COPY_DST:4,UNIFORM:8,MAP_READ:16},GPUMapMode:{READ:1},isSecureContext:true};
  for(const name of names)Object.defineProperty(globalThis,name,{value:globals[name],configurable:true});
  let engine;
  try{
    engine=await createGpuEngine({...LIMITS,...changes});
    const existing=await engine.execute({id:0,op:'upload',rows:2,cols:2,data:new Float32Array([7,8,9,10]).buffer});
    fake.controls.trace=[];fake.controls.allocation=0;
    await test({engine,existing,...fake});
  }finally{engine?.close();assert.equal(fake.controls.live.size,0);for(const name of names)old[name]?Object.defineProperty(globalThis,name,old[name]):delete globalThis[name];}
}
async function check(name,test,options){await fixture(test,options);rows.push({name,passed:true});}


for(const [operation,point] of [['upload','write'],['matmul','bind'],['read','map'],['program','bind']]){
 await fixture(async({engine,existing,controls})=>{
  const channel=new MessageChannel(),service=servePort(channel.port1,engine),client=new MatrixRpc(channel.port2);await client.ready;
  const held={};held.promise=new Promise((resolve,reject)=>{held.resolve=resolve;held.reject=reject;});controls.held=held;controls.point=point;
  const requestValue=operation==='program'?request():operation==='upload'?{op:operation,rows:2,cols:2,data:new ArrayBuffer(16)}:operation==='matmul'?{op:operation,a:existing.handle,b:existing.handle,transposeA:false,transposeB:false}:{op:operation,handle:existing.handle};
  const {id:_,op,...fields}=requestValue,ticket=client.send(op,fields);const outcome=ticket.promise.then(()=>({status:'resolved'}),error=>({status:'rejected',code:error.code}));
  try{
   for(let i=0;i<100&&!controls.trace.includes('fence');i++)await new Promise(resolve=>setTimeout(resolve,1));assert(controls.trace.includes('fence'));
   const cancellation=await client.cancel(ticket.id);assert.equal(cancellation.cancelled,true);assert(!controls.trace.includes('destroy'));
   const queuedStats=client.stats();controls.held=null;held.resolve();const observed=await outcome,stats=await queuedStats;assert.equal(stats.total_bytes,16);assert.equal(stats.resident_handles,1);
   if(process.argv.includes('--expect-cancelled'))assert.equal(observed.code,'Cancelled');rows.push({operation,point,cancellation,outcome:observed,stats,trace:controls.trace.slice(),passed:observed.code==='Cancelled'});
  }finally{controls.held=null;held.resolve();await service.close('done');client.fail(Object.assign(new Error('done'),{code:'Closed'}));}
 });
}
const file=process.argv.includes('--expect-cancelled')?'cancel-failure-candidate.json':'cancel-failure-baseline.json';const report={source_sha256:createHash('sha256').update(fs.readFileSync(new URL('./candidate/gpu-service.mjs',import.meta.url))).digest('hex'),rows,scope:'Injected failure while queue drain is held; acknowledged cancellation and subsequent request ownership.'};fs.writeFileSync(new URL('./'+file,import.meta.url),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(rows.map(({operation,outcome,passed})=>({operation,outcome,passed}))));
