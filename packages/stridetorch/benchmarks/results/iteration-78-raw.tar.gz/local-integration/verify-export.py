from pathlib import Path
import hashlib, json
import paperleet, stridetorch
from stridetorch import runtime
import paperleet._vendor.torch as vendored

repo = Path.cwd()
p = Path(__file__).resolve().parent
read = lambda q: json.loads(q.read_text())
sha = lambda q: hashlib.sha256(q.read_bytes()).hexdigest()
assert Path(paperleet.__file__).resolve().parent == repo / 'paperleet'
assert Path(stridetorch.__file__).resolve().parent == repo / 'packages/stridetorch/src/stridetorch'
expected = read(p / 'source-hashes.json')
for folder in [Path(stridetorch.__file__).parent, Path(vendored.__file__).parent]:
    assert {f.name: sha(f) for f in folder.iterdir() if f.suffix == '.py' or f.name in ['LICENSE', 'NOTICE']} == expected
baseline = read(p / 'immutable-assets.json')
for name, digest in baseline.items():
    assert sha(repo / name) == digest, name
data = repo / 'web/public/data'
index = read(data / 'index.json')
count = read(p / 'context.json')['catalog_modules']
assert len(index['problems']) == count
live = {}
runtimes = {}
def payload(name):
    q = data / name
    digest = sha(q)
    assert digest[:20] in q.name
    live[name] = digest
    return read(q)
for entry in index['problems']:
    payload(entry['detail_url'])
    bundle = payload(entry['browser_judge']['bundle_url'])
    assert bundle['problem'] == entry['id']
    name = bundle['runtime_bundle_url']
    body = payload(name)
    profile = 'autograd' if body['backend'] == 'numpy-autograd-wasm' else 'schedules'
    files = runtime.source_files(profile)
    assert all(body['files'].get(k) == v for k, v in files.items()), entry['id']
    runtimes[name] = dict(backend=body['backend'], package_files=len(files))
all_assets = {str(f.relative_to(repo)): sha(f) for directory in ['browser-judge', 'modules']
              for f in (data / directory).glob('*.json')}
new = {name: digest for name, digest in all_assets.items() if name not in baseline}
assert all(str(Path(name).relative_to('web/public/data')) in live for name in new)
for name in ['index.json', 'index-v3.json', 'catalog.json']:
    live[name] = sha(data / name)
for name, value in [('export-identity.json', dict(status='success', version=stridetorch.__version__,
    source_hashes=expected, preserved_assets=len(baseline), new_assets=len(new),
    active_export_and_index_hashes=len(live), catalog_modules=count, all_new_assets_reachable=True,
    runtimes=runtimes)), ('live-export-sha256.json', live), ('new-assets-sha256.json', new)]:
    (p / name).write_text(json.dumps(value, indent=2) + '\n')
print('Verified', count, 'modules;', len(baseline), 'preserved assets;', len(new),
      'new reachable assets;', len(live), 'live identities')
