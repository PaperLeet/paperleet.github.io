from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
python=p.parent.parent/'torch-iteration-69/integration-dev-env/bin/python';node='/Users/david/.npm/_npx/d18f28baf1132559/node_modules/node/bin/node'
env=dict(os.environ,PYTHON=str(python),PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=os.pathsep.join([str(repo/'packages/stridetorch/src'),str(repo)]),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
env['PATH']=str(Path(node).parent)+':/opt/homebrew/bin:'+str(python.parent)+':'+env['PATH']
assert subprocess.check_output([node,'--version'],text=True).strip()=='v22.23.3'
context=json.loads((p/'context.json').read_text());source=context['source_hashes'];receipts=[]
def verify():
    for name,digest in source.items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==digest,name
    for file in ['policy-identity.json','application-inputs.json','immutable-assets.json']:
        for name,digest in json.loads((p/file).read_text()).items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
def run(label,args,cwd=repo,extra=None):
    verify();start=time.monotonic()
    with (p/(label+'.log')).open('w') as log:
        child=subprocess.Popen(args,cwd=cwd,env={**env,**(extra or {})},stdout=log,stderr=subprocess.STDOUT)
        (p/'gate-progress.json').write_text(json.dumps(dict(status='running',label=label,pid=child.pid,receipts=receipts),indent=2)+'\n')
        code=child.wait()
    receipt=dict(label=label,exit_code=code,seconds=time.monotonic()-start,command=args,cwd=str(cwd),log_sha256=hashlib.sha256((p/(label+'.log')).read_bytes()).hexdigest(),summary=(p/(label+'.log')).read_text().splitlines()[-1:])
    receipts.append(receipt);(p/'gate-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(receipt),flush=True)
    if code:raise SystemExit(code)
    verify()
run('full-wasm',[node,'web/scripts/check-browser-wasm.mjs','--all'])
wasm=json.loads((repo/'reports/browser-wasm.json').read_text());assert wasm['passed'] and wasm['modules']==wasm['catalog_modules']==context['catalog_modules'] and not wasm['browser_budget_exceeded']
(p/'full-wasm-result.json').write_text(json.dumps(wasm,indent=2)+'\n')
run('full-frontend-check',['npm','run','check'],repo/'web')
run('wasm-driver',[node,'web/scripts/check-wasm-cases.mjs'])
run('pages-policy',[node,'web/scripts/check-pages-release.cjs'])
run('build',['npm','run','build'],repo/'web')
value=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED','--jq','.value'],cwd=repo,text=True).strip();assert value in ['0','1']
profile=dict(PAPERLEET_MAIN_SITE_ENABLED=value,VITE_PUBLIC_SITE='0' if value=='1' else '1',VITE_APP_EDITION='hosted' if value=='1' else 'local',VITE_API_ORIGIN='https://app.paperleet.com' if value=='1' else '',VITE_HOSTED_APP_AVAILABLE='1',VITE_HOSTED_APP_URL='https://app.paperleet.com')
(p/'current-pages-profile.json').write_text(json.dumps(profile,indent=2)+'\n');run('pages-profile-build',['npm','run','build'],repo/'web',profile)
verify();(p/'gate-progress.json').write_text(json.dumps(dict(status='completed',receipts=receipts),indent=2)+'\n')
(p/'gates-result.json').write_text(json.dumps(dict(status='passed',source_hashes=source,upstream=context['upstream'],receipts=receipts,modules=wasm['modules'],mutants=sum(v['mutants'] for v in wasm['results']),ci_triggered=False,published=False,deployed=False),indent=2)+'\n')
print('ALL LOCAL APPLICATION GATES PASSED',flush=True)
