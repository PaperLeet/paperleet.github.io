import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
import {loadJudgePackages} from '../torch-iteration-76/chrome-sdk/packages.mjs';
self.onmessage=async()=>{
 try{
  const plan=await(await fetch('./core-wasm-plan.json')).json(),py=await loadPyodide({indexURL:new URL('../torch-iteration-76/runtime/',self.location.href).href,stdout(){},stderr(){}});await loadJudgePackages(py,[]);
  for(const [name,digest]of Object.entries(plan.files)){
   const bytes=new Uint8Array(await(await fetch('./'+name)).arrayBuffer());const actual=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),v=>v.toString(16).padStart(2,'0')).join('');if(actual!==digest)throw Error('Source mismatch: '+name);
   const target=name.startsWith('tests/')?'/contracts/'+name.slice(6):'/'+name;py.FS.mkdirTree(target.split('/').slice(0,-1).join('/'));py.FS.writeFile(target,bytes);
  }
  py.runPython("import sys\nsys.path[:0]=['/core-candidate','/']");py.runPython("exec(compile(open('/core-wasm-check.py').read(),'/core-wasm-check.py','exec'))");
  const report=JSON.parse(py.runPython('json.dumps(wasm_report)'));self.postMessage({...report,files:plan.files,pyodide:py.version,expected_sdk:plan.expected_sdk});
 }catch(error){self.postMessage({status:'failed',error:String(error),stack:error.stack});}
};
