import fs from 'node:fs';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
import {loadJudgePackages} from '../torch-iteration-76/chrome-sdk/packages.mjs';
try{
 const root=new URL('./',import.meta.url),plan=JSON.parse(fs.readFileSync(new URL('core-wasm-plan.json',root)));
 const py=await loadPyodide({indexURL:new URL('../torch-iteration-76/runtime/',root).pathname,stdout(){},stderr(){}});await loadJudgePackages(py,[]);
 for(const [name,digest]of Object.entries(plan.files)){
  const bytes=fs.readFileSync(new URL(name,root));assert.equal(createHash('sha256').update(bytes).digest('hex'),digest);
  const target=name.startsWith('tests/')?'/contracts/'+name.slice(6):'/'+name;py.FS.mkdirTree(target.split('/').slice(0,-1).join('/'));py.FS.writeFile(target,bytes);
 }
 py.runPython("import sys\nsys.path[:0]=['/core-candidate','/']");py.runPython("exec(compile(open('/core-wasm-check.py').read(),'/core-wasm-check.py','exec'))");
 const result=JSON.parse(py.runPython('json.dumps(wasm_report)'));
 const report={...result,files:plan.files,pyodide:py.version,node:process.version};fs.writeFileSync(new URL('core-node-result.json',root),JSON.stringify(report,null,2)+'\n');
 assert.equal(report.status,'passed',JSON.stringify(report.sdk.failures));assert.equal(report.sdk.passed,plan.expected_sdk);console.log(JSON.stringify({status:report.status,native:report.native,guards:report.guard_cases,sdk_passed:report.sdk.passed}));
}catch(error){console.error(String(error));process.exitCode=1;}
