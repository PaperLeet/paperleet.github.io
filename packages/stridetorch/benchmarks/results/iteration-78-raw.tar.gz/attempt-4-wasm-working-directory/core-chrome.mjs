import fs from 'node:fs';import assert from 'node:assert/strict';
import {withFixtureServer} from '../torch-iteration-70/fixture-server.mjs';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
await withFixtureServer(async origin=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 try{
  const page=await browser.newPage();await page.goto(origin+'/torch-iteration-78/index.html');
  const result=await page.evaluate(()=>new Promise((resolve,reject)=>{const worker=new Worker('./core-worker.mjs',{type:'module'}),timer=setTimeout(()=>{worker.terminate();reject(Error('SDK qualification timeout'));},360000);worker.onmessage=({data})=>{clearTimeout(timer);worker.terminate();resolve(data);};worker.onerror=error=>{clearTimeout(timer);worker.terminate();reject(Error(error.message));};worker.postMessage({});}));
  fs.writeFileSync(new URL('core-chrome-result.json',import.meta.url),JSON.stringify({...result,browser:browser.version()},null,2)+'\n');assert.equal(result.status,'passed',JSON.stringify(result.sdk?.failures||result));assert.equal(result.sdk.passed,result.expected_sdk);console.log(JSON.stringify({status:result.status,native:result.native,guards:result.guard_cases,sdk_passed:result.sdk.passed,browser:browser.version()}));
 }finally{await browser.close();}
});
