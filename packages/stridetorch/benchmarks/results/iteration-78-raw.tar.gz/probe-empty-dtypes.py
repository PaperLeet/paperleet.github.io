"""Native metadata-only bmm behavior for every supported dtype pair."""
import json,sys,warnings
from pathlib import Path
import numpy as np


def qualify_empty(torch):
    dtypes=['bool','uint8','int8','int16','int32','int64','uint16','uint32','uint64','float16','float32','float64','complex64','complex128']
    rows=[]
    for da in dtypes:
        for db in dtypes:
            for sa,sb in [((2,0,3),(2,3,4)),((2,3,0),(2,0,4)),((2,3,4),(2,4,0)),((0,3,4),(0,4,2))]:
                source=np.full(sa,complex(np.nan,np.inf) if np.dtype(da).kind=='c' else np.nan if np.dtype(da).kind=='f' else 1,dtype=da)
                a=torch.from_numpy(source);b=torch.from_numpy(np.ones(sb,dtype=db))
                with warnings.catch_warnings(record=True) as messages:
                    warnings.simplefilter('always');value=torch.bmm(a,b).numpy()
                rows.append(dict(dtype_a=da,dtype_b=db,shape_a=sa,shape_b=sb,result_dtype=value.dtype.str,result_shape=value.shape,zero=bool(np.all(value==0)),warnings=len(messages)))
    return rows


if __name__=='__main__':
    if '--native' in sys.argv:
        import torch
        torch.set_num_threads(2)
        rows=qualify_empty(torch);Path('empty-dtype-native.json').write_text(json.dumps(dict(torch=torch.__version__,rows=rows),indent=2)+'\n')
    else:
        from stridetorch import torch
        rows=qualify_empty(torch);assert json.loads(json.dumps(rows))==json.loads(Path('empty-dtype-native.json').read_text())['rows']
        Path('empty-dtype-candidate.json').write_text(json.dumps(dict(status='passed',rows=rows),indent=2)+'\n')
    assert len(rows)==784 and all(r['zero'] and not r['warnings'] for r in rows)
    print(json.dumps(dict(status='passed',cases=len(rows),warnings=0)))
