from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).resolve().parent;r=p.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
subprocess.run(['/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-69/integration-dev-env/bin/python','-B',str(p/'verify-commit.py'),'final-qualified-git-blobs.json','final-git-blob-verification.json'],cwd=repo,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=repo,text=True).split()[0]
api_remote=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/git/ref/heads/main','--jq','.object.sha'],cwd=repo,text=True).strip();assert head==remote==api_remote
source=json.loads((p/'source-main-adoption.json').read_text())['source_commit'];assert subprocess.run(['git','merge-base','--is-ancestor',source,head],cwd=repo).returncode==0
actions={}
for sha in [source,head]:
    data=json.loads(subprocess.check_output(['gh','api',f'repos/PaperLeet/paperleet.github.io/actions/runs?head_sha={sha}&per_page=100'],cwd=repo,text=True));assert data['total_count']==0 and not data['workflow_runs'];actions[sha]=0
freeze=json.loads((r/'selected-source-freeze.json').read_text())
for name,digest in freeze['source_hashes'].items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==digest,name
worker=json.loads((r/'local-integration/generated-worker-proof.json').read_text())
assert hashlib.sha256((repo/worker['asset']).read_bytes()).hexdigest()==worker['asset_sha256']
assert hashlib.sha256((repo/worker['generated_module']).read_bytes()).hexdigest()==worker['generated_module_sha256']
for name,digest in json.loads((p/'release-policy-identity.json').read_text())['files'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
result=dict(status='verified_076_on_main',goal_status='active',main_commit=head,source_commit=source,remote_main=remote,github_api_main=api_remote,qualified_git_blobs=json.loads((p/'final-git-blob-verification.json').read_text())['qualified_git_blobs'],source_resources=62,active_exports=len(json.loads((p/'live-export-sha256.json').read_text())),prior_immutable_tree_entries=len(json.loads((r/'local-integration/immutable-assets.json').read_text())),actions_runs=actions,worktree_clean=True,ci_triggered=False,tags_created=False,published=False,deployed=False)
(p/'final-adoption-verification.json').write_text(json.dumps(result,indent=2)+'\n')
state=json.loads((r/'state.json').read_text());state.update(status=result['status'],goal_status='active',previous_goal_turn_classification='progress',main_library_version='0.76.0',main_adopted=True,main_commit=head,source_commit=source,active_processes=[],ci_triggered=False,tags_created=False,published=False,deployed=False,next_actions=['Keep BrowserTorch as a naming proposal until the user accepts it; no rename or publication yet.','Continue CPU/WASM core API and autodiff improvements against the newly adopted 0.76 baseline.','Re-evaluate experimental WebGPU resident/program benefits using 0.76 public Tensor calls and actual copy/transfer costs before choosing a supported GPU backend.','Continue core API/AD coverage and independent-package qualification; no CI/tag/release/deploy.'])
state.pop('required_before_main_adoption',None);state.pop('required_next',None);state.update(application_gates='passed',repository_changed=True,version='0.76.0');(r/'state.json').write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps(result),flush=True)
