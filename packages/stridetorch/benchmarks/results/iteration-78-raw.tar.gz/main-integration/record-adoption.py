from pathlib import Path
import hashlib,json,subprocess,time
p=Path(__file__).resolve().parent;r=p.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=repo,text=True).split()[0]
assert head==remote and not subprocess.check_output(['git','status','--porcelain','-z'],cwd=repo)
verification=json.loads((p/'commit-verification.json').read_text());assert verification['commit']==head
runs=json.loads(subprocess.check_output(['gh','api',f'repos/PaperLeet/paperleet.github.io/actions/runs?head_sha={head}&per_page=100'],cwd=repo,text=True));assert runs['total_count']==0 and runs['workflow_runs']==[]
base=json.loads((r/'selected-source-freeze.json').read_text())['upstream']
def tree(ref):
    entries=subprocess.check_output(['git','ls-tree','-r','-z',ref,'--','web/public/data/browser-judge','web/public/data/modules'],cwd=repo).decode().split('\0')
    return {entry.split('\t',1)[1]:entry.split('\t',1)[0] for entry in entries if entry}
before,after=tree(base),tree(head);immutable=json.loads((r/'local-integration/immutable-assets.json').read_text())
for name in immutable:assert before[name]==after[name],name
receipt=dict(status='verified_main_adoption',version='0.76.0',source_commit=head,remote_main=head,qualified_git_blobs=verification['qualified_git_blobs'],owned_paths=verification['owned_paths'],preserved_immutable_tree_entries=len(immutable),source_resources=62,autograd_embedded_resources=58,schedules_embedded_resources=6,active_export_identities=len(json.loads((p/'live-export-sha256.json').read_text())),actions_runs_for_source_commit=0,worktree_clean_at_verification=True,ordinary_guarded_push=True,ci_triggered=False,tags_created=False,published=False,deployed=False,execution_base=base,raw_archive=json.loads((r/'archive-verification.json').read_text()),core_source_hashes=json.loads((p/'source-hashes.json').read_text()))
(p/'source-main-adoption.json').write_text(json.dumps(receipt,indent=2)+'\n')
out=repo/'packages/stridetorch/benchmarks/results/iteration-78-main-adoption.json';out.write_text(json.dumps(receipt,indent=2)+'\n')
doc=repo/'docs/validation/torch-runtime-iteration-78.md';text=doc.read_text();assert '## Main adoption' not in text
text+='\n## Main adoption\n\n'+f"Version 0.76.0 was adopted on main at `{head}` through the unchanged guarded ordinary-push wrapper. The remote ref, clean worktree and {verification['qualified_git_blobs']:,} qualified Git blobs were verified, including exact selected source and live export identities. This receipt adds adoption evidence; the runtime had already passed the recorded local gates. All {len(immutable):,} prior immutable asset tree entries retain their Git object identities and modes. The source commit had zero Actions runs at verification. No CI, tag, package publication or deployment was initiated. [Adoption receipt](../../packages/stridetorch/benchmarks/results/iteration-78-main-adoption.json).\n"
doc.write_text(text)
(p/'source-qualified-git-blobs.json').write_bytes((p/'qualified-git-blobs.json').read_bytes())
qualified=json.loads((p/'qualified-git-blobs.json').read_text())
for q in [out,doc]:qualified[str(q.relative_to(repo))]=hashlib.sha256(q.read_bytes()).hexdigest()
(p/'final-qualified-git-blobs.json').write_text(json.dumps(qualified,indent=2)+'\n')
print(json.dumps(dict(status=receipt['status'],commit=head,actions_runs=0,preserved_assets=len(immutable))),flush=True)
