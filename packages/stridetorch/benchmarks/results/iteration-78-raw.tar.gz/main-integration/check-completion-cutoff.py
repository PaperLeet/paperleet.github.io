from pathlib import Path
import hashlib,inspect,json
from release_chain_guard import pages_after_quality_completion,ignorable_stale_queued_quality
p=Path(__file__).resolve().parent
quality=dict(status='completed',conclusion='success',head_sha='a'*40,created_at='2026-10-18T15:54:00Z',updated_at='2026-10-18T16:10:00Z')
pages=dict(name='Publish PaperLeet public site',event='workflow_run',status='completed',conclusion='skipped',head_sha='a'*40,created_at='2026-10-18T15:54:45Z')
rows=[]
def check(name,expected,*,q=None,v=None):
    result=pages_after_quality_completion({**quality,**(q or {})},{**pages,**(v or {})});assert result is expected,name;rows.append(dict(name=name,passed=True))
check('older skipped child on same default-branch SHA does not close gap',False)
check('current quality still running',False,q=dict(status='in_progress',conclusion=None))
check('child at successful completion',True,v=dict(created_at=quality['updated_at']))
check('child after successful completion',True,v=dict(created_at='2026-10-18T16:10:01Z'))
check('manual Pages after successful completion',True,v=dict(event='workflow_dispatch',created_at='2026-10-18T16:10:01Z'))
check('manual Pages before completion',False,v=dict(event='workflow_dispatch'))
check('cancelled quality',False,q=dict(conclusion='cancelled'))
check('failed quality',False,q=dict(conclusion='failure'))
check('old child before successful rerun completion',False,q=dict(updated_at='2026-10-18T16:20:00Z'),v=dict(created_at='2026-10-18T16:10:01Z'))
check('different source SHA',False,v=dict(head_sha='b'*40,created_at='2026-10-18T16:11:00Z'))
check('unknown workflow event',False,v=dict(event='push',created_at='2026-10-18T16:11:00Z'))
check('different workflow',False,v=dict(name='Other',created_at='2026-10-18T16:11:00Z'))
check('missing quality timestamp',False,q=dict(updated_at=None))
check('malformed page timestamp',False,v=dict(created_at='bad'))
check('naive timestamp rejected',False,v=dict(created_at='2026-10-18T16:11:00'))
check('timezone-aware equivalent instant',True,v=dict(created_at='2026-10-18T09:10:00-07:00'))
old=(p/'before-completion-cutoff/release_chain_guard.py').read_text();new=(p/'release_chain_guard.py').read_text();assert new.startswith(old)
wrapper=p.parent.parent/'torch-iteration-67/final-integration/push-main-native.py';provenance=json.loads((p/'guard-provenance.json').read_text());assert hashlib.sha256(wrapper.read_bytes()).hexdigest()==provenance['mandatory_wrapper_sha256']
report=dict(status='passed',cases=len(rows),rows=rows,existing_stale_queued_classifier_unchanged=True,mandatory_wrapper_unchanged=True,source_sha256={n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ['audit-main.py','release_chain_guard.py','check-completion-cutoff.py']},scope='Read-only pre-push guard strengthened; no workflow or repository mutation.')
(p/'completion-cutoff-result.json').write_text(json.dumps(report,indent=2)+'\n');provenance.update(audit_sha256=report['source_sha256']['audit-main.py'],completion_cutoff_sha256=report['source_sha256']['release_chain_guard.py'],guard_strengthening='Require Pages creation at/after the same successful completion, rejecting older skipped workflow_run children on the default-branch SHA.');(p/'guard-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n');print(json.dumps(dict(status='passed',cases=len(rows),mandatory_wrapper_unchanged=True)))
