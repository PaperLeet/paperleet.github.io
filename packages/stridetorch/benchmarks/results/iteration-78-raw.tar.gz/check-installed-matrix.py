"""Exercise the installed public CLI and both installed alias namespaces."""
import importlib,importlib.util,json,os,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
assert importlib.util.find_spec('torch') is None
rows=[]
for name in ['stridetorch','paperleet._vendor.torch']:
    module=importlib.import_module(name)
    assert module.__version__=='0.76.0'
    with module.as_torch():
        import torch
        a=torch.ones(2,3,requires_grad=True);b=torch.ones(3,4,requires_grad=True)
        torch.mm(input=a,mat2=b).sum().backward()
        assert a.grad.tolist()==[[4.]*3]*2 and b.grad.tolist()==[[2.]*4]*3
        x=torch.ones(2,2,3,requires_grad=True);w=torch.ones(2,3,4,requires_grad=True)
        torch.bmm(input=x,mat2=w).sum().backward()
        assert x.grad.tolist()==[[[4.]*3]*2]*2 and w.grad.tolist()==[[[2.]*4]*3]*2
        rows.append(dict(namespace=name,module=type(a).__module__,version=module.__version__))
assert importlib.util.find_spec('torch') is None
script=root/'installed-matrix-cli.py'
script.write_text('import json,sys,torch\na=torch.ones(2,2,3,requires_grad=True);b=torch.ones(2,3,4)\ny=a.bmm(mat2=b);y.sum().backward()\nassert a.grad.tolist()==[[[4.]*3]*2]*2\nassert sys.argv[1:]==["--marker","unchanged"]\nprint(json.dumps(dict(module=type(a).__module__,shape=list(y.shape),sum=y.sum().item())))\n')
environment=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');environment.pop('PYTHONPATH',None)
value=json.loads(subprocess.check_output([str(Path(sys.executable).parent/'stridetorch'),str(script),'--marker','unchanged'],cwd=root,env=environment,text=True))
assert value==dict(module='stridetorch._tensor',shape=[2,2,4],sum=48.)
report=dict(status='passed',aliases=rows,cli=value,native_torch_installed=False,python=sys.version)
(root/'installed-matrix-result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
