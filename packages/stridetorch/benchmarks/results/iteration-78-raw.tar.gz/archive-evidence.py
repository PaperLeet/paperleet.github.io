"""Archive explicit evidence only; never include runtimes, environments or test temps."""
from pathlib import Path
import gzip,hashlib,io,json,os,tarfile
root=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
gates=json.loads((root/'local-integration/gates-result.json').read_text());assert gates['status']=='passed'
assert json.loads((root/'local-integration/gate-progress.json').read_text())['status']=='completed'
assert json.loads((root/'local-integration/cpu-receipt.json').read_text())['status']=='passed'
assert json.loads((root/'core-node-result.json').read_text())['sdk']['passed']==11183
assert json.loads((root/'core-chrome-result.json').read_text())['sdk']['passed']==11183
allowed={p for p in root.iterdir() if p.is_file() and p.suffix in ['.py','.mjs','.json','.log','.html','.diff']}
allowed.add(root/'matrix-oracle.npz')
for folder in ['baseline','candidate','public-gpu','core-baseline','core-candidate','tests','real-gpu','before-cancel-precedence','attempt-1-native-probe','attempt-2-matrix-oracle','attempt-3-test-contracts','attempt-4-wasm-working-directory','attempt-5-empty-cast','attempt-6-disk-full']:
    allowed.update(p for p in (root/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for folder in ['local-integration','main-integration','package-proof','rebased-ui']:
    allowed.update(p for p in (root/folder).iterdir() if p.is_file() and p.suffix in ['.py','.mjs','.json','.log'])
for folder in ['package-proof/dist','package-proof/app-dist','package-proof/sdist-rebuild/dist/wheels','package-proof/sdist-rebuild/app-dist/wheels']:
    allowed.update(p for p in (root/folder).iterdir() if p.is_file())
# Each earlier candidate diagnostic is explicitly retained above.
allowed={p for p in allowed if p.name not in ['archive-manifest.json','archive-verification.json']}
# Current commit manifests contain the archive digest and cannot be embedded in themselves.
allowed={p for p in allowed if str(p.relative_to(root)) not in ['main-integration/qualified-git-blobs.json','main-integration/final-qualified-git-blobs.json','main-integration/source-qualified-git-blobs.json','main-integration/owned-files.json']}

note=root/'raw-evidence-README.txt'
note.write_text('Iteration 78 evidence\n\nSelected library source is 0.76.0, based on local tested 0.75 commit\n0ed2aa3a95d9e7febf683874b5dafd1284af5f1f. No 0.75 remote-main adoption is claimed.\nCore candidate v2 handles empty bmm through metadata-only zero rules. The earlier\ninput-casting implementation, 9614-contract qualifications and first wheel build\nare retained in attempt-5-empty-cast; they are not substituted for v2 proof.\nThe selected source, 78 test files, native full-array NPZ, all 784 empty-dtype\ncontrols, SDK/installed-wheel proofs and real GPU recovery evidence are retained.\n\nqualify-matrix.py generates matrix-oracle.npz using native Torch 2.6. Source/hash\nidentities tie that exact generator to the complete 576-array control set.\nprobe-empty-dtypes.py and probe-matrix-guards.py provide separate native controls.\nreal-gpu/native-oracle.npz is the original 36-case finite float32 matrix/VJP\ncontrol from iteration 74, verified by its original generator SHA and payload\nSHA. make-oracle-original.py retains that exact source. GPU program ownership\nmodes cover 108 executions. Real host-fault tests use actual Apple WebGPU queues\nwith deliberate host exceptions/holds/device destruction; not hardware crashes.\nNo additional latency or physical VRAM claim is made by this iteration.\n\nAn incomplete early CPU run ended with exit 120 while disk space was nearly\nexhausted. Its partial log is retained under attempt-6-disk-full and never counted\nas passing. Only completed task-owned temporary trees/environments were removed;\nqualified source, wheels, raw records, oracle runtimes and original projects were\npreserved. The source archive private namespace layout was initially assumed\nincorrectly by a verifier; verify-sdists.py checks canonical sources and actually\nrebuilds both archives to verify the resulting public/private wheel namespaces.\n\nRuntime binaries, virtual environments, pytest temporaries and extracted source\nrebuild trees are excluded. Pinned runtime identities and wheel closure are\nrecorded. Both selected wheel/sdist pairs and reconstructed wheels are included.\nThe copied public GPU fixture factoring is qualified by its own source hashes;\nthe service bytes match real-GPU qualification. Old cancellation/error outcomes\nare retained before the acknowledged-cancellation fix. No artifact was published.\n\nAll tar mtimes are zero. File mode, uid/gid and owner/group names are preserved;\nduplicates become hardlinks only when all those attributes and payload hashes\nmatch. Every logical payload and metadata item is independently verified.\n')
allowed.add(note)
paths=sorted(allowed,key=lambda p:str(p.relative_to(root)))
manifest={};entries=[];unique={};regular=hardlinks=0
for path in paths:
    relative=str(path.relative_to(root));digest=hashlib.sha256(path.read_bytes()).hexdigest()
    with tarfile.open(fileobj=io.BytesIO(),mode='w') as temp:info=temp.gettarinfo(str(path),arcname=relative)
    assert info.isfile(),relative
    info.mtime=0
    info.mode &= 0o7777
    key=(digest,info.mode,info.uid,info.gid,info.uname,info.gname)
    manifest[relative]=dict(sha256=digest,size=info.size,mode=info.mode,uid=info.uid,gid=info.gid,uname=info.uname,gname=info.gname)
    if key in unique:
        info.type=tarfile.LNKTYPE;info.linkname=unique[key];info.size=0;hardlinks+=1
    else:unique[key]=relative;regular+=1
    entries.append((path,info))
manifest_path=root/'archive-manifest.json';manifest_path.write_text(json.dumps(dict(files=manifest,normalization='mtime=0; preserved mode and owner metadata; manifest itself is not self-hashed'),indent=2)+'\n')
archive=repo/'packages/stridetorch/benchmarks/results/iteration-78-raw.tar.gz'
with archive.open('wb') as output,gzip.GzipFile(fileobj=output,filename='',mode='wb',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
    for path,info in entries:
        if info.islnk():tar.addfile(info)
        else:
            with path.open('rb') as payload:tar.addfile(info,payload)
    info=tar.gettarinfo(str(manifest_path),arcname='archive-manifest.json');info.mtime=0;info.mode &= 0o7777
    manifest_metadata={field:getattr(info,field) for field in ['mode','uid','gid','uname','gname']}
    with manifest_path.open('rb') as payload:tar.addfile(info,payload)
with tarfile.open(archive,'r:gz') as tar:
    members={m.name:m for m in tar.getmembers()};assert len(members)==len(manifest)+1
    assert tar.extractfile('archive-manifest.json').read()==manifest_path.read_bytes()
    for field,value in manifest_metadata.items():assert getattr(members['archive-manifest.json'],field)==value,field
    for name,expected in manifest.items():
        actual=members[name];data=tar.extractfile(actual).read()
        assert hashlib.sha256(data).hexdigest()==expected['sha256'] and len(data)==expected['size'],name
        for field in ['mode','uid','gid','uname','gname']:assert getattr(actual,field)==expected[field],(name,field)
result=dict(status='verified',archive=str(archive),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size,logical_payloads=len(manifest)+1,unique_payloads=regular+1,hardlinks=hardlinks,all_logical_payloads_and_owner_modes_verified=True)
(root/'archive-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
