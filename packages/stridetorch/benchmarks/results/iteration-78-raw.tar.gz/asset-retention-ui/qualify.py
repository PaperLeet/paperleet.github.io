from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent;r=p.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
context=read(p/'context.json');ui=read(r/'path-routing-ui/result.json');nested=read(r/'path-routing-ui/nested-wasm-result.json');assert ui['status']==nested['status']=='passed'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==context['execution_head']
allowed=set(context['external_inputs'])
prior=read(r/'path-routing-ui/frontend-inputs.json')
for n,h in prior.items():
 if n not in allowed:assert sha(repo/n)==h,n
for n,h in context['external_inputs'].items():assert sha(repo/n)==h,n
for row in nested['served']:
 path=repo/'web/dist'/row['path'].lstrip('/')
 if path.is_dir():path=path/'index.html'
 assert sha(path)==row['sha256'],str(path)
assert sha(repo/'problems/architecture/attention/solution.py')==nested['reference_source_sha256']
python=r.parent/'torch-iteration-69/integration-dev-env/bin/python';node='/Users/david/.npm/_npx/d18f28baf1132559/node_modules/node/bin/node';env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');receipts=[]
for label,args in [('pages-assets',[str(python),'-B','web/scripts/check-pages-assets.py']),('retain-production-assets-check',[str(python),'-B','web/scripts/retain-pages-assets.py','web/dist','--check']),('pages-release-policy',[node,'web/scripts/check-pages-release.cjs']),('pages-backfill-policy',[node,'web/scripts/check-pages-backfill.cjs'])]:
 start=time.monotonic()
 with (p/(label+'.log')).open('w') as f:child=subprocess.run(args,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
 receipt=dict(label=label,command=args,exit_code=child.returncode,seconds=time.monotonic()-start,log_sha256=sha(p/(label+'.log')),tail=(p/(label+'.log')).read_text().splitlines()[-3:]);receipts.append(receipt);print(json.dumps(receipt),flush=True);child.check_returncode()
frontend={n:sha(repo/n) for n in prior};(p/'frontend-inputs.json').write_text(json.dumps(frontend,indent=2)+'\n')
result=dict(status='passed',execution_head=context['execution_head'],integration_base=context['integration_base'],external_inputs=context['external_inputs'],receipts=receipts,unchanged_frontend_inputs=len(prior)-2,nested_browser_assets_verified=len(nested['served']),prior_ui_execution=ui['execution_head'],full_frontend_and_both_builds_reused_by_unchanged_inputs=True,numeric_and_worker_inputs_unchanged=True,no_numeric_rerun_claimed=True,ci_triggered=False,published=False,deployed=False)
(p/'result.json').write_text(json.dumps(result,indent=2)+'\n')
