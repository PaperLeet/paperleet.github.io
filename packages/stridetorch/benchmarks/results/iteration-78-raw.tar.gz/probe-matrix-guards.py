import json,sys
import numpy as np
if '--native' in sys.argv:
 import torch
 torch.set_num_threads(2)
else:
 from stridetorch import torch
rows=[]
for sa,sb in [((2,0,3),(2,3,4)),((2,3,0),(2,0,4)),((2,3,4),(2,4,0)),((0,3,4),(0,4,2))]:
 for da,db in [('float32','float64'),('float64','float32'),('float32','float32')]:
  for active in [(True,True),(True,False),(False,True)]:
   for changed in ['a','b','output']:
    a=torch.from_numpy(np.ones(sa,dtype=da)).requires_grad_(active[0]);b=torch.from_numpy(np.ones(sb,dtype=db)).requires_grad_(active[1]);y=torch.bmm(a,b)
    with torch.no_grad():{'a':a,'b':b,'output':y}[changed].detach().add_(1)
    try:y.sum().backward();status='passed'
    except RuntimeError:status='guarded'
    rows.append(dict(shape_a=sa,shape_b=sb,dtype_a=da,dtype_b=db,active=active,changed=changed,status=status))
file='matrix-native-guards.json' if '--native' in sys.argv else 'matrix-candidate-guards.json'
open(file,'w').write(json.dumps(rows,indent=2)+'\n')
if '--native' not in sys.argv:assert json.loads(json.dumps(rows))==json.load(open('matrix-native-guards.json'))
print(len(rows),'guard cases passed')
