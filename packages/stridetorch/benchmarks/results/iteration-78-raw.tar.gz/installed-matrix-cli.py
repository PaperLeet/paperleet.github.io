import json,sys,torch
a=torch.ones(2,2,3,requires_grad=True);b=torch.ones(2,3,4)
y=a.bmm(mat2=b);y.sum().backward()
assert a.grad.tolist()==[[[4.]*3]*2]*2
assert sys.argv[1:]==["--marker","unchanged"]
print(json.dumps(dict(module=type(a).__module__,shape=list(y.shape),sum=y.sum().item())))
