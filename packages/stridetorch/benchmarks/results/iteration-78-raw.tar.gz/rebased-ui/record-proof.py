from pathlib import Path
import hashlib,json,re,subprocess,sys
p=Path(__file__).resolve().parent;r=p.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
result=repo/'packages/stridetorch/benchmarks/results/iteration-78.json';doc=repo/'docs/validation/torch-runtime-iteration-78.md';archive=repo/'packages/stridetorch/benchmarks/results/iteration-78-raw.tar.gz'
if '--refresh-archive' in sys.argv:
    data=read(result);proof=read(r/'archive-verification.json');assert proof['sha256']==sha(archive)
    data['raw_archive']=dict(path=archive.name,bytes=archive.stat().st_size,sha256=proof['sha256']);result.write_text(json.dumps(data,indent=2)+'\n')
    text=doc.read_text();replacement=f"[Raw evidence](../../packages/stridetorch/benchmarks/results/{archive.name}) — {archive.stat().st_size:,} bytes; SHA-256 `{proof['sha256']}`."
    text,count=re.subn(r'\[Raw evidence\][^\n]*',lambda match:replacement,text);assert count==1;doc.write_text(text)
    print('Updated final archive references without changing numerical or UI execution provenance.',flush=True)
    raise SystemExit(0)
ui=read(p/'result.json');context=read(p/'context.json');assert ui['status']=='passed' and ui['core_source_hashes']==read(r/'selected-source-freeze.json')['source_hashes']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==context['execution_head'];assert not subprocess.check_output(['git','status','--porcelain','-z'],cwd=repo)
data=read(result);assert data['status']=='local_application_qualified';assert 'ui_requalification' not in data
data['ui_requalification']=ui;data['external_main_reconciliation']=dict(integration_base=context['integration_base'],pre_rebase_qualified_commit=context['pre_rebase_qualified_commit'],rebased_execution_head=context['execution_head'],original_numeric_execution_base=context['original_numeric_execution_base'],external_inputs=context['external_inputs'],combined_owned_paths=context['combined_owned_paths'],numeric_app_inputs_unchanged=True)
result.write_text(json.dumps(data,indent=2)+'\n');text=doc.read_text();assert '## Rebased UI validation' not in text
text+='\n## Rebased UI validation\n\n'+f"Remote main advanced by three UI commits to `{context['integration_base']}` while the 0.76 application checks ran. Both tested unpublished commits were preserved at `refs/codex/checkpoints/torch-iteration-78-before-ui-rebase` and rebased without conflicts. The rebased tree `{context['execution_head']}` retains all 26 external UI/validation changes. All 62 core resources, 78 test files, 1,426 application inputs, live exports and release-policy identities match the original qualification. Existing frontend dependencies and check commands are preserved; two new frontend checks are included.\n\n"
text+='The complete frontend checks, default/current-Pages-profile builds, release-policy checks and exact generated-worker verification were rerun on that rebased tree and passed. Numerical CPU/WASM runs retain their original execution SHA; no numerical rerun on the rebased Git parent is claimed. The combined qualification ties unchanged compute/application inputs to the new tested frontend.\n';doc.write_text(text)
advance=read(r/'external-ui-advance.json');advance.update(rebased=True,rebased_execution_head=context['execution_head'],ui_qualification='passed');(r/'external-ui-advance.json').write_text(json.dumps(advance,indent=2)+'\n')
state=read(r/'state.json');state.update(status='076_rebased_ui_qualified_evidence_commit_pending',active_processes=[],application_gates='passed',rebased_ui='passed',main_adopted=False,remote_main_observed=context['integration_base']);(r/'state.json').write_text(json.dumps(state,indent=2)+'\n')
print('Recorded actual rebased frontend/build executions while retaining original numerical execution SHAs.',flush=True)
