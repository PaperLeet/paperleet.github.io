from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).resolve().parent;r=p.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
assert read(p/'result.json')['status']=='passed'
allowed={'docs/validation/torch-runtime-iteration-78.md','packages/stridetorch/benchmarks/results/iteration-78.json','packages/stridetorch/benchmarks/results/iteration-78-raw.tar.gz'}
entries=[x for x in subprocess.check_output(['git','status','--porcelain','-z','--untracked-files=all'],cwd=repo).decode().split('\0') if x];assert {x[3:] for x in entries}==allowed;assert all(x[:2]==' M' for x in entries)
context=read(p/'context.json');expected=read(r/'main-integration/pre-rebase-qualified-git-blobs.json')
for n,h in read(r.parent/'torch-iteration-77/main-integration/owned-files.json').items():expected.setdefault(n,h)
expected.update(read(p/'frontend-inputs.json'));expected.update(context['external_inputs'])
for n in allowed:expected[n]=sha(repo/n)
for n,h in expected.items():assert sha(repo/n)==h,n
old_tree={x.split('\t',1)[1]:x.split('\t',1)[0] for x in subprocess.check_output(['git','ls-tree','-r','-z',context['original_numeric_execution_base'],'--','web/public/data/browser-judge','web/public/data/modules'],cwd=repo).decode().split('\0') if x}
new_tree={x.split('\t',1)[1]:x.split('\t',1)[0] for x in subprocess.check_output(['git','ls-tree','-r','-z','HEAD','--','web/public/data/browser-judge','web/public/data/modules'],cwd=repo).decode().split('\0') if x}
for n in read(r/'local-integration/immutable-assets.json'):assert old_tree[n]==new_tree[n],n
(r/'main-integration/qualified-git-blobs.json').write_text(json.dumps(expected,indent=2)+'\n')
subprocess.run(['git','diff','--check'],cwd=repo,check=True);subprocess.run(['git','add','--',*sorted(allowed)],cwd=repo,check=True)
assert {n for n in subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=repo).decode().split('\0') if n}==allowed
print(json.dumps(dict(status='rebased_evidence_ready_to_commit',qualified_git_blobs=len(expected),staged_paths=len(allowed),preserved_prior_immutable=len(read(r/'local-integration/immutable-assets.json')))),flush=True)
