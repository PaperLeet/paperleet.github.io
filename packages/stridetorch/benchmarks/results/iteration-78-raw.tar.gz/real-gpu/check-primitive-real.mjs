import assert from 'node:assert/strict';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const names=['gpu-service.mjs','plan-program.mjs','rpc-client.mjs','check-primitive-real.mjs'];
const hashes=()=>Object.fromEntries(names.map(name=>[name,createHash('sha256').update(fs.readFileSync(path.join(root,name))).digest('hex')]));
const sources=hashes();
const server=http.createServer((request,response)=>{
 if(request.url==='/'){response.writeHead(200,{'content-type':'text/html'});response.end('<!doctype html><title>Real WebGPU fault recovery</title>');return;}
 const name=request.url?.slice(1);if(!names.includes(name)){response.writeHead(404);response.end();return;}
 response.writeHead(200,{'content-type':'text/javascript'});response.end(fs.readFileSync(path.join(root,name)));
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));let browser;
try{
 browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 const page=await browser.newPage();await page.goto('http://127.0.0.1:'+server.address().port);
 const result=await page.evaluate(async()=>{
  const {createGpuEngine}=await import('/gpu-service.mjs');
  const original=navigator.gpu,descriptor=Object.getOwnPropertyDescriptor(navigator,'gpu');
  const rows=[];
  async function fixture(operation,point,mode){
   const controls={point:null,trace:[],hold:null,failDrain:false};let engine;
   const hit=(name,after)=>{controls.trace.push(name);if(controls.point===name){controls.point=null;throw Error('Injected host '+name+(after?' after real GPU call':''));}};
   Object.defineProperty(navigator,'gpu',{configurable:true,value:{requestAdapter:async()=>{
    const adapter=await original.requestAdapter();if(!adapter)throw Error('No real adapter');
    return {info:adapter.info,requestDevice:async()=>{
     const device=await adapter.requestDevice(),queue=device.queue;
     const allocate=device.createBuffer.bind(device),bind=device.createBindGroup.bind(device),destroyDevice=device.destroy.bind(device);
     const write=queue.writeBuffer.bind(queue),submit=queue.submit.bind(queue),fence=queue.onSubmittedWorkDone.bind(queue);
     device.createBuffer=(options)=>{
      const buffer=allocate(options),destroy=buffer.destroy.bind(buffer),map=buffer.mapAsync.bind(buffer);
      buffer.destroy=()=>{controls.trace.push('destroy');destroy();};
      buffer.mapAsync=(...args)=>{try{hit('map',false);}catch(error){return Promise.reject(error);}return map(...args);};return buffer;
     };
     device.createBindGroup=(options)=>{const result=bind(options);hit('bind',true);return result;};
     queue.writeBuffer=(...args)=>{write(...args);hit('write',true);};
     queue.submit=(...args)=>{submit(...args);hit('submit',true);};
     queue.onSubmittedWorkDone=async()=>{
      controls.trace.push('fence:start');if(controls.failDrain)throw Error('Injected host drain failure');
      await fence();if(controls.hold)await controls.hold;controls.trace.push('fence:done');
     };
     device.destroy=()=>{controls.trace.push('device:destroy');destroyDevice();};return device;
    }};
   }}});
   try{
    engine=await createGpuEngine();const existing=await engine.execute({id:0,op:'upload',rows:4,cols:4,data:new Float32Array(16).fill(1).buffer});
    controls.trace=[];controls.point=point;
    const request=operation==='upload'?{id:1,op:'upload',rows:4,cols:4,data:new Float32Array(16).fill(2).buffer}:operation==='matmul'?{id:1,op:'matmul',a:existing.handle,b:existing.handle,transposeA:false,transposeB:false}:{id:1,op:'read',handle:existing.handle};
    if(mode==='failed-drain')controls.failDrain=true;
    let release;if(mode==='held'||mode==='close-held')controls.hold=new Promise(resolve=>{release=resolve;});
    const outcome=engine.execute(request).then(()=>{throw Error('Expected injected rejection');},error=>({message:error.message}));
    if(release){
     for(let i=0;i<500&&!controls.trace.includes('fence:start');i++)await new Promise(resolve=>setTimeout(resolve,2));
     if(!controls.trace.includes('fence:start')||controls.trace.includes('destroy')||engine.stats().total_bytes<=64)throw Error('Capacity reclaimed before drain');
     if(mode==='close-held')engine.close();controls.hold=null;release();
    }
    const error=await outcome;if(!error.message.includes('Injected host'))throw Error('Original error was not propagated');
    const trace=controls.trace.slice(),stats=engine.stats();
    if(mode==='failed-drain'||mode==='close-held'){
     if(!stats.closed||stats.total_bytes||stats.resident_handles)throw Error('Device/handles survived invalidation');
    }else{
     if(stats.closed||stats.total_bytes!==64||stats.resident_handles!==1)throw Error('Resident allocation changed on ordinary rollback');
     if(trace.indexOf('fence:done')<0||trace.indexOf('destroy')<=trace.indexOf('fence:done'))throw Error('Buffers destroyed before real queue completion');
     const snapshot=new Float32Array((await engine.execute({id:2,op:'read',handle:existing.handle})).data);
     if(!snapshot.every(value=>value===1))throw Error('Prior resident contents changed');
     const output=await engine.execute({id:3,op:'matmul',a:existing.handle,b:existing.handle,transposeA:false,transposeB:false});
     const numeric=new Float32Array((await engine.execute({id:4,op:'read',handle:output.handle})).data);
     if(!numeric.every(value=>value===4))throw Error('Numerical execution did not recover');engine.discard(output);
    }
    rows.push({operation,point,mode,passed:true,trace,stats,adapter:engine.info});
   }finally{engine?.close();descriptor?Object.defineProperty(navigator,'gpu',descriptor):delete navigator.gpu;}
  }
  for(const [operation,point] of [['upload','write'],['matmul','bind'],['matmul','submit'],['read','map']])await fixture(operation,point,'ordinary');
  for(const [operation,point] of [['upload','write'],['matmul','bind'],['read','map']])for(const mode of ['failed-drain','held','close-held'])await fixture(operation,point,mode);
  return {status:'passed',cases:rows.length,rows};
 });
 assert.deepEqual(hashes(),sources);assert.equal(result.cases,13);
 const report={...result,source_sha256:sources,browser:browser.version(),launch:{headless:true,extra_flags:[]},scope:'Real Chrome WebGPU buffers, queues and numerical recovery with deliberate trusted-host exceptions, deferred completion and explicit device destruction. These are controlled host faults, not spontaneous hardware faults or physical VRAM measurements. No shader or production quotas changed.'};
 fs.writeFileSync(path.join(root,'primitive-real-result.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,cases:report.cases,browser:report.browser}));
}finally{await browser?.close();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
