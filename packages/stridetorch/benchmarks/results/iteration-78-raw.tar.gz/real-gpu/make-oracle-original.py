"""Freeze native Torch and independent float64 matmul/VJP controls before GPU runs."""
from pathlib import Path
import hashlib,json,sys
import numpy as np
import torch

p=Path(__file__).resolve().parent
assert torch.__version__.split('+')[0]=='2.6.0'
torch.set_num_threads(2)
rng=np.random.default_rng(7404)
shapes=[(1,1,1),(3,5,2),(7,9,11),(8,8,8),(15,17,9),(17,15,23),(32,64,16),(65,33,49),(128,64,32)]
arrays={};cases=[]
for m,k,n in shapes:
    for ta,tb in [(False,False),(True,False),(False,True),(True,True)]:
        name=f'c{len(cases)}'
        a=rng.normal(0,.3,(k,m) if ta else (m,k)).astype('float32')
        b=rng.normal(0,.3,(n,k) if tb else (k,n)).astype('float32')
        g=rng.normal(0,.3,(m,n)).astype('float32')
        at=torch.tensor(a,requires_grad=True);bt=torch.tensor(b,requires_grad=True)
        y=(at.T if ta else at)@(bt.T if tb else bt)
        ga,gb=torch.autograd.grad(y,(at,bt),torch.tensor(g))
        av=a.astype('float64');bv=b.astype('float64');gv=g.astype('float64')
        ao=av.T if ta else av;bo=bv.T if tb else bv
        ga64=gv@bo.T;gb64=ao.T@gv
        if ta:ga64=ga64.T
        if tb:gb64=gb64.T
        data=dict(a=a,b=b,g=g,y=y.detach().numpy(),ga=ga.numpy(),gb=gb.numpy(),y64=ao@bo,ga64=ga64,gb64=gb64)
        for field,value in data.items():arrays[name+'_'+field]=value
        cases.append(dict(name=name,shape=[m,k,n],transpose_a=ta,transpose_b=tb))
np.savez_compressed(p/'native-oracle.npz',**arrays)
source_sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
report=dict(status='frozen_before_gpu_execution',cases=cases,python=sys.version,numpy=np.__version__,
            torch=torch.__version__,torch_git=torch.version.git_version,torch_path=torch.__file__,
            generator_sha256=source_sha(Path(__file__)),payload_sha256=source_sha(p/'native-oracle.npz'),
            tolerance=dict(rtol=1e-4,atol=5e-4),
            scope='36 finite float32 2D matmul and analytical VJP fixtures, all four transpose combinations, native Torch 2.6 plus independent float64 controls; not general torch/autograd/GPU qualification.')
(p/'native-oracle.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],cases=len(cases),payload_sha256=report['payload_sha256'])))
