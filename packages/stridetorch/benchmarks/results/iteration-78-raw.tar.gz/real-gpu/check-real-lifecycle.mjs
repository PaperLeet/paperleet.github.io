import assert from 'node:assert/strict';
import fs from 'node:fs';
import http from 'node:http';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const sha=name=>createHash('sha256').update(fs.readFileSync(path.join(root,name))).digest('hex');
const source=Object.fromEntries(['gpu-service.mjs','plan-program.mjs','rpc-client.mjs','check-real-lifecycle.mjs'].map(name=>[name,sha(name)]));
const server=http.createServer((req,res)=>{
  if(req.url==='/'){res.writeHead(200,{'content-type':'text/html'});res.end('<!doctype html><title>Owned GPU lifecycle checks</title>');return;}
  const name=req.url?.slice(1);
  if(!['gpu-service.mjs','plan-program.mjs','rpc-client.mjs'].includes(name)){res.writeHead(404);res.end();return;}
  res.writeHead(200,{'content-type':'text/javascript'});res.end(fs.readFileSync(path.join(root,name)));
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const base='http://127.0.0.1:'+server.address().port;
let browser;
try{
  browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
  const page=await browser.newPage();await page.goto(base);
  const rows=await page.evaluate(async base=>{
    const {MatrixRpc}=await import(base+'/rpc-client.mjs');
    const custom=`import {createGpuEngine,servePort,LIMITS} from ${JSON.stringify(base+'/gpu-service.mjs')};
      let service,engine;
      onmessage=async e=>{
        if(e.data?.type==='connect'){
          engine=await createGpuEngine();
          service=servePort(e.ports[0],engine,{limits:{...LIMITS,leaseMs:250},onClosed:value=>postMessage({type:'disposed',...value})});
        }else if(e.data?.type==='lose'){engine?.close();}
        else if(e.data?.type==='dispose'){await service?.close('host disposed');}
      };`;
    const rows=[];
    const waitFor=async predicate=>{for(let i=0;i<500&&!predicate();i++)await new Promise(resolve=>setTimeout(resolve,2));if(!predicate())throw Error('State not observed');};
    async function fixture(name,{customWorker=false,startup=false,work}={}){
      const url=customWorker?URL.createObjectURL(new Blob([custom],{type:'text/javascript'})):base+'/gpu-service.mjs';
      const worker=new Worker(url,{type:'module'}),channel=new MessageChannel();
      let closeResolve,closeReject;
      const disposed=new Promise((resolve,reject)=>{closeResolve=resolve;closeReject=reject;});
      const timer=setTimeout(()=>closeReject(Error('Lifecycle timeout: '+name)),5000);
      worker.onmessage=event=>{if(event.data?.type==='disposed')closeResolve(event.data);if(event.data?.type==='unavailable')closeReject(Error(event.data.error));};
      worker.onerror=event=>closeReject(Error(event.message));
      worker.postMessage({type:'connect'},[channel.port1]);
      let client;
      try{
        if(startup){worker.postMessage({type:'dispose'});const value=await disposed;if(value.reason!=='host disposed during startup')throw Error('Startup race did not exercise pending initialization');rows.push({name,passed:true,disposal:value});return;}
        client=new MatrixRpc(channel.port2,{timeoutMs:1000});await client.ready;
        const value=await client.upload(new Float32Array(16).fill(1),4,4);
        const before=await client.stats();if(before.resident_handles!==1||before.total_bytes!==64)throw Error('Resident precondition');
        await work({worker,client,value,disposed,waitFor});
        const disposal=await disposed;if(disposal.stats.total_bytes!==0||disposal.stats.resident_handles!==0||!disposal.stats.closed)throw Error('Resources retained');
        rows.push({name,passed:true,before,disposal});
      }finally{
        clearTimeout(timer);client?.fail(Object.assign(new Error('Fixture finished'),{code:'Closed'}));worker.postMessage({type:'dispose'});worker.terminate();channel.port2.close();if(customWorker)URL.revokeObjectURL(url);
      }
    }
    await fixture('dispose while real GPU device initializes',{startup:true});
    await fixture('host disposal invalidates a real resident handle',{work:async({worker,client,disposed,waitFor})=>{
      worker.postMessage({type:'dispose'});await disposed;await waitFor(()=>client.closed);
      try{await client.read(1);throw Error('Closed handle accepted');}catch(error){if(error.code!=='Closed')throw error;}
    }});
    await fixture('abandoned port recovers real resident allocation at lease',{customWorker:true,work:async({client,disposed})=>{
      client.fail(Object.assign(new Error('Peer disappeared without close command'),{code:'Closed'}));const value=await disposed;if(value.reason!=='lease expired')throw Error('Unexpected abandonment recovery');
    }});
    await fixture('injected real device destruction reaches device-lost handler',{customWorker:true,work:async({worker,disposed})=>{
      worker.postMessage({type:'lose'});const value=await disposed;if(!value.reason.startsWith('GPU device lost: destroyed'))throw Error('Lost event was not observed');
    }});
    return rows;
  },base);
  for(const [name,digest] of Object.entries(source))assert.equal(sha(name),digest);
  const report={status:'passed',cases:rows.length,rows,source_sha256:source,browser:browser.version(),launch:{headless:true,extra_flags:[]},
    scope:'Real Chrome GPU lifecycle checks. These additional clients run in the trusted fixture page, not the opaque Pyodide Worker. A short lease is supplied by trusted host code to exported servePort; production Worker default lease is unchanged. Device-loss injection explicitly destroys a real device; not hardware crash coverage. Destroyed-resource accounting is not physical VRAM/preemptive GPU cancellation evidence.'};
  fs.writeFileSync(path.join(root,'real-lifecycle-result.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,cases:report.cases,rows}));
}finally{if(browser)await browser.close();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
