"""Numerical, ownership and lifetime checks through the real Python/JSPI RPC."""
import io,json
import numpy as np
from pyodide.ffi import run_sync
from js import matrix_rpc_other

oracle=np.load('/native-oracle.npz')
meta=json.loads(_native_meta_json)
rows=[]
for case in meta['cases']:
    name=case['name']
    a,b,g=(oracle[name+'_'+field] for field in ['a','b','g'])
    original=[value.copy() for value in (a,b,g)]
    values=[]
    try:
        am,bm,gm=[Matrix.upload(value) for value in (a,b,g)]
        values.extend([am,bm,gm])
        ta,tb=case['transpose_a'],case['transpose_b']
        ym=am.matmul(bm,ta,tb);values.append(ym)
        gam=bm.matmul(gm,tb,True) if ta else gm.matmul(bm,False,not tb)
        values.append(gam)
        gbm=gm.matmul(am,True,ta) if tb else am.matmul(gm,not ta,False)
        values.append(gbm)
        errors={}
        for field,matrix in [('y',ym),('ga',gam),('gb',gbm)]:
            actual=matrix.numpy()
            assert actual.dtype==np.float32
            for suffix in ['', '64']:
                reference=oracle[name+'_'+field+suffix]
                np.testing.assert_allclose(actual,reference,**meta['tolerance'])
                errors[field+suffix]=float(np.max(np.abs(actual-reference),initial=0))
        for actual,expected in zip((a,b,g),original):
            np.testing.assert_array_equal(actual,expected)
        rows.append(dict(**case,passed=True,max_absolute_error=errors))
    finally:
        for matrix in reversed(values):matrix.close()
    assert run_sync(matrix_rpc.stats()).resident_handles==0

# Upload and readback are explicit copy boundaries, including strided views.
a=np.arange(30,dtype=np.float32).reshape(5,6)[:,::2]
expected=a.copy()
with Matrix.upload(a) as resident:
    a.fill(-90)
    read=resident.numpy()
    np.testing.assert_array_equal(read,expected)
    read.fill(-70)
    np.testing.assert_array_equal(resident.numpy(),expected)
resident.close()
try:resident.numpy()
except RuntimeError:pass
else:raise AssertionError('Released Python handle accepted')

for bad in [np.ones((2,2),dtype=np.float64),np.ones((2,2),dtype=np.int32),np.ones(4,dtype=np.float32)]:
    try:Matrix.upload(bad)
    except TypeError:pass
    else:raise AssertionError('Unsupported array accepted')

# Distinct devices deliberately issue overlapping small handle numbers. Python
# ownership rejects combining their matrices instead of interpreting a foreign ID.
with Matrix.upload(np.ones((2,2),dtype=np.float32)) as left:
    with Matrix.upload(np.full((2,2),7,dtype=np.float32),client=matrix_rpc_other) as right:
        np.testing.assert_array_equal(left.numpy(),np.ones((2,2),dtype=np.float32))
        np.testing.assert_array_equal(right.numpy(),np.full((2,2),7,dtype=np.float32))
        try:left.matmul(right)
        except ValueError:pass
        else:raise AssertionError('Cross-session matrix accepted')

# Resident chaining has no CPU read between products.
with Matrix.upload(np.arange(12,dtype=np.float32).reshape(3,4)) as a:
    with Matrix.upload(np.arange(20,dtype=np.float32).reshape(4,5)/10) as b:
        with Matrix.upload(np.arange(10,dtype=np.float32).reshape(5,2)/10) as c:
            with a.matmul(b) as intermediate:
                with intermediate.matmul(c) as output:
                    expected=(np.arange(12,dtype=np.float32).reshape(3,4)@(np.arange(20,dtype=np.float32).reshape(4,5)/10))@(np.arange(10,dtype=np.float32).reshape(5,2)/10)
                    np.testing.assert_allclose(output.numpy(),expected,**meta['tolerance'])
assert run_sync(matrix_rpc.stats()).resident_handles==0
assert run_sync(matrix_rpc_other.stats()).resident_handles==0
program_rows=[]
for case in meta['cases']:
    name=case['name'];a,b,g=(oracle[name+'_'+field] for field in ['a','b','g'])
    saved=[value.copy() for value in (a,b,g)]
    ta,tb=case['transpose_a'],case['transpose_b']
    def build(values):
        program=MatrixProgram()
        ar,br,gr=[program.input(value) for value in values]
        yr=program.matmul(ar,br,ta,tb)
        gar=program.matmul(br,gr,tb,True) if ta else program.matmul(gr,br,False,not tb)
        gbr=program.matmul(gr,ar,True,ta) if tb else program.matmul(ar,gr,not ta,False)
        return program,[yr,gar,gbr]
    errors={}
    for retain in [False,True]:
        program,refs=build([a,b,g]);before=run_sync(matrix_rpc.stats())
        with program.run(refs,retain=retain) as result:
            after=run_sync(matrix_rpc.stats())
            assert after.submitted-before.submitted==1
            assert after.resident_handles==3*retain
            for field,array,resident in zip(['y','ga','gb'],result.arrays,result.matrices):
                assert array.dtype==np.float32 and array.shape==oracle[name+'_'+field].shape
                for suffix in ['', '64']:
                    reference=oracle[name+'_'+field+suffix]
                    np.testing.assert_allclose(array,reference,**meta['tolerance'])
                    errors[field+suffix]=float(np.max(np.abs(array-reference),initial=0))
                if retain:np.testing.assert_array_equal(resident.numpy(),array)
        assert run_sync(matrix_rpc.stats()).total_bytes==0
    with Matrix.upload(a) as am,Matrix.upload(b) as bm,Matrix.upload(g) as gm:
        program,refs=build([am,bm,gm]);before=run_sync(matrix_rpc.stats())
        with program.run(refs) as result:
            for field,array in zip(['y','ga','gb'],result.arrays):np.testing.assert_allclose(array,oracle[name+'_'+field],**meta['tolerance'])
        after=run_sync(matrix_rpc.stats());assert after.resident_handles==3 and after.submitted-before.submitted==1
    for value,expected in zip((a,b,g),saved):np.testing.assert_array_equal(value,expected)
    program_rows.append(dict(**case,passed=True,max_absolute_error=errors,execution_modes=['ephemeral_upload','retained_upload','resident_input']))

# Retained-only output can be consumed by another bounded program. Readback
# arrays are independent snapshots even when the same output is retained.
program=MatrixProgram();ar=program.input(np.arange(4,dtype=np.float32).reshape(2,2));br=program.input(np.eye(2,dtype=np.float32));yr=program.matmul(ar,br)
with program.run([yr],read=False,retain=True) as first:
    assert first.arrays==(None,)
    next_program=MatrixProgram();x=next_program.input(first.matrices[0]);w=next_program.input(np.eye(2,dtype=np.float32));y=next_program.matmul(x,w)
    with next_program.run([y],retain=True) as second:
        np.testing.assert_array_equal(second.arrays[0],np.arange(4,dtype=np.float32).reshape(2,2))
        second.arrays[0].fill(-100)
        np.testing.assert_array_equal(second.matrices[0].numpy(),np.arange(4,dtype=np.float32).reshape(2,2))
        second.matrices[0].close()
assert run_sync(matrix_rpc.stats()).total_bytes==0

# Local ownership/type errors never turn a foreign handle into a local one.
with Matrix.upload(np.eye(2,dtype=np.float32),client=matrix_rpc_other) as foreign:
    program=MatrixProgram();a=program.input(foreign);b=program.input(np.eye(2,dtype=np.float32));y=program.matmul(a,b)
    try:program.run([y])
    except ValueError:pass
    else:raise AssertionError('Foreign program input accepted')
program=MatrixProgram();a=program.input(np.eye(2,dtype=np.float64));b=program.input(np.eye(2,dtype=np.float32));y=program.matmul(a,b)
try:program.run([y])
except TypeError:pass
else:raise AssertionError('float64 program input accepted')
try:program.input(np.eye(2,dtype=np.float32))
except ValueError:pass
else:raise AssertionError('Input added after dependent nodes')

# Python copy failure after a successful host reply must release all published
# outputs, not only the first converted Matrix.
program=MatrixProgram();a=program.input(np.eye(2,dtype=np.float32));b=program.input(np.eye(2,dtype=np.float32));x=program.matmul(a,b);y=program.matmul(x,b)
original_array=np.array
def failed_copy(*args,**kwargs):raise RuntimeError('Injected Python copy failure')
np.array=failed_copy
try:
    try:program.run([x,y],retain=True)
    except RuntimeError as error:assert str(error)=='Injected Python copy failure'
    else:raise AssertionError('Copy injection did not run')
finally:np.array=original_array
assert run_sync(matrix_rpc.stats()).resident_handles==0
assert run_sync(matrix_rpc_other.stats()).resident_handles==0
import gc,weakref
def inspect_nested_conversion():
    root=np.ones((3,4),dtype=np.float32)
    reference=weakref.ref(root)
    converted=to_js([dict(rows=3,cols=4,data=np.ascontiguousarray(root).reshape(-1))],dict_converter=Object.fromEntries)
    return reference,converted
reference,converted=inspect_nested_conversion()
gc.collect()
conversion=dict(numpy=np.__version__,container=str(converted.constructor.name),data_type=str(converted[0].data.constructor.name),
                data_is_pyproxy=hasattr(converted[0].data,'toJs'),python_root_alive=reference() is not None)
assert conversion['container']=='Array' and conversion['data_type']=='Float32Array' and not conversion['data_is_pyproxy']
json.dumps(dict(status='passed',cases=len(rows),rows=rows,ownership_checks=6,
                program_fixtures=len(program_rows),program_executions=3*len(program_rows),program_rows=program_rows,
                program_ownership_checks=['retained-only continuation','read/retained snapshot isolation','partial consumer release','foreign session','dtype','input ordering','post-reply conversion rollback'],
                nested_conversion_observation=conversion,
                scope='Legacy primitives plus bounded-program float32 2D matrix/VJP. Three program ownership modes, one submit per program. Not an automatic torch GPU/autograd backend.'))
