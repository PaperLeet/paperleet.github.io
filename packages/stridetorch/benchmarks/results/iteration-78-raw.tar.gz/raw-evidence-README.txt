Iteration 78 evidence

Selected library source is 0.76.0, based on local tested 0.75 commit
0ed2aa3a95d9e7febf683874b5dafd1284af5f1f. No 0.75 remote-main adoption is claimed.
Core candidate v2 handles empty bmm through metadata-only zero rules. The earlier
input-casting implementation, 9614-contract qualifications and first wheel build
are retained in attempt-5-empty-cast; they are not substituted for v2 proof.
The selected source, 78 test files, native full-array NPZ, all 784 empty-dtype
controls, SDK/installed-wheel proofs and real GPU recovery evidence are retained.

qualify-matrix.py generates matrix-oracle.npz using native Torch 2.6. Source/hash
identities tie that exact generator to the complete 576-array control set.
probe-empty-dtypes.py and probe-matrix-guards.py provide separate native controls.
real-gpu/native-oracle.npz is the original 36-case finite float32 matrix/VJP
control from iteration 74, verified by its original generator SHA and payload
SHA. make-oracle-original.py retains that exact source. GPU program ownership
modes cover 108 executions. Real host-fault tests use actual Apple WebGPU queues
with deliberate host exceptions/holds/device destruction; not hardware crashes.
No additional latency or physical VRAM claim is made by this iteration.

An incomplete early CPU run ended with exit 120 while disk space was nearly
exhausted. Its partial log is retained under attempt-6-disk-full and never counted
as passing. Only completed task-owned temporary trees/environments were removed;
qualified source, wheels, raw records, oracle runtimes and original projects were
preserved. The source archive private namespace layout was initially assumed
incorrectly by a verifier; verify-sdists.py checks canonical sources and actually
rebuilds both archives to verify the resulting public/private wheel namespaces.

Runtime binaries, virtual environments, pytest temporaries and extracted source
rebuild trees are excluded. Pinned runtime identities and wheel closure are
recorded. Both selected wheel/sdist pairs and reconstructed wheels are included.
The copied public GPU fixture factoring is qualified by its own source hashes;
the service bytes match real-GPU qualification. Old cancellation/error outcomes
are retained before the acknowledged-cancellation fix. No artifact was published.

All tar mtimes are zero. File mode, uid/gid and owner/group names are preserved;
duplicates become hardlinks only when all those attributes and payload hashes
match. Every logical payload and metadata item is independently verified.

Additional upstream integration evidence is retained under rebased-ui,
path-routing-ui and asset-retention-ui. Original full numerical execution SHAs
are preserved. Both path-routing builds and the actual nested attention page
passed; the latter uses real CodeMirror/Worker/Pyodide/NumPy but trusted health
and anonymous-account fixtures, with all other external requests blocked.
An initial read-only health-precondition attempt is retained separately.
The three-file upstream asset-retention fix was reviewed and its 20 tests,
actual production assets and release/backfill policies passed. Workflow triggers
and release gates remain unchanged; only build environment and validation
steps changed upstream. Historical commit manifests are explicitly historical.
The read-only push guard was strengthened to require a Pages child created at
or after the same successful quality completion; 16 controls pass. The mandatory
ordinary-push wrapper remains byte-identical. No CI or publishing initiated.
