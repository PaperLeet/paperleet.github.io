from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).resolve().parent.parent;p=r/'asset-retention-ui';p.mkdir(exist_ok=True);repo=Path('/Users/david/Developer/PaperLeet-torch-release')
git=lambda *a:subprocess.check_output(['git',*a],cwd=repo)
read=lambda q:json.loads(q.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
old='3f56fa6863b38db12ea0b2153ce396b3e8396672';new='891f620921791775082e2e290ff5caf8e06e5b72';execution='170e134d722bac4aa39b8d32e0732aa823f39a43'
assert git('rev-parse','HEAD').decode().strip()==execution
assert not git('status','--porcelain','-z')
names=set(git('diff','--name-only','-z',old,new).decode().split('\0'))-{''}
assert names=={'.github/workflows/ci.yml','web/scripts/check-pages-assets.py','web/scripts/retain-pages-assets.py'}
before=git('show',old+':.github/workflows/ci.yml');after=git('show',new+':.github/workflows/ci.yml')
addition=b'      - name: Validate production asset retention\n        run: |\n          python web/scripts/check-pages-assets.py\n          python web/scripts/retain-pages-assets.py web/dist --check\n'
assert after.replace(addition,b'',1)==before and after.count(addition)==1
(p/'upstream.diff').write_bytes(git('diff',old,new))
subprocess.run(['git','update-ref','refs/codex/checkpoints/torch-iteration-78-before-asset-rebase',execution],cwd=repo,check=True)
subprocess.run(['git','rebase','--onto',new,old],cwd=repo,check=True)
head=git('rev-parse','HEAD').decode().strip()
for root,hashes in [(repo/'packages/stridetorch/src/stridetorch',read(r/'selected-source-freeze.json')['source_hashes']),(repo/'packages/stridetorch/tests',read(r/'local-integration/test-inputs.json')),(repo,read(r/'local-integration/application-inputs.json')),(repo/'web/public/data',read(r/'local-integration/live-export-sha256.json')),(repo,read(r/'local-integration/immutable-assets.json'))]:
 for name,digest in hashes.items():assert sha((root/name).read_bytes())==digest,name
context=read(r/'path-routing-ui/context.json');assert set(git('diff','--name-only','-z',new,'HEAD').decode().split('\0'))-{''}==set(context['approved_owned_paths'])
external={n:sha((repo/n).read_bytes()) for n in names}
policy=read(r/'main-integration/release-policy-identity.json');policy['files']['.github/workflows/ci.yml']=sha(after)
for name,digest in policy['files'].items():assert sha((repo/name).read_bytes())==digest,name
(r/'main-integration/release-policy-identity.json').write_text(json.dumps(policy,indent=2)+'\n')
variants=read(r/'main-integration/release-policy-variants.json');variants['variants'].append(dict(canonical=new+' reviewed: add asset-validation step only; workflow triggers and release guards unchanged',files=policy['files']));variants['scope']='Exact upstream policies reviewed through path-routing asset validation; all original trigger and release guard logic preserved.';(r/'main-integration/release-policy-variants.json').write_text(json.dumps(variants,indent=2)+'\n')
integration=read(r/'main-integration/integration-context.json');integration['ownership_base']=new;(r/'main-integration/integration-context.json').write_text(json.dumps(integration,indent=2)+'\n')
proof=dict(status='rebased',previous_integration_base=old,integration_base=new,previous_qualified_execution=execution,execution_head=head,external_inputs=external,source_resources_unchanged=62,test_files_unchanged=78,application_inputs_unchanged=1426,combined_owned_paths=390,ci_trigger_delta=False,release_guards_unchanged=True)
(p/'context.json').write_text(json.dumps(proof,indent=2)+'\n');(p/'policy-identity.json').write_text(json.dumps(policy,indent=2)+'\n');print(json.dumps(proof),flush=True)
