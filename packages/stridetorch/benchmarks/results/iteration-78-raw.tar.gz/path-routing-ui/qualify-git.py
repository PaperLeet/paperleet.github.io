from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).resolve().parent;r=p.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
assert read(p/'result.json')['status']==read(r/'asset-retention-ui/result.json')['status']=='passed'
allowed={'docs/validation/torch-runtime-iteration-78.md','packages/stridetorch/benchmarks/results/iteration-78.json','packages/stridetorch/benchmarks/results/iteration-78-raw.tar.gz'}
entries=[x for x in subprocess.check_output(['git','status','--porcelain','-z','--untracked-files=all'],cwd=repo).decode().split('\0') if x];assert {x[3:] for x in entries}==allowed;assert all(x[:2]==' M' for x in entries)
expected=read(r/'main-integration/pre-path-routing-qualified-git-blobs.json')
expected.update(read(p/'context.json')['external_inputs']);expected.update(read(r/'asset-retention-ui/frontend-inputs.json'));expected.update(read(r/'asset-retention-ui/context.json')['external_inputs']);expected.update(read(r/'main-integration/release-policy-identity.json')['files'])
for n in allowed:expected[n]=sha(repo/n)
for n,h in expected.items():assert sha(repo/n)==h,n
context=read(r/'main-integration/integration-context.json');changed=set(subprocess.check_output(['git','diff','--name-only','-z',context['ownership_base']],cwd=repo).decode().split('\0'))-{''};assert changed==set(context['approved_owned_paths'])
raw=read(repo/'packages/stridetorch/benchmarks/results/iteration-78.json')['raw_archive'];assert raw['sha256']==sha(repo/'packages/stridetorch/benchmarks/results'/raw['path'])
(r/'main-integration/qualified-git-blobs.json').write_text(json.dumps(expected,indent=2)+'\n')
subprocess.run(['git','diff','--check'],cwd=repo,check=True);subprocess.run(['git','add','--',*sorted(allowed)],cwd=repo,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=repo).decode().split('\0'))-{''}==allowed
print(json.dumps(dict(status='qualified_evidence_staged',qualified_git_blobs=len(expected),owned_paths=len(changed),staged_paths=3)),flush=True)
