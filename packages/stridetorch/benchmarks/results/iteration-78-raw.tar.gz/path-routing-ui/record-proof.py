from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).resolve().parent;r=p.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
ui=read(p/'result.json');ctx=read(p/'context.json');nested=read(p/'nested-wasm-result.json');assets=read(r/'asset-retention-ui/result.json');latest=read(r/'asset-retention-ui/context.json')
assert ui['status']==nested['status']==assets['status']=='passed'
assert ui['execution_head']==ctx['execution_head']==assets['prior_ui_execution']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==latest['execution_head']
for folder,receipts in [(p,ui['receipts']),(r/'asset-retention-ui',assets['receipts'])]:
 for v in receipts:assert v['exit_code']==0 and sha(folder/(v['label']+'.log'))==v['log_sha256']
for name,h in ui['core_source_hashes'].items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==h,name
assert not nested['page_errors'] and '7 / 7' in nested['feedback']
result=repo/'packages/stridetorch/benchmarks/results/iteration-78.json';data=read(result);assert 'path_routing_ui_requalification' not in data
summary={k:v for k,v in ui.items() if k not in ['frontend_inputs','core_source_hashes']};summary.update(frontend_inputs_count=len(ui['frontend_inputs']),core_source_resources=62,evidence_directory='path-routing-ui')
data['path_routing_ui_requalification']=summary
data['nested_browser_wasm_smoke']={k:v for k,v in nested.items() if k not in ['served','blocked_external_requests','probe_source']};data['nested_browser_wasm_smoke'].update(served_identities=len(nested['served']),record_sha256=sha(p/'nested-wasm-result.json'),harness_sha256=sha(p/'check-nested-wasm.mjs'),evidence_directory='path-routing-ui',external_write_requests_blocked=True)
data['asset_retention_reconciliation']=assets
data['latest_integration_base']=latest['integration_base'];data['core_numerical_execution_provenance_preserved']=True
result.write_text(json.dumps(data,indent=2)+'\n')
doc=repo/'docs/validation/torch-runtime-iteration-78.md';text=doc.read_text();assert '## Path-routing integration' not in text
text+='\n## Path-routing integration\n\n'+f"A further 106 upstream paths were reconciled at `{ctx['integration_base']}`. The actual frontend qualification ran on `{ctx['execution_head']}`: complete frontend checks, release-policy checks, default build, path-routing production-profile build and exact generated-worker verification passed. The production build verified all 166 static HTTP 200 routes, metadata, no-JS content, root assets and real missing-page 404s. Upstream added `VITE_PATH_ROUTING=1` to the CI/Pages build environment; release triggers and SHA gates were preserved. All 62 core resources, 78 tests, 1,426 application inputs, live exports and 15,139 prior immutable resources retained their qualified identities. Original numerical executions retain their original SHA.\n\n"
text+='A fresh real Chrome session opened `/problems/architecture/attention/`, edited the canonical solution through CodeMirror, and executed the real judge Worker with Pyodide/NumPy WASM. All 7/7 Attention tests passed, together with explicit `mm` gradient, nonempty `bmm`, and mixed-dtype empty `bmm` assertions. The hosted health and anonymous-account responses were trusted test fixtures; all other external requests, including writes, were blocked. This verifies the local browser execution flow, without claiming live backend/API integration. The first harness attempt stopped at the expected read-only health precondition and is retained separately.\n\n'
text+=f"Upstream then added a three-file static-asset retention fix at `{latest['integration_base']}`. It normalizes root-relative asset references and adds local validation; the exact workflow delta only adds two validation commands. The resulting local tree `{latest['execution_head']}` preserves all other tested frontend/build and numerical inputs. Twenty asset-retention tests, a read-only validation of the actual 253-asset production build, release-gate checks and backfill checks passed. Prior browser-served build payloads were rechecked byte-for-byte. No CI, tag, publication or deployment was initiated.\n"
doc.write_text(text)
state=read(r/'state.json');state.update(status='076_path_routing_and_asset_integration_qualified',previous_goal_turn_classification='progress',local_commit=latest['execution_head'],remote_main_observed=latest['integration_base'],main_adopted=False,path_routing_ui='passed',nested_browser_wasm='passed',asset_retention_reconciliation='passed',active_processes=[],worktree_clean=False);(r/'state.json').write_text(json.dumps(state,indent=2)+'\n')
old=r/'main-integration/qualified-git-blobs.json';copy=r/'main-integration/pre-path-routing-qualified-git-blobs.json';assert not copy.exists();copy.write_bytes(old.read_bytes())
print('Recorded actual browser, path-routing builds and upstream asset-retention validation; original numerical provenance preserved.',flush=True)
