import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const repo='/Users/david/Developer/PaperLeet-torch-release',root=path.join(repo,'web/dist');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const original=fs.readFileSync(path.join(repo,'problems/architecture/attention/solution.py'),'utf8');
const probe=`
# pl_matrix_probe_v076: execute new entry points through the actual judge Worker.
_pl_a = torch.ones(2, 3, requires_grad=True)
torch.mm(input=_pl_a, mat2=torch.ones(3, 4)).sum().backward()
assert _pl_a.grad.tolist() == [[4.0, 4.0, 4.0]] * 2
assert torch.bmm(torch.ones(2, 2, 3), torch.ones(2, 3, 4)).sum().item() == 48.0
_pl_empty = torch.bmm(torch.ones(2, 3, 0, dtype=torch.float64), torch.ones(2, 0, 4, dtype=torch.float32))
assert _pl_empty.dtype == torch.float32 and tuple(_pl_empty.shape) == (2, 3, 4)
assert _pl_empty.sum().item() == 0.0
del _pl_a, _pl_empty
`;
const source=original+'\n'+probe;
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.wasm':'application/wasm','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon'};
const served=[];
const server=http.createServer(async(request,response)=>{
 try{
  const pathname=decodeURIComponent(new URL(request.url,'http://localhost').pathname),target=path.resolve(root,'.'+pathname);assert(target===root||target.startsWith(root+path.sep));
  const stat=await fs.promises.stat(target);
  if(stat.isDirectory()&&!pathname.endsWith('/')){response.writeHead(301,{location:pathname+'/'});response.end();return;}
  const file=stat.isDirectory()?path.join(target,'index.html'):target,bytes=await fs.promises.readFile(file);
  served.push({path:pathname,sha256:sha(bytes),bytes:bytes.length});
  response.writeHead(200,{'content-type':mime[path.extname(file)]||'application/octet-stream','access-control-allow-origin':'*','cache-control':'no-store'});response.end(bytes);
 }catch{response.writeHead(404);response.end('Not found');}
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const origin='http://127.0.0.1:'+server.address().port;let browser;
const output=new URL('nested-wasm-result.json',import.meta.url),diagnostic=new URL('nested-wasm-diagnostic.json',import.meta.url);
try{
 browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 const context=await browser.newContext(),page=await context.newPage();const external=[],errors=[],workers=[];
 await context.route('**/*',route=>{
  const url=route.request().url();
  if(url.startsWith(origin+'/')||url.startsWith('blob:')||url.startsWith('data:'))return route.continue();
  external.push({method:route.request().method(),url});return route.abort();
 });
 page.on('pageerror',error=>errors.push(String(error)));page.on('worker',worker=>workers.push(worker.url()));
 try{
  const response=await page.goto(origin+'/problems/architecture/attention/',{waitUntil:'domcontentloaded'});assert.equal(response.status(),200);
  assert((await response.text()).includes('data-routing="path"'));
  const editor=page.locator('.python-editor .cm-content').first();await editor.waitFor({state:'visible',timeout:60000});
  await editor.click();await editor.press('ControlOrMeta+A');await page.keyboard.insertText(source);
  await page.waitForFunction(()=>document.querySelector('.python-editor .cm-content')?.textContent?.includes('pl_matrix_probe_v076'));
  const run=page.getByRole('button',{name:/^(Run tests|运行测试)$/});await run.waitFor({state:'visible'});assert(await run.isEnabled());
  console.log('Nested path booted, source edited through CodeMirror, starting real browser judge.');await run.click();
  const success=page.locator('.workspace-test-results .result-head.success');await success.waitFor({state:'visible',timeout:240000});
  const feedback=await success.innerText();assert(/7\s*\/\s*7/.test(feedback),feedback);assert(/Tests passed|测试通过/.test(feedback));
  const runtime=served.filter(row=>/\/data\/browser-judge\/runtime-[a-f0-9]+\.json$/.test(row.path));assert(runtime.length>0);
  const runtimeBodies=runtime.map(row=>JSON.parse(fs.readFileSync(path.join(root,row.path),'utf8')));
  assert(runtimeBodies.some(body=>Object.values(body.files||{}).some(text=>typeof text==='string'&&text.includes("__version__ = '0.76.0'"))));
  assert(served.some(row=>row.path.endsWith('/pyodide.asm.wasm')));assert(served.some(row=>row.path.includes('numpy-2.2.5')&&row.path.endsWith('.whl')));assert(workers.length>0);
  const report={status:'passed',path:new URL(page.url()).pathname,feedback,browser:browser.version(),workers,source_sha256:sha(Buffer.from(source)),reference_source_sha256:sha(Buffer.from(original)),probe_source:probe,served,blocked_external_requests:external,page_errors:errors,scope:'Fresh real Chrome loads the actual prerendered nested problem page, enters the canonical attention solution plus explicit mm/bmm/empty-dtype assertions through the editor, and runs actual local Pyodide/NumPy WASM tests. External API calls are blocked; no server submission or account mutation.'};
  fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,path:report.path,feedback,workers:workers.length,runtime_assets:runtime.length}));
 }catch(error){
  fs.writeFileSync(diagnostic,JSON.stringify({error:String(error),url:page.url(),body:(await page.locator('body').innerText()).slice(-18000),errors,workers,served,external},null,2)+'\n');throw error;
 }finally{await context.close();}
}finally{await browser?.close();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
