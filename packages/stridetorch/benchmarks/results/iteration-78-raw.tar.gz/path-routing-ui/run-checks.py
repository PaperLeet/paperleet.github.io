from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent;r=p.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
context=read(p/'context.json');node='/Users/david/.npm/_npx/d18f28baf1132559/node_modules/node/bin/node';python=r.parent/'torch-iteration-69/integration-dev-env/bin/python'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHON=str(python),PYTHONPATH=str(repo/'packages/stridetorch/src')+os.pathsep+str(repo),OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');env['PATH']=str(Path(node).parent)+':/opt/homebrew/bin:'+str(python.parent)+':'+env['PATH']
names=[n for n in subprocess.check_output(['git','ls-files','-z','--','web/src','web/scripts','web/index.html','web/package.json','web/package-lock.json','web/vite.config.ts','web/tsconfig*.json','web/public/browser-judge','web/public/favicon.ico','web/public/favicon.png'],cwd=repo).decode().split('\0') if n]
frontend={n:sha(repo/n) for n in names};(p/'frontend-inputs.json').write_text(json.dumps(frontend,indent=2)+'\n');receipts=[]
def verify():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==context['execution_head']
    for root,values in [(repo/'packages/stridetorch/src/stridetorch',context['source_hashes']),(repo/'packages/stridetorch/tests',read(r/'local-integration/test-inputs.json')),(repo,read(r/'local-integration/application-inputs.json')),(repo,read(p/'policy-identity.json')),(repo,read(r/'local-integration/immutable-assets.json')),(repo/'web/public/data',read(r/'local-integration/live-export-sha256.json')),(repo,frontend),(repo,context['external_inputs'])]:
        for n,h in values.items():assert sha(root/n)==h,n
def run(label,args,cwd=repo,extra=None):
    verify();start=time.monotonic()
    with (p/(label+'.log')).open('w') as log:
        child=subprocess.Popen(args,cwd=cwd,env={**env,**(extra or {})},stdout=log,stderr=subprocess.STDOUT)
        (p/'progress.json').write_text(json.dumps(dict(status='running',label=label,pid=child.pid,receipts=receipts),indent=2)+'\n');code=child.wait()
    receipt=dict(label=label,exit_code=code,seconds=time.monotonic()-start,command=args,cwd=str(cwd),log_sha256=sha(p/(label+'.log')),summary=(p/(label+'.log')).read_text().splitlines()[-1:]);receipts.append(receipt);(p/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(receipt),flush=True)
    if code:raise SystemExit(code)
    verify()
run('full-frontend-check',['npm','run','check'],repo/'web')
run('pages-policy',[node,'web/scripts/check-pages-release.cjs'])
run('build',['npm','run','build'],repo/'web',dict(VITE_PATH_ROUTING='0'))
value=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED','--jq','.value'],cwd=repo,text=True).strip();assert value in ['0','1']
profile=dict(VITE_PATH_ROUTING='1',PAPERLEET_MAIN_SITE_ENABLED=value,VITE_PUBLIC_SITE='0' if value=='1' else '1',VITE_APP_EDITION='hosted' if value=='1' else 'local',VITE_API_ORIGIN='https://app.paperleet.com' if value=='1' else '',VITE_HOSTED_APP_AVAILABLE='1',VITE_HOSTED_APP_URL='https://app.paperleet.com')
(p/'pages-profile.json').write_text(json.dumps(profile,indent=2)+'\n');run('pages-profile-build',['npm','run','build'],repo/'web',profile)
run('generated-worker',[node,str(p/'verify-generated-worker.mjs')])
worker=read(p/'generated-worker-proof.json');assert worker['inputs']==read(r/'local-integration/generated-worker-proof.json')['inputs']
verify();result=dict(status='passed',execution_head=context['execution_head'],integration_base=context['integration_base'],original_numeric_execution_base=context['original_numeric_execution_base'],receipts=receipts,core_source_hashes=context['source_hashes'],application_inputs_unchanged=1426,external_paths_preserved=len(context['external_inputs']),combined_owned_paths=context['combined_owned_paths'],frontend_inputs=frontend,worker_inputs_unchanged=True,no_numeric_rerun_claimed=True,ci_triggered=False,published=False,deployed=False)
(p/'result.json').write_text(json.dumps(result,indent=2)+'\n');(p/'progress.json').write_text(json.dumps(dict(status='completed',receipts=receipts),indent=2)+'\n');print('REBASED UI QUALIFICATION PASSED',flush=True)
