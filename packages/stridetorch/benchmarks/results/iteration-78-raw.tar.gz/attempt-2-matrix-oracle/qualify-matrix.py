"""Exact inputs and independent native 2.6 controls for strict matrix APIs."""
import argparse,hashlib,json
from pathlib import Path
import numpy as np


def specifications():
    for operation in ['mm','bmm']:
        for dtype in ['bool','uint8','int8','int16','int32','int64','uint16','uint32','uint64','float16','float32','float64','complex64','complex128']:
            for dims in [(2,3,4,2),(0,3,4,2),(2,0,4,2),(2,3,0,2),(2,3,4,0)]:
                yield dict(operation=operation,dtype=dtype,dims=dims)


def data(shape,dtype,offset=0):
    raw=(np.arange(np.prod(shape),dtype=np.int64).reshape(shape)+offset)%7-3
    if dtype=='bool':return raw>0
    value=raw.astype(dtype)
    if np.dtype(dtype).kind in 'fc':value=value/np.asarray(8,dtype=dtype)
    if np.dtype(dtype).kind=='c':value=value+(value*.5j).astype(dtype)
    return value


def execute(torch,*,native):
    arrays={};rows=[]
    for i,spec in enumerate(specifications()):
        m,k,n,batch=spec['dims'];operation=spec['operation'];dtype=spec['dtype']
        a=data((m,k) if operation=='mm' else (batch,m,k),dtype)
        b=data((k,n) if operation=='mm' else (batch,k,n),dtype,2)
        try:
            value=getattr(torch,operation)(input=torch.from_numpy(a),mat2=torch.from_numpy(b)).numpy()
            arrays[f'value_{i}']=value;row=dict(status='passed',shape=list(value.shape),dtype=value.dtype.str)
        except Exception as error:row=dict(status='rejected',error=type(error).__name__)
        rows.append(dict(**spec,**row))
    # Bilinear derivatives, noncontiguous layouts and empty mixed dtypes.
    ad=[]
    shapes=[('mm',(3,4),(4,2)),('mm',(0,4),(4,2)),('mm',(3,0),(0,2)),('bmm',(2,3,4),(2,4,2)),('bmm',(0,3,4),(0,4,2)),('bmm',(2,3,0),(2,0,2))]
    shapes += [('bmm',(4,64,64),(4,64,64)),('mm',(128,64),(64,128))]
    for operation,shape_a,shape_b in shapes:
        for dtype in ['float32','float64']:
            for layout in ['C','F','stride']:
                a,b,ta,tb=[data(shape,dtype,offset) for shape,offset in [(shape_a,0),(shape_b,1),(shape_a,2),(shape_b,3)]]
                if layout=='F':a,b,ta,tb=map(np.asfortranarray,(a,b,ta,tb))
                if layout=='stride':a,b,ta,tb=[np.repeat(x,2,axis=-1)[...,::2] for x in (a,b,ta,tb)]
                x,w=[torch.from_numpy(z).requires_grad_() for z in (a,b)];dx,dw=map(torch.from_numpy,(ta,tb))
                fn=getattr(torch,operation);y=fn(x,w);seed=torch.from_numpy(data(tuple(y.shape),dtype,4))
                ga,gb=torch.autograd.grad(y,(x,w),seed)
                primal,tangent=torch.func.jvp(fn,(x,w),(dx,dw))
                loss,(ha,hb)=torch.autograd.functional.hvp(lambda x,w:fn(x,w).square().sum()*.5,(x,w),(dx,dw))
                key=f'ad_{len(ad)}';values=[y,ga,gb,primal,tangent,loss,ha,hb]
                for field,value in zip(['y','ga','gb','primal','tangent','loss','ha','hb'],values):arrays[key+'_'+field]=value.detach().numpy()
                ad.append(dict(operation=operation,shape_a=shape_a,shape_b=shape_b,dtype=dtype,layout=layout))
    mixed=[]
    for shape_a,shape_b in [((2,0,3),(2,3,4)),((2,3,0),(2,0,4)),((2,3,4),(2,4,0)),((0,3,4),(0,4,2))]:
        for da,db in [('float32','float64'),('float64','float32')]:
            x=torch.from_numpy(data(shape_a,da)).requires_grad_();w=torch.from_numpy(data(shape_b,db)).requires_grad_()
            dx=torch.from_numpy(data(shape_a,da,1));dw=torch.from_numpy(data(shape_b,db,2))
            y=torch.bmm(x,w);ga,gb=torch.autograd.grad(y,(x,w),torch.ones_like(y))
            primal,tangent=torch.func.jvp(torch.bmm,(x,w),(dx,dw))
            loss,(ha,hb)=torch.autograd.functional.hvp(lambda x,w:torch.bmm(x,w).square().sum()*.5,(x,w),(dx,dw))
            key=f'mixed_{len(mixed)}'
            for field,value in zip(['y','ga','gb','primal','tangent','loss','ha','hb'],[y,ga,gb,primal,tangent,loss,ha,hb]):arrays[key+'_'+field]=value.detach().numpy()
            mixed.append(dict(shape_a=shape_a,shape_b=shape_b,dtype_a=da,dtype_b=db))
    return dict(rows=rows,ad=ad,mixed=mixed),arrays


if __name__=='__main__':
    args=argparse.ArgumentParser();args.add_argument('--native',action='store_true');options=args.parse_args()
    if options.native:
        import torch
        torch.set_num_threads(2)
        meta,arrays=execute(torch,native=True)
        np.savez('matrix-oracle.npz',**arrays);meta.update(torch=torch.__version__,numpy=np.__version__,program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
        Path('matrix-oracle.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(dict(status='generated',inference=len(meta['rows']),ad=len(meta['ad']),mixed=len(meta['mixed']))))
    else:
        from stridetorch import torch
        meta,arrays=execute(torch,native=False);expected=json.loads(Path('matrix-oracle.json').read_text());control=np.load('matrix-oracle.npz')
        assert json.loads(json.dumps(meta))=={k:expected[k] for k in ['rows','ad','mixed']}
        assert set(arrays)==set(control.files)
        for name,value in arrays.items():
            reference=control[name];assert value.dtype==reference.dtype and value.shape==reference.shape,name
            if value.dtype.kind in 'biu':np.testing.assert_array_equal(value,reference,err_msg=name)
            else:np.testing.assert_allclose(value,reference,rtol=3e-3 if value.dtype==np.float16 else 3e-5 if value.dtype in (np.float32,np.complex64) else 3e-11,atol=3e-3 if value.dtype==np.float16 else 3e-5 if value.dtype in (np.float32,np.complex64) else 3e-11,err_msg=name)
        report=dict(status='passed',inference=len(meta['rows']),ad=len(meta['ad']),mixed=len(meta['mixed']),arrays=len(arrays),oracle_sha256=hashlib.sha256(Path('matrix-oracle.npz').read_bytes()).hexdigest(),numpy=np.__version__)
        Path('matrix-native-candidate-result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
