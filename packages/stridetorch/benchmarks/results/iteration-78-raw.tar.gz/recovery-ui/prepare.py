from pathlib import Path
import hashlib,json,shutil,subprocess
p=Path(__file__).resolve().parent;r=p.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=repo)
old='891f620921791775082e2e290ff5caf8e06e5b72';new='a16a0e54605fba6cea4d06603814ae664b12e4da';head=git('rev-parse','HEAD').decode().strip();assert head=='0b9ca2a99be666ef998fc43788aee00df0a47d3c';assert not git('status','--porcelain','-z')
names=[n for n in git('diff','--name-only','-z',old,new).decode().split('\0') if n];assert len(names)==19
assert all(n.startswith(('web/src/','web/scripts/','docs/validation/')) or n=='web/package.json' for n in names)
a=json.loads(git('show',old+':web/package.json'));b=json.loads(git('show',new+':web/package.json'));sa=a.pop('scripts');sb=b.pop('scripts');assert a==b and set(sa)==set(sb)
for k in sa:
 if k!='check':assert sa[k]==sb[k]
old_checks=sa['check'].split(' && ');new_checks=sb['check'].split(' && ');assert [s for s in new_checks if s in old_checks]==old_checks
added=[s for s in new_checks if s not in old_checks];assert set(added)=={'node scripts/check-admin-paper-progress.mjs','node scripts/check-interview-filter-support.mjs'}
(p/'upstream.diff').write_bytes(git('diff',old,new));subprocess.run(['git','update-ref','refs/codex/checkpoints/torch-iteration-78-before-recovery-ui',head],cwd=repo,check=True);subprocess.run(['git','rebase','--onto',new,old],cwd=repo,check=True)
head=git('rev-parse','HEAD').decode().strip();ctx=read(r/'asset-retention-ui/context.json');context=dict(execution_head=head,integration_base=new,original_numeric_execution_base='0ed2aa3a95d9e7febf683874b5dafd1284af5f1f',pre_rebase_qualified_commit='0b9ca2a99be666ef998fc43788aee00df0a47d3c',source_hashes=read(r/'selected-source-freeze.json')['source_hashes'],external_inputs={n:sha(repo/n) for n in names},combined_owned_paths=390,added_check_commands=added)
(p/'context.json').write_text(json.dumps(context,indent=2)+'\n');shutil.copyfile(r/'main-integration/release-policy-identity.json',p/'policy-identity.json')
for source,target in [('path-routing-ui/run-checks.py','run-checks.py'),('path-routing-ui/verify-generated-worker.mjs','verify-generated-worker.mjs'),('path-routing-ui/check-nested-wasm.mjs','check-nested-wasm.mjs')]:shutil.copyfile(r/source,p/target)
script=(p/'run-checks.py').read_text().replace("run('generated-worker'", "run('pages-assets',[str(python),'-B','web/scripts/check-pages-assets.py'])\nrun('retain-production-assets-check',[str(python),'-B','web/scripts/retain-pages-assets.py','web/dist','--check'])\nrun('generated-worker'");(p/'run-checks.py').write_text(script)
old_manifest=r/'main-integration/qualified-git-blobs.json';shutil.copyfile(old_manifest,r/'main-integration/pre-recovery-qualified-git-blobs.json')
ctx=read(r/'main-integration/integration-context.json');ctx['ownership_base']=new;(r/'main-integration/integration-context.json').write_text(json.dumps(ctx,indent=2)+'\n')
print(json.dumps(dict(status='rebased',head=head,integration_base=new,external_paths=len(names),added_check_commands=added)),flush=True)
