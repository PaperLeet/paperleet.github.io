from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).resolve().parent;r=p.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
ui=read(p/'result.json');context=read(p/'context.json');nested=read(p/'nested-wasm-result.json');assert ui['status']==nested['status']=='passed'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==context['execution_head']
assert not subprocess.check_output(['git','status','--porcelain','-z'],cwd=repo)
for row in ui['receipts']:assert row['exit_code']==0 and sha(p/(row['label']+'.log'))==row['log_sha256']
for n,h in context['source_hashes'].items():assert sha(repo/'packages/stridetorch/src/stridetorch'/n)==h,n
for row in nested['served']:
 target=repo/'web/dist'/row['path'].lstrip('/')
 if target.is_dir():target=target/'index.html'
 assert sha(target)==row['sha256'],str(target)
result=repo/'packages/stridetorch/benchmarks/results/iteration-78.json';data=read(result);assert 'recovery_ui_requalification' not in data
summary={k:v for k,v in ui.items() if k not in ['frontend_inputs','core_source_hashes']};summary.update(frontend_input_count=len(ui['frontend_inputs']),evidence_directory='recovery-ui',nested_browser_wasm=dict(status=nested['status'],feedback=nested['feedback'],record_sha256=sha(p/'nested-wasm-result.json'),harness_sha256=sha(p/'check-nested-wasm.mjs'),served_identities=len(nested['served']),scope=nested['scope']))
data['recovery_ui_requalification']=summary;data['latest_integration_base']=context['integration_base'];result.write_text(json.dumps(data,indent=2)+'\n')
doc=repo/'docs/validation/torch-runtime-iteration-78.md';text=doc.read_text();assert '## Concurrent UI recovery' not in text;text+='\n## Concurrent UI recovery\n\n'+f"An ordinary guarded push after the existing release chain ended failed with a transport broken pipe; no adoption is inferred from that attempt. Main independently advanced to `{context['integration_base']}` by two UI commits (19 paths), preserved at reconciliation. The rebased execution tree `{context['execution_head']}` retains those interview/admin changes, unchanged frontend dependencies, both newly added checks and all original check commands. Core/test/application/export and current release-policy identities are unchanged.\n\n"
text+='Complete frontend checks, both default and production path-routing builds, asset-retention checks, release policies and exact worker regeneration passed on the new tree. The fresh nested Attention page again passed 7/7 real Worker/Pyodide tests plus explicit mm/bmm assertions, with the same documented trusted health/anonymous-account fixtures and blocked external writes. Original full numerical test SHAs are preserved. No CI, tag, package publication or deployment was initiated.\n';doc.write_text(text)
state=read(r/'state.json');state.update(status='076_recovery_ui_qualified',local_commit=context['execution_head'],remote_main_observed=context['integration_base'],worktree_clean=False,active_processes=[],main_adopted=False,recovery_ui='passed');(r/'state.json').write_text(json.dumps(state,indent=2)+'\n')
f=r/'archive-evidence.py';text=f.read_text();needle="'path-routing-ui','asset-retention-ui']";assert text.count(needle)==1;text=text.replace(needle,"'path-routing-ui','asset-retention-ui','recovery-ui']");needle="'main-integration/before-completion-cutoff']";assert text.count(needle)==1;text=text.replace(needle,"'main-integration/before-completion-cutoff','recovery-ui/attempt-policy-shape']");f.write_text(text)
print('Recorded recovery UI and browser validation with original numerical provenance.',flush=True)
