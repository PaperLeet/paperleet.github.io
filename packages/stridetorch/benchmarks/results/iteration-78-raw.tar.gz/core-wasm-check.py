import json,runpy,sys,os
from pathlib import Path
from stridetorch import torch,_tensor
import stridetorch
assert stridetorch.__version__=='0.76.0' and _tensor._WASM_MATMUL
os.chdir('/')
sys.argv=['qualify-matrix.py']
runpy.run_path('/qualify-matrix.py',run_name='__main__')
native=json.loads(Path('/matrix-native-candidate-result.json').read_text())
sys.argv=['probe-matrix-guards.py']
runpy.run_path('/probe-matrix-guards.py',run_name='__main__')
guards=json.loads(Path('/matrix-candidate-guards.json').read_text())
sys.argv=['probe-empty-dtypes.py']
runpy.run_path('/probe-empty-dtypes.py',run_name='__main__')
empty=json.loads(Path('/empty-dtype-candidate.json').read_text())
import pytest
class Record:
    passed=0
    def __init__(self):self.failures=[]
    def pytest_runtest_logreport(self,report):
        if report.when=='call' and report.passed:self.passed+=1
        if report.failed:self.failures.append(dict(test=report.nodeid,error=str(report.longrepr)[-3000:]))
record=Record()
exit_code=pytest.main(['/contracts','-q','--noconftest','-p','no:cacheprovider','--import-mode=importlib'],plugins=[record])
wasm_report=dict(status='passed' if exit_code==0 else 'failed',native=native,guard_cases=len(guards),empty_dtype_cases=len(empty['rows']),sdk=dict(exit_code=int(exit_code),passed=record.passed,failures=record.failures))
