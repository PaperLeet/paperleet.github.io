import json
import numpy as np
import torch
torch.set_num_threads(2)
rows=[]
for operation in ['mm','bmm']:
    for dtype_name in ['bool','uint8','int8','int16','int32','int64','uint16','uint32','uint64','float16','float32','float64','complex64','complex128']:
        dtype=getattr(torch,dtype_name)
        for m,k,n,batch in [(2,3,4,2),(0,3,4,2),(2,0,4,2),(2,3,0,2),(2,3,4,0)]:
            shape_a=(m,k) if operation=='mm' else (batch,m,k)
            shape_b=(k,n) if operation=='mm' else (batch,k,n)
            a=torch.ones(shape_a,dtype=dtype);b=torch.ones(shape_b,dtype=dtype)
            try:
                value=getattr(torch,operation)(input=a,mat2=b)
                row=dict(status='passed',shape=list(value.shape),output_dtype=str(value.dtype))
            except Exception as error:
                row=dict(status='rejected',error=type(error).__name__,message=str(error))
            rows.append(dict(operation=operation,dtype=dtype_name,dimensions=[m,k,n,batch],**row))
keywords=[]
for operation in ['mm','bmm']:
    shape=(2,2) if operation=='mm' else (1,2,2)
    a=torch.ones(shape)
    for name in ['mat2','batch2','other','out']:
        try:
            value=getattr(a,operation)(**{name:a});result=dict(status='passed')
        except Exception as error:result=dict(status='rejected',error=type(error).__name__,message=str(error))
        keywords.append(dict(operation=operation,keyword=name,**result))
report=dict(torch=torch.__version__,numpy=np.__version__,rows=rows,method_keywords=keywords)
with open('native-matrix-probe.json','w') as output:json.dump(report,output,indent=2);output.write('\n')
print(json.dumps(dict(torch=torch.__version__,cases=len(rows),accepted=sum(x['status']=='passed' for x in rows),method_keywords=keywords)))
