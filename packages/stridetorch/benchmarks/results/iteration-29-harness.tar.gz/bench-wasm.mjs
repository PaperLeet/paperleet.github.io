import fs from 'node:fs';import path from 'node:path';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const source=process.argv[2],dtype=process.argv[3],repo='/Users/david/Developer/PaperLeet-torch-release';
const py=await loadPyodide({indexURL:path.join(repo,'web/node_modules/pyodide/'),packageCacheDir:path.join(repo,'web/public/browser-runtime/pyodide-0.29.4/'),stdout:()=>{},stderr:console.error});await loadJudgePackages(py,[]);
py.FS.mkdirTree('/runtime/stridetorch');for(const name of fs.readdirSync(source).filter(n=>n.endsWith('.py')||['LICENSE','NOTICE'].includes(n)))py.FS.writeFile('/runtime/stridetorch/'+name,fs.readFileSync(path.join(source,name)));
py.globals.set('bench_source','/runtime/stridetorch');py.globals.set('bench_dtype',dtype);py.globals.set('bench_runtime','wasm');py.runPython(fs.readFileSync(new URL('bench.py',import.meta.url),'utf8'));console.log(py.runPython('json.dumps(bench_result)'));
