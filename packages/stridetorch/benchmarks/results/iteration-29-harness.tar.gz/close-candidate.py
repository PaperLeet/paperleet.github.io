from pathlib import Path
import hashlib,json,re,subprocess,tarfile
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');proof=r/'proof';out=repo/'packages/stridetorch/benchmarks/results'
def read(p):return json.loads(p.read_text())
def hashes(folder):return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir() if p.is_file() and (p.suffix=='.py' or p.name in ('LICENSE','NOTICE'))}
source=hashes(repo/'packages/stridetorch/src/stridetorch');assert len(source)==45 and source==hashes(r/'trial-selective/stridetorch')==hashes(proof/'source')==hashes(proof/'chrome-contracts/source')
node=read(proof/'source-wasm.json');chrome=read(proof/'chrome-contracts/result.json');wheel=read(proof/'wheel-stride029-result.json');plan=read(proof/'chrome-contracts/plan.json')
for data in (node,chrome,wheel):assert data['source_hashes']==source and data['library']=='0.29.0'
assert node['passed']==chrome['passed']==904 and chrome['status']==wheel['status']=='success' and not wheel['native_torch']
assert chrome['test_hashes']==plan['tests']=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'} and len(plan['tests'])==29
assert '916 passed' in (proof/'python310-stride029-tests.log').read_text()
base=re.search(r'(29853) passed, (1) skipped, (34) warnings in ([\d.]+)s',(r/'full-native.log').read_text());assert base
assert '574 passed' in (r/'focused-selective.log').read_text()
phases={};receipts=[]
for phase,variant in [('initial','candidate'),('optimized','trial-optimized'),('selective','trial-selective')]:
 folder=r/('performance-'+phase);phase_receipts=read(folder/'receipts.json');assert len(phase_receipts)==16 and all(x['exit_code']==0 for x in phase_receipts)
 for receipt in phase_receipts:
  data=read(folder/(receipt['name']+'.json'));expected=hashes(r/('baseline' if receipt['name'].endswith('-baseline') else variant)/'stridetorch');assert data['source_hashes']==expected
  assert len(data['records'])==14 and all(len(case['batches_us'])==9 for case in data['records'].values())
 phases[phase]=dict(summary=read(r/('performance-'+phase+'-summary.json')),receipts=phase_receipts,source_hashes=hashes(r/variant/'stridetorch'));receipts+=phase_receipts
report=dict(status='candidate_core_validated_performance_and_application_adoption_pending',version='0.29.0',baseline_commit=read(r/'state.json')['baseline_commit'],candidate_source='trial-selective/stridetorch',source_hashes=source,base=dict(passed=29853,optional_skips=1,warnings=34,elapsed_s=float(base[4])),focused_passed=574,minimum=dict(passed=916,python=wheel['python'],numpy=wheel['numpy'],native_torch=wheel['native_torch'],artifacts=wheel['artifacts']),node=node,chrome=chrome,performance=phases,performance_children=len(receipts),timing_scope='Fresh-process ABBA;2x2/16x16 matrix RHS;retained backward,forward/square/mean/backward,andno-grad. No optimizer update in timed function. Shared host;actual BLAS thread count unverified. Full-flow/no-grad regressions remain;not a stable integration candidate yet.',new_independent_tests=23,scope='Dense batched/broadcast left/right solve,real VJP/JVP,native primal result layout and saved-value guards;complex inference only. No reusable LU backend,out buffers,sparse or half factorization.',processes=dict(full_base=dict(session=62349,exit_code=0),focused=dict(session=15673,exit_code=0),node=dict(session=71742,exit_code=0),chrome=dict(session=29057,exit_code=0),minimum=dict(session=98536,exit_code=0),build=dict(session=36547,exit_code=0),performance_initial=dict(session=11017,exit_code=0),performance_optimized=dict(session=37521,exit_code=0),performance_selective=dict(session=7956,exit_code=0)),failed_checks_retained=['native-initial.log:117failures;layout and JVP factor behavior plus complex-conjugate/nonleaf fixture mistakes','native-second.log:22failures;materialized zero derivative edges missing','focused-fourth.log:1failure;capability attribute typo;corrected to _browser_capabilities','All performance regressions and trial sources retained'],remaining=['Profile/optimize common unbatched forward and graph metadata without dropping native layouts or guards','Confirm complete-flow cost is suitable before stable main adoption','Latest-main full application/exported WASM/distribution/frontend gates when candidate is ready','Exact remote Quality/actual eligible Pages/live verification for any adopted candidate'])
(r/'local-gates.json').write_text(json.dumps(report,indent=2)+'\n');(r/'implementation.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=repo))
files={}
def add(p,name=None):
 if p.is_file():files[name or str(p.relative_to(r))]=p
for folder in ('baseline/stridetorch','candidate/stridetorch','trial-optimized/stridetorch','trial-selective/stridetorch','performance-initial','performance-optimized','performance-selective','proof/source','proof/chrome-contracts','proof/dist-preflight','proof/python310-stride029-tests'):
 for p in (r/folder).rglob('*'):
  if '__pycache__' not in p.parts and '.pytest_cache' not in p.parts:add(p)
for folder in (r,proof):
 for p in folder.iterdir():
  if p.suffix in ('.py','.mjs','.json','.log','.patch'):add(p)
for name in ('tests/test_torch_solve.py','packages/stridetorch/tests/test_solve.py','packages/stridetorch/README.md','packages/stridetorch/pyproject.toml','docs/validation/torch-runtime-iteration-29.md'):add(repo/name,'maintained/'+name)
archive=out/'iteration-29-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
report['archive']=dict(file=archive.name,files=len(files),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest());(out/'iteration-29.json').write_text(json.dumps(report,indent=2)+'\n')
state=read(r/'state.json');state.update(phase=report['status'],source_hashes=source,local_report=str(out/'iteration-29.json'),archive=report['archive'],processes=report['processes'],next=report['remaining'],turn_classification='progress:0.28 exact-source remote/deployment/live verified;0.29 batch/right-solve candidate added with29853base+minimum916+Node/Chrome904 validated;48timingchildren expose unresolved complete-flow regressions;main stays0.28');(r/'state.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(dict(status=report['status'],archive=report['archive']),indent=2))
