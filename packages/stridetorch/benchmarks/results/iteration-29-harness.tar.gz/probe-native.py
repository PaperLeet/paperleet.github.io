import torch,json
print(torch.__version__)
for shape in [(3,), (2,3),(3,3),(1,3),(2,1,3),(2,3,1)]:
 for ashape in [(3,3),(2,3,3),(1,3,3),(2,1,3,3)]:
  for left in (True,False):
   a=torch.eye(3,dtype=torch.float64).expand(ashape).clone();b=torch.ones(shape,dtype=torch.float64)
   try:r=torch.linalg.solve(a,b,left=left);print('shape',ashape,shape,left,list(r.shape))
   except Exception as e:print('error',ashape,shape,left,type(e).__name__)
for needs in [(True,True),(True,False),(False,True)]:
 for mutated in ('a','b','x'):
  a=torch.tensor([[3.,1.],[.2,2.]],requires_grad=needs[0]);b=torch.ones(2,requires_grad=needs[1]);x=torch.linalg.solve(a,b)
  with torch.no_grad():{'a':a,'b':b,'x':x}[mutated].add_(1)
  try:x.sum().backward();print('mutation',needs,mutated,'allowed',[t.grad.tolist() if t.grad is not None else None for t in (a,b)])
  except Exception as e:print('mutation',needs,mutated,type(e).__name__,str(e)[:90])
