import sys,time,statistics,json,hashlib,pathlib,platform
import numpy as np
if 'bench_source' not in globals():bench_source=sys.argv[1];bench_dtype=sys.argv[2];bench_runtime='cpu'
sys.path.insert(0,str(pathlib.Path(bench_source).parent))
started=time.perf_counter();from stridetorch import torch
import_s=time.perf_counter()-started
source=pathlib.Path(bench_source);source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
dtype=getattr(torch,bench_dtype);records={}
for n in (2,16):
 raw=np.eye(n,dtype=bench_dtype)*3+np.arange(n*n,dtype=bench_dtype).reshape(n,n)/(n*n*20)
 right=np.linspace(.3,1.2,n*2,dtype=bench_dtype).reshape(n,2)
 for needs in ((True,True),(True,False),(False,True)):
  a=torch.tensor(raw,dtype=dtype,requires_grad=needs[0]);b=torch.tensor(right,dtype=dtype,requires_grad=needs[1]);seed=torch.ones(n,2,dtype=dtype)
  x=torch.linalg.solve(a,b);assert x.dtype==np.dtype(bench_dtype);np.testing.assert_allclose(x.numpy(),np.linalg.solve(raw,right),rtol=1e-5,atol=1e-6)
  def backward():
   a.grad=None;b.grad=None;x.backward(seed,retain_graph=True)
  def train():
   a.grad=None;b.grad=None;y=torch.linalg.solve(a,b);y.square().mean().backward()
  for name,call in [('retained',backward),('forward_backward',train)]:
   for _ in range(100):call()
   batches=[];loops=500 if n==2 else 100
   for _ in range(9):
    begin=time.perf_counter()
    for i in range(loops):call()
    batches.append((time.perf_counter()-begin)*1e6/loops)
   records[f'{n}/{needs}/{name}']=dict(median_us=statistics.median(batches),batches_us=batches,loops=loops,output_dtype=str(x.dtype))
 a=torch.tensor(raw,dtype=dtype);b=torch.tensor(right,dtype=dtype)
 def forward():return torch.linalg.solve(a,b)
 for _ in range(100):forward()
 batches=[]
 for _ in range(9):
  begin=time.perf_counter()
  for i in range(500):forward()
  batches.append((time.perf_counter()-begin)*1e6/500)
 records[f'{n}/no_grad']=dict(median_us=statistics.median(batches),batches_us=batches,loops=500)
bench_result=dict(runtime=bench_runtime,dtype=bench_dtype,numpy=np.__version__,python=platform.python_version(),import_s=import_s,source_hashes=source_hashes,records=records)
if __name__=='__main__' and 'bench_runtime' in globals() and bench_runtime=='cpu':print(json.dumps(bench_result))
