from pathlib import Path
import hashlib,json,os,subprocess,time,zipfile
r=Path(__file__).parent;expected=json.loads((r/'source-hashes.json').read_text());public=next((r/'dist-preflight').glob('*.whl'));private=next((r/'private-dist').glob('*.whl'));uv='/Users/david/.local/bin/uv';env=os.environ.copy();env.pop('PYTHONPATH',None);receipts=[]
for wheel,prefix in [(public,'stridetorch/'),(private,'paperleet/_vendor/torch/')]:
 with zipfile.ZipFile(wheel) as z:
  actual={n.removeprefix(prefix):hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith(prefix)}
  assert actual==expected,(wheel,actual.keys()^expected.keys())
venv=r/'coinstall-env';python=venv/'bin/python'
def run(cmd,label):
 start=time.monotonic()
 with (r/(label+'.log')).open('w') as log:p=subprocess.run([str(x) for x in cmd],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(label=label,command=[str(x) for x in cmd],exit_code=p.returncode,elapsed_s=time.monotonic()-start));(r/'coinstall-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode();print(label,'terminal0',flush=True)
run([uv,'venv','--clear',venv,'--python','/Users/david/.local/share/uv/python/cpython-3.10.19-macos-aarch64-none/bin/python3.10'],'coinstall-venv')
run([uv,'pip','install','--python',python,'--no-deps','numpy==1.26.4',public,private],'coinstall-install')
check="""import importlib,importlib.util,hashlib,json,pathlib
expected=json.loads(pathlib.Path('source-hashes.json').read_text())
for name in NAMES:
 m=importlib.import_module(name);p=pathlib.Path(m.__file__).parent
 actual={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in p.iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')}
 assert actual==expected and m.__version__=='0.48.0'
 t=m.torch;x=t.tensor([1.,float('nan'),3.],requires_grad=True);y=t.nanmean(x);assert y.item()==2.;y.backward();assert x.grad.tolist()==[.5,0.,.5]
assert importlib.util.find_spec('torch') is None
import numpy as np
for name in NAMES:
 t=importlib.import_module(name).torch
 layer=t.nn.ConvTranspose2d(2,4,3,stride=2,padding=1,output_padding=1,dtype=t.float64)
 x=t.tensor(np.sin(np.arange(36)).reshape(1,2,3,6),requires_grad=True)
 y,dy=t.func.jvp(layer,(x,),(t.ones_like(x),))
 assert y.shape==dy.shape==(1,4,6,12)
 (y.square().sum()+dy.square().sum()).backward()
 assert np.isfinite(x.grad.numpy()).all() and np.isfinite(layer.weight.grad.numpy()).all()
for name in NAMES:
 t=importlib.import_module(name).torch
 layer=t.nn.InstanceNorm2d(3,affine=True,track_running_stats=True,dtype=t.float64)
 value=t.tensor(np.sin(np.arange(72)).reshape(2,3,3,4),requires_grad=True)
 y,dy=t.func.jvp(layer,(value,),(t.ones_like(value),))
 (y.square().sum()+dy.square().sum()).backward()
 assert layer.num_batches_tracked.item()==0 and np.isfinite(value.grad.numpy()).all()
 assert layer.running_mean._version==2
for name in NAMES:
 t=importlib.import_module(name).torch
 x=t.from_numpy(np.array([[1.,2.,3.],[4.,5.,6.]],order='F')).requires_grad_()
 x.sum().backward();assert x.grad.stride()==x.stride()
 assert x.t().shape==(3,2) and x.mT.stride()==(2,1)
 assert t.movedim(x,0,1).shape==(3,2)
 y=x*2;y.retain_grad();y.sum().backward(retain_graph=True);old=y.grad
 y.sum().backward();assert y.grad is not old;assert old.tolist()==[[1.,1.,1.],[1.,1.,1.]]
for name in NAMES:
 t=importlib.import_module(name).torch
 a=t.tensor([[[3.,0.],[0.,2.]],[[4.,0.],[0.,5.]]],dtype=t.float64,requires_grad=True)
 b=t.tensor([[[1.,2.]],[[3.,4.]]],dtype=t.float64,requires_grad=True)
 x=t.linalg.solve(a,b,left=False)
 np.testing.assert_allclose(x.numpy(),[[[1/3,1.]],[[.75,.8]]])
 x.sum().backward()
 np.testing.assert_allclose(b.grad.numpy(),[[[1/3,.5]],[[.25,.2]]])
 primal,tangent=t.func.jvp(lambda aa,bb:t.linalg.solve(aa,bb,left=False),(a,b),(t.ones_like(a),t.ones_like(b)))
 assert primal.shape==tangent.shape==(2,1,2) and np.isfinite(tangent.numpy()).all()
import io
for name in NAMES:
 m=importlib.import_module(name);t=m.torch
 with m.as_torch() as aliased:
  import torch
  from torch.serialization import save,load
  assert torch is aliased and save is torch.save and load is torch.load
  base=torch.arange(12,dtype=torch.float64);state={'base':base,'view':base[1::2]}
  stream=io.BytesIO();save(state,stream);stream.seek(0);loaded=load(stream,weights_only=True)
  np.testing.assert_array_equal(loaded['view'].numpy(),[1,3,5,7,9,11]);loaded['base'][1]=23.;assert loaded['view'][0].item()==23.
  layer=torch.nn.Linear(2,1).double();opt=torch.optim.AdamW(layer.parameters(),lr=.01);sched=torch.optim.lr_scheduler.StepLR(opt,2)
  x=torch.tensor([[1.,2.]],dtype=torch.float64);layer(x).square().mean().backward();opt.step();sched.step()
  stream=io.BytesIO();save({'model':layer.state_dict(),'optimizer':opt.state_dict(),'scheduler':sched.state_dict()},stream);stream.seek(0);loaded=load(stream)
  target=torch.nn.Linear(2,1).double();newopt=torch.optim.AdamW(target.parameters());newsched=torch.optim.lr_scheduler.StepLR(newopt,2)
  target.load_state_dict(loaded['model']);newsched.load_state_dict(loaded['scheduler']);newopt.load_state_dict(loaded['optimizer'])
  np.testing.assert_array_equal(target(x).numpy(),layer(x).numpy())
  newopt.zero_grad();target(x).square().mean().backward();newopt.step();newsched.step()
for name in NAMES:
 t=importlib.import_module(name).torch
 a=t.tensor([[2.,.2],[.9,3.]],dtype=t.float64,requires_grad=True);b=t.ones(2,2,dtype=t.float64,requires_grad=True)
 x=t.linalg.solve_triangular(a,b,upper=True,left=False,unitriangular=True)
 np.testing.assert_allclose(x.numpy(),[[1.,.8],[1.,.8]]);assert x.stride()==(1,2)
 x.square().mean().backward();assert a.grad[0,0].item()==a.grad[1,1].item()==a.grad[1,0].item()==0.
 a.grad=b.grad=None
 primal,tangent=t.func.jvp(lambda aa,bb:t.linalg.solve_triangular(aa,bb,upper=True,left=False,unitriangular=True),(a,b),(t.ones_like(a),t.ones_like(b)))
 np.testing.assert_allclose(tangent.numpy(),[[1.,-.2],[1.,-.2]])
 tangent.sum().backward();assert np.isfinite(a.grad.numpy()).all() and np.isfinite(b.grad.numpy()).all()
for name in NAMES:
 t=importlib.import_module(name).torch
 a=t.tensor([[4.,1.],[1.,3.]],dtype=t.float64,requires_grad=True)
 factor=t.linalg.cholesky(a);np.testing.assert_allclose(factor.numpy(),[[2.,0.],[.5,np.sqrt(2.75)]])
 factor.square().sum().backward();np.testing.assert_allclose(a.grad.numpy(),np.eye(2),atol=1e-14)
 a.grad=None;direction=t.tensor([[.2,.3],[.7,.4]],dtype=t.float64,requires_grad=True)
 _,tangent=t.func.jvp(lambda v:t.linalg.cholesky(v,upper=True),(a,),(direction,))
 np.testing.assert_allclose(tangent.numpy(),[[.05,.3375],[0.,.048995593493886595]])
 tangent.square().sum().backward();assert np.isfinite(a.grad.numpy()).all() and np.isfinite(direction.grad.numpy()).all()
for name in NAMES:
 t=importlib.import_module(name).torch
 f=t.tensor([[2.,0.],[.4,3.]],dtype=t.float64,requires_grad=True);b=t.ones(2,2,dtype=t.float64,requires_grad=True)
 x=t.cholesky_solve(b,f);np.testing.assert_allclose(x.numpy(),np.linalg.solve(f.numpy()@f.numpy().T,b.numpy()))
 x.square().sum().backward();assert np.isfinite(b.grad.numpy()).all() and np.isfinite(f.grad.numpy()).all()
 f.grad=b.grad=None
 dF=t.ones_like(f)*.13;dB=t.ones_like(b)*.27
 _,tangent=t.func.jvp(lambda bb,ff:bb.cholesky_solve(ff),(b,f),(dB,dF))
 tangent.square().sum().backward();assert np.isfinite(b.grad.numpy()).all() and np.isfinite(f.grad.numpy()).all()
for name in NAMES:
 t=importlib.import_module(name).torch
 f=(t.eye(64,dtype=t.float64)*2).requires_grad_();b=t.full((64,2),.2,dtype=t.float64,requires_grad=True)
 db=t.full_like(b,.03,requires_grad=True);df=t.full_like(f,.01,requires_grad=True)
 x,tangent=t.func.jvp(lambda bb,ff:t.cholesky_solve(bb,ff),(b,f),(db,df))
 np.testing.assert_allclose(x.numpy(),.05);np.testing.assert_allclose(tangent.numpy(),-.0245)
 (x.square().sum()+tangent.square().sum()).backward()
 assert all(a.grad is not None and np.isfinite(a.grad.numpy()).all() for a in (b,f,db,df))
for name in NAMES:
 t=importlib.import_module(name).torch
 f=t.tensor([[2.,0.],[.4,3.]],dtype=t.float64,requires_grad=True);df=t.full_like(f,.13,requires_grad=True)
 x,tangent=t.func.jvp(lambda f:f.cholesky_inverse(),(f,),(df,))
 expected=np.linalg.inv(f.numpy()@f.numpy().T);np.testing.assert_allclose(x.numpy(),expected)
 partial=-expected@df.numpy()@expected@f.numpy().T
 np.testing.assert_allclose(tangent.numpy(),partial+partial.T)
 (x.square().sum()+tangent.square().sum()).backward()
 assert np.isfinite(f.grad.numpy()).all() and np.isfinite(df.grad.numpy()).all()
import pickle
for name in NAMES:
 m=importlib.import_module(name);t=m.torch;legacy=importlib.import_module(name+'._legacy').install()
 for obj in (t,t.nn,t.tensor([1.]),legacy,legacy.tensor([1.])):
  key='not_a_real_torch_symbol_37';sentinel=object()
  assert not hasattr(obj,key) and getattr(obj,key,sentinel) is sentinel
  try:getattr(obj,key)
  except AttributeError as error:
   assert isinstance(error,m.UnsupportedOperation) and error.obj is obj and error.name==key
   restored=pickle.loads(pickle.dumps(error));reference=pickle.loads(pickle.dumps(AttributeError(str(error),name=key,obj=obj)))
   assert isinstance(restored,m.UnsupportedOperation) and isinstance(restored,AttributeError) and restored.name==reference.name and restored.obj is None
  else:raise AssertionError('Missing symbol accepted')
 with m.as_torch():
  try:exec('from torch.nn import not_a_real_torch_symbol_37',{})
  except ImportError:pass
  else:raise AssertionError('Unavailable from-import accepted')
for name in NAMES:
 m=importlib.import_module(name);t=m.torch
 x=t.tensor([[[[1.,2.,3.],[4.,9.,6.],[7.,8.,5.]]]],dtype=t.float64,requires_grad=True)
 p,i=t.nn.functional.max_pool2d(x,2,1,return_indices=True)
 assert p.tolist()==[[[[9.,9.],[9.,9.]]]] and i.tolist()==[[[[4,4],[4,4]]]]
 p.sum().backward();assert x.grad.tolist()==[[[[0.,0.,0.],[0.,4.,0.],[0.,0.,0.]]]]
 v=t.ones_like(x,requires_grad=True)
 p,dual=t.func.jvp(lambda z:t.nn.functional.max_pool2d(z,2,1),(x,),(v,));dual.sum().backward()
 assert v.grad.tolist()==[[[[0.,0.,0.],[0.,4.,0.],[0.,0.,0.]]]]
 model=t.nn.MaxPool2d(2);restored=pickle.loads(pickle.dumps(model));assert restored(x).shape==model(x).shape
 with m.as_torch():
  from torch.nn.modules.pooling import MaxPool2d
  assert MaxPool2d is t.nn.MaxPool2d
for name in NAMES:
 m=importlib.import_module(name);t=m.torch
 x=t.ones(1,1,4,4,dtype=t.float64,requires_grad=True)
 p=t.nn.functional.adaptive_avg_pool2d(x,2);p.sum().backward();np.testing.assert_array_equal(x.grad.numpy(),.25)
 v=t.ones_like(x,requires_grad=True);p,dual=t.func.jvp(lambda z:t.nn.functional.adaptive_avg_pool2d(z,2),(x,),(v,));dual.sum().backward();np.testing.assert_array_equal(v.grad.numpy(),.25)
 model=t.nn.AdaptiveAvgPool2d(2);restored=pickle.loads(pickle.dumps(model));assert restored(x).shape==model(x).shape
 a=np.ones((1,1,4,4));a[...,0,0]=np.inf
 np.testing.assert_array_equal(t.nn.functional.adaptive_avg_pool2d(t.tensor(a),2).numpy(),[[[[np.inf,1.],[1.,1.]]]])
 assert t.nn.AvgPool2d(2)(x).shape==(1,1,2,2)
 with m.as_torch():
  from torch.nn.modules.pooling import AvgPool2d,AdaptiveAvgPool2d
  assert AvgPool2d is t.nn.AvgPool2d and AdaptiveAvgPool2d is t.nn.AdaptiveAvgPool2d
plans=[]
for name in NAMES:
 m=importlib.import_module(name);api=m.torch
 a=np.arange(17*23,dtype=np.float64).reshape(1,1,17,23);a[...,::2]*=-1
 x=api.tensor(a,requires_grad=True);y=api.nn.functional.adaptive_avg_pool2d(x,(5,3));y.sum().backward()
 assert np.isfinite(x.grad.numpy()).all() and not np.shares_memory(x.numpy(),y.numpy())
 module=importlib.import_module(name+'._average_pooling');plan=module._cached_pack_plan(17,23,5,3,np.dtype('float64').str,False)
 assert plan is not None and plan.flat is not None and not plan.flat.flags.writeable
 plans.append(module._cached_pack_plan)
assert len({id(value) for value in plans}) == len(plans)
for name in NAMES:
 m=importlib.import_module(name);api=m.torch
 with m.as_torch() as api:
  import torch
  from torch.nn.modules.pooling import AvgPool1d,AdaptiveAvgPool1d
  assert torch is api and AvgPool1d is api.nn.AvgPool1d
  x=api.arange(14,dtype=api.float64).reshape(1,2,7).requires_grad_()
  model=api.nn.Sequential(AvgPool1d(3,2,1,True,False),AdaptiveAvgPool1d(3))
  y=model(x);y.sum().backward();assert np.isfinite(x.grad.numpy()).all()
  _,t=api.func.jvp(model,(x,),(api.ones_like(x),))
  np.testing.assert_array_equal(t.numpy(),1.)
  np.testing.assert_array_equal(api.avg_pool1d(x,2).numpy(),api.nn.functional.avg_pool1d(x,2).numpy())
for name in NAMES:
 m=importlib.import_module(name);api=m.torch
 with m.as_torch() as api:
  from torch.nn.modules.pooling import MaxPool1d,MaxPool2d
  assert not isinstance(MaxPool1d(2),MaxPool2d)
  x=api.arange(7,dtype=api.float64).reshape(1,1,7).requires_grad_()
  y,i=api.max_pool1d_with_indices(x,1_000_000,1,500_000)
  np.testing.assert_array_equal(y.numpy(),6.);np.testing.assert_array_equal(i.numpy(),6)
  y.sum().backward();np.testing.assert_array_equal(x.grad.numpy(),[[[0,0,0,0,0,0,8]]])
  layer=api.nn.Sequential(api.nn.Conv1d(2,3,3,padding=1),api.nn.SiLU(),MaxPool1d(2),api.nn.AdaptiveAvgPool1d(3),api.nn.Flatten(),api.nn.Linear(9,2)).double()
  opt=api.optim.SGD(layer.parameters(),lr=.01,momentum=.9);data=api.ones(1,2,17,dtype=api.float64)
  layer(data).square().mean().backward();opt.step()
  stream=io.BytesIO();api.save({'model':layer.state_dict(),'optimizer':opt.state_dict()},stream);stream.seek(0);loaded=api.load(stream)
  layer.load_state_dict(loaded['model']);opt.load_state_dict(loaded['optimizer']);opt.zero_grad();layer(data).square().mean().backward();opt.step()
  assert np.isfinite(layer(data).numpy()).all()
for name in NAMES:
 m=importlib.import_module(name);t=m.torch
 with m.as_torch() as api:
  from torch.nn.modules.pooling import MaxPool3d
  a=api.arange(64,dtype=api.float64).reshape(1,1,4,4,4).requires_grad_()
  y,i=MaxPool3d(2,return_indices=True)(a)
  assert i.tolist()==[[[[[21,23],[29,31]],[[53,55],[61,63]]]]]
  y.sum().backward();assert a.grad.sum().item()==8.
  _,tan=api.func.jvp(lambda z:api.max_pool3d(z,2),(a,),(api.ones_like(a),))
  np.testing.assert_array_equal(tan.numpy(),1.)
for name in NAMES:
 m=importlib.import_module(name);t=m.torch
 with m.as_torch():
  from torch.nn.modules.pooling import AvgPool3d,AdaptiveAvgPool3d
  assert AvgPool3d is t.nn.AvgPool3d and AdaptiveAvgPool3d is t.nn.AdaptiveAvgPool3d
  x=t.arange(64,dtype=t.float64).reshape(1,1,4,4,4).requires_grad_()
  y=AvgPool3d(2)(x);y.sum().backward();np.testing.assert_array_equal(x.grad.numpy(),.125)
  x.grad=None
  _,tan=t.func.jvp(lambda z:AdaptiveAvgPool3d((3,2,4))(z),(x,),(t.ones_like(x),))
  np.testing.assert_array_equal(tan.numpy(),1.)
  assert pickle.loads(pickle.dumps(AvgPool3d(2)))(x).shape==(1,1,2,2,2)
print('PASS isolated ownership,aliases,ZIP resume,triangular,Cholesky and Cholesky solve VJP/JVP/full tangent reverse')
"""
run([python,'-c','NAMES='+repr(['stridetorch','paperleet._vendor.torch'])+'\n'+check],'coinstall-both')
run([uv,'pip','uninstall','--python',python,'paperleet'],'coinstall-uninstall-private')
run([python,'-c',"NAMES=['stridetorch']\n"+check],'coinstall-public-survives')
run([uv,'pip','install','--python',python,'--no-deps',private],'coinstall-reinstall-private')
run([uv,'pip','uninstall','--python',python,'stridetorch'],'coinstall-uninstall-public')
run([python,'-c',"NAMES=['paperleet._vendor.torch']\n"+check+"\nassert importlib.util.find_spec('stridetorch') is None"],'coinstall-private-survives')
(r/'coinstall-result.json').write_text(json.dumps(dict(status='success',source_hashes=expected,wheels={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (public,private)},receipts=receipts,scope='ZIP checkpoint alias/shared-storage/model-optimizer-scheduler resume verified in each namespace. Both no-deps distributions coinstalled in a new NumPy-only Python3.10 environment; both namespaces execute nanmean/VJP,matrix views and batched right-solve VJP/JVP; uninstall each owner without changing the other; native Torch absent. This is not an installed PaperLeet application dependency gate.'),indent=2)+'\n')
