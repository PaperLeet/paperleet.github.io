from pathlib import Path
import hashlib,json,warnings
import numpy as np
import torch as native
from paperleet_torch import torch as light
r=Path(__file__).parent
base=np.arange(48,dtype=np.float64).reshape(4,3,4)
cases={
 'contiguous':base,
 'transposed':base.transpose(1,0,2),
 'step_last':base[:,:,::2],
 'step_middle':base[:,::2,:],
 'step_first':base[::2],
 'fortran':np.asfortranarray(base),
 'singleton':base[:1,:, :1].transpose(2,1,0),
 'broadcast':np.broadcast_to(base[0,0],(3,4)),
 'empty':base[:0],
 'scalar':np.array(2.,dtype=np.float64),
 'one':np.array([2.],dtype=np.float64),
}
rows=[]
with warnings.catch_warnings():
 warnings.simplefilter('ignore')
 for name,data in cases.items():
  for target in [(data.size,),(-1,),data.shape,(1,data.size),(data.size,1)]:
   row=dict(case=name,input_shape=data.shape,input_strides=tuple(x//data.itemsize for x in data.strides),target=target)
   for label,api in [('native',native),('light',light)]:
    x=api.from_numpy(data)
    try:
     y=x.view(*target) if target else x.view(())
     row[label]=dict(status='success',shape=tuple(y.shape),shares=(y.data_ptr()==x.data_ptr()) if data.size else None,values=y.tolist())
     if label=='native':row[label]['strides']=y.stride();row[label]['offset']=y.storage_offset()
     else:row[label]['strides']=tuple(x//data.itemsize for x in y.numpy().strides)
    except Exception as e:row[label]=dict(status='error',type=type(e).__name__,message=str(e))
   row['status_mismatch']=row['native']['status']!=row['light']['status'];rows.append(row)
report=dict(native=native.__version__,numpy=np.__version__,light=light.__version__,rows=rows,mismatches=sum(x['status_mismatch'] for x in rows))
(r/'layout-audit.json').write_text(json.dumps(report,indent=2)+'\n');print('Native/light view status mismatches:',report['mismatches'],'/',len(rows))
for x in rows:
 if x['status_mismatch']:print(x['case'],x['target'],x['native']['status'],x['light']['status'])
