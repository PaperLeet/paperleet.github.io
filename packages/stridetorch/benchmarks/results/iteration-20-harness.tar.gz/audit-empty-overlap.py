from pathlib import Path
import json,warnings
import numpy as np
import torch
r=Path(__file__).parent;rows=[]
with warnings.catch_warnings():
 warnings.simplefilter('ignore')
 for kind in ['zero','one_axis','broadcast','overlap']:
  a=np.empty((0,3),dtype=np.float64) if kind=='zero' else np.empty((1,3),dtype=np.float64)
  if kind=='broadcast':a=np.broadcast_to(np.arange(3.,dtype=np.float64),(2,3))
  if kind=='overlap':a=np.lib.stride_tricks.as_strided(np.arange(8.,dtype=np.float64),shape=(2,3),strides=(8,8))
  for how in ['from_numpy','tensor','clone','contiguous']:
   x=torch.from_numpy(a)
   if how=='tensor':x=torch.tensor(a)
   if how=='clone':x=x.clone()
   if how=='contiguous':x=x.contiguous()
   row=dict(case=kind,method=how,stride=x.stride(),shape=tuple(x.shape));rows.append(row)
  for tangent in ['same','contiguous']:
   x=torch.from_numpy(a);t=torch.from_numpy(a.copy() if tangent=='contiguous' else a)
   try:
    y,dy=torch.func.jvp(lambda z:z.view(z.shape),(x,),(t,));rows.append(dict(case=kind,tangent=tangent,status='success',primal_stride=y.stride(),tangent_stride=dy.stride(),tangent_values=dy.tolist()))
   except Exception as e:rows.append(dict(case=kind,tangent=tangent,status='error',type=type(e).__name__,message=str(e)))
(r/'empty-overlap-audit.json').write_text(json.dumps(rows,indent=2)+'\n')
for x in rows:print(x)
