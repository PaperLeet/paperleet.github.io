"""Candidate shape-only view metadata; validated separately before integration."""
import math
import operator
import numpy as np


def shape_args(args, count):
    if len(args)==1 and isinstance(args[0],(tuple,list)):args=tuple(args[0])
    elif not args:raise TypeError('view requires a shape')
    shape=[]
    for value in args:
        if isinstance(value,(bool,np.bool_)):raise TypeError('Shape dimensions must be integers')
        try:value=operator.index(value)
        except TypeError:raise TypeError('Shape dimensions must be integers') from None
        if value < -1:raise RuntimeError('Invalid negative shape dimension')
        shape.append(value)
    if shape.count(-1)>1:raise RuntimeError('Only one dimension can be inferred')
    known=math.prod(v for v in shape if v!=-1)
    if -1 in shape:
        if not known:raise RuntimeError('Cannot infer a dimension with zero known product')
        if count%known:raise RuntimeError('View shape does not match element count')
        shape[shape.index(-1)]=count//known
    elif known!=count:raise RuntimeError('View shape does not match element count')
    return tuple(shape)


def view_strides(old_shape, old_stride, shape):
    count=math.prod(old_shape)
    if not count:
        if old_shape==shape:return old_stride
        stride=[0]*len(shape);step=1
        for axis in reversed(range(len(shape))):
            stride[axis]=step;step*=max(shape[axis],1)
        return tuple(stride)
    if not old_shape:return (1,)*len(shape)
    result=[0]*len(shape);vdim=len(shape)-1;base=old_stride[-1];old_count=new_count=1
    for dim in reversed(range(len(old_shape))):
        old_count*=old_shape[dim]
        end=(dim==0 or (old_shape[dim-1]!=1 and old_stride[dim-1]!=old_count*base))
        if not end:continue
        while vdim>=0 and (new_count<old_count or shape[vdim]==1):
            result[vdim]=new_count*base;new_count*=shape[vdim];vdim-=1
        if new_count!=old_count:raise RuntimeError('View crosses non-contiguous storage chunks; use reshape')
        if dim:
            base=old_stride[dim-1];old_count=new_count=1
    if vdim!=-1:raise RuntimeError('View crosses non-contiguous storage chunks; use reshape')
    return tuple(result)


def view(data,*args):
    shape=shape_args(args,data.size)
    strides=view_strides(data.shape,tuple(v//data.itemsize for v in data.strides),shape)
    result=data.reshape(shape)
    if data.size and result.ctypes.data!=data.ctypes.data:
        raise RuntimeError('NumPy cannot express this validated view without a copy')
    result.strides=tuple(v*data.itemsize for v in strides)
    return result
