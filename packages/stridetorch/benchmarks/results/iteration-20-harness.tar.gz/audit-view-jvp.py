from pathlib import Path
import json
import numpy as np
import torch
r=Path(__file__).parent;rows=[]
for shape in [(3,3),(2,3,4)]:
 a=np.arange(np.prod(shape),dtype=np.float64).reshape(shape)
 for pl in ['contiguous','transposed','step']:
  def layout(kind):
   if kind=='contiguous':return np.array(a,copy=True)
   if kind=='transposed':return np.asfortranarray(a)
   return np.repeat(a,2,axis=-1)[...,::2]
  for tl in ['contiguous','transposed','step']:
   x=torch.from_numpy(layout(pl)).requires_grad_();t=torch.from_numpy(layout(tl)).requires_grad_()
   row=dict(shape=shape,primal_layout=pl,tangent_layout=tl)
   try:
    y,dy=torch.func.jvp(lambda z:z.view(-1),(x,),(t,));g=torch.autograd.grad(dy.square().sum(),(x,t),allow_unused=True)
    row.update(status='success',primal_stride=y.stride(),tangent_stride=dy.stride(),tangent_shares=dy.data_ptr()==t.data_ptr(),x_gradient=None if g[0] is None else g[0].tolist(),t_gradient=None if g[1] is None else g[1].tolist())
   except Exception as e:row.update(status='error',type=type(e).__name__,message=str(e))
   rows.append(row)
args=[]
x=torch.arange(6.)
for label,fn in [('size_kw',lambda:x.view(size=(2,3))),('dtype_kw',lambda:x.view(dtype=torch.int32)),('bool_dim',lambda:x.view(True,6)),('list',lambda:x.view([2,3])),('no_args',lambda:x.view()),('none',lambda:x.view(None)),('float_dim',lambda:x.view(2.,3)),('empty_list',lambda:torch.tensor(1.).view([]))]:
 try:
  y=fn();args.append(dict(case=label,status='success',shape=list(y.shape),strides=y.stride()))
 except Exception as e:args.append(dict(case=label,status='error',type=type(e).__name__,message=str(e)))
(r/'view-jvp-audit.json').write_text(json.dumps(dict(native=torch.__version__,rows=rows,args=args),indent=2)+'\n')
for row in rows:print(row['shape'],row['primal_layout'],row['tangent_layout'],row['status'],row.get('tangent_stride'),row.get('tangent_shares'))
print(json.dumps(args,indent=2))
