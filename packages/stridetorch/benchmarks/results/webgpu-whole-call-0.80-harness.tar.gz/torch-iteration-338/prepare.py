import hashlib
import json
from pathlib import Path
import shutil
import ast

root = Path(__file__).resolve().parent
parent = root.parent / 'torch-iteration-305'
load = json.loads((parent / 'load-plan.json').read_text())
for name, item in load['files'].items():
    if name == 'check-matrix.py':
        continue
    dest = root / item['source']
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(parent / item['source'], dest)
for name in ('rpc-client.mjs', 'gpu-service.mjs', 'plan-program.mjs'):
    shutil.copy2(parent / name, root / name)
del load['files']['check-matrix.py']
digest = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
ast.parse((root / 'measure-matrix.py').read_text())
load['files']['measure-matrix.py'] = dict(source='measure-matrix.py', sha256=digest(root / 'measure-matrix.py'))
(root / 'load-plan.json').write_text(json.dumps(load, indent=2) + '\n')
js = (parent / 'run-browser.mjs').read_text()
js = js.replace("const config={mode:'qualification'};", "const config={mode:'measurement',cycle:Number(process.argv[2])};assert([0,1,2].includes(config.cycle));")
js = js.replace("py.globals.set('_limits_json',JSON.stringify(client.limits));", "py.globals.set('_limits_json',JSON.stringify(client.limits));py.globals.set('_cycle',config.cycle);")
js = js.replace('stdout(){}', "stdout(message){self.postMessage({type:'phase',phase:message});}")
js = js.replace('check-matrix.py', 'measure-matrix.py')
js = js.replace("      if(data.type==='stopped')stoppedResolve();", "      if(data.type==='phase')console.info(data.phase);\n      if(data.type==='stopped')stoppedResolve();")
js = js.replace("if(message.type()==='error')console.log('BROWSER',message.text().slice(0,300));", "console.log('BROWSER',message.text().slice(0,500));")
js = js.replace("'passed_real_gpu_and_torch_matrix_vjp_controls');assert.equal(result.numerical.whole_forward_vjp_calls,48);", "'passed_matched_whole_call_measurement');assert.equal(result.numerical.cases,8);")
js = js.replace('latency_measured:false', 'latency_measured:true')
js = js.replace("scope:'Matched full Torch CPU forward/VJP and explicit GPU programs, default quotas, opaque Worker boundary, owned snapshots and real device cleanup. No GPU performance or Torch GPU backend claim.'", "scope:'Matched whole-call CPU versus manual GPU timing, including three owned CPU snapshots, default quotas and unchanged opaque Worker boundary. All samples retained; inspect A/A controls and chunk lengths before drawing performance conclusions. No Torch GPU backend claim.'")
js = js.replace("path.join(root,'browser-result.json')", "path.join(root,'browser-result-'+config.cycle+'.json')")
js = js.replace("calls:report.numerical.whole_forward_vjp_calls,", "cycle:config.cycle,controls_passed:report.numerical.all_aa_controls_passed,")
js = js.replace("}finally{if(browser)await browser.close();", "}catch(error){fs.writeFileSync(path.join(root,'failure-'+config.cycle+'.json'),JSON.stringify({error:String(error.stack||error),observed_utc:new Date().toISOString()},null,2)+'\\n');throw error;}finally{if(browser)await browser.close();")
(root / 'run-browser.mjs').write_text(js)
plan = dict(repair_of='torch-iteration-337', repair='Include the three pre-existing program count limits in exact default-limit equality. The first attempt stopped before any measured case. No runtime or quota changed.', parent_fixture=str(parent), source_commit='13fcfb6033b7ffab7749c7059f13371dcb225fdb',
            runs=[0,1,2], scope='Four finite float32 matrix shapes, cold and resident, full forward and both VJPs with three owned CPU snapshots.',
            controls='A0/A1 identical independently constructed CPU operations share exact readonly operands. Median paired A1/A0 must be within [0.95,1.05]; retain all failures and label affected comparisons exploratory.',
            order='All six permutations plus their reverse:12 rounds per flow, cyclic flow ordering across three fresh Chrome processes.',
            calibration='Calibrate to80ms, aim40ms measurement chunks; CPU8192/GPU8 iteration caps. Report any shorter chunks, no hidden sample exclusions.',
            lifecycle='Default4096requests/120slease; original100s fixture deadline and opaque learner boundary. No limit changes, no production GPU backend.',
            selection='All three planned runs, no favorable reruns. Numeric failure makes performance unusable. Short chunks/control failures limit claims.',
            files={str(p.relative_to(root)):digest(p) for p in root.rglob('*') if p.is_file() and p.name not in ('source-plan.json','load-plan.json')})
(root / 'source-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
print(json.dumps(dict(status='prepared', files=len(plan['files']), load_files=len(load['files']), plan_sha256=digest(root / 'source-plan.json'))))
