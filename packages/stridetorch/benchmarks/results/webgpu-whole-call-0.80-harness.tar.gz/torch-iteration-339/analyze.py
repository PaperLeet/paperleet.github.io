import hashlib
import json
from pathlib import Path
import statistics

root = Path(__file__).resolve().parent
evaluation = root.parent
fixture = evaluation / 'torch-iteration-338'
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
digest = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
source_plan = json.loads((fixture / 'source-plan.json').read_text())
for name, expected in source_plan['files'].items():
    assert digest(fixture / name) == expected, name
load_plan = json.loads((fixture / 'load-plan.json').read_text())
runtime_hashes = {}
for name, item in load_plan['files'].items():
    assert digest(fixture / item['source']) == item['sha256'], name
    if name.startswith('stridetorch/'):
        source = repo / 'packages/stridetorch/src' / name
        assert digest(source) == item['sha256'], str(source)
        runtime_hashes[name] = item['sha256']
assert len(runtime_hashes) == 65
reports = [json.loads((fixture / f'browser-result-{cycle}.json').read_text()) for cycle in range(3)]
per_case = {}
processes = []
for cycle, report in enumerate(reports):
    assert report['status'] == 'passed'
    assert report['numerical']['cycle'] == cycle
    assert report['numerical']['all_aa_controls_passed']
    assert report['worker'] == dict(secure_context=False, origin='null', gpu_exposed=False, pyodide='0.29.4')
    assert report['gpu_info']['vendor'] == 'apple' and not report['gpu_info']['fallback']
    assert report['requests_sent'] < report['limits']['requests'] == 4096
    assert report['limits'] == reports[0]['limits']
    assert report['numerical']['torch_gpu_backend_enabled'] is False
    assert report['latency_measured'] is True
    assert report['source_sha256'] == source_plan['files']
    for disposal in report['host_disposals']:
        stats = disposal['stats']
        assert stats['closed'] and stats['allocations'] == stats['total_bytes'] == stats['resident_handles'] == 0
        assert stats['submitted'] == stats['completed']
    total_calls = {label: 0 for label in ('A0', 'A1', 'G')}
    for row in report['numerical']['rows']:
        key = (tuple(row['shape']), row['resident'])
        assert row['native_controls_passed'] and row['inputs_unchanged'] and row['owned_outputs']
        assert len(row['raw']) == 12
        assert .95 <= row['aa_ratio'] <= 1.05
        assert sorted(tuple(r['order']) for r in row['raw'][:6]) == sorted(tuple(r['order']) for r in row['raw'][6:])
        assert all(r['samples'][label]['iterations'] == row['iterations'][label] for r in row['raw'] for label in total_calls)
        for label in total_calls:
            total_calls[label] += 1 + sum(c['iterations'] for c in row['calibration'][label]) + 12 * row['iterations'][label]
        per_case.setdefault(key, []).append(dict(cycle=cycle, **row))
    processes.append(dict(cycle=cycle, browser=report['browser'], requests_sent=report['requests_sent'],
                          gpu_info=report['gpu_info'], worker=report['worker'], numpy=report['numerical']['numpy'],
                          whole_calls_including_calibration=total_calls,
                          host_disposals=report['host_disposals'], raw_sha256=digest(fixture / f'browser-result-{cycle}.json')))
rows = []
for (shape, resident), cases in sorted(per_case.items()):
    assert len(cases) == 3
    ratios = [case['gpu_over_cpu_ratio'] for case in cases]
    cpu = [case['median_seconds']['A0'] for case in cases]
    gpu = [case['median_seconds']['G'] for case in cases]
    row = dict(shape=shape, resident=resident, cpu_ms=1000 * statistics.median(cpu), gpu_ms=1000 * statistics.median(gpu),
               median_paired_gpu_over_cpu=statistics.median(ratios), gpu_over_cpu_range=[min(ratios), max(ratios)],
               aa_range=[min(c['aa_ratio'] for c in cases), max(c['aa_ratio'] for c in cases)],
               min_chunk_ms={label: 1000*min(c['min_chunk_seconds'][label] for c in cases) for label in ('A0', 'A1', 'G')},
               gpu_setup_ms=[1000*c['setup_seconds']['G'] for c in cases],
               transfer_plan=cases[0]['transfer_plan'], per_process=cases)
    rows.append(row)
    print(shape, resident, 'CPU/GPU ms', round(row['cpu_ms'],4), round(row['gpu_ms'],4),
          'GPU/CPU range', [round(r,4) for r in row['gpu_over_cpu_range']], 'minchunk', row['min_chunk_ms'])
result = dict(status='passed_three_process_matched_gpu_measurement', source_version='0.80.0',
              source_commit='13fcfb6033b7ffab7749c7059f13371dcb225fdb', runtime_hashes=runtime_hashes,
              source_plan_sha256=digest(fixture / 'source-plan.json'), load_plan_sha256=digest(fixture / 'load-plan.json'),
              processes=processes, rows=rows, limits=reports[0]['limits'],
              findings=dict(native_failures=0, aa_failures=0, resource_failures=0, excluded_samples=0, favorable_reruns=0),
              retained_failed_attempt=dict(directory='torch-iteration-337', reason='Exact quota check initially omitted three existing DAG count fields; abort before timed cases. Corrected338 checks all11 existing values without changing quotas.'),
              limitations=['GPU timing batches for several small/256 cases are below the40ms target because of predeclared8callcap. All raw samples retained.',
                           'Three processes on one Apple Metal3 adapter, four finite float32 shapes, Chrome155/Pyodide0.29.4/NumPy2.2.5; no cross-device or general operator inference.',
                           'Every call includes forward, both gradients and three CPU snapshots. GPU uses explicit VJPs; CPU uses actual StrideTorch autograd.grad.',
                           'Input setup is separately reported. Browser/Pyodide/service startup and first-call shader compilation are outside steady-state timing.',
                           'No automatic cutoff, GPU Tensor storage or production GPU backend is enabled. Native Torch2.6/2.14 supply numerical oracles, not the measured CPU baseline.'],
              decision='Prototype a bounded GPU path for substantial dense float32 matrix workloads. Preserve CPU/WASM for small work. Further automatic autograd/device/mutation/lifetime and cross-device qualification is required before production adoption.')
out = root / 'result.json'
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(status=result['status'], process_count=len(processes), case_count=len(rows), result_sha256=digest(out))))
