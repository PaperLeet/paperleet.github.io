from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent;py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';out=r/'performance';out.mkdir()
env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');receipts=[]
expected=json.loads((r/'proof/chrome-contracts/plan.json').read_text())['source']
baseline={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'baseline-source/stridetorch').iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
for repeat in range(4):
    for runtime in (('cpu','node','chrome') if repeat%2==0 else ('chrome','node','cpu')):
        name=f'{runtime}-{repeat}';result=out/(name+'.json')
        if runtime=='cpu':args=[py,r/'bench_max_pooling_1d.py','--baseline-source',r/'baseline-source/stridetorch','--candidate-source',r/'proof/source','--samples','7','--iterations','40','--output',result]
        else:args=['/opt/homebrew/bin/node',r/('bench-wasm.mjs' if runtime=='node' else 'bench-chrome.mjs'),result]
        if repeat%2:args+=['--reverse']
        start=time.monotonic()
        with (out/(name+'.log')).open('w') as log:p=subprocess.run([str(v) for v in args],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
        receipts.append(dict(name=name,exit_code=p.returncode,elapsed_s=time.monotonic()-start,args=[str(v) for v in args]));(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
        print(name,'terminal',p.returncode,flush=True);p.check_returncode()
        report=json.loads(result.read_text());assert report['status']=='success' and len(report['results'])==52
        assert report['source_hashes']['candidate']==expected and report['source_hashes']['baseline']==baseline
print('All12 prototype performance children terminal0',flush=True)
