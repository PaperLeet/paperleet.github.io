import {loadJudgePackages} from '../../../extraction-browser/packages.mjs';
self.onmessage=async({data})=>{try{
const plan=await(await fetch('./plan.json')).json();const {loadPyodide}=await import('../../../runtime-0.29.4/pyodide.mjs');
const py=await loadPyodide({indexURL:new URL('../../../runtime-0.29.4/',self.location.href).href,stdout(){},stderr(){}});await loadJudgePackages(py,[]);
for(const [name,relative] of [['baseline','../../baseline-source/stridetorch/'],['candidate','./source/']]){py.FS.mkdirTree('/'+name);for(const file of Object.keys(plan.source))py.FS.writeFile('/'+name+'/'+file,await(await fetch(relative+file)).text());}
py.FS.writeFile('/bench.py',await(await fetch('../../'+(data.scan?'bench_pooling_scan.py':'bench_max_pooling_1d.py'))).text());if(data.scan)py.FS.writeFile('/bench_max_pooling_1d.py',await(await fetch('../../bench_max_pooling_1d.py')).text());py.globals.set('scan_mode',Boolean(data.scan));py.globals.set('reverse_order',data.reverse);
py.runPython(`import sys,runpy
sys.argv=['bench.py','--baseline-source','/baseline','--candidate-source','/candidate','--iterations','4' if scan_mode else '40','--samples','7','--output','/result.json']+(['--reverse'] if reverse_order else [])
runpy.run_path('/bench.py',run_name='__main__')`);
self.postMessage({...JSON.parse(py.FS.readFile('/result.json',{encoding:'utf8'})),runtime:'Chrome Worker/Pyodide',pyodide:py.version});
}catch(error){self.postMessage({error:String(error.stack||error)});}};
