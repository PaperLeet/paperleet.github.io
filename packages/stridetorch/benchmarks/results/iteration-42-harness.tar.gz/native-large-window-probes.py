"""Future large-padding/tiny-input oracles; do not run the unoptimized adapter."""
from pathlib import Path
import json
import torch
rows=[]
for dimensions in (1,2):
 for dtype in (torch.float32,torch.float64):
  for kernel in (1024,1_000_000):
   for indices in (False,True):
    shape=(1,1,7) if dimensions==1 else (1,1,1,7)
    x=torch.arange(7,dtype=dtype).reshape(shape).requires_grad_()
    size=kernel if dimensions==1 else (1,kernel)
    stride=1 if dimensions==1 else (1,1)
    padding=kernel//2 if dimensions==1 else (0,kernel//2)
    fn=lambda z:getattr(torch.nn.functional,'max_pool'+str(dimensions)+'d')(z,size,stride,padding,return_indices=indices)
    result=fn(x);y,i=result if indices else (result,None)
    y.sum().backward();gradient=x.grad.tolist();x.grad=None
    direction=torch.ones_like(x,requires_grad=True)
    p,t=torch.func.jvp(lambda z:fn(z)[0] if indices else fn(z),(x,),(direction,))
    t.sum().backward();assert x.grad is None
    assert y.shape[-1]==8 and (y==6).all() and (t==1).all()
    rows.append(dict(dimensions=dimensions,dtype=str(dtype),kernel=kernel,return_indices=indices,output_shape=list(y.shape),values=y.detach().tolist(),index=None if i is None else i.tolist(),input_gradient=gradient,reverse_tangent=direction.grad.tolist()))
Path(__file__).with_suffix('.json').write_text(json.dumps(dict(native=torch.__version__,scope=__doc__,cases=rows),indent=2)+'\n')
print('Saved16 native large-window value/index/VJP/JVP/reverse-tangent probes')
