from pathlib import Path
import json
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
core=json.loads((out/'iteration-42.json').read_text());app=json.loads((out/'iteration-42-integration.json').read_text())
assert core['version']==app['version']=='0.42.0'
lines=['# Torch runtime iteration 0.42: direct 1D max pooling and reachable scans','',
'This candidate adds `nn.MaxPool1d`, functional value/index entry points, and',
'root `torch.max_pool1d` / `torch.max_pool1d_with_indices` aliases. Ordinary',
'Torch imports continue through the existing host alias/launcher. Numerical',
'selection and scatter kernels are shared with 2D without constructing extra',
'Tensor view graph nodes. Main adoption is recorded separately after validation.','',
'## Compatibility and computation','',
'CL/NCL inputs support stride, padding, dilation, ceil mode and optional indices.',
'Float32/float64 support reverse AD, JVP and reverse-over-forward; float16',
'inference is supported. The native CPU target supports integer 1D inference',
'only with returned indices: the adapter preserves that boundary explicitly.',
'Existing integer 2D inference remains supported. Valid 1D kernels above eight',
'million taps require the server; invalid argument/geometry checks run first.',
'Native Torch 2.14.1 supplies the reference implementation used by these tests.','',
'MaxPool1d and MaxPool2d share a private Module base and remain public sibling',
'types. This preserves dimensional `isinstance` checks, repr, state dictionaries,',
'pickle and ordinary import aliases. Saved input/index/tangent mutation and',
'output edits are compared with native paths, including hidden-index forward AD.',
'Empty values and indices preserve conventional contiguous strides.','',
'A paired block handles 1×2 windows, including the existing 2D API; 2×2 blocks',
'retain their behavior. Finite ties choose the first actual sample; multiple',
'NaNs choose the last, including payload/route selection. Window packing retains',
'the conservative 32 MiB workspace estimate. It is separate from output',
'allocations and total process memory.','',
'The scan fallback bounds each kernel-axis loop by offsets that can reach any',
'real sample between the first and last output. Globally unreachable taps are',
'discarded before iteration; remaining taps keep their original order. No',
'reassociation, cached user values or new input copies are introduced. Million-',
'tap padding over seven input values is checked against native values, indices,',
'VJP, JVP and reverse tangents. These tests do not time the slow old million-tap',
'scan. Dilated windows without any actual sample retain their inference values',
'and indices but explicitly require the server for derivatives.','',
'## Validation','',
f"- Focused native/standalone max and average pooling: {core['focused_passed']:,} passed.",
f"- Full repository/library CPU suite: {core['full_cpu']['passed']:,} passed, one optional skip; {core['full_cpu']['duration_s']:.2f} s.",
f"- Actual Node/Pyodide and Chrome Worker: {core['node_wasm']['passed']:,} independent checks each, 41 suites; Pyodide 0.29.4 / NumPy 2.2.5.",
f"- Isolated Python 3.10.19 / NumPy 1.26.4 standalone wheel: {core['minimal_passed']:,} passed, native Torch absent.",
'- Four internal routes repeat 360 seeded 1D/2D float32/64 geometries: 1,440 numeric/geometry trials. Invalid outputs and explicitly unsupported empty-window derivatives are classified separately from valid VJP/JVP comparisons.',
'- Native parameter outcomes, index/IEEE selection, noncontiguous and empty layouts, selective saved versions, Module type/pickle and Conv1d–SiLU–max–adaptive-average–linear momentum-SGD checkpoint continuation are covered.',
'- Public/private wheels and source archives share all 49 source/license identities. Coinstallation, normal Torch aliases, large-window tapes, training/checkpoint resume and independent uninstall pass in minimal environments.',
f"- Original native catalog: 78 problems, 10,218 executions, 342 mutants, three repeats; {app['native']['duration_s']:.3f} s within the unchanged 600 s aggregate budget.",
f"- Exported WASM catalog: 78 problems and 342 mutants; {app['exported_wasm']['elapsed_ms']} ms, concurrency 2, no exceeded browser budgets. Exported attention includes all 3,302 independent checks against actual exported source.",
'- Full frontend checks, publishing-policy checks and both typed production profiles pass. All 9,597 prior immutable payloads are unchanged; 158 new reachable payloads and 161 active identities are frozen.','',
'## Performance','',
'The supported baseline is the adopted 0.41 2D composition. It never invokes',
'a missing old 1D API. Both candidate composition and direct 1D API are measured:',
'the former controls the shared pair-block kernel, the latter also removes',
'Tensor view/graph dispatch. All values, indices, derivatives and a complete',
'training update are compared before timing. Each CPU, Node/Pyodide and Chrome',
'Worker runtime has four fresh processes, alternating variant order, seven',
'samples and 40 calls per sample (five for complete training), across 52',
'float32/float64 forward/strided/index/VJP/JVP and complete CNN/SGD flows.','',
'The table gives reductions in elapsed time against the old composition. Ranges',
'span the two dtypes after taking the median of four process results.','',
'| Flow | CPU | Node/WASM | Chrome Worker/WASM |','| --- | ---: | ---: | ---: |']
for kind,mode,title in [('pair','forward','Pair forward'),('pair','indices','Pair with returned indices'),
                         ('pair','backward','Pair full backward'),('large_pair','forward','Large pair forward'),
                         ('overlap','forward','Overlapping forward'),('dilated','jvp','Dilated JVP'),('cnn','training','Complete CNN/SGD step')]:
    cells=[]
    for runtime in ('cpu','node','chrome'):
        values=[v['median_reduction_percent'] for v in core['max_pooling_workflows'][runtime]['results'] if (v['kind'],v['mode'])==(kind,mode)]
        assert len(values)==2;cells.append(f'{min(values):.1f}–{max(values):.1f}%')
    lines.append('| '+title+' | '+' | '.join(cells)+' |')
lines += ['', 'Negative entries denote regressions. Shared-host variance, all samples,',
'same-candidate composition comparisons and control drift remain in the JSON',
'and harness. This does not establish a uniform speedup, native Torch speed',
'comparison, GPU behavior or cross-runtime throughput.','',
'A separate six-process comparison uses the same explicitly forced scan',
'algorithm in both namespaces, seven samples and four calls, on 1,024/4,096-tap',
'kernels with seven input values. Its 12 forward/VJP/JVP flows verify exact',
'values and derivatives before timing. These target the fallback, not automatic',
'dispatch or application throughput. The 4,096-tap results below combine two',
'fresh processes per runtime; ranges span the two dtypes.','',
'| Forced scan flow | CPU | Node/WASM | Chrome Worker/WASM |','| --- | ---: | ---: | ---: |']
for mode,title in [('forward','Forward'),('backward','Full backward'),('jvp','JVP')]:
    cells=[]
    for runtime in ('cpu','node','chrome'):
        values=[v['median_reduction_percent'] for v in core['forced_scan_workflows'][runtime] if v['kernel']==4096 and v['mode']==mode]
        assert len(values)==2;cells.append(f'{min(values):.1f}–{max(values):.1f}%')
    lines.append('| '+title+' | '+' | '.join(cells)+' |')
lines += ['', 'Eight additional paired CPU/WASM children retain 21 existing library',
'workflows; sixteen alternating fresh CPU processes measure namespace import',
'with NumPy included/preloaded separately. Source/gzip estimates do not measure',
'browser transport, installation or total resident memory. Earlier prototype',
'measurements and tests are retained separately under `before-scan`; final',
'claims above use the frozen 0.42 source only.','',
'## Evidence and release policy','',
'- `packages/stridetorch/benchmarks/results/iteration-42.json` and `iteration-42-harness.tar.gz`.',
'- `packages/stridetorch/benchmarks/results/iteration-42-integration.json` and `iteration-42-integration-harness.tar.gz`.',
'- Reusable tools: `bench_max_pooling_1d.py` and `bench_pooling_scan.py` under the package benchmarks directory.','',
'Only `__init__.py`, `_api.py` and `_pooling.py` change among the 49 runtime/',
'license resources; 46 remain byte-identical. The canonical quality gate remains',
'tag/manual triggered, with the existing current-main Pages release chain.',
'Ordinary main pushes do not request new CI or deployment. No tag, dispatch,',
'package upload or online publication is requested by this iteration. The user',
'will release later. WebGPU remains a separate backend investigation requiring',
'resident storage and end-to-end transfer/graph evidence.','']
(repo/'docs/validation/torch-runtime-iteration-42.md').write_text('\n'.join(lines))
f=repo/'packages/stridetorch/ROADMAP.md';text=f.read_text();marker='## Next implementation areas';assert '## 0.42:' not in text
section='''## 0.42: direct 1D max pooling, pair blocks and reachable scans

- Add CL/NCL max pooling, root/functional/Module aliases, indices, stride,
  padding, dilation and ceil mode with native dtype and linear-AD boundaries.
- Keep 1D/2D Modules as sibling types; preserve type checks, pickle, checkpoint
  state and native input/index/tangent version rules. Normalize empty outputs.
- Share a 1x2 block kernel with existing 2D pooling. Bound ordered scan loops
  to globally reachable offsets, retaining tie/NaN order under huge padding.
- Validate independent regions/scatter, native selection/metadata/parameters,
  four-route seeded 1D/2D geometry, million-tap examples and checkpointed Conv1d
  training across CPU, minimum packaging and actual Node/Chrome WASM.
- Measure 52 complete flows with candidate-composition controls plus a separate
  forced-scan study, legacy flows and imports; retain every sample/regression.
  See the [0.42 validation record](../../docs/validation/torch-runtime-iteration-42.md).
- Full original catalog, latest frontend, typed builds and immutable export
  identity gates precede main adoption; CI/tag/publishing remain user-controlled.

'''
assert marker in text;f.write_text(text.replace(marker,section+marker))
print('Wrote frozen-source0.42 validation narrative and roadmap;main adoption pending')
