from pathlib import Path
import hashlib,io,json,shutil,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
files=sorted([p for folder in [r,b/'torch-iteration-473'] for p in folder.iterdir() if p.is_file() and p.suffix not in ['.gz'] and p.name!='archive-receipt.json'])
manifest={str(p.relative_to(b)):sha(p) for p in files};target=r/'qualification-0.82-main-adoption-harness.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as stream:
 for p in files:stream.add(p,arcname=str(p.relative_to(b)),recursive=False)
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256.json');info.size=len(data);stream.addfile(info,io.BytesIO(data))
with tarfile.open(target) as stream:
 for name,h in manifest.items():assert hashlib.sha256(stream.extractfile(name).read()).hexdigest()==h,name
receipt=dict(path='packages/stridetorch/benchmarks/results/'+target.name,sha256=sha(target),bytes=target.stat().st_size,files=len(files),all_payloads_verified=True);write(r/'archive-receipt.json',receipt)
summary=json.loads((r/'result.json').read_text());summary['raw_archive']=receipt;write(repo/'packages/stridetorch/benchmarks/results/qualification-0.82-main-adoption.json',summary);shutil.copy2(target,repo/receipt['path']);print(json.dumps(receipt))
