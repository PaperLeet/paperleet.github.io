from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sha=lambda data:hashlib.sha256(data).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
def gh(path):return json.loads(subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/'+path],cwd=repo,text=True))
assert not (r/'result.json').exists()
adopted=read(b/'torch-iteration-473/qualification-grant.json')['head'];push=read(b/'torch-iteration-473/adoption-push-receipt.json');assert push['exit_code']==0
remote=gh('git/ref/heads/main')['object']['sha'];assert remote==adopted,(remote,adopted)
subprocess.run(['git','fetch','origin','main'],cwd=repo,check=True)
assert subprocess.check_output(['git','rev-parse','origin/main'],cwd=repo,text=True).strip()==remote
resources=read(b/'torch-iteration-473/source-hashes.json');exports=read(b/'torch-iteration-473/live-export-sha256.json');policies=read(b/'torch-iteration-473/release-policy-identity.json')['files']
for prefix,mapping in [('packages/stridetorch/src/stridetorch/',resources),('web/public/data/',exports),('',policies)]:
 for name,h in mapping.items():assert sha(subprocess.check_output(['git','show',remote+':'+prefix+name],cwd=repo))==h,name
runs=gh('actions/runs?head_sha='+adopted+'&per_page=100');assert runs['total_count']==0,runs['total_count']
pages=gh('pages');assert pages['source']==dict(branch='gh-pages',path='/') and pages['build_type']=='legacy'
assert gh('git/ref/heads/main')['object']['sha']==remote
write(r/'result.json',dict(status='verified_main_adoption_without_ci_or_publication',version='0.82.0',adopted_commit=adopted,verified_remote_sha=remote,verified_utc=datetime.now(timezone.utc).isoformat(),remote_root_tree=subprocess.check_output(['git','rev-parse',remote+'^{tree}'],cwd=repo,text=True).strip(),runtime_resources=resources,runtime_files_verified_from_remote_commit_tree=True,export_identities_verified_from_same_commit=len(exports),release_policies_verified_from_same_commit=len(policies),qualified_application_head=read(b/'torch-iteration-471/result.json')['head'],main_adopted=True,workflow_runs_for_adopted_commit=0,ci_triggered=False,tags_pushed=False,published=False,deployed=False,pages_source=pages['source'],ordinary_guarded_push=True,standard_object_negotiation=True,mandatory_wrapper_sha256='4b51422c5533ca6177a4a29a557cf37d1c6727d7530908e444be5833588c2882',successful_push_seconds=push['seconds'],successful_push_log_sha256=push['log_sha256'],goal_status='active'))
write(r/'remote-workflows.json',runs);write(r/'pages-source.json',dict(build_type=pages['build_type'],source=pages['source']));print(json.dumps(dict(status='verified_main_adoption_without_ci_or_publication',head=remote)))
