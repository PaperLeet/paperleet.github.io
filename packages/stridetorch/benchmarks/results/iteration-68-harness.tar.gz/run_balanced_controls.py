from pathlib import Path
import json,os,subprocess,hashlib,time
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-67';repo=Path('/Users/david/Developer/PaperLeet-torch-release');baseline=repo/'packages/stridetorch/src/stridetorch';candidate=r/'candidate-source/stridetorch';out=r/'balanced-controls';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();sources=lambda root:{p.name:sha(p) for p in root.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']}
a,b=sources(baseline),sources(candidate);assert [n for n in a if a[n]!=b[n]]==['_graph.py']
plans=[dict(group='joint',operation='classification',dtype='float64',input_shape=[64,32],kind='index',case='index_64'),dict(group='joint',operation='classification',dtype='float64',input_shape=[8,16],kind='soft',case='soft_8'),dict(group='joint',operation='groupnorm',dtype='float64',input_shape=[8,16,16,16],kind='train',case='vision_train'),dict(group='joint',operation='groupnorm',dtype='float64',input_shape=[256,128],kind='affine',case='affine')]
(out/'plans.json').write_text(json.dumps(plans,indent=2)+'\n');env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');receipts=[];python=old.parent/'torch-iteration-21/stride-dev-env/bin/python';bench=old/'lean-outliers/assets/bench_lean_outliers.py'
for cycle in range(6):
 start=time.time()
 with (out/f'{cycle}.json').open('w') as stdout,(out/f'{cycle}.log').open('w') as stderr:
  child=subprocess.run([str(python),str(bench),str(baseline),str(candidate),str(out/'plans.json'),str(cycle)],env=env,cwd=bench.parent,stdout=stdout,stderr=stderr)
 receipts.append(dict(cycle=cycle,exit_code=child.returncode,seconds=time.time()-start));(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');child.check_returncode();j=json.loads((out/f'{cycle}.json').read_text());assert j['source_hashes']==dict(baseline=a,duplicate=a,candidate=b);assert len(j['rows'])==4;print('BalancedCPU',cycle,'PASS',flush=True)
assert sources(baseline)==a and sources(candidate)==b
print('ALL6 FRESH BALANCED AA/B CHILDREN PASS',flush=True)
