from pathlib import Path
import os,subprocess,time,json,hashlib
r=Path(__file__).resolve().parent;previous=r.parent/'torch-iteration-67';python=r.parent/'torch-iteration-21/stride-dev-env/bin/python';baseline=previous/'versioned-release/snapshot/packages/stridetorch/src/stridetorch';candidate=r/'candidate-source/stridetorch';bench=previous/'bench_joint.py';out=r/'cpu-controls';out.mkdir(exist_ok=True)
env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');receipts=[]
for repeat in range(4):
 for label,source in [('candidate',candidate),('aa',baseline)] if repeat%2==0 else [('aa',baseline),('candidate',candidate)]:
  name=f'{label}-{repeat}';start=time.time()
  with (out/(name+'.json')).open('w') as stdout,(out/(name+'.log')).open('w') as stderr:
   child=subprocess.run([str(python),str(bench),str(baseline),str(source)],env=env,stdout=stdout,stderr=stderr,cwd=previous)
  receipts.append(dict(label=label,repeat=repeat,exit_code=child.returncode,seconds=time.time()-start));(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');child.check_returncode();result=json.loads((out/(name+'.json')).read_text());assert len(result['rows'])==26
  print(name,'PASS',flush=True)
print('ALL FOUR CANDIDATE AND FOUR AA CONTROLS PASS',flush=True)
