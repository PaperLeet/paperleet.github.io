from pathlib import Path
import json,subprocess,os,time,statistics,hashlib
p=Path(__file__).resolve().parent;r=p.parent;python=r.parent/'torch-iteration-21/stride-dev-env/bin/python';assets=p/'assets';out=p/'results';out.mkdir(exist_ok=True);env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');plan=json.loads((assets/'plan.json').read_text());receipts=[]
for cycle in range(6):
 for runtime in ['node','chrome','cpu'] if cycle%2==0 else ['cpu','chrome','node']:
  name=f'{runtime}-{cycle}';file=out/(name+'.json');args=[str(python),str(assets/'bench_lean_outliers.py'),str(assets/'baseline/stridetorch'),str(assets/'candidate/stridetorch'),str(assets/'selected.json'),str(cycle)] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(p/f'bench-{runtime}.mjs'),str(file)];start=time.time()
  if file.exists():
   previous=json.loads(file.read_text()); previous=previous.get('benchmark',previous)
   if len(previous.get('rows',[]))==5 and previous.get('cycle')==cycle:
    receipts.append(dict(runtime=runtime,cycle=cycle,exit_code=0,recovered_completed_result=True,sha256=hashlib.sha256(file.read_bytes()).hexdigest()));print(name,'RECOVERED',flush=True);continue
  with (out/(name+'.log')).open('w') as log:
   if runtime=='cpu':
    with file.open('w') as stdout:child=subprocess.run(args,cwd=assets,env=dict(env,CYCLE=str(cycle)),stdout=stdout,stderr=log)
   else:child=subprocess.run(args,cwd=assets,env=dict(env,CYCLE=str(cycle)),stdout=log,stderr=subprocess.STDOUT)
  receipts.append(dict(runtime=runtime,cycle=cycle,exit_code=child.returncode,seconds=time.time()-start));(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');child.check_returncode();raw=json.loads(file.read_text());result=raw.get('benchmark',raw);assert len(result['rows'])==5 and result['source_hashes']==dict(baseline=plan['source_hashes']['baseline'],duplicate=plan['source_hashes']['baseline'],candidate=plan['source_hashes']['candidate']);print(name,'PASS',flush=True)
rows=[]
for runtime in ['cpu','node','chrome']:
 children=[]
 for cycle in range(6):
  raw=json.loads((out/f'{runtime}-{cycle}.json').read_text());children.append(raw.get('benchmark',raw))
 for i in range(5):
  samples=[v['rows'][i] for v in children];assert all(v['plan']==samples[0]['plan'] for v in samples);ratios={label:[v['ratios'][label] for v in samples] for label in ['duplicate','candidate']};ratios['candidate_over_duplicate']=[v['ratios']['candidate']/v['ratios']['duplicate'] for v in samples];rows.append(dict(runtime=runtime,plan=samples[0]['plan'],samples=ratios,medians={label:statistics.median(values) for label,values in ratios.items()}))
report=dict(status='completed',children=18,flows_per_child=5,source_hashes=plan['source_hashes'],programs=plan['programs'],selected_sha256=plan['selected_sha256'],rows=rows,scope='Five selected full-flow latency outliers, six fresh processes per runtime, all six module-load permutations, 12 balanced >=50ms common batches, same-source A/A and candidate B. Source/program hashes checked. Local timing does not prove application throughput or universal improvement.')
(p/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print('ALL18 FRESH AA/B CHILDREN PASS',flush=True)
