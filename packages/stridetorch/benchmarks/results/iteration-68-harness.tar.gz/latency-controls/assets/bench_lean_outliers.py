"""Longer balanced A/A/B checks for full-series outliers; no new kernel code."""
from pathlib import Path
import gc,json,time,statistics,hashlib
import numpy as np
import bench_determinants as det
import bench_inverse as inv
import bench_joint as joint

def build(module,row):
 dtype=row['dtype'];shape=tuple(row['input_shape']);backward=row.get('mode')=='full_step'
 if row['group']=='joint':
  fn,_=joint.fixture(module,row['operation'])(shape,row['kind'],np.dtype(dtype),'joint');return fn,lambda:[fn().numpy().copy()]
 data=np.full(shape,.3,dtype=dtype) if row['operation']=='graph' else det._data(shape,dtype)
 if row['group']=='inverse':
  direction=(np.eye(shape[-1])*.2+np.sin(np.arange(data.size).reshape(shape)*.17)*.01).astype(dtype)
  return inv.method(module,data,direction,row['operation'],backward,True)
 return det._method(module,data,row['operation'],backward,False)

def addresses(fn):
 output={}
 for name,value in zip(fn.__code__.co_freevars,fn.__closure__ or []):
  item=value.cell_contents
  try:a=object.__getattribute__(item,'_data')
  except (AttributeError,TypeError):continue
  if isinstance(a,np.ndarray):
   address=int(a.__array_interface__['data'][0]);output[name]=dict(dtype=str(a.dtype),shape=list(a.shape),strides=list(a.strides),mod64=address%64,mod256=address%256,mod4096=address%4096)
 return output

def run(baseline,candidate,plans,cycle):
 paths=dict(baseline=baseline,duplicate=baseline,candidate=candidate);modules={};hashes={};orders=[['baseline','duplicate','candidate'],['duplicate','candidate','baseline'],['candidate','baseline','duplicate'],['candidate','duplicate','baseline'],['baseline','candidate','duplicate'],['duplicate','baseline','candidate']];load_order=orders[cycle%6]
 for label in load_order:modules[label],hashes[label]=det.load('_outlier_'+label,paths[label])
 assert hashes['baseline']==hashes['duplicate'];rows=[]
 for item in plans:
  functions={};captures={};alignment={}
  for label in load_order:functions[label],captures[label]=build(modules[label],item);alignment[label]=addresses(functions[label])
  expected=captures['baseline']()
  for label in ['duplicate','candidate']:
   if item['group']=='inverse':inv.compare(captures[label](),expected,item['dtype'],2 if item['operation']=='inverse_jvp' else 1)
   else:det._compare(captures[label](),expected,item['dtype'],True)
  del expected;gc.collect();calls=1;calibration={}
  for label in load_order:
   batch=1
   while True:
    start=time.perf_counter()
    for _ in range(batch):functions[label]()
    elapsed=time.perf_counter()-start
    if elapsed>=.05:break
    batch*=2
   calls=max(calls,batch);calibration[label]=dict(calls=batch,elapsed_s=elapsed)
  samples={label:[] for label in paths}
  for order in orders+list(reversed(orders)):
   for label in order:
    started=time.perf_counter()
    for _ in range(calls):functions[label]()
    samples[label].append((time.perf_counter()-started)/calls)
  medians={label:statistics.median(values) for label,values in samples.items()};rows.append(dict(plan=item,calls=calls,calibration=calibration,alignment=alignment,samples_s=samples,median_s=medians,ratios={label:medians[label]/medians['baseline'] for label in ['duplicate','candidate']}))
 return dict(source_hashes=hashes,cycle=cycle,load_order=load_order,rows=rows,program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Four selected workflows per runtime, same-source duplicate A/A and candidate B. Rotating module load order, 12 balanced common batches >=50ms, deterministic full-series shapes and independent pre-timing checks. Memory addresses modulo cache/page sizes are diagnostic metadata, not a causal explanation. No broad speedup claim.')

if __name__=='__main__':
 import sys
 print(json.dumps(run(sys.argv[1],sys.argv[2],json.loads(Path(sys.argv[3]).read_text()),int(sys.argv[4])),indent=2))
