"""Actual inverse/matmul APIs, new complex forward and explicit JVP composition."""
import gc
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time
import warnings

import numpy as np

try:import bench_determinants as common
except ModuleNotFoundError:
    sys.path.insert(0,str(Path(__file__).resolve().parent/'proof/chrome-contracts'))
    import bench_determinants as common


def method(module,data,direction,operation,backward,direct):
    t=module.torch;a=t.tensor(data,requires_grad=backward);e=t.tensor(direction,requires_grad=backward)
    weight=t.tensor(np.full(data.shape,.7,dtype=data.dtype)) if backward else None
    def call():
        a.grad=e.grad=None
        if operation=='matmul':p=a@e;values=(p,)
        elif operation=='inverse':p=t.linalg.inv(a);values=(p,)
        elif direct:values=t.func.jvp(t.linalg.inv,(a,),(e,))
        else:
            p=t.linalg.inv(a);values=(p,-(p@e@p))
        if backward:(values[-1]*weight).sum().backward()
        return values
    def capture():
        outputs=call();values=[x.numpy().copy() for x in outputs]
        if backward:
            values.append(a.grad.numpy().copy())
            if operation!='inverse':values.append(e.grad.numpy().copy())
        return values
    return call,capture


def compare(actual,expected,dtype,outputs):
    assert len(actual)==len(expected)
    for index,(a,b) in enumerate(zip(actual,expected)):
        assert a.shape==b.shape and a.dtype==b.dtype
        for aa,bb in [(a.real,b.real),(a.imag,b.imag)] if a.dtype.kind=='c' else [(a,b)]:
            for fn in [np.isnan,np.isposinf,np.isneginf]:np.testing.assert_array_equal(fn(aa),fn(bb))
        if dtype=='float32' and index>=outputs:
            delta=a.astype('float64')-b.astype('float64');scale=float(np.max(np.abs(b),initial=0));assert float(np.max(np.abs(delta),initial=0))<=1e-5*scale
        else:np.testing.assert_allclose(a,b,rtol=3e-5 if dtype in ['float32','complex64'] else 3e-11,atol=3e-12)


def run(baseline_source,candidate_source,samples=5):
    old,oh=common.load('_inverse_baseline',baseline_source);new,nh=common.load('_inverse_candidate',candidate_source);plans=[];rows=[]
    shapes=[('scalar',(1,1)),('small',(2,2)),('larger',(64,64)),('batch_large',(4,32,32))]
    for dtype in ['float32','float64']:
        for label,shape in shapes:
            for operation in ['inverse','inverse_jvp']:
                for backward in [False,True]:plans.append((operation,dtype,label,shape,backward,True))
        for label,shape in [('small',(2,2)),('larger',(64,64))]:
            for backward in [False,True]:plans.append(('matmul',dtype,label,shape,backward,True))
    for dtype in ['complex64','complex128']:
        for label,shape in [('small',(2,2)),('large',(32,32))]:plans.append(('inverse',dtype,label,shape,False,True))
    warnings.filterwarnings('ignore',category=RuntimeWarning)
    for operation,dtype,label,shape,backward,matched in plans:
        data=common._data(shape,dtype);direction=(np.eye(shape[-1])*.2+np.sin(np.arange(data.size).reshape(shape)*.17)*.01).astype(dtype)
        variants={'candidate':method(new,data,direction,operation,backward,True)}
        if matched:variants['baseline']=method(old,data,direction,operation,backward,True)
        actual=variants['candidate'][1]()
        if matched:compare(actual,variants['baseline'][1](),dtype,2 if operation=='inverse_jvp' else 1)
        else:np.testing.assert_allclose(data@actual[0],np.eye(shape[-1]),rtol=3e-5 if dtype=='complex64' else 3e-11,atol=3e-6 if dtype=='complex64' else 3e-12)
        methods={name:value[0] for name,value in variants.items()}
        for fn in methods.values():fn()
        gc.collect();calibration={};calls=1;times={name:[] for name in methods}
        for name,fn in methods.items():
            batch=1
            while True:
                started=time.perf_counter()
                for _ in range(batch):fn()
                elapsed=time.perf_counter()-started
                if elapsed>=.02:break
                if batch>=1_048_576:raise RuntimeError('Inverse timer resolution is insufficient')
                batch*=2
            calls=max(calls,batch);calibration[name]=dict(calls=batch,elapsed_s=elapsed)
        for repeat in range(samples):
            for name in list(methods) if repeat%2==0 else list(reversed(methods)):
                started=time.perf_counter()
                for _ in range(calls):methods[name]()
                times[name].append((time.perf_counter()-started)/calls)
        medians={name:statistics.median(values) for name,values in times.items()}
        rows.append(dict(operation=operation,dtype=dtype,shape=label,input_shape=list(shape),mode='full_step' if backward else 'forward',matched=matched,baseline_kind='actual_'+operation,calls=calls,calibration=calibration,samples_s=times,median_s=medians,candidate_over_baseline=medians['candidate']/medians['baseline'] if matched else None))
    assert len(rows)==44 and sum(x['matched'] for x in rows)==44
    return dict(versions=dict(baseline=old.__version__,candidate=new.__version__),source_hashes=dict(baseline=oh,candidate=nh),program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),samples=samples,rows=rows,scope='44 matched actual 0.66 workflows: 16 real inverse, 16 real inverse JVP, 8 matmul and 4 complex forward controls. Values and weighted reverse gradients are checked. Inputs/directions/weights predate timing; dispatch/transform/graphs/kernels/clearing/weighted reverse/destruction are timed. Five alternating common calibrated batches >=20ms; no native/GPU/cold-start or universal speedup claim.')


def memory(baseline_source,candidate_source,force_shared=False):
    import tracemalloc
    old,oh=common.load('_inverse_memory_baseline',baseline_source);new,nh=common.load('_inverse_memory_candidate',candidate_source);rows=[]
    if force_shared:
        old.torch;new.torch
        old._linalg._INVERSE_JVP_SHARED=True
        new._linalg._INVERSE_JVP_SHARED=True
    for dtype in ['float32','float64']:
        for shape in [(64,64),(4,32,32)]:
            data=common._data(shape,dtype)
            base=np.ascontiguousarray(np.broadcast_to(np.eye(shape[-1])*.2,shape).astype(dtype))
            for layout in ['C','F'] if len(shape)==2 else ['C','interleaved']:
                direction=base if layout=='C' else np.asfortranarray(base) if layout=='F' else np.moveaxis(np.ascontiguousarray(np.moveaxis(base,0,-1)),-1,0)
                for operation in ['inverse','inverse_jvp']:
                    for variant,module in [('baseline',old),('candidate',new)]:
                        t=module.torch;a=t.tensor(data,requires_grad=True);e=t.tensor(direction,requires_grad=True);weight=t.tensor(np.full(shape,.7,dtype=dtype))
                        def build():
                            return (t.linalg.inv(a),) if operation=='inverse' else t.func.jvp(t.linalg.inv,(a,),(e,))
                        out=build();(out[-1]*weight).sum().backward();a.grad=e.grad=None;del out;gc.collect()
                        tracemalloc.start();out=build();retained,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
                        tracemalloc.start();(out[-1]*weight).sum().backward();_,back_peak=tracemalloc.get_traced_memory();tracemalloc.stop()
                        rows.append(dict(operation=operation,variant=variant,dtype=dtype,input_shape=list(shape),direction_layout=layout,primal_stride=list(a.stride()),direction_stride=list(e.stride()),direction_copy_expected=operation=='inverse_jvp' and a.stride()!=e.stride(),matrix_bytes=data.nbytes,new_retained_bytes=retained,forward_peak_bytes=peak,backward_peak_bytes=back_peak))
                        del out,a,e,weight;gc.collect()
    return dict(source_hashes=dict(baseline=oh,candidate=nh),candidate_shared_override=force_shared,rows=rows,scope='Warm incremental CPU tracemalloc forward retained/peak and separately traced weighted backward peaks against actual 0.66 APIs. C primals; explicit C/F two-dimensional directions and C/interleaved batched directions; actual element strides and expected native-compatible direction-copy predicate are recorded per row. Inputs/directions/weights predate tracing. The optional shared-route override exercises WASM routing on CPU as an allocation proxy, with its override recorded explicitly. Not total tape bytes, RSS, LAPACK workspace or WASM heap.')


if __name__=='__main__':print(json.dumps(memory(sys.argv[1],sys.argv[2],force_shared='--shared-route' in sys.argv) if '--memory' in sys.argv[3:] else run(sys.argv[1],sys.argv[2]),indent=2))
