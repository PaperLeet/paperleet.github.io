"""Observe consumed cotangent arrays without retaining them in the observer."""
import gc,json,sys,weakref,hashlib
from pathlib import Path
import numpy as np
sys.path.insert(0,sys.argv[1])
import stridetorch
from stridetorch import torch
from stridetorch._autograd import joint_result

records=[]
for width in [8,131072]:
 refs={};observations=[]
 x=torch.ones(width,dtype=torch.float64,requires_grad=True)
 y=torch.ones(width,dtype=torch.float64,requires_grad=True)
 a=x*2;b=y*3
 def observe(label):
  def hook(g):
   observations.append(dict(at=label,alive={k:v() is not None for k,v in refs.items()}))
  return hook
 for name,tensor in [('a',a),('b',b),('x',x),('y',y)]:tensor.register_hook(observe(name))
 def backward(g,needs):
  first=np.full(width,float(g)*4);second=np.full(width,float(g)*5)
  refs['a']=weakref.ref(first);refs['b']=weakref.ref(second)
  return first,second
 output=joint_result(np.array(np.sum(4*a.numpy()+5*b.numpy()),dtype=np.float64),(a,b),backward)
 output.backward()
 np.testing.assert_array_equal(x.grad.numpy(),np.full(width,8.))
 np.testing.assert_array_equal(y.grad.numpy(),np.full(width,15.))
 gc.collect();assert all(v() is None for v in refs.values())
 records.append(dict(width=width,observations=observations,final_all_released=True))
source=Path(stridetorch.__file__).parent
print(json.dumps(dict(source=str(source),graph_sha256=hashlib.sha256((source/'_graph.py').read_bytes()).hexdigest(),records=records)))
