"""Actual MHA training-step CPU allocations; native values checked outside tracing."""
from pathlib import Path
import sys,json,gc,hashlib,tracemalloc,statistics
import numpy as np
import torch as native
native.set_num_threads(2)
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'torch-iteration-67'))
from bench_determinants import load
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');paths=dict(baseline=repo/'packages/stridetorch/src/stridetorch',explicit=r/'versioned-release/snapshot/packages/stridetorch/src/stridetorch',reused=r/'reused-seed-source/stridetorch');modules={};hashes={}
for name,path in paths.items():modules[name],hashes[name]=load('_attention_memory_'+name,path)
rows=[]
for dtype in ['float32','float64']:
 for n,length,dim in [(1,16,32),(2,64,128),(2,64,256)]:
  rng=np.random.default_rng(7427);inputs=rng.normal(size=(n,length,dim)).astype(dtype);seed=(rng.normal(size=(n,length,dim))*.1).astype(dtype);reference=native.nn.MultiheadAttention(dim,4,batch_first=True,dropout=0,dtype=getattr(native,dtype));initial={name:(rng.normal(size=tuple(param.shape))*.04).astype(dtype) for name,param in reference.named_parameters()}
  with native.no_grad():
   for name,param in reference.named_parameters():param.copy_(native.tensor(initial[name]))
  nx=native.tensor(inputs,requires_grad=True);opt=native.optim.SGD(reference.parameters(),lr=.01);out,_=reference(nx,nx,nx,need_weights=False);loss=((out-native.tensor(seed))**2).mean();loss.backward();reference_output=out.detach().numpy().copy();reference_loss=loss.item();reference_gradients={name:param.grad.numpy().copy() for name,param in reference.named_parameters()};reference_input_grad=nx.grad.numpy().copy();opt.step();reference_updated={name:param.detach().numpy().copy() for name,param in reference.named_parameters()};fixtures={}
  for name,module in modules.items():
   t=module.torch;model=t.nn.MultiheadAttention(dim,4,batch_first=True,dropout=0,dtype=getattr(t,dtype));params=dict(model.named_parameters());x=t.tensor(inputs,requires_grad=True);target=t.tensor(seed);optimizer=t.optim.SGD(model.parameters(),lr=.01)
   def reset(t=t,params=params):
    with t.no_grad():
     for key,param in params.items():param.copy_(t.tensor(initial[key]))
   def step(model=model,x=x,target=target,optimizer=optimizer):
    optimizer.zero_grad(set_to_none=True);x.grad=None;actual,_=model(x,x,x,need_weights=False);loss=(actual-target).square().mean();loss.backward();optimizer.step();return actual,loss
   reset();actual,value=step();rtol=3e-5 if dtype=='float32' else 3e-10;atol=3e-6 if dtype=='float32' else 3e-12;np.testing.assert_allclose(actual.numpy(),reference_output,rtol=rtol,atol=atol);np.testing.assert_allclose(value.numpy(),reference_loss,rtol=rtol,atol=atol);np.testing.assert_allclose(x.grad.numpy(),reference_input_grad,rtol=rtol,atol=atol)
   for key,param in params.items():np.testing.assert_allclose(param.grad.numpy(),reference_gradients[key],rtol=rtol,atol=atol);np.testing.assert_allclose(param.numpy(),reference_updated[key],rtol=rtol,atol=atol)
   fixtures[name]=(reset,step)
  samples={name:[] for name in paths}
  for order in [['baseline','explicit','reused'],['reused','explicit','baseline'],['explicit','baseline','reused']]:
   for name in order:
    reset,step=fixtures[name];reset();gc.collect();tracemalloc.start(1);tracemalloc.reset_peak();value=step();current,peak=tracemalloc.get_traced_memory();tracemalloc.stop();del value;samples[name].append(dict(current_bytes=current,peak_bytes=peak))
  medians={name:statistics.median(v['peak_bytes'] for v in values) for name,values in samples.items()};row=dict(dtype=dtype,input_shape=[n,length,dim],samples=samples,median_peak_bytes=medians,ratios={name:medians[name]/medians['baseline'] for name in ['explicit','reused']});rows.append(row);print(dtype,[n,length,dim],row['ratios'],flush=True)
report=dict(status='success',source_hashes=hashes,program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),native_torch=native.__version__,numpy=np.__version__,rows=rows,scope='Warm complete self-MHA, squared loss, zeroing, backward and SGD step, including input gradients. Native outputs/loss/input gradient/four parameter gradients and four updated arrays checked before tracing. CPU tracked incremental allocation only, not latency, RSS or browser heap.')
(r/'attention-memory.json').write_text(json.dumps(report,indent=2)+'\n')
