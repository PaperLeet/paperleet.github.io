"""CPU tracked-allocation diagnostic, not browser heap or latency evidence."""
from pathlib import Path
import gc,hashlib,json,sys,tracemalloc
import numpy as np
sys.path.insert(0,sys.argv[1])
import stridetorch
from stridetorch import torch
from stridetorch._autograd import joint_result
rows=[]
for width in [32,131072,524288]:
 for repeat in range(4):
  x=torch.ones(width,dtype=torch.float64,requires_grad=True)
  y=torch.ones(width,dtype=torch.float64,requires_grad=True)
  a=x*2;b=y*3
  def backward(g,needs):return np.full(width,float(g)*4),np.full(width,float(g)*5)
  output=joint_result(np.array(np.sum(4*a.numpy()+5*b.numpy())),(a,b),backward)
  gc.collect();tracemalloc.start(1);tracemalloc.reset_peak();output.backward();current,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
  np.testing.assert_array_equal(x.grad.numpy(),np.full(width,8.));np.testing.assert_array_equal(y.grad.numpy(),np.full(width,15.))
  rows.append(dict(width=width,repeat=repeat,tracked_current_bytes=current,tracked_peak_bytes=peak))
  del output,a,b,x,y
source=Path(stridetorch.__file__).parent
print(json.dumps(dict(status='success',python=sys.version,numpy=np.__version__,source=str(source),source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']},program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='CPU tracked allocation for a synthetic two-input VJP with exact analytical gradients. Not a latency, WASM heap, application or native-Torch comparison.',rows=rows)))
