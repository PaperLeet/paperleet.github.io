"""Recognize only provably stale, unstarted manual quality requests."""
import re


def ignorable_stale_queued_quality(run, current_sha, jobs, *,
                                  canonical_policies_verified=False,
                                  ancestor_verified=False):
    """This never authorizes cancelling or changing a workflow.

    The caller verifies the pinned CI/Pages policies at both immutable SHAs.
    Those policies bind execution to the requested SHA and reject publication
    unless it is still current main. A non-force main advance cannot make an
    ancestor request current again. Active Pages and current quality runs
    remain blocking.
    """
    return (
        run.get('name') == 'PaperLeet quality gate'
        and run.get('path') == '.github/workflows/ci.yml'
        and run.get('status') == 'queued'
        and run.get('conclusion') is None
        and run.get('event') == 'workflow_dispatch'
        and run.get('head_branch') == 'main'
        and run.get('repository', {}).get('full_name') == 'PaperLeet/paperleet.github.io'
        and run.get('head_repository', {}).get('full_name') == 'PaperLeet/paperleet.github.io'
        and re.fullmatch('[0-9a-f]{40}', run.get('head_sha', '')) is not None
        and re.fullmatch('[0-9a-f]{40}', current_sha) is not None
        and run['head_sha'] != current_sha
        and isinstance(jobs, list)
        and not jobs
        and canonical_policies_verified is True
        and ancestor_verified is True
    )
