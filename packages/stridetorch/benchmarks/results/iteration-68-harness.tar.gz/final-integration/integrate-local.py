"""Apply only the measured candidate and validate current PaperLeet locally."""
from pathlib import Path
import json,hashlib,subprocess,os,time,shutil,datetime
p=Path(__file__).resolve().parent;r=p.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');python=r.parent/'torch-iteration-21/stride-dev-env/bin/python'
read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
def save(name,j):(p/name).write_text(json.dumps(j,indent=2)+'\n')
def sources(q):return {f.name:sha(f) for f in q.iterdir() if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']}
context=read(p/'context.json');baseline=read(p/'baseline-source-sha256.json');candidate=read(p/'source-hashes.json');controls=read(r/'latency-controls/summary.json');assert controls['status']=='completed' and controls['children']==18 and controls['source_hashes']==dict(baseline=baseline,candidate=candidate)
# The final observed controls must be reviewed explicitly before invoking this.
assert (p/'latency-reviewed.json').exists();review=read(p/'latency-reviewed.json');assert review['controls_sha256']==sha(r/'latency-controls/summary.json') and review['proceed_local_validation']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==context['upstream']
target=repo/'packages/stridetorch';assert sources(target/'src/stridetorch')==candidate
immutable=read(p/'baseline-immutable-sha256.json');inputs=read(p/'application-input-sha256.json')
for name,digest in read(p/'owned-input-sha256.json').items():assert sha(repo/name)==digest
env=dict(os.environ,PYTHONPATH=os.pathsep.join([str(target/'src'),str(repo)]),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');env['PATH']='/Users/david/.npm/_npx/d18f28baf1132559/node_modules/node/bin:/opt/homebrew/bin:'+str(python.parent)+':'+env['PATH'];receipts=[]
def run(label,args,cwd=repo):
 started=time.monotonic()
 with (p/(label+'.log')).open('w') as log:child=subprocess.run(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipt=dict(label=label,exit_code=child.returncode,seconds=time.monotonic()-started,args=args,cwd=str(cwd),summary=(p/(label+'.log')).read_text().splitlines()[-1:]);receipts.append(receipt);save('receipts.json',receipts);child.check_returncode();assert sources(target/'src/stridetorch')==candidate;print(label,'TERMINAL0',receipt['summary'],flush=True);return receipt
run('export',[str(python),'-m','paperleet.cli','export'])
run('verify-export',[str(python),str(p/'verify-export.py')])
cpu=run('cpu',[str(python),'-m','pytest','tests','packages/stridetorch/tests','-q','-p','no:cacheprovider','--basetemp',str(p/'pytest-tmp')]);save('cpu-receipt.json',dict(**cpu,source_hashes=candidate))
run('wasm',['/opt/homebrew/bin/node','web/scripts/check-browser-wasm.mjs','--all'])
wasm=read(repo/'reports/browser-wasm.json');assert wasm['passed'] and wasm['catalog_modules']==wasm['modules']==85 and not wasm['browser_budget_exceeded'];assert len(wasm['results'])==85 and all(v['passed'] and not v['browser_budget_exceeded'] for v in wasm['results']);save('full-wasm-result.json',wasm)
run('full-frontend-check',['npm','run','check'],repo/'web')
run('build',['npm','run','build'],repo/'web')
for name,digest in immutable.items():assert sha(repo/name)==digest
for name,digest in inputs.items():assert sha(repo/name)==digest
for name,digest in read(p/'release-policy-identity.json')['files'].items():assert sha(repo/name)==digest
save('local-validation.json',dict(status='passed',source_hashes=candidate,receipts=receipts,catalog_modules=85,mutants=sum(v['mutants'] for v in wasm['results']),original_immutable_assets=len(immutable),main_adopted=False,ci_triggered=False,scope='Local integration source/export/full CPU/full current85-module WASM/full frontend/build. Actual final wheel metadata and remote adoption are separate gates.'))
print('LOCAL INTEGRATION GATES PASSED; NO PUSH OR RELEASE',flush=True)
