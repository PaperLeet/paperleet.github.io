from pathlib import Path
import json,hashlib,subprocess,tarfile,os,shutil,re
p=Path(__file__).resolve().parent;r=p.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results';read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
def save(q,j):q.write_text(json.dumps(j,indent=2)+'\n')
source=read(p/'source-hashes.json');tests=read(p/'test-hashes.json');assert len(source)==61 and len(tests)==64
for name,digest in source.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==digest
for name,digest in tests.items():assert sha(repo/'packages/stridetorch/tests'/name)==digest
for manifest,prefix in [('application-input-sha256.json',repo),('frontend-input-sha256.json',repo),('owned-input-sha256.json',repo),('baseline-immutable-sha256.json',repo),('new-assets-sha256.json',repo),('live-export-sha256.json',repo/'web/public/data')]:
 for name,digest in read(p/manifest).items():assert sha(prefix/name)==digest,(manifest,name)
policy=read(p/'release-policy-identity.json')
for name,digest in policy['files'].items():
 assert sha(repo/name)==digest
 assert hashlib.sha256(subprocess.check_output(['git','show','4db2b71b8948eb4fe8156fc80a97461431c412d8:'+name],cwd=repo)).hexdigest()==digest
cpu=read(p/'cpu-receipt.json');assert cpu['exit_code']==0 and cpu['source_hashes']==source and '41716 passed, 1 skipped' in cpu['summary'][0]
local=read(p/'local-validation.json');assert local['status']=='passed' and local['source_hashes']==source and len(local['receipts'])==6 and all(v['exit_code']==0 for v in local['receipts'])
wasm=read(p/'full-wasm-result.json');assert wasm['passed'] and wasm['modules']==wasm['catalog_modules']==85 and not wasm['browser_budget_exceeded'];assert len(wasm['results'])==85 and sum(v['mutants'] for v in wasm['results'])==378
assert all(v['passed'] and not v['browser_budget_exceeded'] for v in wasm['results'])
contracts=next(v for v in wasm['results'] if v['id']=='architecture/attention')['independent_contracts'];assert contracts['passed']==8079 and len(contracts['suites'])==63
assert {v['suite']:v['source_sha256'] for v in contracts['suites']}=={n:h for n,h in tests.items() if n!='test_standalone.py'}
package=read(r/'final-package-release/package-proof/package-identity.json');assert package['status']=='success' and package['source_hashes']==source and package['standalone_installed_tests']==8092 and package['native_torch'] is False
for name,digest in package['artifacts'].items():assert sha(r/'final-package-release/package-proof'/name)==digest
node=read(r/'versioned-release/wasm-proof/source-wasm.json');chrome=read(r/'versioned-release/wasm-proof/chrome-contracts/result.json')
for j in [node,chrome]:assert j['source_hashes']==source and j['passed']==8079 and j['library']=='0.68.0'
profile=read(p/'pages-profile-build-receipt.json');assert profile['exit_code']==0 and profile['node']=='v22.23.3' and profile['source_hashes']==source
assert profile['frontend_input_hashes']==read(p/'frontend-input-sha256.json')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();sync=read(p/'upstream-sync.json');assert sync['after']==head==profile['upstream']
for field in ['changed_upstream_paths','second_sync_changed_paths','preserved_owned_paths']:
 for name,digest in sync[field].items():assert sha(repo/name)==digest
export=read(p/'export-identity.json');assert export['version']=='0.68.0' and export['source_hashes']==source and export['catalog_modules']==85 and export['preserved_assets']==13735 and export['new_assets']==172 and export['active_export_and_index_hashes']==175
formal=read(r/'performance/summary.json');controls=read(r/'latency-controls/summary.json');assert formal['status']=='completed' and formal['children']==12 and formal['flows_per_child']==30;assert controls['status']=='completed' and controls['children']==18 and controls['flows_per_child']==5
assert formal['source_hashes']==controls['source_hashes']==dict(baseline=read(p/'baseline-source-sha256.json'),candidate=source)
review=read(p/'latency-reviewed.json');assert review['proceed_local_validation'] and review['controls_sha256']==sha(r/'latency-controls/summary.json')
memory={key:read(r/name) for key,name in [('attention','attention-memory.json'),('mlp_negative_control','mlp-memory.json'),('synthetic_prototype','candidate-gradient-memory.json')]}
for label in ['attention','mlp_negative_control']:assert memory[label]['status']=='success' and memory[label]['source_hashes']['explicit']==source
prototype=memory['synthetic_prototype']['source_hashes'];assert sorted(n for n in source if source[n]!=prototype[n])==['__init__.py']
gpu=read(r/'gpu-broker-probe/summary.json');assert gpu['status']=='passed' and gpu['fresh_browser_processes']==3 and gpu['float32_matmuls']==24 and gpu['malformed_requests_rejected']==9
runtime=read(r.parent/'torch-iteration-66/runtime-identity.json')
for name,digest in runtime['public_runtime_files'].items():assert sha(repo/'web/public/browser-runtime/pyodide-0.29.4'/name)==digest
snapshot=p/'published-inputs';snapshot.mkdir(exist_ok=True)
shutil.copytree(repo/'packages/stridetorch/src/stridetorch',snapshot/'runtime-source',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
shutil.copytree(repo/'packages/stridetorch/tests',snapshot/'runtime-tests',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
for name in ['README.md','pyproject.toml','LICENSE','NOTICE']:shutil.copy2(repo/'packages/stridetorch'/name,snapshot/name)
save(p/'state.json',dict(status='all_local_gates_passed',version='0.68.0',source_hashes=source,upstream=head,main_adopted=False))
checkpoint=read(r/'state.json');checkpoint.update(status='all_local_gates_passed',current_local_head=head,main_adopted=False,ready_for_adoption=True,integration_session_terminal=0,production_pages_build_terminal=0,next_steps=['Create exact source/report/export commit, then guarded native main push only after fresh release-chain audit.','Keep the independent functional VJP prototype separate until its remaining SDK/native/WASM/package gates pass.']);save(r/'state.json',checkpoint)
save(r/'continuation-latest.json',dict(status='all_local_gates_passed',state_file=str(r/'state.json'),main_adopted=False,ci_triggered=False,tag_or_release_created=False,next_steps=checkpoint['next_steps']))
archive=out/'iteration-68-harness.tar.gz';assert not archive.exists();seen={};payloads={};logical_bytes=0;hardlinks=0
excluded={'__pycache__','.pytest_cache','.git','pytest-tmp','node_modules','build','dist'};allowed={'.py','.mjs','.json','.log','.md','.html','.toml','.npz','.txt','.whl','.pkl','.patch'}
with tarfile.open(archive,'w:gz') as target:
 for current,dirs,files in os.walk(r):
  dirs[:]=sorted(n for n in dirs if n not in excluded and not n.endswith(('-env','-venv','.egg-info')))
  for name in sorted(files):
   q=Path(current)/name
   if q.is_symlink() or not(q.name in ['LICENSE','NOTICE'] or q.suffix in allowed or q.name.endswith('.tar.gz')):continue
   arc=str(q.relative_to(r));digest=sha(q);payloads[arc]=digest;info=target.gettarinfo(str(q),arcname=arc);logical_bytes+=q.stat().st_size;key=(digest,info.mode,info.uid,info.gid,info.uname,info.gname)
   if key in seen:info.type=tarfile.LNKTYPE;info.linkname=seen[key];info.size=0;target.addfile(info);hardlinks+=1
   else:
    seen[key]=arc
    with q.open('rb') as content:target.addfile(info,content)
with tarfile.open(archive,'r:gz') as target:
 assert len(target.getmembers())==len(payloads)
 for member in target.getmembers():assert hashlib.sha256(target.extractfile(member).read()).hexdigest()==payloads[member.name]
archive_record=dict(name=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),files=len(payloads),unique_payloads=len(seen),hardlinks=hardlinks,logical_bytes=logical_bytes,all_logical_payloads_verified=True,identical_permissions_and_ownership_required=True,filesystem_timestamps_not_comparison_inputs=True);save(p/'archive-identity.json',archive_record)
assert archive.stat().st_size<95*1024*1024
report=dict(status='validated_locally',version='0.68.0',baseline_version='0.67.0',upstream=head,full_cpu_baseline=sync['before'],source_hashes=source,test_hashes=tests,owned_inputs=read(p/'owned-input-sha256.json'),full_cpu=cpu,full_wasm=wasm,independent_package=package,versioned_node_contracts=node,versioned_chrome_contracts=chrome,local_integration=local,production_pages_build=profile,upstream_sync=sync,export_identity=export,active_export_sha256=read(p/'live-export-sha256.json'),release_policies=policy,public_runtime_files=runtime['public_runtime_files'],performance=formal,longer_outlier_controls=controls,latency_review=review,memory=memory,gpu_broker_feasibility=gpu,raw_archive=archive_record,limitations=['CPU tracked incremental allocations are not RSS, WASM heap or GPU memory. MLP negative control is unchanged; memory gains are workload dependent.','Initial latency outliers are preserved; longer balanced controls did not reproduce the ~3% GroupNorm slowdown. No universal speedup claim.','The synthetic cleanup experiment used a0.67 prototype with identical graph/numerical bytes to0.68 and a different __init__ version literal; it is not relabeled as a fresh0.68 run.','GPU fixture only proves bounded float32 matmul brokering from an opaque Worker using asynchronous Pyodide/JSPI. No torch GPU dispatch, gradients, browser-wide support, cancellation/device-loss recovery, production CSP qualification or throughput claim.','No API growth in0.68; the separate first-order functional VJP prototype is not included.','Archived raw scripts retain original workspace paths and require documented dependencies/path adjustment for replay. Historical rejected experiments are included as historical data.','Main adoption, CI execution and deployment are not implied by local validation.'])
save(out/'iteration-68.json',report)
print(json.dumps(dict(status='validated_locally',cpu=cpu['summary'],wasm_modules=85,mutants=378,minimum_tests=8092,raw_archive=archive_record)),flush=True)
