from pathlib import Path
import json,subprocess,os,time,hashlib
p=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');python=p.parent.parent/'torch-iteration-21/stride-dev-env/bin/python';read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
local=read(p/'local-validation.json');assert local['status']=='passed'
expected_ui=read(p/'frontend-input-sha256.json')
for name,digest in expected_ui.items():assert sha(repo/name)==digest,name
for name,digest in read(p/'source-hashes.json').items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==digest
for name,digest in read(p/'live-export-sha256.json').items():assert sha(repo/'web/public/data'/name)==digest
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();value=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED','--jq','.value'],cwd=repo,text=True).strip()
profile=dict(PAPERLEET_MAIN_SITE_ENABLED=value,VITE_PUBLIC_SITE='0' if value=='1' else '1',VITE_APP_EDITION='hosted' if value=='1' else 'local',VITE_API_ORIGIN='https://app.paperleet.com' if value=='1' else '',VITE_HOSTED_APP_AVAILABLE='1',VITE_HOSTED_APP_URL='https://app.paperleet.com')
(p/'current-pages-profile.json').write_text(json.dumps(dict(observed_value=value,environment=profile,source='.github/workflows/ci.yml and pages.yml exact matching environment',main=head),indent=2)+'\n');env=dict(os.environ,PYTHON=str(python),PYTHONPATH=os.pathsep.join([str(repo/'packages/stridetorch/src'),str(repo)]),**profile);env['PATH']='/Users/david/.npm/_npx/d18f28baf1132559/node_modules/node/bin:/opt/homebrew/bin:'+str(python.parent)+':'+env['PATH'];version=subprocess.check_output(['node','--version'],env=env,text=True).strip();assert version=='v22.23.3'
started=time.monotonic()
with (p/'pages-profile-build.log').open('w') as log:child=subprocess.run(['npm','run','build'],cwd=repo/'web',env=env,stdout=log,stderr=subprocess.STDOUT)
report=dict(exit_code=child.returncode,seconds=time.monotonic()-started,node=version,profile=profile,source_hashes=local['source_hashes'],upstream=head,frontend_input_hashes=expected_ui,scope='Actual current production Pages environment, built locally with Node22.23.3. No workflow dispatched and no deployment performed.');(p/'pages-profile-build-receipt.json').write_text(json.dumps(report,indent=2)+'\n');child.check_returncode()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
for name,digest in expected_ui.items():assert sha(repo/name)==digest
print('PRODUCTION PAGES PROFILE LOCAL BUILD PASS',head,flush=True)
