// Isolated feasibility probe. No library/device dispatch or production integration.
export async function runBrokerProbe() {
 const report={host_secure:isSecureContext,host_gpu:!!navigator.gpu,backend_enabled:false};
 if(!navigator.gpu)return {...report,status:'unavailable'};
 const adapter=await navigator.gpu.requestAdapter();if(!adapter)return {...report,status:'no-adapter'};
 const device=await adapter.requestDevice();const channel=new MessageChannel();let frame,busy=false;const counts={accepted:0,rejected:0,completed:0};
 const shader=`struct Dims{m:u32,k:u32,n:u32,pad:u32};
 @group(0) @binding(0) var<storage,read> a:array<f32>;
 @group(0) @binding(1) var<storage,read> b:array<f32>;
 @group(0) @binding(2) var<storage,read_write> c:array<f32>;
 @group(0) @binding(3) var<uniform> dims:Dims;
 @compute @workgroup_size(8,8) fn main(@builtin(global_invocation_id) id:vec3<u32>){
 if(id.x>=dims.n || id.y>=dims.m){return;} var v:f32=0.0;
 for(var q:u32=0u;q<dims.k;q=q+1u){v=v+a[id.y*dims.k+q]*b[q*dims.n+id.x];}
 c[id.y*dims.n+id.x]=v;}`;
 try {
  const pipeline=device.createComputePipeline({layout:'auto',compute:{module:device.createShaderModule({code:shader}),entryPoint:'main'}});
  channel.port1.onmessage=async({data})=>{
   const {id,op,m,k,n,a,b}=data??{};
   const reply=value=>channel.port1.postMessage({id,...value},value.output?[value.output.buffer]:[]);
   if(busy || op!=='matmul-f32' || ![m,k,n].every(v=>Number.isInteger(v)&&v>0&&v<=128) || m*k+k*n+m*n>32768 || !(a instanceof Float32Array) || !(b instanceof Float32Array) || a.length!==m*k || b.length!==k*n){counts.rejected++;reply({error:'Rejected bounded matmul request'});return;}
   busy=true;counts.accepted++;const buffers=[];device.pushErrorScope('validation');let popped=false;
   try {
    const buffer=(size,usage)=>{const v=device.createBuffer({size,usage});buffers.push(v);return v;};
    const left=buffer(a.byteLength,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST),right=buffer(b.byteLength,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST),output=buffer(m*n*4,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC),read=buffer(m*n*4,GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST),dims=buffer(16,GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST);
    device.queue.writeBuffer(left,0,a);device.queue.writeBuffer(right,0,b);device.queue.writeBuffer(dims,0,new Uint32Array([m,k,n,0]));
    const bindings=device.createBindGroup({layout:pipeline.getBindGroupLayout(0),entries:[left,right,output,dims].map((v,binding)=>({binding,resource:{buffer:v}}))});const encoder=device.createCommandEncoder(),pass=encoder.beginComputePass();pass.setPipeline(pipeline);pass.setBindGroup(0,bindings);pass.dispatchWorkgroups(Math.ceil(n/8),Math.ceil(m/8));pass.end();encoder.copyBufferToBuffer(output,0,read,0,m*n*4);device.queue.submit([encoder.finish()]);await read.mapAsync(GPUMapMode.READ);let value;try{value=new Float32Array(read.getMappedRange()).slice();}finally{read.unmap();}
    const validation=await device.popErrorScope();popped=true;if(validation)throw Error(validation.message);counts.completed++;reply({output:value});
   }catch(error){reply({error:String(error)});}finally{if(!popped)await device.popErrorScope();for(const b of buffers)b.destroy();busy=false;}
  };
  const workerSource=await(await fetch('./worker.mjs')).text();frame=document.createElement('iframe');frame.sandbox='allow-scripts';frame.srcdoc=`<script>onmessage=event=>{if(event.source!==parent)return;onmessage=null;const url=URL.createObjectURL(new Blob([event.data.source],{type:'text/javascript'}));const worker=new Worker(url);worker.onmessage=e=>{URL.revokeObjectURL(url);parent.postMessage(e.data,'*');};worker.onerror=e=>parent.postMessage({status:'worker-load-failed',error:String(e.message||e.type||e)},'*');worker.postMessage({base:event.data.base},[event.ports[0]]);};<\/script>`;
  const result=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{window.removeEventListener('message',listener);reject(Error('opaque worker probe timeout'));},90000);const listener=event=>{if(event.source!==frame.contentWindow)return;clearTimeout(timer);window.removeEventListener('message',listener);resolve(event.data);};window.addEventListener('message',listener);frame.onload=()=>frame.contentWindow.postMessage({source:workerSource,base:new URL('../../../',location.href).href},'*',[channel.port2]);document.body.append(frame);});
  return {...report,...result,counts,adapter:{vendor:adapter.info?.vendor,architecture:adapter.info?.architecture,fallback:adapter.info?.isFallbackAdapter},scope:'Bounded float32 matmul roundtrip through secure-host GPU service from opaque iframe Worker/Pyodide. No torch backend, autograd or speedup claim.'};
 }finally{channel.port1.close();channel.port2.close();frame?.remove();device.destroy();}
}
