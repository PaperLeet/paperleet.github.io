self.onmessage=async event=>{
 const port=event.ports[0],pending=new Map();let sequence=0;
 port.onmessage=({data})=>{const entry=pending.get(data.id);if(!entry)return;pending.delete(data.id);clearTimeout(entry.timer);data.error?entry.reject(Error(data.error)):entry.resolve(data.output);};
 const request=payload=>new Promise((resolve,reject)=>{const id=++sequence;const timer=setTimeout(()=>{pending.delete(id);reject(Error('GPU service response timeout'));},10000);pending.set(id,{resolve,reject,timer});port.postMessage({id,...payload},[payload.a.buffer,payload.b.buffer]);});
 try {
  const base=event.data.base,{loadPyodide}=await import(base+'runtime-0.29.4/pyodide.mjs'),{loadJudgePackages}=await import(base+'extraction-browser/packages.mjs');const py=await loadPyodide({indexURL:base+'runtime-0.29.4/',stdout(){},stderr(){}});await loadJudgePackages(py,[]);
  let rejected=0;
  for(const payload of [{op:'arbitrary-shader',m:1,k:1,n:1,a:new Float32Array(1),b:new Float32Array(1)},{op:'matmul-f32',m:129,k:1,n:1,a:new Float32Array(129),b:new Float32Array(1)},{op:'matmul-f32',m:2,k:2,n:2,a:new Float32Array(3),b:new Float32Array(4)}]){try{await request(payload);}catch(error){if(!String(error).includes('Rejected bounded'))throw error;rejected++;}}
  py.globals.set('host_matmul',async(a,b,m,k,n)=>{let av,bv;try{av=a.getBuffer('f32');bv=b.getBuffer('f32');const left=av.data.slice(),right=bv.data.slice();return await request({op:'matmul-f32',m,k,n,a:left,b:right});}finally{av?.release();bv?.release();}});
  const result=JSON.parse(await py.runPythonAsync(`import numpy as np,json
from pyodide.ffi import run_sync
rng=np.random.default_rng(8173)
rows=[]
for m,k,n in [(1,1,1),(3,7,5),(17,31,13),(64,64,64)]:
 for strided in [False,True]:
  a=rng.normal(size=(k,m) if strided else (m,k)).astype(np.float32)
  b=rng.normal(size=(n,k) if strided else (k,n)).astype(np.float32)
  if strided:a=a.T;b=b.T
  original_a=a.copy();original_b=b.copy();expected=a@b
  packed_a=np.ascontiguousarray(a);packed_b=np.ascontiguousarray(b)
  value=run_sync(host_matmul(packed_a,packed_b,m,k,n))
  actual=np.array(value.to_py(),dtype=np.float32).reshape(m,n)
  np.testing.assert_allclose(actual,expected,rtol=4e-5,atol=1e-5)
  np.testing.assert_array_equal(a,original_a);np.testing.assert_array_equal(b,original_b)
  rows.append(dict(shape=[m,k,n],strided_input=strided,elements=int(actual.size),max_abs_error=float(np.max(np.abs(actual-expected)))))
json.dumps(dict(status='success',numpy=np.__version__,cases=rows))`));
  self.postMessage({...result,worker_origin:self.origin,worker_secure:isSecureContext,worker_gpu:!!navigator.gpu,pyodide:py.version,jspi:{suspending:typeof WebAssembly.Suspending,promising:typeof WebAssembly.promising},rejected_requests:rejected});
 }catch(error){self.postMessage({status:'failed',error:String(error.stack||error),worker_origin:self.origin,worker_secure:isSecureContext,worker_gpu:!!navigator.gpu});}
 finally{for(const {timer,reject} of pending.values()){clearTimeout(timer);reject(Error('probe closed'));}pending.clear();port.close();}
};
