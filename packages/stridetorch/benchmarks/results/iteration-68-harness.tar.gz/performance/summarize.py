from pathlib import Path
import json,statistics,hashlib
p=Path(__file__).resolve().parent;plan=json.loads((p/'assets/plan.json').read_text());receipts=json.loads((p/'results/receipts.json').read_text());assert len(receipts)==12 and all(v['exit_code']==0 for v in receipts)
rows=[];identities={}
for runtime in ['cpu','node','chrome']:
 children=[]
 for repeat in range(4):
  path=p/'results'/f'{runtime}-{repeat}.json';raw=path.read_bytes();j=json.loads(raw);b=j.get('benchmark',j);assert b['source_hashes']==plan['source_hashes'] and len(b['rows'])==30 and b['cleanup_program_sha256']==plan['programs']['bench_cleanup.py'];children.append(b);identities[path.name]=hashlib.sha256(raw).hexdigest()
 for i in range(30):
  samples=[child['rows'][i] for child in children];first=samples[0];assert all([row[k] for k in ['operation','case','dtype','input_shape']]==[first[k] for k in ['operation','case','dtype','input_shape']] for row in samples);ratios=[row['candidate_over_baseline'] for row in samples]
  rows.append(dict(runtime=runtime,operation=first['operation'],case=first['case'],dtype=first['dtype'],input_shape=first['input_shape'],median=statistics.median(ratios),minimum=min(ratios),maximum=max(ratios),children=ratios))
report=dict(status='completed',children=12,flows_per_child=30,source_hashes=plan['source_hashes'],programs=plan['programs'],rows=rows,result_identities=identities,scope='Four serial fresh children each for CPU,Node,Chrome, real versioned0.68 source against adopted0.67. Complete matched calls, outputs and gradients checked before timing. Not an application, nativeTorch, cold import or uniform speedup claim.')
(p/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
for runtime in ['cpu','node','chrome']:
 selected=[row for row in rows if row['runtime']==runtime];print(runtime,'worst',max(selected,key=lambda v:v['median']))
