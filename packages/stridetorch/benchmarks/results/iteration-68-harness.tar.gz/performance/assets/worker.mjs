import {loadJudgePackages} from '../../../extraction-browser/packages.mjs';
self.onmessage=async()=>{try{
const plan=await(await fetch('./plan.json')).json();const {loadPyodide}=await import('../../../runtime-0.29.4/pyodide.mjs');const py=await loadPyodide({indexURL:new URL('../../../runtime-0.29.4/',self.location.href).href,stdout(){},stderr(){}});await loadJudgePackages(py,[]);
for(const label of ['baseline','candidate']){py.FS.mkdirTree('/'+label+'/stridetorch');for(const name of Object.keys(plan.source_hashes[label]))py.FS.writeFile('/'+label+'/stridetorch/'+name,await(await fetch('./'+label+'/stridetorch/'+name)).text());}
for(const name of Object.keys(plan.programs))py.FS.writeFile('/'+name,await(await fetch('./'+name)).text());py.globals.set('plan_json',JSON.stringify(plan));
const result=JSON.parse(py.runPython(`import sys,json,pathlib,hashlib
sys.path.insert(0,'/')
plan=json.loads(plan_json)
for name,digest in plan['programs'].items():assert hashlib.sha256(pathlib.Path('/'+name).read_bytes()).hexdigest()==digest
from bench_cleanup import run
result=run('/baseline/stridetorch','/candidate/stridetorch')
assert result['source_hashes']==plan['source_hashes']
assert result['cleanup_program_sha256']==plan['programs']['bench_cleanup.py']
json.dumps(result)`));self.postMessage({runtime:'chrome',pyodide:py.version,benchmark:result});
}catch(error){self.postMessage({error:String(error.stack||error)});}};
