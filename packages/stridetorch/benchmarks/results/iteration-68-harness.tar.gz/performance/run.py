from pathlib import Path
import json,subprocess,os,time,hashlib
p=Path(__file__).resolve().parent;r=p.parent;python=r.parent/'torch-iteration-21/stride-dev-env/bin/python';assets=p/'assets';out=p/'results';out.mkdir(exist_ok=True);env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');plan=json.loads((assets/'plan.json').read_text());receipts=[]
for repeat in range(4):
 for runtime in ['cpu','node','chrome'] if repeat%2==0 else ['chrome','node','cpu']:
  name=f'{runtime}-{repeat}';file=out/(name+'.json');args=[str(python),str(assets/'bench_cleanup.py'),str(assets/'baseline/stridetorch'),str(assets/'candidate/stridetorch')] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(p/f'bench-{runtime}.mjs'),str(file)];start=time.time()
  with (out/(name+'.log')).open('w') as log:
   if runtime=='cpu':
    with file.open('w') as stdout:child=subprocess.run(args,cwd=assets,env=env,stdout=stdout,stderr=log)
   else:child=subprocess.run(args,cwd=assets,env=env,stdout=log,stderr=subprocess.STDOUT)
  receipts.append(dict(runtime=runtime,repeat=repeat,exit_code=child.returncode,seconds=time.time()-start));(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');child.check_returncode();result=json.loads(file.read_text());result=result.get('benchmark',result);assert len(result['rows'])==30 and result['source_hashes']==plan['source_hashes'];print(name,'PASS',flush=True)
print('ALL12 SERIAL FRESH30-FLOW CHILDREN PASS',flush=True)
