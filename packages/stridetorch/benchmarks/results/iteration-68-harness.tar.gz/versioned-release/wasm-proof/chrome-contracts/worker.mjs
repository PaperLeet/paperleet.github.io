import {loadJudgePackages} from '../../../../extraction-browser/packages.mjs';
self.onmessage=async()=>{try{
 const plan=await(await fetch('./plan.json')).json();
 const {loadPyodide}=await import('../../../../runtime-0.29.4/pyodide.mjs');
 const py=await loadPyodide({indexURL:new URL('../../../../runtime-0.29.4/',self.location.href).href,stdout(){},stderr(){}});
 await loadJudgePackages(py,[]);py.FS.mkdirTree('/runtime/stridetorch');
 for(const name of Object.keys(plan.source))py.FS.writeFile('/runtime/stridetorch/'+name,await(await fetch('./source/'+name)).text());
 for(const name of Object.keys(plan.tests))py.FS.writeFile('/runtime/'+name,await(await fetch('./tests/'+name)).text());
 py.globals.set('plan_json',JSON.stringify(plan));
 const report=JSON.parse(py.runPython(`
import sys,json,pathlib,hashlib
sys.path.insert(0,'/runtime')
plan=json.loads(plan_json)
actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path('/runtime/stridetorch').iterdir() if p.is_file()}
assert actual==plan['source']
for name,expected in plan['tests'].items():assert hashlib.sha256(pathlib.Path('/runtime',name).read_bytes()).hexdigest()==expected
import pytest,stridetorch,numpy
assert stridetorch.__version__==plan['version']
class Record:
    passed=0
    def pytest_runtest_logreport(self,report):
        if report.when=='call' and report.passed:self.passed+=1
record=Record()
code=pytest.main(['/runtime/'+name for name in plan['tests']]+['-q','--noconftest','-p','no:cacheprovider','--import-mode=importlib'],plugins=[record])
assert int(code)==0 and record.passed==plan['expected'],(code,record.passed)
json.dumps(dict(status='success',library=stridetorch.__version__,numpy=numpy.__version__,passed=record.passed,source_hashes=actual,test_hashes=plan['tests']))
`));
 self.postMessage({...report,pyodide:py.version});
}catch(error){self.postMessage({error:String(error.stack||error)});}};
