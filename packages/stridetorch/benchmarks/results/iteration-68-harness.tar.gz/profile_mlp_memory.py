"""Warm whole MLP training-step tracked allocations with an analytic oracle."""
from pathlib import Path
import sys,json,hashlib,gc,tracemalloc,statistics
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'torch-iteration-67'))
from bench_determinants import load
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
paths=dict(baseline=repo/'packages/stridetorch/src/stridetorch',explicit=r/'versioned-release/snapshot/packages/stridetorch/src/stridetorch',reused=r/'reused-seed-source/stridetorch')
modules={};hashes={}
for name,path in paths.items():modules[name],hashes[name]=load('_mlp_memory_'+name,path)
orders=[['baseline','explicit','reused'],['reused','explicit','baseline'],['explicit','baseline','reused']]
rows=[]
for dtype in ['float32','float64']:
 for n,d,h,c in [(16,32,64,8),(64,128,256,16),(128,256,512,32)]:
  rng=np.random.default_rng(7401);x=rng.normal(size=(n,d)).astype(dtype);w1=(rng.normal(size=(d,h))*.05).astype(dtype);b1=np.full(h,.03,dtype=dtype);w2=(rng.normal(size=(h,c))*.05).astype(dtype);b2=np.full(c,-.02,dtype=dtype);labels=np.arange(n)%c
  arrays=[w1,b1,w2,b2];z0=x.astype('float64')@w1.astype('float64')+b1;hidden=np.maximum(z0,0);logits=hidden@w2.astype('float64')+b2;shift=logits-logits.max(-1,keepdims=True);prob=np.exp(shift);prob/=prob.sum(-1,keepdims=True);loss_ref=-np.log(prob[np.arange(n),labels]).mean();dz=prob.copy();dz[np.arange(n),labels]-=1;dz/=n;dh=(dz@w2.astype('float64').T)*(z0>0);grads=[x.astype('float64').T@dh,dh.sum(0),hidden.T@dz,dz.sum(0)]
  fixtures={}
  for name,module in modules.items():
   t=module.torch;params=[t.nn.Parameter(t.tensor(a)) for a in arrays];inputs=t.tensor(x);targets=t.tensor(labels,dtype=t.int64);opt=t.optim.SGD(params,lr=.01)
   def reset(params=params,t=t):
    with t.no_grad():
     for param,array in zip(params,arrays):param.copy_(t.tensor(array))
   def step(t=t,params=params,inputs=inputs,targets=targets,opt=opt):
    opt.zero_grad(set_to_none=True);hval=t.relu(inputs@params[0]+params[1]);value=t.nn.functional.cross_entropy(hval@params[2]+params[3],targets);value.backward();opt.step();return value
   reset();value=step();tol=3e-5 if dtype=='float32' else 3e-11;atol=3e-6 if dtype=='float32' else 3e-12;np.testing.assert_allclose(value.numpy(),loss_ref,rtol=tol,atol=atol)
   for param,array,g in zip(params,arrays,grads):np.testing.assert_allclose(param.grad.numpy(),g,rtol=tol,atol=atol);np.testing.assert_allclose(param.numpy(),array.astype('float64')-.01*g,rtol=tol,atol=atol)
   fixtures[name]=(reset,step)
  samples={name:[] for name in paths}
  for order in orders:
   for name in order:
    reset,step=fixtures[name];reset();gc.collect();tracemalloc.start(1);tracemalloc.reset_peak();value=step();current,peak=tracemalloc.get_traced_memory();tracemalloc.stop();del value;samples[name].append(dict(current_bytes=current,peak_bytes=peak))
  medians={name:statistics.median(v['peak_bytes'] for v in values) for name,values in samples.items()};rows.append(dict(dtype=dtype,shape=[n,d,h,c],samples=samples,median_peak_bytes=medians,ratios={name:medians[name]/medians['baseline'] for name in ['explicit','reused']}))
report=dict(status='success',source_hashes=hashes,program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),python=sys.version,numpy=np.__version__,rows=rows,scope='Warm complete linear-ReLU-linear-crossentropy-SGD call including zeroing/backward/step; exact-input float64 analytic loss, four gradients and four updated-parameter arrays checked before tracing. Existing params/gradients predate tracing. CPU tracked allocations only, not latency, RSS or browser heap.')
(r/'mlp-memory.json').write_text(json.dumps(report,indent=2)+'\n')
for row in rows:print(row['dtype'],row['shape'],row['ratios'])
