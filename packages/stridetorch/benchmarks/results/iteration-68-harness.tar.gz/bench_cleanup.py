"""Joint routing controls plus complete fixed-parameter MHA backward calls."""
from pathlib import Path
import gc,hashlib,json,statistics,time,sys
import numpy as np
import bench_joint as joint
from bench_determinants import load

def attention(module,shape,dtype):
 t=module.torch;n,length,dim=shape;rng=np.random.default_rng(7427);model=t.nn.MultiheadAttention(dim,4,batch_first=True,dropout=0,dtype=getattr(t,dtype));x=t.tensor(rng.normal(size=shape).astype(dtype),requires_grad=True)
 with t.no_grad():
  for parameter in model.parameters():parameter.copy_(t.tensor((rng.normal(size=tuple(parameter.shape))*.04).astype(dtype)))
 params=list(model.parameters())
 def call():
  model.zero_grad(set_to_none=True);x.grad=None;out,_=model(x,x,x,need_weights=False);value=out.square().mean();value.backward();return value
 def capture():
  value=call();return [value.numpy().copy(),x.grad.numpy().copy(),*[p.grad.numpy().copy() for p in params]]
 return call,capture

def run(baseline,candidate):
 result=joint.run(baseline,candidate);a,ah=load('_mha_latency_old',baseline);b,bh=load('_mha_latency_new',candidate);assert result['source_hashes']==dict(baseline=ah,candidate=bh)
 for dtype in ['float32','float64']:
  for shape in [(1,16,32),(2,64,256)]:
   variants={name:attention(module,shape,dtype) for name,module in [('baseline',a),('candidate',b)]};want=variants['baseline'][1]();actual=variants['candidate'][1]();assert len(want)==len(actual)==6
   for x,y in zip(actual,want):np.testing.assert_allclose(x,y,rtol=3e-5 if dtype=='float32' else 3e-11,atol=3e-6 if dtype=='float32' else 3e-12)
   del actual,want;gc.collect();calls=1
   for fn,_ in variants.values():
    batch=1
    while True:
     start=time.perf_counter()
     for _ in range(batch):fn()
     if time.perf_counter()-start>=.02:break
     batch*=2
    calls=max(calls,batch)
   samples={name:[] for name in variants}
   for repeat in range(10):
    for name in variants if repeat%2==0 else reversed(variants):
     start=time.perf_counter()
     for _ in range(calls):variants[name][0]()
     samples[name].append((time.perf_counter()-start)/calls)
   medians={name:statistics.median(values) for name,values in samples.items()};result['rows'].append(dict(operation='mha',case='backward_'+str(shape[-1]),kind='backward',dtype=dtype,input_shape=list(shape),calls=calls,samples_s=samples,median_s=medians,candidate_over_baseline=medians['candidate']/medians['baseline'],pre_timing_arrays=6))
 assert len(result['rows'])==30
 result.update(python=sys.version,numpy=np.__version__,cleanup_program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='26 existing complete GroupNorm/classification controls with five balanced common >=20ms batches, plus four complete MHA loss/backward/zeroing calls with ten balanced common >=20ms batches. All inputs/params are fixed; no optimizer update in timed MHA. Six output/gradient arrays matched before MHA timing; independent native checks are separate. No uniform speedup, browser memory, nativeTorch or application throughput claim.')
 return result
if __name__=='__main__':print(json.dumps(run(sys.argv[1],sys.argv[2]),indent=2))
