from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;p=r/'latency-controls';a=p/'assets';a.mkdir(parents=True,exist_ok=True);old=r.parent/'torch-iteration-67/lean-outliers/assets'
for label in ['baseline','candidate']:shutil.copytree(r/'performance/assets'/label,a/label,dirs_exist_ok=True)
for name in ['bench_determinants.py','bench_inverse.py','bench_joint.py','bench_groupnorm_fixture.py','bench_classification_fixture.py','bench_lean_outliers.py']:shutil.copy2(old/name,a/name)
plans=[dict(group='joint',operation='groupnorm',dtype=dtype,input_shape=shape,kind=kind,case=case) for dtype,shape,kind,case in [('float64',[256,128],'train','mlp_train'),('float32',[256,128],'affine','affine'),('float64',[256,128],'affine','affine'),('float64',[8,16,16,16],'train','vision_train')]]
plans.append(dict(group='joint',operation='classification',dtype='float32',input_shape=[8,16],kind='smooth',case='smooth_8'))
(a/'selected.json').write_text(json.dumps(plans,indent=2)+'\n')
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
plan=dict(source_hashes=json.loads((r/'performance/assets/plan.json').read_text())['source_hashes'],programs={q.name:sha(q) for q in a.glob('*.py')},selected_sha256=sha(a/'selected.json'))
(a/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
code="""import sys,json,pathlib,hashlib
sys.path.insert(0,'/')
plan=json.loads(plan_json)
for name,digest in plan['programs'].items():assert hashlib.sha256(pathlib.Path('/'+name).read_bytes()).hexdigest()==digest
assert hashlib.sha256(pathlib.Path('/selected.json').read_bytes()).hexdigest()==plan['selected_sha256']
from bench_lean_outliers import run
result=run('/baseline/stridetorch','/candidate/stridetorch',json.loads(pathlib.Path('/selected.json').read_text()),cycle)
assert result['source_hashes']==dict(baseline=plan['source_hashes']['baseline'],duplicate=plan['source_hashes']['baseline'],candidate=plan['source_hashes']['candidate'])
json.dumps(result)"""
(p/'code.json').write_text(json.dumps(code))
(a/'worker.mjs').write_text("""import {loadJudgePackages} from '../../../extraction-browser/packages.mjs';
self.onmessage=async({data})=>{try{
const plan=await(await fetch('./plan.json')).json();const {loadPyodide}=await import('../../../runtime-0.29.4/pyodide.mjs');const py=await loadPyodide({indexURL:new URL('../../../runtime-0.29.4/',self.location.href).href,stdout(){},stderr(){}});await loadJudgePackages(py,[]);
for(const label of ['baseline','candidate']){py.FS.mkdirTree('/'+label+'/stridetorch');for(const name of Object.keys(plan.source_hashes[label]))py.FS.writeFile('/'+label+'/stridetorch/'+name,await(await fetch('./'+label+'/stridetorch/'+name)).text());}
for(const name of [...Object.keys(plan.programs),'selected.json'])py.FS.writeFile('/'+name,await(await fetch('./'+name)).text());py.globals.set('plan_json',JSON.stringify(plan));py.globals.set('cycle',data.cycle);
const result=JSON.parse(py.runPython("""+json.dumps(code)+"""));self.postMessage({runtime:'chrome',pyodide:py.version,numpy:py.runPython('__import__("numpy").__version__'),benchmark:result});
}catch(error){self.postMessage({error:String(error.stack||error)});}};
""")
node=(r/'performance/bench-node.mjs').read_text();node=node[:node.index("const code=`")]+"py.FS.writeFile('/selected.json',fs.readFileSync(path.join(assets,'selected.json')));py.globals.set('cycle',Number(process.env.CYCLE));\nconst code="+json.dumps(code)+";\nconst result=JSON.parse(py.runPython(code));assert.equal(result.rows.length,5);fs.writeFileSync(process.argv[2],JSON.stringify({runtime:'node',pyodide:py.version,numpy:py.runPython('__import__(\"numpy\").__version__'),benchmark:result},null,2)+'\\n');\n";(p/'bench-node.mjs').write_text(node)
chrome=(r/'performance/bench-chrome.mjs').read_text().replace('torch-iteration-68/performance/assets/','torch-iteration-68/latency-controls/assets/').replace('page.evaluate(()=>new Promise','page.evaluate((cycle)=>new Promise').replace('worker.postMessage({});}));','worker.postMessage({cycle});}),Number(process.env.CYCLE));').replace('result.benchmark.rows.length,30','result.benchmark.rows.length,5').replace("result.benchmark.numpy,'2.2.5'","result.numpy,'2.2.5'")
(p/'bench-chrome.mjs').write_text(chrome)
