from pathlib import Path
import hashlib,json,re,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
def read(name):return json.loads((r/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
p=read('publication.json');commit=p['commit'];assert commit=='93e8cbba55bebddc4d0d9522cd8c7fc1654e5b40'
o=read('remote-observer-terminal.json');q=o['runs']['quality'];assert o['status']=='failure' and q['id']==38948582658 and q['head_sha']==commit and q['conclusion']=='failure'
jobs={j['name']:j for j in q['jobs']};assert jobs['native']['conclusion']==jobs['browser-wasm']['conclusion']=='success' and jobs['infrastructure']['conclusion']==jobs['pilot']['conclusion']=='failure'
for name,h in p['source_hashes'].items():assert hashlib.sha256(subprocess.check_output(['git','show',commit+':packages/stridetorch/src/stridetorch/'+name],cwd=repo)).hexdigest()==h
for name,h in p['export_sha256'].items():assert sha(r/'integration-proof/live-expected'/name)==h and hashlib.sha256(subprocess.check_output(['git','show',commit+':web/public/data/'+name],cwd=repo)).hexdigest()==h
assert len(p['source_hashes'])==47 and len(p['export_sha256'])==161
n=read('remote-native/ci.json');w=read('remote-wasm/browser-wasm.json');assert n['passed'] and not n['issues'] and n['problems']==78 and n['tests_executed']==10218 and n['repeats']==3 and n['duration_s']<=600 and sum(map(len,n['mutation'].values()))==342
assert w['passed'] and w['scope']=='catalog' and w['modules']==78 and not w['browser_budget_exceeded'] and sum(c['mutants'] for c in w['results'])==342
reference={c['id']:c for c in read('integration-proof/full-wasm-result.json')['results']}
for case in w['results']:
 for key in ('tests','mutants','pyodide','numpy','backend','packages','bundle_url','runtime_bundle_url','source_sha256','budgets'):assert case[key]==reference[case['id']][key]
contracts=next(c['independent_contracts'] for c in w['results'] if 'independent_contracts' in c);assert contracts['passed']==1128 and len(contracts['suites'])==32 and {c['suite']:c['source_sha256'] for c in contracts['suites']}==read('integration-proof/wasm-harness-identity.json')['test_hashes']
log=(r/'remote-infrastructure.log').read_text();m=re.search(r'4 failed, 31038 passed, 1 skipped, 37 warnings in ([\d.]+)s',log);assert m
failed=sorted(set(re.findall(r'FAILED (tests/test_torch_cholesky\.py::[^\s]+)',log)));assert len(failed)==4 and all('used-nan' in f or 'diagonal-nan' in f for f in failed)
pages=read('failed-source-pages-jobs.json');assert len(pages)==1 and pages[0]['id']==38949910058 and pages[0]['head_sha']==commit and pages[0]['conclusion']=='skipped' and {j['name']:j['conclusion'] for j in pages[0]['jobs']}=={'build':'skipped','deploy':'skipped'}
downloads=read('remote-download-receipts.json');assert len(downloads)==3 and all(v['exit_code']==0 for v in downloads.values())
p.update(quality_status='failure',deployment_status='skipped',observed_pages_runs=[38949910058],live_verified=False);(r/'publication.json').write_text(json.dumps(p,indent=2)+'\n')
files=['close-remote-failure.py','publication.json','remote-observer-terminal.json','remote-infrastructure.log','remote-native/ci.json','remote-wasm/browser-wasm.json','remote-download-receipts.json','download-remote.py','failed-source-pages-runs.json','failed-source-pages-jobs.json','integration-proof/wasm-harness-identity.json','integration-proof/release-snapshot.json']
archive=out/'iteration-32-remote-failure-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name in files:tar.add(r/name,arcname=name,recursive=False)
report=dict(status='remote_quality_failed_not_deployed',version='0.32.0',source_commit=commit,quality=q,source_hashes=p['source_hashes'],export_files=161,native=n,wasm={k:v for k,v in w.items() if k!='results'},independent_contracts=contracts,infrastructure=dict(failed=4,passed=31038,optional_skip=1,warnings=37,duration_s=float(m[1]),failed_assertions=failed),actual_pages=pages,last_verified_live=p['last_verified_site'],live_verification_not_attempted_for_failed_source=True,receipts=dict(observer=dict(session=49082,exit_code=1),downloads=dict(session=77476,exit_code=0,children=downloads)),archive=dict(file=archive.name,files=len(files),bytes=archive.stat().st_size,sha256=sha(archive)),scope='Exact Git93e8 and frozen0.32 exports/tests verified;current0.33 worktree never substituted. Native NaN exception behavior is not portable. New0.33 probes additionally expose silent finite-factor failures on WASM.0.33 adds explicit factor status and is undergoing separate complete validation;0.32 is not claimed deployed or remotely accepted.')
(out/'iteration-32-remote-failure.json').write_text(json.dumps(report,indent=2)+'\n');(r/'remote-failure.json').write_text(json.dumps(report,indent=2)+'\n');s=read('state.json');s.update(phase='0.32 exact-source Quality failed;Pages build/deploy skipped;0.33 portable status fix under validation',remote_observer=dict(session=49082,quality_id=38948582658,terminal_collected=True,exit_code=1),remote_failure_report='iteration-32-remote-failure.json');(r/'state.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(dict(status=report['status'],failed=failed,archive=report['archive']),indent=2))
