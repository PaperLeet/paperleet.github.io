from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,subprocess,time
r=Path(__file__).resolve().parent;plans={'native-artifact':['gh','run','download','38948582658','-n','judge-reports','-D',str(r/'remote-native')],'wasm-artifact':['gh','run','download','38948582658','-n','browser-wasm-reports','-D',str(r/'remote-wasm')],'infrastructure-log':['gh','run','view','38948582658','--job','117133902190','--log']};receipts={}
def run(name,args):
 start=time.monotonic()
 with (r/('remote-infrastructure.log' if name=='infrastructure-log' else name+'.log')).open('w') as log:p=subprocess.run(args,cwd='/Users/david/Developer/PaperLeet-torch-release',stdout=log,stderr=subprocess.STDOUT)
 return name,dict(args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-start)
with ThreadPoolExecutor(max_workers=3) as pool:
 for f in as_completed([pool.submit(run,name,args) for name,args in plans.items()]):
  name,receipt=f.result();receipts[name]=receipt;(r/'remote-download-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,'terminal',receipt['exit_code'],flush=True)
assert all(v['exit_code']==0 for v in receipts.values())
