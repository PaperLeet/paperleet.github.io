from pathlib import Path
import contextlib,json,torch
from torch.nn.attention import sdpa_kernel,SDPBackend
rows=[]
def record(name,fn):
 try:rows.append(dict(name=name,status='success',result=fn()))
 except Exception as error:rows.append(dict(name=name,status=type(error).__name__,error=str(error)[:400]))
for need in [True,False]:
 for mask_dtype in [torch.float32,torch.float64,torch.bool]:
  def call(need=need,mask_dtype=mask_dtype):
   m=torch.nn.MultiheadAttention(4,2,dtype=torch.float64);q=torch.ones(3,2,4,dtype=torch.float64)
   with sdpa_kernel(SDPBackend.MATH):y,w=m(q,q,q,attn_mask=torch.zeros(3,3,dtype=mask_dtype),need_weights=need)
   return dict(dtype=str(y.dtype),shape=list(y.shape))
  record(f'need{need}-mask{mask_dtype}',call)
for source,static_source in [(3,5),(3,3)]:
 for mask in ['none','attn','padding']:
  def call(source=source,static_source=static_source,mask=mask):
   m=torch.nn.MultiheadAttention(4,2,dtype=torch.float64);q=torch.ones(2,1,4,dtype=torch.float64);k=torch.ones(source,1,4,dtype=torch.float64);s=torch.ones(2,static_source,2,dtype=torch.float64)
   with sdpa_kernel(SDPBackend.MATH):y,w=torch.nn.functional.multi_head_attention_forward(q,k,k,4,2,m.in_proj_weight,m.in_proj_bias,None,None,False,0.,m.out_proj.weight,m.out_proj.bias,static_k=s,static_v=s,attn_mask=torch.zeros(2,source,dtype=torch.bool) if mask=='attn' else None,key_padding_mask=torch.zeros(1,static_source,dtype=torch.bool) if mask=='padding' else None)
   return dict(output=list(y.shape),weights=list(w.shape))
  record(f'static{source}-{static_source}-{mask}',call)
record('namespace',lambda:dict(root=hasattr(torch.nn,'NonDynamicallyQuantizableLinear'),modules=hasattr(torch.nn.modules,'NonDynamicallyQuantizableLinear'),linear=hasattr(torch.nn.modules.linear,'NonDynamicallyQuantizableLinear'),constants=torch.nn.MultiheadAttention.__constants__))
record('versions',lambda:{k:v._version for k,v in torch.nn.MultiheadAttention(4,2,add_bias_kv=True).named_parameters()})
out=dict(native=torch.__version__,rows=rows);Path(__file__).with_name('native-details.json').write_text(json.dumps(out,indent=2)+'\n')
for row in rows:print(row)
