from pathlib import Path
import hashlib,json

r=Path(__file__).resolve().parent;p=r/'proof';old=r.parent/'torch-iteration-51/proof'
source=p/'source'
hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in source.iterdir() if f.is_file()}
(p/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
s=(old/'check-wheel.py').read_text().replace('==53','==54').replace('package_modules=53','package_modules=54').replace('stride051','stride052-preflight').replace('StrideTorch0.45','MHA candidate')
(p/'check-wheel.py').write_text(s)
s=(old/'check-coinstall.py').read_text()
needle="print('PASS isolated ownership,aliases,ZIP resume,triangular,Cholesky and Cholesky solve VJP/JVP/full tangent reverse')"
addition="""for name in NAMES:
 t=importlib.import_module(name).torch
 layer=t.nn.MultiheadAttention(4,2,batch_first=True,add_bias_kv=True,dtype=t.float64)
 x=t.tensor(np.sin(np.arange(24)).reshape(2,3,4),requires_grad=True)
 y,j=t.func.jvp(lambda a:layer(a,a,a,need_weights=False)[0],(x,),(t.ones_like(x),))
 (y.square().sum()+j.square().sum()).backward()
 assert y.shape==j.shape==(2,3,4) and np.isfinite(x.grad.numpy()).all()
 assert all(p.grad is not None for p in layer.parameters())
"""
assert needle in s
s=s.replace(needle,addition+needle)
(p/'check-coinstall.py').write_text(s)
print('Prepared independent Python3.10 / NumPy1.26.4 package and ownership gates')
