from pathlib import Path
import hashlib,json,os,shutil,subprocess,time

r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
py=r.parent/'torch-iteration-21/stride-dev-env/bin/python'
env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
dest=r/'fairbench';dest.mkdir(exist_ok=True)
plan=json.loads((r/'proof/chrome-contracts/bench-plan.json').read_text())
source=repo/'packages/stridetorch/src/stridetorch'
for name,digest in plan['source'].items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==digest
bench=repo/'packages/stridetorch/benchmarks/bench_multihead.py'
assert hashlib.sha256(bench.read_bytes()).hexdigest()==plan['benchmark_sha256']
receipts=[]
for repeat in range(4):
    order=['cpu','node','chrome'] if repeat%2==0 else ['chrome','node','cpu']
    for runtime in order:
        label=f'{runtime}-{repeat}'
        if runtime=='cpu':args=[str(py),str(bench)]
        elif runtime=='node':args=['/opt/homebrew/bin/node',str(r/'proof/bench-node.mjs')]
        else:args=['/opt/homebrew/bin/node',str(r/'proof/chrome-contracts/bench-run.mjs')]
        start=time.monotonic()
        with (dest/(label+'.log')).open('w') as out:
            child=subprocess.run(args,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
        receipts.append(dict(label=label,args=args,exit_code=child.returncode,elapsed_s=time.monotonic()-start))
        (dest/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
        print(label,'TERMINAL',child.returncode,flush=True);child.check_returncode()
        if runtime=='cpu':data=json.loads((dest/(label+'.log')).read_text())
        else:
            path=r/('proof/bench-node-result.json' if runtime=='node' else 'proof/chrome-contracts/bench-result.json')
            data=json.loads(path.read_text());assert data['source_hashes']==plan['source']
            if runtime=='chrome':assert data['benchmark_sha256']==plan['benchmark_sha256']
        (dest/(label+'.json')).write_text(json.dumps(data,indent=2)+'\n')
(dest/'identity.json').write_text(json.dumps(dict(source_hashes=plan['source'],benchmark_sha256=plan['benchmark_sha256'],
    thread_caps={k:env[k] for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS']},
    all_children_terminal=True,children=len(receipts)),indent=2)+'\n')
