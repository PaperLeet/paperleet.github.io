from pathlib import Path
import hashlib,json,re,subprocess,tarfile,statistics

r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
p=r/'proof';c=p/'chrome-contracts';results=repo/'packages/stridetorch/benchmarks/results'
def read(path):return json.loads(path.read_text())
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
source=repo/'packages/stridetorch/src/stridetorch'
expected=read(p/'source-hashes.json')
actual={f.name:digest(f) for f in source.iterdir() if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']}
assert actual==expected and len(actual)==56
plan=read(c/'plan.json')
for name,value in plan['tests'].items():assert digest(repo/'packages/stridetorch/tests'/name)==value
node=read(p/'source-wasm.json');chrome=read(c/'result.json')
for data in [node,chrome]:assert data['source_hashes']==actual and data['passed']==6402 and data['numpy']=='2.2.5'
assert chrome['test_hashes']==plan['tests']
wheel=read(p/'wheel-stride052-preflight-result.json');coinstall=read(p/'coinstall-result.json')
for data in [wheel,coinstall]:assert data['status']=='success' and data['source_hashes']==actual
assert not wheel['native_torch']
cpu=re.search(r'(\d+) passed, (\d+) skipped, (\d+) warnings in ([\d.]+)s',(r/'full-cpu.log').read_text())
assert cpu and int(cpu[1])==40031 and int(cpu[2])==1
assert '6415 passed' in (p/'python310-stride052-preflight-tests.log').read_text()
comparison=read(r/'mha-comparison.json');assert comparison['status']=='passed' and comparison['arrays']==4107
fair=r/'fairbench';identity=read(fair/'identity.json');receipts=read(fair/'receipts.json')
assert identity['all_children_terminal'] and identity['children']==12 and len(receipts)==12
assert all(v['exit_code']==0 for v in receipts)
assert identity['source_hashes']==actual
assert identity['benchmark_sha256']==digest(repo/'packages/stridetorch/benchmarks/bench_multihead.py')
summary={}
for runtime in ['cpu','node','chrome']:
    summary[runtime]={}
    for mode in ['forward','reverse','jvp','training4']:
        medians=[];regressions=[]
        for repeat in range(4):
            data=read(fair/f'{runtime}-{repeat}.json');data=data.get('benchmark',data)
            rows=[v for v in data['rows'] if v['mode']==mode]
            assert len(rows)==6
            medians.append(statistics.median((1-v['packed_over_control'])*100 for v in rows))
            regressions.append(sum(v['packed_over_control']>1 for v in rows))
        summary[runtime][mode]=dict(median_reduction_percent=statistics.median(medians),
            process_median_range_percent=[min(medians),max(medians)],slower_rows_per_process=regressions)
baseline='13d2782a494415ba72bc604a0ef7e4c4f875ba25'
policies=['.github/workflows/ci.yml','.github/workflows/pages.yml','web/scripts/check-release-request.cjs','web/scripts/pages-release-gate.cjs','web/scripts/check-pages-release.cjs','web/scripts/check-pages-backfill.cjs','docs/releasing.md']
for name in policies:assert (repo/name).read_bytes()==subprocess.check_output(['git','show',baseline+':'+name],cwd=repo)
record=dict(status='development_preflight_passed',iteration=52,package_version='0.51.0',
    scope='MHA feature branch; release metadata and active browser exports have not been advanced',
    baseline_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
    source_hashes=actual,test_hashes=plan['tests'],new_tests=218,
    cpu=dict(passed=int(cpu[1]),skipped=int(cpu[2]),warnings=int(cpu[3]),duration_s=float(cpu[4]),observed_process_exit_code=0),
    native_comparison=comparison,node=dict(passed=6402,pyodide='0.29.4',numpy='2.2.5'),
    chrome=dict(passed=6402,browser=chrome['browser'],pyodide=chrome['pyodide'],numpy=chrome['numpy']),
    minimum_wheel=dict(passed=6415,python=wheel['python'],numpy=wheel['numpy'],native_torch=False),
    independent_ownership=coinstall['status'],performance=summary,
    performance_scope='Packed self-attention vs same-library three-projection control, not prior release or native Torch. Three shapes, both dtypes, 24 flows per runtime, four fresh processes, five samples, four calls (one four-SGD flow). Restore and result copies excluded from training timing; optimizer construction included. Shared host; no peak RSS or universal speed claim.',
    policies={n:digest(repo/n) for n in policies},no_remote_mutations=True,
    pending=['Advance version metadata after final integration validation','Regenerate and verify active exports while preserving published immutable payloads','Run full exported 78-problem WASM catalog and frontend/build gates','Check current remote and Actions before any ordinary main adoption'],
    harness_scripts={f.name:digest(f) for f in r.glob('*.py')})
archive=results/'iteration-52-mha-preflight-harness.tar.gz';target=results/'iteration-52-mha-preflight.json'
assert not archive.exists() and not target.exists()
selected=set()
for pattern in ['*.py','*.json','*.log','*.npz','fairbench/*','fairbench-pre-seed/*','pre-seed-benchmark-evidence/*','bench-initial-including-reset/*',
                'proof/*.py','proof/*.mjs','proof/*.json','proof/*.log','proof/source/*',
                'proof/chrome-contracts/*','proof/chrome-contracts/tests/*.py',
                'proof/python310-stride052-preflight-tests/*.py','proof/dist-preflight/*','proof/private-dist/*']:
    selected.update(f for f in r.glob(pattern) if f.is_file())
with tarfile.open(archive,'w:gz') as tar:
    for f in sorted(selected):tar.add(f,arcname=f.relative_to(r),recursive=False)
record['archive']=dict(path=archive.relative_to(repo).as_posix(),sha256=digest(archive),files=len(selected),bytes=archive.stat().st_size)
target.write_text(json.dumps(record,indent=2)+'\n')
table=[]
for runtime in ['cpu','node','chrome']:
    for mode,data in summary[runtime].items():
        low,high=data['process_median_range_percent']
        table.append(f"| {runtime} | {mode} | {data['median_reduction_percent']:.1f}% | {low:.1f}% to {high:.1f}% |")
report=f'''# Torch runtime iteration 52 — MHA development preflight

This feature branch adds `nn.MultiheadAttention` and
`nn.functional.multi_head_attention_forward`. It is a development checkpoint:
package metadata still says 0.51.0, main remains at the prior adopted version,
and final browser exports/main adoption are pending. No release or online
deployment has been initiated. The broader library/core-coverage/backend goal
remains active. Project renaming awaits the user's selection.

## Behavior and compatibility

The math path supports real float32/float64, batched sequence-first/batch-first
and unbatched inputs, self/shared-KV/cross attention, separate K/V widths,
boolean and additive 2D/3D attention masks, key padding, averaged/per-head
weights, bias K/V and zero tokens, functional static K/V, dropout and evaluation.
Self-attention packs Q/K/V into one projection; shared K/V packs those two.
Output projection uses the native NonDynamicallyQuantizableLinear namespace,
genuine initialization writes and parameter versions. State dictionaries, hooks,
conversion, independent pickle/deepcopy and optimizer/checkpoint continuation
are tested. Input/parameter/mask gradients and JVP/mixed AD compose through the
existing engine, with saved-version guards.

Native reference execution explicitly disables MHA fastpath and selects SDPA
MATH on Torch 2.14.1. It does not claim fused inference equivalence. The native
probe retains backend differences: fastpath may ignore a causal hint and may
produce NaNs for fully masked rows even without returned weights. This library
follows math fallback behavior: causal hints require explicit masks; returned
weights preserve fully-masked softmax NaNs; no-weight SDPA returns zero attention
before the output projection, so nonzero output bias remains. Nonempty finite
mask cases are used in the full mixed-native differential, and fully-masked
values/first derivatives are checked separately against independent equations.
No new fully-masked native mixed-derivative equivalence is asserted.

Returned weights require a matching final additive-mask dtype, while SDPA also
accepts float32 masks with float64 input. Boolean masks mean True=blocked.
Training follows the library's dropout distribution/stream; native seeded dropout
bits are not promised. Invalid probabilities and non-positive/non-integer or
boolean dimensions are rejected eagerly; some native constructors defer or
accept these inputs. No nested tensors, GPU/Flash kernel or quantization support
is added by this change.

## Validation

| Check | Observed result |
|---|---|
| Complete CPU repository/library suite | 40,031 passed, 1 skipped; {float(cpu[4]):.2f}s |
| New independent NumPy MHA tests | 218 passed |
| Separate native processes | 192 differential cases + 16 initialization cases; 4,107 arrays |
| Node / Pyodide 0.29.4 / NumPy 2.2.5 | 6,402 contracts, 49 suites |
| Actual Chrome {chrome['browser']} Worker | Same 6,402 contracts and exact source/test hashes |
| Installed Python 3.10.19 / NumPy 1.26.4 wheel | 6,415 passed, native Torch absent |
| Public/private coinstall and independent uninstall | Exact 54 Python modules plus LICENSE/NOTICE; MHA primal/JVP/mixed reverse runs in both namespaces |
| Release policy | Seven canonical files byte-identical |

The independent NumPy reference uses separate operand projections and explicit
head contractions. Directional finite differences validate each input,
parameter and floating mask VJP; JVPs are independently differenced, and nested
finite differences check reverse-over-JVP inputs, parameters and directions.
The output bias is correctly unused by a pure input-JVP loss. A stochastic
embedding/LayerNorm/MHA/MLP encoder trains, restores AdamW/scheduler state and
continues with identical parameters. Forward/reverse dropout replay, empty
static sources, fully masked rows and mutation guards have dedicated checks.

Native differential tolerances are rtol 8e-5 / atol 8e-6 for float32 and
2e-10 / 2e-11 for float64. All array schemas, dtypes, shapes, None gradients
and initialization versions agree. The largest observed absolute error is
9.54e-7 across gradients/mixed derivatives; initialization differs by at most
5.96e-8. Native arrays and source-identified script are archived separately from
the adapter arrays; no Torch installation is needed for portable tests.

## Projection packing measurements

Positive percentages mean less time than the same library's three-independent-
projection control. This is a mechanism comparison, not a previous-version or
native Torch comparison. Three self-attention shapes and both dtypes produce
24 flows per runtime. Four fresh processes per runtime run sequentially with
alternating runtime/method order, five samples and four calls per sample (one
four-step encoder SGD flow for training). Numerical-library thread caps are two.
Parameter restoration and diagnostic array copies are outside training timing;
optimizer construction is included. Values, all input/parameter gradients,
JVPs and matching four-update encoder parameters are checked before timing.

| Runtime | Flow | Median reduction | Range of process medians |
|---|---|---:|---:|
{chr(10).join(table)}

All per-shape samples and slower cases are retained. Small differences can be
host noise; these observations establish no universal speed or peak-memory
improvement. Initial concurrent/restore-including pilots are preserved separately.

## Evidence and remaining integration

Machine-readable results and the matching raw source/tests, native arrays,
benchmarks, logs, wheels and receipts are stored in
`packages/stridetorch/benchmarks/results/iteration-52-mha-preflight.json` and
`iteration-52-mha-preflight-harness.tar.gz`. The archive is SHA-256 identified.
It excludes virtual environments, credentials and runtime binaries.

Before promoting this candidate, advance the version, regenerate active exports
without replacing published immutable payloads, verify the complete 78-problem
exported WASM catalog, and run frontend/build gates. Then inspect current remote
main and active quality/Pages chains before an ordinary non-force main push.
No CI trigger, tag, workflow dispatch, release, PyPI upload or deployment is
authorized by this checkpoint. CPU/WASM optimization and broader core coverage,
including Transformer composition and optional GPU execution, remain ongoing.
'''
(repo/'docs/validation/torch-runtime-iteration-52-preflight.md').write_text(report)
print(json.dumps(dict(status=record['status'],archive=record['archive'],performance=summary)))
