from pathlib import Path
import hashlib
import json
import shutil

r=Path(__file__).resolve().parent
repo=Path('/Users/david/Developer/PaperLeet-torch-release')
old=r.parent/'torch-iteration-51'
p=r/'proof';chrome=p/'chrome-contracts';chrome.mkdir(parents=True,exist_ok=True)
for destination in [p/'source',chrome/'source']:
    destination.mkdir(exist_ok=True)
    for f in (repo/'packages/stridetorch/src/stridetorch').iterdir():
        if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']:shutil.copy2(f,destination/f.name)
def hashes(folder):return {f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in folder.iterdir() if f.is_file()}
source=hashes(p/'source');assert len(source)==56
tests=chrome/'tests';tests.mkdir(exist_ok=True)
for f in (repo/'packages/stridetorch/tests').glob('test_*.py'):
    if f.name!='test_standalone.py':shutil.copy2(f,tests/f.name)
assert len(hashes(tests))==49
(chrome/'plan.json').write_text(json.dumps(dict(version='0.51.0',candidate='0.52 MHA work in progress',expected=6402,source=source,tests=hashes(tests)),indent=2)+'\n')
shutil.copy2(old/'fixture-server.mjs',r/'fixture-server.mjs')
for name in ['run.mjs','worker.mjs','index.html']:
    (chrome/name).write_text((old/'proof/chrome-contracts'/name).read_text().replace('torch-iteration-51','torch-iteration-52'))
s=(old/'proof/wasm-contracts.mjs').read_text().replace('torch-iteration-51','torch-iteration-52').replace("'attention_efficiency'","'attention_efficiency','multihead_attention'").replace('6184','6402')
(p/'wasm-contracts.mjs').write_text(s)
print(dict(resources=len(source),suites=49,contracts=6402))
