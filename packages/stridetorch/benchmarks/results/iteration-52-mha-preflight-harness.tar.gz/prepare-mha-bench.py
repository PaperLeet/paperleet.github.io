from pathlib import Path
import hashlib
import json
import shutil

r=Path(__file__).resolve().parent;p=r/'proof';c=p/'chrome-contracts'
bench=Path('/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/benchmarks/bench_multihead.py')
shutil.copy2(bench,c/'bench_multihead.py')
plan=json.loads((c/'plan.json').read_text());plan['benchmark_sha256']=hashlib.sha256(bench.read_bytes()).hexdigest()
(c/'bench-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
s=(c/'worker.mjs').read_text().replace("fetch('./plan.json')","fetch('./bench-plan.json')")
s=s.replace("py.globals.set('plan_json'", "py.FS.writeFile('/runtime/bench_multihead.py',await(await fetch('./bench_multihead.py')).text());\n py.globals.set('plan_json'")
start=s.index('import pytest,stridetorch,numpy')
end=s.index('`));',start)
s=s[:start]+'''import stridetorch,numpy
assert hashlib.sha256(pathlib.Path('/runtime/bench_multihead.py').read_bytes()).hexdigest()==plan['benchmark_sha256']
from bench_multihead import run
result=run()
json.dumps(dict(status='success',library=stridetorch.__version__,numpy=numpy.__version__,source_hashes=actual,benchmark_sha256=plan['benchmark_sha256'],benchmark=result))
'''+s[end:]
(c/'bench-worker.mjs').write_text(s)
s=(c/'run.mjs').read_text().replace("'./worker.mjs'","'./bench-worker.mjs'").replace("'result.json'","'bench-result.json'").replace("['run.mjs','worker.mjs','plan.json']","['bench-run.mjs','bench-worker.mjs','bench-plan.json']").replace("},120000)","},300000)")
(c/'bench-run.mjs').write_text(s)
s=(p/'wasm-contracts.mjs').read_text()
s=s.replace("const suites=", "py.FS.writeFile('/runtime/bench_multihead.py',fs.readFileSync(new URL('chrome-contracts/bench_multihead.py',import.meta.url),'utf8'));\nconst suites=")
start=s.index('import pytest,stridetorch,numpy');end=s.index('`));',start)
s=s[:start]+'''import stridetorch,numpy
from bench_multihead import run
result=run()
json.dumps(dict(status='success',library=stridetorch.__version__,numpy=numpy.__version__,source_hashes=actual,benchmark=result))
'''+s[end:]
s=s.replace("'source-wasm.json'","'bench-node-result.json'")
(p/'bench-node.mjs').write_text(s)
print('Prepared source-identified MHA benchmark in Node and actual Chrome')
