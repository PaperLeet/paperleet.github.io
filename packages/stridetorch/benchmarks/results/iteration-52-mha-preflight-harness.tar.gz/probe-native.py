from pathlib import Path
import contextlib,inspect,json,warnings
import torch
from torch.nn.attention import sdpa_kernel,SDPBackend
torch.set_num_threads(2);rows=[]
def record(name,fn):
 try:
  result=fn();rows.append(dict(name=name,status='success',result=result))
 except Exception as error:rows.append(dict(name=name,status=type(error).__name__,error=str(error)[:500]))
def array(x):
 if x is None:return None
 return dict(shape=list(x.shape),stride=list(x.stride()),finite=bool(x.isfinite().all()),nan=int(x.isnan().sum()),zero=bool((x==0).all()),requires_grad=x.requires_grad)
record('signatures',lambda:dict(module=str(inspect.signature(torch.nn.MultiheadAttention)),forward=str(inspect.signature(torch.nn.MultiheadAttention.forward)),functional=str(inspect.signature(torch.nn.functional.multi_head_attention_forward))))
for options in [dict(),dict(bias=False),dict(kdim=6,vdim=4),dict(add_bias_kv=True,add_zero_attn=True)]:
 def state(options=options):
  t=torch.nn.MultiheadAttention(8,2,dtype=torch.float64,**options)
  return dict(parameters=list(t._parameters),state={k:list(v.shape) for k,v in t.state_dict().items()},attributes={k:getattr(t,k) for k in ['embed_dim','kdim','vdim','_qkv_same_embed_dim','num_heads','dropout','batch_first','head_dim','add_zero_attn']},repr=repr(t),outtype=type(t.out_proj).__name__)
 record('state-'+str(options),state)
for fast in [False,True]:
 for need in [False,True]:
  for causal in [False,True]:
   for masked in [False,True]:
    def call(fast=fast,need=need,causal=causal,masked=masked):
     old=torch.backends.mha.get_fastpath_enabled();torch.backends.mha.set_fastpath_enabled(fast)
     try:
      m=torch.nn.MultiheadAttention(8,2,batch_first=True,dtype=torch.float64).eval();x=torch.randn(2,3,8,dtype=torch.float64)
      with torch.no_grad(),sdpa_kernel(SDPBackend.MATH):
       y,w=m(x,x,x,need_weights=need,is_causal=causal,key_padding_mask=torch.ones(2,3,dtype=torch.bool) if masked else None)
      return dict(output=array(y),weights=array(w))
     finally:torch.backends.mha.set_fastpath_enabled(old)
    record(f'fast{fast}-need{need}-causal{causal}-masked{masked}',call)
for batch in [False,True]:
 for need in [False,True]:
  def jvp(batch=batch,need=need):
   m=torch.nn.MultiheadAttention(8,2,batch_first=batch,dtype=torch.float64);x=torch.randn((2,3,8) if batch else (3,2,8),dtype=torch.float64,requires_grad=True)
   with sdpa_kernel(SDPBackend.MATH):
    p,t=torch.func.jvp(lambda q:m(q,q,q,need_weights=need),(x,),(torch.ones_like(x),))
   return dict(p=[array(v) for v in p],t=[array(v) for v in t])
  record(f'jvp-batch{batch}-need{need}',jvp)
for value in [0,-1,2.5,True]:record('embed-'+str(value),lambda value=value:repr(torch.nn.MultiheadAttention(value,1)))
for value in [0,-1,3,2.5,True]:record('heads-'+str(value),lambda value=value:repr(torch.nn.MultiheadAttention(8,value)))
for p in [-.1,1.1,float('nan')]:record('dropout-'+str(p),lambda p=p:repr(torch.nn.MultiheadAttention(8,2,dropout=p)))
for length in [0,1]:
 def empty(length=length):
  m=torch.nn.MultiheadAttention(4,2,dtype=torch.float64);q=torch.ones(3,1,4,dtype=torch.float64,requires_grad=True);k=torch.ones(length,1,4,dtype=torch.float64,requires_grad=True)
  result={}
  for need in [False,True]:
   y,w=m(q,k,k,need_weights=need);g=torch.autograd.grad(y.sum(),[q,k],retain_graph=True);result[str(need)]=dict(y=array(y),weights=array(w),grads=[array(v) for v in g])
  return result
 record('source-length-'+str(length),empty)
out=dict(native=torch.__version__,rows=rows)
Path(__file__).with_name('native-probe.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
for row in rows:print(row['name'],row['status'],row.get('error',''))
