import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const repo='/Users/david/Developer/PaperLeet-torch-release';
const source="/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-52/proof/source";
const py=await loadPyodide({indexURL:path.join(repo,'web/node_modules/pyodide/'),packageCacheDir:path.join(repo,'web/public/browser-runtime/pyodide-0.29.4/'),stdout:console.log,stderr:console.error});
await loadJudgePackages(py,[]);py.FS.mkdirTree('/runtime/stridetorch');
const hashes={};
for(const name of fs.readdirSync(source).filter(name=>name.endsWith('.py')||['LICENSE','NOTICE'].includes(name))){
 const bytes=fs.readFileSync(path.join(source,name));
 py.FS.writeFile('/runtime/stridetorch/'+name,bytes);
 hashes[name]=crypto.createHash('sha256').update(bytes).digest('hex');
}
py.FS.writeFile('/runtime/bench_multihead.py',fs.readFileSync(new URL('chrome-contracts/bench_multihead.py',import.meta.url),'utf8'));
const suites=['module_lifecycle','optimizer_lifecycle','conversion_modes','scheduler_lifecycle','nn_workflows','attention','attention_efficiency','multihead_attention','module_hooks','graph_lifecycle','tensor_hooks','numpy_inputs','construction','promotion','arithmetic','ieee','linear_wasm','batchnorm','groupnorm','instancenorm','classification','convolution','convolution_padding','transpose_convolution','layout','shape_ops','statistics','dispatch','mean','nan_reductions','joint_vjp','indexing','gradient_layout','axis_transforms','solve','serialization','triangular','cholesky','cholesky_solve','cholesky_inverse','linalg_failures','feature_detection','pooling','average_pooling','average_pooling_plans','average_pooling_1d','pooling_1d','pooling_3d','average_pooling_3d'];
for(const name of suites)py.FS.writeFile('/runtime/test_'+name+'.py',fs.readFileSync(path.join("/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-52/proof/chrome-contracts/tests",'test_'+name+'.py'),'utf8'));
py.globals.set('expected_hashes',JSON.stringify(hashes));py.globals.set('test_paths',suites.map(name=>'/runtime/test_'+name+'.py').join('|'));
const result=JSON.parse(py.runPython(`
import sys,json,pathlib,hashlib
sys.path.insert(0,'/runtime')
actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path('/runtime/stridetorch').iterdir() if p.is_file()}
assert actual==json.loads(expected_hashes)
import stridetorch,numpy
from bench_multihead import run
result=run()
json.dumps(dict(status='success',library=stridetorch.__version__,numpy=numpy.__version__,source_hashes=actual,benchmark=result))
`));
assert.equal(result.numpy,'2.2.5');fs.writeFileSync(new URL('bench-node-result.json',import.meta.url),JSON.stringify(result,null,2));
console.log('PASS actual Pyodide',py.version,result.library,result.passed,'contracts and source hashes');
