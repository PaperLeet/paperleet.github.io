from pathlib import Path
import hashlib,json,os,subprocess,time,traceback
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
plan=read(r/'execution-plan.json');context=read(r/'merge-receipt.json');receipts=[]
node=Path('/Users/david/.local/share/fnm/node-versions/v22.22.1/installation/bin/node');python=b/'torch-iteration-82/application-env/bin/python'
env=dict(os.environ,PYTHON=str(python),PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0',PYTHONPATH=os.pathsep.join([str(repo/'packages/stridetorch/src'),str(repo)]),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');env['PATH']=str(node.parent)+':/opt/homebrew/bin:'+str(python.parent)+':'+env['PATH']
def verify():
 assert subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'],cwd=repo,text=True).strip()==context['head']
 for name,h in plan['files'].items():assert sha(r/name)==h,name
 for name,h in plan['static_inputs'].items():assert sha(repo/name)==h,name
 for name,h in read(b/'torch-iteration-462/live-export-sha256.json').items():assert sha(repo/'web/public/data'/name)==h,name
 for name,h in read(b/'torch-iteration-463/source-plan.json')['inputs'].items():assert sha(Path(name))==h,name

def run(label,command,cwd=repo,extra=None):
 verify();started=time.time()
 with (r/(label+'.log')).open('w') as output:
  child=subprocess.Popen(list(map(str,command)),cwd=cwd,env={**env,**(extra or {})},stdout=output,stderr=subprocess.STDOUT);write(r/'progress.json',dict(status='running',supervisor_pid=os.getpid(),pid=child.pid,label=label,receipts=receipts));code=child.wait()
 receipt=dict(label=label,exit_code=code,seconds=time.time()-started,command=list(map(str,command)),cwd=str(cwd),log_sha256=sha(r/(label+'.log')));receipts.append(receipt);write(r/'receipts.json',receipts);print(json.dumps(receipt),flush=True);assert code==0,(label,(r/(label+'.log')).read_text()[-1800:]);verify()
try:
 run('inbox-notification-filters',[node,'scripts/check-inbox-notification-filters.mjs'],repo/'web')
 run('inbox',[node,'scripts/check-inbox.mjs'],repo/'web')
 run('inbox-reading',[node,'scripts/check-inbox-reading.mjs'],repo/'web')
 run('review-notifications',[node,'scripts/check-review-notifications.mjs'],repo/'web')
 run('moderation-user-messages',[node,'scripts/check-moderation-user-messages.mjs'],repo/'web')
 run('admin-inbox',[node,'scripts/check-admin-inbox.mjs'],repo/'web')
 run('build',['npm','run','build'],repo/'web',dict(VITE_PATH_ROUTING='0'))
 value=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED','--jq','.value'],cwd=repo,text=True).strip();assert value in ['0','1']
 profile=dict(VITE_PATH_ROUTING='1',PAPERLEET_MAIN_SITE_ENABLED=value,VITE_PUBLIC_SITE='0' if value=='1' else '1',VITE_APP_EDITION='hosted' if value=='1' else 'local',VITE_API_ORIGIN='https://app.paperleet.com' if value=='1' else '',VITE_HOSTED_APP_AVAILABLE='1',VITE_HOSTED_APP_URL='https://app.paperleet.com');write(r/'current-pages-profile.json',profile)
 run('pages-profile-build',['npm','run','build'],repo/'web',profile)
 run('pages-assets',[python,'-B','web/scripts/check-pages-assets.py'])
 run('retain-production-assets-check',[python,'-B','web/scripts/retain-pages-assets.py','web/dist','--check'])
 run('generated-worker',[node,r/'verify-generated-worker.mjs'])
 run('nested-wasm',[node,r/'check-nested-wasm.mjs'])
 result=dict(status='passed_current_frontend_followup_with_unchanged_qualified_082_runtime',head=context['head'],version='0.82.0',previous_frontend_qualification_sha256=sha(b/'torch-iteration-470/result.json'),receipts=receipts,base_full_catalog_stage=462,base_completed_checks=read(b/'torch-iteration-462/progress.json')['receipts'][:-1],base_remaining_checks=read(b/'torch-iteration-467/progress.json')['receipts'][:-1],first_real_worker_success_sha256=sha(b/'torch-iteration-468/nested-wasm-result.json'),current_real_worker_sha256=sha(r/'nested-wasm-result.json'),cpu_result_sha256=sha(b/'torch-iteration-460/result.json'),cpu_equivalence_sha256=sha(b/'torch-iteration-462/cpu-source-equivalence.json'),package_result_sha256=sha(b/'torch-iteration-463/result.json'),source_hashes=read(b/'torch-iteration-462/source-hashes.json'),live_exports=read(b/'torch-iteration-462/live-export-sha256.json'),preserved_original_failures=[str(b/'torch-iteration-462/progress.json'),str(b/'torch-iteration-467/progress.json')],main_updated=False,ci_triggered=False,published=False,goal_status='active')
 write(r/'result.json',result);write(r/'progress.json',dict(status='completed',receipts=receipts));print(json.dumps(dict(status=result['status'],head=result['head'])),flush=True)
except BaseException as error:write(r/'progress.json',dict(status='failed',error=str(error),traceback=traceback.format_exc(),receipts=receipts));raise
