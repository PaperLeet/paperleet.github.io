from pathlib import Path
import hashlib,json,os,subprocess,time,traceback,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
plan=json.loads((r/'plan.json').read_text());results=[]
def verify():
 assert sha(Path(__file__))==plan['runner_sha256']
 for name,h in plan['inputs'].items():assert sha(Path(name))==h,name
try:
 for job in plan['jobs']:
  verify();env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONPATH=str(repo)+os.pathsep+str(repo/'packages/stridetorch/src'),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
  for name in ['PYTHONTRACEMALLOC','PYTHONPROFILEIMPORTTIME']:env.pop(name,None)
  probe="import json,stridetorch,paperleet._vendor.torch as private;print(json.dumps(dict(public=stridetorch.__file__,private=private.__file__,version=stridetorch.__version__)))"
  imports=json.loads(subprocess.check_output([job['python'],'-B','-c',probe],env=env,cwd=r,text=True));assert imports['version']=='0.82.0' and Path(imports['public']).is_relative_to(repo) and Path(imports['private']).is_relative_to(repo),imports
  label=job['label'];log=r/(label+'.log');assert not log.exists();xml=r/(label+'.xml');temporary=r/(label+'-tmp')
  args=[job['python'],'-B','-m','pytest',*job['paths'],'-q','-p','no:cacheprovider','--basetemp='+str(temporary),'--junitxml='+str(xml)]
  started=time.time()
  with log.open('w') as output:
   child=subprocess.Popen(args,cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT);write(r/'progress.json',dict(status='running',pid=os.getpid(),child_pid=child.pid,label=label,command=args,results=results));code=child.wait()
  suites=list(ET.parse(xml).getroot().iter('testsuite'));totals={k:sum(int(x.attrib.get(k,0)) for x in suites) for k in ['tests','failures','errors','skipped']}
  receipt=dict(label=label,exit_code=code,seconds=time.time()-started,totals=totals,imports=imports,xml_sha256=sha(xml),log_sha256=sha(log));results.append(receipt);verify();print(json.dumps(receipt),flush=True);write(r/'progress.json',dict(status='running',results=results));assert code==0,receipt
 write(r/'result.json',dict(status='passed_canonical_082_sdk_and_application_cpu',results=results,version='0.82.0',main_updated=False,ci_triggered=False,goal_status='active'));write(r/'progress.json',dict(status='completed',results=results))
except BaseException as error:write(r/'progress.json',dict(status='failed',results=results,error=str(error),traceback=traceback.format_exc()));raise
