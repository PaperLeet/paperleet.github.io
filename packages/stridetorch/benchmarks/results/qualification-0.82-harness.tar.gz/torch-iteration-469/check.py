import sys,json,numpy as np
sys.path.insert(0,'/candidate');sys.path.insert(0,'/oracle')
import stridetorch
from cases import packed,unpacked
assert stridetorch.__version__=='0.82.0'
def execute(api,dtypes,kind,order,foreach):
 params=[];grads=[]
 for i,dtype in enumerate(dtypes):
  raw=np.array([3.+i,-4.-i],dtype=dtype)
  if np.dtype(dtype).kind=='c':raw=raw+np.asarray([2j,-1j],dtype=dtype)
  g=api.from_numpy(raw);p=api.zeros(g.shape,dtype=getattr(api,dtype));p.grad=g;params.append(p);grads.append(g)
 versions=[g._version for g in grads]
 if kind=='norm':value=api.nn.utils.clip_grad_norm_((p for p in params),1.25,norm_type=order,foreach=foreach)
 else:value=api.nn.utils.clip_grad_value_((p for p in params),1.25,foreach=foreach)
 assert all(p.grad is g for p,g in zip(params,grads)) and api.is_grad_enabled()
 return dict(value=None if value is None else packed(value),gradients=[packed(g) for g in grads],versions=[g._version-v for g,v in zip(grads,versions)])


reference=json.load(open('/oracle/reference.json'));rows=[];failures=[]
for row in reference['rows']:
 actual=execute(stridetorch.torch,**row['case']);expected=row['expected'];issues=[]
 if actual['versions']!=expected['versions']:issues.append('versions')
 for key in ['value','gradients']:
  aa=[actual[key]] if key=='value' else actual[key];ee=[expected[key]] if key=='value' else expected[key]
  for a,e in zip(aa,ee):
   if a is None or e is None:
    if (a is None)!=(e is None):issues.append(key+'_none')
    continue
   x,y=unpacked(a),unpacked(e)
   if x.shape!=y.shape or x.dtype!=y.dtype:issues.append(key+'_metadata');continue
   tol=4e-3 if x.dtype==np.dtype('float16') else 6e-6 if x.dtype in [np.dtype('float32'),np.dtype('complex64')] else 4e-12
   try:np.testing.assert_allclose(x,y,rtol=tol,atol=3e-5 if x.dtype==np.dtype('float16') else 1e-7 if tol==6e-6 else 1e-12,equal_nan=True)
   except AssertionError:issues.append(key+'_values')
 result=dict(case=row['case'],actual=actual,issues=issues);rows.append(result)
 if issues:failures.append(result)
report=dict(status='passed' if not failures else 'needs_repair',cases=len(rows),failures=failures,rows=rows,numpy=np.__version__,version=stridetorch.__version__,native_reference=reference['native_torch'])
assert len(rows)==84
