"""Independent gradient-clipping scenarios shared by native and CPU/WASM probes."""
import base64
import itertools
import numpy as np


def specs():
    rows=[]
    for dtype,order,foreach in itertools.product(['float16','float32','float64','complex64','complex128'],[0.,.5,1.,1.5,2.,2.9,-1.,'inf','-inf','nan'],[None,False,True]):
        rows.append(dict(kind='norm',dtype=dtype,order=order,foreach=foreach,layout='mixed_shapes',bound=2.,grad_mode=True))
    for dtype,foreach,layout in itertools.product(['float32','float64'],[None,False,True],['single','generator','strided','duplicate_parameter','shared_gradient','overlapping_views','none_gradient','empty','all_none','zero','empty_gradient','scalar','leaf_gradient','history_gradient']):
        for kind in ['norm','value']:
            rows.append(dict(kind=kind,dtype=dtype,order=2.,foreach=foreach,layout=layout,bound=1.5,grad_mode=False))
    for dtype,kind,foreach,bound in itertools.product(['float16','float32','float64'],['norm','value'],[None,False,True],[0.,-1.,'inf','-inf','nan','huge']):
        rows.append(dict(kind=kind,dtype=dtype,order=2.,foreach=foreach,layout='nonfinite',bound=bound,grad_mode=True))
    for dtype,foreach in itertools.product(['complex64','int64','bool'],[None,False,True]):
        for kind in ['norm','value']:
            rows.append(dict(kind=kind,dtype=dtype,order=2.,foreach=foreach,layout='single',bound=1.5,grad_mode=True))
    for dtype,foreach,layout in itertools.product(['float32','float64'],[None,False,True],['nan_gradient','inf_gradient','zero','empty','all_none']):
        rows.append(dict(kind='norm',dtype=dtype,order=2.,foreach=foreach,layout=layout,bound=2.,grad_mode=True,error_if_nonfinite=True))
    for kind in ['norm','value']:
        for layout in ['generator','empty']:
            rows.append(dict(kind=kind,dtype='float32',order=2.,foreach=None,layout=layout,bound='invalid',grad_mode=False))
    for index,row in enumerate(rows):row['key']=str(index)+'/'+row['kind']+'/'+row['dtype']+'/'+str(row['order'])+'/'+str(row['foreach'])+'/'+row['layout']+'/'+str(row['bound'])
    return rows


def packed(tensor):
    a=tensor.detach().cpu().numpy().copy()
    return dict(dtype=a.dtype.str,shape=list(a.shape),bytes=base64.b64encode(a.tobytes()).decode())


def unpacked(value):
    return np.frombuffer(base64.b64decode(value['bytes']),dtype=value['dtype']).reshape(value['shape'])


def number(value):
    return {'inf':float('inf'),'-inf':-float('inf'),'nan':float('nan'),'huge':1e100,'invalid':'not-a-number'}.get(value,value) if isinstance(value,str) else value


def exercise(torch,spec):
    dtype=np.dtype(spec['dtype']);layout=spec['layout'];events=[];roots=[]
    def tensor(a):
        a=np.asarray(a,dtype=dtype);roots.append(a)
        return torch.from_numpy(a)
    if layout=='mixed_shapes':
        grads=[tensor([[3.,-4.,0.],[1.,-2.,.5]]),tensor([6.,-8.]),tensor(2.)]
        if dtype.kind=='c':grads[0]=tensor([[3+4j,-4+3j,0],[1-2j,-2+1j,.5j]])
    elif layout=='strided':
        root=np.arange(24,dtype=dtype).reshape(4,6)-10;roots.append(root);grads=[torch.from_numpy(root[::2,1::2])]
    elif layout=='overlapping_views':
        root=torch.from_numpy(np.arange(6,dtype=dtype)-3);grads=[root[:4],root[2:]]
    elif layout=='nonfinite':grads=[tensor([0.,-0.,float('nan'),float('inf'),-float('inf'),3.,-4.])]
    elif layout=='nan_gradient':grads=[tensor([float('nan'),1.]),tensor([2.,3.])]
    elif layout=='inf_gradient':grads=[tensor([float('inf'),1.]),tensor([2.,3.])]
    elif layout=='zero':grads=[tensor([0.,-0.]),tensor([0.,0.])]
    elif layout=='empty_gradient':grads=[tensor(np.empty((0,3))) ,tensor([3.,4.])]
    elif layout=='scalar':grads=[tensor(-3.)]
    elif layout=='empty':grads=[]
    else:grads=[tensor([6.,-8.])]
    if layout in ['leaf_gradient','history_gradient']:
        grads[0].requires_grad_()
        if layout=='history_gradient':grads[0]=grads[0]*2
    if layout=='shared_gradient':grads.append(grads[0])
    params=[]
    for g in grads:
        p=torch.zeros(g.shape,dtype=getattr(torch,spec['dtype']));p.grad=g;params.append(p)
    if layout=='duplicate_parameter':params.append(params[0])
    if layout=='none_gradient':params.append(torch.zeros(2,dtype=getattr(torch,spec['dtype'])))
    if layout=='all_none':
        params=[torch.zeros(2,dtype=getattr(torch,spec['dtype']))];grads=[]
    before=[packed(g) for g in grads];versions=[g._version for g in grads]
    pointers=[p.grad for p in params]
    def generated():
        for i,p in enumerate(params):events.append('yield:'+str(i));yield p
        events.append('exhausted')
    arguments=params[0] if layout=='single' else generated() if layout=='generator' else params
    error=None;value=None
    with torch.set_grad_enabled(spec['grad_mode']):
        try:
            if spec['kind']=='norm':value=torch.nn.utils.clip_grad_norm_(arguments,number(spec['bound']),number(spec['order']),error_if_nonfinite=spec.get('error_if_nonfinite',False),foreach=spec['foreach'])
            else:value=torch.nn.utils.clip_grad_value_(arguments,number(spec['bound']),foreach=spec['foreach'])
        except Exception as exc:error=dict(type=type(exc).__name__,message=str(exc))
        mode_restored=torch.is_grad_enabled()==spec['grad_mode']
    return dict(spec=spec,error=error,value=None if value is None else packed(value),result_detached=value is None or not value.requires_grad,before=before,gradients=[packed(g) for g in grads],gradient_requires_grad=[g.requires_grad for g in grads],version_deltas=[g._version-v for g,v in zip(grads,versions)],identities_preserved=all(p.grad is g for p,g in zip(params,pointers)),mode_restored=mode_restored,events=events)
