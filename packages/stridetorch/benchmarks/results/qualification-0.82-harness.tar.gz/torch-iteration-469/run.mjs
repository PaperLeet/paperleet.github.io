import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
const root=new URL('./',import.meta.url),hash=x=>createHash('sha256').update(x).digest('hex');
const plan=JSON.parse(fs.readFileSync(new URL('source-plan.json',root)));
for(const [name,h] of Object.entries(plan.files))assert.equal(hash(fs.readFileSync(new URL(name,root))),h,name);
const py=await loadPyodide({indexURL:decodeURIComponent(new URL('../torch-iteration-76/runtime/',root).pathname)});await py.loadPackage('numpy');py.runPython('import sys;sys.dont_write_bytecode=True');
for(const name of Object.keys(plan.files))if(name.startsWith('candidate/')||name.startsWith('oracle/')){py.FS.mkdirTree('/'+name.split('/').slice(0,-1).join('/'));py.FS.writeFile('/'+name,fs.readFileSync(new URL(name,root)));}
const report=JSON.parse(py.runPython("exec(compile("+JSON.stringify(fs.readFileSync(new URL('check.py',root),'utf8'))+",'/check.py','exec'));json.dumps(report)"));
fs.writeFileSync(new URL('result.json',root),JSON.stringify({...report,pyodide:py.version,node:process.version},null,2)+'\n');assert.equal(report.status,'passed');console.log(JSON.stringify({status:report.status,cases:report.cases,numpy:report.numpy,version:report.version}));
