from pathlib import Path
import hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
assert not (r/'qualification-0.82-harness.tar.gz').exists()
current=read(b/'torch-iteration-471/result.json');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert current['head']==head
cpu=read(b/'torch-iteration-460/result.json');assert cpu['totals']==dict(tests=45933,failures=0,errors=0,skipped=1) and cpu['exit_code']==0
resources=read(b/'torch-iteration-462/source-hashes.json');assert len(resources)==66
for name,h in resources.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==h,name
for name,h in read(b/'torch-iteration-471/execution-plan.json')['static_inputs'].items():assert sha(repo/name)==h,name
package=read(b/'torch-iteration-463/result.json');assert package['resources']==66 and len(package['artifacts'])==6
for name,h in read(b/'torch-iteration-463/source-plan.json')['inputs'].items():assert sha(Path(name))==h,name
exports=read(b/'torch-iteration-462/live-export-sha256.json');assert len(exports)==183
for name,h in exports.items():assert sha(repo/'web/public/data'/name)==h,name
identity=read(b/'torch-iteration-462/export-identity.json');assert identity['preserved_assets']==16227 and identity['new_assets']==180 and identity['all_new_assets_reachable']
for name,h in read(b/'torch-iteration-462/immutable-assets.json').items():assert sha(repo/name)==h,name
native=read(b/'torch-iteration-462/native-catalog-result.json');assert native['passed'] and native['problems']==89 and native['tests_executed']==12360
wasm=read(b/'torch-iteration-462/full-wasm-result.json');assert wasm['passed'] and wasm['modules']==89 and not wasm['browser_budget_exceeded'];assert sum(v['mutants'] for v in wasm['results'])==406
for stage,expected_status in [(462,'failed'),(467,'failed')]:assert read(b/f'torch-iteration-{stage}/progress.json')['status']==expected_status
completed=read(b/'torch-iteration-462/receipts.json')[:-1]+read(b/'torch-iteration-467/receipts.json')[:-1]+read(b/'torch-iteration-470/receipts.json')+current['receipts']
assert all(v['exit_code']==0 for v in completed)
assert any(v['label']=='full-frontend-check' for v in completed)
worker=read(b/'torch-iteration-471/nested-wasm-result.json');assert worker['status']=='passed' and not worker['page_errors'] and worker['feedback']=='Tests passed\n7 / 7 tests passed'
for n,name in [(466,'numpy25.json'),(466,'numpy126.json'),(469,'result.json')]:
 x=read(b/f'torch-iteration-{n}'/name);assert x['status']=='passed' and x['cases']==84 and not x['failures']
# Staged current packaging inputs and current generated worker are preserved for replay.
files=[]
for name,h in read(b/'torch-iteration-463/source-plan.json')['inputs'].items():
 p=Path(name);target=r/'canonical'/p.relative_to(repo);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);files.append(target)
for name,h in exports.items():
 target=r/'exports'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/'web/public/data'/name,target);files.append(target)
worker_proof=read(b/'torch-iteration-471/generated-worker-proof.json')
for name in [worker_proof['generated_module'],worker_proof['asset']]:
 target=r/'generated'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/name,target);files.append(target)
for stage in [450,451,456,457,458,459,460,462,463,466,467,468,469,470,471]:
 folder=b/f'torch-iteration-{stage}'
 files.extend(p for p in folder.iterdir() if p.is_file() and p.suffix not in ['.gz','.zst'])
 if stage==462:files.extend(p for p in (folder/'native-references').rglob('*') if p.is_file())
 if stage==463:
  for item in package['artifacts']:
   p=folder/item['path'];assert sha(p)==item['sha256'];files.append(p)
 if stage==469:files.extend(p for p in (folder/'oracle').rglob('*') if p.is_file())
summary=dict(status='qualified_082_runtime_application_catalog_and_browser_with_scoped_main_merges',version='0.82.0',qualified_application_head=head,cpu_head=cpu['head'],runtime_resources=resources,cpu=dict(passed=45932,skipped=cpu['skips'],errors=0,failures=0),native_sdk=dict(numpy25_passed=12298,numpy126_passed=12295,numpy126_existing_skips=3),wasm_sdk=dict(node_passed=12285,chrome_worker_passed=12285,failed=0,skipped=0,pyodide='0.29.4',numpy='2.2.5',isolated_version_literal='0.81.0',version_only_difference_from_canonical=True,canonical_082_confirmed_in_actual_generated_worker=True),clipping_native26_oracle_cases=478,mixed_precision_clipping_cases_per_environment=84,secondary_native214=dict(all_checks_match=475,error_class_differences=3,numerical_or_mutation_mismatches=0,pinned_contract='Torch2.6'),catalog=dict(modules=89,native_repeats=3,native_test_records=12360,wasm_modules=89,wasm_mutants=406,browser_budget_exceeded=[]),packaging=dict(artifacts=package['artifacts'],resources=66,coinstall_both_numpy_environments=True,current_application_bytes_verified=True),exports=dict(active_identities=183,new_assets=180,previous_assets_preserved=16227,all_new_assets_reachable=True,hashes=exports),completed_application_receipts=completed,source_equivalence=read(b/'torch-iteration-462/cpu-source-equivalence.json'),frontend_followups=[read(b/f'torch-iteration-{n}/merge-receipt.json') for n in [470,471]],actual_generated_worker=dict(status=worker['status'],browser=worker['browser'],feedback=worker['feedback'],page_errors=worker['page_errors'],result_sha256=sha(b/'torch-iteration-471/nested-wasm-result.json')),failed_invocations_preserved=[dict(stage=451,reason='pytest tests problems has721unimplementedworkspaceexerciseerrors;allrootapptestspassed;normalfullcomposite460passed'),dict(stage=462,reason='customcasesdriverwrongcwd;previouscompletedCPU/catalog/export/WASM/fullfrontendchecksretained;467correctcwdpassed'),dict(stage=467,reason='virtualizededitoroffscreenDOMwaitbeforeWorker;468endmarkersucceededandverifiesexactruntimebytes'),dict(stage=450,reason='minimumenvironmentprivateinstallprecondition;451properpublicSDKpassed'),dict(stage=452,reason='stagedgeneratedegg-infomanifest;453correctedstagingand463currentpackagespassed')],development_evidence='gradient-utilities-0.82-development.json',terminal_hvp_optimization_adopted=False,operand_retention_candidate_adopted=False,production_webgpu_enabled=False,new_latency_speedup_claimed=False,main_adopted=False,ci_triggered=False,tags_pushed=False,published=False,deployed=False,goal_status='active')
write(r/'qualification.json',summary)
write(r/'replay-dependencies.json',dict(external=['Gitqualifiedheadandcommitsforfullapplication/test/problem/browserinputs;staticinputhashesretained','Developmentarchivegradient-utilities-0.82-development-harness.tar.gzcontainsfullSDKandindependent478oracle','Python3.12NumPy2.5.4Torch2.14.1','Python3.10NumPy1.26.4Torch2.6.0','Node22.22.1Chrome155.0.8059.82','Pyodide0.29.4Python3.13.2NumPy2.2.5andpytestwheels;runtime76notbundled','thinbackup457dependsrecordedimmutableGitobjects;recoveryarchivesnotduplicatedhere'],notes=['Adaptabsoluteenvironmentpathsforreplay','Failedinvocationsarekeptandnotrewrittenaspasses','NoisolatedexperimentadoptedfromHVPormemory/GPUplans','Currentpackagestaginginputsandsixbuildartifactsincluded;postqualificationdeltaonlyproofdocsandhash-verifiedderivedexports']))
files.extend([r/'aggregate.py',r/'qualification.json',r/'replay-dependencies.json']);files=sorted(set(files));assert all('__pycache__' not in p.parts for p in files)
manifest={str(p.relative_to(b)):sha(p) for p in files};seen={};target=r/'qualification-0.82-harness.tar.gz'
with tarfile.open(target,'w:gz') as archive:
 for p in files:
  name=str(p.relative_to(b));h=manifest[name]
  if h in seen:
   info=archive.gettarinfo(str(p),arcname=name);info.type=tarfile.LNKTYPE;info.linkname=seen[h];info.size=0;archive.addfile(info)
  else:archive.add(p,arcname=name,recursive=False);seen[h]=name
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256.json');info.size=len(data);archive.addfile(info,io.BytesIO(data))
with tarfile.open(target) as archive:
 for name,h in manifest.items():assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==h,name
receipt=dict(path='packages/stridetorch/benchmarks/results/'+target.name,files=len(files),unique_payloads=len(seen),bytes=target.stat().st_size,sha256=sha(target),all_payloads_verified=True);write(r/'archive-receipt.json',receipt)
summary['raw_archive']=receipt
out=repo/'packages/stridetorch/benchmarks/results';assert not (out/'qualification-0.82.json').exists();write(out/'qualification-0.82.json',summary);shutil.copy2(target,out/target.name)
print(json.dumps(receipt))
