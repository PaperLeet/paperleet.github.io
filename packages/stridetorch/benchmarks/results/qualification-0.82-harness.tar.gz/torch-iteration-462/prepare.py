from pathlib import Path
import copy,hashlib,json,subprocess,tomllib
b=Path(__file__).resolve().parent.parent;r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
merge=read(r/'merge-receipt.json');cpu=read(b/'torch-iteration-460/result.json');cpu_plan=read(b/'torch-iteration-460/plan.json')
assert cpu['status']=='passed_full_application_cpu' and cpu['head']==merge['cpu_qualified_head'] and cpu['totals']==dict(tests=45933,failures=0,errors=0,skipped=1)
head=subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head==merge['merged_head']
differences=[name for name,h in cpu_plan['inputs'].items() if sha(repo/name)!=h];assert differences==['pyproject.toml'],differences
old=tomllib.loads(subprocess.check_output(['/usr/bin/git','show',cpu['head']+':pyproject.toml'],cwd=repo,text=True));current=tomllib.loads((repo/'pyproject.toml').read_text());normalized=copy.deepcopy(current);normalized['tool']['setuptools']['package-data']['paperleet'].remove('daily_challenges.json');assert normalized==old
backend_delta=subprocess.check_output(['/usr/bin/git','diff','--name-only',cpu['head'],head,'--','paperleet','tests','problems','packages/stridetorch','pyproject.toml'],cwd=repo,text=True).splitlines();assert set(backend_delta)=={'paperleet/daily_challenges.py','paperleet/daily_challenges.json','pyproject.toml'}
write(r/'cpu-source-equivalence.json',dict(status='qualified_computation_and_existing_application_sources_unchanged',cpu_head=cpu['head'],merged_head=head,unchanged_previously_checked_files=len(cpu_plan['inputs'])-1,changed_metadata='Onlydaily_challenges.jsonaddedtoprivatepackage-data',new_backend_files=['paperleet/daily_challenges.py','paperleet/daily_challenges.json'],new_backend_coverage=['463installedcalendarsmokeandexactwheelbytesbothNumPys','462merged-app-imports12cases','462full-frontend-checkincludesdailychallengecontract'],no_old_tests_removed=True))
package=read(b/'torch-iteration-463/result.json');assert package['status']=='passed_current_public_private_package_rebuilds_and_installed_smoke' and package['head']==head and package['resources']==66
s=(b/'torch-iteration-365/run.py').read_text().replace('0.81.0','0.82.0').replace('resources=65','resources=66').replace("application=b/'torch-iteration-361'","application=b/'torch-iteration-460'").replace("cpu['head']==context['head']","cpu['head']==context['cpu_head']").replace("cpu['totals']['tests']>=45855","cpu['totals']['tests']==45933").replace("b/'torch-iteration-364/receipt.json'","b/'torch-iteration-457/receipt.json'")
needle=" run('native-catalog'";pos=s.index(needle)
prelude=""" assert read(r/'cpu-source-equivalence.json')['status']=='qualified_computation_and_existing_application_sources_unchanged'
 assert read(b/'torch-iteration-463/result.json')['head']==context['head']
 run('merged-app-imports',[python,'-B','-m','pytest','tests/test_lightweight_torch.py','tests/test_torch_gradient_utilities.py','-q','-p','no:cacheprovider','--basetemp='+str(r/'merged-app-tmp'),'--junitxml='+str(r/'merged-app.xml')])
"""
s=s[:pos]+prelude+s[pos:]
s=s.replace(" run('wasm-driver'", " run('custom-cases-wasm',[node,'web/scripts/check-custom-cases-wasm.mjs'])\n run('wasm-driver'")
s=s.replace("source_hashes=read(r/'source-hashes.json'),", "source_hashes=read(r/'source-hashes.json'),cpu_equivalence_sha256=sha(r/'cpu-source-equivalence.json'),current_package_sha256=sha(b/'torch-iteration-463/result.json'),")
(r/'run.py').write_text(s)
(r/'verify-export.py').write_text((b/'torch-iteration-365/verify-export.py').read_text().replace('0.81.0','0.82.0').replace('len(expected) == 65','len(expected) == 66'))
(r/'verify-generated-worker.mjs').write_text((b/'torch-iteration-365/verify-generated-worker.mjs').read_text())
s=(b/'torch-iteration-365/check-nested-wasm.mjs').read_text().replace('pl_matrix_probe_v081','pl_matrix_probe_v082')
needle="const source=original+'\\n'+probe+'\\n'+packedProbe;"
extra="""const clippingProbe=`
# Exercise final 0.82 package bytes and ordinary nested aliases in the real Worker.
import stridetorch as _pl82_package
from torch.nn.utils.clip_grad import clip_grad_norm_ as _pl82_norm, clip_grad_value_ as _pl82_value
assert _pl82_package.__version__ == '0.82.0'
_pl82_parameter = torch.tensor([3., 4.], dtype=torch.float64, requires_grad=True)
_pl82_optimizer = torch.optim.SGD([_pl82_parameter], lr=.1)
_pl82_parameter.square().sum().backward()
_pl82_buffer = _pl82_parameter.grad
_pl82_total = _pl82_norm((_pl82_parameter,), 1.)
assert _pl82_total.item() == 10. and not _pl82_total.requires_grad
_pl82_value(_pl82_parameter, .7)
_pl82_optimizer.step()
assert _pl82_parameter.grad is _pl82_buffer
torch.testing.assert_close(_pl82_parameter.detach(), torch.tensor([3. - .1 * 6. / (10. + 1e-6), 4. - .07], dtype=torch.float64), rtol=1e-12, atol=1e-12)
_pl82_root = torch.tensor([3., 4.], dtype=torch.float64, requires_grad=True)
_pl82_gradient = _pl82_root * 2.
_pl82_parameter.grad = _pl82_gradient
_pl82_norm(_pl82_parameter, 1.)
_pl82_gradient.sum().backward()
torch.testing.assert_close(_pl82_root.grad, torch.tensor([2., 2.], dtype=torch.float64))
del _pl82_package, _pl82_norm, _pl82_value, _pl82_parameter, _pl82_optimizer, _pl82_buffer, _pl82_total, _pl82_root, _pl82_gradient
`;
const source=original+'\\n'+probe+'\\n'+packedProbe+'\\n'+clippingProbe;"""
assert needle in s;s=s.replace(needle,extra);(r/'check-nested-wasm.mjs').write_text(s)
files=subprocess.check_output(['/usr/bin/git','ls-files','paperleet','tests','problems','packages/stridetorch/src','packages/stridetorch/tests','packages/stridetorch/README.md','packages/stridetorch/pyproject.toml','pyproject.toml','web/src','web/scripts','web/package.json','web/package-lock.json','web/tsconfig.json','web/vite.config.ts','.github/workflows'],cwd=repo,text=True).splitlines()
write(r/'static-inputs.json',{name:sha(repo/name) for name in files if (repo/name).is_file()})
assets={str(p.relative_to(repo)):sha(p) for folder in ['web/public/data/browser-judge','web/public/data/modules'] for p in (repo/folder).glob('*.json')};write(r/'immutable-assets.json',assets)
resources={p.name:sha(p) for p in (repo/'packages/stridetorch/src/stridetorch').iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']};assert len(resources)==66;write(r/'source-hashes.json',resources)
write(r/'context.json',dict(head=head,cpu_head=cpu['head'],catalog_modules=89,version='0.82.0',merged_upstream=merge['merged_upstream']))
write(r/'prerequisites.json',dict(cpu_plan_sha256=sha(b/'torch-iteration-460/plan.json'),current_package_result_sha256=sha(b/'torch-iteration-463/result.json')))
write(r/'execution-plan.json',dict(files={p.name:sha(p) for p in r.iterdir() if p.is_file() and p.name!='execution-plan.json'},scope='Freshcurrent-main082catalog/export/fullWASM/frontend/build/Worker;qualifiedCPUsourceequivalenceexplicit;currentmergedprivatepackage6artifacts;alloldassetsretained;noCIordeploy'))
print(json.dumps(dict(status='prepared',head=head,resources=66,preserved_assets=len(assets))))
