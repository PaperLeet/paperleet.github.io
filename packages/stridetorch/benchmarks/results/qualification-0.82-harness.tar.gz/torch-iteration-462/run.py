"""Serial local catalog/export/browser gates after the confirmed CPU process ends."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,traceback
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
plan=read(r/'execution-plan.json');context=read(r/'context.json');static=read(r/'static-inputs.json');assets=read(r/'immutable-assets.json');prereq=read(r/'prerequisites.json');receipts=[]
python=b/'torch-iteration-82/application-env/bin/python';node=Path('/Users/david/.local/share/fnm/node-versions/v22.22.1/installation/bin/node')
env=dict(os.environ,PYTHON=str(python),PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0',PYTHONPATH=os.pathsep.join([str(repo/'packages/stridetorch/src'),str(repo)]),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');env['PATH']=str(node.parent)+':/opt/homebrew/bin:'+str(python.parent)+':'+env['PATH']

def progress(status,**details):write(r/'progress.json',dict(status=status,supervisor_pid=os.getpid(),observed_unix=time.time(),receipts=receipts,**details))
def verify():
 for name,h in plan['files'].items():assert sha(r/name)==h,name
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==context['head']
 for name,h in static.items():assert sha(repo/name)==h,name
 for name,h in assets.items():assert sha(repo/name)==h,name
 if (r/'live-export-sha256.json').exists():
  for name,h in read(r/'live-export-sha256.json').items():assert sha(repo/'web/public/data'/name)==h,name

def run(label,command,cwd=repo,extra=None):
 verify()
 with (r/(label+'.log')).open('w') as log:
  child=subprocess.Popen(list(map(str,command)),cwd=cwd,env={**env,**(extra or {})},stdout=log,stderr=subprocess.STDOUT);progress('running',label=label,pid=child.pid,command=list(map(str,command)));code=child.wait()
 receipt=dict(label=label,exit_code=code,command=list(map(str,command)),cwd=str(cwd),log_sha256=sha(r/(label+'.log')));receipts.append(receipt);write(r/'receipts.json',receipts);print(json.dumps(receipt),flush=True);assert code==0,(label,(r/(label+'.log')).read_text()[-2200:]);verify()
try:
 verify()
 application=b/'torch-iteration-460'
 assert sha(application/'plan.json')==prereq['cpu_plan_sha256']
 cpu=read(application/'result.json')
 assert cpu['status']=='passed_full_application_cpu' and cpu['head']==context['cpu_head']
 assert cpu['totals']['tests']==45933 and cpu['totals']['failures']==cpu['totals']['errors']==0 and cpu['totals']['skipped']==1
 write(r/'application-cpu-receipt.json',dict(result_sha256=sha(application/'result.json'),result=cpu))
 resource=read(b/'torch-iteration-457/receipt.json')
 assert resource['status']=='verified_recoverable_thin_backup'
 write(r/'resource-recovery-receipt.json',dict(receipt_sha256=sha(b/'torch-iteration-457/receipt.json'),result=resource))
 assert read(r/'cpu-source-equivalence.json')['status']=='qualified_computation_and_existing_application_sources_unchanged'
 assert read(b/'torch-iteration-463/result.json')['head']==context['head']
 run('merged-app-imports',[python,'-B','-m','pytest','tests/test_lightweight_torch.py','tests/test_torch_gradient_utilities.py','-q','-p','no:cacheprovider','--basetemp='+str(r/'merged-app-tmp'),'--junitxml='+str(r/'merged-app.xml')])
 run('native-catalog',[python,'-B','-m','paperleet.cli','ci','--repeats','3','--budget','600'])
 native=read(repo/'reports/ci.json');assert native['passed'] and native['problems']==89 and native['repeats']==3 and not native['issues'] and native['tests_executed']==12360,native
 write(r/'native-catalog-result.json',native);snapshot=r/'native-references';snapshot.mkdir();references={}
 for identifier in native['mutation']:
  name=identifier.replace('/','-')+'-reference.json';source=repo/'reports'/name;shutil.copyfile(source,snapshot/name);references[name]=sha(snapshot/name)
 write(r/'native-references-sha256.json',references)
 run('export',[python,'-B','-m','paperleet.cli','export'])
 run('verify-export',[python,'-B',r/'verify-export.py'])
 run('full-wasm',[node,'web/scripts/check-browser-wasm.mjs','--all'])
 wasm=read(repo/'reports/browser-wasm.json');assert wasm['passed'] and wasm['modules']==wasm['catalog_modules']==89 and not wasm['browser_budget_exceeded'],wasm
 write(r/'full-wasm-result.json',wasm)
 run('full-frontend-check',['npm','run','check'],repo/'web')
 run('custom-cases-wasm',[node,'web/scripts/check-custom-cases-wasm.mjs'])
 run('wasm-driver',[node,'web/scripts/check-wasm-cases.mjs'])
 run('pages-policy',[node,'web/scripts/check-pages-release.cjs'])
 run('build',['npm','run','build'],repo/'web',dict(VITE_PATH_ROUTING='0'))
 value=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED','--jq','.value'],cwd=repo,text=True).strip();assert value in ['0','1']
 profile=dict(VITE_PATH_ROUTING='1',PAPERLEET_MAIN_SITE_ENABLED=value,VITE_PUBLIC_SITE='0' if value=='1' else '1',VITE_APP_EDITION='hosted' if value=='1' else 'local',VITE_API_ORIGIN='https://app.paperleet.com' if value=='1' else '',VITE_HOSTED_APP_AVAILABLE='1',VITE_HOSTED_APP_URL='https://app.paperleet.com')
 write(r/'current-pages-profile.json',profile);run('pages-profile-build',['npm','run','build'],repo/'web',profile)
 run('pages-assets',[python,'-B','web/scripts/check-pages-assets.py'])
 run('retain-production-assets-check',[python,'-B','web/scripts/retain-pages-assets.py','web/dist','--check'])
 run('generated-worker',[node,r/'verify-generated-worker.mjs'])
 run('nested-wasm',[node,r/'check-nested-wasm.mjs'])
 verify();result=dict(status='passed_local_application_catalog_export_frontend_worker_gates',head=context['head'],version='0.82.0',resources=66,source_hashes=read(r/'source-hashes.json'),cpu_equivalence_sha256=sha(r/'cpu-source-equivalence.json'),current_package_sha256=sha(b/'torch-iteration-463/result.json'),application_cpu_sha256=sha(application/'result.json'),native_catalog_sha256=sha(r/'native-catalog-result.json'),wasm_catalog_sha256=sha(r/'full-wasm-result.json'),export_sha256=sha(r/'export-identity.json'),receipts=receipts,execution_plan_sha256=sha(r/'execution-plan.json'),modules=89,mutants=sum(v['mutants'] for v in wasm['results']),performance_qualified=False,main_adopted=False,ci_triggered=False,pushed=False,published=False,deployed=False,goal_status='active')
 write(r/'result.json',result);progress('completed',result_status=result['status']);print(json.dumps({k:v for k,v in result.items() if k not in ['receipts','source_hashes']}),flush=True)
except BaseException as error:
 progress('failed',error=str(error),traceback=traceback.format_exc());raise
