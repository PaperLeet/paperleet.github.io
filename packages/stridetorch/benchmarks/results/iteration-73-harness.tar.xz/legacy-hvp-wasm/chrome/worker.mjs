import {loadJudgePackages} from '../../../extraction-browser/packages.mjs';
self.onmessage=async()=>{
 const output=[];
 try{
  const plan=await(await fetch('../plan.json')).json();
  const {loadPyodide}=await import('../../../runtime-0.29.4/pyodide.mjs');
  const py=await loadPyodide({indexURL:new URL('../../../runtime-0.29.4/',self.location.href).href,stdout:v=>output.push(v),stderr:v=>output.push(v)});
  await loadJudgePackages(py,[]);py.FS.mkdirTree('/runtime/stridetorch');py.FS.mkdirTree('/runtime/fixtures');
  for(const name of Object.keys(plan.source))py.FS.writeFile('/runtime/stridetorch/'+name,await(await fetch('../source/'+name)).text());
  for(const name of Object.keys(plan.fixtures))py.FS.writeFile('/runtime/fixtures/'+name,await(await fetch('../fixtures/'+name)).text());
  py.globals.set('plan_json',JSON.stringify(plan));
  const result=JSON.parse(py.runPython(await(await fetch('../replay.py')).text()));
  self.postMessage({...result,pyodide:py.version,output});
 }catch(error){self.postMessage({error:String(error.stack||error),output});}
};
