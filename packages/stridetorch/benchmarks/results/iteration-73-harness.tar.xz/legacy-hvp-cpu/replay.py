"""Executed inside Pyodide after the frozen source/fixture files are loaded."""
import contextlib,hashlib,io,json,pathlib,sys
import numpy as np

sys.path.insert(0,'/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-73/legacy-hvp-cpu/runtime')
plan=json.loads(plan_json);root=pathlib.Path('/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-73/legacy-hvp-cpu/runtime/fixtures')
sys.path.insert(0,str(root))
from determinant_reference import reference as polynomial_reference
source={q.name:hashlib.sha256(q.read_bytes()).hexdigest() for q in pathlib.Path('/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-73/legacy-hvp-cpu/runtime/stridetorch').iterdir() if q.is_file()}
assert source==plan['source']
for name,digest in plan['fixtures'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
import stridetorch
assert stridetorch.__version__==plan['version']
def normalized(value):
    if isinstance(value,dict):return {k:(v.removeprefix('torch.') if k=='dtype' else normalized(v)) for k,v in value.items()}
    if isinstance(value,list):return [normalized(v) for v in value]
    return value
maximum=0.
def compare(a,b,dtype):
    global maximum
    if isinstance(a,dict):
        assert set(a)==set(b),(set(a),set(b))
        if 'values' in a and 'shape' in a:
            for key in ['shape','dtype','requires_grad']:assert a[key]==b[key],(key,a[key],b[key])
            x=np.asarray(a['values'],dtype=float);y=np.asarray(b['values'],dtype=float)
            np.testing.assert_allclose(y,x,rtol=1e-4 if dtype=='float32' else 1e-8,atol=3e-6 if dtype=='float32' else 2e-10,equal_nan=True)
            finite=np.isfinite(x)&np.isfinite(y)
            if finite.any():maximum=max(maximum,float(np.max(np.abs(x[finite]-y[finite]))))
        else:
            for key in a:compare(a[key],b[key],dtype)
    elif isinstance(a,list):
        assert len(a)==len(b)
        for x,y in zip(a,b):compare(x,y,dtype)
    else:assert a==b,(a,b)
precision=json.loads((root/'native-instance-precision.json').read_text())
assert max(precision['rows'][1]['max_abs_errors_vs_analytic'])<1e-10
failures=[];candidates={};summaries=[];controls=[];polynomial_extensions=[]
for job in plan['programs']:
    output=io.StringIO()
    with contextlib.redirect_stdout(output):
        exec(compile((root/job['script']).read_text(),str(root/job['script']),'exec'),{'__name__':'__main__'})
    actual=normalized(json.loads(output.getvalue()));native=normalized(json.loads((root/job['oracle']).read_text()))
    assert native['cases']==actual['cases']==job['cases']
    for a,b in zip(native['rows'],actual['rows']):
        try:
            if job['label']=='piecewise':
                compare(a,b,a['dtype']);continue
            for key in a:
                if key not in ['result','exception','message']:compare(a[key],b[key],a['dtype'])
            if a['status']=='success':
                if job['label'] in ['singular','singular_extended'] and np.isnan(np.asarray((a['result'][1][0] if isinstance(a['result'][1],list) else a['result'][1])['values'],dtype=float)).any():
                    compare(a['result'][0],b['result'][0],a['dtype'])
                    native_value=a['result'][1][0] if isinstance(a['result'][1],list) else a['result'][1]
                    actual_value=b['result'][1][0] if isinstance(b['result'][1],list) else b['result'][1]
                    for key in ['shape','dtype','requires_grad']:assert native_value[key]==actual_value[key],key
                    target=polynomial_reference(a['fixture_inputs'],a['fixture_vectors'],a['squared'])
                    data=np.asarray(actual_value['values'],dtype=float)
                    assert np.isfinite(data).all()
                    np.testing.assert_allclose(data,target,rtol=1e-5,atol=np.finfo(a['dtype']).tiny)
                    polynomial_extensions.append(dict(group=job['label'],case=a['case'],dtype=a['dtype'],strict=a['strict'],squared=a['squared'],strided=a.get('strided'),max_abs_error=float(np.max(np.abs(data-target)))))
                elif job['label']=='models' and a['case']=='instancenorm_train' and a['dtype']=='float32':
                    assert [q['values'] for q in a['fixture_inputs']]==precision['arrays']
                    assert [q['values'] for q in a['fixture_vectors']]==precision['directions']
                    compare(a['result'][0],b['result'][0],a['dtype']);errors=[]
                    for reference,value in zip(precision['reference'],b['result'][1]):
                        assert value['dtype']=='float32' and not value['requires_grad']
                        target=np.asarray(reference);data=np.asarray(value['values'])
                        assert value['shape']==list(target.shape)
                        np.testing.assert_allclose(data,target,rtol=1e-5,atol=1e-6)
                        errors.append(float(np.max(np.abs(data-target))))
                    controls.append(dict(strict=a['strict'],strided=a['strided'],max_abs_errors=errors))
                else:compare(a['result'],b['result'],a['dtype'])
        except (AssertionError,KeyError,TypeError) as error:
            failures.append(dict(group=job['label'],case=a['case'],dtype=a['dtype'],strict=a['strict'],squared=a.get('squared'),strided=a.get('strided'),error=str(error),native=a,actual=b))
    candidates[job['label']]=actual
    summaries.append(dict(group=job['label'],cases=actual['cases']))
assert sum(q['cases'] for q in summaries)==plan['expected'] and len(controls)==4
assert len(polynomial_extensions)==40,len(polynomial_extensions)
json.dumps(dict(status='failed' if failures else 'success',version=stridetorch.__version__,numpy=np.__version__,python=sys.version.split()[0],
    source_hashes=source,native_reference_profiles=plan['native_reference_profiles'],fixture_hashes=plan['fixtures'],cases=plan['expected'],groups=summaries,failures=failures,candidates=candidates,
    independent_precision_controls=controls,polynomial_extension_controls=polynomial_extensions,direct_native_cases=plan['expected']-44,max_finite_abs_difference=maximum),allow_nan=False)
