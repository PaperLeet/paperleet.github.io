"""Replay all qualified0.72 JVP rows on the isolated preprocessing prototype."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
import numpy as np
r=Path(__file__).resolve().parent;p=r/'cpu-equivalence';p.mkdir()
old=r.parent/'torch-iteration-72';selected=old/'selected-release';source=r/'candidate/packages/stridetorch/src'
read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
freeze=read(r/'source-freeze.json');baseline=read(selected/'core-and-package-proof.json')
assert baseline['status']=='selected_version_cpu_native_wasm_and_package_passed' and baseline['source_hashes']==freeze['baseline_source_hashes']
manifest=lambda:{q.name:sha(q) for q in (source/'stridetorch').iterdir() if q.suffix=='.py' or q.name in ['LICENSE','NOTICE']}
assert manifest()==freeze['source_hashes']
env=dict(os.environ,PYTHONPATH=str(source),PYTHONDONTWRITEBYTECODE='1',STRIDE_PROBE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')


def compare(a,b,dtype,path=()):
    if isinstance(a,dict):
        assert set(a)-{'message'}==set(b)-{'message'},(path,set(a),set(b))
        if 'values' in a:
            for key in ['dtype','shape','requires_grad']:assert a[key]==b[key],(path,key)
            np.testing.assert_allclose(b['values'],a['values'],rtol=1e-4 if dtype=='float32' else 1e-8,atol=3e-6 if dtype=='float32' else 2e-10)
        else:
            for key in set(a)-{'message'}:compare(a[key],b[key],dtype,path+(key,))
    elif isinstance(a,list):
        assert len(a)==len(b),path
        for i,(x,y) in enumerate(zip(a,b)):compare(x,y,dtype,path+(i,))
    else:assert a==b,(path,a,b)


failures=[];receipts=[]
for name,directory,count in [('basic','prototype-proof',480),('advanced','advanced-proof',512),
                            ('default-models','default-model-proof',416),('graph-models','model-proof',416),
                            ('dependencies','dependencies',480)]:
    target=p/name;target.mkdir()
    origin=selected/'native-cpu'/directory
    program=old/'probe-functional-jvp-dependencies.py' if name=='dependencies' else origin/'probe.py'
    expected=origin/('candidate-dependencies.json' if name=='dependencies' else 'candidate.json')
    shutil.copy2(program,target/'probe.py')
    with (target/'candidate.json').open('w') as output,(target/'stderr.log').open('w') as error:
        child=subprocess.run([sys.executable,str(target/'probe.py')],cwd=target,env=env,stdout=output,stderr=error)
    child.check_returncode();assert manifest()==freeze['source_hashes']
    a,b=read(expected),read(target/'candidate.json');assert a['cases']==b['cases']==count and len(a['rows'])==len(b['rows'])==count
    for x,y in zip(a['rows'],b['rows']):
        try:compare(x,y,x['dtype'].removeprefix('torch.'))
        except (AssertionError,TypeError,KeyError) as error:failures.append(dict(flow=name,error=str(error),expected=x,actual=y))
    receipts.append(dict(flow=name,cases=count,exit_code=0,program_sha256=sha(program),candidate_sha256=sha(target/'candidate.json'),baseline_rows_sha256=sha(expected)))
    print(name,'TERMINAL0',count,flush=True)
result=dict(status='failed' if failures else 'selected_072_cpu_equivalence_passed',cases=2304,failures=failures,
            source_hashes=freeze['source_hashes'],baseline_source_hashes=freeze['baseline_source_hashes'],
            baseline_core_qualification_sha256=sha(selected/'core-and-package-proof.json'),receipts=receipts,
            scope='CPU paired equivalence to previously qualified selected0.72 rows at original tolerances. References retain2184native-qualified,88independent-math and32explicit-unsupported classifications. No new native oracle,WASM/package/fullSDK/application/performance or main-adoption claim.')
(p/'qualification.json').write_text(json.dumps(result,indent=2)+'\n')
assert not failures
print(json.dumps(dict(status=result['status'],cases=2304,failures=0)),flush=True)
