"""Check inherited explicit mutation rejection on the selected candidate after latency terminates."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
r=Path(__file__).resolve().parent;v=r/'selected-release'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
summary=json.loads((r/'performance/summary.json').read_text());assert summary['status']=='completed'
freeze=json.loads((v/'source-freeze.json').read_text())
program=r.parent/'torch-iteration-72/probe-jvp-captured-vector-mutation.py'
target=v/'captured-vector-mutation.json'
env=dict(os.environ,PYTHONPATH=str(v/'snapshot/packages/stridetorch/src'),STRIDE_PROBE='1',PYTHONDONTWRITEBYTECODE='1')
with target.open('w') as output:subprocess.run([sys.executable,str(program)],env=env,stdout=output,check=True)
rows=json.loads(target.read_text());assert len(rows)==4
for row in rows:assert row['error']=='BrowserUnsupported' and row['message']=='Tensor mutation during JVP requires the server'
record=dict(status='explicit_unsupported_boundary_verified',cases=4,source_hashes=freeze['source_hashes'],
 evidence_sha256={str(program.relative_to(r.parent)):sha(program),'selected-release/captured-vector-mutation.json':sha(target)},
 scope='CPU only:captured vector Tensor.add_ before/after constructing the callback output,create_graph false/true. Explicit unsupported error,not part of2304inventory or native compatibility claim.')
# close-local verifies evidence paths relative to iteration73; store a local copy.
copy=v/'probe-jvp-captured-vector-mutation.py';copy.write_bytes(program.read_bytes())
record['evidence_sha256']={'selected-release/probe-jvp-captured-vector-mutation.py':sha(copy),
                         'selected-release/captured-vector-mutation.json':sha(target)}
(v/'captured-vector-mutation-boundary.json').write_text(json.dumps(record,indent=2)+'\n')
print('Verified4explicitly unsupported mutation boundaries on selected0.73')
