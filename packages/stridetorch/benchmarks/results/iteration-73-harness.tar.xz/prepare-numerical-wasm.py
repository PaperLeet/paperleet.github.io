"""Prepare current-source JVP CPU-row replay and adopted HVP references in real WASM."""
from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-72/selected-release'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();freeze=json.loads((r/'source-freeze.json').read_text())
p=r/'numerical-wasm';p.mkdir();shutil.copytree(r/'wasm-proof/chrome-contracts/source',p/'source');(p/'fixtures').mkdir()
flows=[]
for label,count in [('basic',480),('advanced',512),('default-models',416),('graph-models',416),('dependencies',480)]:
    origin=r/'cpu-equivalence'/label
    shutil.copy2(origin/'probe.py',p/'fixtures'/(label+'.py'))
    shutil.copy2(origin/'candidate.json',p/'fixtures'/(label+'.json'))
    flows.append(dict(name=label,program=label+'.py',expected=label+'.json',cases=count))
plan=dict(source=freeze['source_hashes'],fixtures={q.name:sha(q) for q in (p/'fixtures').iterdir()},version='0.72.0',flows=flows,expected_cases=2304,
 scope='Unreleased preprocessing prototype. CurrentCPU rows are paired-equivalent to separately qualified public0.72data;not a new native oracle.')
(p/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for name in ['node.mjs','replay.py']:shutil.copy2(old/'numerical-wasm'/name,p/name)
shutil.copytree(old/'numerical-wasm/chrome',p/'chrome',ignore=shutil.ignore_patterns('result.json'))
for name in ['worker.mjs','run.mjs']:
    q=p/'chrome'/name;q.write_text(q.read_text().replace('../../../../','../../../').replace('/torch-iteration-72/selected-release/numerical-wasm/', '/torch-iteration-73/numerical-wasm/'))
p=r/'legacy-hvp-wasm';p.mkdir();shutil.copytree(r/'wasm-proof/chrome-contracts/source',p/'source')
shutil.copytree(old/'legacy-hvp-wasm/fixtures',p/'fixtures')
plan=json.loads((old/'legacy-hvp-wasm/plan.json').read_text());plan['source']=freeze['source_hashes']
(p/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for name in ['node.mjs','replay.py']:shutil.copy2(old/'legacy-hvp-wasm'/name,p/name)
shutil.copytree(old/'legacy-hvp-wasm/chrome',p/'chrome',ignore=shutil.ignore_patterns('result.json'))
for name in ['worker.mjs','run.mjs']:
    q=p/'chrome'/name;q.write_text(q.read_text().replace('../../../../','../../../').replace('/torch-iteration-72/selected-release/legacy-hvp-wasm/', '/torch-iteration-73/legacy-hvp-wasm/'))
code=(r.parent/'torch-iteration-72/replay-legacy-hvp-cpu.py').read_text().replace("r.parent / 'torch-iteration-71/production-release/native-wasm-proof'", "r.parent / 'torch-iteration-72/selected-release/legacy-hvp-wasm'").replace("r/'optimized-prototype-freeze.json'","r/'source-freeze.json'").replace('version literal0.71','version literal0.72').replace("plan['version'] = '0.71.0'","plan['version'] = '0.72.0'")
compile(code,str(r/'replay-legacy-hvp-cpu.py'),'exec');(r/'replay-legacy-hvp-cpu.py').write_text(code)
print('Prepared realNode/Chrome2304JVP+720legacyHVP fixtures andCPU legacy replay;prototype version literal0.72')
