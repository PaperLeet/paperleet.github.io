"""After terminal integration, preserve proofs and validate a reviewed frontend-only fast-forward."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
p=Path(__file__).resolve().parent;r=p.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();save=lambda q,d:q.write_text(json.dumps(d,indent=2)+'\n')
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
assert len(sys.argv)==2,'Pass the exact fetched and reviewed target SHA only after the integration handle is terminal.'
target=sys.argv[1];before=read(p/'local-validation.json');assert before['status']=='passed'
assert git('rev-parse','HEAD').decode().strip()==before['upstream']
assert git('rev-parse',target).decode().strip()==target
subprocess.run(['git','merge-base','--is-ancestor',before['upstream'],target],cwd=repo,check=True)
changed=git('diff','--name-only',before['upstream'],target).decode().splitlines();assert changed
allowed=lambda n:n.startswith(('web/src/','web/scripts/','docs/validation/')) or n=='web/package.json'
assert all(allowed(n) for n in changed),changed
for name in ['web/scripts/check-browser-wasm.mjs','web/scripts/check-wasm-cases.mjs','web/scripts/prepare-browser-worker.mjs']:
    assert name not in changed,'Runtime verifier changed;validate the affected domain instead of reusing its old proof.'
worker=read(p/'generated-worker-proof.json')
for name,digest in worker['inputs'].items():assert hashlib.sha256(git('show',target+':'+name)).hexdigest()==digest
old_pkg=json.loads(git('show',before['upstream']+':web/package.json'));new_pkg=json.loads(git('show',target+':web/package.json'))
assert {k:v for k,v in old_pkg.items() if k!='scripts'}=={k:v for k,v in new_pkg.items() if k!='scripts'}
assert all(new_pkg['scripts'].get(k)==v for k,v in old_pkg['scripts'].items() if k!='check')
assert all(k.startswith('check:') for k in set(new_pkg['scripts'])-set(old_pkg['scripts']))
domains=[('application-input-sha256.json',''),('source-hashes.json','packages/stridetorch/src/stridetorch'),
 ('test-hashes.json','packages/stridetorch/tests'),('baseline-immutable-sha256.json',''),('live-export-sha256.json','web/public/data')]
for manifest,prefix in domains:
    for name,digest in read(p/manifest).items():assert sha(repo/prefix/name)==digest,(manifest,name)
policy=read(p/'release-policy-identity.json')
for group in [policy['files'],policy['workflows']]:
    for name,digest in group.items():assert hashlib.sha256(git('show',target+':'+name)).hexdigest()==digest
old=p/('validated-on-'+before['upstream'][:12]);old.mkdir()
for q in list(p.iterdir()):
    if q.is_file() and q.suffix in ['.py','.mjs','.json','.log']:shutil.copy2(q,old/q.name)
if (p/'published-inputs').exists():shutil.move(str(p/'published-inputs'),str(old/'published-inputs'))
for relative in ['packages/stridetorch/benchmarks/results/iteration-73.json','packages/stridetorch/benchmarks/results/iteration-73-harness.tar.xz','docs/validation/torch-runtime-iteration-73.md']:
    q=repo/relative
    if q.exists():
        assert not git('ls-files','--',relative),'Do not move tracked evidence.'
        shutil.move(str(q),str(old/q.name))
subprocess.run(['git','merge','--ff-only',target],cwd=repo,check=True)
tracked=git('ls-files','-z','--','web/src','web/scripts','web/index.html','web/package.json','web/package-lock.json','web/vite.config.ts','web/tsconfig*.json','web/public/browser-judge').decode().split('\0')
frontend={n:sha(repo/n) for n in tracked if n};save(p/'frontend-input-sha256.json',frontend)
context=read(p/'context.json');context.update(upstream=target,original_qualified_upstream=before['upstream']);save(p/'context.json',context)
python=r.parent/'torch-iteration-69/integration-dev-env/bin/python'
env=dict(os.environ,PYTHON=str(python),PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=os.pathsep.join([str(repo/'packages/stridetorch/src'),str(repo)]),
 OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
env['PATH']='/Users/david/.npm/_npx/d18f28baf1132559/node_modules/node/bin:/opt/homebrew/bin:'+str(python.parent)+':'+env['PATH']
assert subprocess.check_output(['node','--version'],env=env,text=True).strip()=='v22.23.3'
receipts=read(old/'receipts.json')[:5]
assert [x['label'] for x in receipts]==['editable-environment','export','verify-export','cpu','wasm']
assert all(x['exit_code']==0 for x in receipts)
def run(label,args,cwd=repo,extra=None):
    start=time.monotonic()
    with (p/(label+'.log')).open('w') as output:child=subprocess.run(args,cwd=cwd,env={**env,**(extra or {})},stdout=output,stderr=subprocess.STDOUT)
    receipts.append(dict(label=label,args=args,cwd=str(cwd),exit_code=child.returncode,seconds=time.monotonic()-start,
                         log_sha256=sha(p/(label+'.log')),summary=(p/(label+'.log')).read_text().splitlines()[-1:],executed_on_upstream=target))
    save(p/'receipts.json',receipts);child.check_returncode();print(label,'TERMINAL0',flush=True)
run('full-frontend-check',['npm','run','check'],repo/'web')
run('wasm-driver',['node','web/scripts/check-wasm-cases.mjs'])
run('pages-policy',['node','web/scripts/check-pages-release.cjs'])
run('build',['npm','run','build'],repo/'web')
value=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED','--jq','.value'],cwd=repo,text=True).strip();assert value in ['0','1']
profile=dict(PAPERLEET_MAIN_SITE_ENABLED=value,VITE_PUBLIC_SITE='0' if value=='1' else '1',VITE_APP_EDITION='hosted' if value=='1' else 'local',
 VITE_API_ORIGIN='https://app.paperleet.com' if value=='1' else '',VITE_HOSTED_APP_AVAILABLE='1',VITE_HOSTED_APP_URL='https://app.paperleet.com')
save(p/'current-pages-profile.json',profile);run('pages-profile-build',['npm','run','build'],repo/'web',profile)
run('generated-worker',['node',str(p/'verify-generated-worker.mjs')])
for manifest,prefix in domains:
    for name,digest in read(old/manifest).items():assert sha(repo/prefix/name)==digest,(manifest,name)
for name,digest in frontend.items():assert sha(repo/name)==digest
assert git('rev-parse','HEAD').decode().strip()==target
equivalence=dict(status='verified_unchanged_numeric_inputs_and_revalidated_frontend',retained_proof_directory=old.name,
 original_qualified_upstream=before['upstream'],current_upstream=target,changed_paths=changed,changed_file_sha256={n:sha(repo/n) for n in changed},
 retained_proof_sha256={n:sha(old/n) for n in ['local-validation.json','cpu-receipt.json','full-wasm-result.json','application-input-sha256.json','source-hashes.json','test-hashes.json','release-policy-identity.json']},
 scope='Only frontend/docs/check scripts changed. Numeric/runtime/test/package/export,compiler locks andWorker/policy inputs unchanged;completeupdated frontend suite andboth builds rerun. Original execution records retained.')
save(p/'source-equivalent-frontend-update.json',equivalence)
save(p/'frontend-update-dependency-audit.json',dict(status='unchanged_runtime_dependencies_and_dev_build_entrypoints',refs=[before['upstream'],target],
 inspected_python_web_references={n:sha(repo/n) for n in ['tests/test_dev.py','tests/test_submissions.py','tests/test_browser_judge.py','scripts/dev.py','paperleet/export.py']},
 non_script_package_fields_identical=True,dev_build_wasm_entrypoints_identical=True))
save(p/'local-validation.json',dict(before,upstream=target,receipts=receipts,frontend_commands=len(new_pkg['scripts']['check'].split(' && ')),source_equivalent_frontend_update=equivalence,
 main_adopted=False,ci_triggered=False,deployed=False))
print('FRONTEND BASE REFRESHED AND VERIFIED;NO PUSH OR RELEASE',flush=True)
