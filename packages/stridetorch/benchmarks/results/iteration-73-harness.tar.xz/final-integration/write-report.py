"""Write iteration73 human evidence from the terminal local report only."""
from pathlib import Path
import json
p=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
report=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-73.json').read_text())
assert report['status']=='validated_locally' and report['version']=='0.73.0'
local=report['local_integration'];archive=report['raw_archive'];rows=report['performance']['rows']
frontend_note=''
if report.get('source_equivalent_frontend_update'):
    update=report['source_equivalent_frontend_update']
    frontend_note=f'''\nCPU and full-catalog WASM gates executed on `{update['original_qualified_upstream']}`.
The base subsequently advanced through {len(update['changed_paths'])} frontend/documentation files
to `{update['current_upstream']}`. Recorded runtime, Python application/test/catalog,
package/dependency and Worker inputs are unchanged. The complete updated frontend
suite and both build profiles were rerun on the latter base. Original execution
records remain in `{update['retained_proof_directory']}`; the CPU/WASM results are
source-equivalent evidence, not claims of re-execution on the later Git SHA.\n'''
targets=[];other=[]
for runtime in ['cpu','node','chrome']:
    selected=[row for row in rows if row['runtime']==runtime and row['family']!='functional_jvp'];assert len(selected)==20
    def span(key):
        values=[row['medians'][key] for row in selected];return f'{min(values):.4f}–{max(values):.4f}'
    other.append(f"| {runtime} | {span('duplicate_over_baseline')} | {span('candidate_over_baseline')} | {span('candidate_over_duplicate')} |")
    for row in rows:
        if row['runtime']!=runtime or row['family']!='functional_jvp':continue
        ratios=row['medians'];ns=row['median_ns']
        targets.append(f"| {runtime} | {row['case']} | {ratios['duplicate_over_baseline']:.4f} | {ratios['candidate_over_baseline']:.4f} | {ratios['candidate_over_duplicate']:.4f} | {ns['baseline']/1000:.2f} → {ns['candidate']/1000:.2f} |")
memory=[]
allocation=report.get('cpu_allocation_controls') or report['cpu_allocations']
for row in allocation['rows']:
    memory.append(f"| {row['case']} | {row['duplicate_over_baseline_peak']:.4f} | {row['candidate_over_baseline_peak']:.4f} |")
text=f'''# Torch runtime iteration 73: functional JVP preprocessing

Version 0.73 preserves the functional-JVP API and reduces temporary preprocessing
objects. Validation helpers and real dtype descriptors are shared across calls;
single-Tensor validation retains all checks without creating a generator, and
non-strict calls do not allocate strict-mode tracking sets. Exact base-Tensor
leaves receive their final gradient metadata at construction. Tensor subclasses
retain their `detach`/`requires_grad_` dispatch.

An early prototype bypassed three observed subclass `detach` calls. Its source,
original passing narrower evidence and failing dispatch probe are preserved.
The corrected candidate adds 128 regression cases spanning Tensor/returned-
subclass forms, inputs/vectors, dtype, original gradient flags, strictness and
graph mode. These check dispatch, values, reverse queries and caller buffers.

The existing callback count, original flags/buffers/hooks, cast behavior,
zero/unused/empty strict semantics and returned reverse graphs retain their
qualified behavior. Supported functional-JVP differentiation remains real
float32/64 with ordinary reverse queries of returned graphs. General higher-order
reverse AD, complex/nested transforms, callback hook registration and Tensor
mutation inside forward AD remain outside this bounded API. No GPU backend is
enabled by this change.

## Exact-version verification

| Gate | Result |
| --- | --- |
| Minimum installed standalone wheel | 8,851 tests; Python 3.10.19, NumPy 1.26.4, no native Torch |
| Node / Chrome Pyodide SDK | 8,838 tests and 74 suites each; Pyodide 0.29.4, NumPy 2.2.5 |
| Package ownership | Wheel/sdist/private-wheel identities, aliases, separate uninstall, checkpoints and fresh-process JVP operator pickle |
| JVP CPU/Node/Chrome inventory | 2,304 cases per runtime; 2,184 native-qualified, 88 explicit math controls, 32 explicit unsupported hook cases |
| Legacy HVP CPU/Node/Chrome inventory | 720 cases each; 676 direct native, four precision controls, 40 polynomial extensions |
| Current application CPU | {report['full_cpu']['passed']:,} passed |
| Full browser catalog | {local['catalog_modules']} modules, {local['mutants']} mutants; no failed or over-budget modules |
| Frontend | {local['frontend_commands']} check commands, Worker derivation and two build profiles |
| Previous immutable assets | {report['export_identity']['preserved_assets']:,} preserved byte-for-byte |
| New export assets | {report['export_identity']['new_assets']} reachable content-addressed assets |

The JVP numeric inventory is paired to the previously qualified public 0.72
rows at their original tolerances. It retains the independent normalization and
singular-determinant graph controls described in the iteration-72 report; these
are not literal native graph matches or a newly executed native oracle.
Four extra CPU mutation probes remain explicitly unsupported and separate from
the 2,304-case inventory. Source hashes, imported/executed helper paths, original
prototype versions and all failed/intermediate snapshots are retained.

The integration base is `{report['upstream']}`. Application/frontend inputs,
release policies and generated Worker derivation were checked against their
recorded identities. Local validation does not itself prove main adoption or
deployment; remote adoption is recorded separately. No CI, tag or release was
requested by these checks.
{frontend_note}

## CPU and WASM latency

Both sides call the **same public APIs**: released 0.72 is A, its same-source
control is A′, selected 0.73 is B. There is no composed JVP baseline. Ten JVP
workflows include single-Tensor/one-Tensor-tuple input forms, `nn.Parameter`
arguments, graph results, linear and normalization callbacks. Twenty additional
public workflows cover established behavior.

Each runtime has six fresh processes and every source-load permutation, with
twelve balanced common batches of at least 20 ms per workflow. Numerical,
dtype/shape, alias and caller-state checks precede timing. Ratios below one mean
shorter duration. Interpret both A/A denominators and the explicit performance
review. These data do not establish universal gains or native-Torch/GPU/import-
cold-start performance.

| Runtime | JVP workflow | A′/A | B/A | B/A′ | A → B μs |
| --- | --- | --- | --- | --- | --- |
{chr(10).join(targets)}

| Runtime | Other 20 A′/A range | B/A range | B/A′ range |
| --- | --- | --- | --- |
{chr(10).join(other)}

## CPU allocation peaks

After all latency children terminated, six fresh CPU processes exercised thirteen
API workflows with all source-load permutations, equal prewarm/capture counts
and rotated workflow/call orders. The original one-process observations are
retained separately. These `tracemalloc` peaks include
retained output graphs where requested. They are not RSS, WASM/GPU memory,
latency, isolated-cause evidence or universal improvement claims.

The additional controls show 0.8–3.7% lower tracked peaks for these JVP fixtures.
The three existing HVP fixtures show 0.24%, 0.85% and 1.25% higher peaks; this
tradeoff is retained and is not described as a memory improvement.

| Workflow | A′/A peak | B/A peak |
| --- | --- | --- |
{chr(10).join(memory)}

## Reproduction evidence

Machine report: `packages/stridetorch/benchmarks/results/iteration-73.json`.
Raw harness `{archive['name']}`: {archive['bytes']:,} bytes,
SHA-256 `{archive['sha256']}`. It contains {archive['files']:,} logical files,
{archive['unique_payloads']:,} unique mode/ownership-compatible payloads and
{archive['hardlinks']:,} deduplicated hardlinks. Every logical extracted payload
was verified. Scripts retain absolute paths and require dependency/path setup;
virtual environments are not bundled.
'''
(repo/'docs/validation/torch-runtime-iteration-73.md').write_text(text)
print('Wrote0.73 terminal-evidence human report')
