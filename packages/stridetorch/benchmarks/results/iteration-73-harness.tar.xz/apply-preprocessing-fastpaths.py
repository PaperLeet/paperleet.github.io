"""Avoid generators for single Tensor validation and unused strict-mode sets."""
from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;p=r/'candidate/packages/stridetorch';q=p/'src/stridetorch/_autograd.py'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
freeze=json.loads((r/'source-freeze.json').read_text())
assert sha(q)==freeze['source_hashes']['_autograd.py']
backup=r/'before-single-tensor-fastpaths';backup.mkdir()
shutil.copytree(r/'candidate',backup/'candidate',ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
for name in ['source-freeze.json','state.json','focused-subclass-fixed-sdk.log','cpu-equivalence-subclass-fixed.log']:
    shutil.copy2(r/name,backup/name)
shutil.move(str(r/'cpu-equivalence'),str(backup/'cpu-equivalence'))
code=q.read_text();start=code.index('def _functional_jvp_tensors(');end=code.index('\ndef _functional_jvp_prepare(',start)
code=code[:start]+'''def _functional_jvp_tensors(value, name):
    if isinstance(value, tuple):
        if any(not isinstance(item, _tensor.Tensor) for item in value):
            raise TypeError(name + ' must be a Tensor or a tuple of Tensors')
        return value, True
    if not isinstance(value, _tensor.Tensor):
        raise TypeError(name + ' must be a Tensor or a tuple of Tensors')
    return (value,), False

'''+code[end:]
needle='        private_seeds = set()\n        if strict:\n            prepared = []'
assert code.count(needle)==1
code=code.replace(needle,'        private_seeds = None\n        if strict:\n            private_seeds = set()\n            prepared = []')
compile(code,str(q),'exec');q.write_text(code)
freeze['source_hashes']['_autograd.py']=sha(q)
freeze['intended_change']+=' Single-Tensor validation avoids a generator; default non-strict calls do not allocate a private-seed set. Tuple priority and all error checks retained.'
(r/'source-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
print('Applied isolated single-Tensor/default-mode allocation fast paths; no performance claim')
