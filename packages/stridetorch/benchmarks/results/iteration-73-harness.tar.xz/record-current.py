"""Record the exact current prototype after focused and CPU-equivalence checks."""
from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent;p=r/'candidate/packages/stridetorch';read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
freeze=read(r/'source-freeze.json');proof=read(r/'cpu-equivalence/qualification.json')
assert proof['status']=='selected_072_cpu_equivalence_passed' and proof['source_hashes']==freeze['source_hashes'] and not proof['failures']
for key,directory in [('source_hashes','src/stridetorch'),('test_hashes','tests')]:
    for name,digest in freeze[key].items():assert sha(p/directory/name)==digest
assert '522 passed' in (r/'focused-fastpaths-sdk.log').read_text()
state=dict(status='focused_cpu_and_qualified_baseline_equivalence_passed',version_literal='0.72.0',release_selected=False,
 source_hashes=freeze['source_hashes'],test_hashes=freeze['test_hashes'],focused_sdk_cases=522,subclass_regression_cases=128,cpu_inventory_equivalence_cases=2304,
 evidence_sha256={name:sha(r/name) for name in ['source-freeze.json','focused-fastpaths-sdk.log','cpu-equivalence/qualification.json','cpu-equivalence-fastpaths.log',
 'probe-subclass-preprocess.py','subclass-preprocess-before.json','subclass-preprocess-fixed.json',Path(__file__).name]},
 findings=['Helpers and dtype tuple are shared rather than rebuilt on every call.',
 'Exact Tensor leaves get their final gradient metadata at construction;Tensor subclasses retain detach/requires_grad_ dispatch.',
 'Single-Tensor validation keeps every type check without allocating a generator;non-strict calls no longer allocate a private-seed set.',
 'An initial prototype bypassed three observed subclass detach calls. Preserved source/proofs and128regression cases document the correction.',
 'Each inventory child records imported module path,actual61resource hashes and executed helper source path. Original2304reference boundaries/tolerances retained.'],
 limitations=['No fullSDK,WASM,minimum installed package,performance or application qualification yet. No speedup claim.',
 'Baseline was the selected0.72candidate,not main-adopted at creation. Exact baseline source identity retained.'],
 main_adopted=False,ci_triggered=False,active_processes=[],
 next_steps=['Complete0.72latest-main integration and guarded adoption independently.',
 'After all heavy0.72jobs terminate,qualify fullCPU/WASM SDK,minimum package and controlled performance before selecting a further release.'])
(r/'state.json').write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps(dict(status=state['status'],focused=522,paired_cpu=2304,source_files=len(freeze['source_hashes']),test_files=len(freeze['test_hashes']))))
