"""Prepare matched public0.72/selected0.73 workflows,including single Tensor and Parameter cases."""
from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;p=r/'performance';a=p/'assets';a.mkdir(parents=True)
repo=Path('/Users/david/Developer/PaperLeet-torch-release');old=r.parent/'torch-iteration-72/performance'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();manifest=lambda q:{f.name:sha(f) for f in q.iterdir() if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']}
freeze=json.loads((r/'selected-release/source-freeze.json').read_text())
assert not subprocess.check_output(['git','status','--porcelain','-z'],cwd=repo)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
for label,origin in [('baseline',repo/'packages/stridetorch/src/stridetorch'),('jacobian_baseline',repo/'packages/stridetorch/src/stridetorch'),
 ('candidate',r/'selected-release/snapshot/packages/stridetorch/src/stridetorch')]:
    shutil.copytree(origin,a/label/'stridetorch',ignore=shutil.ignore_patterns('__pycache__'))
hashes={label:manifest(a/label/'stridetorch') for label in ['baseline','candidate','jacobian_baseline']};hashes['duplicate']=hashes['baseline']
assert hashes['candidate']==freeze['source_hashes'] and hashes['baseline']==freeze['baseline_source_hashes']
for name,digest in hashes['baseline'].items():assert hashlib.sha256(subprocess.check_output(['git','show',head+':packages/stridetorch/src/stridetorch/'+name],cwd=repo)).hexdigest()==digest
program=(old/'assets/bench_vjp.py').read_text()
start=program.index('def build_functional_jvp(');end=program.index('\ndef run(',start)
factory=program[start:end]
needle=" t=module.torch;rng=np.random.default_rng(7231);counter=[0];graph=case=='functional_jvp_graph_scalar'"
assert needle in factory
factory=factory.replace(needle,""" t=module.torch;rng=np.random.default_rng(7231);counter=[0]
 tensor_inputs=case.endswith('_tensor');parameter_inputs=case=='functional_jvp_parameter_linear'
 if tensor_inputs:case=case.removesuffix('_tensor')
 if parameter_inputs:case='functional_jvp_linear'
 graph=case=='functional_jvp_graph_scalar'""")
needle=" values=tuple(t.tensor(a,dtype=getattr(t,dtype),requires_grad=graph or bool(i%2)) for i,a in enumerate(arrays))"
assert needle in factory
factory=factory.replace(needle,needle+"\n if parameter_inputs:values=tuple(t.nn.Parameter(value,requires_grad=value.requires_grad) if i else value for i,value in enumerate(values))")
fs=factory.index(' def fn():');fe=factory.index(' def capture():',fs)
factory=factory[:fs]+''' def fn():
  return t.autograd.functional.jvp(callback,values[0] if tensor_inputs else values,
                                   directions[0] if tensor_inputs else directions,create_graph=graph)
'''+factory[fe:]
program=program[:start]+factory+program[end:]
needle="'functional_jvp_instancenorm']))"
assert needle in program
program=program.replace(needle,"'functional_jvp_instancenorm','functional_jvp_scalar_tensor','functional_jvp_graph_scalar_tensor','functional_jvp_parameter_linear']))")
program=program.replace("'Qualified pure-callback composition of released0.71 public AD; not an existing functional JVP API' if family=='functional_jvp' else 'Released0.71 public API on both sides'", "'Released0.72 public API on both sides'")
program=program.replace('Twenty released0.71 public API flows and seven independently checked pure-callback JVP compositions.',
 'Thirty released0.72 public API flows,including ten functionalJVP workflows with public API calls on both sides.')
program=program.replace('Twenty public0.71API regression flows and seven qualified new functionalJVP workflows.',
 'Thirty public0.72API workflows against selected0.73candidate;no composed JVP baseline.')
compile(program,str(a/'bench_vjp.py'),'exec');(a/'bench_vjp.py').write_text(program)
plan=dict(source_hashes=hashes,programs={'bench_vjp.py':sha(a/'bench_vjp.py')},baseline_main=head,baseline_version='0.72.0',candidate_version='0.73.0',flows=30,
 scope='Same public APIs on both sides:20existing regression flows and10functionalJVP flows,including single-Tensor,one-Tensor tuple,Parameter subclass and graph-result forms. No hand-composition reference.')
(a/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for name in ['bench-node.mjs','bench-chrome.mjs','assets/worker.mjs']:
    code=(old/name).read_text().replace('rows.length,27','rows.length,30').replace('/torch-iteration-72/performance/','/torch-iteration-73/performance/')
    target=p/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(code)
shutil.copy2(old/'assets/index.html',a/'index.html')
code=(old/'run.py').read_text().replace('==27','==30').replace('range(27)','range(30)').replace('flows_per_child=27','flows_per_child=30').replace('FRESH27-FLOW','FRESH30-FLOW')
code=code.replace('Twenty existing public0.71API flows and seven independently checked pure-callback JVP compositions of released0.71 public AD primitives. The new functionalJVP API has no released0.71 counterpart.',
 'Thirty existing public0.72API workflows,including10functionalJVP flows using the same public APIs on both sides. No composed baseline.')
compile(code,str(p/'run.py'),'exec');(p/'run.py').write_text(code)
print('Prepared18fresh CPU/Node/Chrome AA/B children with30matched public API flows;no timing started')
