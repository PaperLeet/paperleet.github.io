"""Create0.73 qualification candidate; adoption remains conditional on measured merit."""
from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;proof=json.loads((r/'prototype-validation.json').read_text())
assert proof['status']=='prototype_cpu_wasm_minimum_package_qualified'
v=r/'selected-release';v.mkdir();package=v/'snapshot/packages/stridetorch'
shutil.copytree(r/'candidate/packages/stridetorch',package,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
for name in ['pyproject.toml','src/stridetorch/__init__.py']:
    q=package/name;code=q.read_text();assert code.count('0.72.0')==1;q.write_text(code.replace('0.72.0','0.73.0'))
with (package/'README.md').open('a') as output:
    output.write('''

Version 0.73 preserves the functional-JVP API while sharing its validation
helpers and dtype descriptors across calls. Single-Tensor validation avoids a
temporary generator, and non-strict calls avoid allocating strict-mode tracking
sets. Private base-Tensor leaves receive their final gradient metadata at
construction; Tensor subclasses retain their `detach`/`requires_grad_` dispatch.
The existing strict checks, caller isolation, cast behavior and returned reverse
graphs remain covered by the SDK and numeric inventories. Performance results
are scoped to the workflows and runtimes recorded in the validation report.
''')
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
source={q.name:sha(q) for q in (package/'src/stridetorch').iterdir() if q.suffix=='.py' or q.name in ['LICENSE','NOTICE']}
tests={q.name:sha(q) for q in (package/'tests').glob('test_*.py')}
assert {name for name in source if source[name]!=proof['source_hashes'][name]}=={'__init__.py'} and tests==proof['test_hashes']
freeze=dict(version='0.73.0',source_hashes=source,test_hashes=tests,package_hashes={n:sha(package/n) for n in ['pyproject.toml','README.md','LICENSE','NOTICE']},
 baseline_source_hashes=json.loads((r/'source-freeze.json').read_text())['baseline_source_hashes'],
 prototype_qualification_sha256=sha(r/'prototype-validation.json'),scope='Version/README selection for finalqualification. No adoption or measured-performance decision yet.')
(v/'source-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
print(json.dumps(dict(status='candidate_selected_for_qualification',version='0.73.0',source_files=61,test_files=75)))
