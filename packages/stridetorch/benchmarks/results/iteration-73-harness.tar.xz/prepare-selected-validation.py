"""Prepare exact-version0.73 SDK,package and numerical qualification inputs."""
from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;v=r/'selected-release';p=v/'package-proof';p.mkdir()
repo=Path('/Users/david/Developer/PaperLeet-torch-release');package=v/'snapshot/packages/stridetorch'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();freeze=json.loads((v/'source-freeze.json').read_text())
prototype=json.loads((r/'prototype-validation.json').read_text());assert prototype['status']=='prototype_cpu_wasm_minimum_package_qualified'
freeze['baseline_source_hashes']=json.loads((r/'source-freeze.json').read_text())['baseline_source_hashes']
(v/'source-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
source=freeze['source_hashes'];tests=freeze['test_hashes']
assert len(source)==61 and len(tests)==75
for name,digest in source.items():assert sha(package/'src/stridetorch'/name)==digest
assert not subprocess.check_output(['git','status','--porcelain','-z'],cwd=repo)
names=[n for n in subprocess.check_output(['git','ls-files','-z','--','paperleet','pyproject.toml','setup.py','LICENSE','NOTICE','README.md','MANIFEST.in'],cwd=repo).decode().split('\0') if n]
app={}
for name in names:
    target=v/'snapshot'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/name,target)
    if name.startswith('paperleet/') and (name.endswith('.py') or name=='paperleet/interview_catalog.json'):app[name]=sha(repo/name)
assert len(app)==37
(p/'application-source-hashes.json').write_text(json.dumps(app,indent=2)+'\n')
(p/'application-fixture.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),files={n:sha(repo/n) for n in names}),indent=2)+'\n')
(p/'source-hashes.json').write_text(json.dumps(source,indent=2)+'\n')
for name in ['check-wheel.py','check-coinstall.py','fresh-load.py']:
    code=(r/'package-validation/package-proof'/name).read_text().replace('0.72.0','0.73.0').replace('stride072','stride073')
    compile(code,str(p/name),'exec');(p/name).write_text(code)
code=(r/'package-validation/run-package-proof.py').read_text().replace('0.72.0','0.73.0').replace('stride072','stride073')
compile(code,str(v/'run-package-proof.py'),'exec');(v/'run-package-proof.py').write_text(code)
# SDK fixtures are copied from the selected snapshot, not the prototype source.
w=v/'wasm-proof';c=w/'chrome-contracts';c.mkdir(parents=True)
for name in ['node.mjs','sdk.py']:shutil.copy2(r/'wasm-proof'/name,w/name)
for name in ['worker.mjs','run.mjs','index.html']:
    code=(r/'wasm-proof/chrome-contracts'/name).read_text().replace('../../../','../../../../').replace('/torch-iteration-73/wasm-proof/', '/torch-iteration-73/selected-release/wasm-proof/')
    (c/name).write_text(code)
for directory,manifest,origin in [('source',source,package/'src/stridetorch'),('tests',{k:d for k,d in tests.items() if k!='test_standalone.py'},package/'tests')]:
    (c/directory).mkdir()
    for name,digest in manifest.items():assert sha(origin/name)==digest;shutil.copy2(origin/name,c/directory/name)
plan=dict(source=source,tests={k:d for k,d in tests.items() if k!='test_standalone.py'},version='0.73.0',prototype_iteration=73,expected=8838,
          scope='Exact selected0.73candidate SDK. Adoption depends on final correctness and measured merit.')
(c/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for folder in ['numerical-wasm','legacy-hvp-wasm']:
    q=v/folder;q.mkdir();shutil.copytree(c/'source',q/'source');shutil.copytree(r/folder/'fixtures',q/'fixtures')
    plan=json.loads((r/folder/'plan.json').read_text());plan['source']=source;plan['version']='0.73.0'
    (q/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
    for name in ['node.mjs','replay.py']:(q/name).write_text((r/folder/name).read_text().replace('0.72.0','0.73.0'))
    shutil.copytree(r/folder/'chrome',q/'chrome',ignore=shutil.ignore_patterns('result.json'))
    for name in ['worker.mjs','run.mjs']:
        target=q/'chrome'/name;target.write_text(target.read_text().replace('../../../','../../../../').replace('/torch-iteration-73/'+folder+'/', '/torch-iteration-73/selected-release/'+folder+'/').replace('0.72.0','0.73.0'))
code=(r/'qualify-cpu-equivalence.py').read_text().replace("p=r/'cpu-equivalence'","p=r/'selected-release/cpu-equivalence'").replace(
 "source=r/'candidate/packages/stridetorch/src'","source=r/'selected-release/snapshot/packages/stridetorch/src'").replace(
 "freeze=read(r/'source-freeze.json')","freeze=read(r/'selected-release/source-freeze.json')").replace('selected_072_cpu_equivalence_passed','public_072_cpu_equivalence_passed')
compile(code,str(r/'qualify-selected-cpu-equivalence.py'),'exec');(r/'qualify-selected-cpu-equivalence.py').write_text(code)
code=(r/'replay-legacy-hvp-cpu.py').read_text().replace("r / 'legacy-hvp-cpu'","r / 'selected-release/legacy-hvp-cpu'").replace(
 "r / 'candidate/packages/stridetorch/src/stridetorch'","r / 'selected-release/snapshot/packages/stridetorch/src/stridetorch'").replace(
 "r/'source-freeze.json'","r/'selected-release/source-freeze.json'").replace("plan['version'] = '0.72.0'","plan['version'] = '0.73.0'")
(r/'replay-selected-legacy-hvp-cpu.py').write_text(code)
code=(r/'run-wasm-tail.py').read_text().replace('r=Path(__file__).resolve().parent','r=Path(__file__).resolve().parent/\'selected-release\'').replace(
 "r/'candidate/packages/stridetorch/src/stridetorch'","r/'snapshot/packages/stridetorch/src/stridetorch'")
(r/'run-selected-wasm-tail.py').write_text(code)
print('Prepared selected0.73 SDK8838,minpackage8851,CPU/Node/Chrome JVP2304 andlegacyHVP720 checks')
