"""Reproduce the preserved subclass-dispatch gap or check the current prototype."""
from pathlib import Path
import importlib.util,json,sys
import numpy as np
r=Path(__file__).resolve().parent
candidate=r/('before-subclass-preprocess-fix/candidate' if '--before' in sys.argv else 'candidate')/'packages/stridetorch/src/stridetorch'
baseline=r.parent/'torch-iteration-72/selected-release/snapshot/packages/stridetorch/src/stridetorch'
rows=[]
for label,path in [('baseline',baseline),('candidate',candidate)]:
    name='_subclass_'+label
    spec=importlib.util.spec_from_file_location(name,path/'__init__.py',submodule_search_locations=[str(path)])
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);t=module.torch
    for graph in [False,True]:
        for gx in [False,True]:
            calls=[]
            class Spy(t.Tensor):
                def detach(self):calls.append('detach');return super().detach()
            x=Spy(np.array([2.,3.]),requires_grad=gx);v=t.ones_like(x)
            y,d=t.autograd.functional.jvp(lambda a:a.square(),x,v,create_graph=graph)
            rows.append(dict(label=label,graph=graph,gx=gx,calls=calls,value=y.detach().tolist(),direction=d.detach().tolist()))
print(json.dumps(rows,indent=2))
