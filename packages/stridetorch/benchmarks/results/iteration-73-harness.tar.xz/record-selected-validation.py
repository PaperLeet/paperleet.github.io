"""Verify exact0.73 candidate qualification before any timing experiment."""
from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent;v=r/'selected-release';read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
f=read(v/'source-freeze.json');source=f['source_hashes'];tests=f['test_hashes'];assert f['version']=='0.73.0'
for key,directory in [('source_hashes','src/stridetorch'),('test_hashes','tests')]:
    for name,digest in f[key].items():assert sha(v/'snapshot/packages/stridetorch'/directory/name)==digest
for name,digest in f['package_hashes'].items():assert sha(v/'snapshot/packages/stridetorch'/name)==digest
for name in ['node-result.json','chrome-contracts/result.json']:
    q=read(v/'wasm-proof'/name)
    assert q['status']=='success' and q['passed']==8838 and q['suites']==74 and q['library']=='0.73.0' and not q['failures']
    assert q['source_hashes']==source and q['test_hashes']=={k:d for k,d in tests.items() if k!='test_standalone.py'}
    assert q['pyodide']=='0.29.4' and q['numpy']=='2.2.5'
for name in ['node-result.json','chrome/result.json']:
    q=read(v/'numerical-wasm'/name);assert q['status']=='success' and q['cases']==2304 and q['source_hashes']==source and not q['failures']
for folder,name in [('legacy-hvp-cpu','result.json'),('legacy-hvp-wasm','node-result.json'),('legacy-hvp-wasm','chrome/result.json')]:
    q=read(v/folder/name)
    assert q['status']=='success' and q['cases']==720 and q['source_hashes']==source and not q['failures']
    assert q['direct_native_cases']==676 and len(q['independent_precision_controls'])==4 and len(q['polynomial_extension_controls'])==40
q=read(v/'cpu-equivalence/qualification.json');assert q['status']=='public_072_cpu_equivalence_passed' and q['source_hashes']==source and not q['failures']
package=read(v/'package-proof/package-identity.json')
assert package['status']=='success' and package['source_hashes']==source and package['standalone_installed_tests']==8851
assert package['python']=='3.10.19' and package['numpy']=='1.26.4' and package['native_torch'] is False
for name,digest in package['artifacts'].items():assert sha(v/'package-proof'/name)==digest
assert '8851 passed' in (v/'package-proof/python310-stride073-tests.log').read_text()
evidence={}
for q in v.rglob('*'):
    if not q.is_file() or any(part in ['snapshot','coinstall-env','python310-stride073-env','python310-stride073-tests','runtime','__pycache__'] for part in q.relative_to(v).parts):continue
    if q.suffix in ['.json','.log','.py','.mjs','.html','.whl','.gz'] and q.name!='core-and-package-proof.json':evidence[str(q.relative_to(v))]=sha(q)
result=dict(status='selected_version_cpu_wasm_minimum_package_qualified',version='0.73.0',source_hashes=source,test_hashes=tests,
 minimum_installed_sdk_cases=8851,wasm_sdk_cases_per_runtime=8838,wasm_suites=74,cpu_wasm_jvp_cases_per_runtime=2304,legacy_hvp_cases_per_runtime=720,
 jvp_reference_classification=dict(direct_native_qualified=2184,independent_math_controls=88,explicit_unsupported_hooks=32),
 evidence_sha256=evidence,scope='Exact0.73candidate,CPU equivalence to qualified public0.72rows,minimum NumPy-only installed SDK,realNode/Chrome SDK/JVP/HVP references,package ownership and freshpickle. No latency gain/application/main-adoption claim.')
(v/'core-and-package-proof.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],minimum_sdk=8851,wasm_sdk=8838,jvp=2304,hvp=720)))
