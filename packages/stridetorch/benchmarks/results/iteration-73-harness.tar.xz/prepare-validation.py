"""Freeze independent prototype SDK/package and actual WASM qualification inputs."""
from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-72/selected-release'
repo=Path('/Users/david/Developer/PaperLeet-torch-release');package=r/'candidate/packages/stridetorch'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();freeze=json.loads((r/'source-freeze.json').read_text())
source=freeze['source_hashes'];tests=freeze['test_hashes']
assert len(source)==61 and len(tests)==75
for name,digest in source.items():assert sha(package/'src/stridetorch'/name)==digest
for name,digest in tests.items():assert sha(package/'tests'/name)==digest
w=r/'wasm-proof';c=w/'chrome-contracts';c.mkdir(parents=True)
for name in ['node.mjs','sdk.py']:shutil.copy2(old/'wasm-proof'/name,w/name)
for name in ['worker.mjs','run.mjs','index.html']:
    code=(old/'wasm-proof/chrome-contracts'/name).read_text().replace('../../../../','../../../').replace(
      '/torch-iteration-72/selected-release/wasm-proof/','/torch-iteration-73/wasm-proof/')
    (c/name).write_text(code)
for directory,manifest,origin in [('source',source,package/'src/stridetorch'),('tests',{k:v for k,v in tests.items() if k!='test_standalone.py'},package/'tests')]:
    (c/directory).mkdir()
    for name,digest in manifest.items():assert sha(origin/name)==digest;shutil.copy2(origin/name,c/directory/name)
plan=dict(source=source,tests={k:v for k,v in tests.items() if k!='test_standalone.py'},version='0.72.0',prototype_iteration=73,expected=8838,
          scope='Unreleased preprocessing prototype,version literal0.72.0. Existing public0.72baseline is separate. FullSDK only;not performance/release/main qualification.')
(c/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
# The same standalone and privately vendored code must be built together.
v=r/'package-validation';p=v/'package-proof';p.mkdir(parents=True)
snapshot=v/'snapshot';shutil.copytree(package,snapshot/'packages/stridetorch',ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
assert not subprocess.check_output(['git','status','--porcelain','-z'],cwd=repo)
names=[n for n in subprocess.check_output(['git','ls-files','-z','--','paperleet','pyproject.toml','setup.py','LICENSE','NOTICE','README.md','MANIFEST.in'],cwd=repo).decode().split('\0') if n]
application={}
for name in names:
    target=snapshot/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/name,target)
    if name.startswith('paperleet/') and (name.endswith('.py') or name=='paperleet/interview_catalog.json'):application[name]=sha(repo/name)
assert len(application)==37
(p/'application-source-hashes.json').write_text(json.dumps(application,indent=2)+'\n')
(p/'application-fixture.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),files={n:sha(repo/n) for n in names}),indent=2)+'\n')
(p/'source-hashes.json').write_text(json.dumps(source,indent=2)+'\n')
for name in ['check-wheel.py','check-coinstall.py','fresh-load.py']:
    code=(old/'package-proof'/name).read_text().replace('8723','8851')
    compile(code,str(p/name),'exec');(p/name).write_text(code)
code=(old/'run-package-proof.py').read_text().replace('8723','8851')
code=code.replace('Actual current application including GraphSAGE interview catalog, version0.72.0 runtime and final README',
 'Unreleased preprocessing prototype with0.72version literal and exact current application')
compile(code,str(v/'run-package-proof.py'),'exec');(v/'run-package-proof.py').write_text(code)
print(json.dumps(dict(status='prepared',source_files=61,test_files=75,wasm_cases=8838,minimum_installed_cases=8851,release_selected=False)))
