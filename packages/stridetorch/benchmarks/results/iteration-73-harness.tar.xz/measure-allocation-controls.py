"""Resolve bounded allocation variation with fresh balanced source/call-order controls."""
from pathlib import Path
import gc,hashlib,importlib.util,itertools,json,os,statistics,subprocess,sys,tracemalloc
import numpy as np
r=Path(__file__).resolve().parent;p=r/'performance';a=p/'assets';out=p/'allocation-controls'
read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
plan=read(a/'plan.json');latency=read(p/'summary.json')
assert latency['status']=='completed' and latency['fresh_children']==18 and latency['source_hashes']==plan['source_hashes']
assert len(read(p/'results/receipts.json'))==18 and all(x['exit_code']==0 for x in read(p/'results/receipts.json'))
labels=['baseline','duplicate','candidate'];orders=list(itertools.permutations(labels))
cases=['functional_jvp_scalar','functional_jvp_graph_scalar','functional_jvp_unused','functional_jvp_linear',
       'functional_jvp_layernorm','functional_jvp_batchnorm','functional_jvp_instancenorm','functional_jvp_scalar_tensor',
       'functional_jvp_graph_scalar_tensor','functional_jvp_parameter_linear','hvp_scalar','hvp_linear','hvp_unused']
if '--child' in sys.argv:
    cycle=int(sys.argv[sys.argv.index('--child')+1]);load_order=orders[cycle]
    spec=importlib.util.spec_from_file_location('_allocation_control_bench',a/'bench_vjp.py');bench=importlib.util.module_from_spec(spec);spec.loader.exec_module(bench)
    modules={}
    for label in load_order:
        modules[label],actual=bench.load('_allocationctrl_'+label,a/('candidate' if label=='candidate' else 'baseline')/'stridetorch')
        assert actual==plan['source_hashes'][label]
    case_order=cases[cycle:]+cases[:cycle]
    if cycle%2:case_order=list(reversed(case_order))
    rows=[]
    for case in case_order:
        factory=bench.build_hvp if case.startswith('hvp_') else bench.build_functional_jvp
        entries={label:factory(modules[label],case,label=='candidate') for label in load_order}
        captures={label:entries[label][1]() for label in load_order}
        for label in labels:
            assert len(captures[label])==len(captures['baseline'])
            for x,y in zip(captures[label],captures['baseline']):np.testing.assert_allclose(x,y,rtol=3e-5,atol=3e-6)
        del captures
        # Equal prewarm counts; no extra baseline-only capture. Rotate labels.
        for offset in range(3):
            for label in labels[offset:]+labels[:offset]:
                value=entries[label][0]();del value
        samples=[]
        for order in orders[cycle:]+orders[:cycle]:
            for label in order:
                gc.collect();tracemalloc.start();tracemalloc.reset_peak()
                value=entries[label][0]();current,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
                samples.append(dict(order=list(order),label=label,current_bytes=current,peak_bytes=peak))
                del value
        med={label:statistics.median(x['peak_bytes'] for x in samples if x['label']==label) for label in labels}
        rows.append(dict(case=case,samples=samples,median_peak_bytes=med,
                         candidate_over_baseline_peak=med['candidate']/med['baseline'],
                         duplicate_over_baseline_peak=med['duplicate']/med['baseline'],
                         candidate_over_duplicate_peak=med['candidate']/med['duplicate']))
    print(json.dumps(dict(status='passed',cycle=cycle,load_order=list(load_order),case_order=case_order,rows=rows,
                          source_hashes=plan['source_hashes'],program_sha256=sha(Path(__file__)),benchmark_program_sha256=sha(a/'bench_vjp.py'))))
else:
    out.mkdir();receipts=[];env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
    for cycle in range(6):
        path=out/f'cpu-{cycle}.json'
        with path.open('w') as output,(out/f'cpu-{cycle}.log').open('w') as error:
            child=subprocess.run([sys.executable,str(Path(__file__)), '--child',str(cycle)],env=env,stdout=output,stderr=error)
        receipts.append(dict(cycle=cycle,exit_code=child.returncode,result_sha256=sha(path)))
        (out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');child.check_returncode()
        print('allocation-control',cycle,'TERMINAL0',flush=True)
    children=[read(out/f'cpu-{cycle}.json') for cycle in range(6)];rows=[]
    for case in cases:
        samples=[next(x for x in child['rows'] if x['case']==case) for child in children]
        med={key:statistics.median(x[key] for x in samples) for key in ['candidate_over_baseline_peak','duplicate_over_baseline_peak','candidate_over_duplicate_peak']}
        rows.append(dict(case=case,**med,child_ratios={key:[x[key] for x in samples] for key in med}))
    result=dict(status='completed',fresh_cpu_processes=6,source_hashes=plan['source_hashes'],rows=rows,
                original_allocation_sha256=sha(p/'api-memory.json'),program_sha256=sha(Path(__file__)),
                scope='Additional controls after original one-process variation:all6source loadorders,equal prewarm/capture counts,rotated workflow/call orders. Same13fixtures,rawsamples retained. Tracemalloc only;not RSS,WASM/GPU memory or latency.')
    (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(status='completed',fresh_cpu_processes=6,ratios={x['case']:x['candidate_over_baseline_peak'] for x in rows})))
