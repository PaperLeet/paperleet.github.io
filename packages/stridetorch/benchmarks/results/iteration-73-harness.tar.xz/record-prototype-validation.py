"""Close exact0.72-literal prototype validation before candidate version selection."""
from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent;read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
f=read(r/'source-freeze.json');source=f['source_hashes'];tests=f['test_hashes']
for key,directory in [('source_hashes','src/stridetorch'),('test_hashes','tests')]:
    for name,digest in f[key].items():assert sha(r/'candidate/packages/stridetorch'/directory/name)==digest
assert '8851 passed, 1 warning' in (r/'full-sdk.log').read_text()
for name in ['node-result.json','chrome-contracts/result.json']:
    q=read(r/'wasm-proof'/name)
    assert q['status']=='success' and q['passed']==8838 and q['suites']==74 and not q['failures']
    assert q['source_hashes']==source and q['test_hashes']=={k:v for k,v in tests.items() if k!='test_standalone.py'} and q['library']=='0.72.0'
for name in ['node-result.json','chrome/result.json']:
    q=read(r/'numerical-wasm'/name);assert q['status']=='success' and q['cases']==2304 and not q['failures'] and q['source_hashes']==source
for directory,name in [('legacy-hvp-cpu','result.json'),('legacy-hvp-wasm','node-result.json'),('legacy-hvp-wasm','chrome/result.json')]:
    q=read(r/directory/name)
    assert q['status']=='success' and q['cases']==720 and q['source_hashes']==source and not q['failures']
package=read(r/'package-validation/package-proof/package-identity.json')
assert package['status']=='success' and package['source_hashes']==source and package['standalone_installed_tests']==8851
assert package['python']=='3.10.19' and package['numpy']=='1.26.4' and package['native_torch'] is False
for name,digest in package['artifacts'].items():assert sha(r/'package-validation/package-proof'/name)==digest
cpu=read(r/'cpu-equivalence/qualification.json');assert cpu['status']=='selected_072_cpu_equivalence_passed' and cpu['source_hashes']==source
result=dict(status='prototype_cpu_wasm_minimum_package_qualified',version_literal='0.72.0',release_selected=False,source_hashes=source,test_hashes=tests,
 cpu_sdk_cases=8851,wasm_sdk_cases_per_runtime=8838,wasm_suites=74,jvp_inventory_cases_per_runtime=2304,legacy_hvp_cases_per_runtime=720,
 evidence_sha256={name:sha(r/name) for name in ['source-freeze.json','full-sdk.log','wasm-proof/node-result.json','wasm-proof/chrome-contracts/result.json',
 'numerical-wasm/node-result.json','numerical-wasm/chrome/result.json','legacy-hvp-cpu/result.json','legacy-hvp-wasm/node-result.json','legacy-hvp-wasm/chrome/result.json',
 'cpu-equivalence/qualification.json','package-validation/package-proof/package-identity.json','wasm-tail-receipts.json',Path(__file__).name]},
 scope='Unreleased0.72-literal optimization prototype,completeSDK and minimuminstalled package,paired baseline behavior inventories and adoptedHVP references. No performance or main-adoption claim.')
(r/'prototype-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],cpu=8851,wasm=8838,jvp=2304,hvp=720)))
