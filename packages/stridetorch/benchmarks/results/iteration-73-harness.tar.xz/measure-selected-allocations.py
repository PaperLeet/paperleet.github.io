"""Bounded CPU API allocation peaks, only after all latency children terminate."""
from pathlib import Path
import gc,hashlib,importlib.util,itertools,json,statistics,tracemalloc
import numpy as np
r=Path(__file__).resolve().parent;p=r/'performance';a=p/'assets'
read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
summary=read(p/'summary.json');receipts=read(p/'results/receipts.json');plan=read(a/'plan.json')
assert summary['status']=='completed' and len(receipts)==18 and all(row['exit_code']==0 for row in receipts)
assert summary['source_hashes']==plan['source_hashes']
spec=importlib.util.spec_from_file_location('_selected_allocations',a/'bench_vjp.py');bench=importlib.util.module_from_spec(spec);spec.loader.exec_module(bench)
assert sha(a/'bench_vjp.py')==plan['programs']['bench_vjp.py']
labels=['baseline','duplicate','candidate'];modules={}
for label in labels:
    modules[label],actual=bench.load('_allocation_'+label,a/('candidate' if label=='candidate' else 'baseline')/'stridetorch')
    assert actual==plan['source_hashes'][label]
cases=['functional_jvp_scalar','functional_jvp_graph_scalar','functional_jvp_unused','functional_jvp_linear',
       'functional_jvp_layernorm','functional_jvp_batchnorm','functional_jvp_instancenorm','functional_jvp_scalar_tensor','functional_jvp_graph_scalar_tensor','functional_jvp_parameter_linear','hvp_scalar','hvp_linear','hvp_unused']
rows=[]
for case in cases:
    factory=bench.build_hvp if case.startswith('hvp_') else bench.build_functional_jvp
    entries={label:factory(modules[label],case,label=='candidate') for label in labels}
    expected=entries['baseline'][1]()
    for label in labels:
        actual=entries[label][1]();assert len(expected)==len(actual)
        for x,y in zip(expected,actual):np.testing.assert_allclose(x,y,rtol=3e-5,atol=3e-6)
    samples=[]
    for order in itertools.permutations(labels):
        for label in order:
            gc.collect();tracemalloc.start();tracemalloc.reset_peak()
            result=entries[label][0]();current,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
            samples.append(dict(order=list(order),label=label,current_bytes=current,peak_bytes=peak))
            del result
    medians={label:statistics.median(row['peak_bytes'] for row in samples if row['label']==label) for label in labels}
    rows.append(dict(case=case,samples=samples,median_peak_bytes=medians,
                     candidate_over_baseline_peak=medians['candidate']/medians['baseline'],
                     duplicate_over_baseline_peak=medians['duplicate']/medians['baseline']))
result=dict(status='passed',source_hashes=plan['source_hashes'],program_sha256=sha(Path(__file__)),
            benchmark_program_sha256=sha(a/'bench_vjp.py'),rows=rows,
            scope='One CPU process,thirteen API workflows,six balanced call orders. Tracemalloc peaks include retained output graphs where requested. Not RSS,WASM/GPU memory,latency,isolated-cause or universal improvement evidence.')
(p/'api-memory.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status='passed',cases=len(rows),ratios={row['case']:row['candidate_over_baseline_peak'] for row in rows})))
