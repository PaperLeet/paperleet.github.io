"""Isolate JVP preprocessing work while the unchanged0.72 application gates run."""
from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent
baseline=r.parent/'torch-iteration-72/selected-release/snapshot/packages/stridetorch'
candidate=r/'candidate/packages/stridetorch'
shutil.copytree(baseline,candidate,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
manifest=lambda p:{q.name:sha(q) for q in p.iterdir() if q.suffix=='.py' or q.name in ['LICENSE','NOTICE']}
before=manifest(baseline/'src/stridetorch')
q=candidate/'src/stridetorch/_autograd.py';code=q.read_text()
start=code.index('    def tensors(value, name):',code.index('def functional_jvp('))
end=code.index('    with enable_grad():',start)
old=code[start:end]
assert 'return item.detach().requires_grad_(need_graph)' in old
helpers='''_FUNCTIONAL_JVP_REAL_DTYPES = (np.dtype('float32'), np.dtype('float64'))


def _functional_jvp_tensors(value, name):
    was_tuple = isinstance(value, tuple)
    values = value if was_tuple else (value,)
    if any(not isinstance(item, _tensor.Tensor) for item in values):
        raise TypeError(name + ' must be a Tensor or a tuple of Tensors')
    return values, was_tuple


def _functional_jvp_prepare(item, need_graph, create_graph):
    if create_graph and item.requires_grad:
        return item.view_as(item)
    # detach() constructs the same base Tensor and ndarray descriptor. Setting
    # leaf gradient metadata in that constructor avoids a second method call.
    return _tensor.Tensor(item._data, requires_grad=need_graph)


'''
code=code[:start]+code[end:]
start=code.index('def functional_jvp(');end=code.index('\ndef functional_hvp(',start)
body=code[start:end]
body=body.replace('tensors(', '_functional_jvp_tensors(')
body=body.replace('prepare(item, True)', '_functional_jvp_prepare(item, True, create_graph)')
body=body.replace('prepare(item, False)', '_functional_jvp_prepare(item, False, create_graph)')
body=body.replace("(np.dtype('float32'), np.dtype('float64'))", '_FUNCTIONAL_JVP_REAL_DTYPES')
body=body.replace('seed = seed.detach().requires_grad_(True)', 'seed = _tensor.Tensor(seed._data, requires_grad=True)')
code=code[:start]+helpers+body+code[end:]
compile(code,str(q),'exec');q.write_text(code)
after=manifest(candidate/'src/stridetorch')
assert {name for name in before if before[name]!=after[name]}=={'_autograd.py'}
freeze=dict(status='unreleased_preprocessing_prototype',version_literal='0.72.0',source_hashes=after,
 baseline_source_hashes=before,baseline_at_creation='Qualified selected0.72 candidate; main adoption still pending.',
 test_hashes={q.name:sha(q) for q in (candidate/'tests').glob('test_*.py')},
 intended_change='Hoist two per-call helpers/cache dtype constants and construct private detached leaves with final gradient metadata. No numerical/validation rule intentionally removed.',
 limitations='No performance claim or release selection. Pending CPU/native/WASM/package/application qualification. No mutation of the0.72candidate/application.')
(r/'source-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
print(json.dumps(dict(status=freeze['status'],changed=['_autograd.py'],source_files=len(after))))
