import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const root=path.dirname(new URL(import.meta.url).pathname),assets=path.join(root,'assets'),plan=JSON.parse(fs.readFileSync(path.join(assets,'plan.json'))),repo='/Users/david/Developer/PaperLeet-torch-release';
const py=await loadPyodide({indexURL:repo+'/web/node_modules/pyodide/',packageCacheDir:repo+'/web/public/browser-runtime/pyodide-0.29.4/',stdout(){},stderr(){}});await loadJudgePackages(py,[]);
for(const label of ['baseline','candidate','jacobian_baseline']){py.FS.mkdirTree('/'+label+'/stridetorch');for(const name of Object.keys(plan.source_hashes[label]))py.FS.writeFile('/'+label+'/stridetorch/'+name,fs.readFileSync(path.join(assets,label,'stridetorch',name)));}
for(const name of Object.keys(plan.programs))py.FS.writeFile('/'+name,fs.readFileSync(path.join(assets,name)));
py.globals.set('plan_json',JSON.stringify(plan));
py.globals.set('cycle',Number(process.env.CYCLE));
const code="import sys,json,pathlib,hashlib\nsys.path.insert(0,'/')\nplan=json.loads(plan_json)\nfor name,digest in plan['programs'].items():assert hashlib.sha256(pathlib.Path('/'+name).read_bytes()).hexdigest()==digest\nfrom bench_vjp import run\nresult=run('/baseline/stridetorch','/candidate/stridetorch','/jacobian_baseline/stridetorch',cycle)\nassert result['source_hashes']==plan['source_hashes']\njson.dumps(result)";
const result=JSON.parse(py.runPython(code));assert.equal(result.rows.length,30);assert.equal(result.numpy,'2.2.5');fs.writeFileSync(process.argv[2],JSON.stringify({runtime:'node',pyodide:py.version,benchmark:result},null,2)+'\n');
