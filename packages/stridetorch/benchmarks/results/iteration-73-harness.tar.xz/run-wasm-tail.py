"""Qualify real Chrome SDK and both WASM numerical inventories in serial children."""
from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent
freeze=json.loads((r/'source-freeze.json').read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
receipts=[];env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
jobs=[('chrome-sdk','wasm-proof/chrome-contracts/run.mjs'),('node-jvp','numerical-wasm/node.mjs'),
      ('chrome-jvp','numerical-wasm/chrome/run.mjs'),('node-hvp','legacy-hvp-wasm/node.mjs'),('chrome-hvp','legacy-hvp-wasm/chrome/run.mjs')]
for label,name in jobs:
    for filename,digest in freeze['source_hashes'].items():assert sha(r/'candidate/packages/stridetorch/src/stridetorch'/filename)==digest
    start=time.monotonic()
    with (r/(label+'.log')).open('w') as output:
        child=subprocess.run(['/opt/homebrew/bin/node',str(r/name)],cwd=r,env=env,stdout=output,stderr=subprocess.STDOUT)
    receipts.append(dict(label=label,script=name,exit_code=child.returncode,seconds=time.monotonic()-start,log_sha256=sha(r/(label+'.log'))))
    (r/'wasm-tail-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
    child.check_returncode()
    print(label,'TERMINAL0',flush=True)
print('REAL WASM SDK AND NUMERICAL TAIL COMPLETE',flush=True)
