from pathlib import Path
import contextlib,json,torch
from torch.nn.attention import sdpa_kernel,SDPBackend
rows=[]
for rank in [3,4]:
 for mask_kind in ['none','bool','float']:
  for backend in ['default','math']:
   shape=(2,3,4) if rank==3 else (2,2,3,4);kshape=(*shape[:-2],5,4);vshape=(*shape[:-2],5,6)
   q=torch.randn(shape,dtype=torch.float64,requires_grad=True);k=torch.randn(kshape,dtype=q.dtype,requires_grad=True);v=torch.randn(vshape,dtype=q.dtype,requires_grad=True)
   mask=None if mask_kind=='none' else torch.ones(3,5,dtype=torch.bool) if mask_kind=='bool' else torch.randn(3,5,dtype=q.dtype)
   try:
    with sdpa_kernel(SDPBackend.MATH) if backend=='math' else contextlib.nullcontext():
     y,j=torch.func.jvp(lambda a,b,c:torch.nn.functional.scaled_dot_product_attention(a,b,c,attn_mask=mask),(q,k,v),(torch.ones_like(q),torch.ones_like(k),torch.ones_like(v)))
     (y.square().sum()+j.square().sum()).backward()
    result=dict(status='success',shape=list(y.shape),finite_mixed_gradients=all(torch.isfinite(t.grad).all().item() for t in [q,k,v]))
   except Exception as e:result=dict(status='error',type=type(e).__name__,message=str(e).splitlines()[0])
   rows.append(dict(rank=rank,mask=mask_kind,backend=backend,**result))
masked=[]
for weights in [True,False]:
 m=torch.nn.MultiheadAttention(4,2,batch_first=True,dtype=torch.float64);q=torch.randn(2,3,4,dtype=torch.float64)
 y,w=m(q,q,q,attn_mask=torch.ones(3,3,dtype=torch.bool),need_weights=weights)
 masked.append(dict(need_weights=weights,output_all_nan=torch.isnan(y).all().item(),output_all_zero=(y==0).all().item(),weights_none=w is None))
r=Path(__file__).resolve().parent;(r/'next-attention-probe.json').write_text(json.dumps(dict(native=torch.__version__,jvp=rows,fully_masked_mha=masked),indent=2)+'\n');print({'jvp_successes':sum(v['status']=='success' for v in rows),'jvp_cases':len(rows),'fully_masked_mha':masked})
