from pathlib import Path
r=Path(__file__).resolve().parent
s=(r/'run-performance.py').read_text().replace('receipts={}',"receipts=json.loads((out/'receipts.json').read_text())")
old="""  start=time.monotonic()
  with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  receipts[name]=dict(args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-start);(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\\n');p.check_returncode()
"""
new="""  previous=receipts.get(name)
  if previous is None or previous['exit_code']!=0 or not output.exists():
   if previous is not None:
    failures=json.loads((out/'failed-attempts.json').read_text()) if (out/'failed-attempts.json').exists() else []
    target=out/(name+'-failed-'+str(len(failures))+'.log');(out/(name+'.log')).rename(target)
    failures.append(dict(name=name,receipt=previous,log=target.name,reason='Fixed Pyodide pytest dependency fetch failed before benchmark execution; no timing samples produced.'))
    (out/'failed-attempts.json').write_text(json.dumps(failures,indent=2)+'\\n')
   start=time.monotonic()
   with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
   receipts[name]=dict(args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-start);(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\\n');p.check_returncode()
  else:print('REUSE VERIFIED',name,flush=True)
"""
assert old in s;s=s.replace(old,new)
s=s.replace("(r/'performance-summary.json').write_text", "(r/'performance-summary.json').write_text")
exec(compile(s,str(r/'run-performance.py'),'exec'),{'__file__':str(r/'run-performance.py'),'__name__':'__main__'})
