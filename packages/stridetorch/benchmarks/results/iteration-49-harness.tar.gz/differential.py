import os,json,numpy as np
if os.environ.get('STRIDE_PROBE'):
 from stridetorch import torch,_convolution as c
 route=os.environ.get('STRIDE_ROUTE','auto');c._PADDING_ALGORITHM=route.split('-')[0]
 c._ALGORITHM='matrix' if route.endswith('matrix') else 'direct' if route.endswith('direct') else 'auto'
 if route=='capped':c._PADDING_ALGORITHM='auto';c._GATHER_WORKSPACE_BYTES=0;c._PAD_WORKSPACE_BYTES=0
else:import torch
rng=np.random.default_rng(4912);rows=[]
for dim in [1,2,3]:
 for dtype in [torch.float32,torch.float64]:
  for groups in [1,2]:
   for kind in ['halo','anisotropic','same','overlap']:
    for unbatched in [False,True]:
     shape=(2,4,*([3]*dim));kernel=(2 if kind=='same' else 3,)*dim
     raw=rng.normal(size=shape).astype(np.float32 if dtype==torch.float32 else np.float64)
     if kind=='anisotropic':raw=np.asfortranarray(raw)
     if kind=='overlap':raw=np.repeat(raw,2,axis=-1)[...,::2]
     if unbatched:raw=raw[0]
     x=torch.from_numpy(raw).requires_grad_();w=torch.tensor(rng.normal(size=(6,4//groups,*kernel)),dtype=dtype,requires_grad=True);b=torch.tensor(rng.normal(size=6),dtype=dtype,requires_grad=True)
     options=dict(padding='same' if kind=='same' else (31 if kind=='halo' else 2),dilation=31 if kind=='halo' else 3 if kind=='same' else 2,groups=groups)
     if kind=='anisotropic':options.update(stride=(2,1,3)[:dim],padding=(7,11,13)[:dim],dilation=(7,11,13)[:dim])
     fn=lambda a,c,d:getattr(torch.nn.functional,f'conv{dim}d')(a,c,d,**options)
     y=fn(x,w,b);seed=torch.tensor(rng.normal(size=y.shape),dtype=dtype);y.backward(seed)
     array=lambda t:t.detach().numpy().tolist()
     row=dict(id=f'{dim}:{str(dtype).replace("torch.","")}:{groups}:{kind}:{unbatched}',value=array(y),stride=list(y.stride()),grads=[array(v.grad) for v in [x,w,b]])
     vals=[torch.tensor(v.detach().numpy(),requires_grad=True) for v in [x,w,b]];directions=[torch.tensor(rng.normal(size=v.shape),dtype=dtype,requires_grad=True) for v in vals]
     p,t=torch.func.jvp(fn,tuple(vals),tuple(directions));(p*seed+t*seed.square()).sum().backward()
     row.update(jvp=array(t),mixed=[array(v.grad) for v in (*vals,*directions)]);rows.append(row)
print(json.dumps(rows))
