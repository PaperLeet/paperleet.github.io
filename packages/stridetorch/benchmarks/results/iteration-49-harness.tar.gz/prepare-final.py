from pathlib import Path
import json,hashlib,shutil
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-48';repo=Path('/Users/david/Developer/PaperLeet-torch-release');p=r/'proof';p.mkdir(exist_ok=True);chrome=p/'chrome-contracts';chrome.mkdir(exist_ok=True)
for dest in [p/'source',chrome/'source']:
 dest.mkdir(exist_ok=True)
 for f in (repo/'packages/stridetorch/src/stridetorch').iterdir():
  if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']:shutil.copy2(f,dest/f.name)
hashes=lambda d:{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in d.iterdir() if f.is_file()}
source=hashes(p/'source');assert len(source)==54
(p/'source-hashes.json').write_text(json.dumps(source,indent=2)+'\n')
tests=chrome/'tests';tests.mkdir(exist_ok=True)
for f in (repo/'packages/stridetorch/tests').glob('test_*.py'):
 if f.name!='test_standalone.py':shutil.copy2(f,tests/f.name)
assert len(hashes(tests))==46
(chrome/'plan.json').write_text(json.dumps(dict(version='0.49.0',expected=5892,source=source,tests=hashes(tests)),indent=2)+'\n')
for name in ['run.mjs','worker.mjs','index.html']:(chrome/name).write_text((old/'proof/chrome-contracts'/name).read_text().replace('torch-iteration-48','torch-iteration-49'))
for name in ['wasm-contracts.mjs','check-wheel.py','check-coinstall.py']:
 s=(old/'proof'/name).read_text().replace('torch-iteration-48','torch-iteration-49').replace('0.48.0','0.49.0').replace('stride048','stride049')
 if name=='wasm-contracts.mjs':s=s.replace("'convolution','transpose_convolution'","'convolution','convolution_padding','transpose_convolution'").replace('record.passed==5600','record.passed==5892')
 if name=='check-wheel.py':s=s.replace('len(names)==51','len(names)==52').replace('package_modules=51','package_modules=52')
 if name=='check-coinstall.py':
  pos=s.index('for name in NAMES:\n t=importlib.import_module(name).torch')
  s=s[:pos]+'''for name in NAMES:
 t=importlib.import_module(name).torch
 x=t.ones(1,2,3,3,3,dtype=t.float64,requires_grad=True);w=t.ones(4,2,3,3,3,dtype=t.float64,requires_grad=True)
 y,j=t.func.jvp(lambda xx,ww:t.nn.functional.conv3d(xx,ww,padding=1000000,dilation=1000000),(x,w),(t.ones_like(x),t.ones_like(w)))
 np.testing.assert_allclose(y.numpy(),2.);np.testing.assert_allclose(j.numpy(),4.)
 (y.square().sum()+j.square().sum()).backward();assert np.isfinite(x.grad.numpy()).all()
''' +s[pos:]
 (p/name).write_text(s)
for name in ['run-full.py','run-gates.py','run-setup-final.py']:(r/name).write_text((old/name).read_text().replace('torch-iteration-48','torch-iteration-49'))
i=r/'integration-proof';i.mkdir(exist_ok=True)
for name in ['run-setup.py','run-export.py','freeze.py','verify-private.py','verify-export.py','run-native.py','run-frontend.py','run-wasm.py']:
 s=(old/'integration-proof'/name).read_text().replace('torch-iteration-48','torch-iteration-49').replace('0.48.0','0.49.0')
 if name=='freeze.py':s=s.replace('len(tests)==45','len(tests)==46').replace("plan['expected']==5600","plan['expected']==5892").replace('expected_passed=5600','expected_passed=5892').replace('expected_suites=45','expected_suites=46')
 if name=='verify-export.py':s=s.replace('10545','10703')
 if name=='verify-private.py':s=s.replace('core_modules=51','core_modules=52').replace('all_53_core_license_hashes_identical','all_54_core_license_hashes_identical')
 if name=='run-wasm.py':s=s.replace('5600','5892').replace('==45','==46')
 (i/name).write_text(s)
(i/'context.json').write_text(json.dumps(dict(upstream='e5e611e919bd468d7cad5909e5a38a50f9738117',version='0.49.0',source_hashes=source),indent=2)+'\n')
print({'resources':len(source),'suites':46,'expected_contracts':5892})
