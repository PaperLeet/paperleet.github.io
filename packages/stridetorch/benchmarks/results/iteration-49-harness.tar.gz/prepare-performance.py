from pathlib import Path
import shutil,json,hashlib
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');chrome=r/'proof/chrome-contracts'
shutil.copy2(repo/'packages/stridetorch/benchmarks/bench_convolution_padding.py',r/'bench_convolution_padding.py');shutil.copy2(r/'bench_convolution_padding.py',chrome/'bench.py')
(chrome/'baseline').mkdir(exist_ok=True)
for p in (r/'baseline-source/stridetorch').iterdir():
 if p.is_file():shutil.copy2(p,chrome/'baseline'/p.name)
hashes=lambda d:{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.iterdir() if p.is_file() and (p.suffix=='.py' or p.name in ['LICENSE','NOTICE'])}
plan=dict(source=hashes(r/'proof/source'),baseline=hashes(r/'baseline-source/stridetorch'),benchmark_sha256=hashlib.sha256((r/'bench_convolution_padding.py').read_bytes()).hexdigest())
(chrome/'bench-plan.json').write_text(json.dumps(plan,indent=2)+'\n');shutil.copy2(r/'prototype-stage/proof/chrome-contracts/bench-worker.mjs',chrome/'bench-worker.mjs')
