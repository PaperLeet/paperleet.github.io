import os,json,numpy as np
if os.environ.get('STRIDE_PROBE'):
 from stridetorch import torch,_convolution as c
 route=os.environ.get('STRIDE_ROUTE','auto');c._PADDING_ALGORITHM=route.split('-')[0];c._ALGORITHM='matrix' if route.endswith('matrix') else 'direct' if route.endswith('direct') else 'auto'
 if route=='capped':c._PADDING_ALGORITHM='auto';c._GATHER_WORKSPACE_BYTES=0;c._PAD_WORKSPACE_BYTES=0
else:import torch
rows=[]
for dim in [1,2,3]:
 for kind in ['weight_inf','input_inf','seed_inf','seed_nan']:
  x=torch.ones(1,1,*([3]*dim),dtype=torch.float64,requires_grad=True);w=torch.ones(1,1,*([3]*dim),dtype=torch.float64,requires_grad=True)
  with torch.no_grad():
   if kind=='weight_inf':w[(0,0,*([0]*dim))]=float('inf')
   if kind=='input_inf':x[(0,0,*([0]*dim))]=float('inf')
  y=getattr(torch.nn.functional,f'conv{dim}d')(x,w,padding=31,dilation=31);seed=torch.ones_like(y)
  if kind.startswith('seed_'):seed[(0,0,*([0]*dim))]=float('inf') if kind=='seed_inf' else float('nan')
  y.backward(seed);rows.append(dict(id=f'{dim}:{kind}',value=y.detach().numpy().tolist(),dx=x.grad.numpy().tolist(),dw=w.grad.numpy().tolist()))
print(json.dumps(rows,allow_nan=True))
