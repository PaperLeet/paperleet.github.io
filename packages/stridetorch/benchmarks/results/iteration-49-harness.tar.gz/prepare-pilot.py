from pathlib import Path
import shutil,json,hashlib
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-48';repo=Path('/Users/david/Developer/PaperLeet-torch-release');p=r/'proof';p.mkdir(exist_ok=True);chrome=p/'chrome-contracts';chrome.mkdir(exist_ok=True)
for dest,origin in [(p/'source',repo/'packages/stridetorch/src/stridetorch'),(chrome/'source',repo/'packages/stridetorch/src/stridetorch'),(chrome/'baseline',r/'baseline-source/stridetorch')]:
 dest.mkdir(exist_ok=True)
 for f in origin.iterdir():
  if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']:shutil.copy2(f,dest/f.name)
shutil.copy2(repo/'packages/stridetorch/benchmarks/bench_convolution_padding.py',r/'bench_convolution_padding.py');shutil.copy2(r/'bench_convolution_padding.py',chrome/'bench.py')
hashes=lambda d:{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in d.iterdir() if f.is_file()}
(chrome/'bench-plan.json').write_text(json.dumps(dict(source=hashes(chrome/'source'),baseline=hashes(chrome/'baseline'),benchmark_sha256=hashlib.sha256((chrome/'bench.py').read_bytes()).hexdigest()),indent=2)+'\n')
(chrome/'index.html').write_text('<!doctype html><title>Convolution padding benchmark</title>')
(r/'bench-chrome.mjs').write_text((old/'bench-chrome.mjs').read_text().replace('torch-iteration-48','torch-iteration-49'))
