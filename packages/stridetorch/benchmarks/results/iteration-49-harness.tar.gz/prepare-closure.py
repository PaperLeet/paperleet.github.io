from pathlib import Path
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-48'
s=(old/'close-local.py').read_text().replace('0.48.0','0.49.0').replace('iteration-48','iteration-49').replace('stride048','stride049')
s=s.replace('len(actual)==53','len(actual)==54').replace('len(tests)==45','len(tests)==46').replace("len(contracts['suites'])==45","len(contracts['suites'])==46").replace('==5600','==5892').replace('==39229','==39521').replace("'5613 passed'","'5905 passed'").replace("'722 passed'","'1014 passed'")
s=s.replace("numeric['source_hashes']==actual", "numeric['source_hashes']==actual and numeric['regular_cases']==96 and numeric['regular_routes']==6 and numeric['regular_checks']==6912 and numeric['ieee_cases']==12 and numeric['ieee_checks']==216")
s=s.replace("len(baseline['source'])==52","len(baseline['source'])==53").replace('bench_transpose_convolution','bench_convolution_padding').replace("len(row['flows'])==38","len(row['flows'])==32").replace("row['source_hashes']==actual and row['library']=='0.49.0'","row['source_hashes']==dict(baseline=baseline['source'],candidate=actual) and row['candidate_version']=='0.49.0' and row['baseline_version']=='0.48.0'")
s=s.replace("  assert row['benchmark_sha256']==sha(r/'bench_convolution_padding.py')", "  assert performance['benchmark_sha256']==sha(r/'bench_convolution_padding.py')")
s=s.replace('==10545','==10703')
s=s.replace("changed=={'__init__.py','_api.py','_convolution.py'} and set(actual)-set(baseline['source'])=={'_transpose_convolution.py'}", "changed=={'__init__.py','_transpose_convolution.py','_convolution.py'} and set(actual)-set(baseline['source'])=={'_convolution_padding.py'}")
s=s.replace('unchanged_resources=49','unchanged_resources=50').replace("added_resources=['_transpose_convolution.py']","added_resources=['_convolution_padding.py']").replace('focused_transposed_convolution=515,focused_regular_convolution=207','focused_padding=292,focused_transposed_convolution=515,focused_regular_convolution=207')
s=s.replace('PASS0.48 exact local proof:53resources,5600Node/Chrome,39229CPU,5613minimum,144x5native plus68semantic cases,78/342catalog,38flowsx12children','PASS0.49 exact local proof:54resources,5892Node/Chrome,39521CPU,5905minimum,96x6regular+144x5transpose+IEEE/state,78/342catalog,32flowsx12children')
(r/'close-local.py').write_text(s)
