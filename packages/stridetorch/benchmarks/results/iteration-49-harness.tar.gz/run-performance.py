from pathlib import Path
import hashlib,json,os,statistics,subprocess,time
r=Path(__file__).resolve().parent;out=r/'performance';out.mkdir(exist_ok=True);py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';source=json.loads((r/'proof/source-hashes.json').read_text());baseline=json.loads((r/'baseline.json').read_text())['source'];receipts={}
assert json.loads((r/'full-root-receipt.json').read_text())['exit_code']==0
assert json.loads((r/'integration-proof/wasm-receipt.json').read_text())['exit_code']==0
assert json.loads((r/'native-differential-receipt.json').read_text())['source_hashes']==source
for name in ['proof/source-wasm.json','proof/chrome-contracts/result.json']:assert json.loads((r/name).read_text())['source_hashes']==source
env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');load_before=os.getloadavg();bench_sha=hashlib.sha256((r/'bench_convolution_padding.py').read_bytes()).hexdigest()
for repeat in range(4):
 for runtime in (('cpu','node','chrome') if repeat%2==0 else ('chrome','node','cpu')):
  name=f'{runtime}-{repeat}';output=out/(name+'.json');reverse=['--reverse'] if repeat%2 else []
  args=([str(py),str(r/'bench_convolution_padding.py'),'--baseline-source',str(r/'baseline-source/stridetorch'),'--candidate-source',str(r/'proof/source'),'--output',str(output)] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(r/('bench-wasm.mjs' if runtime=='node' else 'bench-chrome.mjs')),str(output)])+reverse
  start=time.monotonic()
  with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  receipts[name]=dict(args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-start);(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode()
  j=json.loads(output.read_text());assert j['status']=='success' and j['candidate_version']=='0.49.0' and j['baseline_version']=='0.48.0' and len(j['flows'])==32 and j['source_hashes']==dict(baseline=baseline,candidate=source)
  for flow in j['flows']:
   if 'qualification' not in flow:continue
   q=flow['qualification']
   if flow['kind']=='transpose_control':assert not q['candidate']['padding'];continue
   expected='gather' if flow['kind'].startswith('halo') else 'padded'
   assert q['candidate']['padding'].get(expected,0)>0 and q['control']['padding'].get('padded',0)>0
   assert q['gather']['padding'].get('gather',0)>0 and q['tap']['padding'].get('tap',0)>0
  print(name,'PASS32',round(receipts[name]['elapsed_s'],2),flush=True)
summary={}
for runtime in ['cpu','node','chrome']:
 reports=[json.loads((out/f'{runtime}-{i}.json').read_text()) for i in range(4)];rows=[]
 for case in range(32):
  first=reports[0]['flows'][case];row={k:first[k] for k in ['kind','shape','dtype','mode']};times={name:[j['flows'][case]['median_s'][name] for j in reports] for name in first['median_s']};medians={name:statistics.median(v) for name,v in times.items()}
  row.update(median_s=medians,all_child_median_s=times,time_reduction_percent=100*(1-medians['candidate']/medians['baseline']),control_time_reduction_percent=100*(1-medians['control']/medians['baseline']));rows.append(row)
 summary[runtime]=rows
assert bench_sha==hashlib.sha256((r/'bench_convolution_padding.py').read_bytes()).hexdigest()
(r/'performance-summary.json').write_text(json.dumps(dict(status='success',children=len(receipts),all_children_terminal=True,summary=summary,receipts=receipts,source_hashes=dict(baseline=baseline,candidate=source),benchmark_sha256=bench_sha,load_before=load_before,load_after=os.getloadavg(),scope='0.48 vs0.49 direct comparison, same-source padded control plus gather/tap controls. Four fresh processes per CPU/Node/Chrome; alternating method/runtime order;5samples/8calls or3SGDsteps.32 flows validate values, VJP/JVP/mixed derivatives and3optimizer steps before timing. Actual padding/matrix selection qualified. Safe legacy halos only; not peak RSS/GPU/native Torch/universal speed evidence.'),indent=2)+'\n')
