from pathlib import Path
import subprocess,os,json,numpy as np
r=Path(__file__).resolve().parent;py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';reference=json.loads((r/'reference.json').read_text());assert len(reference)==96
errors=[];count=0
for route in ['auto','gather-direct','gather-matrix','tap','capped','padded']:
 with (r/f'candidate-{route}.json').open('w') as out,(r/f'candidate-{route}.log').open('w') as log:
  subprocess.check_call([str(py),str(r/'differential.py')],stdout=out,stderr=log,env={**os.environ,'STRIDE_PROBE':'1','STRIDE_ROUTE':route})
 rows=json.loads((r/f'candidate-{route}.json').read_text());assert len(rows)==96
 for a,b in zip(reference,rows):
  assert a['id']==b['id']
  for key in ['value','stride','grads','jvp','mixed']:
   pairs=zip(a[key],b[key]) if key in ['grads','mixed'] else [(a[key],b[key])]
   for i,(left,right) in enumerate(pairs):
    count+=1
    try:np.testing.assert_allclose(right,left,rtol=2e-5 if 'float32' in a['id'] else 8e-12,atol=3e-5 if 'float32' in a['id'] else 8e-12)
    except AssertionError:errors.append([route,a['id'],key,i])
print(dict(cases=96,routes=6,checks=count,errors=errors[:10],error_count=len(errors)))
(r/'prototype-numeric.json').write_text(json.dumps(dict(cases=96,routes=6,checks=count,errors=errors),indent=2)+'\n')
