from pathlib import Path
import json,os,shutil,subprocess,time
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');env=dict(os.environ);env['PATH']='/opt/homebrew/bin:'+env['PATH'];receipts=[]
for name in ('context.json','latest-upstream.json','frontend-receipts.json','pages-profile.json'):shutil.copy2(r/name,r/('before-css-'+name))
context=json.loads((r/'context.json').read_text());base='0fb0bdc57732aadb8233d3ec9d246570ce088c58';upstream='96200d504e0b88b78a0a2814501097ccb211b905'
files=subprocess.check_output(['git','diff','--name-only',base,upstream],cwd=repo,text=True).splitlines();assert len(files)==23
for name in files:assert (repo/name).read_bytes()==subprocess.check_output(['git','show',upstream+':'+name],cwd=repo)
context.update(upstream=upstream,merge_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),upstream_files_preserved=files,latest_change_scope='Relative to first frontend check123d:inbox.css plus its validation document only;no JS/test/Python/catalog/package/lock changes',full_frontend_check_at='123d3622ddb89b2fe78643daace4cf8abf389411',followup='Targeted inbox check and both complete builds after CSS-only merge')
for name in ('context.json','latest-upstream.json'):(r/name).write_text(json.dumps(context,indent=2)+'\n')
profile=json.loads((r/'pages-profile.json').read_text());value=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED','--jq','.value'],text=True).strip();assert value==profile['observed_value'];profile['revalidated_after_css']=True;(r/'pages-profile-latest.json').write_text(json.dumps(profile,indent=2)+'\n')
for command,name,cwd,overrides in [(['/opt/homebrew/bin/node','web/scripts/check-inbox.mjs'],'inbox-css-check.log',repo,{}),(['npm','run','build'],'frontend-build-latest.log',repo/'web',{}),(['npm','run','build'],'pages-profile-build-latest.log',repo/'web',profile['environment'])]:
 start=time.monotonic()
 with (r/name).open('w') as log:p=subprocess.run(command,cwd=cwd,env={**env,**overrides},stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(command=command,log=name,cwd=str(cwd),environment=overrides,exit_code=p.returncode,elapsed_s=time.monotonic()-start));(r/'css-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode();print(name,'terminal0',flush=True)
