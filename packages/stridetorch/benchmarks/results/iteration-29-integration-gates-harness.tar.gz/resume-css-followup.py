from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');env=dict(os.environ);env['PATH']='/opt/homebrew/bin:'+env['PATH'];receipts=[]
for name in ('css-followup.log','css-receipts.json','inbox-css-check.log'):
 p=r/name
 if p.exists():p.rename(r/('initial-wrong-cwd-'+name))
profile=json.loads((r/'pages-profile-latest.json').read_text())
for command,name,overrides in [(['/opt/homebrew/bin/node','scripts/check-inbox.mjs'],'inbox-css-check.log',{}),(['npm','run','build'],'frontend-build-latest.log',{}),(['npm','run','build'],'pages-profile-build-latest.log',profile['environment'])]:
 start=time.monotonic()
 with (r/name).open('w') as log:p=subprocess.run(command,cwd=repo/'web',env={**env,**overrides},stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(command=command,log=name,cwd=str(repo/'web'),environment=overrides,exit_code=p.returncode,elapsed_s=time.monotonic()-start));(r/'css-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode();print(name,'terminal0',flush=True)
