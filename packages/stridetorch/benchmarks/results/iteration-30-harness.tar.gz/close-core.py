from pathlib import Path
import hashlib,json,os,re,tarfile
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results';p=r/'proof-hardened'
def read(path):return json.loads((r/path).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
expected=read('proof-hardened/source-hashes.json');actual={f.name:sha(f) for f in (repo/'packages/stridetorch/src/stridetorch').iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')};assert expected==actual and len(actual)==46
plan=read('proof-hardened/chrome-contracts/plan.json');assert len(plan['tests'])==30 and plan['expected']==948 and plan['source']==actual
assert plan['tests']=={f.name:sha(f) for f in (repo/'packages/stridetorch/tests').glob('test_*.py') if f.name!='test_standalone.py'}
receipts=read('proof-hardened/gate-receipts.json');assert len(receipts)==4 and all(v['exit_code']==0 for v in receipts.values())
m=re.search(r'29960 passed, 1 skipped, 34 warnings in ([\d.]+)s',(p/'full-native.log').read_text());assert m
assert '114 passed' in (r/'focused-build.log').read_text()
minimal=read('proof-hardened/wheel-stride030-result.json');assert minimal['status']=='success' and not minimal['native_torch'] and minimal['source_hashes']==actual and '960 passed' in (p/'python310-stride030-tests.log').read_text()
node=read('proof-hardened/source-wasm.json');chrome=read('proof-hardened/chrome-contracts/result.json');assert node['passed']==chrome['passed']==948 and node['source_hashes']==chrome['source_hashes']==actual and chrome['status']=='success'
coinstall=read('proof-hardened/coinstall-result.json');private=read('proof-hardened/private-artifact-identity.json');assert coinstall['status']==private['status']=='success' and coinstall['source_hashes']==private['source_hashes']==actual
performance=read('performance-summary.json');assert performance['source_size']['candidate']['hashes']==actual and len(performance['receipts'])==20 and all(x['exit_code']==0 for x in performance['receipts'])
files=[]
for directory,dirs,names in os.walk(r):
 dirs[:]=[d for d in dirs if not d.endswith('-env') and d not in ('__pycache__','.pytest_cache','dist-preflight','private-dist','performance-cache')]
 for name in names:
  f=Path(directory)/name
  if name in ('LICENSE','NOTICE') or f.suffix in ('.py','.mjs','.json','.log','.pt','.txt','.md','.html','.patch'):
   if name not in ('local-gates.json',):files.append(f)
archive=out/'iteration-30-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for f in sorted(files):tar.add(f,arcname=str(f.relative_to(r)),recursive=False)
report=dict(status='core_candidate_validated_application_integration_pending',version='0.30.0',baseline_commit=read('state.json')['baseline_commit'],source_hashes=actual,standalone_test_hashes=plan['tests'],full_cpu=dict(passed=29960,optional_skipped=1,warnings=34,duration_s=float(m[1])),focused_passed=114,minimal_wheel=minimal,independent_node_wasm=node,actual_chrome_worker=chrome,private_distribution=private,coinstall=coinstall,performance=performance,gate_receipts=receipts,scope='Modern native ZIP weights-only CPU data checkpoints;14 dtypes,shared views and native bidirectional AdamW/StepLR resume;NumPy-only independent fixture and SGD analytic resume. Fixed allowlist,extensions disabled,BUILD only OrderedDict attributes. No whole-module/executable/legacy/mmap support. No nativeTorch runtime dependency.',retained_failures=['Initial external padded buffer unsupported;bounded physical storage span fixes it','Cached EXT bypass reproduced with3 failed tests;pure restricted unpickler rejects extensions','BUILD host dtype mutation reproduced;BUILD now accepts only OrderedDict attributes','First coinstall probe incorrectly expected a fresh as_torch namespace to equal m.torch;corrected probe,no product change','One focused invocation used nonexistent tests/test_torch_operator_dispatch.py;corrected maintained packages/test_dispatch.py,114 pass'],archive=dict(file=archive.name,files=len(files),bytes=archive.stat().st_size,sha256=sha(archive)),remaining=['Full PaperLeet native catalog,exported WASM and frontend gates','Latest-main preservation and non-force adoption','Remote Quality,actual Pages and live-byte proof'])
(out/'iteration-30.json').write_text(json.dumps(report,indent=2)+'\n');(r/'local-gates.json').write_text(json.dumps(report,indent=2)+'\n')
state=read('state.json');state.update(phase='0.30 final hardened core/package/CPU/WASM/browser/performance validated;application gates next',source_hashes=actual,previous_turn_classification='progress:0.29 actual deployment closed;0.30 native-format checkpoint data validated with complete final source proofs and measured costs',core_report='iteration-30.json');(r/'state.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(dict(status=report['status'],full_cpu=report['full_cpu'],archive=report['archive']),indent=2))
