from pathlib import Path
from collections import OrderedDict
import hashlib,io,json,sys,zipfile
import numpy as np
import torch as native
from stridetorch import _serialization as codec,torch as lite
r=Path(__file__).parent
for dtype in ('bool','int8','uint8','int16','uint16','int32','uint32','int64','uint64','float16','float32','float64','complex64','complex128'):
 a=np.arange(12).astype(dtype);a=a if dtype!='bool' else a%2==0
 if np.dtype(dtype).kind=='c':a=a+1j*a
 base=lite.from_numpy(a);obj=OrderedDict(base=base,view=base[2:10:2],matrix=base.reshape(3,4).t(),repeat=base,nested={'epoch':4,'bytes':b'abc','complex':2+3j,'set':{1,2}},dtype=getattr(lite,dtype),device=lite.device('cpu'));obj._metadata={'':{'version':1}}
 b=io.BytesIO();codec.save(obj,b);(r/f'lite-{dtype}.pt').write_bytes(b.getvalue())
 restored=codec.load(io.BytesIO(b.getvalue()));n=native.load(io.BytesIO(b.getvalue()),weights_only=True)
 for key in ('base','view','matrix'):
  np.testing.assert_array_equal(restored[key].numpy(),obj[key].numpy());np.testing.assert_array_equal(n[key].numpy(),obj[key].numpy());assert restored[key].stride()==n[key].stride()
 assert restored['base'] is restored['repeat'] and n['base'] is n['repeat'];assert restored._metadata==obj._metadata
 with lite.no_grad():restored['base'][2]=0
 assert restored['view'][0].item()==0
 # Native writer to lightweight reader,including wide unsigned v3 storage.
 nb=io.BytesIO();native.save(n,nb);result=codec.load(io.BytesIO(nb.getvalue()));np.testing.assert_array_equal(result['matrix'].numpy(),obj['matrix'].numpy())
 print(dtype,'both directions and own roundtrip pass',len(b.getvalue()),flush=True)
for protocol in (2,3,4,5):
 x=codec.load(r/f'native-protocol{protocol}.pt');assert isinstance(x['parameter'],lite.nn.Parameter);assert x['repeat'] is x['base'];assert x._metadata=={'':{'version':1}};print('read native protocol',protocol,'pass')
