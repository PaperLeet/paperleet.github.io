"""Absolute checkpoint costs and paired0.29 numerical-overhead controls."""
import contextlib,gc,hashlib,importlib.util,io,json,os,statistics,sys,time
from pathlib import Path
import numpy as np
paths=globals().get('bench_sources') or json.loads(os.environ['BENCH_SOURCES']);packages={};hashes={}
for label,path in paths.items():
 root=Path(path);name='checkpoint_'+label;spec=importlib.util.spec_from_file_location(name,root/'__init__.py',submodule_search_locations=[str(root)]);p=importlib.util.module_from_spec(spec);sys.modules[name]=p;spec.loader.exec_module(p);packages[label]=p
 hashes[label]={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in root.iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')}
assert packages['baseline'].__version__=='0.29.0' and packages['candidate'].__version__=='0.30.0'
libs={'candidate':packages['candidate'].torch}
if globals().get('bench_native',os.environ.get('BENCH_NATIVE')):
 import torch
 libs['native']=torch
checkpoint={};controls={}
def samples(callback,loops):
 start=time.perf_counter()
 for _ in range(loops):callback()
 return (time.perf_counter()-start)*1e6/loops
for recipe in ('one-1MiB','many128x16','shared64views','training-resume'):
 callbacks={};identities={};checks={}
 for label,lib in libs.items():
  if recipe=='training-resume':
   def make(lib=lib):
    model=lib.nn.Linear(8,4).double()
    with lib.no_grad():model.weight.copy_(lib.tensor(np.linspace(-.4,.5,32).reshape(4,8),dtype=lib.float64));model.bias.fill_(.1)
    optimizer=lib.optim.AdamW(model.parameters(),lr=.01);scheduler=lib.optim.lr_scheduler.StepLR(optimizer,2)
    return model,optimizer,scheduler
   model,opt,scheduler=make();x=lib.tensor(np.arange(16).reshape(2,8)/16,dtype=lib.float64)
   def step(model,opt,scheduler,x=x):
    opt.zero_grad();loss=model(x).square().mean();loss.backward();opt.step();scheduler.step();return loss.item()
   step(model,opt,scheduler)
   source={'model':model.state_dict(),'optimizer':opt.state_dict(),'scheduler':scheduler.state_dict()}
  elif recipe=='one-1MiB':source=lib.tensor(np.linspace(-1,1,262144,dtype=np.float32))
  elif recipe=='many128x16':source={str(i):lib.tensor(np.arange(16,dtype=np.float32)+i) for i in range(128)}
  else:
   root=lib.tensor(np.arange(16384,dtype=np.float32));source={'root':root,'views':[root[i:i+128] for i in range(64)]}
  f=io.BytesIO();lib.save(source,f);raw=f.getvalue();loaded=lib.load(io.BytesIO(raw),weights_only=True)
  def validate(a,b):
   if isinstance(a,lib.Tensor):np.testing.assert_array_equal(a.detach().numpy(),b.detach().numpy());assert a.stride()==b.stride()
   elif isinstance(a,dict):
    assert a.keys()==b.keys()
    for k in a:validate(a[k],b[k])
   elif isinstance(a,(list,tuple)):
    for x,y in zip(a,b):validate(x,y)
   else:assert a==b
  validate(source,loaded)
  def save(lib=lib,source=source):buffer=io.BytesIO();lib.save(source,buffer);return buffer.getvalue()
  def load(lib=lib,raw=raw):return lib.load(io.BytesIO(raw),weights_only=True)
  if recipe=='training-resume':
   # Rebuild the destination and perform a real update after saving/loading.
   def resume(save=save,lib=lib,make=make,step=step):
    state=lib.load(io.BytesIO(save()),weights_only=True);m,o,s=make();m.load_state_dict(state['model']);s.load_state_dict(state['scheduler']);o.load_state_dict(state['optimizer']);return step(m,o,s)
   checks[label]=resume();operations={'save-load-rebuild-update':resume}
  else:operations={'save':save,'load':load}
  callbacks[label]=operations;identities[label]=dict(bytes=len(raw),version=getattr(lib,'__version__',packages['candidate'].__version__))
 if recipe=='training-resume' and 'native' in checks:np.testing.assert_allclose(checks['candidate'],checks['native'],rtol=2e-11,atol=2e-12)
 loops=3 if recipe in ('one-1MiB','training-resume') else 5
 for operations in callbacks.values():
  for call in operations.values():
   for _ in range(5):call()
 gc.collect();rows={label:{operation:[] for operation in operations} for label,operations in callbacks.items()}
 for block in range(9):
  order=list(callbacks) if block%2==0 else list(reversed(callbacks))
  for label in order:
   for operation,call in callbacks[label].items():rows[label][operation].append(samples(call,loops))
 checkpoint[recipe]=dict(identity=identities,loops=loops,samples_us=rows,medians_us={label:{op:statistics.median(v) for op,v in ops.items()} for label,ops in rows.items()})
for operation in ('unary-backward','layernorm-backward','attention-backward','jvp','inference'):
 calls={};validate={}
 for label,p in packages.items():
  lib=p.torch;x=lib.tensor(np.linspace(-.4,.7,32).reshape(4,8),dtype=lib.float64,requires_grad=True)
  if operation=='jvp':
   tangent=lib.ones_like(x);call=lambda lib=lib,x=x,t=tangent:lib.func.jvp(lambda a:a.sin().square(),(x,),(t,))
  elif operation=='inference':
   def call(x=x,lib=lib):
    with lib.no_grad():return x.sin().exp().tanh()
  else:
   if operation=='layernorm-backward':forward=lambda x=x,f=lib.nn.functional:f.layer_norm(x,(8,))
   elif operation=='attention-backward':forward=lambda x=x,f=lib.nn.functional:f.scaled_dot_product_attention(x,x,x)
   else:forward=lambda x=x:x.sin().exp().tanh()
   def call(x=x,forward=forward):x.grad=None;forward().square().mean().backward()
  calls[label]=call
  validate[label]=(lambda call=call:[v.detach().numpy().copy() for v in call()]) if operation=='jvp' else (lambda call=call:call().numpy().copy()) if operation=='inference' else (lambda x=x:x.grad.numpy().copy())
 for call in calls.values():
  for _ in range(200):call()
 gc.collect();blocks=[]
 for block in range(9):
  order=('baseline','candidate','candidate','baseline') if block%2==0 else ('candidate','baseline','baseline','candidate');times={'baseline':[],'candidate':[]}
  for label in order:times[label].append(samples(calls[label],100))
  blocks.append(dict(samples_us=times,change_percent=100*(statistics.mean(times['candidate'])/statistics.mean(times['baseline'])-1)))
 values={label:check() for label,check in validate.items()};np.testing.assert_allclose(values['candidate'],values['baseline'],rtol=2e-12,atol=2e-13)
 controls[operation]=dict(values={label:np.asarray(value).tolist() for label,value in values.items()},blocks=blocks,median_change_percent=statistics.median(b['change_percent'] for b in blocks))
result=dict(python=sys.version,numpy=np.__version__,source_hashes=hashes,checkpoint=checkpoint,controls=controls,scope='GC enabled;checkpoint9 alternating blocks,5warmups,3or5calls/sample;controls9 ABBA/BAAB blocks,200warmups,100calls/sample. CPU native is separate context,not a0.29 speedup baseline. Shared host;no CPU/WASM cross-runtime speed claim,BLAS threading not verified.')
if 'bench_sources' not in globals():print(json.dumps(result))
