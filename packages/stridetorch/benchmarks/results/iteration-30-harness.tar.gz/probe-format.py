import io,json,pickletools,zipfile,torch,inspect
from collections import OrderedDict
from pathlib import Path
r=Path(__file__).parent
for protocol in (2,3,4,5):
 base=torch.arange(12,dtype=torch.float64);obj=OrderedDict(base=base,view=base[2:10:2],matrix=base.reshape(3,4).t(),repeat=base,parameter=torch.nn.Parameter(torch.ones(2)),nested={'epoch':4,'value':2+3j,'set':{1,2},'bytes':b'abc'})
 obj._metadata={'':{'version':1}}
 output=io.BytesIO();torch.save(obj,output,pickle_protocol=protocol);raw=output.getvalue();(r/f'native-protocol{protocol}.pt').write_bytes(raw)
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  prefix=z.namelist()[0].split('/')[0]+'/';data=z.read(prefix+'data.pkl');print(protocol,[(n.removeprefix(prefix),len(z.read(n))) for n in z.namelist()]);(r/f'native-protocol{protocol}-pickle.txt').write_text(pickletools.dis(data,out=io.StringIO()) or '')
  with (r/f'native-protocol{protocol}-pickle.txt').open('w') as log:pickletools.dis(data,out=log)
 try:loaded=torch.load(io.BytesIO(raw),weights_only=True);print('weights-only',protocol,'success')
 except Exception as e:print('weights-only',protocol,type(e).__name__,str(e)[:220])
print('native signatures',inspect.signature(torch.save),inspect.signature(torch.load))
print('typed storage view pointers',base.untyped_storage().data_ptr(),base[2:].untyped_storage().data_ptr())
