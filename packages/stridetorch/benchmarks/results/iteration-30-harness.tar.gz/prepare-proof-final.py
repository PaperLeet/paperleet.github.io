from pathlib import Path
import json,hashlib,shutil
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');old=r.parent/'torch-iteration-29/proof-refined';proof=r/'proof-final';proof.mkdir(exist_ok=True);source=repo/'packages/stridetorch/src/stridetorch'
for target in (proof/'source',proof/'chrome-contracts/source'):shutil.copytree(source,target,ignore=shutil.ignore_patterns('__pycache__'),dirs_exist_ok=True)
shutil.copytree(repo/'packages/stridetorch/tests',proof/'chrome-contracts/tests',ignore=shutil.ignore_patterns('__pycache__'),dirs_exist_ok=True)
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};assert len(hashes)==46
plan=dict(version='0.30.0',expected=947,source=hashes,tests={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'});assert len(plan['tests'])==30
(proof/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n');(proof/'chrome-contracts/plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for name in ('run.mjs','worker.mjs','index.html'):
 s=(old/'chrome-contracts'/name).read_text().replace('torch-iteration-29/proof-refined','torch-iteration-30/proof-final');(proof/'chrome-contracts'/name).write_text(s)
s=(old/'wasm-contracts.mjs').read_text().replace('torch-iteration-29/proof-refined','torch-iteration-30/proof-final').replace('0.29.0','0.30.0').replace("'axis_transforms','solve']","'axis_transforms','solve','serialization']").replace('==904','==947');(proof/'wasm-contracts.mjs').write_text(s)
s=(old/'check-wheel.py').read_text().replace('0.29','0.30').replace('stride029','stride030').replace('==43','==44').replace('package_modules=43','package_modules=44');(proof/'check-wheel.py').write_text(s)
print('FROZEN46 source/license hashes,30 independent suites947 contracts')
