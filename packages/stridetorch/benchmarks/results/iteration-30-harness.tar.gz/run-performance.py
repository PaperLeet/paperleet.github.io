from pathlib import Path
import gzip,hashlib,json,os,statistics,subprocess,time
r=Path(__file__).parent;out=r/'performance';out.mkdir(exist_ok=True);py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';sources={'baseline':str(r/'baseline/stridetorch'),'candidate':str(r/'proof-hardened/source')};env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2');receipts=[]
def run(name,args,extra):
 start=time.monotonic()
 with (out/(name+'.json')).open('w') as log,(out/(name+'.stderr.log')).open('w') as err:p=subprocess.run([str(x) for x in args],env={**env,**extra},stdout=log,stderr=err,cwd=r)
 receipts.append(dict(name=name,command=[str(x) for x in args],exit_code=p.returncode,elapsed_s=time.monotonic()-start));(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,'terminal',p.returncode,flush=True);p.check_returncode()
for preload in ('0','1'):
 for repeat in range(4):
  for label in (('baseline','candidate') if repeat%2==0 else ('candidate','baseline')):
   run(f'import-{preload}-{repeat}-{label}',[py,r/'bench-import.py'],{'IMPORT_SOURCE':sources[label],'IMPORT_PRELOAD':preload})
for repeat in range(2):
 for runtime in (('cpu','wasm') if repeat%2==0 else ('wasm','cpu')):
  args=[py,r/'bench-checkpoints.py'] if runtime=='cpu' else ['/opt/homebrew/bin/node',r/'bench-checkpoints-wasm.mjs',sources['baseline'],sources['candidate'],'float64']
  run(f'checkpoint-{runtime}-{repeat}',args,{'BENCH_SOURCES':json.dumps(sources),'BENCH_NATIVE':'1' if runtime=='cpu' else ''})
size={}
for label,source in sources.items():
 files={p.name:p.read_bytes() for p in Path(source).iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};raw=b''.join(files[name] for name in sorted(files));size[label]=dict(files=len(files),raw_bytes=len(raw),gzip_bytes=len(gzip.compress(raw,mtime=0)),hashes={name:hashlib.sha256(data).hexdigest() for name,data in files.items()})
imports={}
for preload in ('0','1'):
 imports[preload]={}
 for label in sources:
  rows=[json.loads((out/f'import-{preload}-{i}-{label}.json').read_text()) for i in range(4)];assert all(not x['zipfile_imported'] and x['source_hashes']==size[label]['hashes'] for x in rows)
  imports[preload][label]=dict(samples_ms=[x['namespace_import_ms'] for x in rows],median_ms=statistics.median(x['namespace_import_ms'] for x in rows))
reports={runtime:[json.loads((out/f'checkpoint-{runtime}-{i}.json').read_text()) for i in range(2)] for runtime in ('cpu','wasm')}
for group in reports.values():
 for row in group:
  assert row['source_hashes']=={label:data['hashes'] for label,data in size.items()}
summary=dict(source_size=size,cold_namespace_import=imports,controls={runtime:{op:[row['controls'][op]['median_change_percent'] for row in rows] for op in rows[0]['controls']} for runtime,rows in reports.items()},checkpoint={runtime:{recipe:[row['checkpoint'][recipe]['medians_us'] for row in rows] for recipe in rows[0]['checkpoint']} for runtime,rows in reports.items()},receipts=receipts,scope='Sequential fresh processes after final compatibility gates;4 cold imports per variant/preload;2 complete CPU and2 Pyodide performance processes;all samples retained;relative numerical controls compare0.29,checkpoint reports absolute cost and separate native context.')
(r/'performance-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('PERFORMANCE COMPLETE',flush=True)
