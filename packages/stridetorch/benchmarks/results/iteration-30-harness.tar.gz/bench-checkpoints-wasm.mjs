import fs from 'node:fs';import path from 'node:path';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const py=await loadPyodide({indexURL:'/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/',packageCacheDir:'/Users/david/Developer/PaperLeet-torch-release/web/public/browser-runtime/pyodide-0.29.4/',stdout(){},stderr:console.error});await loadJudgePackages(py,[]);
const sources={baseline:process.argv[2],candidate:process.argv[3]},mapped={};
for(const [label,source]of Object.entries(sources)){
 mapped[label]='/runtime/'+label;py.FS.mkdirTree(mapped[label]);
 for(const name of fs.readdirSync(source).filter(n=>n.endsWith('.py')||['LICENSE','NOTICE'].includes(n)))py.FS.writeFile(mapped[label]+'/'+name,fs.readFileSync(path.join(source,name)));
}
py.globals.set('bench_dtype',process.argv[4]);py.globals.set('bench_sources_json',JSON.stringify(mapped));py.runPython('import json;bench_sources=json.loads(bench_sources_json)');py.runPython(fs.readFileSync(new URL('bench-checkpoints.py',import.meta.url),'utf8'));console.log(py.runPython('json.dumps(result)'));
