from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
assert not (r/'qualification-grant.json').exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip()
integration=read(b/'torch-iteration-563/result.json');assert integration['status']=='passed_current_main_benchmark_only_integration' and all(v['exit_code']==0 for v in integration['receipts'])
plan=read(b/'torch-iteration-563/execution-plan.json')
for n,h in plan['frontend_inputs'].items():assert sha(repo/n)==h,n
for n,h in plan['our_files'].items():
 if not n.startswith('docs/validation/'):assert sha(repo/n)==h,n
for n,h in plan['package_inputs'].items():assert sha(Path(n))==h,n
summary=read(repo/'packages/stridetorch/benchmarks/results/resident-session.json');assert summary['status']=='qualified_batched_resident_tensor_offload_session'
qualified=read(b/'torch-iteration-559/result.json');assert qualified['totals']==dict(tests=123,failures=0,errors=0,skipped=0)
for n,h in qualified['qualified_files'].items():assert sha(repo/'packages/stridetorch/benchmarks/webgpu_rpc'/n)==h,n
for n,h in read(b/'torch-iteration-561/commit-receipt.json')['paths'].items():
 if not n.startswith('docs/validation/'):assert sha(repo/n)==h,n
assert summary['package_inputs_unchanged']==206 and summary['canonical_resources_unchanged']==66 and not summary['automatic_dispatch']
delta=subprocess.check_output(['git','diff','--name-only',integration['remote_baseline'],'HEAD'],cwd=repo,text=True).splitlines()
assert all(n in integration['own_delta'] or n.startswith(('docs/validation/','packages/stridetorch/benchmarks/results/')) for n in delta),delta
resources=read(b/'torch-iteration-511/source-hashes.json');exports=read(b/'torch-iteration-511/live-export-sha256.json');assert len(resources)==66 and len(exports)==183
for n,h in resources.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/n)==h,n
for n,h in exports.items():assert sha(repo/'web/public/data'/n)==h,n
write(r/'source-hashes.json',resources);write(r/'live-export-sha256.json',exports)
for n,h in read(r/'release-policy-identity.json')['files'].items():assert sha(repo/n)==h,n
required={}
for n in ['operand-lifetime-jspi-followup.json','operand-lifetime-owned-flow.json','qualification-0.83.json','qualification-0.83-main-adoption.json','post083-shape-jspi.json','webgpu-tensor-offload.json','webgpu-tensor-offload-main-adoption.json','resident-session.json']:
 aggregate=read(repo/'packages/stridetorch/benchmarks/results'/n);receipt=aggregate.get('raw_archive',aggregate.get('archive'));archive=repo/receipt['path'];assert sha(archive)==receipt['sha256']
 with tarfile.open(archive) as stream:manifest=json.load(stream.extractfile('sha256.json'))
 for name,h in manifest.items():assert sha(b/name)==h,name;required[str(b/name)]=h
for stage in [559,560,561,562,563]:
 for p in (b/f'torch-iteration-{stage}').iterdir():
  if p.is_file():required[str(p)]=sha(p)
wrapper=b/'torch-iteration-67/final-integration/push-main-native.py';assert sha(wrapper)=='4b51422c5533ca6177a4a29a557cf37d1c6727d7530908e444be5833588c2882'
for p in list(r.glob('*.py'))+[r/'guard-provenance.json',r/'release-policy-identity.json',r/'release-policy-variants.json',r/'commit-receipt.json',wrapper]:required[str(p)]=sha(p)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();names=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0');reviewed={n:sha(repo/n) for n in names if n}
write(r/'qualification-grant.json',dict(head=head,source_resources=66,runtime_resources=resources,ci_triggered=False,version='0.83.0',local_qualification_complete=True,scope='Qualified bounded resident developer GPU session; no application/default runtime delta',required_files=[dict(path=n,sha256=h) for n,h in required.items()],reviewed_commit_files=reviewed))
write(r/'grant-receipt.json',dict(head=head,remote_baseline=integration['remote_baseline'],tracked_files=len(reviewed),required_files=len(required),own_delta=delta,default_runtime_unchanged=True,public_package_inputs_unchanged=True,ci_triggered=False,goal_status='active'));print(json.dumps(dict(head=head,tracked_files=len(reviewed),required_files=len(required))))
