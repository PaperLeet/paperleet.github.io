from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');py=r.parent.parent/'torch-iteration-21/stride-dev-env/bin/python'
with (r/'frontend-runner.log').open('w') as log:subprocess.check_call([str(py),str(r/'run-frontend.py')],cwd=repo,stdout=log,stderr=subprocess.STDOUT)
context=json.loads((r/'context.json').read_text());scripts=json.loads((repo/'web/package.json').read_text())['scripts'];coverage={};receipts=[]
for path in context['changed_files']:
    if not path.startswith('web/scripts/check-'):continue
    name=Path(path).name
    if 'scripts/'+name in scripts['check']:coverage[path]='npm check'
    elif 'scripts/'+name in scripts['build']:coverage[path]='both typed builds'
    else:
        args=['/opt/homebrew/bin/node','scripts/'+name];start=time.monotonic()
        with (r/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=repo/'web',env=dict(os.environ,PYTHON=str(py)),stdout=log,stderr=subprocess.STDOUT)
        receipts.append(dict(args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-start));p.check_returncode();coverage[path]='additional changed-script check'
(r/'additional-receipts.json').write_text(json.dumps(dict(coverage=coverage,receipts=receipts),indent=2)+'\n')
print('Latest full frontend/two typed builds and all changed-script coverage pass',flush=True)
