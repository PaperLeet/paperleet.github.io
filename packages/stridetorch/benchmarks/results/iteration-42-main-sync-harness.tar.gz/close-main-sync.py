from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;s=r/'main-sync-proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
context=json.loads((s/'context.json').read_text());front=json.loads((s/'frontend-receipts.json').read_text());extra=json.loads((s/'additional-receipts.json').read_text())
assert len(front)==5 and all(v['exit_code']==0 for v in front+extra['receipts'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==context['upstream']
assert len(context['changed_files'])==11 and len(context['source_hashes'])==49 and len(context['active_export_sha256'])==161
changed_scripts={name for name in context['changed_files'] if name.startswith('web/scripts/check-')}
assert set(extra['coverage'])==changed_scripts
scripts=json.loads((repo/'web/package.json').read_text())['scripts']
for name,coverage in extra['coverage'].items():
    short='scripts/'+Path(name).name
    if coverage=='npm check':assert short in scripts['check']
    elif coverage=='both typed builds':assert short in scripts['build']
    else:assert any(short in v['args'] and v['exit_code']==0 for v in extra['receipts'])
for name,digest in context['changed_files'].items():
    assert sha(s/'incoming'/name)==sha(repo/name)==digest
    assert hashlib.sha256(subprocess.check_output(['git','show',context['upstream']+':'+name],cwd=repo)).hexdigest()==digest
for name,digest in context['source_hashes'].items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==digest
for name,digest in context['active_export_sha256'].items():assert sha(repo/'web/public/data'/name)==digest
for name,digest in json.loads((r/'canonical-policy-identity.json').read_text())['hashes'].items():assert sha(repo/name)==digest
shutil.copy2(Path(__file__),s/'close-main-sync.py')
archive=out/'iteration-42-main-sync-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for path in sorted(s.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:tar.add(path,arcname=str(path.relative_to(s)),recursive=False)
report=dict(status='complete_local_latest_frontend_passed_runtime_identity_unchanged',version='0.42.0',context=context,frontend_receipts=front,changed_script_coverage=extra,
            archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),
            scope='11 incoming frontend/check/style/documentation changes;package.json check command only. Full latest frontend suite,both typed builds and all changed-script coverage pass. All49 runtime/license and161 active-export identities retain full CPU/native/WASM evidence. No Python,catalog,SDK,dependency/lock or canonical policy input changed.',
            publication='No tag,dispatch,package upload or online publication by this task.')
(out/'iteration-42-main-sync.json').write_text(json.dumps(report,indent=2)+'\n')
doc=repo/'docs/validation/torch-runtime-iteration-42.md'
doc.write_text(doc.read_text()+f'\nLatest upstream `{context["upstream"]}` adds 11 frontend/check/style/documentation\nchanges. They were retained by fast-forward, and the full latest frontend suite,\nboth typed builds and every changed check script pass. All 49 source/license\nand 161 active-export identities remain exact; existing numerical/native/full-\nWASM evidence retains unchanged inputs. See `iteration-42-main-sync.json`\nand `iteration-42-main-sync-harness.tar.gz`.\n')
print(json.dumps(dict(upstream=context['upstream'],changed=11,source_unchanged=49,exports_unchanged=161,archive=report['archive'])))
