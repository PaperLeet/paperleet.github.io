"""Audit the exact 0.65 CPU allocation fixture and native dual aliasing."""
from pathlib import Path
import hashlib,json
import numpy as np
import torch as native
import bench_determinants as common

r=Path(__file__).resolve().parent;old,hashes=common.load('_stride_audit_old',r/'baseline-source/stridetorch');rows=[]
assert native.__version__.startswith('2.14.1') and native.version.git_version=='5c4886908584029761b579af026dcfb627c84070'
for dtype in ['float32','float64']:
    for shape in [(64,64),(4,32,32)]:
        data=common._data(shape,dtype);direction=np.broadcast_to(np.eye(shape[-1])*.2,shape).astype(dtype)
        a=old.torch.tensor(data,requires_grad=True);e=old.torch.tensor(direction,requires_grad=True)
        na=native.tensor(data,requires_grad=True);ne=native.tensor(direction,requires_grad=True)
        assert a.stride()==na.stride() and e.stride()==ne.stride()
        with native.autograd.forward_ad.dual_level():
            dual=native.autograd.forward_ad.make_dual(na,ne);tangent=native.autograd.forward_ad.unpack_dual(dual).tangent
            before=tangent._version
            with native.no_grad():ne.add_(1)
            rows.append(dict(dtype=dtype,shape=shape,matrix_bytes=data.nbytes,primal_stride=list(a.stride()),direction_stride=list(e.stride()),native_dual_stride=list(tangent.stride()),native_dual_shares_direction_version=tangent._version!=before))
report=dict(status='verified',numpy=np.__version__,native_version=native.__version__,native_git=native.version.git_version,source_hashes=hashes,rows=rows,scope='Exact original 0.65 CPU tracemalloc fixture, before allocation tracing. Interleaved batch direction triggers a native feature-stride copy; matching 2D direction aliases. No old numerical result is rewritten.')
(r/'direction-stride-audit.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified original allocation fixture strides and native dual version sharing')
