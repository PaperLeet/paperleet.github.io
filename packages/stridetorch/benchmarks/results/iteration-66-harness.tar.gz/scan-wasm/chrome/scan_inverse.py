"""Development crossover scan: actual inverse JVP full steps, no adoption claim."""
import gc,hashlib,json,statistics,time
from pathlib import Path
import bench_inverse as bench

def run(baseline_source,candidate_source):
    old,oh=bench.common.load('_scan_old',baseline_source);new,nh=bench.common.load('_scan_new',candidate_source);rows=[]
    for dtype in ['float32','float64']:
        for n in [1,2,3,4,8,12,16,24,32,64]:
            shape=(n,n);data=bench.common._data(shape,dtype);direction=(data*.1).copy()
            variants={label:bench.method(module,data,direction,'inverse_jvp',True,True) for label,module in [('baseline',old),('candidate',new)]}
            bench.compare(variants['candidate'][1](),variants['baseline'][1](),dtype,2)
            gc.collect();calls=1;functions={label:method[0] for label,method in variants.items()}
            for fn in functions.values():
                batch=1
                while True:
                    started=time.perf_counter()
                    for _ in range(batch):fn()
                    if time.perf_counter()-started>=.02:break
                    batch*=2
                calls=max(calls,batch)
            samples={label:[] for label in functions}
            for repeat in range(5):
                for label in functions if repeat%2==0 else reversed(functions):
                    started=time.perf_counter()
                    for _ in range(calls):functions[label]()
                    samples[label].append((time.perf_counter()-started)/calls)
            medians={label:statistics.median(values) for label,values in samples.items()}
            rows.append(dict(dtype=dtype,n=n,calls=calls,samples_s=samples,candidate_over_baseline=medians['candidate']/medians['baseline']))
    return dict(source_hashes=dict(baseline=oh,candidate=nh),program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows,scope='One development child: 20 actual prior-API full-step workflows at ten sizes, two dtypes, common >=20ms calibrated batches and five alternating samples. Inputs/weights predate timing. Not the final formal result.')

if __name__=='__main__':
    import sys
    print(json.dumps(run(sys.argv[1],sys.argv[2]),indent=2))
