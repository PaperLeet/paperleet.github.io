from pathlib import Path
import hashlib,json
import numpy as np
r=Path(__file__).resolve().parent
reference=json.loads((r/'native-jvp.json').read_text());candidate=json.loads((r/'adapter-jvp.json').read_text())
assert reference['input_sha256']==candidate['input_sha256']==hashlib.sha256((r/'jvp-inputs.npz').read_bytes()).hexdigest()
assert reference['driver_sha256']==candidate['driver_sha256']==hashlib.sha256((r/'differential-jvp.py').read_bytes()).hexdigest()
assert reference['version'].startswith('2.14.1') and reference['native_git']=='5c4886908584029761b579af026dcfb627c84070'
expected=json.loads((r/'jvp-expected-source.json').read_text());assert candidate['source_hashes']==expected and len(expected)==61
assert candidate['version']=='0.66.0'
native=np.load(r/'native-jvp.npz');actual=np.load(r/'adapter-jvp.npz');arrays=none_fields=0;layouts=[];normwise=[];singleton_zero_signs=0
assert reference['rows'].keys()==candidate['rows'].keys() and len(reference['rows'])==696
for key,row in reference['rows'].items():
 other=candidate['rows'][key];assert row['status']==other['status']=='ok',(key,row.get('message'),other.get('message'))
 assert {k:v for k,v in row.items() if k!='values'}=={k:v for k,v in other.items() if k!='values'},key
 for field,meta in row['values'].items():
  found=other['values'][field]
  if meta is None:
   assert found is None,(key,field);none_fields+=1;continue
  assert found is not None,(key,field)
  assert {k:v for k,v in meta.items() if k!='stride'}=={k:v for k,v in found.items() if k!='stride'},(key,field)
  if meta['stride']!=found['stride']:
   assert field in ('stored_a','stored_e') and meta['shape']==[1,1] and all(v>0 for v in meta['stride']+found['stride']),(key,field,meta,found)
   layouts.append(dict(case=key,field=field,native=meta['stride'],candidate=found['stride'],scope='Equivalent positive singleton strides under the established owned-gradient layout contract.'))
  name=key+'.'+field;x=native[name];y=actual[name];arrays+=1
  for fn in [np.isnan,np.isposinf,np.isneginf]:np.testing.assert_array_equal(fn(y),fn(x),err_msg=name)
  finite=np.isfinite(x)
  if row['dtype']=='float32' and row['shape'][-1]>=8 and x.ndim>=2:
   for index in np.ndindex(x.shape[:-2]):
    mask=finite[index];a=x[index][mask].astype('float64');b=y[index][mask].astype('float64');scale=float(np.max(np.abs(a),initial=0));error=float(np.max(np.abs(a-b),initial=0))
    assert error<=1e-5*scale,(name,index,error,scale)
   normwise.append(name)
  else:np.testing.assert_allclose(y[finite],x[finite],rtol=2e-5 if row['dtype']=='float32' else 3e-12,atol=0,err_msg=name)
  if row['shape'][-1]==1 and field in ('primal','tangent'):
   zero=(x==0)&(y==0);np.testing.assert_array_equal(np.signbit(y[zero]),np.signbit(x[zero]),err_msg=name);singleton_zero_signs+=int(np.count_nonzero(zero))
assert arrays==3132 and len(layouts)==48
result=dict(status='success',cases=696,numeric_arrays=arrays,none_fields=none_fields,singleton_owned_layout_qualifications=layouts,normwise_float32_matrix_arrays=normwise,singleton_zero_sign_values=singleton_zero_signs,input_sha256=reference['input_sha256'],driver_sha256=reference['driver_sha256'],scope='696 native 2.14.1 determinant JVP controls; real float32/64, C/F/sliced inputs/directions, all four requires-grad pairs, primal/tangent/reverse/stored gradients and returned-primal hooks. Finite componentwise tolerance float32 2e-5 / float64 3e-12; float32 matrix gradients for n>=8 use per-matrix max-norm relative bound 1e-5 to handle near-zero entries. NaN/Inf masks are exact. Singleton zero signs are exact. Ordinary det singular-cofactor semantics are checked separately.')
result.update(source_hashes=expected,version='0.66.0',native_version=reference['version'],native_git=reference['native_git'])
(r/'jvp-qualification.json').write_text(json.dumps(result,indent=2)+'\n')
print('696 native JVP cases:',arrays,'arrays;',none_fields,'None fields;',len(layouts),'equivalent singleton stored-layout qualifications')
