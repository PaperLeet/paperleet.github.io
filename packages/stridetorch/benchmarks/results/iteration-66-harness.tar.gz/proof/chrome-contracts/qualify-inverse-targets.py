from pathlib import Path
import json,sys
import numpy as np

r=Path(__file__).resolve().parent;label=sys.argv[1] if len(sys.argv)>1 else 'adapter'
old=json.loads((r/'native-inverse-targets.json').read_text());new=json.loads((r/(label+'-inverse-targets.json')).read_text())
assert old['input_sha256']==new['input_sha256'] and old['driver_sha256']==new['driver_sha256']
assert old['rows'].keys()==new['rows'].keys() and len(old['rows'])==480
reference=np.load(r/'native-inverse-targets.npz');actual=np.load(r/(label+'-inverse-targets.npz'));assert set(reference.files)==set(actual.files)
arrays=none=normwise=0
for key,want in old['rows'].items():
    got=new['rows'][key]
    assert {k:v for k,v in want.items() if k!='fields'}=={k:v for k,v in got.items() if k!='fields'},(key,'state')
    assert want['fields']==got['fields'],(key,'layout',want['fields'],got['fields'])
    for name,meta in want['fields'].items():
        if meta is None:none+=1;continue
        a=actual[key+'.'+name];b=reference[key+'.'+name];assert a.dtype==b.dtype and a.shape==b.shape
        for fn in [np.isnan,np.isposinf,np.isneginf]:np.testing.assert_array_equal(fn(a),fn(b),err_msg=key+'.'+name)
        if a.size and a.shape[-1]>=8:
            scale=np.max(np.abs(b.astype('float64')),axis=(-2,-1));error=np.max(np.abs(a.astype('float64')-b.astype('float64')),axis=(-2,-1));bound=1e-5 if a.dtype==np.dtype('float32') else 3e-12
            assert np.all(error<=bound*scale),(key,name,error,scale);normwise+=1
        else:np.testing.assert_allclose(a,b,rtol=3e-5 if a.dtype==np.dtype('float32') else 3e-12,atol=3e-7 if a.dtype==np.dtype('float32') else 3e-14,err_msg=key+'.'+name)
        arrays+=1
report=dict(status='success',contexts=len(old['rows']),numeric_arrays=arrays,none_fields=none,normwise_arrays=normwise,input_sha256=old['input_sha256'],driver_sha256=old['driver_sha256'],source_hashes=new['source_hashes'],scope='Exact frozen native partial-target/reuse/retained-gradient/hooks/mutation states and meaningful raw/stored strides; C/F/interleaved directions, 2x2/32x32, batched and empty groups. All IEEE masks exact; finite large matrices use explicit per-matrix relative max norm bounds, small matrices use componentwise normal-input tolerances.')
(r/(label+'-inverse-target-qualification.json')).write_text(json.dumps(report,indent=2)+'\n');print(label,len(old['rows']),'target/reuse/mutation contexts;',arrays,'arrays')
