"""Freeze final 0.66 inputs; preserve development pilots instead of reusing them."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess

r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-65';repo=Path('/Users/david/Developer/PaperLeet-torch-release')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
mapping={'iteration-65':'iteration-66','iteration-64':'iteration-65','0.65.0':'0.66.0','0.64.0':'0.65.0','stride065':'stride066'}
pattern=re.compile('|'.join(re.escape(key) for key in mapping))
numbers={'7966':'8052','7979':'8065','41596':'41682','13231':'13389','13389':'13547'}
number_pattern=re.compile(r'\b('+'|'.join(numbers)+r')\b')
def adapt(text):
    return number_pattern.sub(lambda m:numbers[m[0]],pattern.sub(lambda m:mapping[m[0]],text))

scripts=['run-oracles.py','run-minimum-oracle.py','run-full.py','run-gates.py','run-front-only.py','run-full-wasm-only.py','prepare-oracle.py','prepare-bench.py','run-bench-final.py','bench-combined.py','post-performance.py','post-performance-all.py','warm-memory.py','summarize-performance.py','summarize-inverse-performance.py','fresh-load.py','check-native-isolation.py','close-local.py','finish-source.py','record-adoption.py','verify-adoption.py','push-main-node.py','push-via-node.mjs','audit-main.py']
for name in scripts:
    assert not (r/name).exists(),name
    text=adapt((old/name).read_text())
    if name=='close-local.py':
        text=text.replace("len(tests)==58","len(tests)==60").replace("len(tests)==58","len(tests)==60").replace("len(plan['tests'])==58","len(plan['tests'])==60").replace("len(contracts['suites'])==58","len(contracts['suites'])==60").replace('suites=58','suites=60').replace('added_tests=343','added_tests=86')
    (r/name).write_text(text)

proof=r/'proof';chrome=proof/'chrome-contracts';chrome.mkdir(parents=True)
for name in ['wasm-contracts.mjs','check-wheel.py','check-coinstall.py','chrome-contracts/run.mjs','chrome-contracts/worker.mjs','chrome-contracts/index.html']:
    target=proof/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(adapt((old/'proof'/name).read_text()))
source=repo/'packages/stridetorch/src/stridetorch';tests=repo/'packages/stridetorch/tests'
for target in [proof/'source',chrome/'source']:
    target.mkdir()
    for p in [*source.glob('*.py'),source/'LICENSE',source/'NOTICE']:shutil.copy2(p,target/p.name)
(chrome/'tests').mkdir()
prior=json.loads((old/'proof/test-hashes.json').read_text())
for name in [*prior,'test_selective_joint.py','test_inverse_routing.py']:shutil.copy2(tests/name,chrome/'tests'/name)
plan=dict(source={p.name:sha(p) for p in (proof/'source').iterdir()},tests={p.name:sha(p) for p in (chrome/'tests').iterdir()},version='0.66.0',expected=8052)
assert len(plan['source'])==61 and len(plan['tests'])==60
for path,value in [(chrome/'plan.json',plan),(proof/'source-hashes.json',plan['source']),(proof/'test-hashes.json',plan['tests']),(r/'inverse-expected-source.json',plan['source']),(r/'jvp-expected-source.json',plan['source'])]:path.write_text(json.dumps(value,indent=2)+'\n')

files=['differential-determinants.py','qualify-determinants.py','differential-singleton.py','qualify-singleton.py','differential-jvp.py','qualify-jvp.py','native-determinants.json','native-determinants.npz','baseline-determinants.json','baseline-determinants.npz','determinant-inputs.npz','determinant-inputs.json','singleton-inputs.json','singleton-inputs.npz','native-singleton-controls.json','native-singleton-controls.npz','jvp-inputs.json','jvp-inputs.npz','native-jvp.json','native-jvp.npz','native-runtime.json','native-catalog-reuse.json','runtime-identity.json','release-policy-identity.json']
for name in files:
    if name.endswith('.py'):(r/name).write_text(adapt((old/name).read_text()))
    else:shutil.copy2(old/name,r/name)
# Current inverse controls were used for pilots; copy only the final driver,
# retaining the frozen corpus and pilot results as evidence.
for name in ['differential-inverse.py','qualify-inverse.py','probe-inverse-mutation-layouts.py','probe-matmul-guards.py','probe-inverse-api.py']:(r/name).write_text(adapt((old/name).read_text()))

i=r/'integration-proof';i.mkdir()
for name in ['run-export.py','run-frontend.py','verify-export.py']:
    (i/name).write_text(adapt((old/'integration-proof'/name).read_text()).replace('len(published)==13231','len(published)==13389'))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
for name in ['context.json','full-suite-baseline.json']:(i/name).write_text(json.dumps(dict(upstream=head),indent=2)+'\n')
policy=json.loads((r/'release-policy-identity.json').read_text())
for name,digest in policy['files'].items():assert sha(repo/name)==digest
identity=json.loads((r/'runtime-identity.json').read_text())
for name,digest in identity['public_runtime_files'].items():assert sha(repo/'web/public/browser-runtime/pyodide-0.29.4'/name)==digest==sha(r.parent/'runtime-0.29.4'/name)
for name in identity['node_core_files_identical']:assert sha(repo/'web/node_modules/pyodide'/name)==identity['public_runtime_files'][name]
identity['revalidated_for_version']='0.66.0';(r/'runtime-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
native=json.loads((r/'native-catalog-reuse.json').read_text())
assert native['files']==1152
for name,digest in native['native_input_sha256'].items():assert sha(repo/name)==digest
for name,digest in json.loads((r/'owned-input-sha256.json').read_text()).items():assert sha(repo/name)==digest
print('Frozen final 0.66: 61 source/license resources, 60 suites / 8052 contracts; 13389 prior immutable payloads; 1152 native inputs and 7 canonical policies unchanged')
