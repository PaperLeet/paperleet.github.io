"""Native partial-target, retained-gradient, graph reuse and mutation observations."""
from pathlib import Path
import hashlib,json,sys
import numpy as np

r=Path(__file__).resolve().parent;backend=sys.argv[1];label=sys.argv[2] if len(sys.argv)>2 else backend
if backend=='native':import torch as t
else:
 from stridetorch import torch as t
 if '--shared' in sys.argv:
  from stridetorch import _linalg
  _linalg._INVERSE_JVP_SHARED=True
rows={};arrays={};frozen_inputs=np.load(r/'inverse-target-inputs.npz');manifest=json.loads((r/'inverse-target-inputs.json').read_text())
assert hashlib.sha256((r/'inverse-target-inputs.npz').read_bytes()).hexdigest()==manifest['sha256']

def tensor(data,layout):
    if layout=='F':x=t.from_numpy(data.swapaxes(-1,-2).copy()).transpose(-1,-2)
    elif layout=='I':
        value=np.asfortranarray(data) if data.ndim==2 else np.moveaxis(np.ascontiguousarray(np.moveaxis(data,0,-1)),-1,0)
        x=t.from_numpy(value)
    else:x=t.from_numpy(data.copy())
    return x.detach().requires_grad_()

def exception(error):
    message=str(error)
    return 'modified' if 'modified' in message else 'released' if 'freed' in message or 'second time' in message else type(error).__name__

def capture(key,field,value,fields):
    if value is None:fields[field]=None;return
    fields[field]=dict(dtype=str(value.detach().numpy().dtype),shape=list(value.shape),stride=list(value.stride()))
    arrays[key+'.'+field]=value.detach().numpy().copy()

for group in manifest['groups']:
  dtype=group['dtype'];shape=tuple(group['shape']);n=shape[-1];prefix=group['key']
  a_data=frozen_inputs[prefix+'.a'];e_data=frozen_inputs[prefix+'.e'];weight=frozen_inputs[prefix+'.weight']
  for pa,pe in [('C','C'),('F','C'),('C','I')]:
   for sequence in ['A','E','AE','EA']:
    key=f'reuse.{dtype}.{shape}.{pa}{pe}.{sequence}';fields={};a=tensor(a_data,pa);e=tensor(e_data,pe);p,v=t.func.jvp(t.linalg.inv,(a,),(e,));p.retain_grad();v.retain_grad();p_seen=[];v_seen=[]
    p.register_hook(lambda gradient:p_seen.append(1));v.register_hook(lambda gradient:v_seen.append(1));states=[]
    for index,target in enumerate(sequence):
     seed=t.from_numpy((weight*(index+1)).copy())
     try:
      gradient=t.autograd.grad(v,a if target=='A' else e,seed,retain_graph=index<len(sequence)-1)[0]
      states.append('ok');capture(key,'gradient'+str(index),gradient,fields)
     except Exception as error:states.append(exception(error))
    try:
     gradient=t.autograd.grad(p,a,t.from_numpy(weight.copy()))[0];primal_state='ok';capture(key,'primal_gradient',gradient,fields)
    except Exception as error:primal_state=exception(error)
    for name,value in [('retained_primal',p.grad),('retained_tangent',v.grad),('stored_a',a.grad),('stored_e',e.grad)]:capture(key,name,value,fields)
    rows[key]=dict(states=states,primal_state=primal_state,primal_hooks=len(p_seen),tangent_hooks=len(v_seen),fields=fields)
   for target in ['A','E','both']:
    for changed in ['a','e','p','tangent']:
     key=f'mutation.{dtype}.{shape}.{pa}{pe}.{target}.{changed}';fields={};a=tensor(a_data,pa);e=tensor(e_data,pe);p,v=t.func.jvp(t.linalg.inv,(a,),(e,))
     with t.no_grad():{'a':a,'e':e,'p':p,'tangent':v}[changed].detach().add_(1)
     try:
      inputs=(a,e) if target=='both' else (a,) if target=='A' else (e,);gradients=t.autograd.grad(v,inputs,t.from_numpy(weight.copy()));state='ok'
      for index,value in enumerate(gradients):capture(key,'gradient'+str(index),value,fields)
     except Exception as error:state=exception(error)
     rows[key]=dict(state=state,fields=fields)

np.savez_compressed(r/(label+'-inverse-targets.npz'),**arrays)
report=dict(backend=backend,forced_shared='--shared' in sys.argv,rows=rows,arrays=len(arrays),input_sha256=manifest['sha256'],driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
if backend=='native':
 report.update(native_version=t.__version__,native_git=t.version.git_version)
 assert report['native_version'].startswith('2.14.1') and report['native_git']=='5c4886908584029761b579af026dcfb627c84070'
else:
 import stridetorch
 source=Path(stridetorch.__file__).parent;report['source_hashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']}
(r/(label+'-inverse-targets.json')).write_text(json.dumps(report,indent=2)+'\n')
print(label,len(rows),'partial-target/reuse/mutation contexts;',len(arrays),'arrays')
