"""A diagnostic for the next iteration; deliberately does not change runtime code."""
from pathlib import Path
import gc,hashlib,json,sys,weakref
import numpy as np

r=Path(__file__).resolve().parent
sys.path.insert(0,'/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src')
from stridetorch import torch
from stridetorch._autograd import joint_result

rows=[]
for retain in [False,True]:
    x=torch.tensor([2.],requires_grad=True);middle=x*2;payload=np.ones(4096);reference=weakref.ref(payload);mode={'retain':retain}
    def build(data):
        def backward(g,needs):return (g+data[0]*0,)
        return joint_result(middle.numpy().copy(),(middle,),backward)
    output=build(payload);node=output._grad_node;del payload
    def hook(g):
        rows.append(dict(retain_graph=mode['retain'],joint_node_released=node.released,joint_descriptor_cleared=node.joint is None,payload_alive_in_predecessor=reference() is not None))
    middle.register_hook(hook);output.sum().backward(retain_graph=retain);gc.collect();rows[-1]['payload_alive_after_traversal']=reference() is not None
    if retain:
        mode['retain']=False;output.sum().backward();gc.collect();rows[-1]['payload_alive_after_traversal']=reference() is not None
assert rows[0]['joint_node_released'] and rows[0]['payload_alive_in_predecessor'] and not rows[0]['payload_alive_after_traversal']
assert not rows[1]['joint_node_released'] and rows[1]['payload_alive_after_traversal']
assert rows[2]['joint_node_released'] and not rows[2]['payload_alive_after_traversal']
source=Path('/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src/stridetorch/_graph.py')
report=dict(status='observed',source_graph_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),rows=rows,scope='Diagnostic only. The current joint callback payload can remain live in engine locals after its node releases, until traversal exits. It is not a leak or a production fix; inspect callback/gradient local lifetimes next. This observation alone does not attribute the entire measured peak difference to one cause.')
(r/'next-memory-lifetime-observation.json').write_text(json.dumps(report,indent=2)+'\n')
print('Observed callback payload lifetime beyond node release, with correct eventual/retained graph ownership')
