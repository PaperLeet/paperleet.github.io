from pathlib import Path
import hashlib,json
import numpy as np

r=Path(__file__).resolve().parent;arrays={};groups=[]
for dtype in ['float32','float64']:
    for shape in [(2,2),(2,3,3),(0,2,2),(32,32),(2,32,32)]:
        key=str(len(groups));n=shape[-1]
        data=np.broadcast_to(np.eye(n)*2,shape).copy()+np.sin(np.arange(np.prod(shape)).reshape(shape)*.13)*.1
        direction=np.cos(np.arange(np.prod(shape)).reshape(shape)*.17)*.3
        weight=np.sin(np.arange(np.prod(shape)).reshape(shape)*.19+.2)
        for name,value in [('a',data),('e',direction),('weight',weight)]:arrays[key+'.'+name]=value.astype(dtype)
        groups.append(dict(key=key,dtype=dtype,shape=list(shape)))
np.savez_compressed(r/'inverse-target-inputs.npz',**arrays)
(r/'inverse-target-inputs.json').write_text(json.dumps(dict(groups=groups,arrays=len(arrays),sha256=hashlib.sha256((r/'inverse-target-inputs.npz').read_bytes()).hexdigest()),indent=2)+'\n')
print('Froze',len(groups),'groups /',len(arrays),'exact partial-target input arrays')
