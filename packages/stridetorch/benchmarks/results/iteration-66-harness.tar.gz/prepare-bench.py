from pathlib import Path
import hashlib,json,shutil

r=Path(__file__).resolve().parent;p=r/'proof';c=p/'chrome-contracts'
repo=Path('/Users/david/Developer/PaperLeet-torch-release')
def hashes(folder):return {f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in folder.iterdir() if f.is_file()}
baseline=r/'baseline-source/stridetorch';candidate=repo/'packages/stridetorch/src/stridetorch'
assert hashes(candidate)==json.loads((p/'source-hashes.json').read_text())
shutil.copytree(baseline,c/'baseline',dirs_exist_ok=True)
bench=repo/'packages/stridetorch/benchmarks/bench_determinants.py';shutil.copy2(bench,c/'bench_determinants.py');shutil.copy2(r/'bench_inverse.py',c/'bench_inverse.py')
for name in ['bench_joint.py', 'bench_groupnorm_fixture.py', 'bench_classification_fixture.py']:shutil.copy2(r/name,c/name)
plan=dict(baseline=hashes(baseline),candidate=hashes(candidate),benchmark_sha256=hashlib.sha256(bench.read_bytes()).hexdigest(),inverse_benchmark_sha256=hashlib.sha256((r/'bench_inverse.py').read_bytes()).hexdigest())
plan['joint_benchmark_sha256']=hashlib.sha256((r/'bench_joint.py').read_bytes()).hexdigest()
plan['joint_fixture_sha256']={name:hashlib.sha256((r/name).read_bytes()).hexdigest() for name in ['bench_groupnorm_fixture.py', 'bench_classification_fixture.py']}
(c/'bench-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
worker="""import {loadJudgePackages} from '../../../extraction-browser/packages.mjs';
self.onmessage=async()=>{try{
 const plan=await(await fetch('./bench-plan.json')).json();
 const {loadPyodide}=await import('../../../runtime-0.29.4/pyodide.mjs');
 const py=await loadPyodide({indexURL:new URL('../../../runtime-0.29.4/',self.location.href).href,stdout(){},stderr(){}});
 await loadJudgePackages(py,[]);
 for(const [name,dir] of [['baseline','baseline'],['candidate','source']]){
  py.FS.mkdirTree('/'+name+'/stridetorch');
  for(const file of Object.keys(plan[name]))py.FS.writeFile('/'+name+'/stridetorch/'+file,await(await fetch('./'+dir+'/'+file)).text());
 }
 py.FS.writeFile('/bench_determinants.py',await(await fetch('./bench_determinants.py')).text());
 py.FS.writeFile('/bench_inverse.py',await(await fetch('./bench_inverse.py')).text());
 for(const name of ['bench_joint.py', 'bench_groupnorm_fixture.py', 'bench_classification_fixture.py'])py.FS.writeFile('/'+name,await(await fetch('./'+name)).text());
 py.globals.set('plan_json',JSON.stringify(plan));
 const result=JSON.parse(py.runPython(`
import sys,json,pathlib,hashlib
sys.path.insert(0,'/')
plan=json.loads(plan_json)
for label in ['baseline','candidate']:
 actual={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in pathlib.Path('/'+label+'/stridetorch').iterdir() if f.is_file()}
 assert actual==plan[label]
assert hashlib.sha256(pathlib.Path('/bench_determinants.py').read_bytes()).hexdigest()==plan['benchmark_sha256']
import numpy
from bench_determinants import run
bench=run('/baseline/stridetorch','/candidate/stridetorch')
from bench_inverse import run as run_inverse
bench['inverse_benchmark']=run_inverse('/baseline/stridetorch','/candidate/stridetorch')
assert bench['inverse_benchmark']['program_sha256']==plan['inverse_benchmark_sha256']
from bench_joint import run as run_joint
bench['joint_benchmark']=run_joint('/baseline/stridetorch','/candidate/stridetorch')
assert bench['joint_benchmark']['source_hashes']==bench['source_hashes']
assert bench['joint_benchmark']['program_sha256']==plan['joint_benchmark_sha256']
assert bench['joint_benchmark']['fixture_hashes']==plan['joint_fixture_sha256']
assert bench['source_hashes']==dict(baseline=plan['baseline'],candidate=plan['candidate'])
json.dumps(dict(status='success',numpy=numpy.__version__,benchmark_sha256=plan['benchmark_sha256'],benchmark=bench))
`));self.postMessage({...result,pyodide:py.version});
}catch(error){self.postMessage({error:String(error.stack||error)});}};
"""
(c/'bench-worker.mjs').write_text(worker)
s=(c/'run.mjs').read_text().replace("'./worker.mjs'","'./bench-worker.mjs'").replace("'result.json'","'bench-result.json'")
s=s.replace("['run.mjs','worker.mjs','plan.json']","['bench-run.mjs','bench-worker.mjs','bench-plan.json']").replace('},120000)','},300000)')
(c/'bench-run.mjs').write_text(s)
node="""import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const base=new URL('./chrome-contracts/',import.meta.url);const plan=JSON.parse(fs.readFileSync(new URL('bench-plan.json',base)));
const py=await loadPyodide({indexURL:'/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/',packageCacheDir:'/Users/david/Developer/PaperLeet-torch-release/web/public/browser-runtime/pyodide-0.29.4/',stdout(){},stderr(){}});
await loadJudgePackages(py,[]);
for(const [name,dir] of [['baseline','baseline'],['candidate','source']]){
 py.FS.mkdirTree('/'+name+'/stridetorch');
 for(const file of Object.keys(plan[name]))py.FS.writeFile('/'+name+'/stridetorch/'+file,fs.readFileSync(new URL(dir+'/'+file,base)));
}
py.FS.writeFile('/bench_determinants.py',fs.readFileSync(new URL('bench_determinants.py',base)));
py.FS.writeFile('/bench_inverse.py',fs.readFileSync(new URL('bench_inverse.py',base)));
for(const name of ['bench_joint.py', 'bench_groupnorm_fixture.py', 'bench_classification_fixture.py'])py.FS.writeFile('/'+name,fs.readFileSync(new URL(name,base)));
py.globals.set('plan_json',JSON.stringify(plan));
const result=JSON.parse(py.runPython(`
import sys,json,pathlib,hashlib
sys.path.insert(0,'/')
plan=json.loads(plan_json)
for label in ['baseline','candidate']:
 actual={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in pathlib.Path('/'+label+'/stridetorch').iterdir() if f.is_file()}
 assert actual==plan[label]
assert hashlib.sha256(pathlib.Path('/bench_determinants.py').read_bytes()).hexdigest()==plan['benchmark_sha256']
import numpy
from bench_determinants import run
bench=run('/baseline/stridetorch','/candidate/stridetorch')
from bench_inverse import run as run_inverse
bench['inverse_benchmark']=run_inverse('/baseline/stridetorch','/candidate/stridetorch')
assert bench['inverse_benchmark']['program_sha256']==plan['inverse_benchmark_sha256']
from bench_joint import run as run_joint
bench['joint_benchmark']=run_joint('/baseline/stridetorch','/candidate/stridetorch')
assert bench['joint_benchmark']['source_hashes']==bench['source_hashes']
assert bench['joint_benchmark']['program_sha256']==plan['joint_benchmark_sha256']
assert bench['joint_benchmark']['fixture_hashes']==plan['joint_fixture_sha256']
assert bench['source_hashes']==dict(baseline=plan['baseline'],candidate=plan['candidate'])
json.dumps(dict(status='success',numpy=numpy.__version__,benchmark_sha256=plan['benchmark_sha256'],benchmark=bench))
`));result.pyodide=py.version;assert.equal(result.numpy,'2.2.5');
fs.writeFileSync(new URL("bench-node-result.json",import.meta.url),JSON.stringify(result,null,2)+String.fromCharCode(10));
console.log(JSON.stringify({status:result.status,flows:result.benchmark.rows.length,pyodide:result.pyodide,numpy:result.numpy}));
"""
(p/'bench-node.mjs').write_text(node)
print(dict(baseline=len(plan['baseline']),candidate=len(plan['candidate']),regression_flows=100,inverse_flows=44,joint_flows=26))
