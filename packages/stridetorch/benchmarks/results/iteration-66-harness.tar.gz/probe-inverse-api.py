from pathlib import Path
import json,sys
import numpy as np
if sys.argv[1]=='native':import torch as t
else:from stridetorch import torch as t
r=Path(__file__).resolve().parent;rows=[]
for dtype in ['float32','float64','complex64','complex128']:
 for shape in [(1,1),(2,2),(2,2,2),(0,0),(2,0,0),(0,2,2)]:
  data=np.broadcast_to(np.eye(shape[-1])*2,shape).astype(dtype).copy()
  if 'complex' in dtype:data+=np.broadcast_to(np.eye(shape[-1])*.1j,shape).astype(dtype)
  for alias in ['linalg','top','method','A_keyword','input_keyword']:
   row=dict(dtype=dtype,shape=shape,alias=alias)
   try:
    x=t.from_numpy(data);y=t.linalg.inv(x) if alias=='linalg' else t.inverse(x) if alias=='top' else x.inverse() if alias=='method' else t.linalg.inv(A=x) if alias=='A_keyword' else t.linalg.inv(input=x)
    row.update(status='ok',stride=y.stride(),dtype_out=str(y.numpy().dtype),value=y.numpy().tolist() if 'complex' not in dtype else None)
   except Exception as error:row.update(status='error',error=type(error).__name__,message=str(error)[:160])
   rows.append(row)
mutations=[]
for target in ['input','output']:
 a=t.from_numpy(np.array([[2.,.3],[.4,3.]])).requires_grad_();y=t.linalg.inv(a)
 with t.no_grad():(a if target=='input' else y).detach().add_(1.)
 try:y.sum().backward();mutations.append(dict(target=target,status='ok'))
 except RuntimeError:mutations.append(dict(target=target,status='guarded'))
(r/('api-'+sys.argv[1]+'.json')).write_text(json.dumps(dict(rows=rows,mutations=mutations),indent=2)+'\n')
print(sys.argv[1],'API successes',sum(x['status']=='ok' for x in rows),'/',len(rows),'mutations',mutations)
