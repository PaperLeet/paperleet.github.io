from pathlib import Path
import json,sys
import numpy as np
if sys.argv[1]=='native':import torch as t
else:from stridetorch import torch as t
def tensor(data,layout,requires):
 if layout=='F':value=t.from_numpy(data.swapaxes(-1,-2).copy()).transpose(-1,-2)
 elif layout=='S':
  backing=np.zeros((*data.shape[:-2],data.shape[-2]*2,data.shape[-1]*2));backing[...,::2,::2]=data;value=t.from_numpy(backing)[...,::2,::2]
 else:value=t.from_numpy(data.copy())
 return value.detach().requires_grad_(requires)
rows=[]
for shape in [(1,1),(2,2),(2,2,2),(0,0),(0,2,2)]:
 for a_layout in ['C','F','S']:
  for e_layout in ['C','F','S']:
   for needs in [(True,True),(True,False),(False,True)]:
    for target in ['input','direction','primal','tangent']:
     for channel in ['primal','tangent']:
      data=np.broadcast_to(np.eye(shape[-1])*2,shape).copy();a=tensor(data,a_layout,needs[0]);e=tensor(np.ones(shape),e_layout,needs[1]);p,v=t.func.jvp(t.linalg.inv,(a,),(e,));value=p if channel=='primal' else v
      row=dict(shape=shape,a_layout=a_layout,e_layout=e_layout,needs=needs,target=target,channel=channel)
      with t.no_grad():{'input':a,'direction':e,'primal':p,'tangent':v}[target].detach().add_(1)
      if not value.requires_grad:row['status']='no_graph'
      else:
       try:value.sum().backward();row['status']='ok'
       except RuntimeError:row['status']='guarded'
      rows.append(row)
r=Path(__file__).resolve().parent;(r/('mutation-layouts-'+sys.argv[1]+'.json')).write_text(json.dumps(rows,indent=2)+'\n');print(sys.argv[1],len(rows),'cases')
