from pathlib import Path
import json
import os
import subprocess
import time

root = Path(__file__).resolve().parent
proof = root / 'integration-proof'
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
baseline = json.loads((proof / 'full-suite-baseline.json').read_text())['upstream']
env = dict(os.environ, PYTHON=str(root.parent / 'torch-iteration-21/stride-dev-env/bin/python'))
env['PATH'] = '/opt/homebrew/bin:' + str(Path(env['PYTHON']).parent) + ':' + env['PATH']
env['PYTHONPATH'] = os.pathsep.join([str(repo / 'packages/stridetorch/src'), str(repo)])
env.update(OMP_NUM_THREADS='2', MKL_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2',
           VECLIB_MAXIMUM_THREADS='2')
value = subprocess.check_output([
    'gh', 'api', 'repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED',
    '--jq', '.value'], text=True).strip()
profile = dict(
    VITE_PUBLIC_SITE='0' if value == '1' else '1',
    VITE_APP_EDITION='hosted' if value == '1' else 'local',
    VITE_API_ORIGIN='https://app.paperleet.com' if value == '1' else '',
    VITE_HOSTED_APP_AVAILABLE='1', VITE_HOSTED_APP_URL='https://app.paperleet.com')
(proof / 'current-pages-profile.json').write_text(json.dumps(
    dict(observed_value=value, environment=profile), indent=2) + '\n')
checks = ['full-frontend-check']
receipts = []
script = json.loads((repo / 'web/package.json').read_text())['scripts']['check']
record = dict(status='running', upstream=head, full_suite_baseline=baseline,
              checks=checks, receipts=receipts, full_frontend=True,
              frontend_check_commands=len(script.split('&&')),
              scope='Complete current npm check suite plus WASM driver, Pages policy and both build profiles after disjoint UI/docs synchronization.')

def run(args, label, cwd, overrides=None):
    started = time.time()
    with (proof / ('latest-' + label + '.log')).open('w') as log:
        subprocess.run(args, cwd=cwd, env={**env, **(overrides or {})},
                       stdout=log, stderr=subprocess.STDOUT, check=True)
    receipts.append(dict(label=label, args=args, cwd=str(cwd), exit_code=0,
                         elapsed_s=time.time() - started))
    (proof / 'latest-ui-qualification.json').write_text(json.dumps(record, indent=2) + '\n')
    print(label, 'PASS', flush=True)

run(['npm', 'run', 'check'], 'full-frontend-check', repo / 'web')
run(['/opt/homebrew/bin/node', 'web/scripts/check-wasm-cases.mjs'], 'wasm-driver', repo)
run(['/opt/homebrew/bin/node', 'web/scripts/check-pages-release.cjs'], 'pages-policy', repo)
run(['npm', 'run', 'build'], 'build', repo / 'web')
run(['npm', 'run', 'build'], 'pages-profile-build', repo / 'web', profile)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == head
record['status'] = 'qualified'
(proof / 'latest-ui-qualification.json').write_text(json.dumps(record, indent=2) + '\n')
print('CURRENT MAIN UI QUALIFIED', head, flush=True)
