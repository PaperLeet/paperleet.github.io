from pathlib import Path
import hashlib,json,sys,warnings
import numpy as np
if sys.argv[1]=='native':
 import torch as t
 source_hashes=None;version=t.__version__;native_git=t.version.git_version
else:
 import stridetorch as package
 t=package.torch;version=package.__version__;native_git=None;source=Path(package.__file__).parent
 source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
r=Path(__file__).resolve().parent;plan=json.loads((r/'inverse-inputs.json').read_text());inputs=np.load(r/'inverse-inputs.npz');rows={};arrays={}
def tensor(data,layout,requires):
 if layout=='F':value=t.from_numpy(data.swapaxes(-1,-2).copy()).transpose(-1,-2)
 elif layout=='S':
  backing=np.zeros((*data.shape[:-2],data.shape[-2]*2,data.shape[-1]*2),dtype=data.dtype);backing[...,::2,::2]=data;value=t.from_numpy(backing)[...,::2,::2]
 else:value=t.from_numpy(data.copy())
 return value.detach().requires_grad_(requires)
for item in plan['cases']:
 key=item['key'];a=inputs[key+'.a']
 for li,layout in enumerate(['C','F','S']):
  flags=[(True,True),(True,False),(False,True),(False,False)] if item['mode']=='jvp' else [(False,False)]
  for fi,(need_a,need_e) in enumerate(flags):
   direction_layout=['C','F','S'][(li+fi+item['index'])%3];name=f'{key}.{layout}.{fi}';meta=dict(**item,layout=layout,direction_layout=direction_layout,need_a=need_a,need_e=need_e)
   try:
    with warnings.catch_warnings():
     warnings.simplefilter('ignore');x=tensor(a,layout,need_a)
     if item['mode']=='forward':values=dict(primal=t.linalg.inv(A=x))
     else:
      e=inputs[key+'.e'];seed=t.from_numpy(inputs[key+'.seed'].copy());direction=tensor(e,direction_layout,need_e);p,v=t.func.jvp(t.linalg.inv,(x,),(direction,));values=dict(primal=p,tangent=v);hook=[]
      if p.requires_grad:p.retain_grad();p.register_hook(lambda g:hook.append(g.detach().clone()))
      if v.requires_grad:
       active=tuple(value for value,needed in [(x,need_a),(direction,need_e)] if needed);gradients=iter(t.autograd.grad(v,active,seed,retain_graph=True,allow_unused=True))
       values['gradient_a']=next(gradients) if need_a else None;values['gradient_e']=next(gradients) if need_e else None
       values['retained_primal']=p.grad.detach().clone() if p.grad is not None else None;values['hook_primal']=hook[0] if hook else None
       values['primal_gradient_a']=t.autograd.grad(p,x,seed,retain_graph=True)[0] if need_a else None
       v.backward(seed);values['stored_a']=x.grad;values['stored_e']=direction.grad
      else:
       for field in ['gradient_a','gradient_e','retained_primal','hook_primal','primal_gradient_a','stored_a','stored_e']:values[field]=None
    schema={}
    for field,value in values.items():
     if value is None:schema[field]=None;continue
     data=value.detach().numpy();arrays[name+'.'+field]=data.copy();schema[field]=dict(dtype=str(data.dtype),shape=list(data.shape),stride=list(value.stride()),requires_grad=value.requires_grad)
    rows[name]=dict(status='ok',values=schema,**meta)
   except Exception as error:
    message=str(error);category='singular' if 'singular' in message.lower() else type(error).__name__
    rows[name]=dict(status='error',error=type(error).__name__,category=category,message=message[:220],**meta)
np.savez_compressed(r/(sys.argv[1]+'-inverse.npz'),**arrays)
(r/(sys.argv[1]+'-inverse.json')).write_text(json.dumps(dict(rows=rows,input_sha256=plan['sha256'],driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),backend=sys.argv[1],source_hashes=source_hashes,version=version,native_git=native_git),indent=2)+'\n')
print(sys.argv[1],len(rows),'cases;',sum(v['status']=='error' for v in rows.values()),'errors;',len(arrays),'arrays')
