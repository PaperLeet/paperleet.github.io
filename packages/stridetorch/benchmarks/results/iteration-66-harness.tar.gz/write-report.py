from pathlib import Path
import json

r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
j=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-66.json').read_text())

def table(rows):
    text='| Runtime | Operation | Dtype | Shape / case | Mode | 0.66 / actual 0.65 | Four-child range |\n|---|---|---|---|---|---:|---:|\n'
    for row in rows:
        lo,hi=row['ratio_range'];shape=row.get('case',row['input_shape']);mode=row.get('mode',row.get('kind',''))
        text+=f"| {row['runtime']} | {row['operation']} | {row['dtype']} | {shape} | {mode} | {row['ratio_median']:.3f} | {lo:.3f}–{hi:.3f} |\n"
    return text

inverse=j['inverse_performance']['rows'];old=j['performance']['rows'];joint=j['joint_performance']['rows']
wasm_large=[v for v in inverse if v['runtime'] in ['node','chrome'] and v['operation']=='inverse_jvp' and v['shape'] in ['larger','batch_large'] and v['mode']=='full_step']
wasm_small=[v for v in inverse if v['runtime'] in ['node','chrome'] and v['operation']=='inverse_jvp' and v['shape'] in ['scalar','small'] and v['mode']=='full_step']
cpu_jvp=[v for v in inverse if v['runtime']=='cpu' and v['operation']=='inverse_jvp' and v['mode']=='full_step']
worst_old=sorted(old,key=lambda v:v['ratio_median'],reverse=True)[:8]
worst_joint=sorted(joint,key=lambda v:v['ratio_median'],reverse=True)[:10]
worst_other=sorted([v for v in inverse if v['operation']!='inverse_jvp'],key=lambda v:v['ratio_median'],reverse=True)[:8]
allocation='| Dtype | Shape | Direction layout / strides | Prior / new retained bytes | Prior / new forward peak | Prior / new backward peak |\n|---|---|---|---:|---:|---:|\n'
memory=j['inverse_shared_proxy_memory'];assert memory['candidate_shared_override']
for a,b in zip(memory['rows'][::2],memory['rows'][1::2]):
    assert a['variant']=='baseline' and b['variant']=='candidate'
    if a['operation']!='inverse_jvp':continue
    allocation+=f"| {a['dtype']} | {a['input_shape']} | {a['direction_layout']} / {a['direction_stride']} | {a['new_retained_bytes']:,} / {b['new_retained_bytes']:,} | {a['forward_peak_bytes']:,} / {b['forward_peak_bytes']:,} | {a['backward_peak_bytes']:,} / {b['backward_peak_bytes']:,} |\n"
stages=j['ui_qualification_stages'];ui='; '.join((f"complete frontend suite ({s['frontend_check_commands']} commands)" if s.get('full_frontend') else f"{len(s['checks'])} affected checks") + f" plus driver/policy/two builds at `{s['upstream']}`" for s in stages) if stages else 'No later UI sync was required.'
archive=j['raw_archive']
text=f'''# Torch runtime iteration 66 — selective shared inverse JVP reverse kernels

Version **0.66.0** reduces repeated inverse-JVP reverse work on Pyodide/WASM,
adds traversal-local pruning for validated joint reverse rules, and corrects
empty-direction mutation guards. Existing public inverse APIs are unchanged.
Final integration baseline is `{j['baseline_main']}`; full CPU/frontend/catalog
validation baseline is `{j['full_validation_baseline']}`. {ui}

## Shared work and measured dispatch

The previous inverse JVP computes the same upstream-gradient matrix product
separately in the inverse-result and direction reverse branches. A joint rule
now shares it when both inputs require gradients, the runtime is Emscripten,
and the matrix core is at least 32×32. This removes one matrix multiplication
from the complete reverse step. CPU, smaller cores and one-input cases retain
the independent rules. The returned primal alias, native multiplication
associations, column-major output axes and saved-value guards are preserved.

A development scan covers ten sizes from 1 through 64 and both real dtypes on
CPU, Node and Chrome. Unconditional joint routing saves work in large WASM
cores but adds Python dispatch cost in small cases. The selected cutoff is a
conservative measured dispatch choice for the pinned runtime, not a universal
hardware optimum. Prototype A, its slower CPU pilot/profile, single-pass
prototype B, the size scan and the final dispatch pilots remain archived with
their own source hashes. They are distinct from final-source formal timing.

The graph engine's joint-gradient validation and routing now use one pass.
Existing rules still receive construction-time active-input flags. Only rules
that explicitly opt in receive masks for the current gradient targets. The
shared inverse rule skips an unrequested matrix or direction branch; repeated
retained-graph calls recompute from each new seed. No upstream-gradient cache
or cross-traversal kernel result is retained. Storage-version guards are checked
before callbacks and remain in force even when a derivative branch is pruned.

## Empty directions and the allocation-scope correction

The new native corpus finds **six** prior mismatches: both dtypes, three target
selections, and an interleaved empty batch. The previous stride comparison treats
the empty direction as an independent copy and permits its mutation. Native
PyTorch canonicalizes that empty tangent without making independent saved
storage, so its version guard must remain. Nonempty directions still use the
native-compatible stride-copy rule. The fix passes the new corpus and all prior
1,080 mutation/layout cases; no existing guards are relaxed.

The original 0.65 CPU allocation fixture uses
`broadcast_to(...).astype(...)`. A later audit verifies that its 4×32×32
direction has element strides `(1,128,4)`, while the primal has `(1024,32,1)`.
The native dual uses a copy: mutating the original direction does not change
the dual tangent's version. The 2D 64×64 fixture has matching `(64,1)` strides
and shares the original direction's version. This is confirmed for float32/64
against native **PyTorch 2.14.1**, git
`5c4886908584029761b579af026dcfb627c84070`.

The [0.65 report](torch-runtime-iteration-65.md) is corrected accordingly. Its
archived numbers, source and raw archive are not rewritten. The prior claim
that all directions in that allocation diagnostic were contiguous and required
no copy was inaccurate. Its batch retained-allocation cost includes the required
direction snapshot. The original latency benchmark constructs directions
differently and is unaffected by this scope correction.

## Verification

- **41,682 CPU tests pass, 1 skip** with exact source hashes checked before and
  after execution. **86 new SDK tests** cover opt-in/default joint masks, frozen
  and shared inputs, nonleaf target execution, repeated seeds, guard-before-
  callback behavior, malformed derivative checks, independent diagonal inverse
  derivatives, both dispatch paths and empty interleaved guards.
- **8,052 contracts / 60 suites** pass separately on Node/Pyodide and Chrome
  Worker. The isolated Python 3.10.19 / NumPy 1.26.4 wheel passes **8,065 tests**,
  with native Torch absent. Public wheel/sdist, vendored wheel, coinstallation,
  native-Torch alias restoration and fresh-process serialization are checked.
- **480 new frozen contexts**, generated from ten groups / 30 exact input
  arrays, cover partial gradient targets, retained primal/tangent gradients,
  hooks, graph reuse/release and storage mutations. Two dtypes, C/F/interleaved
  directions, 2×2 and 32×32 matrices, batches and empties compare **784 numerical
  arrays and 240 None fields**. CPU default routing, CPU forced-shared routing,
  Node, Chrome and the minimum wheel all match native states and meaningful
  strides. All IEEE masks are exact. The 320 large-matrix arrays use explicit
  per-matrix relative max-norm limits `1e-5` (float32) / `3e-12` (float64);
  small normal-input arrays use componentwise `rtol=3e-5, atol=3e-7` or
  `rtol=3e-12, atol=3e-14`. The prior stricter extreme-input corpus is retained.
- Previous **600 determinant/log**, **398 singleton**, **696 determinant JVP**
  and **864 inverse** contexts remain passing on all four environments, along
  with **1,080 inverse mutation/layout**, **105 matmul guard** and **120 API**
  checks. Native, legacy singular-cofactor and unsupported-input expectations
  remain separate. The package contains 59 Python resources and LICENSE/NOTICE.
- The original **78 exported modules / 342 mutants** pass original browser budgets,
  including the full 60-suite independent contract run. **1,152 native catalog
  input hashes and 13,389 previous immutable payloads** remain unchanged. There
  are 158 new reachable payloads and 161 active export/index hashes.
- Full frontend checks and both build profiles pass on the original Node 25.9.0 run; the latest affected checks and both builds
  also pass under CI-matching Node 22.23.3 after the upstream fix recorded below. An initial frontend run
  exposed a stale test after upstream `71a5d396` made the navigation label
  “Workspace” and moved progress hints to its title. A local correction checks the
  stable bilingual label and localized title while retaining empty/completed/
  loading/disabled-state checks. Upstream independently landed its own correction
  in `323c0c4b`; the final checkout uses that upstream test without a local test
  diff, and reruns it in the later UI qualification.
  The original failure, targeted reproduction, corrected pass and full rerun
  are preserved. Any later disjoint UI qualification is recorded above.
- All 18 public/fixture runtime assets, five Node core files and 13 lock-pinned
  package wheels are revalidated. Pyodide is 0.29.4 / NumPy 2.2.5; development
  CPU uses Python 3.12.11 / NumPy 2.5.4. Host metadata and per-child load averages
  are retained; machine-wide isolation is not claimed.
- Seven release-policy files remain byte-identical to canonical
  `{j['release_policy']['canonical']}`. No CI trigger, tag, workflow dispatch,
  release, package upload or deployment is initiated.

## Final-source performance against actual 0.65

Twelve fresh children, four each CPU/Node/Chrome, alternate runtime order and
use five alternating common calibrated batches of at least 20 ms. Owned tests
and builds finish before timing; supported CPU thread caps are two. Every
child measures **170 actual prior-API workflows**: 100 determinant/log/graph,
44 inverse/JVP/matmul/complex forwards and 26 existing GroupNorm/classification
controls. All comparator APIs exist in 0.65. No new-feature composition or
candidate-only ratio is used. Fixtures, conversions and seeds precede timing;
dispatch, graph construction, kernels, weighted backward, clearing and result
destruction are included when applicable.

Eligible large WASM inverse-JVP complete steps:

{table(wasm_large)}
Small WASM complete steps, retaining independent routing:

{table(wasm_small)}
CPU inverse-JVP complete steps, retaining independent routing:

{table(cpu_jvp)}
Largest median ratios among other inverse/matmul/complex controls:

{table(worst_other)}
Largest median ratios among the 100 prior determinant/log/graph workflows:

{table(worst_old)}
Largest median ratios among 26 GroupNorm/classification controls, including
all-input, affine-only, bias-only, frozen-label and weighted-soft-target cases:

{table(worst_joint)}
The official GroupNorm fixtures retain independent Tensor-composition checks;
classification fixtures retain their independent float64 formula checks.
Only actual library APIs are timed. A preliminary single-child classification
outlier of 31% did not reproduce in the four-child development recheck; both
the outlier and recheck remain archived. Final tables above use the twelve
fresh final-source children, retaining all samples and losses. There is no
native-Torch/GPU, cold-start or universal speedup claim.

## Allocation diagnostics and reproduction

Thirty-two warm CPU rows explicitly separate C/F 2D directions and C/interleaved
batch directions against actual 0.65 APIs. Actual primal/direction element
strides and the direction-copy predicate are recorded per row. Another 32 rows
force the shared WASM route on CPU to inspect its allocation behavior. This is
an explicitly marked CPU proxy, not a WASM heap measurement. The 24 prior
determinant/log diagnostics retain warm and cold-first results separately.

The shared-route proxy's JVP rows show forward retained/peak bytes and separately
traced backward peaks. Inputs/directions/weights precede tracing; the forced
runtime override is recorded. Necessary snapshots are kept for F/interleaved
directions. These counts are not total tape bytes, RSS, LAPACK workspace or
WASM heap size, and no universal memory saving is claimed:

{allocation}
The shared-route CPU proxy's backward peak rises about 19–20%, while retained
bytes change by less than 0.4% and forward peaks are essentially unchanged.
Default CPU inverse-JVP allocation rows are unchanged. Sharing saves arithmetic
but this implementation has an observable temporary-lifetime cost; lowering that
peak remains further work. These proxy numbers do not establish a WASM heap
increase of the same percentage.

[Machine report](../../packages/stridetorch/benchmarks/results/iteration-66.json)
and [raw harness](../../packages/stridetorch/benchmarks/results/iteration-66-harness.tar.gz)
contain source/test snapshots, frozen native inputs/outputs, prototype snapshots,
profiles, failed development pilots, corrected scope audit, package artifacts,
qualification programs, receipts and all timing samples. Archive: {archive['bytes']:,}
bytes; SHA-256 `{archive['sha256']}`.

Supported numerical execution changes only in the CPU/WASM graph and inverse
rules. The separate capability probe does not enable a WebGPU backend or claim
a GPU performance gain.
The wider independent-library efficiency/core-coverage/backend objective remains active.
'''
text+='''
## Latest 82-module catalog qualification

Upstream `c79995fe` adds top-p draws, multi-turn SFT masks, continual-learning
metrics and EWC. The prior 1,152 native exercise inputs and exact 61 runtime
resources remain unchanged. The four new modules pass 471 native cases across
three reference/mutant repeats and 30 WASM reference tests; all 17 new mutants
are detected within the original browser budgets. Combined coverage is 82
modules / 359 mutants, from the full original 78-module run plus this four-module
extension, rather than a fresh full-82 rerun.

The latest export preserves all 13,555 pre-existing payloads in the staged
snapshot, including the eight new upstream payloads, and adds eight reachable
runtime-specific payloads. The tree contains 13,563 immutable payloads and 169
active asset/index hashes. Ten affected frontend/bundle checks, the driver and
release policy checks, two local build profiles and 25 catalog tests pass.

The pre-existing upstream Pages run 39082894813 failed its Node 22.23.3 size
check before deployment. This is reproduced locally on the exact Pages-profile
artifacts: 409,388 raw bytes and 133,260 gzip bytes, versus limits of 409,600
and 133,120 bytes. Node 25.9.0 compresses those same artifacts to 132,726 bytes
and passes. The seven canonical release-policy files and size budgets remain
unchanged; no workflow retry or deployment was initiated. Local Node 25 build
success does not imply that the current Node 22 release gate passes.

The reusable [WebGPU bridge probe](../../packages/stridetorch/benchmarks/webgpu_bridge.mjs)
and [sandbox feasibility record](torch-webgpu-bridge-feasibility.md) also
record a successful scalar Python/GPU roundtrip in a secure Worker, unavailable
WebGPU in the tested opaque-origin Worker, and the asynchronous Python-entry
requirement. They do not enable a GPU backend or claim a performance gain.
'''
text+='''
## Upstream Node 22 build correction

Upstream `4db2b71b` separates shared profile models from UI-only modules. After
preserving all 187 owned paths byte-for-byte, nine affected UI/publishing checks,
the driver/policy checks and both build profiles pass with Node 22.23.3.
The default initial graph is 404,949 raw / 131,575 gzip bytes; the production
Pages graph is 406,806 raw / 132,118 gzip bytes. Both satisfy the original budgets.
The preceding c799 failure remains historical evidence, not a current limitation.

Upstream also adds the exact production Pages build to the quality job and
asserts parity of deployment variables. This iteration preserves those changes.
The CI trigger header is unchanged: tags/manual dispatch only; exact current-main
SHA gates and the Pages workflow remain intact. The seven policy hashes now pin
this reviewed upstream identity; the earlier identity is retained for old-stage
provenance. No push-triggered CI, manual retry or deployment is introduced here.
'''
(repo/'docs/validation/torch-runtime-iteration-66.md').write_text(text)
print('Wrote iteration-66 validation report')
