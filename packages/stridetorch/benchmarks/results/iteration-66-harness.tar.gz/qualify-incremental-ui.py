from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;i=r/'integration-proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release');receipts=[];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();baseline=json.loads((i/'full-suite-baseline.json').read_text())['upstream'];env=dict(os.environ,PYTHON=str(r.parent/'torch-iteration-21/stride-dev-env/bin/python'));env['PATH']='/opt/homebrew/bin:'+str(Path(env['PYTHON']).parent)+':'+env['PATH'];env['PYTHONPATH']=os.pathsep.join([str(repo/'packages/stridetorch/src'),str(repo)])
checks=['moderation-comparison', 'community-reports', 'report-history', 'deferred-features']
def run(args,label,cwd,extra=None):
 start=time.monotonic()
 with (i/('latest-'+label+'.log')).open('w') as log:p=subprocess.run(args,cwd=cwd,env={**env,**(extra or {})},stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(label=label,args=args,cwd=str(cwd),exit_code=p.returncode,elapsed_s=time.monotonic()-start));(i/'latest-ui-qualification.json').write_text(json.dumps(dict(status='running',upstream=head,full_suite_baseline=baseline,checks=checks,receipts=receipts,scope='Incremental moderation snapshot comparison plus community report/history and deferred-feature checks after disjoint UI/docs sync; driver/policy/two builds. Full C7 frontend suite remains retained.'),indent=2)+'\n');p.check_returncode();print(label,'TERMINAL 0',flush=True)
for label in checks:run(['/opt/homebrew/bin/node','scripts/check-'+label+'.mjs'],label,repo/'web')
run(['/opt/homebrew/bin/node','web/scripts/check-wasm-cases.mjs'],'wasm-driver',repo);run(['/opt/homebrew/bin/node','web/scripts/check-pages-release.cjs'],'pages-policy',repo)
run(['npm','run','build'],'build',repo/'web');run(['npm','run','build'],'pages-profile-build',repo/'web',json.loads((i/'current-pages-profile.json').read_text())['environment'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
p=i/'latest-ui-qualification.json';j=json.loads(p.read_text());j['status']='qualified';p.write_text(json.dumps(j,indent=2)+'\n');print('LATEST UI QUALIFIED',head,flush=True)
