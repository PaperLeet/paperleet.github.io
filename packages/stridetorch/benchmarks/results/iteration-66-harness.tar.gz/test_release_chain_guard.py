"""The exception must fail closed for all release-relevant differences."""
from copy import deepcopy
from release_chain_guard import ignorable_stale_queued_quality

base = dict(name='PaperLeet quality gate', path='.github/workflows/ci.yml',
            status='queued', conclusion=None, event='workflow_dispatch',
            head_branch='main', head_sha='a' * 40,
            repository=dict(full_name='PaperLeet/paperleet.github.io'),
            head_repository=dict(full_name='PaperLeet/paperleet.github.io'))

def check(run=base, current='b' * 40, jobs=(), policies=True, ancestor=True):
    return ignorable_stale_queued_quality(
        run, current, list(jobs) if isinstance(jobs, tuple) else jobs,
        canonical_policies_verified=policies, ancestor_verified=ancestor)

assert check()
assert not check(current='a' * 40)
assert not check(jobs=[dict(status='queued')])
assert not check(jobs=None)
assert not check(policies=False)
assert not check(ancestor=False)
assert not check(current='bad-sha')
for key, value in [
    ('name', 'Publish PaperLeet public site'), ('status', 'in_progress'),
    ('conclusion', 'cancelled'), ('event', 'push'), ('head_branch', 'other'),
    ('head_sha', 'bad-sha'), ('path', '.github/workflows/other.yml'),
    ('repository', dict(full_name='someone/else')),
    ('head_repository', dict(full_name='someone/else')),
]:
    run = deepcopy(base)
    run[key] = value
    assert not check(run), (key, value)
print('16 stale-queue release-guard cases PASS')
