from pathlib import Path
import json,sys
import numpy as np
if sys.argv[1]=='native':import torch as t
else:from stridetorch import torch as t
rows=[]
for shape_a,shape_b in [((2,2),(2,2)),((2,),(2,)),((2,),(2,2)),((2,2),(2,)),((2,2,2),(2,2))]:
 for needs in [(True,True),(True,False),(False,True)]:
  for selected in ['a','b','both']:
   if selected=='a' and not needs[0] or selected=='b' and not needs[1]:continue
   for changed in ['a','b','output']:
    a=t.from_numpy(np.arange(np.prod(shape_a),dtype='float64').reshape(shape_a)+1).requires_grad_(needs[0]);b=t.from_numpy(np.arange(np.prod(shape_b),dtype='float64').reshape(shape_b)+1).requires_grad_(needs[1]);y=a@b
    with t.no_grad():{'a':a,'b':b,'output':y}[changed].detach().add_(1)
    inputs=tuple(value for value,active in zip((a,b),needs) if active) if selected=='both' else a if selected=='a' else b
    try:t.autograd.grad(y.sum(),inputs);status='ok'
    except RuntimeError:status='guarded'
    rows.append(dict(shape_a=shape_a,shape_b=shape_b,needs=needs,selected=selected,changed=changed,status=status))
r=Path(__file__).resolve().parent;(r/('matmul-'+sys.argv[1]+'.json')).write_text(json.dumps(rows,indent=2)+'\n');print(sys.argv[1],len(rows),'cases')
