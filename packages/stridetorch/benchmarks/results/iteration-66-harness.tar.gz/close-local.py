from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');p=r/'proof';i=r/'integration-proof';out=repo/'packages/stridetorch/benchmarks/results'
read=lambda n:json.loads((r/n).read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def save(f,v):f.write_text(json.dumps(v,indent=2)+'\n')
owned=read('owned-input-sha256.json');additional=read('additional-root-test-hashes.json')
for name,digest in additional.items():
 assert sha(repo/name)==digest
 target=r/'root-test-snapshot'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/name,target)
for name,digest in owned.items():assert sha(repo/name)==digest,name
source={f.name:sha(f) for f in (repo/'packages/stridetorch/src/stridetorch').iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')};plan=read('proof/chrome-contracts/plan.json')
assert source==read('proof/source-hashes.json')==plan['source'] and len(source)==61
tests={f.name:sha(f) for f in (repo/'packages/stridetorch/tests').glob('test_*.py') if f.name!='test_standalone.py'};assert tests==plan['tests'] and len(tests)==60
cpu=read('full-root-receipt.json');assert cpu['exit_code']==0 and cpu['passed']==41682 and cpu['skipped']==1 and cpu['source_hashes']==source
node=read('proof/source-wasm.json');chrome=read('proof/chrome-contracts/result.json');wheel=read('proof/wheel-stride066-result.json');co=read('proof/coinstall-result.json')
assert node['passed']==chrome['passed']==8052 and chrome['test_hashes']==tests
assert node['source_hashes']==chrome['source_hashes']==wheel['source_hashes']==co['source_hashes']==source
assert all(v['status']=='success' for v in [chrome,wheel,co]) and not wheel['native_torch']
assert '8065 passed' in (p/'python310-stride066-tests.log').read_text()
gates=read('proof/gate-receipts.json');assert len(gates)==6 and all(v['exit_code']==0 for v in gates.values())
oracle_receipts=read('oracle-receipts.json');assert len(oracle_receipts)==2 and all(v['exit_code']==0 for v in oracle_receipts.values())
qual=read('determinants-qualification.json');on=read('proof/oracle-node-result.json');oc=read('proof/chrome-contracts/oracle-result.json')
for q in [qual,on['qualification'],oc['qualification']]:
 assert q['status']=='success' and q['source_hashes']==source
 assert q['counts']==dict(log_native_cases=480,det_native_cases=54,det_legacy_cases=48,det_restricted_cases=18,numeric_arrays=1764,none_gradients=360,singleton_layout_contract_arrays=10)
 assert q['input_sha256']==sha(r/'determinant-inputs.npz')
jvp=read('jvp-qualification.json');assert jvp['status']=='success' and jvp['cases']==696 and jvp['numeric_arrays']==3132 and jvp['source_hashes']==source
inverse=read('inverse-qualification.json');assert inverse['status']=='success' and inverse['cases']==864 and inverse['numeric_arrays']==2454 and inverse['source_hashes']==source
minimum=read('minimum-oracle-result.json');assert minimum['status']=='success' and minimum['source_hashes']==source and minimum['qualification']['counts']==qual['counts']
singleton=read('singleton-qualification.json');assert singleton['status']=='success' and singleton['cases']==398 and singleton['numeric_arrays']==1194
for extra in [on['inverse_qualification'],oc['inverse_qualification'],minimum['inverse_qualification']]:
 assert extra['status']=='success' and extra['cases']==864 and extra['numeric_arrays']==2454 and extra['source_hashes']==source and extra['input_sha256']==inverse['input_sha256']
for extra in [on['jvp_qualification'],oc['jvp_qualification'],minimum['jvp_qualification']]:
 assert extra['status']=='success' and extra['cases']==696 and extra['numeric_arrays']==3132 and extra['source_hashes']==source and extra['input_sha256']==jvp['input_sha256']
for extra in [on['singleton_qualification'],oc['singleton_qualification'],minimum['singleton_qualification']]:
 assert extra['status']=='success' and extra['cases']==398 and extra['numeric_arrays']==1194 and extra['input_sha256']==singleton['input_sha256']
targets=read('adapter-inverse-target-qualification.json');shared_targets=read('shared-inverse-target-qualification.json')
for q in [targets,shared_targets,on['inverse_target_qualification'],oc['inverse_target_qualification'],minimum['inverse_target_qualification']]:
 assert q['status']=='success' and q['contexts']==480 and q['numeric_arrays']==784 and q['none_fields']==240 and q['source_hashes']==source
 assert q['input_sha256']==targets['input_sha256'] and q['driver_sha256']==targets['driver_sha256']
front_adjustment=read('frontend-test-adjustment.json');assert front_adjustment['targeted_recheck_exit_code']==0 and sha(repo/front_adjustment['path'])==front_adjustment['sha256']
front=read('integration-proof/frontend-receipts.json');integration=read('integration-proof/receipts.json');assert len(front)==5 and len(integration)==2 and all(v['exit_code']==0 for v in front+integration)
builds=read('integration-proof/final-export-build-receipts.json') if (i/'final-export-build-receipts.json').exists() else [];assert all(v['exit_code']==0 for v in builds)
wasm=read('integration-proof/full-wasm-result.json');assert wasm['passed'] and wasm['modules']==wasm['catalog_modules']==78 and sum(v['mutants'] for v in wasm['results'])==342 and all(v['passed'] for v in wasm['results'])
assert not wasm['browser_budget_exceeded'] and all(not v['browser_budget_exceeded'] for v in wasm['results'])
contracts=next(v for v in wasm['results'] if v['id']=='architecture/attention')['independent_contracts'];assert contracts['passed']==8052 and len(contracts['suites'])==60 and {v['suite']:v['source_sha256'] for v in contracts['suites']}==tests
exports=read('integration-proof/export-identity.json');assert exports['published_assets_unchanged']==13389 and exports['new_assets']==exports['active_assets']==158
live={};data=repo/'web/public/data';index=json.loads((data/'index.json').read_text())
for entry in index['problems']:
 for name in [entry['detail_url'],entry['browser_judge']['bundle_url']]:live[name]=sha(data/name)
 manifest=json.loads((data/entry['browser_judge']['bundle_url']).read_text());name=manifest['runtime_bundle_url'];live[name]=sha(data/name)
for name in ['index.json','index-v3.json','catalog.json']:live[name]=sha(data/name)
assert len(live)==169;save(i/'live-expected-sha256.json',live)
extension=read('pre-adoption-c79995fe/export-identity.json');assert extension['catalog_modules']==82 and extension['preserved_assets']==13555 and extension['new_assets']==8
newwasm=read('pre-adoption-c79995fe/wasm-new-four-report.json');newnative=read('pre-adoption-c79995fe/native-new-four-report.json');assert newwasm['passed'] and newwasm['mutants']==17 and newnative['passed'] and newnative['repeats']==3
policy=read('release-policy-identity.json')
for name,digest in policy['files'].items():assert sha(repo/name)==digest
runtime_identity=read('runtime-identity.json');assert runtime_identity['status']=='success' and len(runtime_identity['public_runtime_files'])==18
for name,digest in runtime_identity['public_runtime_files'].items():assert sha(repo/'web/public/browser-runtime/pyodide-0.29.4'/name)==digest==sha(r.parent/'runtime-0.29.4'/name)
for name in runtime_identity['node_core_files_identical']:assert sha(repo/'web/node_modules/pyodide'/name)==runtime_identity['public_runtime_files'][name]
native=read('native-catalog-reuse.json');assert native['files']==1152
for name,digest in native['native_input_sha256'].items():assert sha(repo/name)==digest
isolation=read('native-isolation-result.json');assert isolation['status']=='success' and isolation['library_version']=='0.66.0'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head==read('integration-proof/context.json')['upstream']
full_baseline=read('integration-proof/full-suite-baseline.json')['upstream'];assert full_baseline==cpu['base_commit']
sync=None;ui=None;ui_stages=[]
if head!=full_baseline:
 sync=read('upstream-sync.json');ui=read('integration-proof/latest-ui-qualification.json');assert sync['before']==full_baseline and sync['after']==head and ui['status']=='qualified' and ui['upstream']==head and ui['full_suite_baseline']==full_baseline
 ui_stages=read('integration-proof/ui-qualification-stages.json') if (i/'ui-qualification-stages.json').exists() else [ui]
 for stage in ui_stages:assert stage['status']=='qualified' and stage['full_suite_baseline']==full_baseline and len(stage['receipts'])==len(stage['checks'])+4 and all(v['exit_code']==0 for v in stage['receipts'])
 for name,digest in sync['paths'].items():assert sha(repo/name)==digest
perf=read('performance/identity.json');receipts=read('performance/receipts.json');assert perf['status']=='success' and perf['children']==len(receipts)==12 and all(v['exit_code']==0 for v in receipts)
baseline=json.loads((r.parent/'torch-iteration-65/proof/source-hashes.json').read_text());assert perf['source_hashes']==dict(baseline=baseline,candidate=source);assert sha(repo/'packages/stridetorch/benchmarks/bench_determinants.py')==perf['benchmark_sha256']
for runtime in ['cpu','node','chrome']:
 for repeat in range(4):
  j=read(f'performance/{runtime}-{repeat}.json');j=j.get('benchmark',j);assert len(j['inverse_benchmark']['rows'])==44 and j['inverse_benchmark']['source_hashes']==perf['source_hashes'] and j['inverse_benchmark']['program_sha256']==perf['inverse_benchmark_sha256'];assert len(j['rows'])==100 and sum(v['matched'] for v in j['rows'])==100 and j['versions']==dict(baseline='0.65.0',candidate='0.66.0') and j['source_hashes']==perf['source_hashes']
environment=read('performance/environment.json');assert environment['numpy']=='2.5.4' and environment['machine']=='arm64'
inverse_perf=read('inverse-performance-summary.json');assert inverse_perf['children']==12 and len(inverse_perf['rows'])==132
inverse_memory=read('performance/inverse-memory.json');assert inverse_memory['source_hashes']==perf['source_hashes'] and len(inverse_memory['rows'])==32 and not inverse_memory['candidate_shared_override']
assert sha(r/'bench_inverse.py')==perf['inverse_benchmark_sha256']
assert sha(r/'bench_joint.py')==perf['joint_benchmark_sha256']
for name,digest in perf['joint_fixture_sha256'].items():assert sha(r/name)==digest
joint_perf=read('joint-performance-summary.json');assert joint_perf['children']==12 and len(joint_perf['rows'])==78
for runtime in ['cpu','node','chrome']:
 for repeat in range(4):
  q=read(f'performance/{runtime}-{repeat}.json');q=q.get('benchmark',q)['joint_benchmark']
  assert len(q['rows'])==26 and q['source_hashes']==perf['source_hashes'] and q['program_sha256']==perf['joint_benchmark_sha256'] and q['fixture_hashes']==perf['joint_fixture_sha256']
shared_memory=read('performance/inverse-shared-proxy-memory.json');assert shared_memory['candidate_shared_override'] and shared_memory['source_hashes']==perf['source_hashes'] and len(shared_memory['rows'])==32
stride_audit=read('direction-stride-audit.json');assert stride_audit['status']=='verified' and len(stride_audit['rows'])==4 and stride_audit['source_hashes']==baseline

memory=read('performance/memory.json');assert memory['source_hashes']==perf['source_hashes'] and len(memory['rows'])==24
fresh=[]
for name,python,path in [('stridetorch',p/'python310-stride066-env/bin/python',p/'stridetorch-activation.pkl'),('paperleet._vendor.torch',p/'coinstall-env/bin/python',p/'paperleet-_vendor-torch-activation.pkl')]:
 result=subprocess.run([str(python),'-I',str(r/'fresh-load.py'),name,str(path)],capture_output=True,text=True,cwd=r);assert result.returncode==0,result.stderr;fresh.append(dict(namespace=name,exit_code=0,output=result.stdout.strip()))
save(r/'fresh-load-result.json',fresh)
metadata=r/'package-metadata';metadata.mkdir(exist_ok=True)
for name in ['README.md','pyproject.toml','LICENSE','NOTICE']:shutil.copy2(repo/'packages/stridetorch'/name,metadata/name)
shutil.copy2(repo/'packages/stridetorch/tests/test_standalone.py',metadata/'test_standalone.py')
footprint={}
for label,folder,names in [('baseline',r/'baseline-source/stridetorch',baseline),('candidate',repo/'packages/stridetorch/src/stridetorch',source)]:
 payload=b''.join((folder/n).read_bytes() for n in sorted(names));footprint[label]=dict(source_license_bytes=len(payload),local_concatenated_gzip_bytes=len(gzip.compress(payload,mtime=0)))
archive=out/'iteration-66-harness.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as target:
 for current,dirs,files in os.walk(r):
  dirs[:]=[d for d in dirs if d not in ['__pycache__','.pytest_cache'] and not d.endswith(('-env','-venv'))]
  for name in sorted(files):
   f=Path(current)/name
   if f.name.endswith('.tar.gz') and any(part.startswith('pre-adoption-') for part in f.relative_to(r).parts):continue
   if not f.is_symlink() and (f.name in ['LICENSE','NOTICE'] or f.suffix in ['.py','.mjs','.json','.log','.md','.html','.toml','.npz','.txt','.whl','.pkl'] or f.name.endswith('.tar.gz')):target.add(f,arcname=f.relative_to(r),recursive=False)
assert archive.stat().st_size<95*1024*1024
backend_assessment=dict(capability_probe_scope='Scalar JSPI/GPU roundtrip and opaque sandbox exposure only; no tensor backend or performance qualification.',status='unchanged_from_065',gpu_prototype_run=True,scope='WASM large inverse-JVP shared reverse kernels and opt-in target pruning; CPU and small/one-input dispatch retained; empty-direction version guard fix and single-pass joint routing; no GPU backend change.')
report=dict(status='validated_locally',version='0.66.0',baseline_main=head,source_hashes=source,test_hashes=tests,owned_inputs=owned,additional_root_test_hashes=additional,changed_resources=sorted(n for n in baseline if source[n]!=baseline[n]),added_resources=sorted(source.keys()-baseline.keys()),added_tests=86,full_cpu=cpu,node_wasm=node,chrome_worker=chrome,minimal_wheel=wheel,coinstall=co,fresh_process=fresh,native_qualification=qual,singleton_qualification=singleton,jvp_qualification=jvp,inverse_qualification=inverse,inverse_target_qualification=targets,shared_cpu_target_qualification=shared_targets,minimum_qualification=minimum,node_qualification=on,chrome_qualification=oc,runtime_identity=runtime_identity,native_catalog_reuse=native,native_dtype_isolation=isolation,export_identity=exports,active_export_sha256=live,frontend=front,frontend_test_adjustment=front_adjustment,full_validation_baseline=full_baseline,upstream_sync=sync,latest_ui_qualification=ui,ui_qualification_stages=ui_stages,final_export_builds=builds,full_wasm=dict(modules=78,mutants=342,contracts=8052,suites=60,passed=True,browser_budget_exceeded=False),release_policy=policy,performance_identity=perf,performance=read('performance-summary.json'),inverse_performance=inverse_perf,inverse_memory=inverse_memory,inverse_shared_proxy_memory=shared_memory,joint_performance=joint_perf,direction_stride_audit=stride_audit,performance_environment=environment,backend_assessment=backend_assessment,memory=memory,source_footprint=footprint,limitations=['Real first-order AD only; complex inverse forward only; no arbitrary higher derivatives or output buffers.','The measured shared routing cutoff applies to pinned Pyodide/WASM cores >=32 with both inputs requiring gradients. CPU, small cores and one-input rules retain independent edges; no universal hardware speedup claim.','Shared routing prunes only explicitly requested graph branches; native saved-storage guards remain conservative. Empty directions preserve native version sharing.','The prior singular determinant legacy cofactor contract and pinned native determinant/log JVP conventions remain separate. Nonfinite matrix inputs remain unsupported.','Positive singleton stored-gradient strides may differ under the established owned-buffer contract; meaningful strides and all new target/reuse/mutation layouts match.','Allocation diagnostics distinguish C/F/interleaved directions and record actual strides. Shared-route measurements on CPU are allocation proxies, never WASM heap/RSS/tape-size claims. The original 0.65 memory scope is corrected without rewriting its raw measurements.','100 determinant/log/graph + 44 inverse/matmul/complex + 26 GroupNorm/classification workflows per child compare actual 0.65 APIs; preliminary pilots and the 20-workflow, ten-size scan are not final timing evidence.','No GPU backend change or new GPU performance is claimed this iteration.'],raw_archive=dict(name=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)))
report['catalog_extension']=dict(export=extension,wasm=newwasm,native=newnative,catalog_tests=read('pre-adoption-c79995fe/catalog-tests-receipt.json'),ui=ui,total_modules=82,total_mutants=359,scope='Original complete 78-module proof plus separately qualified four new modules, not a fresh full-82 rerun.');report['historical_release_build_limitation']=read('pre-adoption-c79995fe/node22-build-check-receipt.json');report['release_build_status']=dict(status='passed_node22_after_upstream_fix',upstream=head,node='22.23.3',qualification=ui,initial_default_raw=404949,initial_default_gzip=131575,initial_pages_raw=406806,initial_pages_gzip=132118);report['webgpu_bridge_capabilities']=json.loads((repo/'packages/stridetorch/benchmarks/results/webgpu-bridge-capabilities.json').read_text());save(out/'iteration-66.json',report);save(r/'state.json',dict(status='local_gates_passed',version='0.66.0',main_adoption_pending=True,source_hashes=source,active_export_sha256=live))
print(json.dumps(dict(status=report['status'],cpu=cpu['passed'],wasm=8052,wheel=8065,catalog=78,mutants=342,raw_archive=report['raw_archive'])))
