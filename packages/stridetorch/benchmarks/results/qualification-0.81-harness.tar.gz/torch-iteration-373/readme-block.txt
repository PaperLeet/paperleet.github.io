Version **0.81** packs contiguous reduction rows for eligible 2D WASM matrix
products. Representative complete forward/gradient flows improve while native
CPU BLAS routing and public APIs retain their existing behavior. The
[0.81 qualification record](../../docs/validation/torch-runtime-0.81-qualification.md)
records measured scope, temporary-copy memory costs, installed-package checks
and local PaperLeet application/browser verification. WebGPU remains an
experimental developer prototype; it is not an enabled torch backend.
