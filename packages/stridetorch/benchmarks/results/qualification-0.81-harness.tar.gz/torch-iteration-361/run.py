from pathlib import Path
import hashlib,json,os,subprocess,time,traceback,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');b=r.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n');plan=read(r/'plan.json')
def verify():
 assert sha(Path(__file__))==plan['runner_sha256']
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==plan['head']
 for name,h in plan['inputs'].items():assert sha(repo/name)==h,name
try:
 verify();command=[str(b/'torch-iteration-82/application-env/bin/python'),'-B','-m','pytest','tests','packages/stridetorch/tests','-q','-p','no:cacheprovider','--basetemp',str(r/'pytest-tmp'),'--junitxml='+str(r/'full-suite.xml')]
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0',PYTHONPATH=os.pathsep.join([str(repo/'packages/stridetorch/src'),str(repo)]),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
 with (r/'full-suite.log').open('w') as log:
  child=subprocess.Popen(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT);write(r/'progress.json',dict(status='running',label='full-application-cpu',pid=child.pid,supervisor_pid=os.getpid(),observed_unix=time.time(),command=command,plan_sha256=sha(r/'plan.json')));code=child.wait()
 verify();root=ET.parse(r/'full-suite.xml').getroot();suites=list(root) if root.tag=='testsuites' else [root];totals={k:sum(int(s.get(k,0)) for s in suites) for k in ['tests','failures','errors','skipped']};skips=[dict(name=t.get('classname')+'::'+t.get('name'),reason=x.get('message')) for s in suites for t in s.findall('testcase') for x in t.findall('skipped')]
 assert totals['tests']>=45855,totals
 result=dict(status='passed_full_application_cpu' if code==0 and not totals['failures'] and not totals['errors'] else 'failed',head=plan['head'],version='0.81.0',totals=totals,skips=skips,command=command,exit_code=code,plan_sha256=sha(r/'plan.json'),runner_sha256=sha(Path(__file__)),log_sha256=sha(r/'full-suite.log'),xml_sha256=sha(r/'full-suite.xml'),catalog_budgets_qualified=False,wasm_catalog_qualified=False,performance_qualified=False,main_adopted=False,ci_triggered=False,pushed=False,goal_status='active')
 write(r/'result.json',result);write(r/'progress.json',dict(status='completed',results=result));print(json.dumps(result),flush=True);raise SystemExit(code)
except BaseException as error:
 if isinstance(error,SystemExit):raise
 write(r/'progress.json',dict(status='failed',error=str(error),traceback=traceback.format_exc()));raise
