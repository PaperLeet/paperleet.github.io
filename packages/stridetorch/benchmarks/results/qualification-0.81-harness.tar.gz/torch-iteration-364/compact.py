"""Thin backup of generated test data; reuse verified immutable Git payloads."""
from pathlib import Path
import hashlib,io,json,shutil,stat,subprocess,tarfile
root=Path(__file__).resolve().parent
repo=Path('/Users/david/Developer/PaperLeet-torch-release')
source=root.parent/'torch-iteration-311/pytest-tmp'
destination=root/'retained-311-pytest-tmp.thin.tar.zst'
assert source.is_dir() and not source.is_symlink() and not destination.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['/usr/bin/git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
entries=subprocess.check_output(['/usr/bin/git','-C',str(repo),'ls-tree','-r',head,'packages/stridetorch/benchmarks/results'],text=True).splitlines()
blobs={line.split('\t',1)[1]:line.split()[2] for line in entries}
manifest={};external_bytes=0
for p in [source,*sorted(source.rglob('*'))]:
    info=p.lstat();name='pytest-tmp'+('/'+str(p.relative_to(source)) if p!=source else '')
    entry=dict(mode=stat.S_IMODE(info.st_mode),uid=info.st_uid,gid=info.st_gid,mtime_ns=info.st_mtime_ns)
    if p.is_symlink():entry.update(kind='symlink',target=str(p.readlink()))
    elif p.is_dir():entry['kind']='directory'
    elif p.is_file():
        entry.update(kind='file',sha256=sha(p),bytes=info.st_size)
        text=str(p)
        marker='/source/'
        if marker in text:
            relative=text.split(marker,1)[1]
            if relative in blobs and sha(repo/relative)==entry['sha256']:
                entry['external']=dict(repository=str(repo),commit=head,path=relative,git_blob=blobs[relative])
                external_bytes+=info.st_size
    else:raise RuntimeError('Unexpected special entry '+str(p))
    manifest[name]=entry
data=(json.dumps(manifest,indent=2)+'\n').encode()
(root/'manifest.json').write_bytes(data)
print(json.dumps(dict(status='manifest_ready',entries=len(manifest),external_immutable_bytes=external_bytes)),flush=True)
encoder=subprocess.Popen(['/opt/homebrew/bin/zstd','-q','-3','--long=27','-T1','-o',str(destination)],stdin=subprocess.PIPE,stderr=subprocess.PIPE)
with tarfile.open(fileobj=encoder.stdin,mode='w|') as archive:
    item=tarfile.TarInfo('manifest.json');item.size=len(data);archive.addfile(item,io.BytesIO(data))
    for name,entry in manifest.items():
        if 'external' in entry:continue
        p=source.parent/name;item=archive.gettarinfo(str(p),arcname=name)
        if entry['kind']=='file':
            item.type=tarfile.REGTYPE;item.size=entry['bytes']
            with p.open('rb') as stream:archive.addfile(item,stream)
        else:archive.addfile(item)
encoder.stdin.close();error=encoder.stderr.read();assert encoder.wait()==0,error
decoder=subprocess.Popen(['/opt/homebrew/bin/zstd','-q','-d','-c',str(destination)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
seen=set()
with tarfile.open(fileobj=decoder.stdout,mode='r|') as archive:
    for item in archive:
        if item.name=='manifest.json':assert archive.extractfile(item).read()==data;continue
        entry=manifest[item.name];seen.add(item.name)
        assert item.mode==entry['mode'] and item.uid==entry['uid'] and item.gid==entry['gid']
        if entry['kind']=='file':assert hashlib.sha256(archive.extractfile(item).read()).hexdigest()==entry['sha256'],item.name
        elif entry['kind']=='symlink':assert item.issym() and item.linkname==entry['target']
        else:assert item.isdir()
decoder.stdout.close();error=decoder.stderr.read();assert decoder.wait()==0,error
assert seen=={name for name,entry in manifest.items() if 'external' not in entry}
for name,entry in manifest.items():
    if entry['kind']=='file':
        assert sha(source.parent/name)==entry['sha256'],name
        if 'external' in entry:assert sha(repo/entry['external']['path'])==entry['sha256'],name
receipt=dict(status='verified_recoverable_thin_backup',original=str(source),archive=str(destination),archive_bytes=destination.stat().st_size,
             archive_sha256=sha(destination),manifest_sha256=sha(root/'manifest.json'),entries=len(manifest),external_bytes=external_bytes,
             original_bytes=sum(e.get('bytes',0) for e in manifest.values()),
             scope='Every original file byte is either stored in the archive or verified identical to a protected immutable Git blob recorded by commit/path/blobid/SHA256. Restore external files from that repository; manifest records original modes/owners/timestamps/links. Not a standalone archive. Failed363partialarchive remains untouched.')
(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
shutil.rmtree(source)
print(json.dumps(receipt),flush=True)
