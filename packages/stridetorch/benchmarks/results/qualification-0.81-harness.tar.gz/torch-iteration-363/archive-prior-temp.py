"""Preserve an old generated pytest tree as a verified, recoverable archive."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import stat
import tarfile

root=Path(__file__).resolve().parent
source=root.parent/'torch-iteration-311/pytest-tmp'
assert source.is_dir() and not source.is_symlink()
destination=root/'retained-311-pytest-tmp.tar.gz'
assert not destination.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={}
for p in [source,*sorted(source.rglob('*'))]:
    info=p.lstat();name='pytest-tmp'+('/'+str(p.relative_to(source)) if p!=source else '')
    entry=dict(mode=stat.S_IMODE(info.st_mode),uid=info.st_uid,gid=info.st_gid,mtime_ns=info.st_mtime_ns)
    if p.is_symlink():entry.update(kind='symlink',target=str(p.readlink()))
    elif p.is_dir():entry['kind']='directory'
    elif p.is_file():entry.update(kind='file',sha256=sha(p),bytes=info.st_size)
    else:raise RuntimeError('Unexpected special entry '+str(p))
    manifest[name]=entry
manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode()
with tarfile.open(destination,'w:gz',compresslevel=1) as archive:
    stored={}
    for name,entry in manifest.items():
        path=source.parent/name
        item=archive.gettarinfo(str(path),arcname=name)
        if entry['kind']=='file':
            key=(entry['sha256'],entry['bytes'],entry['mode'],entry['uid'],entry['gid'])
            if key in stored:
                item.type=tarfile.LNKTYPE;item.linkname=stored[key];item.size=0
                archive.addfile(item)
            else:
                stored[key]=name;item.type=tarfile.REGTYPE
                with path.open('rb') as stream:archive.addfile(item,stream)
        else:archive.addfile(item)
    print(json.dumps(dict(status='archive_written',unique_file_payloads=len(stored),archive_bytes=destination.stat().st_size)),flush=True)
    item=tarfile.TarInfo('manifest.json');item.size=len(manifest_bytes);archive.addfile(item,io.BytesIO(manifest_bytes))
with tarfile.open(destination,'r:gz') as archive:
    for name,entry in manifest.items():
        item=archive.getmember(name)
        assert item.mode==entry['mode'] and item.uid==entry['uid'] and item.gid==entry['gid']
        if entry['kind']=='file':
            assert hashlib.sha256(archive.extractfile(item).read()).hexdigest()==entry['sha256'],name
        elif entry['kind']=='symlink':assert item.issym() and item.linkname==entry['target']
        else:assert item.isdir()
for name,entry in manifest.items():
    if entry['kind']=='file':assert sha(source.parent/name)==entry['sha256'],name
receipt=dict(status='all_prior_temp_payloads_preserved_and_verified',original=str(source),archive=str(destination),
             archive_sha256=sha(destination),archive_bytes=destination.stat().st_size,entries=len(manifest),
             original_bytes=sum(e.get('bytes',0) for e in manifest.values()),
             scope='Generated old test tree compacted with content-deduplicated tar hardlinks only after byte, mode, ownership and link verification. Independent original timestamps remain in manifest; ordinary tar extraction shares identical file payloads. Source/runtime/assets/logs/environments are not deleted. Restore by extracting archive into torch-iteration-311.')
(root/'prior-temp-archive-manifest.json').write_bytes(manifest_bytes)
(root/'prior-temp-archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
shutil.rmtree(source)
print(json.dumps(receipt))
