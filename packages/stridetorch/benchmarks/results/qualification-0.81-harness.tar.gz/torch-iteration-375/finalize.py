from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
b=Path(__file__).resolve().parent.parent;r=Path(__file__).resolve().parent
repo=Path('/Users/david/Developer/PaperLeet-torch-release')
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
stage=lambda n:b/f'torch-iteration-{n}'
assert not (r/'result.json').exists()
latest=read(stage(374)/'result.json')
assert latest['status']=='passed_local_application_catalog_export_frontend_worker_gates'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==latest['head']
statics=read(stage(374)/'static-inputs.json')
for name,h in statics.items():assert sha(repo/name)==h,name
receipts=read(stage(374)/'receipts.json')
assert all(x['exit_code']==0 for x in receipts)
for x in receipts:assert sha(stage(374)/(x['label']+'.log'))==x['log_sha256'],x['label']
resources=read(stage(360)/'result.json')['resources']
for name,h in resources.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==h,name
cpu=read(stage(361)/'plan.json')['inputs']
delta=[name for name,h in cpu.items() if sha(repo/name)!=h]
assert all(name.startswith('web/') for name in delta),delta
private_wheel=next((stage(357)/'private-dist').glob('*.whl'))
with zipfile.ZipFile(private_wheel) as archive:
 packaged={name:hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist() if name.startswith('paperleet/') and (name.endswith('.py') or name.endswith('.json') or name.endswith('/LICENSE') or name.endswith('/NOTICE'))}
 for name,h in packaged.items():
  p=repo/name if not name.startswith('paperleet/_vendor/torch/') else repo/'packages/stridetorch/src/stridetorch'/name.removeprefix('paperleet/_vendor/torch/')
  assert sha(p)==h,name
 expected_app={str(p.relative_to(repo)) for p in (repo/'paperleet').rglob('*.py')}
 assert expected_app=={name for name in packaged if name.endswith('.py') and not name.startswith('paperleet/_vendor/torch/')}
write(r/'current-source-proof.json',dict(head=latest['head'],static_inputs_verified=len(statics),latest_receipts_verified=len(receipts),cpu_changed_inputs=delta,cpu_delta_scope='UI only; full202 at e27904f1 plus15focused current tests and full builds',private_wheel_sha256=sha(private_wheel),private_application_files_verified=len(packaged),runtime_resources=resources))
readme=repo/'packages/stridetorch/README.md';text=readme.read_text();start=text.index('The working **0.81 candidate**');end=text.index('```sh',start)
readme.write_text(text[:start]+(stage(373)/'readme-block.txt').read_text()+'\n'+text[end:])
roadmap=repo/'packages/stridetorch/ROADMAP.md';assert '## Version 0.81 local qualification' not in roadmap.read_text()
roadmap.write_text(roadmap.read_text().rstrip()+'\n\n'+(stage(373)/'roadmap-block.txt').read_text())
target=stage(366);assert not (target/'public').exists()
public=target/'public';public.mkdir()
inputs={}
paths=[repo/'packages/stridetorch'/name for name in ['pyproject.toml','README.md','LICENSE','NOTICE']]
paths += [repo/'packages/stridetorch/src/stridetorch'/name for name in resources]
for p in paths:
 name=p.relative_to(repo/'packages/stridetorch');dest=public/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);inputs[str(p)]=sha(p)
staged={str(p.relative_to(target)):sha(p) for p in public.rglob('*') if p.is_file()}
write(target/'source-plan.json',dict(inputs=inputs,staged=staged,expected=resources,previous_package_proof_sha256=sha(stage(360)/'result.json')))
write(target/'execution-plan.json',dict(runner_sha256=sha(target/'run.py'),source_plan_sha256=sha(target/'source-plan.json'),scope='Public metadata refresh; all65runtime resources unchanged; previous installed full SDK carries by identity'))
write(r/'result.json',dict(status='verified_current_source_and_prepared_metadata_refresh',previous_goal_turn='progress: r374 finished current frontend/build/Worker gates',runtime_unchanged=True,source_proof_sha256=sha(r/'current-source-proof.json'),main_adopted=False,ci_triggered=False,goal_status='active'))
print(json.dumps(dict(status='prepared',source_inputs=len(statics),private_files=len(packaged),cpu_ui_deltas=len(delta))))
