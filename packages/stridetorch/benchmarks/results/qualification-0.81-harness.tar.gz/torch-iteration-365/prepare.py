from pathlib import Path
import hashlib,json,subprocess
b=Path(__file__).resolve().parent.parent;r=Path(__file__).resolve().parent
repo=Path('/Users/david/Developer/PaperLeet-torch-release')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
old=(b/'torch-iteration-312/run-gates.py').read_text()
header=old.split('try:\n verify()\n',1)[0].replace('/Users/david/.npm/_npx/d18f28baf1132559/node_modules/node/bin/node','/Users/david/.local/share/fnm/node-versions/v22.22.1/installation/bin/node')
body=" run('native-catalog'"+old.split(" run('native-catalog'",1)[1]
body=body.replace('source=284',"version='0.81.0'")
start="""try:
 verify()
 application=b/'torch-iteration-361'
 assert sha(application/'plan.json')==prereq['cpu_plan_sha256']
 cpu=read(application/'result.json')
 assert cpu['status']=='passed_full_application_cpu' and cpu['head']==context['head']
 assert cpu['totals']['tests']>=45855 and cpu['totals']['failures']==cpu['totals']['errors']==0 and cpu['totals']['skipped']==1
 write(r/'application-cpu-receipt.json',dict(result_sha256=sha(application/'result.json'),result=cpu))
 resource=read(b/'torch-iteration-364/receipt.json')
 assert resource['status']=='verified_recoverable_thin_backup'
 write(r/'resource-recovery-receipt.json',dict(receipt_sha256=sha(b/'torch-iteration-364/receipt.json'),result=resource))
"""
(r/'run.py').write_text(header+start+body)
(r/'verify-export.py').write_text((b/'torch-iteration-312/verify-export.py').read_text().replace('0.80.0','0.81.0'))
(r/'verify-generated-worker.mjs').write_text((b/'torch-iteration-330/verify-generated-worker.mjs').read_text())
nested=(b/'torch-iteration-330/check-nested-wasm.mjs').read_text().replace('pl_matrix_probe_v080','pl_matrix_probe_v081')
pos=nested.index('const source=original+')
probe="""const packedProbe=`
# Verify the eligible packed contraction through the real exported judge Worker.
import numpy as _pl_pack_np
_pl_pack_original = _pl_pack_np.einsum
_pl_pack_calls = []
def _pl_pack_spy(expression, *args, **kwargs):
    _pl_pack_calls.append(expression)
    return _pl_pack_original(expression, *args, **kwargs)
try:
    _pl_pack_np.einsum = _pl_pack_spy
    _pl_pack_a = torch.ones(128, 64, dtype=torch.float64, requires_grad=True)
    _pl_pack_b = torch.ones(64, 128, dtype=torch.float64, requires_grad=True)
    _pl_pack_y = _pl_pack_a @ _pl_pack_b
    _pl_pack_da, _pl_pack_db = torch.autograd.grad(_pl_pack_y, (_pl_pack_a, _pl_pack_b), torch.ones_like(_pl_pack_y))
    assert _pl_pack_calls == ['ik,jk->ij'] * 3
    assert _pl_pack_y.sum().item() == 1048576.0
    assert _pl_pack_da.sum().item() == _pl_pack_db.sum().item() == 1048576.0
finally:
    _pl_pack_np.einsum = _pl_pack_original
del _pl_pack_np, _pl_pack_original, _pl_pack_calls, _pl_pack_spy, _pl_pack_a, _pl_pack_b, _pl_pack_y, _pl_pack_da, _pl_pack_db
`;
"""
nested=nested[:pos]+probe+nested[pos:]
nested=nested.replace("const source=original+'\\n'+probe;","const source=original+'\\n'+probe+'\\n'+packedProbe;")
(r/'check-nested-wasm.mjs').write_text(nested)
files=subprocess.check_output(['/usr/bin/git','-C',str(repo),'ls-files','paperleet','tests','problems','packages/stridetorch/src','packages/stridetorch/tests','packages/stridetorch/README.md','packages/stridetorch/pyproject.toml','pyproject.toml','web/src','web/scripts','web/package.json','web/package-lock.json','web/tsconfig.json','web/vite.config.ts','.github/workflows'],text=True).splitlines()
static={n:sha(repo/n) for n in files if (repo/n).is_file()}
assets={str(p.relative_to(repo)):sha(p) for folder in ('web/public/data/browser-judge','web/public/data/modules') for p in (repo/folder).glob('*.json')}
context=dict(head=subprocess.check_output(['/usr/bin/git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),catalog_modules=89,version='0.81.0')
source=repo/'packages/stridetorch/src/stridetorch'
resources={p.name:sha(p) for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
assert len(resources)==65
write(r/'context.json',context);write(r/'static-inputs.json',static);write(r/'immutable-assets.json',assets);write(r/'source-hashes.json',resources)
write(r/'prerequisites.json',dict(cpu_plan_sha256=sha(b/'torch-iteration-361/plan.json')))
write(r/'execution-plan.json',dict(files={p.name:sha(p) for p in r.iterdir() if p.is_file()},scope='Freshserial081nativecatalog/export/fullWASM/frontend/build/Worker after361CPU. FixedNode22. Alloldimmutableassetsretained. NoCIordeploy.'))
print(json.dumps(dict(status='prepared',static_inputs=len(static),preserved_assets=len(assets),source_resources=len(resources))))
