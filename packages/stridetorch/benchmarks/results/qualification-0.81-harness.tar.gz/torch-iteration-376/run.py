from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path(__file__).resolve().parent;b=r.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
public=next((b/'torch-iteration-366/dist').glob('*.whl'));private=next((b/'torch-iteration-357/private-dist').glob('*.whl'))
smoke=r/'installed-smoke.py';shutil.copy2(b/'torch-iteration-357/installed-smoke.py',smoke)
inputs={str(p):sha(p) for p in [public,private,smoke,b/'torch-iteration-366/source-plan.json',b/'torch-iteration-375/current-source-proof.json']}
write(r/'execution-plan.json',dict(runner_sha256=sha(Path(__file__)),inputs=inputs,dependency_environments='Previously qualified and read-only; install only new independent target; no dependency resolution'))
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');env.pop('PYTHONPATH',None)
receipts=[]
def run(label,args):
 for name,h in inputs.items():assert sha(Path(name))==h
 start=time.monotonic()
 with (r/(label+'.log')).open('w') as log:child=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(label=label,command=args,exit_code=child.returncode,seconds=time.monotonic()-start,log_sha256=sha(r/(label+'.log'))));print(json.dumps(receipts[-1]),flush=True);child.check_returncode()
python=b/'torch-iteration-82/application-env/bin/python'
run('install',['/Users/david/.local/bin/uv','pip','install','--python',str(python),'--target',str(r/'installed'),'--no-deps','--offline',str(public),str(private)])
for label,exe in [('numpy25',python),('numpy126',b/'torch-iteration-137/native26-env/bin/python')]:
 run(label,[str(exe),'-I','-B',str(smoke),str(r/'installed'),str(b/'torch-iteration-366/source-plan.json')])
write(r/'result.json',dict(status='passed_actual_final_public_private_coininstall_and_both_numpy_smokes',receipts=receipts,public_wheel_sha256=sha(public),private_wheel_sha256=sha(private),runtime_unchanged=True,ci_triggered=False,published=False,goal_status='active'))
