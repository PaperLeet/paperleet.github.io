
from pathlib import Path
import hashlib, importlib, json, sys
import numpy as np
prefix=Path(sys.argv[1]).resolve();sys.path.insert(0,str(prefix))
expected=json.load(open(sys.argv[2]))['expected']
import stridetorch as public
import paperleet
import paperleet._vendor.torch as private
assert Path(paperleet.__file__).resolve().is_relative_to(prefix)
for module in [public, private]:
    folder=Path(module.__file__).resolve().parent
    assert folder.is_relative_to(prefix) and module.__version__=='0.81.0'
    assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']}==expected
    api=module.torch
    x=api.tensor([3.,4.],dtype=api.float64,requires_grad=True)
    buffer=api.full_like(x,7.);x.grad=buffer
    value,product=api.autograd.functional.hvp(api.linalg.vector_norm,x,api.ones_like(x))
    assert value.item()==5. and x.grad is buffer
    np.testing.assert_allclose(product.numpy(),[.032,-.024],rtol=1e-9,atol=1e-12)
    np.testing.assert_array_equal(x.grad.numpy(),[7.,7.])
    backend=importlib.import_module(module.__name__+'._tensor')
    previous_flag=backend._WASM_MATMUL;backend._WASM_MATMUL=True
    try:
        a=api.ones(128,64,dtype=api.float64,requires_grad=True)
        b=api.ones(64,128,dtype=api.float64,requires_grad=True)
        y=a@b;da,db=api.autograd.grad(y,(a,b),api.ones_like(y))
        np.testing.assert_array_equal(y.numpy(),np.full((128,128),64.))
        np.testing.assert_array_equal(da.numpy(),np.full((128,64),128.))
        np.testing.assert_array_equal(db.numpy(),np.full((64,128),128.))
    finally:backend._WASM_MATMUL=previous_flag

native=importlib.import_module('torch')
saved={name:module for name,module in sys.modules.items() if name=='torch' or name.startswith('torch.')}
with public.as_torch():
    assert importlib.import_module('torch').Tensor is public.torch.Tensor
    with private.as_torch():
        assert importlib.import_module('torch').Tensor is private.torch.Tensor
    assert importlib.import_module('torch').Tensor is public.torch.Tensor
assert importlib.import_module('torch') is native
assert {name:module for name,module in sys.modules.items() if name=='torch' or name.startswith('torch.')}==saved
print(json.dumps(dict(status='passed_installed_current_package_paths_hvp_and_alias_restoration',public=str(public.__file__),private=str(private.__file__),numpy=np.__version__,native_torch=native.__version__)))
