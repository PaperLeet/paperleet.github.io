import ast
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent;base=root.parent
repo=Path('/Users/david/Developer/PaperLeet-torch-release')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
package=read(base/'torch-iteration-357/result.json');plan=read(base/'torch-iteration-357/source-plan.json')
assert package['version']=='0.81.0' and len(package['artifacts'])==6
assert package['status']=='passed_current_public_private_package_rebuilds_and_installed_smoke'
for name,digest in plan['inputs'].items():assert sha(Path(name))==digest,name
source=repo/'packages/stridetorch/src/stridetorch';prior=base/'torch-iteration-346/candidate'
assert plan['expected']=={p.name:sha(p) for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
assert ast.dump(ast.parse((source/'_matmul.py').read_text()),include_attributes=False)==ast.dump(ast.parse((prior/'_matmul.py').read_text()),include_attributes=False)
for p in source.iterdir():
    if p.name in plan['expected'] and p.name not in ('__init__.py','_matmul.py'):assert sha(p)==sha(prior/p.name),p.name
left,right=ast.parse((source/'__init__.py').read_text()),ast.parse((prior/'__init__.py').read_text())
for tree in (left,right):
    for node in tree.body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='__version__' for t in node.targets):node.value=ast.Constant(value='normalized')
assert ast.dump(left,include_attributes=False)==ast.dump(right,include_attributes=False)
sdk={}
for label,passed,skipped in (('native',12225,0),('minimum',12222,3)):
    report=read(base/'torch-iteration-359'/(label+'-result.json'))
    assert report['status']=='passed_installed081_full_sdk' and report['passed']==passed and report['skipped']==skipped
    assert report['resource_sha256']==plan['expected']
    assert report['child_source']==str(base/'torch-iteration-357/installed/stridetorch/__init__.py')
    sdk[label]=dict(passed=passed,skipped=skipped,numpy=report['numpy'],parent_source=report['source'],child_source=report['child_source'],report_sha256=sha(base/'torch-iteration-359'/(label+'-result.json')))
result=dict(status='passed_final081_distribution_and_installed_sdk_core',version='0.81.0',resources=plan['expected'],package_artifacts=package['artifacts'],installed_sdk=sdk,
            ast_equivalence=dict(matmul_matches_qualified_candidate=True,init_version_only=True,other63resources_identical=True),
            scoped_qualification='torch-iteration-356/result.json',current_application_qualification_pending=True,immutable_export_pending=True,
            final_version_browser_catalog_pending=True,main_adopted=False,ci_triggered=False,published=False,goal_status='active',
            retained_harness_repair=dict(first=358,corrected=359,reason='Parent target imports succeeded but two nonisolated children lacked PYTHONPATH in the native environment; minimum children could use an older installed package. Fresh359propagates target and explicitly verifies child0.81path before the unchangedfullSDK. Both original results retained.'))
(root/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],version=result['version'],sdk=sdk)))
