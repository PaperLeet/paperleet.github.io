import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const repo='/Users/david/Developer/PaperLeet-torch-release',root=path.join(repo,'web/dist');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const original=fs.readFileSync(path.join(repo,'problems/architecture/attention/solution.py'),'utf8');
const probe=`
# pl_matrix_probe_v081: execute new entry points through the actual judge Worker.
_pl_a = torch.ones(2, 3, requires_grad=True)
torch.mm(input=_pl_a, mat2=torch.ones(3, 4)).sum().backward()
assert _pl_a.grad.tolist() == [[4.0, 4.0, 4.0]] * 2
assert torch.bmm(torch.ones(2, 2, 3), torch.ones(2, 3, 4)).sum().item() == 48.0
_pl_empty = torch.bmm(torch.ones(2, 3, 0, dtype=torch.float64), torch.ones(2, 0, 4, dtype=torch.float32))
assert _pl_empty.dtype == torch.float32 and tuple(_pl_empty.shape) == (2, 3, 4)
assert _pl_empty.sum().item() == 0.0
_pl_v = torch.ones(3, requires_grad=True)
torch.mv(input=torch.ones(2, 3), vec=_pl_v).sum().backward()
assert _pl_v.grad.tolist() == [2.0] * 3
assert torch.ones(3).dot(torch.ones(3)).item() == 3.0
assert torch.ones(2, 3).matmul(torch.ones(3, 4)).sum().item() == 24.0
_pl_c = torch.ones(4, requires_grad=True)
_pl_m = torch.ones(2, 3, requires_grad=True)
_pl_n = torch.ones(3, 4, requires_grad=True)
torch.addmm(_pl_c, _pl_m, _pl_n, beta=2, alpha=3).sum().backward()
assert _pl_c.grad.tolist() == [4.0] * 4
assert _pl_m.grad.tolist() == [[12.0] * 3] * 2
assert _pl_n.grad.tolist() == [[6.0] * 4] * 3
assert torch.addmv(torch.ones(2), torch.ones(2, 3), torch.ones(3)).tolist() == [4.0, 4.0]
assert torch.nn.functional.linear(torch.ones(2, 3), torch.ones(4, 3), torch.ones(4)).sum().item() == 32.0

_pl_norm_x = torch.tensor([3., 4.], dtype=torch.float64, requires_grad=True)
_pl_norm = torch.linalg.vector_norm(_pl_norm_x)
_pl_norm.backward()
torch.testing.assert_close(_pl_norm_x.grad, torch.tensor([.6, .8], dtype=torch.float64))
_pl_norm_value, _pl_norm_direction = torch.func.jvp(torch.linalg.vector_norm, (_pl_norm_x,), (torch.ones_like(_pl_norm_x),))
assert abs(_pl_norm_value.item() - 5.) < 1e-12 and abs(_pl_norm_direction.item() - 1.4) < 1e-12
_pl_norm_value, _pl_norm_hvp = torch.autograd.functional.hvp(torch.linalg.vector_norm, _pl_norm_x, torch.ones_like(_pl_norm_x))
torch.testing.assert_close(_pl_norm_hvp, torch.tensor([.032, -.024], dtype=torch.float64), rtol=1e-9, atol=1e-12)
torch.testing.assert_close(_pl_norm_x.grad, torch.tensor([.6, .8], dtype=torch.float64))
del _pl_norm_x, _pl_norm, _pl_norm_value, _pl_norm_direction, _pl_norm_hvp


# Alternate the actual HVP callback between the legacy polynomial and norm routes.
_pl_calls = []
def _pl_branch(value):
    _pl_calls.append(1)
    if value.sum().item() < 0:
        return value.pow(3).sum()
    return torch.linalg.vector_norm(value).square()
for _pl_count, _pl_sign in enumerate([-1., 1., -1., 1.], 1):
    _pl_point = torch.tensor([1., 2., 3.], dtype=torch.float64) * _pl_sign
    _pl_point.requires_grad_(True)
    _pl_buffer = torch.full_like(_pl_point, 9.)
    _pl_point.grad = _pl_buffer
    _pl_direction = torch.tensor([.25, -.5, .75], dtype=torch.float64)
    _pl_value, _pl_product = torch.autograd.functional.hvp(_pl_branch, _pl_point, _pl_direction)
    _pl_expected = 6 * _pl_point.detach() * _pl_direction if _pl_sign < 0 else 2 * _pl_direction
    torch.testing.assert_close(_pl_product, _pl_expected, rtol=1e-9, atol=1e-12)
    assert len(_pl_calls) == _pl_count and _pl_point.grad is _pl_buffer
    assert _pl_buffer.tolist() == [9., 9., 9.]
del _pl_calls, _pl_branch, _pl_count, _pl_sign, _pl_point, _pl_buffer, _pl_direction, _pl_value, _pl_product, _pl_expected

del _pl_a, _pl_empty, _pl_v, _pl_c, _pl_m, _pl_n
`;
const packedProbe=`
# Verify the eligible packed contraction through the real exported judge Worker.
import numpy as _pl_pack_np
_pl_pack_original = _pl_pack_np.einsum
_pl_pack_calls = []
def _pl_pack_spy(expression, *args, **kwargs):
    _pl_pack_calls.append(expression)
    return _pl_pack_original(expression, *args, **kwargs)
try:
    _pl_pack_np.einsum = _pl_pack_spy
    _pl_pack_a = torch.ones(128, 64, dtype=torch.float64, requires_grad=True)
    _pl_pack_b = torch.ones(64, 128, dtype=torch.float64, requires_grad=True)
    _pl_pack_y = _pl_pack_a @ _pl_pack_b
    _pl_pack_da, _pl_pack_db = torch.autograd.grad(_pl_pack_y, (_pl_pack_a, _pl_pack_b), torch.ones_like(_pl_pack_y))
    assert _pl_pack_calls == ['ik,jk->ij'] * 3
    assert _pl_pack_y.sum().item() == 1048576.0
    assert _pl_pack_da.sum().item() == _pl_pack_db.sum().item() == 1048576.0
finally:
    _pl_pack_np.einsum = _pl_pack_original
del _pl_pack_np, _pl_pack_original, _pl_pack_calls, _pl_pack_spy, _pl_pack_a, _pl_pack_b, _pl_pack_y, _pl_pack_da, _pl_pack_db
`;
const source=original+'\n'+probe+'\n'+packedProbe;
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.wasm':'application/wasm','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon'};
const served=[];
const server=http.createServer(async(request,response)=>{
 try{
  const pathname=decodeURIComponent(new URL(request.url,'http://localhost').pathname),target=path.resolve(root,'.'+pathname);assert(target===root||target.startsWith(root+path.sep));
  const stat=await fs.promises.stat(target);
  if(stat.isDirectory()&&!pathname.endsWith('/')){response.writeHead(301,{location:pathname+'/'});response.end();return;}
  const file=stat.isDirectory()?path.join(target,'index.html'):target,bytes=await fs.promises.readFile(file);
  served.push({path:pathname,sha256:sha(bytes),bytes:bytes.length});
  response.writeHead(200,{'content-type':mime[path.extname(file)]||'application/octet-stream','access-control-allow-origin':'*','cache-control':'no-store'});response.end(bytes);
 }catch{response.writeHead(404);response.end('Not found');}
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const origin='http://127.0.0.1:'+server.address().port;let browser;
const output=new URL('nested-wasm-result.json',import.meta.url),diagnostic=new URL('nested-wasm-diagnostic.json',import.meta.url);
try{
 browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 const context=await browser.newContext(),page=await context.newPage();const external=[],errors=[],workers=[];
 await context.route('**/*',route=>{
  const url=route.request().url();
  if(url.startsWith(origin+'/')||url.startsWith('blob:')||url.startsWith('data:'))return route.continue();
  external.push({method:route.request().method(),url});
  const headers={'content-type':'application/json','access-control-allow-origin':origin,'access-control-allow-credentials':'true'};
  if(route.request().method()==='GET'&&url==='https://app.paperleet.com/api/health')return route.fulfill({status:200,headers,body:JSON.stringify({mode:'hosted',auth_required:true,judge:{ready:false}})});
  if(route.request().method()==='GET'&&url==='https://app.paperleet.com/api/account/me')return route.fulfill({status:401,headers,body:JSON.stringify({detail:'Not authenticated'})});
  return route.abort();
 });
 page.on('pageerror',error=>errors.push(String(error)));page.on('worker',worker=>workers.push(worker.url()));
 try{
  const response=await page.goto(origin+'/problems/architecture/attention/',{waitUntil:'domcontentloaded'});assert.equal(response.status(),200);
  assert((await response.text()).includes('data-routing="path"'));
  const editor=page.locator('.python-editor .cm-content').first();await editor.waitFor({state:'visible',timeout:60000});
  await page.waitForFunction(()=>[...document.querySelectorAll('button')].some(b=>/^(Run tests|运行测试)$/.test(b.textContent.trim())&&!b.disabled));
  await editor.click();await editor.press('ControlOrMeta+A');await page.keyboard.insertText(source);
  await page.waitForFunction(()=>document.querySelector('.python-editor .cm-content')?.textContent?.includes('pl_matrix_probe_v081'));
  const run=page.getByRole('button',{name:/^(Run tests|运行测试)$/});await run.waitFor({state:'visible'});assert(await run.isEnabled());
  console.log('Nested path booted, source edited through CodeMirror, starting real browser judge.');await run.click();
  const success=page.locator('.workspace-test-results .result-head.success');await success.waitFor({state:'visible',timeout:240000});
  const feedback=await success.innerText();assert(/7\s*\/\s*7/.test(feedback),feedback);assert(/Tests passed|测试通过/.test(feedback));
  const runtime=served.filter(row=>/\/data\/browser-judge\/runtime-[a-f0-9]+\.json$/.test(row.path));assert(runtime.length>0);
  const runtimeBodies=runtime.map(row=>JSON.parse(fs.readFileSync(path.join(root,row.path),'utf8')));
  assert(runtimeBodies.some(body=>Object.values(body.files||{}).some(text=>typeof text==='string'&&text.includes("__version__ = '0.80.0'"))));
  assert(served.some(row=>row.path.endsWith('/pyodide.asm.wasm')));assert(served.some(row=>row.path.includes('numpy-2.2.5')&&row.path.endsWith('.whl')));assert(workers.length>0);
  const report={status:'passed',path:new URL(page.url()).pathname,feedback,browser:browser.version(),workers,source_sha256:sha(Buffer.from(source)),reference_source_sha256:sha(Buffer.from(original)),probe_source:probe,served,blocked_external_requests:external,page_errors:errors,scope:'Fresh real Chrome loads the actual prerendered nested problem page, enters the canonical attention solution plus explicit mm/bmm/mv/dot/matmul and empty-dtype assertions through the editor, and runs actual local Pyodide/NumPy WASM tests. Only health/anonymous-account responses are supplied by trusted configuration fixtures; numerical execution and static assets are real. All other external requests are blocked, including writes. No server submission or account mutation.'};
  fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,path:report.path,feedback,workers:workers.length,runtime_assets:runtime.length}));
 }catch(error){
  fs.writeFileSync(diagnostic,JSON.stringify({error:String(error),url:page.url(),body:(await page.locator('body').innerText()).slice(-18000),errors,workers,served,external},null,2)+'\n');throw error;
 }finally{await context.close();}
}finally{await browser?.close();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
