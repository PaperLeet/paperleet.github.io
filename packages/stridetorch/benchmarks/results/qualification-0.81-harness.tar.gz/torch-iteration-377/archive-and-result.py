from pathlib import Path
import hashlib,io,json,tarfile
r=Path(__file__).resolve().parent;b=r.parent
repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
stage=lambda n:b/f'torch-iteration-{n}'
required=[stage(n)/'result.json' for n in [356,360,361,366,371,372,374,375,376]]
for p in required:assert p.is_file(),p
assert read(stage(376)/'result.json')['status']=='passed_actual_final_public_private_coininstall_and_both_numpy_smokes'
assert all(x['exit_code']==0 for x in read(stage(374)/'receipts.json'))
wasm=read(stage(365)/'full-wasm-result.json');assert wasm['passed'] and len(wasm['results'])==89 and not wasm['browser_budget_exceeded']
assert sum(x['mutants'] for x in wasm['results'])==406
worker=read(stage(374)/'nested-wasm-result.json');assert worker['status']=='passed' and '7 / 7' in worker['feedback']
source=read(stage(360)/'result.json')['resources']
for name,h in source.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==h
excluded=stage(363)/'retained-311-pytest-tmp.tar.gz'
write(r/'external-evidence.json',dict(partial_failed_backup=dict(path=str(excluded),sha256=sha(excluded),bytes=excluded.stat().st_size,retained_in_place=True,embedded=False),dependencies=[dict(path=str(p.relative_to(repo)),sha256=sha(p)) for p in [out/'candidate-0.81-package-core-harness.tar.gz',out/'matmul-packed-rows-qualification-harness.tar.gz',out/'webgpu-whole-call-0.80-harness.tar.gz']],replay_notes=['Harnesses reference original local paths; adapt external Python/Node/Chrome/Pyodide dependencies for replay.','Thin backups embed payloads and verified Git object references; restoration requires recorded repository objects.','Immutable export history is bound by manifests and tracked Git files, not embedded a second time.','Unused362plan,failed363backup,367ENOSPC,365browserfixturefailure,and370resultformatterfailureare retained; their individual status is not rewritten.']))
files=[]
for n in [360,361,362,363,364,365,366,367,369,370,371,372,373,374,375,376,377]:
 for p in stage(n).rglob('*'):
  if not p.is_file() or p==excluded or '__pycache__' in p.parts or p.name=='archive-receipt.json':continue
  files.append(p)
manifest={str(p.relative_to(b)):sha(p) for p in sorted(files)}
destination=out/'qualification-0.81-harness.tar.gz';assert not destination.exists()
with tarfile.open(destination,'w:gz') as archive:
 for p in sorted(files):archive.add(p,arcname=str(p.relative_to(b)),recursive=False)
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256.json');info.size=len(data);archive.addfile(info,io.BytesIO(data))
with tarfile.open(destination,'r:gz') as archive:
 for name,h in manifest.items():assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==h,name
receipt=dict(path=str(destination.relative_to(repo)),files=len(manifest),bytes=destination.stat().st_size,sha256=sha(destination),verified_all_payloads=True)
write(r/'archive-receipt.json',receipt)
result=dict(status='passed_local_081_qualification_ready_for_guarded_main_adoption',version='0.81.0',qualified_application_head=read(stage(374)/'result.json')['head'],upstream_main_included='f5c0e42016a5f2da2969c6263379e44d00fc0c7a',runtime_resources=source,evidence=[dict(path=str(p.relative_to(b)),sha256=sha(p)) for p in required],raw_archive=receipt,external_evidence=read(r/'external-evidence.json'),installed_sdk=dict(numpy25_passed=12225,numpy126_passed=12222,numpy126_skipped=3),application_cpu=dict(passed=45854,skipped=1,failures=0,errors=0),native_catalog=dict(modules=89,repeats=3,records=12360,passed=True),wasm_catalog=dict(modules=89,mutants=406,elapsed_ms=wasm['elapsed_ms'],budget_exceeded=[],runtime='actualNodePyodide0.29.4NumPy2.2.5',whole_catalog_speedup_claim=False),frontend=dict(full_prior_commands=202,full_head='e27904f10c31274a9c27e984a0b1c1a02ac1bb12',current_focused_commands=15,current_total_commands=203,fresh_full203_claim=False,both_current_builds_passed=True,real_chrome_worker_attention_tests=7,additional_packed_route_probe=True),exports=dict(preserved=16047,new_reachable=180,active_identities=183),performance=dict(full_flows=27,fresh_node_processes=3,fresh_chrome_processes=3,aa_controls_passed=162,per_process_regressions_above_10_percent=0,scope='See retained qualification356and360ASTidentity;notwholecatalog'),known_raw_wasm_norm_hvp_gate_passed=False,production_torch_gpu_backend_enabled=False,main_adopted=False,ci_triggered=False,tags_pushed=False,published=False,deployed=False,goal_status='active')
write(out/'qualification-0.81.json',result)
print(json.dumps(receipt),flush=True)
