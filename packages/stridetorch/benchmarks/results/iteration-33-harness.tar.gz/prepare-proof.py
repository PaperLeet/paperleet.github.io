from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');old=r.parent/'torch-iteration-32/proof-refined';proof=r/'proof';proof.mkdir(exist_ok=True);source=repo/'packages/stridetorch/src/stridetorch'
for target in (proof/'source',proof/'chrome-contracts/source'):shutil.copytree(source,target,ignore=shutil.ignore_patterns('__pycache__'),dirs_exist_ok=True)
shutil.copytree(repo/'packages/stridetorch/tests',proof/'chrome-contracts/tests',ignore=shutil.ignore_patterns('__pycache__'),dirs_exist_ok=True)
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};assert len(hashes)==47
plan=dict(version='0.33.0',expected=1215,source=hashes,tests={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'});assert len(plan['tests'])==33
(proof/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n');(proof/'chrome-contracts/plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for name in ('run.mjs','worker.mjs','index.html'):
 s=(old/'chrome-contracts'/name).read_text().replace('torch-iteration-32/proof-refined','torch-iteration-33/proof');(proof/'chrome-contracts'/name).write_text(s)
s=(old/'wasm-contracts.mjs').read_text().replace('torch-iteration-32/proof-refined','torch-iteration-33/proof').replace('0.32.0','0.33.0').replace("'cholesky']","'cholesky','cholesky_solve']").replace('==1128','==1215');(proof/'wasm-contracts.mjs').write_text(s)
s=(old/'check-wheel.py').read_text().replace('0.32','0.33').replace('stride032','stride033');(proof/'check-wheel.py').write_text(s)
s=(old/'check-coinstall.py').read_text().replace('0.32.0','0.33.0')
anchor="print('PASS isolated ownership,aliases,ZIP resume,triangular and Cholesky VJP/JVP/full tangent reverse')"
addition="""for name in NAMES:
 t=importlib.import_module(name).torch
 f=t.tensor([[2.,0.],[.4,3.]],dtype=t.float64,requires_grad=True);b=t.ones(2,2,dtype=t.float64,requires_grad=True)
 x=t.cholesky_solve(b,f);np.testing.assert_allclose(x.numpy(),np.linalg.solve(f.numpy()@f.numpy().T,b.numpy()))
 x.square().sum().backward();assert np.isfinite(b.grad.numpy()).all() and np.isfinite(f.grad.numpy()).all()
 f.grad=b.grad=None
 dF=t.ones_like(f)*.13;dB=t.ones_like(b)*.27
 _,tangent=t.func.jvp(lambda bb,ff:bb.cholesky_solve(ff),(b,f),(dB,dF))
 tangent.square().sum().backward();assert np.isfinite(b.grad.numpy()).all() and np.isfinite(f.grad.numpy()).all()
print('PASS isolated ownership,aliases,ZIP resume,triangular,Cholesky and Cholesky solve VJP/JVP/full tangent reverse')"""
assert anchor in s;s=s.replace(anchor,addition);(proof/'check-coinstall.py').write_text(s)
print('Frozen47 resources,33 suites1215 browser checks')
