import fs from 'node:fs';import path from 'node:path';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const repo='/Users/david/Developer/PaperLeet-torch-release';const py=await loadPyodide({indexURL:path.join(repo,'web/node_modules/pyodide/'),packageCacheDir:path.join(repo,'web/public/browser-runtime/pyodide-0.29.4/'),stdout:console.error,stderr:console.error});await loadJudgePackages(py,[]);
console.log(py.runPython(`
import numpy as np,json
rows=[]
for dtype in ('float32','float64','complex128'):
 for n in (1,3,7):
  a=np.eye(n,dtype=dtype);a[0,0]=0;b=np.ones((n,2),dtype=dtype)
  for name,call in [('solve',lambda:np.linalg.solve(a,b)),('empty-solve',lambda:np.linalg.solve(a,b[:,:0])),('inv',lambda:np.linalg.inv(a)),('slogdet',lambda:np.linalg.slogdet(a))]:
   try:
    value=call();value=[v.tolist() for v in value] if name=='slogdet' else value.tolist();rows.append(dict(dtype=dtype,n=n,operation=name,status='returned',values=str(value)))
   except Exception as e:rows.append(dict(dtype=dtype,n=n,operation=name,status=type(e).__name__,message=str(e)))
json.dumps(dict(numpy=np.__version__,rows=rows))
`));
