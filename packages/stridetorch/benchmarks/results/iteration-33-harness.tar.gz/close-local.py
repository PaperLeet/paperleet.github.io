from pathlib import Path
import hashlib,json,os,re,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results';proof=r/'proof-final'
def read(name):return json.loads((r/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
actual={p.name:sha(p) for p in (repo/'packages/stridetorch/src/stridetorch').iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};assert len(actual)==47 and actual==read('proof-final/source-hashes.json')
plan=read('proof-final/chrome-contracts/plan.json');tests={p.name:sha(p) for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'};assert plan['source']==actual and plan['expected']==1375 and len(tests)==34 and plan['tests']==tests
gates=read('proof-final/gate-receipts.json');assert len(gates)==6 and all(x['exit_code']==0 for x in gates.values());full=read('final-full-root-result.json');assert full['passed']>=31655 and full['skipped']==1
node=read('proof-final/source-wasm.json');chrome=read('proof-final/chrome-contracts/result.json');wheel=read('proof-final/wheel-stride033-result.json');coinstall=read('proof-final/coinstall-result.json');assert node['passed']==chrome['passed']==1375 and node['source_hashes']==chrome['source_hashes']==wheel['source_hashes']==coinstall['source_hashes']==actual and chrome['test_hashes']==tests and chrome['status']==wheel['status']==coinstall['status']=='success' and not wheel['native_torch'];assert '1387 passed' in (proof/'python310-stride033-tests.log').read_text();assert '776 passed' in (r/'focused-speed-final.log').read_text()
performance=read('performance-final-summary.json');initial=read('performance-summary.json');imports=read('import-summary.json');assert len(performance['receipts'])==16 and all(x['exit_code']==0 for x in performance['receipts'].values());assert len(imports['receipts'])==16 and all(x['exit_code']==0 for x in imports['receipts']);assert len(read('final-sequential-receipts.json'))==3 and all(x['exit_code']==0 for x in read('final-sequential-receipts.json'))
for report in (r/'performance-final').glob('*.json'):
 if report.name!='receipts.json':assert json.loads(report.read_text())['source_hashes']['candidate']==actual
native=r/'native-contracts';native.mkdir(exist_ok=True)
for p in (repo/'tests').glob('test_torch_*'):
 if p.is_file():shutil.copy2(p,native/p.name)
metadata=r/'package-metadata';metadata.mkdir(exist_ok=True)
for name in ('README.md','pyproject.toml','LICENSE','NOTICE'):shutil.copy2(repo/'packages/stridetorch'/name,metadata/name)
def archive(name,root,excluded):
 files=[]
 for folder,dirs,names in os.walk(root):
  dirs[:]=[d for d in dirs if not d.endswith('-env') and d not in excluded and d not in ('__pycache__','.pytest_cache')]
  for name2 in names:
   p=Path(folder)/name2
   if p.is_symlink():continue
   if p.name in ('LICENSE','NOTICE') or p.suffix in ('.py','.mjs','.cjs','.json','.log','.txt','.md','.html','.toml'):files.append(p)
 path=out/name
 with tarfile.open(path,'w:gz') as tar:
  for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
 return dict(file=path.name,files=len(files),bytes=path.stat().st_size,sha256=sha(path))
core_archive=archive('iteration-33-harness.tar.gz',r,{'dist-preflight','private-dist','dist-paperleet','dist-paperleet-before-catalog-merge','integration-proof','integration-proof-prototype','retired-prototype-assets'})
core=dict(status='complete_local_core_and_application_gates_passed_main_adoption_pending',version='0.33.0',baseline_main='bbe623fca182336bdc3b2f12fe41c981f4f9040a',source_hashes=actual,standalone_test_hashes=tests,native_test_hashes={p.name:sha(p) for p in native.iterdir()},full_cpu=full,focused_passed=776,minimal_passed=1387,minimal_wheel=wheel,node_wasm=node,actual_chrome_worker=chrome,coinstall=coinstall,gate_receipts=gates,initial_performance=initial,final_performance=performance,cold_namespace_imports=imports,archive=core_archive,scope='Cholesky solve full unmasked factor VJP/JVP and reverse through both JVP channels;float32/64 AD;complex64/128 inference;no out,half,complexAD. Reuse graph-local intermediates for actual finite triangular factors;associate narrow JVP/VJP through RHS. Quiet NumPy backend factor/singularity status guards. No nativeTorch/SciPy runtime dependency or cross-call tensor-value caches.',retained_failures=['0.32 remote infrastructure4NaN cases failed and Pages skipped;frozen separately in iteration-32-remote-failure.json.','Initial0.33 native31337 passed,Node/Chrome12invalid-factor failures1203passes;quiet-WASM NumPy factor/solve/inv failure reporting corrected.','Initial16paired performance children passed correctness but WASM narrow JVP and some backwards regressed;raw full evidence retained before graph-local intermediate and JVP reassociation refinement.','First final integration private wheel contained premerge application catalog;identity check failed. Prior wheel/log retained and rebuilt from merged catalog;final identity gate must pass.','First final native catalog concurrent with full root/frontend passed all numerical/mutation tests but flow_matching T3 took11.54s and exceeded its unchanged per-test budget;failure report retained and whole native catalog rerun in isolation.'],primary_sources=['https://docs.pytorch.org/docs/2.14/generated/torch.cholesky_solve.html','https://github.com/pytorch/pytorch/blob/v2.14.0/torch/csrc/autograd/FunctionsManual.cpp#L4719','https://docs.pytorch.org/docs/2.14/notes/numerical_accuracy.html#non-finite-values'],release_policy='Local-only verification. Ordinary pushes and PRs trigger no CI. User will later create a stable current-main release tag. No agent tag,dispatch or online publication.')
save('iteration-33.json',core)
i=r/'integration-proof';native_ci=read('integration-proof/native-ci.json');wasm=read('integration-proof/full-wasm-result.json');setup=read('integration-proof/setup-receipts.json');front=read('integration-proof/frontend-receipts.json');snapshot=read('integration-proof/release-snapshot.json');exports=read('integration-proof/export-identity.json');private=read('integration-proof/distribution-identity.json')
assert native_ci['passed'] and native_ci['problems']==78 and native_ci['tests_executed']==10218 and native_ci['repeats']==3 and native_ci['duration_s']<=600
assert wasm['passed'] and wasm['catalog_modules']==wasm['modules']==78 and not wasm['browser_budget_exceeded']
assert sum(x['mutants'] for x in wasm['results'])==342 and all(x['passed'] and not x['browser_budget_exceeded'] for x in wasm['results'])
for x in wasm['results']:
 for field in ('bundle_url','runtime_bundle_url'):assert x[field] in read('integration-proof/live-expected-sha256.json'),x[field]
assert len(setup)==4 and len(front)==5 and all(x['exit_code']==0 for x in setup+front);assert snapshot['source_hashes']==actual and exports['published_assets_unchanged']==8175 and exports['all_new_assets_reachable'] and private['status']=='success'
for name,digest in read('integration-proof/live-expected-sha256.json').items():assert sha(repo/'web/public/data'/name)==digest,name
integration_archive=archive('iteration-33-integration-harness.tar.gz',i,{'dist-paperleet','dist-paperleet-before-catalog-merge'})
integration=dict(status='complete_local_application_gates_passed_main_adoption_pending',version='0.33.0',upstream='bbe623fca182336bdc3b2f12fe41c981f4f9040a',source_hashes=actual,core_report='iteration-33.json',native=native_ci,exported_wasm=wasm,setup_receipts=setup,frontend_receipts=front,release_snapshot=snapshot,export_integrity=exports,distribution_identity=private,runtime_sizes=read('integration-proof/runtime-sizes.json'),wasm_harness=read('integration-proof/wasm-harness-identity.json'),context=read('integration-proof/context.json'),react_review=read('react-review.json'),archive=integration_archive,publication='No CI,tag or release triggered. Local application results do not assert deployment. Last verified live0.31;user will release later.')
save('iteration-33-integration.json',integration);print(json.dumps(dict(core=core_archive,integration=integration_archive,full_cpu=full,native_duration=native_ci['duration_s'],wasm_ms=wasm['elapsed_ms']),indent=2))
