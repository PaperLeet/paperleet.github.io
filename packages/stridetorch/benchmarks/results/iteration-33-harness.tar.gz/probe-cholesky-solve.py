from pathlib import Path
import gc,hashlib,json,shutil,weakref
import numpy as np
import torch
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');source=repo/'packages/stridetorch/src/stridetorch';target=r/'baseline/stridetorch';shutil.copytree(source,target,ignore=shutil.ignore_patterns('__pycache__'),dirs_exist_ok=True)
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};assert len(hashes)==47;(r/'baseline-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
print('native',torch.__version__)
for upper in (False,True):
 for active in ((True,True),(True,False),(False,True)):
  for mutated in ('b','factor','out'):
   f=torch.tensor([[2.,.2],[.4,3.]],dtype=torch.float64,requires_grad=active[1]);b=torch.tensor([[1.,2.],[3.,4.]],dtype=torch.float64,requires_grad=active[0]);x=torch.cholesky_solve(b,f,upper=upper)
   with torch.no_grad():{'b':b,'factor':f,'out':x}[mutated].detach().add_(.1)
   try:x.sum().backward();outcome='allowed'
   except Exception as e:outcome=type(e).__name__+':'+str(e)[:100]
   print('mutation',upper,active,mutated,outcome)
 for shape in ((0,0),(1,1),(2,2),(2,0,0),(2,1,1),(0,3,3),(2,3,3)):
  n=shape[-1];f=torch.eye(n,dtype=torch.float64).expand(shape);b=torch.ones(shape[:-1]+(2,),dtype=torch.float64)
  try:
   x=torch.cholesky_solve(b,f,upper=upper);p,t=torch.func.jvp(lambda bb,ff:torch.cholesky_solve(bb,ff,upper=upper),(b,f),(torch.ones_like(b),torch.ones_like(f)));print('layout',upper,shape,tuple(x.shape),x.stride(),t.stride())
  except Exception as e:print('layout-error',shape,type(e).__name__,str(e))
 for ignored in ('finite','nan'):
  f=np.array([[2.,.2],[.4,3.]]);f[1,0] = np.nan if ignored=='nan' and upper else f[1,0];f[0,1]=np.nan if ignored=='nan' and not upper else f[0,1]
  F=torch.tensor(f,requires_grad=True);B=torch.tensor([[1.,2.],[3.,4.]],dtype=torch.float64,requires_grad=True);dF=torch.tensor([[.1,.3],[.4,.2]],dtype=torch.float64,requires_grad=True);dB=torch.full_like(B,.2,requires_grad=True)
  x,t=torch.func.jvp(lambda b,f:torch.cholesky_solve(b,f,upper=upper),(B,F),(dB,dF));grads=torch.autograd.grad(.17*x.square().sum()+.23*t.square().sum(),(B,F,dB,dF));print('channels',upper,ignored,'x',x.tolist(),'t',t.tolist(),'grads',[g.tolist() for g in grads])
 for dtype in (torch.float32,torch.float64,torch.complex64,torch.complex128):
  f=torch.tensor([[0.,0.],[.3,2.]],dtype=dtype);b=torch.ones(2,1,dtype=dtype)
  try:print('singular',upper,str(dtype),torch.cholesky_solve(b,f,upper=upper).tolist())
  except Exception as e:print('singular-error',upper,str(dtype),type(e).__name__,str(e))
