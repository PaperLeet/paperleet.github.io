from pathlib import Path
import hashlib,json,subprocess,shutil
root=Path(__file__).resolve().parent;r=root/'integration-proof';r.mkdir(exist_ok=True);repo=Path('/Users/david/Developer/PaperLeet-torch-release');old=root.parent/'torch-iteration-32/integration-proof';upstream='bbe623fca182336bdc3b2f12fe41c981f4f9040a'
def save(name,obj):(r/name).write_text(json.dumps(obj,indent=2)+'\n')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source={p.name:digest(p) for p in (repo/'packages/stridetorch/src/stridetorch').iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};assert len(source)==47 and source==json.loads((root/'proof-final/source-hashes.json').read_text())
assert subprocess.run(['git','merge-base','--is-ancestor',upstream,'HEAD'],cwd=repo).returncode==0
assert not (repo/'web/node_modules').is_symlink()
before=json.loads(subprocess.check_output(['git','show',upstream+':web/package.json'],cwd=repo));current=json.loads((repo/'web/package.json').read_text());assert before['dependencies']==current['dependencies'] and before['devDependencies']==current['devDependencies'];assert (repo/'web/package-lock.json').read_bytes()==subprocess.check_output(['git','show',upstream+':web/package-lock.json'],cwd=repo)
for name in ('verify-export.py','run-frontend.py','verify-private.py','run-native.py','run-export.py'):
 s=(old/name).read_text().replace('0.32.0','0.33.0').replace('==7862','==8175').replace('proof-refined','proof-final');(r/name).write_text(s)
s=(old/'freeze.py').read_text().replace('0.32.0','0.33.0').replace('proof-refined','proof-final').replace('==32','==34').replace('1128','1375').replace('expected_suites=32','expected_suites=34').replace("'torch-iteration-31/integration-proof/owned-dependencies.json'","'torch-iteration-32/integration-proof/owned-dependencies.json'").replace('iteration32 integration','iteration33 integration');(r/'freeze.py').write_text(s)
for name in ('run-setup.py','run-wasm.py'):
 s=(old/name).read_text();(r/name).write_text(s)
context=dict(upstream=upstream,source_hashes=source,core_report='iteration-33.json',dependency_inputs_unchanged=True,merge=json.loads((root/'merge-context.json').read_text()),release_policy='No branch/PR CI or automatic deployment;only user-created version tags trigger reused full quality and publication. No tags or Actions dispatch created.',scope='All prior8175 main assets,including undeployed0.32 exports,retained. Same47 runtime hashes as premerge full31619 source;all4 incoming hotfix tests retained. Full frontend/native/exported WASM remain required.')
save('context.json',context);(r/'dist-paperleet').mkdir(exist_ok=True)
for p in (root/'proof-final/private-dist').iterdir():shutil.copy2(p,r/'dist-paperleet'/p.name)
print('Prepared47 resources,34 suites1375 checks;8175 prior main assets retained;local gates only')
