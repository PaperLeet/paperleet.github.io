import fs from 'node:fs';import path from 'node:path';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const repo='/Users/david/Developer/PaperLeet-torch-release';
const py=await loadPyodide({indexURL:path.join(repo,'web/node_modules/pyodide/'),packageCacheDir:path.join(repo,'web/public/browser-runtime/pyodide-0.29.4/'),stdout:console.error,stderr:console.error});await loadJudgePackages(py,[]);
console.log(py.runPython(`
import numpy as np,json
rows=[]
for batched in (False,True):
 for kind in ('negative','used-nan','diagonal-nan'):
  a=np.broadcast_to(np.eye(2),(2,2,2)).copy() if batched else np.eye(2)
  bad=a[1] if batched else a
  if kind=='negative':bad[1,1]=-1
  elif kind=='used-nan':bad[1,0]=np.nan
  else:bad[0,0]=np.nan
  try:
   value=np.linalg.cholesky(a);rows.append(dict(batched=batched,kind=kind,status='returned',values=value.tolist(),diagonal_positive=bool((np.diagonal(value,axis1=-2,axis2=-1).real>0).all())))
  except Exception as e:rows.append(dict(batched=batched,kind=kind,status=type(e).__name__,message=str(e)))
json.dumps(dict(numpy=np.__version__,rows=rows))
`));
