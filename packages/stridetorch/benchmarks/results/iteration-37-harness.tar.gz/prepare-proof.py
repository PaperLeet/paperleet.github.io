from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');old=r.parent/'torch-iteration-36/proof';p=r/'proof';p.mkdir()
source=repo/'packages/stridetorch/src/stridetorch'
for dest in (p/'source',p/'chrome-contracts/source'):shutil.copytree(source,dest,ignore=shutil.ignore_patterns('__pycache__'))
shutil.copytree(repo/'packages/stridetorch/tests',p/'chrome-contracts/tests',ignore=shutil.ignore_patterns('__pycache__'))
hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in source.iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')}
tests={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (repo/'packages/stridetorch/tests').glob('test_*.py') if f.name!='test_standalone.py'}
assert len(hashes)==47 and len(tests)==36
(p/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n');(p/'chrome-contracts/plan.json').write_text(json.dumps(dict(version='0.37.0',expected=1581,source=hashes,tests=tests),indent=2)+'\n')
for name in ('chrome-contracts/run.mjs','chrome-contracts/worker.mjs','chrome-contracts/index.html','wasm-contracts.mjs','check-wheel.py','check-coinstall.py'):
    text=(old/name).read_text().replace('torch-iteration-36/proof','torch-iteration-37/proof').replace('0.36','0.37').replace('stride036','stride037').replace('1532','1581').replace('1544','1594')
    if name=='wasm-contracts.mjs':text=text.replace("'cholesky_inverse','linalg_failures'","'cholesky_inverse','linalg_failures','feature_detection'")
    if name=='check-coinstall.py':
        marker="print('PASS isolated ownership,aliases,ZIP resume,triangular,Cholesky and Cholesky solve VJP/JVP/full tangent reverse')"
        assert marker in text
        addition="""import pickle
for name in NAMES:
 m=importlib.import_module(name);t=m.torch;legacy=importlib.import_module(name+'._legacy').install()
 for obj in (t,t.nn,t.tensor([1.]),legacy,legacy.tensor([1.])):
  key='not_a_real_torch_symbol_37';sentinel=object()
  assert not hasattr(obj,key) and getattr(obj,key,sentinel) is sentinel
  try:getattr(obj,key)
  except AttributeError as error:
   assert isinstance(error,m.UnsupportedOperation) and error.obj is obj and error.name==key
   restored=pickle.loads(pickle.dumps(error));reference=pickle.loads(pickle.dumps(AttributeError(str(error),name=key,obj=obj)))
   assert isinstance(restored,m.UnsupportedOperation) and isinstance(restored,AttributeError) and restored.name==reference.name and restored.obj is None
  else:raise AssertionError('Missing symbol accepted')
 with m.as_torch():
  try:exec('from torch.nn import not_a_real_torch_symbol_37',{})
  except ImportError:pass
  else:raise AssertionError('Unavailable from-import accepted')
"""
        text=text.replace(marker,addition+marker)
    (p/name).write_text(text)
for name in ('run-gates.py','run-full.py'):(r/name).write_text((r.parent/'torch-iteration-36'/name).read_text())
print('Frozen0.37:47 resources,36 suites/1581 browser checks,1594 minimal wheel checks')
