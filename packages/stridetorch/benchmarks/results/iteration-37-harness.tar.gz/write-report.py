from pathlib import Path
import json
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
core=json.loads((out/'iteration-37.json').read_text());app=json.loads((out/'iteration-37-integration.json').read_text());perf=core['final_performance'];full=core['full_cpu']
def interval(runtime,key):
    values=perf['summary'][runtime][key]['median_reductions_percent'];return f'{min(values):.1f} to {max(values):.1f}%'
table='\n'.join(f'| {key} | {interval("cpu",key)} | {interval("wasm",key)} |' for key in perf['summary']['cpu'])
followup=core['cpu_variability_followup']['summary']
def followup_range(key):
    values=followup[key];return f'{min(values):.1f} to {max(values):.1f}%'
imports=core['cold_namespace_imports']['summary'];size=perf['source_footprint'];audit=core['numerical_source_audit'];probe=core['unary_lookup_probe']
text=f'''# StrideTorch 0.37: Python feature discovery with typed fallback

Version 0.37 lets ordinary Python feature checks work across the torch-compatible
namespace, Tensors and optimizers. Previously a missing public symbol made both
`hasattr(value, name)` and `getattr(value, name, default)` raise an unsupported
backend exception. They now return False/default, as native Python/PyTorch code
expects. This supports optional code paths without rewriting them around a
library-specific exception. The independent NumPy-only package remains named
`stridetorch` pending the user's browser-oriented naming decision.

## Lookup, import and failure boundaries

All **32** declared torch module namespaces use an AttributeError subtype that
also matches the existing UnsupportedOperation/NotImplementedError handlers.
The same applies to missing public Tensor/Parameter/optimizer attributes.
Normal `nn.Module` attributes already followed native AttributeError behavior
and retain that behavior. Live missing-symbol errors carry the actual owner in
`obj` and the requested key in `name`. Private/protocol lookup remains ordinary
AttributeError. Existing values, including dynamically added/deleted attributes,
are honored; there is no negative-name cache or fake callable placeholder.

An unavailable `from torch import ...` follows normal Python ImportError
semantics. PaperLeet's existing structured exception classifier recognizes
ImportError and UnsupportedOperation, so both direct and import-based failures
retain server fallback. The application test now executes missing root symbols,
missing `torch.nn` symbols and missing submodules through the real harness.
Text inside unrelated assertions still does not establish an unsupported API.

Actual unsupported options/AD modes keep their existing NotImplementedError
classification and are not AttributeError. Genuine descriptor ValueError and
TypeError also propagate. The change is restricted to lookup; it does not turn
every backend failure into an attribute default. Attribute existence is only a
structural check, not proof that every dtype, gradient or device mode works.

The dual error bases deliberately preserve both Python lookup handling and
existing backend catches. Python's [exception documentation](https://docs.python.org/3/library/exceptions.html#inheriting-from-built-in-exceptions)
advises against multiple built-in exception bases because layouts can differ or
change. Actual gates cover Python 3.10.19, 3.12.11 and Pyodide's 3.13.2; they do
not establish compatibility with untested interpreters or future layouts.
No new dependency or global interpreter patch is introduced. The
[module lookup protocol](https://peps.python.org/pep-0562/) remains Python's own.

## Both runtime profiles and object ownership

The small Schedules profile uses the same error definitions and explicitly
exports the shared errors module. Its package resources grow from five to six,
including both redistribution notices. An isolated subprocess starts from only
those exported files, exercises values/defaults/typed failures and verifies that
the full `_api` and `_tensor` modules are not imported. Schedules still rejects
autograd; missing-attribute compatibility does not enable unsupported modes.

Standard copy/pickle behavior is checked against the running interpreter's own
AttributeError. The first Python 3.10 test incorrectly required `name` to survive
serialization; native Python 3.10 drops it, while newer tested runtimes retain
it. The corrected test follows that standard behavior and verifies that the
owner is not serialized. The original three failed assertions are retained.
An early inheritance-order probe also rejected keyword metadata; the selected
AttributeError-first form passes actual metadata, copy and catch tests.

Repeated optional probes release temporary Tensors and alias namespaces after
collection. Public/private installed layouts perform the same tests, including
error serialization and standard imports, and survive independent uninstall.
The existing explicit `import torch` alias/CLI lifecycle is preserved.

## Numerical source and local validation

Source hashes identify **40 unchanged resources**. AST comparison checks
**{sum(audit['unchanged_function_counts'].values())} unchanged existing function definitions** in Tensor,
optimizer and Schedules code outside lookup helpers, plus unchanged numerical
install statements and non-lookup operator registration. The generic operation
unsupported helper remains unchanged. This source evidence complements runtime
tests; it does not establish all third-party-library compatibility.

- Full merged Python suite: **{full['passed']:,} passes, 1 optional skip,
  {full['warnings']} warnings, {full['duration_s']:.2f}s**.
- Focused native feature, dispatch/lifecycle, standalone and actual import
  fallback contracts: **124 passes**.
- Node Pyodide and actual Chrome Worker: **1,581 checks in 36 suites each**
  on pinned Pyodide 0.29.4 / NumPy 2.2.5 without native Torch.
- Independent Python 3.10.19 / NumPy 1.26.4 wheel: **1,594 passes**.
  All 47 core/license resources agree across public/private distributions;
  aliases, CLI, ZIP resume, lookup/import/pickle and uninstall ownership pass.
- Original native application catalog: **78 problems, 10,218 executions,
  342 mutants, 3 repeats, {app['native']['duration_s']:.2f}s**, unchanged budgets.
- Actual exported WASM: **78/78 modules, 342 mutants,
  {app['exported_wasm']['elapsed_ms']}ms**, concurrency 2, no deadline exceeded.
- Full frontend check and both typed builds pass. All **8,807** prior immutable
  assets remain byte-identical; **158** new payloads are reachable and all
  **161** active index/payload files are SHA-256 frozen.

The first full WASM run passed 77/78 modules. Its attention task also runs all
independent SDK suites, including the new Schedules-specific lookup tests;
that VM originally contained only the autograd export and lacked `_legacy.py`.
The maintained test driver now loads that one module from the actual exported
Schedules bundle, after the original learner/reference/mutant checks, verifies
every shared resource agrees and records both profile URLs and the supplemental
source hash. All **1,581 checks in 36 suites** then pass in the complete 78-module
rerun. No SDK test was skipped, production bundle enlarged, checkout runtime
substituted or deadline increased. The original failed run and targeted
diagnostics remain in the integration reproduction archive.

## Complete-flow measurements

Eight sequential children cover two dtypes and two fresh processes per CPU/WASM
after heavy gates. The 21 workflows use nine ABBA/BAAB blocks, warmups, GC enabled,
actual SGD updates and value/dtype/gradient/state checks. Both namespaces use
the same inverse and native-ordered JVP APIs. Optional-SGD and optional Schedules
inference compare the new Python default lookup with an explicit 0.36
UnsupportedOperation-catching workaround. Unmodified 0.36 would fail the same
optional probe, so this is not described as a speed comparison with working
unmodified feature detection. The initial 19-flow and both-profile 21-flow pilots
remain available.

| Whole workflow | CPU time reduction vs 0.36 | WASM time reduction vs 0.36 |
| --- | ---: | ---: |
{table}

Negative values mean slower. This version makes no uniform numerical speedup
claim. An initial CPU unary control sample shows -11.4% despite unchanged
numerical code. Four additional complete paired CPU children run after the full
WASM gate, without source edits or discarded original samples. Their unary
control range is **{followup_range('unary-control')}**, optional-SGD
**{followup_range('optional-sgd')}**, and Schedules optional inference
**{followup_range('legacy-optional-inference')}**. A separate 50-iteration unary
probe counts actual missing-lookup calls: baseline
`{json.dumps(probe['baseline']['missing_lookup_counts'],sort_keys=True)}` and candidate
`{json.dumps(probe['candidate']['missing_lookup_counts'],sort_keys=True)}`; its gradients agree.
The follow-up remains separate from the original table.

Cold CPU namespace import medians (four fresh alternating processes per set):
NumPy included {imports['0']['previous_036']['median_ms']:.2f} →
{imports['0']['candidate_037']['median_ms']:.2f}ms; preloaded
{imports['1']['previous_036']['median_ms']:.2f} →
{imports['1']['candidate_037']['median_ms']:.2f}ms. Source bytes
{size['previous_036']['raw_bytes']} → {size['candidate_037']['raw_bytes']}; local
gzip estimates {size['previous_036']['local_gzip_estimate_bytes']} →
{size['candidate_037']['local_gzip_estimate_bytes']}. These shared-host results
request thread limits but do not verify vendor thread counts. They are not
statistical guarantees, browser wire sizes or native-Torch/CPU-WASM throughput
comparisons. No WebGPU backend is enabled by this change.

## Reproduction, adoption and remaining scope

[`iteration-37.json`](../../packages/stridetorch/benchmarks/results/iteration-37.json)
and [`iteration-37-integration.json`](../../packages/stridetorch/benchmarks/results/iteration-37-integration.json)
contain exact hashes, receipts, probes, pilots and hashed reproduction archives.
Application gates use upstream `{app['upstream']}`, including its current catalog
in the rebuilt private wheel. Later main synchronization/adoption is recorded
separately. Native-reference tests are oracles, not runtime dependencies.

The [explicit-release policy](../releasing.md) remains unchanged. No CI, tag,
workflow dispatch, package upload or online publication is requested. The user
will tag later. Local results do not establish remote Linux CI or deployment.
The actual export inventory still lacks max_pool2d/MaxPool2d, transpose
convolution and instance normalization; this lookup repair does not advertise
them. Broader core numerical coverage and prior measured performance gaps remain
active work toward independent-library readiness.
'''
(repo/'docs/validation/torch-runtime-iteration-37.md').write_text(text)
roadmap=repo/'packages/stridetorch/ROADMAP.md';content=roadmap.read_text();marker='## Next implementation areas';assert marker in content and '## Version 0.37:' not in content
addition=f'''## Version 0.37: Python-compatible optional feature discovery

- Missing public namespace/Tensor/optimizer attributes follow AttributeError,
  hasattr and getattr-default rules while retaining typed unsupported catches.
  Standard import failures preserve actual browser fallback; real operation and
  descriptor errors remain visible. Both browser profiles share the behavior.
- The minimal Schedules export explicitly carries shared errors and starts
  independently of the full API. Dynamic attributes, copy/pickle, object
  lifetimes and both installed namespaces are validated across tested runtimes.
- Full core {full['passed']:,} passes; Node/Chrome 1,581 each; minimum wheel 1,594.
  Complete native/exported WASM catalogs and frontend/builds pass. No uniform
  numerical speedup is claimed; all controls and outlier follow-up are retained
  in the [validation record](../../docs/validation/torch-runtime-iteration-37.md).
- Quiet main adoption is separate from publication. No CI/tag/dispatch/online
  release. Actual missing pooling/transpose-convolution APIs remain future work.

'''
roadmap.write_text(content.replace(marker,addition+marker));print('Wrote0.37 validation report and roadmap from actual receipts')
