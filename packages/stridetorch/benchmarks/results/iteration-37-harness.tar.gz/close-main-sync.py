from pathlib import Path
import hashlib,json,tarfile
r=Path(__file__).resolve().parent;s=r/'main-sync-proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
context=json.loads((s/'context.json').read_text());receipts=json.loads((s/'frontend-receipts.json').read_text());assert len(receipts)==5 and all(v['exit_code']==0 for v in receipts)
for path,digest in context['changed_files'].items():assert sha(repo/path)==sha(s/'incoming'/path)==digest
for name,digest in context['source_hashes'].items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==digest
for name,digest in context['active_export_sha256'].items():assert sha(repo/'web/public/data'/name)==digest
archive=out/'iteration-37-main-sync-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(s.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(s)),recursive=False)
report=dict(status='complete_local_latest_frontend_and_both_builds_passed',context=context,frontend_receipts=receipts,archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),publication='No CI, tag, workflow dispatch or online release requested.')
(out/'iteration-37-main-sync.json').write_text(json.dumps(report,indent=2)+'\n')
doc=repo/'docs/validation/torch-runtime-iteration-37.md';doc.write_text(doc.read_text()+f'\nFinal main synchronization preserves all 15 incoming UI/docs/check files through\n`{context["upstream"]}` byte-for-byte. The complete frontend check and both\ntyped builds pass again, including community code blocks and resilient sharing.\nAll 47 computational resources and 161 exports remain unchanged; see\n`iteration-37-main-sync.json`. The full exported WASM retry ran after these\nchecks against this same source and catalog.\n')
print(json.dumps(dict(upstream=context['upstream'],frontend='full check and both builds passed',source_unchanged=47,exports_unchanged=161)))
