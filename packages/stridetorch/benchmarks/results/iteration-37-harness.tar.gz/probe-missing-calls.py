from pathlib import Path
from collections import Counter
import importlib.util,json,sys
r=Path(__file__).resolve().parent;rows={}
for label,folder in [('baseline',r/'baseline/stridetorch'),('candidate',r/'proof/source')]:
    name='probe_'+label;spec=importlib.util.spec_from_file_location(name,folder/'__init__.py',submodule_search_locations=[str(folder)]);package=importlib.util.module_from_spec(spec);sys.modules[name]=package;spec.loader.exec_module(package);lib=package.torch
    counts=Counter();original=lib.Tensor.__getattr__
    def lookup(self,key,original=original,counts=counts):
        counts[key]+=1;return original(self,key)
    lib.Tensor.__getattr__=lookup
    x=lib.tensor([[.2,.3],[.4,.5]],dtype=lib.float64,requires_grad=True)
    for _ in range(50):
        x.grad=None;x.sin().exp().tanh().square().mean().backward()
    rows[label]=dict(missing_lookup_counts=dict(counts),gradient=x.grad.numpy().tolist())
    lib.Tensor.__getattr__=original
assert rows['baseline']['gradient']==rows['candidate']['gradient']
(r/'unary-missing-lookup-probe.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
