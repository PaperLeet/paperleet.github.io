from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';i=r/'integration-proof';receipts=[];start_wait=time.monotonic()
def save(name,value):(r/name).write_text(json.dumps(value,indent=2)+'\n')
while True:
 if not all(p.exists() for p in (i/'frontend-receipts.json',r/'full-root-receipt.json',i/'setup-receipts.json')):
  if time.monotonic()-start_wait>1200:raise RuntimeError('Local gate receipts missing after20minutes')
  time.sleep(5);continue
 front=json.loads((i/'frontend-receipts.json').read_text());full=json.loads((r/'full-root-receipt.json').read_text());setup=json.loads((i/'setup-receipts.json').read_text())
 if any(x['exit_code']!=0 for x in front+setup) or full['exit_code']!=0:raise RuntimeError('Local gate failed')
 if len(front)==5 and len(setup)==4:break
 if time.monotonic()-start_wait>900:raise RuntimeError('Final frontend did not finish within15minutes')
 time.sleep(5)
print('Final frontend/full-root complete;isolated native then performance/import/WASM',flush=True)
for script,folder,logname in [('run-native.py',i,'native-runner.log'),('run-performance-final.py',r,'performance-final-run.log'),('run-imports.py',r,'imports-run.log'),('run-wasm.py',i,'wasm-runner.log')]:
 started=time.monotonic();env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
 with (folder/logname).open('w') as log:p=subprocess.run([str(py),str(folder/script)],cwd=folder,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(script=script,exit_code=p.returncode,elapsed_s=time.monotonic()-started));save('final-sequential-receipts.json',receipts);print(script,'terminal',p.returncode,flush=True);p.check_returncode()
print('All4 final sequential gates terminal0',flush=True)
