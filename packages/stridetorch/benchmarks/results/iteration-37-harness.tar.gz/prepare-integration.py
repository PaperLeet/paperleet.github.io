from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;i=r/'integration-proof';i.mkdir();repo=Path('/Users/david/Developer/PaperLeet-torch-release');old=r.parent/'torch-iteration-36/integration-proof'
upstream=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
for name in ('verify-export.py','run-export.py','freeze.py','verify-private.py','run-frontend.py','run-setup.py','run-native.py','run-wasm.py'):
    text=(old/name).read_text().replace('0.36.0','0.37.0').replace('==8649','==8807').replace('1532','1581').replace('len(tests)==35','len(tests)==36').replace('expected_suites=35','expected_suites=36').replace('iteration36 integration','iteration37 integration')
    text=text.replace('torch-iteration-35/integration-proof/owned-dependencies.json','torch-iteration-36/integration-proof/owned-dependencies.json')
    (i/name).write_text(text)
source=json.loads((r/'proof/source-hashes.json').read_text());assert len(source)==47 and all(hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/k).read_bytes()).hexdigest()==v for k,v in source.items())
(i/'context.json').write_text(json.dumps(dict(upstream=upstream,source_hashes=source,core_report='iteration-37.json',release_policy='No CI, tag, dispatch, package upload or online publication. User will explicitly tag later.',scope='All8807 prior immutable assets retained. Both profiles carry Python-compatible missing-symbol behavior; schedules includes shared errors explicitly. Fresh current private catalog, full native/exported WASM/frontend/both builds required; timings run after heavy gates.'),indent=2)+'\n')
(i/'dist-paperleet').mkdir()
for p in (r/'proof/private-dist').iterdir():shutil.copy2(p,i/'dist-paperleet'/p.name)
print('Prepared application integration',upstream,'8807 prior assets')
