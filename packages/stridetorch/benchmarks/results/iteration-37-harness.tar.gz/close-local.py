from pathlib import Path
import hashlib,json,os,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results';proof=r/'proof';i=r/'integration-proof'
def read(name):return json.loads((r/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
actual={p.name:sha(p) for p in (repo/'packages/stridetorch/src/stridetorch').iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};assert len(actual)==47 and actual==read('proof/source-hashes.json')
tests={p.name:sha(p) for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'};plan=read('proof/chrome-contracts/plan.json');assert len(tests)==36 and plan['tests']==tests and plan['source']==actual and plan['expected']==1581
gates=read('proof/gate-receipts.json');assert len(gates)==6 and all(v['exit_code']==0 for v in gates.values())
full=read('full-root-receipt.json');assert full['exit_code']==0 and full['passed']>=32549 and full['skipped']==1
assert '124 passed' in (r/'focus-profiles.log').read_text()
node=read('proof/source-wasm.json');chrome=read('proof/chrome-contracts/result.json');wheel=read('proof/wheel-stride037-result.json');coinstall=read('proof/coinstall-result.json')
assert node['passed']==chrome['passed']==1581 and node['source_hashes']==chrome['source_hashes']==wheel['source_hashes']==coinstall['source_hashes']==actual
assert chrome['test_hashes']==tests and chrome['status']==wheel['status']==coinstall['status']=='success' and not wheel['native_torch']
assert '1594 passed' in (proof/'python310-stride037-tests.log').read_text()
performance=read('performance-final-summary.json');imports=read('import-summary.json')
assert len(performance['receipts'])==8 and all(v['exit_code']==0 for v in performance['receipts'].values())
assert len(imports['receipts'])==16 and all(v['exit_code']==0 for v in imports['receipts'])
for p in (r/'performance-final').glob('*.json'):
    if p.name!='receipts.json':assert json.loads(p.read_text())['source_hashes']['candidate']==actual
audit=read('numerical-source-audit.json');assert audit['status']=='success' and audit['unchanged_resources']==40
followup=read('cpu-followup-summary.json');assert len(followup['receipts'])==4 and all(v['exit_code']==0 for v in followup['receipts'].values())
for p in (r/'performance-cpu-followup').glob('previous-*.json'):assert json.loads(p.read_text())['source_hashes']['candidate']==actual
native=read('integration-proof/native-ci.json');wasm=read('integration-proof/full-wasm-result.json');setup=read('integration-proof/setup-receipts.json');front=read('integration-proof/frontend-receipts.json');snapshot=read('integration-proof/release-snapshot.json');exports=read('integration-proof/export-identity.json');private=read('integration-proof/distribution-identity.json')
assert native['passed'] and native['problems']==78 and native['tests_executed']==10218 and native['repeats']==3 and native['duration_s']<=600 and not native['issues']
assert len(native['mutation'])==78 and sum(map(len,native['mutation'].values()))==342 and all(hits for mutants in native['mutation'].values() for hits in mutants.values())
assert wasm['passed'] and wasm['catalog_modules']==wasm['modules']==78 and not wasm['browser_budget_exceeded'] and sum(v['mutants'] for v in wasm['results'])==342
assert all(v['passed'] and not v['browser_budget_exceeded'] for v in wasm['results'])
attention=next(v for v in wasm['results'] if v['id']=='architecture/attention')
contracts=attention['independent_contracts'];assert contracts['passed']==1581 and len(contracts['suites'])==36
assert {v['suite']:v['source_sha256'] for v in contracts['suites']}==tests
profiles=contracts['runtime_profiles'];assert len(profiles)==2 and profiles[0]['backend']=='numpy-autograd-wasm' and profiles[0]['supplemented_files']==[]
assert profiles[1]['backend']=='numpy-wasm' and profiles[1]['supplemented_files']==[dict(name='stridetorch/_legacy.py',source_sha256=actual['_legacy.py'])]
repair=read('integration-proof/harness-repair.json');assert repair['source_hashes_unchanged'] and repair['active_exports_unchanged']
first=read('integration-proof/wasm-first/full-wasm-result.json');assert not first['passed'] and sum(v['passed'] for v in first['results'])==77
harness=read('integration-proof/wasm-harness-identity.json');assert sha(repo/harness['file'])==harness['sha256'] and sha(repo/harness['driver_file'])==harness['driver_sha256']
assert read('integration-proof/wasm-receipt.json')['exit_code']==0
assert all(v['exit_code']==0 for v in read('final-sequential-receipts.json'))
assert len(setup)==4 and len(front)==5 and all(v['exit_code']==0 for v in setup+front)
assert snapshot['source_hashes']==actual and exports['published_assets_unchanged']==8807 and exports['active_assets']==exports['new_assets']==158 and exports['all_new_assets_reachable'] and private['status']=='success'
small=[row for row in exports['runtimes'].values() if row['backend']=='numpy-wasm'];assert len(small)==1 and small[0]['package_files']==6
live=read('integration-proof/live-expected-sha256.json');assert len(live)==161
for name,digest in live.items():assert sha(repo/'web/public/data'/name)==digest
for folder,paths in [('native-contracts',(repo/'tests').glob('test_torch_*')),('package-metadata',[(repo/'packages/stridetorch'/name) for name in ('README.md','pyproject.toml','LICENSE','NOTICE')])]:
    dest=r/folder;dest.mkdir(exist_ok=True)
    for p in paths:
        if p.is_file():shutil.copy2(p,dest/p.name)
shutil.copy2(repo/'tests/test_browser_judge.py',r/'native-contracts/test_browser_judge.py')
shutil.copy2(repo/'packages/stridetorch/tests/test_standalone.py',r/'package-metadata/test_standalone.py')
def archive(name,root,excluded):
    files=[]
    for folder,dirs,names in os.walk(root):
        dirs[:]=[d for d in dirs if not d.endswith('-env') and d not in excluded and d not in ('__pycache__','.pytest_cache')]
        for name2 in names:
            p=Path(folder)/name2
            if p.is_symlink():continue
            if p.name in ('LICENSE','NOTICE') or p.suffix in ('.py','.mjs','.cjs','.json','.log','.txt','.md','.html','.toml','.diff'):files.append(p)
    path=out/name
    with tarfile.open(path,'w:gz') as tar:
        for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
    return dict(file=path.name,files=len(files),bytes=path.stat().st_size,sha256=sha(path))
core_archive=archive('iteration-37-harness.tar.gz',r,{'dist-preflight','private-dist','dist-paperleet','integration-proof','main-sync-proof','main-sync-final'})
core=dict(status='complete_local_core_and_application_gates_passed_main_adoption_pending',version='0.37.0',baseline_main='0ad30894e62c34df33cd76b47967c1ed17b5c1a6',source_hashes=actual,standalone_test_hashes=tests,native_test_hashes={p.name:sha(p) for p in (r/'native-contracts').iterdir()},full_cpu=full,focused_passed=124,minimal_passed=1594,minimal_wheel=wheel,node_wasm=node,actual_chrome_worker=chrome,coinstall=coinstall,gate_receipts=gates,pilot_reports={name:read(name+'/receipts.json') for name in ('performance-first','performance-profiles')},final_performance=performance,cold_namespace_imports=imports,numerical_source_audit=audit,native_feature_probe=read('native-feature-probe.json'),export_inventory=read('actual-export-audit.json'),archive=core_archive,scope='Missing public symbols on all32 torch namespaces, Tensors and optimizers follow Python AttributeError/default protocols while retaining UnsupportedOperation/NotImplementedError catches. Model Module attributes retain their existing ordinary AttributeError. Unavailable from-imports produce standard ImportError and retain browser fallback. Both runtime profiles share error definitions; minimal schedules explicitly embeds errors and retains no-AD boundaries. No negative symbol cache, numerical algorithm change, new dependency or GPU backend.',retained_findings=['Initial CPython3.10 tests incorrectly required AttributeError.name to survive copy/pickle; actual standard exception drops it there. Assertions now compare against each interpreter standard behavior; original three failures retained.','Probe with NotImplementedError before AttributeError rejected name/obj keywords; AttributeError-first MRO preserves current native metadata and existing backend catches. Python advises against multiple built-in exception bases because layouts can change; gates validate Python3.10.19/3.12.11 and actual Pyodide3.13.2, not untested/future interpreters.','Initial19-workflow and expanded21-workflow pilots retain raw samples, controls and requested thread settings. This is a usability change; no uniform numerical speedup is claimed.'],primary_sources=['https://peps.python.org/pep-0562/','https://docs.python.org/3/library/exceptions.html#inheriting-from-built-in-exceptions','https://docs.python.org/3/library/functions.html#hasattr'],release_policy='No CI, tag, dispatch, package upload or online publication; user will explicitly release later.')
core['cpu_variability_followup']=followup;core['unary_lookup_probe']=read('unary-missing-lookup-probe.json');save('iteration-37.json',core)
app_archive=archive('iteration-37-integration-harness.tar.gz',i,{'dist-paperleet'})
app=dict(status='complete_local_application_gates_passed_main_adoption_pending',version='0.37.0',upstream=read('integration-proof/context.json')['upstream'],source_hashes=actual,core_report='iteration-37.json',native=native,exported_wasm=wasm,setup_receipts=setup,frontend_receipts=front,release_snapshot=snapshot,export_integrity=exports,distribution_identity=private,runtime_sizes=read('integration-proof/runtime-sizes.json'),wasm_harness=read('integration-proof/wasm-harness-identity.json'),context=read('integration-proof/context.json'),archive=app_archive,publication='Local results do not assert remote Linux CI or online deployment. No CI/tag/dispatch requested.')
app['test_harness_repair']=repair;app['test_harness_repair']['status']='complete_full78_retry_passed'
save('iteration-37-integration.json',app);print(json.dumps(dict(core=core_archive,integration=app_archive,full_cpu=full,native_s=native['duration_s'],wasm_ms=wasm['elapsed_ms']),indent=2))
