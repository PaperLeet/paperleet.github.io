from pathlib import Path
import ast,hashlib,json
r=Path(__file__).resolve().parent;old=r/'baseline/stridetorch';new=r/'proof/source'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
before={p.name:digest(p) for p in old.iterdir()};after={p.name:digest(p) for p in new.iterdir()}
changed=sorted(name for name in before if before[name]!=after[name])
assert changed==sorted(['__init__.py','_api.py','_errors.py','_legacy.py','_optimizer.py','_tensor.py','runtime.py'])
def functions(path):
    result={}
    def visit(node,prefix=''):
        for child in ast.iter_child_nodes(node):
            if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
                name=prefix+child.name
                if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef)):result[name]=ast.dump(child,include_attributes=False)
                visit(child,name+'.')
            else:visit(child,prefix)
    visit(ast.parse(path.read_text()));return result
counts={}
for name,excluded in [('_tensor.py',{'Tensor.__getattr__'}),('_optimizer.py',{'Optimizer.__getattr__'}),('_legacy.py',{'Tensor.__getattr__','_unsupported','install'})]:
    a,b=functions(old/name),functions(new/name);assert a.keys()==b.keys()
    for key in a:
        if key not in excluded:assert a[key]==b[key],(name,key)
    counts[name]=len(a)-len(excluded)
class LookupWiring(ast.NodeTransformer):
    def visit_FunctionDef(self,node):
        if node.name in ('missing','missing_root'):return None
        return self.generic_visit(node)
    def visit_Assign(self,node):
        if any(isinstance(target,ast.Attribute) and target.attr=='__getattr__' for target in node.targets):return None
        return self.generic_visit(node)
def normalized(path):return ast.dump(LookupWiring().visit(ast.parse(path.read_text())),include_attributes=False)
assert normalized(old/'_api.py')==normalized(new/'_api.py')
a,b=functions(old/'_legacy.py'),functions(new/'_legacy.py')
assert ast.dump(LookupWiring().visit(ast.parse((old/'_legacy.py').read_text()).body[-1]),include_attributes=False)==ast.dump(LookupWiring().visit(ast.parse((new/'_legacy.py').read_text()).body[-1]),include_attributes=False)
assert functions(old/'_errors.py')['unsupported']==functions(new/'_errors.py')['unsupported']
report=dict(status='success',changed_resources=changed,unchanged_resources=len(before)-len(changed),unchanged_function_counts=counts,registry_wiring='All non-lookup API registration statements unchanged after removing only missing helpers and __getattr__ assignments.',legacy='All numeric functions and install statements unchanged except lookup wiring; unsupported mode errors use the shared compatible base.',unsupported_operations='Original generic unsupported operation helper unchanged.',scope='AST/source evidence complements runtime tests. Python feature discovery intentionally changes; this is not proof that all third-party code or all interpreters are supported.')
(r/'numerical-source-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
