from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';i=r/'integration-proof'
front=json.loads((r/'main-sync-proof/frontend-receipts.json').read_text());assert len(front)==5 and all(v['exit_code']==0 for v in front)
receipts=json.loads((r/'final-sequential-receipts.json').read_text());assert len(receipts)==4 and receipts[-1]['script']=='run-wasm.py' and receipts[-1]['exit_code']==1 and all(v['exit_code']==0 for v in receipts[:-1])
first=r/'final-sequential-first-receipts.json';assert first.exists() and json.loads(first.read_text())==receipts
start=time.monotonic()
env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
with (i/'wasm-runner.log').open('w') as log:p=subprocess.run([str(py),str(i/'run-wasm.py')],cwd=i,env=env,stdout=log,stderr=subprocess.STDOUT)
retry=dict(script='run-wasm.py',exit_code=p.returncode,elapsed_s=time.monotonic()-start,scope='Complete78-module retry with repaired cross-profile SDK test context; unchanged source,export inputs,deadlines,concurrency; original failure retained in first receipts and wasm-first.')
(r/'wasm-retry-receipt.json').write_text(json.dumps(retry,indent=2)+'\n');p.check_returncode()
receipts[-1]=retry;(r/'final-sequential-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
print('Full78 WASM retry terminal0; now4 paired CPU children',flush=True)
start=time.monotonic()
with (r/'cpu-followup-runner.log').open('w') as log:p=subprocess.run([str(py),str(r/'run-cpu-followup.py')],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
(r/'cpu-followup-receipt.json').write_text(json.dumps(dict(exit_code=p.returncode,elapsed_s=time.monotonic()-start),indent=2)+'\n');p.check_returncode();print('Four CPU followup children terminal0',flush=True)
