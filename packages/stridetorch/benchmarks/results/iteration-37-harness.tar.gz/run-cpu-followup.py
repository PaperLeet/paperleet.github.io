from pathlib import Path
import json, os, subprocess, time

r = Path(__file__).resolve().parent
out = r / 'performance-cpu-followup'
out.mkdir(exist_ok=True)
assert json.loads((r / 'final-sequential-receipts.json').read_text())[-1]['script'] == 'run-wasm.py'
assert all(x['exit_code'] == 0 for x in json.loads((r / 'final-sequential-receipts.json').read_text()))
receipts = {}
reports = []
for repeat in (1, 2):
    for dtype in ('float32', 'float64'):
        name = f'previous-cpu-{dtype}-{repeat}'
        args = [str(r.parent / 'torch-iteration-21/stride-dev-env/bin/python'), str(r / 'bench-library.py')]
        env = dict(os.environ, BENCH_DTYPE=dtype, BENCH_LANE='previous',
                   BENCH_SOURCES=json.dumps(dict(baseline=str(r / 'baseline/stridetorch'), candidate=str(r / 'proof/source'))),
                   OMP_NUM_THREADS='2', MKL_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', VECLIB_MAXIMUM_THREADS='2')
        start = time.monotonic()
        with (out / (name + '.json')).open('w') as stdout, (out / (name + '.stderr.log')).open('w') as stderr:
            result = subprocess.run(args, cwd=r, env=env, stdout=stdout, stderr=stderr)
        receipts[name] = dict(exit_code=result.returncode, elapsed_s=time.monotonic()-start)
        (out / 'receipts.json').write_text(json.dumps(receipts, indent=2)+'\n')
        result.check_returncode()
        report = json.loads((out / (name + '.json')).read_text())
        assert report['source_hashes']['candidate'] == json.loads((r / 'proof/source-hashes.json').read_text())
        reports.append(report)
summary = {key: [v['results'][key]['median_time_reduction_percent'] for v in reports] for key in reports[0]['results']}
value = dict(scope='Four additional paired CPU children after the full exported WASM gate. Follow-up of the initial CPU unary-control outlier and absolute-time variability; no source changes or discarded original measurements.', receipts=receipts, summary=summary)
(r / 'cpu-followup-summary.json').write_text(json.dumps(value, indent=2)+'\n')
print(json.dumps(summary, indent=2))
