from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');i=r/'integration-proof'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=read(r/'proof/source-hashes.json');actual={p.name:sha(p) for p in (repo/'packages/stridetorch/src/stridetorch').iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};assert source==actual
assert all(sha(repo/'web/public/data'/name)==digest for name,digest in read(i/'live-expected-sha256.json').items())
first=read(i/'wasm-first/full-wasm-result.json');assert not first['passed'] and sum(v['passed'] for v in first['results'])==77
assert [v['id'] for v in first['results'] if not v['passed']]==['architecture/attention']
a=read(i/'attention-cross-profile.json');contracts=a['independent_contracts'];assert contracts['passed']==1581 and len(contracts['suites'])==36
profiles=contracts['runtime_profiles'];assert len(profiles)==2 and profiles[0]['supplemented_files']==[] and profiles[1]['supplemented_files']==[dict(name='stridetorch/_legacy.py',source_sha256=source['_legacy.py'])]
harness=read(i/'wasm-first/wasm-harness-identity.json');tests={p.name:sha(p) for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'};assert tests==harness['test_hashes']
assert sha(repo/harness['driver_file'])==harness['driver_sha256']
harness.update(status='frozen_before_complete_retry',sha256=sha(repo/harness['file']),repair='SDK-only test context now loads the actual exported Schedules-only legacy module after original learner/reference/mutant checks. All shared resources agree; source and catalog unchanged. First failed77/78 run retained.')
(i/'wasm-harness-identity.json').write_text(json.dumps(harness,indent=2)+'\n');shutil.copy2(repo/harness['file'],i/'maintained-check-browser-wasm.mjs')
receipt=dict(status='targeted_attention_verified_full_retry_pending',first_run_passed=77,first_run_total=78,first_failure='SDK feature_detection legacy-profile tests imported a module deliberately absent from the autograd-only bundle.',change='Cross-profile SDK contracts supplement only the exported Schedules _legacy.py after all original production checks. No test skipped, runtime source checkout substituted, production bundle enlarged or timeout increased.',source_hashes_unchanged=True,active_exports_unchanged=True,targeted_contracts=contracts,previous_harness_sha256=read(i/'wasm-first/wasm-harness-identity.json')['sha256'],current_harness_sha256=harness['sha256'])
(i/'harness-repair.json').write_text(json.dumps(receipt,indent=2)+'\n');print('Frozen repaired harness; source47/export161 unchanged, targeted1581/36 verified')
