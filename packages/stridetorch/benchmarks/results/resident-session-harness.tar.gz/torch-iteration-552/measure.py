import gc,itertools,json,math,statistics,time
import numpy as np
import stridetorch
from pyodide.ffi import run_sync
from js import matrix_rpc
from baseline_torch_bridge import MatmulOffload as Baseline
from resident_bridge import ResidentMatmulOffload
from workloads import Flow

config=json.load(open('/config.json'));cycle,size=int(_cycle),int(_size)
assert cycle in config['cycles'] and size in config['sizes'] and gc.isenabled() and stridetorch.__version__=='0.83.0'
limits=json.loads(_limits_json);assert limits==dict(bytes=33554432,matrixBytes=4194304,dimension=1024,macs=268435456,handles=24,pending=8,requests=4096,leaseMs=120000,programInputs=8,programNodes=8,programOutputs=8)
refs=[np.load('/native26.npz',allow_pickle=False),np.load('/native214.npz',allow_pickle=False)]
initial_err=np.geterr();initial_handler=np.geterrcall();rows=[]
orders=list(itertools.permutations(['A0','A1','R']));offset=cycle%6;orders=orders[offset:]+orders[:offset];orders+=list(reversed(orders))
kinds=config['flows'];kinds=kinds[cycle:]+kinds[:cycle]

def verify(result,kind):
 index,values=result;source='steady_single' if kind=='changing_rhs' else kind
 assert len(values)==(5 if kind=='steady_chain' else 3)
 for i,value in enumerate(values):
  assert value.dtype==np.float32 and value.flags.owndata and value.base is None
  for ref in refs:
   expected=ref[f'{size}_{source}_{i}']
   if kind=='changing_rhs' and i<2:expected=expected+index*ref[f'{size}_'+('y_slope' if i==0 else 'da_slope')]
   np.testing.assert_allclose(value,expected,rtol=config['rtol'],atol=config['atol'])
 assert all(not np.shares_memory(a,b) for i,a in enumerate(values) for b in values[i+1:])

def timed(call,count):
 gc.collect();start=time.perf_counter()
 for _ in range(count):result=call()
 return time.perf_counter()-start,result

for kind in kinds:
 operations={};setup={};counts={};calibration={}
 try:
  for label in ['A0','A1','R']:
   start=time.perf_counter();operation=ResidentMatmulOffload() if label=='R' else Baseline();operations[label]=Flow(stridetorch.torch,operation,size,kind);setup[label]=time.perf_counter()-start
   verify(operations[label](),kind)
   for _ in range(config['warmup_calls']):verify(operations[label](),kind)
  for label in ['A0','A1','R']:
   count=1;samples=[]
   while True:
    elapsed,result=timed(operations[label],count);verify(result,kind);samples.append(dict(iterations=count,seconds=elapsed))
    if elapsed>=config['calibration_seconds'] or count>=config['iteration_cap']:break
    count=min(config['iteration_cap'],count*2)
   counts[label]=min(config['iteration_cap'],max(1,math.ceil(count*config['target_batch_seconds']/elapsed)));calibration[label]=samples
  raw=[]
  for order in orders:
   samples={}
   for label in order:
    elapsed,result=timed(operations[label],counts[label]);verify(result,kind);samples[label]=dict(iterations=counts[label],seconds=elapsed,seconds_per_call=elapsed/counts[label],iteration_after=operations[label].iteration)
   raw.append(dict(order=order,samples=samples))
  medians={label:statistics.median(v['samples'][label]['seconds_per_call'] for v in raw) for label in ['A0','A1','R']}
  aa=medians['A1']/medians['A0'];paa=statistics.median(v['samples']['A1']['seconds_per_call']/v['samples']['A0']['seconds_per_call'] for v in raw)
  ratio=medians['R']/medians['A0'];paired=statistics.median(v['samples']['R']['seconds_per_call']/v['samples']['A0']['seconds_per_call'] for v in raw)
  floor=min(v['samples'][label]['seconds'] for v in raw for label in ['A0','A1','R'])
  info=operations['R'].operation.cache_info();stats=run_sync(matrix_rpc.stats()).to_py();assert stats['resident_handles']==info['owned_leases'] and stats['total_bytes']==stats['resident_bytes']==info['resident_bytes']
  row=dict(size=size,kind=kind,setup_seconds=setup,counts=counts,calibration=calibration,raw=raw,medians=medians,aa_ratio=aa,paired_aa_ratio=paa,resident_over_baseline_ratio=ratio,paired_resident_over_baseline_ratio=paired,minimum_batch_seconds=floor,aa_passed=all(.95<=v<=1.05 for v in [aa,paa]),floor_passed=floor>=config['minimum_batch_seconds'],cache_info=info,stats_before_close=stats,normal_gc=True,native_controls_passed=True)
  rows.append(row);print('RESIDENT_SAMPLE '+json.dumps(row),flush=True)
 finally:
  for operation in operations.values():operation.close()
 stats=run_sync(matrix_rpc.stats()).to_py();assert stats['resident_handles']==stats['total_bytes']==stats['allocations']==0
assert len(rows)==3 and gc.isenabled() and np.geterr()==initial_err and np.geterrcall() is initial_handler
report=dict(status='passed_resident_comparison',cases=3,cycle=cycle,size=size,rows=rows,config=config,source_version=stridetorch.__version__,numpy=np.__version__,final_stats=run_sync(matrix_rpc.stats()).to_py(),latency_measured=True,production_changed=False,automatic_dispatch_enabled=False)
