from pathlib import Path
import hashlib,json,statistics
r=Path(__file__).resolve().parent;b=r.parent;source=Path(__import__('sys').argv[1]) if len(__import__('sys').argv)>1 else b/'torch-iteration-552';read=lambda p:json.loads(p.read_text());config=read(source/'config.json');assert read(source/'progress.json')['status']=='completed';rows=[];flags=[]
for size in config['sizes']:
 reports=[read(source/f'browser-result-{size}-{cycle}.json') for cycle in config['cycles']]
 for report in reports:assert report['status']=='passed' and all(v['stats']['closed'] and v['stats']['total_bytes']==0 for v in report['host_disposals'])
 for kind in config['flows']:
  values=[next(v for v in report['numerical']['rows'] if v['kind']==kind) for report in reports]
  aa=[statistics.median(v[k] for v in values) for k in ['aa_ratio','paired_aa_ratio']];ratio=[statistics.median(v[k] for v in values) for k in ['resident_over_baseline_ratio','paired_resident_over_baseline_ratio']]
  controls=all(.95<=v<=1.05 for v in aa) and all(.9<=v[k]<=1.1 for v in values for k in ['aa_ratio','paired_aa_ratio']) and all(v['floor_passed'] for v in values)
  individual=[dict(size=size,kind=kind,cycle=i,aa=v['aa_ratio'],paired_aa=v['paired_aa_ratio'],floor=v['minimum_batch_seconds']) for i,v in enumerate(values) if not v['aa_passed'] or not v['floor_passed']];flags.extend(individual)
  rows.append(dict(size=size,kind=kind,controls_passed=controls,aa=aa,ratios=ratio,resident_benefit=controls and all(v<1 for v in ratio),baseline_ms=1000*statistics.median(v['medians']['A0'] for v in values),resident_ms=1000*statistics.median(v['medians']['R'] for v in values),minimum_batch_ms=1000*min(v['minimum_batch_seconds'] for v in values),individual_flags=individual))
summary=dict(status='analyzed_resident_comparison',source=str(source),rows=rows,individual_flags=flags,processes=6,contexts=18,production_changed=False,all_preplanned_controls_passed=all(v['controls_passed'] for v in rows),candidate_adopted=False,goal_status='active');(r/'result.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
