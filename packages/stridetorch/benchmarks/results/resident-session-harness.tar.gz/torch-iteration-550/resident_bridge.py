"""Bounded content-coherent GPU buffer residency for explicit Tensor offload.

A context owns its immutable buffers. CPU Tensor values remain public, while
resident buffers can bridge forward nodes and directly adjacent GPU pullbacks.
No computed numerical result is memoized: every eligible call runs its program.
"""
from collections import OrderedDict
import operator
import weakref
import numpy as np
import torch_bridge as core


class _RpcBackend:
    def upload(self, value):
        from matrix_client import Matrix
        return Matrix.upload(value)

    def program(self, jobs, resolved, retain):
        from matrix_client import MatrixProgram
        program = MatrixProgram()
        refs = {}
        for a, b, _, _ in jobs:
            for value in (a, b):
                if id(value) not in refs:
                    refs[id(value)] = program.input(resolved[id(value)])
        outputs = [program.matmul(refs[id(a)], refs[id(b)], ta, tb) for a, b, ta, tb in jobs]
        return program.run(outputs, read=True, retain=retain)

    def release(self, matrices):
        from pyodide.ffi import run_sync, to_js
        live = [matrix for matrix in matrices if not matrix.closed]
        if not live:
            return
        client = live[0].client
        if any(matrix.client != client for matrix in live):
            raise RuntimeError('Resident buffers belong to different sessions')
        if not client.closed:
            run_sync(client.releaseMany(to_js([matrix.handle for matrix in live])))
        for matrix in live:
            matrix.closed = True


class _Entry:
    def __init__(self, serial, data, matrix, used):
        self.serial, self.data, self.matrix, self.used = serial, data, matrix, used


def _bits_equal(a, b):
    return a.shape == b.shape and a.dtype == b.dtype and np.array_equal(a.view(np.uint32), b.view(np.uint32))


class ResidentMatmulOffload(core.MatmulOffload):
    """Explicit bounded session; no GPU device or stable package API is added.

    close() frees resident buffers and rejects new forward calls. Existing
    graphs can finish through CPU pullbacks after an intentional close. Failed
    GPU calls propagate errors; they are never retried as CPU work.
    """
    def __init__(self, *, max_entries=8, max_bytes=8*1024*1024, backend=None):
        for name, value, maximum in [('max_entries', max_entries, 8), ('max_bytes', max_bytes, 8*1024*1024)]:
            if isinstance(value, bool):
                raise TypeError(name+' must be an integer')
            number = operator.index(value)
            if not 0 <= number <= maximum:
                raise ValueError(name+' exceeds the bounded cache limit')
        self.max_entries, self.max_bytes = operator.index(max_entries), operator.index(max_bytes)
        self.backend = _RpcBackend() if backend is None else backend
        self.closed = False
        self.failed = False
        self._entries, self._leases = [], {}
        self._operations = OrderedDict()
        self._serial = self._clock = 0
        self._counters = dict(uploads=0, upload_bytes=0, cache_hits=0, programs=0,
                              inline_upload_bytes=0, retained_results=0, evictions=0)
        super().__init__()

    def __enter__(self):
        self._live()
        if core._busy:
            raise RuntimeError('A GPU Tensor submission is already active')
        return self

    def __exit__(self, typ, error, traceback):
        try:
            self.close()
        except BaseException as cleanup:
            if error is not None:
                raise RuntimeError('Resident cleanup failed after an operation error: '+str(cleanup)) from error
            raise
        return False

    def _live(self):
        if self.closed:
            raise RuntimeError('Resident GPU session is closed')
        if self.failed:
            raise RuntimeError('Resident GPU cleanup failed; close the session before reuse')

    def __call__(self, a, b):
        self._live()
        return super().__call__(a, b)

    def _touch(self, entry):
        self._clock += 1
        entry.used = self._clock

    def _find(self, value):
        for entry in self._entries:
            if _bits_equal(entry.data, value):
                self._touch(entry)
                return entry
        return None

    def _release(self, matrices):
        live = list({id(matrix): matrix for matrix in matrices if id(matrix) in self._leases}.values())
        if not live:
            return
        self.backend.release(live)
        removed = {id(matrix) for matrix in live}
        for key in removed:
            self._leases.pop(key, None)
        self._entries[:] = [entry for entry in self._entries if id(entry.matrix) not in removed]

    def _room(self, size, pinned):
        if not self.max_entries or size > self.max_bytes:
            return False
        while len(self._entries) >= self.max_entries or sum(entry.data.nbytes for entry in self._entries)+size > self.max_bytes:
            available = [entry for entry in self._entries if id(entry.matrix) not in pinned]
            if not available:
                return False
            victim = min(available, key=lambda entry: entry.used)
            self._release([victim.matrix])
            self._counters['evictions'] += 1
        return True

    def _add(self, value, matrix):
        self._serial += 1
        self._clock += 1
        entry = _Entry(self._serial, value, matrix, self._clock)
        self._entries.append(entry)
        return entry

    def _known_output(self, key):
        reference = self._operations.get(key) if key is not None else None
        entry = reference() if reference is not None else None
        return entry is not None and entry in self._entries

    def _submit_jobs(self, jobs, retain_outputs):
        if self.closed:
            return [core._cpu_product(*job) for job in jobs]
        self._live()
        unique = {id(value): value for a, b, _, _ in jobs for value in (a, b)}
        resolved, entries, pinned = {}, {}, set()
        # Pin existing hits first so filling later misses cannot evict a live
        # input descriptor of this program.
        for key, value in unique.items():
            entry = self._find(value)
            if entry is not None:
                resolved[key], entries[key] = entry.matrix, entry
                pinned.add(id(entry.matrix))
                self._counters['cache_hits'] += 1
        for key, value in unique.items():
            if key in resolved:
                continue
            # A newly uploaded equal-valued input can serve another operand.
            entry = self._find(value)
            if entry is not None:
                resolved[key], entries[key] = entry.matrix, entry
                pinned.add(id(entry.matrix))
                self._counters['cache_hits'] += 1
            elif self._room(value.nbytes, pinned):
                matrix = self.backend.upload(value)
                self._leases[id(matrix)] = matrix
                entry = self._add(value, matrix)
                resolved[key], entries[key] = matrix, entry
                pinned.add(id(matrix))
                self._counters['uploads'] += 1
                self._counters['upload_bytes'] += value.nbytes
            else:
                resolved[key] = value
                self._counters['inline_upload_bytes'] += value.nbytes
        keys, wanted = [], []
        for (a, b, ta, tb), retain in zip(jobs, retain_outputs):
            key = (entries[id(a)].serial, entries[id(b)].serial, ta, tb) if id(a) in entries and id(b) in entries else None
            shape = (a.shape[1] if ta else a.shape[0], b.shape[0] if tb else b.shape[1])
            keys.append(key)
            wanted.append(bool(retain and self.max_entries and 4*shape[0]*shape[1] <= self.max_bytes and not self._known_output(key)))
        self._counters['programs'] += 1
        result = self.backend.program(jobs, resolved, any(wanted))
        matrices = list(result.matrices)
        for matrix in matrices:
            if matrix is not None:
                self._leases[id(matrix)] = matrix
        arrays = list(result.arrays)
        if len(arrays) != len(jobs) or len(matrices) != len(jobs):
            raise RuntimeError('Resident transport returned an invalid output count')
        discard = []
        for array, matrix, job, key, keep in zip(arrays, matrices, jobs, keys, wanted):
            a, b, ta, tb = job
            shape = (a.shape[1] if ta else a.shape[0], b.shape[0] if tb else b.shape[1])
            if not isinstance(array, np.ndarray) or array.dtype != np.float32 or array.shape != shape:
                raise RuntimeError('Resident transport returned an invalid matrix')
            if matrix is None:
                continue
            existing = self._find(array)
            if keep and existing is None and self._room(array.nbytes, set()):
                existing = self._add(array, matrix)
                self._counters['retained_results'] += 1
            else:
                discard.append(matrix)
            if keep and existing is not None and key is not None:
                self._operations[key] = weakref.ref(existing)
                self._operations.move_to_end(key)
                while len(self._operations) > 64:
                    self._operations.popitem(last=False)
        self._release(discard)
        return arrays

    def _execute(self, *args, **kwargs):
        if core._busy:
            raise RuntimeError('A GPU Tensor submission is already active')
        if self.closed:
            return super()._execute(*args, **kwargs)
        self._live()
        before = dict(self._leases)
        try:
            return super()._execute(*args, **kwargs)
        except BaseException as error:
            # The base has reset the global gate after validating original
            # Tensor/seed state. Rollback itself can suspend too.
            core._busy = True
            try:
                self._release([matrix for key, matrix in self._leases.items() if key not in before])
            except BaseException as cleanup:
                self.failed = True
                raise RuntimeError('Resident rollback failed: '+str(cleanup)) from error
            finally:
                core._busy = False
            raise

    def cache_info(self):
        if core._busy:
            raise RuntimeError('A GPU Tensor submission is already active')
        return dict(self._counters, entries=len(self._entries), resident_bytes=sum(entry.data.nbytes for entry in self._entries),
                    owned_leases=len(self._leases), closed=self.closed, failed=self.failed,
                    max_entries=self.max_entries, max_bytes=self.max_bytes)

    def clear(self):
        self._live()
        if core._busy:
            raise RuntimeError('A GPU Tensor submission is already active')
        core._busy = True
        try:
            self._release(list(self._leases.values()))
            self._operations.clear()
        except BaseException:
            self.failed = True
            raise
        finally:
            core._busy = False

    def close(self):
        if self.closed and not self._leases:
            return
        if core._busy:
            raise RuntimeError('A GPU Tensor submission is already active')
        core._busy = True
        self.closed = True
        try:
            self._release(list(self._leases.values()))
            self._operations.clear()
            self.failed = False
        except BaseException:
            self.failed = True
            raise
        finally:
            core._busy = False
