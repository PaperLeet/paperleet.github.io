import json
import numpy as np
from pyodide.ffi import run_sync
from js import matrix_rpc,transfer_audit
from stridetorch import torch
from baseline_torch_bridge import MatmulOffload
from resident_bridge import ResidentMatmulOffload
import cases

a,b,c,g=[torch.from_numpy(value) for value in cases.chain_inputs('C')]
for value in [a,b,c]:value.requires_grad_()
rows=[]
for name,call in [('stateless',MatmulOffload()),('resident',ResidentMatmulOffload())]:
 for phase in ['cold','warm']:
  matrix_rpc.audit_label=name+'-'+phase;start=int(matrix_rpc.nextId);before=len(transfer_audit)
  y=call(a,b);z=call(y,c);da,db,dc=torch.autograd.grad(z,(a,b,c),g)
  for value in [da,db,dc]:assert np.isfinite(value.numpy()).all()
  events=transfer_audit.to_py()[before:];wire=int(matrix_rpc.nextId)-start
  assert len(events)==4 and sum(v['nodes'] for v in events)==6 and wire==4
  expected=0 if name=='resident' and phase=='warm' else 18480 if name=='resident' else 47320
  assert sum(v['input_bytes'] for v in events)==expected,(name,phase,events)
  assert sum(v['readback_bytes'] for v in events)==27064
  rows.append(dict(provider=name,phase=phase,programs=4,compute_nodes=6,rpc_requests=wire,input_bytes=expected,readback_bytes=27064,events=events))
 if name=='resident':
  cache=call.cache_info();assert cache['owned_leases']==cache['entries']==7;call.close();assert call.cache_info()['owned_leases']==0
stats=run_sync(matrix_rpc.stats()).to_py();assert stats['resident_handles']==stats['total_bytes']==stats['allocations']==0
report=dict(status='passed_resident_transfer_trace',cases=4,rows=rows,cache_before_close=cache,final_stats=stats,source='Actual MatrixRpc.program descriptors and returned typed-array byte lengths; no timed measurements',production_changed=False)
