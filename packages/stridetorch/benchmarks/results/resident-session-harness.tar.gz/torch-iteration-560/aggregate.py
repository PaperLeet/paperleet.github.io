from pathlib import Path
import hashlib,io,json,shutil,tarfile,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
assert not (r/'resident-session-harness.tar.gz').exists();gpu=read(b/'torch-iteration-555/browser-result-0.json');assert gpu['status']=='passed' and len(gpu['numerical']['controls'])==31 and gpu['numerical']['cases']==51
performance=read(b/'torch-iteration-557/result.json');assert performance['all_preplanned_controls_passed'] and all(v['resident_benefit'] for v in performance['rows']);trace=read(b/'torch-iteration-558/browser-result-0.json');assert trace['status']=='passed'
native={}
for label in ['native25','native126']:
 suites=list(ET.parse(b/'torch-iteration-554'/(label+'.xml')).getroot().iter('testsuite'));totals={k:sum(int(v.attrib.get(k,0)) for v in suites) for k in ['tests','failures','errors','skipped']};assert totals==dict(tests=123,failures=0,errors=0,skipped=0);native[label]=totals
checks={}
for name,expected in [('program',63),('protocol',9),('primitive',39),('cancel-drain',4)]:
 result=json.loads((b/'torch-iteration-559'/(name+'.log')).read_text().splitlines()[-1]);assert result['status']=='passed' and result['cases']==expected;checks[name]=dict(cases=expected,log_sha256=sha(b/'torch-iteration-559'/(name+'.log')))
for name,h in read(b/'torch-iteration-515/source-plan.json')['inputs'].items():assert sha(Path(name))==h,name
for name,h in read(b/'torch-iteration-511/live-export-sha256.json').items():assert sha(repo/'web/public/data'/name)==h,name
summary=dict(status='qualified_batched_resident_tensor_offload_session',canonical_runtime_version='0.83.0',native=native,repository_checks=read(b/'torch-iteration-559/result.json'),portable_checks=checks,actual_gpu=dict(browser=gpu['browser'],gpu_info=gpu['gpu_info'],worker=gpu['worker'],cases=51,controls=gpu['numerical']['controls'],final_cache=gpu['numerical']['final_cache'],host_disposals=gpu['host_disposals'],requests=gpu['requests_sent']),performance=performance,initial_resident_campaign=read(b/'torch-iteration-553/result.json'),initial_candidate_adopted=False,initial_regressions_preserved=True,transfer_trace=trace['numerical'],new_program_semantics='Only fresh uploaded inputs may be exported unread+retained; existing handles cannot be exported as second owners; per-computed-output retention is optional; all original limits and shader unchanged',cache_limits=dict(entries=8,bytes=8388608,shadow_data_bytes_bounded=True),memoizes_computed_results=False,readback_still_required=True,after_intentional_close_existing_graphs_use_cpu=True,public_gpu_tensor_storage=False,automatic_dispatch=False,canonical_resources_unchanged=66,public_sdk_sources_unchanged=93,active_export_identities_unchanged=183,package_inputs_unchanged=206,ci_triggered=False,tags_pushed=False,published=False,deployed=False,goal_status='active')
write(r/'result.json',summary)
files=[r/'aggregate.py',r/'result.json']
for stage in range(550,560):files.extend(p for p in (b/f'torch-iteration-{stage}').rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for stage in [550,551,552,554,555,556,558]:
 for name,h in read(b/f'torch-iteration-{stage}/source-plan.json')['files'].items():assert sha(b/f'torch-iteration-{stage}'/name)==h,(stage,name)
for name in ['torch_bridge.py','resident_bridge.py','matrix_client.py','plan-program.mjs','check-program.mjs','test_torch_bridge.py','test_resident_bridge.py','README.md']:
 target=r/'repository'/name;target.parent.mkdir(exist_ok=True);shutil.copy2(repo/'packages/stridetorch/benchmarks/webgpu_rpc'/name,target);files.append(target)
write(r/'replay-dependencies.json',dict(entrypoints=['554/test_base.py and test_resident.py for native checks','555/run-browser.mjs for GPU numerical/state/ownership checks','556/run-all.py for all six planned timing processes','558/run-browser.mjs for untimed transfer trace'],external=['Pyodide0.29.4/NumPy2.2.5 runtime assets at stage76; not included','Node22.22.1, Chrome155/Apple metal-3 and Playwright','Native Py3.12/NumPy2.5.4/Torch2.14.1 and Py3.10/NumPy1.26.4/Torch2.6','Adjust historical absolute paths before replay'],notes=['550/551/552/553 preserve the original correct but slower changing-weight candidate; no original individual flags removed','554/555/556/557 are the selected batched-retention candidate; both initial and final six-process campaigns retained','A sampled signature only filters; exact bits determine reuse. Six kernels execute in four program RPCs in every traced chain call','Warm upload bytes are zero in the traced chain, but 27064 data bytes are still read back; transfer figures exclude headers/uniforms','Session setup/close are outside timing; per-call evictions/uploads/cache logic/graph/copies are included','No default CPU/WASM/public device API, shader, quota, CI, tag, deployment or package publication change']))
files.append(r/'replay-dependencies.json');files=sorted(set(files));manifest={str(p.relative_to(b)):sha(p) for p in files};seen={};target=r/'resident-session-harness.tar.gz'
with tarfile.open(target,'w:gz') as stream:
 for p in files:
  name=str(p.relative_to(b));h=manifest[name]
  if h in seen:
   info=stream.gettarinfo(str(p),arcname=name);info.type=tarfile.LNKTYPE;info.linkname=seen[h];info.size=0;stream.addfile(info)
  else:stream.add(p,arcname=name,recursive=False);seen[h]=name
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256.json');info.size=len(data);stream.addfile(info,io.BytesIO(data))
with tarfile.open(target) as stream:
 for name,h in manifest.items():assert hashlib.sha256(stream.extractfile(name).read()).hexdigest()==h,name
receipt=dict(path='packages/stridetorch/benchmarks/results/'+target.name,sha256=sha(target),files=len(files),unique_payloads=len(seen),bytes=target.stat().st_size,all_payloads_verified=True);write(r/'archive-receipt.json',receipt);summary['raw_archive']=receipt
write(repo/'packages/stridetorch/benchmarks/results/resident-session.json',summary);shutil.copy2(target,repo/receipt['path']);print(json.dumps(receipt))
