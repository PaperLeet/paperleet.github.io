from pathlib import Path
import hashlib,io,json,subprocess,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
current=b/'torch-iteration-385';result=read(current/'result.json');assert result['status']=='passed_local_application_catalog_export_frontend_worker_gates'
assert result['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert len(read(repo/'web/package.json')['scripts']['check'].split(' && '))==204
for name,h in read(current/'static-inputs.json').items():assert sha(repo/name)==h,name
for receipt in read(current/'receipts.json'):
 assert receipt['exit_code']==0
 assert sha(current/(receipt['label']+'.log'))==receipt['log_sha256']
for name,h in read(b/'torch-iteration-366/source-plan.json')['inputs'].items():assert sha(Path(name))==h,name
for name,h in read(current/'live-export-sha256.json').items():assert sha(repo/'web/public/data'/name)==h,name
files=[]
for n in [368,378,379,384,385,387]:
 for p in (b/f'torch-iteration-{n}').rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and p.name!='archive-receipt.json':files.append(p)
manifest={str(p.relative_to(b)):sha(p) for p in sorted(files)}
destination=out/'qualification-0.81-main-sync-harness.tar.gz';assert not destination.exists()
with tarfile.open(destination,'w:gz') as stream:
 for p in sorted(files):stream.add(p,arcname=str(p.relative_to(b)),recursive=False)
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256.json');info.size=len(data);stream.addfile(info,io.BytesIO(data))
with tarfile.open(destination) as stream:
 for name,h in manifest.items():assert hashlib.sha256(stream.extractfile(name).read()).hexdigest()==h,name
receipt=dict(path=str(destination.relative_to(repo)),files=len(files),bytes=destination.stat().st_size,sha256=sha(destination),verified_all_payloads=True);write(r/'archive-receipt.json',receipt)
sync=dict(status='passed_current_main_ui_reconciliation',version='0.81.0',qualified_head=result['head'],incoming_main='3aa2c298f4d82192c7c6191d8319d659acadabca',full_frontend_commands=204,both_builds_passed=True,actual_chrome_worker_passed=True,unchanged_core_catalog_by_identity=True,metadata_refresh_still_current=True,application_result_sha256=sha(current/'result.json'),archive=receipt,prior_transport_attempts=dict(first='368:curl55Brokenpipe,remoteunchanged',second='379:terminatedverifiedobsoleteGittransportafterremoteadvanced;no workflow touched'),retained_harness_failure='384:omittedcatalog_modulescontextfield;failedbeforefrontend;fresh385restores89withunchangedassertions',main_adopted=False,ci_triggered=False,tags_pushed=False,published=False,deployed=False,goal_status='active');write(out/'qualification-0.81-main-sync.json',sync)
doc=repo/'docs/validation/torch-runtime-0.81-qualification.md'
doc.write_text(doc.read_text()+f'\n## Final comment-search main reconciliation\n\nUpstream main advanced to `3aa2c298f4d82192c7c6191d8319d659acadabca` during\nthe first upload retry. That ordinary transfer was stopped after verifying the\nexpected remote was obsolete; no workflow was cancelled. The new shared search,\nreply and card UI is merged at `{result["head"]}`.\nExperiment 385 passes the **entire current 204-command frontend check**, both\ncomplete builds, Pages/retention/generated-Worker gates and the actual Chrome\nWorker with the packed-route assertions. Core/catalog inputs and all 183 export\nidentities remain unchanged; final public metadata from 366 is still current.\nThe earlier 202-plus-15 scope above remains an accurate historical stage.\n\nExperiment 384 failed before frontend checks because its preparation omitted\nthe catalog-count context field. Fresh 385 supplies 89 to the unchanged verifier;\nthe original failure is retained. The first upload failed with curl 55 and left\nmain unchanged. Both transport attempts, audits, exact grants, the corrected\n204-command run and source manifests are in the\n[main-sync archive](../../{receipt["path"]}): {receipt["files"]} verified files,\n{receipt["bytes"]:,} bytes, SHA-256 `{receipt["sha256"]}`.\n[Machine-readable reconciliation](../../packages/stridetorch/benchmarks/results/qualification-0.81-main-sync.json).\n')
print(json.dumps(receipt),flush=True)
