from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');guard=b/'torch-iteration-368'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
assert not (guard/'qualification-grant.json').exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip()
aggregate=read(repo/'packages/stridetorch/benchmarks/results/qualification-0.81.json')
assert aggregate['status']=='passed_local_081_qualification_ready_for_guarded_main_adoption'
wrapper=b/'torch-iteration-67/final-integration/push-main-native.py'
assert sha(wrapper)=='4b51422c5533ca6177a4a29a557cf37d1c6727d7530908e444be5833588c2882'
archive=repo/aggregate['raw_archive']['path'];assert sha(archive)==aggregate['raw_archive']['sha256']
with tarfile.open(archive) as stream:manifest=json.load(stream.extractfile('sha256.json'))
for name,h in manifest.items():assert sha(b/name)==h,name
for name,h in read(b/'torch-iteration-366/source-plan.json')['inputs'].items():assert sha(Path(name))==h,name
changed=[name for name,h in read(b/'torch-iteration-374/static-inputs.json').items() if sha(repo/name)!=h]
assert changed==['packages/stridetorch/README.md'],changed
policy=read(guard/'release-policy-identity.json')['files']
for name,h in policy.items():assert sha(repo/name)==h,name
resources=aggregate['runtime_resources'];assert len(resources)==65
for name,h in resources.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==h,name
write(guard/'source-hashes.json',resources)
exports=read(b/'torch-iteration-374/live-export-sha256.json');assert len(exports)==183
for name,h in exports.items():assert sha(repo/'web/public/data'/name)==h,name
write(guard/'live-export-sha256.json',exports)
native=read(b/'torch-iteration-365/native-catalog-result.json');assert native['passed'] and native['tests_executed']==12360 and not native['issues']
worker=read(b/'torch-iteration-374/nested-wasm-result.json');assert worker['status']=='passed' and worker['page_errors']==[]
provenance=read(guard/'guard-provenance.json');provenance.update(audit_sha256=sha(guard/'audit-main.py'),runner_sha256=sha(guard/'run-guarded-push.py'),scope='0.81 exact final local qualification grant; same mandatory wrapper and release-chain guards')
write(guard/'guard-provenance.json',provenance)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
files=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0');reviewed={name:sha(repo/name) for name in files if name}
required=[dict(path=str(b/name),sha256=h) for name,h in manifest.items()]
for p in list(guard.glob('*.py'))+[guard/'guard-provenance.json',guard/'release-policy-identity.json',guard/'release-policy-variants.json',wrapper,b/'torch-iteration-377/archive-receipt.json']:
 required.append(dict(path=str(p),sha256=sha(p)))
grant=dict(head=head,source_resources=65,runtime_resources=resources,ci_triggered=False,version='0.81.0',local_qualification_complete=True,required_files=required,reviewed_commit_files=reviewed)
write(guard/'qualification-grant.json',grant)
write(r/'result.json',dict(status='prepared_exact_qualified_main_push_grant',head=head,tracked_files=len(reviewed),required_files=len(required),readme_only_delta_since_final_browser_check=True,public_metadata_current=True,main_adopted=False,ci_triggered=False,goal_status='active'))
print(json.dumps(dict(head=head,tracked_files=len(reviewed),required_files=len(required))))
