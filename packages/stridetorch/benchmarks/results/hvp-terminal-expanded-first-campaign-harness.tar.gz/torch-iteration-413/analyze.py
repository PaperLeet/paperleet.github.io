from pathlib import Path
import hashlib,json,statistics
r=Path(__file__).resolve().parent;b=r.parent;bench=b/'torch-iteration-410';campaign=b/'torch-iteration-412'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
terminal=read(campaign/'result.json');assert terminal['status']=='completed_all_planned_processes' and terminal['processes']==12
assert read(campaign/'progress.json')['status']=='completed'
config=read(bench/'config.json');runtime_reports={};failures=[]
for runtime in ['cpu25','cpu126','node','chrome']:
 processes=[];by_key={}
 for cycle in [0,1,2]:
  target=bench/f'latency-{runtime}-{cycle}.json';wrapper=read(target);report=wrapper.get('report',wrapper);assert report['cycle']==cycle and len(report['rows'])==32
  receipt=next(x for x in terminal['receipts'] if x['label']==f'{runtime}-{cycle}');assert receipt['exit_code']==0 and receipt['result_sha256']==sha(target)
  log=campaign/(runtime+'-'+str(cycle)+'.log');assert receipt['log_sha256']==sha(log)
  raw=[json.loads(line[11:]) for line in log.read_text().splitlines() if line.startswith('HVP_SAMPLE ')];assert raw==report['rows']
  for row in report['rows']:
   assert row['independent_owned_outputs'] and len(row['orders'])==12
   assert all(len(v)==12 for v in row['samples'].values())
   key=row['spec']['key'];by_key.setdefault(key,[]).append(row)
   if not row['aa_passed']:failures.append(dict(runtime=runtime,cycle=cycle,key=key,gate='aa',ratio=row['aa_ratio']))
   if row['candidate_ratio']>config['regression_threshold']:failures.append(dict(runtime=runtime,cycle=cycle,key=key,gate='candidate_regression',ratio=row['candidate_ratio']))
   if row['minimum_batch_seconds']<config['minimum_batch_seconds']:failures.append(dict(runtime=runtime,cycle=cycle,key=key,gate='minimum_batch',seconds=row['minimum_batch_seconds']))
  processes.append(dict(cycle=cycle,result_sha256=sha(target),log_sha256=sha(log),minimum_batch_seconds=receipt['minimum_batch_seconds'],numpy=report['numpy'],python=report['python'],browser=wrapper.get('browser'),pyodide=wrapper.get('pyodide')))
 rows=[]
 for key,values in sorted(by_key.items()):
  assert len(values)==3
  rows.append(dict(spec=values[0]['spec'],candidate_ratios=[x['candidate_ratio'] for x in values],candidate_median=statistics.median(x['candidate_ratio'] for x in values),aa_ratios=[x['aa_ratio'] for x in values]))
 assert len(rows)==32
 runtime_reports[runtime]=dict(processes=processes,rows=rows,by_kind={kind:dict(median_ratio_min=min(x['candidate_median'] for x in rows if x['spec']['kind']==kind),median_ratio_max=max(x['candidate_median'] for x in rows if x['spec']['kind']==kind)) for kind in sorted({x['spec']['kind'] for x in rows})})
memory={}
for runtime,path in [('cpu25',b/'torch-iteration-411/numpy25.json'),('cpu126',b/'torch-iteration-411/numpy126.json'),('node',bench/'memory-node-0.json'),('chrome',bench/'memory-chrome-0.json')]:
 wrapper=read(path);report=wrapper.get('report',wrapper);assert report['status']=='passed_tensor_context_and_array_lifetime_controls' and len(report['rows'])==32
 for row in report['rows']:
  for value in row['observations'].values():assert value['retained_tensors']==value['retained_tensor_backed_arrays']==value['retained_contexts']==0 and value['calls']==30
 rows=[]
 for row in report['rows']:
  a=row['observations']['A0'];v=row['observations']['B'];entry=dict(key=row['spec']['key'],baseline_nodes=a['node_constructions'],candidate_nodes=v['node_constructions'])
  if report['tracemalloc_enabled']:
   entry['baseline_peak_median']=statistics.median(x['peak_extra_bytes'] for x in a['native_peaks']);entry['candidate_peak_median']=statistics.median(x['peak_extra_bytes'] for x in v['native_peaks']);entry['extra_peak_bytes']=entry['candidate_peak_median']-entry['baseline_peak_median']
  rows.append(entry)
 memory[runtime]=dict(report_sha256=sha(path),calls=1920,retained_tracked_owners=0,rows=rows,tracemalloc_enabled=report['tracemalloc_enabled'],heap_capacity_before=wrapper.get('heap_capacity_before'),heap_capacity_after=wrapper.get('heap_capacity_after'))
result=dict(status='qualified_scoped_terminal_hvp_optimization' if not failures else 'needs_investigation',processes=12,flows=32,aa_controls=384,failures=failures,runtimes=runtime_reports,memory=memory,minimum_batch_seconds=terminal['minimum_batch_seconds'],raw_native_expanded_gate_passed=False,expanded_wasm_baseline_candidate_equal=True,retained_raw_native_difference='float32/finite_large/2.9/sin_out',chrome_sdk_passed=12212,native_sdk_passed=dict(numpy25=12225,numpy126=12222,numpy126_skipped=3),owned_copy_correction=config['owned_copy_correction'],limitations=['Threefreshprocessesperruntimeononehost;notallPyTorchprograms.','60msmeasuredtargetnotuniformlymet;20msminimumpredefined;allsamplesretained.','NativepeaksarenotbrowserRSS;WASMheapcapacityisretainedhighwater.','Newcandidateversion/package/application/export/mainintegrationnotyetqualified.'],source_plan_sha256=sha(bench/'source-plan.json'),campaign_result_sha256=sha(campaign/'result.json'),production_changed=False,ci_triggered=False,goal_status='active')
write(r/'result.json',result);print(json.dumps(dict(status=result['status'],failures=failures,minimum_batch_seconds=result['minimum_batch_seconds'],by_runtime={k:v['by_kind'] for k,v in runtime_reports.items()})),flush=True)
