"""Full detached HVP calls, shared by independent oracles and runtime timings."""
import itertools
import numpy as np


def specs():
    rows=[dict(n=n,dtype=dtype,kind=kind,strided=False)
          for n,dtype,kind in itertools.product([64,1024],['float32','float64'],
                                               ['norm_square','norm_sine','composed_norm'])]
    rows += [dict(n=64,dtype='float32',kind='polynomial',strided=False),
             dict(n=1024,dtype='float64',kind='polynomial',strided=False)]
    rows += [dict(n=64,dtype=dtype,kind=kind,strided=False)
             for dtype,kind in itertools.product(['float32','float64'],
                 ['axis','normalize','tuple','captured','barrier','discard','zero_norm'])]
    rows += [dict(n=n,dtype=dtype,kind='norm_square',strided=True)
             for n,dtype in itertools.product([64,1024],['float32','float64'])]
    assert len(rows)==32
    for row in rows:
        row['key']=f"{row['kind']}/{row['n']}/{row['dtype']}/"+('strided' if row['strided'] else 'dense')
    return rows


def arrays(spec):
    n=spec['n'];dtype=spec['dtype']
    raw=(np.arange(n)%19+1).astype(dtype)/32
    direction=((np.arange(n)%7)-3).astype(dtype)/8
    if spec['strided']:
        storage=np.empty(n*2,dtype=dtype);storage[::2]=raw;storage[1::2]=-7
        raw=storage[::2]
    if spec['kind'] in ['axis','normalize']:
        raw=raw.reshape(8,8);direction=direction.reshape(8,8)
    other=np.ascontiguousarray(raw[::-1]);other_direction=np.ascontiguousarray(-direction[::-1])
    coefficient=(np.arange(n)%5+1).astype(dtype)/8
    for value in [raw,direction,other,other_direction,coefficient]:value.setflags(write=False)
    return raw,direction,other,other_direction,coefficient


def setup(api,spec,data):
    raw,direction,other,other_direction,coefficient=data
    x=api.from_numpy(raw).requires_grad_(True);v=api.from_numpy(direction)
    inputs=[x];vectors=[v]
    if spec['kind']=='tuple':
        inputs.append(api.from_numpy(other).requires_grad_(True));vectors.append(api.from_numpy(other_direction))
    captured=api.from_numpy(coefficient).requires_grad_(True) if spec['kind']=='captured' else None
    owners=[*inputs,*([captured] if captured is not None else [])]
    buffers=[]
    for value in owners:value.grad=api.full_like(value,9.);buffers.append(value.grad)
    args=tuple(inputs) if len(inputs)>1 else inputs[0]
    seeds=tuple(vectors) if len(vectors)>1 else vectors[0]
    def function(a,*rest):
        kind=spec['kind']
        if kind=='polynomial':return (a.sin()*a).sum()
        if kind=='norm_square':return api.linalg.vector_norm(a).square()
        if kind=='norm_sine':return api.linalg.vector_norm(a,ord=2.9).sin()
        if kind=='composed_norm':return api.linalg.vector_norm(a.sin()+.5,ord=1.5).square()
        if kind=='axis':return api.linalg.vector_norm(a,dim=-1,keepdim=True).square().sum()
        if kind=='normalize':return (a/(api.linalg.vector_norm(a,ord=1.5,dim=-1,keepdim=True)+.5)).square().sum()
        if kind=='tuple':return api.linalg.vector_norm(a*rest[0]+.25,ord=2.9).square()+.125*a.square().sum()
        if kind=='captured':return api.linalg.vector_norm(a*captured+.25).square()
        if kind=='zero_norm':return api.linalg.vector_norm(a,ord=0).square()
        if kind=='barrier':
            with api.no_grad():constant=api.linalg.vector_norm(a)
            return (a.sin()*a).sum()+constant
        if kind=='discard':
            api.linalg.vector_norm(a)
            return (a.sin()*a).sum()
        raise AssertionError(kind)
    def invoke():
        value,product=api.autograd.functional.hvp(function,args,seeds)
        products=product if isinstance(product,tuple) else (product,)
        result=(value,*products)
        assert all(not item.requires_grad for item in result)
        assert all(item.grad is saved for item,saved in zip(owners,buffers))
        assert api.is_grad_enabled()
        # Include owned output copies in every measured full call.
        return tuple(item.detach().cpu().numpy().copy() for item in result)
    def check_state():
        assert all(item.grad is saved for item,saved in zip(owners,buffers))
        for item in buffers:np.testing.assert_array_equal(item.numpy(),np.full(item.shape,9.,dtype=spec['dtype']))
        for actual,initial in [(x.detach().numpy(),raw),*([(inputs[1].detach().numpy(),other)] if len(inputs)>1 else [])]:np.testing.assert_array_equal(actual,initial)
    return invoke,check_state


def packed(values):
    return [dict(shape=list(value.shape),dtype=str(value.dtype),values=value.reshape(-1).tolist()) for value in values]


def compare(values,reference,dtype):
    assert len(values)==len(reference)
    for value,row in zip(values,reference):
        assert list(value.shape)==row['shape'] and str(value.dtype)==row['dtype']
        expected=np.asarray(row['values'],dtype=row['dtype']).reshape(row['shape'])
        np.testing.assert_allclose(value,expected,rtol=5e-5 if dtype=='float32' else 3e-11,
                                   atol=2e-6 if dtype=='float32' else 1e-12,equal_nan=True)
