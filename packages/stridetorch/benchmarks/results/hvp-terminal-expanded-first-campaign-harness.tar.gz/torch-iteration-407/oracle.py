from pathlib import Path
import hashlib,json
import numpy as np
import torch
from workloads import specs,arrays,setup,packed
r=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((r/'source-plan.json').read_text())
for name,h in plan['files'].items():assert sha(r/name)==h,name
assert torch.__version__=='2.6.0'
rows=[]
for spec in specs():
 invoke,check=setup(torch,spec,arrays(spec));values=invoke();check()
 rows.append(dict(spec=spec,outputs=packed(values)))
record=dict(status='passed_native26_oracles',torch=torch.__version__,numpy=np.__version__,rows=rows,
            workloads_sha256=sha(r/'workloads.py'),source_plan_sha256=sha(r/'source-plan.json'))
(r/'native26.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print('native oracles',len(rows),flush=True)
