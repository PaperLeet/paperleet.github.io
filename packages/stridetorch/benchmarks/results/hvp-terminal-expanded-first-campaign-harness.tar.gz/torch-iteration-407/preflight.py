from pathlib import Path
import argparse,hashlib,importlib.util,json,sys
import numpy as np
from workloads import specs,arrays,setup,compare,packed
r=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(label,variant):
 path=r/variant/'stridetorch';name='_hvp407_'+label
 spec=importlib.util.spec_from_file_location(name,path/'__init__.py',submodule_search_locations=[str(path)])
 module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
 plan=json.loads((r/'source-plan.json').read_text())
 for name,h in plan['files'].items():assert sha(r/name)==h,name
 reference=json.loads((r/'native26.json').read_text());assert reference['workloads_sha256']==sha(r/'workloads.py')
 modules={label:load(label,variant) for label,variant in [('A0','baseline'),('A1','baseline'),('B','candidate')]}
 rows=[]
 for spec,ref in zip(specs(),reference['rows']):
  assert spec==ref['spec'];data=arrays(spec);baseline=None;outputs={}
  for label,module in modules.items():
   invoke,check=setup(module.torch,spec,data);values=invoke();check();compare(values,ref['outputs'],spec['dtype'])
   if baseline is None:baseline=values
   else:
    assert len(values)==len(baseline)
    for value,expected in zip(values,baseline):assert value.dtype==expected.dtype and value.shape==expected.shape and value.tobytes()==expected.tobytes(),(spec['key'],label)
   outputs[label]=packed(values)
  rows.append(dict(spec=spec,outputs=outputs))
 assert len(rows)==32
 record=dict(status='passed_independent_native_and_exact_baseline_preflight',rows=rows,numpy=np.__version__,python=sys.version,source_plan_sha256=sha(r/'source-plan.json'),native_reference_sha256=sha(r/'native26.json'))
 args.output.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print('preflight',np.__version__,len(rows),flush=True)
if __name__=='__main__':main()
