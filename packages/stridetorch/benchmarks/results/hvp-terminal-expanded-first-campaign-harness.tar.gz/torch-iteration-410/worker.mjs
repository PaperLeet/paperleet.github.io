import {execute} from './execute.mjs';
self.onmessage=async({data:{mode,cycle}})=>{
 try{
  const plan=await(await fetch('./source-plan.json')).json();
  const result=await execute(mode,cycle,plan,async item=>{
   const response=await fetch(item.source);if(!response.ok)throw Error('Missing '+item.source);
   const bytes=new Uint8Array(await response.arrayBuffer());
   const actual=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),v=>v.toString(16).padStart(2,'0')).join('');
   if(actual!==item.sha256)throw Error('Changed '+item.source);return bytes;
  },message=>self.postMessage({status:'diagnostic',message}));
  self.postMessage({status:'completed',...result});
 }catch(error){self.postMessage({status:'failed',error:String(error.stack||error)});}
};
