from pathlib import Path
import hashlib,io,json,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
study=read(b/'torch-iteration-413/result.json');assert study['status']=='needs_investigation' and len(study['failures'])==5
assert read(b/'torch-iteration-412/result.json')['processes']==12
assert not (b/'torch-iteration-416/progress.json').exists()
dependency=out/'qualification-0.81-data-followup-harness.tar.gz'
write(r/'replay-dependencies.json',dict(existing_oracle_archive=dict(path=str(dependency.relative_to(repo)),sha256=sha(dependency),members='torch-iteration-394: original4480probe/comparers/native26/native214/compositionreferences'),external_runtime_requirements=['Python3.12/NumPy2.5.4','Python3.10/NumPy1.26.4/Torch2.6.0','Node22.22.1','Chrome155.0.8059.82','Pyodide0.29.4/NumPy2.2.5 and pinned76SDKloader/packages','Pathadaptationrequiredforlocalenvironmentandbrowserexecutables'],scope='Currentarchivecontainsallnewrawoutputs,all32fixtures,isolatedsources,timings,memoryandunlaunchedprecisionplans;olderindependentoraclesareinlinkedexistingarchive.'))
files=[p for n in [407,408,409,410,411,412,413,414,415,416,418] for p in (b/f'torch-iteration-{n}').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='archive-receipt.json']
manifest={str(p.relative_to(b)):sha(p) for p in files};destination=out/'hvp-terminal-expanded-first-campaign-harness.tar.gz';assert not destination.exists();seen={}
with tarfile.open(destination,'w:gz') as stream:
 for p in sorted(files):
  name=str(p.relative_to(b));h=manifest[name]
  if h in seen:
   info=stream.gettarinfo(str(p),arcname=name);info.type=tarfile.LNKTYPE;info.linkname=seen[h];info.size=0;stream.addfile(info)
  else:stream.add(p,arcname=name,recursive=False);seen[h]=name
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256.json');info.size=len(data);stream.addfile(info,io.BytesIO(data))
with tarfile.open(destination) as stream:
 for name,h in manifest.items():assert hashlib.sha256(stream.extractfile(name).read()).hexdigest()==h,name
receipt=dict(path=str(destination.relative_to(repo)),files=len(files),unique_payloads=len(seen),bytes=destination.stat().st_size,sha256=sha(destination),verified_all_payloads=True);write(r/'archive-receipt.json',receipt)
result=dict(study,raw_archive=receipt,precision_followup=dict(stage=416,planned_processes=6,all_cases=32,status='prespecified_not_launched_at_archive_time',config=read(b/'torch-iteration-415/config.json')),replay_dependencies=read(r/'replay-dependencies.json'));write(out/'hvp-terminal-expanded-first-campaign.json',result)
doc=repo/'docs/validation/torch-runtime-hvp-terminal-values-expanded.md';doc.write_text(doc.read_text()+f'\n[Machine-readable first campaign](../../packages/stridetorch/benchmarks/results/hvp-terminal-expanded-first-campaign.json)\nand [verified raw archive](../../{receipt["path"]}):\n{receipt["files"]} files ({receipt["unique_payloads"]} unique payloads, internal\ntar hard links for identical bytes), {receipt["bytes"]:,} bytes, SHA-256\n`{receipt["sha256"]}`. The replay-dependency manifest links the retained original\nnative oracles in the existing 0.81 data-follow-up archive; external runtime\ndependencies and original absolute paths need adaptation. The precision source\nand plans are included before any precision-run output exists.\n')
print(json.dumps(receipt),flush=True)
