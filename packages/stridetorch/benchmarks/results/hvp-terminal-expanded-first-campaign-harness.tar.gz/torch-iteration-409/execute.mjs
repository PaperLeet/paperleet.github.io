import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
export async function execute(variant,plan,read,diagnostic){
 const url=new URL('../torch-iteration-76/runtime/',import.meta.url);
 const py=await loadPyodide({indexURL:url.protocol==='file:'?decodeURIComponent(url.pathname):url.href,stdout:diagnostic,stderr:diagnostic});
 await py.loadPackage('numpy');py.runPython('import sys;sys.dont_write_bytecode=True');
 const payload={...plan.common,...plan.variants[variant]};
 for(const [name,item] of Object.entries(payload)){
  const bytes=await read(item);
  py.FS.mkdirTree('/'+name.split('/').slice(0,-1).join('/'));py.FS.writeFile('/'+name,bytes);
 }
 const report=JSON.parse(py.runPython("import runpy,json;result=runpy.run_path('/check.py')['result'];json.dumps(result)"));
 return {...report,pyodide:py.version};
}
