from pathlib import Path
import hashlib,json,os,subprocess,time,traceback
r=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
plan=read(r/'campaign-plan.json');assert sha(Path(__file__))==plan['runner_sha256'];assert sha(r/'source-plan.json')==plan['source_plan_sha256']
receipts=[]
try:
 for runtime in ['node','chrome']:
  for variant in ['baseline','candidate']:
   label=runtime+'-'+variant;args=[plan['node'],str(r/'run.mjs'),runtime,variant]
   with (r/(label+'.log')).open('w') as log:
    child=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT)
    write(r/'progress.json',dict(status='running',pid=os.getpid(),child_pid=child.pid,label=label,receipts=receipts));print('running',label,child.pid,flush=True);code=child.wait()
   receipt=dict(label=label,exit_code=code,log_sha256=sha(r/(label+'.log')));receipts.append(receipt);write(r/'receipts.json',receipts);assert code==0,receipt
  baseline=read(r/(runtime+'-baseline.json'));candidate=read(r/(runtime+'-candidate.json'))
  assert (r/(runtime+'-baseline-raw-hvp.json')).read_bytes()==(r/(runtime+'-candidate-raw-hvp.json')).read_bytes(),runtime
  assert baseline['native_comparison']==candidate['native_comparison']
  for version,counts in candidate['native_comparison']['counts'].items():assert counts['matched']==4479 and counts['mismatched']==1,(runtime,version,counts)
  assert {x['key'] for x in candidate['native_comparison']['findings']}=={'float32/finite_large/2.9/sin_out'}
 result=dict(status='passed_no_new_discrepancy_with_retained_raw_native_failure',runtime_cases=4480,node_baseline_candidate_byte_identical=True,chrome_baseline_candidate_byte_identical=True,raw_native_gate_passed=False,retained_difference='float32/finite_large/2.9/sin_out',receipts=receipts,production_changed=False,ci_triggered=False,goal_status='active')
 write(r/'result.json',result);write(r/'progress.json',dict(status='completed'));print(json.dumps(result),flush=True)
except BaseException as error:write(r/'progress.json',dict(status='failed',error=str(error),traceback=traceback.format_exc(),receipts=receipts));raise
