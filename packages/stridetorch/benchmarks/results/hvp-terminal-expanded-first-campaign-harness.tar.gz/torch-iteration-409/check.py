from pathlib import Path
import json,runpy,sys
sys.dont_write_bytecode=True
assert sys.platform=='emscripten'
runpy.run_path('/run-observed-probe.py',run_name='__main__')
runpy.run_path('/compare-hvp-boundaries.py',run_name='__main__')
import stridetorch
assert stridetorch.__file__=='/prototype/stridetorch/__init__.py'
result=dict(raw_hvp_json=Path('/hvp-prototype.json').read_text(),
            native_comparison=json.loads(Path('/hvp-comparison.json').read_text()),
            paths=json.loads(Path('/path-observations.json').read_text()),
            numpy=__import__('numpy').__version__,source_version=stridetorch.__version__,
            raw_native_gate_passed=False)
