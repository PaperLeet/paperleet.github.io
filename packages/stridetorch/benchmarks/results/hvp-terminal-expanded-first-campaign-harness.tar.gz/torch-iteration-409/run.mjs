import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {withFixtureServer} from '../torch-iteration-70/fixture-server.mjs';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import {execute} from './execute.mjs';
const root=new URL('./',import.meta.url),runtime=process.argv[2],variant=process.argv[3];
assert(['node','chrome'].includes(runtime)&&['baseline','candidate'].includes(variant));
const label=runtime+'-'+variant,hash=bytes=>createHash('sha256').update(bytes).digest('hex');
assert(!fs.existsSync(new URL(label+'.json',root)));
const plan=JSON.parse(fs.readFileSync(new URL('source-plan.json',root)));
const bytes=item=>fs.readFileSync(new URL(item.source,root));
function verify(){
 for(const [name,h] of Object.entries(plan.files))assert.equal(hash(fs.readFileSync(new URL(name,root))),h,name);
 for(const item of Object.values({...plan.common,...plan.variants[variant]}))assert.equal(hash(bytes(item)),item.sha256,item.source);
}
verify();let report,browserVersion;
try{
 if(runtime==='node')report=await execute(variant,plan,async item=>bytes(item),console.log);
 else await withFixtureServer(async origin=>{
  let browser;
  try{
   browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});browserVersion=browser.version();
   const page=await browser.newPage();await page.goto(origin+'/torch-iteration-409/index.html');
   const message=await page.evaluate(variant=>new Promise((resolve,reject)=>{
    const worker=new Worker('./worker.mjs',{type:'module'}),timer=setTimeout(()=>{worker.terminate();reject(Error('Corpus deadline360s'));},360000);
    worker.onmessage=({data})=>{if(data.status==='diagnostic')return;clearTimeout(timer);worker.terminate();resolve(data);};
    worker.onerror=event=>{clearTimeout(timer);worker.terminate();reject(Error(event.message));};worker.postMessage({variant});
   }),variant);
   assert.equal(message.status,'completed',JSON.stringify(message));report=message.report;
  }finally{if(browser)await browser.close();}
 });
 verify();fs.writeFileSync(new URL(label+'-raw-hvp.json',root),report.raw_hvp_json);delete report.raw_hvp_json;
 fs.writeFileSync(new URL(label+'.json',root),JSON.stringify({...report,runtime,variant,browser:browserVersion,node:process.version,source_plan_sha256:hash(fs.readFileSync(new URL('source-plan.json',root)))},null,2)+'\n');
 assert.equal(report.paths.selections.three_reverse,4480);assert.deepEqual(report.paths.missing_rules,{});assert.equal(report.paths.context_restored,true);
 console.log(JSON.stringify({runtime,variant,native_counts:report.native_comparison.counts,raw_native_gate_passed:false}));
}catch(error){fs.writeFileSync(new URL(label+'-failure.json',root),JSON.stringify({error:String(error.stack||error)},null,2)+'\n');throw error;}
