"""Separate uninstrumented native peaks and instrumented Tensor-owner lifetimes."""
from pathlib import Path
import argparse,gc,hashlib,importlib,inspect,json,sys,weakref
import numpy as np
parser=argparse.ArgumentParser();parser.add_argument('--source-root',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--no-tracemalloc',action='store_true');args=parser.parse_args()
source=args.source_root.resolve();sys.path.insert(0,str(source))
from workloads import specs,arrays,setup,compare
from preflight import load
reference=json.loads((source/'native26.json').read_text());assert hashlib.sha256((source/'workloads.py').read_bytes()).hexdigest()==reference['workloads_sha256']
modules={label:load('memory_'+label,'candidate' if label=='B' else 'baseline') for label in ['A0','B']};rows=[]
for spec,ref in zip(specs(),reference['rows']):
 data=arrays(spec);observations={}
 for label,module in modules.items():
  invoke,check=setup(module.torch,spec,data)
  for _ in range(3):values=invoke();compare(values,ref['outputs'],spec['dtype'])
  assert all(x.flags.owndata and x.base is None for x in values);del values;gc.collect()
  peaks=[]
  if not args.no_tracemalloc:
   import tracemalloc
   for _ in range(3):
    gc.collect();tracemalloc.start();before,_=tracemalloc.get_traced_memory()
    values=invoke();current,peak=tracemalloc.get_traced_memory();output_bytes=sum(x.nbytes for x in values);del values;gc.collect();after,_=tracemalloc.get_traced_memory();tracemalloc.stop()
    peaks.append(dict(peak_extra_bytes=peak-before,after_release_extra_bytes=after-before,held_output_extra_bytes=current-before,owned_output_bytes=output_bytes))
  tensor=importlib.import_module(module.__name__+'._tensor');graph=importlib.import_module(module.__name__+'._graph');higher=importlib.import_module(module.__name__+'._higher_order');state=importlib.import_module(module.__name__+'._state')
  closure=inspect.getclosurevars(invoke).nonlocals
  fixed=[]
  for key in ['owners','buffers','args','seeds']:
   value=closure[key];fixed.extend(value if isinstance(value,(tuple,list)) else [value])
  fixed_ids=set()
  for value in fixed:
   data_array=value._data
   while isinstance(data_array,np.ndarray):fixed_ids.add(id(data_array));data_array=data_array.base
  tensor_refs=[];array_refs=[];context_refs=[];clear_counts=[];nodes=[0]
  original_tensor=tensor.Tensor.__init__;original_node=graph.Node.__init__;original_context=higher.Context.__init__;original_clear=higher.Context.clear
  def track_tensor(self,*a,**kw):
   original_tensor(self,*a,**kw);tensor_refs.append(weakref.ref(self));array_refs.append(weakref.ref(self._data))
  def track_node(self,*a,**kw):nodes[0]+=1;original_node(self,*a,**kw)
  def track_context(self,*a,**kw):original_context(self,*a,**kw);context_refs.append(weakref.ref(self))
  def track_clear(self):
   before=(len(self.rules),len(self.pending),len(self.owners));original_clear(self);assert not self.rules and not self.pending and not self.owners;clear_counts.append(before)
  tensor.Tensor.__init__=track_tensor;graph.Node.__init__=track_node;higher.Context.__init__=track_context;higher.Context.clear=track_clear
  try:
   for _ in range(30):values=invoke()
   assert all(x.flags.owndata and x.base is None for x in values);del values
  finally:tensor.Tensor.__init__=original_tensor;graph.Node.__init__=original_node;higher.Context.__init__=original_context;higher.Context.clear=original_clear
  gc.collect();check()
  live_tensors=sum(x() is not None for x in tensor_refs)
  live_arrays=sum(x() is not None and id(x()) not in fixed_ids for x in array_refs)
  live_contexts=sum(x() is not None for x in context_refs)
  assert live_tensors==live_arrays==live_contexts==0,(spec['key'],label,live_tensors,live_arrays,live_contexts)
  assert len(clear_counts)==30 and state._tensor_reverse_context is None and state._grad_enabled
  observations[label]=dict(native_peaks=peaks,node_constructions=nodes[0],calls=30,tensor_creations=len(tensor_refs),context_clear_sizes=clear_counts,retained_tensors=live_tensors,retained_tensor_backed_arrays=live_arrays,retained_contexts=live_contexts)
 rows.append(dict(spec=spec,observations=observations))
 print('MEMORY_FLOW '+spec['key'],flush=True)
report=dict(status='passed_tensor_context_and_array_lifetime_controls',rows=rows,numpy=np.__version__,python=sys.version,platform=sys.platform,tracemalloc_enabled=not args.no_tracemalloc,scope='UninstrumentednativeCPythontracemallocpeaksseparatefrominstrumented30callTensor-backedarray/contextweakrefs;notRSSornativereferenceindependenttiming;fixedinputarraysareexplicitlyexcluded')
args.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
