# Next core API investigation: training gradient utilities

Static inspection of the qualified 0.81 source at 60e2d2e3 finds no
`torch.nn.utils`, `torch.nn.utils.clip_grad`, `clip_grad_norm_` or
`clip_grad_value_` registration. Existing ordinary training scripts commonly use
these entry points; they are a concrete compatibility gap beyond the HVP work.
No new clipping implementation is enabled by this note.

The installed, read-only Torch 2.6 `torch/nn/utils/clip_grad.py` is the primary
reference for a later independent implementation and oracle probe. Important
behaviors to verify before implementation:

- A Tensor parameter and a single-use generator both work; missing gradients
  are filtered, without replacing existing gradient buffers or model Parameters.
- Total norm is a norm of per-gradient norms, not an assumed flat-vector shortcut.
  This matters for zero/negative orders, mixed dtypes and nonfinite values.
- Nonfinite rejection happens before scaling; the non-error route preserves
  IEEE behavior. Native clipping uses a 1e-6 denominator term and clamps the
  coefficient at one. Negative/NaN/Inf max-norm inputs need observations.
- Duplicate Parameters, overlapping gradient views, gradient identity and
  saved-storage version invalidation need independent native controls.
- All mutations run without constructing an AD graph and restore caller gradient
  mode. Existing gradients may themselves have history or require gradients.
- Observe empty/no-gradient and complex/value-clipping behavior, rather than
  assuming permissive behavior. Decide and document any explicit boundary.
- Check `foreach=None`, `False` and `True`; do not claim a native foreach or GPU
  backend for a scalar-loop implementation.
- Register both direct attributes and unchanged import aliases, and test native
  Torch cache restoration after scoped aliases.

The owned latency campaign remains serial and isolated. No clipping oracle or
functional tests run during its measurement window. This is the next coverage
investigation after the terminal-HVP candidate is evaluated and integrated.
