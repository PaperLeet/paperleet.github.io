import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {withFixtureServer} from '../torch-iteration-70/fixture-server.mjs';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import {execute} from './execute.mjs';
const root=new URL('./',import.meta.url),runtime=process.argv[2],mode=process.argv[3],cycle=Number(process.argv[4]);
assert(['node','chrome'].includes(runtime)&&['memory','latency'].includes(mode)&&[0,1,2].includes(cycle));
const label=mode+'-'+runtime+'-'+cycle,hash=bytes=>createHash('sha256').update(bytes).digest('hex');
assert(!fs.existsSync(new URL(label+'.json',root)));
const plan=JSON.parse(fs.readFileSync(new URL('source-plan.json',root)));
const bytes=item=>fs.readFileSync(new URL(item.source,root));
function verify(){
 for(const [name,h] of Object.entries(plan.files))assert.equal(hash(fs.readFileSync(new URL(name,root))),h,name);
 for(const item of Object.values(plan.payload))assert.equal(hash(bytes(item)),item.sha256,item.source);
 for(const item of plan.prerequisites)assert.equal(hash(bytes(item)),item.sha256,item.source);
}
verify();let result,browserVersion;
try{
 if(runtime==='node')result={status:'completed',...await execute(mode,cycle,plan,async item=>bytes(item),console.log)};
 else await withFixtureServer(async origin=>{
  let browser;
  try{
   browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});browserVersion=browser.version();
   const page=await browser.newPage();page.on('console',event=>console.log(event.text()));await page.goto(origin+'/torch-iteration-415/index.html');
   result=await page.evaluate(({mode,cycle})=>new Promise((resolve,reject)=>{
    const worker=new Worker('./worker.mjs',{type:'module'}),timer=setTimeout(()=>{worker.terminate();reject(Error('Measurement deadline600s'));},600000);
    worker.onmessage=({data})=>{if(data.status==='diagnostic'){console.log(data.message);return;}clearTimeout(timer);worker.terminate();resolve(data);};
    worker.onerror=event=>{clearTimeout(timer);worker.terminate();reject(Error(event.message));};worker.postMessage({mode,cycle});
   }),{mode,cycle});
  }finally{if(browser)await browser.close();}
 });
 verify();fs.writeFileSync(new URL(label+'.json',root),JSON.stringify({...result,runtime,mode,cycle,browser:browserVersion,node:process.version,source_plan_sha256:hash(fs.readFileSync(new URL('source-plan.json',root)))},null,2)+'\n');
 assert.equal(result.status,'completed',JSON.stringify(result));assert.equal(result.report.rows.length,32);
 if(mode==='latency')assert.equal(result.report.status,'completed');
 else assert.equal(result.report.status,'passed_tensor_context_and_array_lifetime_controls');
 console.log(JSON.stringify({status:'completed',label,rows:32,browser:browserVersion}));
}catch(error){fs.writeFileSync(new URL(label+'-failure.json',root),JSON.stringify({error:String(error.stack||error)},null,2)+'\n');throw error;}
