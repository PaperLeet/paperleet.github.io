"""Balanced A/A/B full public HVP calls, including independent owned outputs."""
from pathlib import Path
import argparse,gc,hashlib,importlib.util,itertools,json,math,statistics,sys,time
import numpy as np

parser=argparse.ArgumentParser();parser.add_argument('--source-root',type=Path,required=True);parser.add_argument('--config',type=Path,required=True);parser.add_argument('--cycle',type=int,required=True);parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args();source=args.source_root.resolve();sys.path.insert(0,str(source))
from workloads import specs,arrays,setup,compare
config=json.loads(args.config.read_text());reference=json.loads((source/'native26.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(source/'workloads.py')==reference['workloads_sha256']
assert args.cycle in [0,1,2] and len(specs())==config['flows']==32
def load(label,variant):
 path=source/variant/'stridetorch';name='_hvp410_'+label
 spec=importlib.util.spec_from_file_location(name,path/'__init__.py',submodule_search_locations=[str(path)]);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
modules={label:load(label,'candidate' if label=='B' else 'baseline') for label in ['A0','A1','B']}
orders=list(itertools.permutations(modules));rotation=args.cycle%len(orders);orders=orders[rotation:]+orders[:rotation];orders+=list(reversed(orders))
rows=[]
pairs=list(zip(specs(),reference['rows']));offset=(args.cycle*11)%len(pairs);pairs=pairs[offset:]+pairs[:offset]
for spec,ref in pairs:
 assert spec==ref['spec'];data=arrays(spec);calls={};state_checks={};baseline=None
 for label,module in modules.items():
  invoke,check=setup(module.torch,spec,data);values=invoke();check();compare(values,ref['outputs'],spec['dtype'])
  assert all(value.flags.owndata and value.base is None for value in values)
  if baseline is None:baseline=values
  else:
   for actual,wanted in zip(values,baseline):assert actual.dtype==wanted.dtype and actual.shape==wanted.shape and actual.tobytes()==wanted.tobytes(),(spec['key'],label)
  warm_started=time.perf_counter()
  while time.perf_counter()-warm_started<config['warmup_seconds']:invoke()
  calls[label]=invoke;state_checks[label]=check
 del values,baseline
 enabled=gc.isenabled();gc.disable();samples={label:[] for label in modules};calibration={};count_candidates=[]
 try:
  labels=list(modules);labels=labels[args.cycle:]+labels[:args.cycle]
  for label in labels:
   count=1;attempts=[]
   while True:
    started=time.perf_counter()
    for _ in range(count):calls[label]()
    elapsed=time.perf_counter()-started;attempts.append(dict(iterations=count,seconds=elapsed))
    if elapsed>=config['calibration_seconds'] or count>=config['iteration_cap']:break
    count=min(count*2,config['iteration_cap'])
   calibration[label]=attempts
   count_candidates.append(min(config['iteration_cap'],max(1,math.ceil(count*config['target_batch_seconds']/elapsed))))
  count=max(count_candidates)
  for order in orders:
   for label in order:
    started=time.perf_counter()
    for _ in range(count):calls[label]()
    elapsed=time.perf_counter()-started
    samples[label].append(dict(iterations=count,batch_seconds=elapsed,seconds_per_call=elapsed/count,started_seconds=started,ended_seconds=started+elapsed))
 finally:
  if enabled:gc.enable()
 for check in state_checks.values():check()
 medians={label:statistics.median(sample['seconds_per_call'] for sample in values) for label,values in samples.items()}
 paired_aa=statistics.median(y['seconds_per_call']/x['seconds_per_call'] for x,y in zip(samples['A0'],samples['A1']))
 paired_candidate=statistics.median(y['seconds_per_call']/x['seconds_per_call'] for x,y in zip(samples['A0'],samples['B']))
 row=dict(spec=spec,count=count,orders=orders,calibration=calibration,samples=samples,medians=medians,aa_ratio=medians['A1']/medians['A0'],candidate_ratio=medians['B']/medians['A0'],aa_passed=(1-config['aa_tolerance']<=medians['A1']/medians['A0']<=1+config['aa_tolerance'] and 1-config['aa_tolerance']<=paired_aa<=1+config['aa_tolerance']),paired_aa_ratio=paired_aa,paired_candidate_ratio=paired_candidate,minimum_batch_seconds=min(x['batch_seconds'] for values in samples.values() for x in values),independent_owned_outputs=True)
 rows.append(row);print('HVP_SAMPLE '+json.dumps(row),flush=True)
report=dict(status='completed',cycle=args.cycle,rows=rows,config=config,config_sha256=sha(args.config),workloads_sha256=sha(source/'workloads.py'),native_reference_sha256=sha(source/'native26.json'),numpy=np.__version__,python=sys.version,platform=sys.platform,scope='WholepublicHVP+detachedCPUviews+explicitindependentownedcopies;all32nativeoracleandbaselinepreflightsretained;noview-onlypilotcomparison')
args.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
