from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,tarfile
p=Path(__file__).resolve().parent;r=p.parent;raw=r/'webgpu-rpc';repo=Path('/Users/david/Developer/PaperLeet-torch-release')
read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
save=lambda q,d:q.write_text(json.dumps(d,indent=2)+'\n')
context=read(p/'context.json');qualification=read(raw/'browser-result.json');formal=read(raw/'performance/summary.json');life=read(raw/'real-lifecycle-result.json')
assert formal['status']=='completed' and formal['fresh_children']==36
for name,digest in formal['source_sha256'].items():assert sha(raw/name)==digest
for result in [qualification,life]:
    assert result['status']=='passed'
    for name,digest in result['source_sha256'].items():assert sha(raw/name)==digest
for name,digest in context['runtime_source_hashes'].items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==digest
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==context['upstream']
assert not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=repo)
for name,digest in read(p/'copied-source-sha256.json').items():assert sha(repo/name)==digest
policy=read(p/'release-policy-identity.json')
for group in [policy['files'],policy['workflows']]:
    for name,digest in group.items():assert sha(repo/name)==digest
for name,digest in read(p/'live-export-sha256.json').items():assert sha(repo/'web/public/data'/name)==digest
checks={}
for name in ['package-check','wheel-check']:
    receipt=read(p/(name+'-receipt.json'));assert receipt['exit_code']==0 and sha(p/(name+'.log'))==receipt['log_sha256']
    matches=re.findall(r'(\d+) passed',(p/(name+'.log')).read_text());assert len(matches)==1
    checks[name]=dict(receipt,passed=int(matches[0]))
protocol=read(p/'protocol-main-result.json');assert protocol['status']=='passed' and protocol['cases']==9
for name,digest in protocol['source_sha256'].items():assert sha(repo/'packages/stridetorch/benchmarks/webgpu_rpc'/name)==digest
assert all(row['disposal']['stats']['total_bytes']==0 and row['disposal']['stats']['closed'] for row in life['rows'])
minimum={};undersized=0;profiles=[]
for case in formal['rows']:
    samples=[]
    for cycle in range(6):
        q=raw/'performance/results'/(case['case']['name']+'-'+str(cycle)+'.json');result=read(q)
        assert result['status']=='passed' and result['benchmark']['status']=='passed'
        assert result['launch']==dict(headless=True,extra_flags=[])
        for name,digest in result['source_sha256'].items():assert sha(raw/name)==digest
        assert all(v['stats']['total_bytes']==0 and v['stats']['closed'] for v in result['host_disposals'])
        samples.append(result['benchmark'])
        for batch in result['benchmark']['batches']:
            for label,value in batch['results'].items():minimum[label]=min(minimum.get(label,float('inf')),value['seconds'])
    import statistics
    profiles.append(dict(case=case['case'],median_seconds=case['medians'],median_ratios=case['ratios'],
                         gpu_over_duplicate={key:statistics.median(value['ratios'][key+'_over_cpu']/value['ratios']['duplicate_over_cpu'] for value in samples) for key in ['roundtrip','resident']},
                         undersized_batches=case['undersized_batches']))
    undersized+=case['undersized_batches']
published=p/'published-inputs';published.mkdir();owned={}
for q in sorted((repo/'packages/stridetorch/benchmarks/webgpu_rpc').iterdir()):
    assert q.is_file();shutil.copy2(q,published/q.name);owned[str(q.relative_to(repo))]=sha(q)
save(p/'owned-input-sha256.json',owned)
state=read(r/'state.json');state.update(status='all_experimental_service_checks_passed',active_processes=[],main_modified=True,main_adopted=False,goal_status='active',last_goal_turn_classification='progress')
for name in ['state.json','continuation-latest.json']:save(r/name,state)
out=repo/'packages/stridetorch/benchmarks/results';archive=out/'iteration-74-harness.tar.xz';assert not archive.exists()
excluded={'package-check-tmp','wheel-check-tmp','__pycache__','.pytest_cache','.git','node_modules','build','dist'}
allowed={'.py','.mjs','.json','.log','.md','.npz','.toml','.txt','.cjs'};seen={};payloads={};logical=0;links=0
with tarfile.open(archive,'w:xz',preset=6) as target:
    for current,dirs,files in os.walk(r):
        dirs[:]=sorted(name for name in dirs if name not in excluded and not name.endswith(('-env','-venv','.egg-info')))
        for name in sorted(files):
            q=Path(current)/name
            if q.is_symlink() or q.suffix not in allowed:continue
            arc=str(q.relative_to(r));digest=sha(q);payloads[arc]=digest;info=target.gettarinfo(str(q),arcname=arc);logical+=q.stat().st_size
            key=(digest,info.mode,info.uid,info.gid,info.uname,info.gname)
            if key in seen:info.type=tarfile.LNKTYPE;info.linkname=seen[key];info.size=0;target.addfile(info);links+=1
            else:
                seen[key]=arc
                with q.open('rb') as data:target.addfile(info,data)
with tarfile.open(archive,'r:xz') as target:
    assert len(target.getmembers())==len(payloads)
    for member in target.getmembers():assert hashlib.sha256(target.extractfile(member).read()).hexdigest()==payloads[member.name]
identity=dict(name=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,files=len(payloads),unique_payloads=len(seen),hardlinks=links,logical_bytes=logical,all_logical_payloads_verified=True)
save(p/'archive-identity.json',identity)
report=dict(status='validated_experimental_service',iteration=74,supported_library_version='0.73.0',upstream=context['upstream'],
            supported_runtime_changed=False,production_judge_changed=False,gpu_torch_device_enabled=False,
            runtime_source_hashes=context['runtime_source_hashes'],published_inputs=owned,native_oracle=read(raw/'native-oracle.json'),
            opaque_gpu_qualification=qualification,deterministic_protocol=protocol,additional_real_device_lifecycle=life,
            performance_profiles=profiles,performance_full=formal,minimum_batch_seconds=minimum,under_target_batches=undersized,
            local_checks=checks,raw_archive=identity,release_policies=policy,
            limitations=['One Chrome155/AppleMetal3 device; six fresh processes per matrix program, not other hardware/browser coverage.',
                         'Explicit finite float32 2D matrix and analytical VJP programs; not public torch API/autograd or native CPU performance.',
                         'One small matrix uses one attention-score head from a PaperLeet fixture; this is not full attention or its batched/masked/softmax/gradient behavior.',
                         '111 of1152 timing batches were below20ms (minimum recorded per profile retained); no universal crossover threshold or automatic routing selection.',
                         'GPU-buffer accounting/explicit destruction is not physical VRAM measurement or preemption of submitted kernels. MessagePort queues/browser-driver resources lack hard tenant isolation.',
                         'FP64/complex/special values, batched/broadcast/empty matmul, automatic autograd, production judge async/budgets/cancellation integration and a supported GPU backend remain future work.'])
assert undersized==111
save(out/'iteration-74.json',report)
table=[]
for row in profiles:
    ns=row['median_seconds'];ratios=row['median_ratios'];shape='×'.join(map(str,row['case']['shape']))
    table.append(f"| {row['case']['name']} ({shape}) | {ns['cpu']*1e6:.2f} | {ns['roundtrip']*1e6:.2f} | {ns['resident']*1e6:.2f} | {ratios['duplicate_over_cpu']:.4f} | {ratios['roundtrip_over_cpu']:.4f} | {ratios['resident_over_cpu']:.4f} |")
text=f'''# Torch runtime iteration 74: isolated WebGPU matrix service

The supported library remains **0.73.0**, executing on CPU/NumPy/WASM. This
iteration adds a reusable developer prototype and measured evidence. It does not
enable a torch GPU device, change import aliases or alter the production judge.

An opaque-origin `sandbox="allow-scripts"` iframe retains its isolation. Its
Pyodide Worker has no direct WebGPU access. A MessagePort connects it to a secure
host Worker that owns one device and exposes only fixed float32 2D matrix
operations. An 8×8 tiled WGSL kernel accepts transpose flags; resident results
can feed subsequent matrix products without a CPU read between them.
The Python client copies upload/readback data and binds every handle to its
own session. The portable sources have no PaperLeet imports:
[`benchmarks/webgpu_rpc`](../../packages/stridetorch/benchmarks/webgpu_rpc/README.md).

## Verification

* 36 native Torch 2.6.0 and independent float64 matrix/analytical-VJP fixtures,
  nine irregular/tile-boundary shapes and all four transpose combinations.
  Original tolerance: `rtol=1e-4`, `atol=5e-4`; no tolerance was widened.
* 13 real opaque-worker boundary checks, including shape/field/handle errors,
  residency/transient/work quotas, recovery and cancellation-result discard.
* Nine deterministic protocol/lifetime checks with an injected fake engine.
* Four additional real GPU lifecycle checks: pending-startup disposal,
  resident-handle invalidation, abandoned-port lease recovery and a real device
  deliberately destroyed to exercise the device-lost event. These additional
  clients run in the trusted fixture page; they do not extend opaque-worker or
  hardware-crash coverage.
* {checks['package-check']['passed']} namespace/feature-detection tests and {checks['wheel-check']['passed']} built-wheel/ownership/independent-install tests.
  The stable runtime's 61 source resources and exported runtime identities
  remain identical. Full application CPU/catalog/frontend tests from iteration
  73 were not rerun for these new benchmark-only files.

The browser was unmodified headless Chrome 155.0.8059.82 on Apple Metal3, without
extra feature flags. The fixture supplied CORS for local Pyodide 0.29.4 assets.
It verifies parent-document access remains blocked, authenticates frame messages
by source and nonce, and terminates the learner Worker before reporting success.
Every successful device session ended with zero tracked allocations/handles.
This checks API accounting and destruction calls, not immediate physical VRAM
reclaim. An earlier local server MIME failure and its exact inputs are retained.

## Whole matrix-program costs

Each of six programs ran in six fresh Chrome/Pyodide/device processes. CPU A and
A′ are identical NumPy/WASM programs. GPU roundtrip includes per-call upload,
Python/JS conversion, RPC, dispatch, readback and release. Resident keeps inputs
on the GPU between calls; its setup upload is excluded, while output readback
and release remain included. Adapter/pipeline/Python initialization is excluded
from these warm measurements. Every program first checks float32 results
against an independent float64 expression, caller arrays and resource balance.

Eight balanced batches per program/profile target 20ms. Request-budget caps and
timing variation leave **111/1152 batches** below target, with minimum CPU/A′
19.6/19.5ms and GPU roundtrip/resident 10.1/6.2ms. These samples remain visible;
the results support the observed large differences, not a precise universal
crossover. Ratios are medians of six per-process ratios; descriptive microsecond
medians are aggregated separately and need not reproduce those ratios.

| Program (M×K×N) | NumPy μs | GPU roundtrip μs | GPU resident μs | A′/A | Roundtrip/A | Resident/A |
| --- | --- | --- | --- | --- | --- | --- |
{chr(10).join(table)}

`paperleet_attention_score_head` is one 4×5 by 5×6 score product from the
attention fixture, not full attention. `resident_mlp_chain` is two products with
no activation. `linear_vjp` explicitly evaluates the output and two analytical
matrix derivatives on both sides; it does not compare automatic torch autograd.

On this measured setup the 256/512 dense products benefit from the GPU even with
per-call transfers, while the small score matrices, short chain and small VJP
are slower. Residency reduces costs but does not make these small programs
faster. Keep CPU/WASM as the supported default. Further GPU work should retain
data across larger programs, amortize dispatch, qualify the Tensor/storage and
autograd interfaces, and test the real judge's async execution/budgets before
selecting an explicit opt-in backend. These results do not select an automatic
routing threshold or establish native CPU, other-browser, full-model or training
performance.

## Boundaries and reproduction

The service bounds accepted GPU allocations, handles, pending requests, work
and lease duration. It does not provide arbitrary shader execution. Cancellation
skips queued work or discards an output after completion; device destruction
does not establish GPU kernel preemption. MessagePort transport queues and
browser/driver resources still lack a hard denial-of-service isolation guarantee.
FP64/complex/special-value behavior, batched/broadcast/empty products and a
public GPU/autograd backend remain unqualified.

The [Pyodide 0.29.4 JSPI documentation](https://pyodide.org/en/0.29.4/usage/api/python-api/ffi.html#pyodide.ffi.run_sync)
requires an asynchronous-compatible Python entry for `run_sync` and labels the
feature experimental. The [WebGPU device destruction documentation](https://developer.mozilla.org/en-US/docs/Web/API/GPUDevice/destroy)
distinguishes device/resource destruction from already queued command execution.

Machine report: `packages/stridetorch/benchmarks/results/iteration-74.json`.
Raw harness `{identity['name']}`: {identity['bytes']:,} bytes,
SHA-256 `{identity['sha256']}`; {identity['files']} logical files,
{identity['unique_payloads']} mode/ownership-compatible payloads and
{identity['hardlinks']} hardlinks, every logical extracted payload verified.
The raw harness preserves absolute historical paths and requires Chrome,
Playwright, Pyodide assets and native Torch setup/path adjustment.
The qualification base is `{context['upstream']}`; remote integration is verified
separately. No CI, tag, package publication or deployment is requested here.
'''
(repo/'docs/validation/torch-runtime-iteration-74.md').write_text(text)
save(p/'local-report-identity.json',dict(report_sha256=sha(out/'iteration-74.json'),doc_sha256=sha(repo/'docs/validation/torch-runtime-iteration-74.md'),archive=identity,owned_inputs=owned))
print(json.dumps(dict(status=report['status'],protocol=9,native_fixtures=36,real_boundaries=13,lifecycle=4,latency_children=36,local_checks={k:v['passed'] for k,v in checks.items()},archive=identity)),flush=True)
