"""Numerical, ownership and lifetime checks through the real Python/JSPI RPC."""
import io,json
import numpy as np
from pyodide.ffi import run_sync
from js import matrix_rpc_other

oracle=np.load('/native-oracle.npz')
meta=json.loads(_native_meta_json)
rows=[]
for case in meta['cases']:
    name=case['name']
    a,b,g=(oracle[name+'_'+field] for field in ['a','b','g'])
    original=[value.copy() for value in (a,b,g)]
    values=[]
    try:
        am,bm,gm=[Matrix.upload(value) for value in (a,b,g)]
        values.extend([am,bm,gm])
        ta,tb=case['transpose_a'],case['transpose_b']
        ym=am.matmul(bm,ta,tb);values.append(ym)
        gam=bm.matmul(gm,tb,True) if ta else gm.matmul(bm,False,not tb)
        values.append(gam)
        gbm=gm.matmul(am,True,ta) if tb else am.matmul(gm,not ta,False)
        values.append(gbm)
        errors={}
        for field,matrix in [('y',ym),('ga',gam),('gb',gbm)]:
            actual=matrix.numpy()
            assert actual.dtype==np.float32
            for suffix in ['', '64']:
                reference=oracle[name+'_'+field+suffix]
                np.testing.assert_allclose(actual,reference,**meta['tolerance'])
                errors[field+suffix]=float(np.max(np.abs(actual-reference),initial=0))
        for actual,expected in zip((a,b,g),original):
            np.testing.assert_array_equal(actual,expected)
        rows.append(dict(**case,passed=True,max_absolute_error=errors))
    finally:
        for matrix in reversed(values):matrix.close()
    assert run_sync(matrix_rpc.stats()).resident_handles==0

# Upload and readback are explicit copy boundaries, including strided views.
a=np.arange(30,dtype=np.float32).reshape(5,6)[:,::2]
expected=a.copy()
with Matrix.upload(a) as resident:
    a.fill(-90)
    read=resident.numpy()
    np.testing.assert_array_equal(read,expected)
    read.fill(-70)
    np.testing.assert_array_equal(resident.numpy(),expected)
resident.close()
try:resident.numpy()
except RuntimeError:pass
else:raise AssertionError('Released Python handle accepted')

for bad in [np.ones((2,2),dtype=np.float64),np.ones((2,2),dtype=np.int32),np.ones(4,dtype=np.float32)]:
    try:Matrix.upload(bad)
    except TypeError:pass
    else:raise AssertionError('Unsupported array accepted')

# Distinct devices deliberately issue overlapping small handle numbers. Python
# ownership rejects combining their matrices instead of interpreting a foreign ID.
with Matrix.upload(np.ones((2,2),dtype=np.float32)) as left:
    with Matrix.upload(np.full((2,2),7,dtype=np.float32),client=matrix_rpc_other) as right:
        np.testing.assert_array_equal(left.numpy(),np.ones((2,2),dtype=np.float32))
        np.testing.assert_array_equal(right.numpy(),np.full((2,2),7,dtype=np.float32))
        try:left.matmul(right)
        except ValueError:pass
        else:raise AssertionError('Cross-session matrix accepted')

# Resident chaining has no CPU read between products.
with Matrix.upload(np.arange(12,dtype=np.float32).reshape(3,4)) as a:
    with Matrix.upload(np.arange(20,dtype=np.float32).reshape(4,5)/10) as b:
        with Matrix.upload(np.arange(10,dtype=np.float32).reshape(5,2)/10) as c:
            with a.matmul(b) as intermediate:
                with intermediate.matmul(c) as output:
                    expected=(np.arange(12,dtype=np.float32).reshape(3,4)@(np.arange(20,dtype=np.float32).reshape(4,5)/10))@(np.arange(10,dtype=np.float32).reshape(5,2)/10)
                    np.testing.assert_allclose(output.numpy(),expected,**meta['tolerance'])
assert run_sync(matrix_rpc.stats()).resident_handles==0
assert run_sync(matrix_rpc_other.stats()).resident_handles==0
json.dumps(dict(status='passed',cases=len(rows),rows=rows,ownership_checks=6,
                scope='Explicit float32 2D matrix forward/VJP primitives, not an automatic torch GPU or autograd backend.'))
