import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const repo='/Users/david/Developer/PaperLeet-torch-release';
const runtime=repo+'/web/public/browser-runtime/pyodide-0.29.4';
const sha=file=>createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const config=process.env.GPU_BENCHMARK_CASE?{mode:'benchmark',case:JSON.parse(process.env.GPU_BENCHMARK_CASE),cycle:Number(process.env.GPU_BENCHMARK_CYCLE)}:{mode:'qualification'};
const files=['gpu-service.mjs','rpc-client.mjs','matrix_client.py','qualify.py','benchmark.py','run-browser.mjs','native-oracle.npz','native-oracle.json'];
const source=Object.fromEntries(files.map(name=>[name,sha(path.join(root,name))]));
const requests=[];
const server=http.createServer(async(req,res)=>{
  try{
    const name=new URL(req.url,'http://localhost').pathname;requests.push({path:name,origin:req.headers.origin||null});
    if(name==='/'){res.writeHead(200,{'content-type':'text/html'});res.end('<!doctype html><title>Local bounded GPU service experiment</title>');return;}
    const base=name.startsWith('/runtime/')?runtime:root;
    const relative=name.startsWith('/runtime/')?name.slice('/runtime/'.length):name.startsWith('/rpc/')?name.slice('/rpc/'.length):null;
    assert(relative!==null);const file=path.resolve(base,relative);assert(file.startsWith(base+path.sep));
    const bytes=await fs.promises.readFile(file);
    res.writeHead(200,{'content-type':/\.m?js$/.test(file)?'text/javascript':file.endsWith('.wasm')?'application/wasm':'application/octet-stream','access-control-allow-origin':'*','cache-control':'no-store'});res.end(bytes);
  }catch{res.writeHead(404);res.end();}
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const origin='http://127.0.0.1:'+server.address().port;

async function workerMain(base,config){
  self.onmessage=async event=>{
    if(event.data?.type!=='attach'||event.ports.length!==(config.mode==='benchmark'?1:2))return;
    self.onmessage=null;
    try{
      const {MatrixRpc}=await import(base+'/rpc/rpc-client.mjs');
      const clients=event.ports.map(port=>new MatrixRpc(port));
      self.matrix_rpc=clients[0];self.matrix_rpc_other=clients[1]||clients[0];
      await Promise.all(clients.map(client=>client.ready));
      self.postMessage({type:'phase',phase:'GPU clients ready'});
      const {loadPyodide}=await import(base+'/runtime/pyodide.mjs');
      const py=await loadPyodide({indexURL:base+'/runtime/',stdout(){},stderr(){}});await py.loadPackage('numpy');
      self.postMessage({type:'phase',phase:'Pyodide and NumPy ready'});
      const [matrix,program,meta,payload]=await Promise.all([
        fetch(base+'/rpc/matrix_client.py').then(value=>value.text()),fetch(base+'/rpc/qualify.py').then(value=>value.text()),
        fetch(base+'/rpc/native-oracle.json').then(value=>value.json()),fetch(base+'/rpc/native-oracle.npz').then(value=>value.arrayBuffer())]);
      py.FS.writeFile('/native-oracle.npz',new Uint8Array(payload));py.globals.set('_native_meta_json',JSON.stringify(meta));
      if(config.mode==='benchmark'){
        py.globals.set('_benchmark_case_json',JSON.stringify(config.case));py.globals.set('_benchmark_cycle',config.cycle);
        const benchmarkSource=await fetch(base+'/rpc/benchmark.py').then(value=>value.text());
        const benchmark=JSON.parse(await py.runPythonAsync(matrix+'\n'+benchmarkSource));
        const beforeClose=await Promise.all(clients.map(client=>client.stats()));
        if(beforeClose.some(value=>value.total_bytes!==0||value.resident_handles!==0))throw Error('Benchmark resources leaked');
        await Promise.all(clients.map(client=>client.close()));
        self.postMessage({type:'result',result:{status:'passed',worker:{secure_context:isSecureContext,origin:self.origin,gpu_exposed:!!navigator.gpu,pyodide:py.version},benchmark,before_close:beforeClose}});return;
      }
      const numerical=JSON.parse(await py.runPythonAsync(matrix+'\n'+program));
      self.postMessage({type:'phase',phase:'Native and float64 matrix/VJP controls passed'});
      const client=clients[0],boundaries=[];
      async function rejected(name,promise,code){
        try{await promise;throw Error('Unexpected acceptance: '+name);}catch(error){if(error.code!==code)throw error;boundaries.push({name,code,passed:true});}
      }
      await rejected('negative shape',client.send('upload',{rows:-1,cols:1,data:new ArrayBuffer(4)}).promise,'Shape');
      await rejected('byte mismatch',client.send('upload',{rows:2,cols:2,data:new ArrayBuffer(12)}).promise,'Shape');
      await rejected('unknown operation',client.send('shader',{code:'untrusted source'}).promise,'Operation');
      await rejected('surplus fields',client.send('stats',{extra:1}).promise,'Protocol');
      await rejected('unknown handle',client.read(2147483647),'Handle');
      await rejected('malformed field names',client.send('upload',{rows:2,'cols,data':1}).promise,'Protocol');
      const handles=[];
      for(let i=0;i<client.limits.handles;i++)handles.push((await client.upload(new Float32Array([i+1]),1,1)).handle);
      await rejected('handle quota',client.upload(new Float32Array([1]),1,1),'Capacity');
      for(const handle of handles)await client.release(handle);
      await rejected('released handle',client.read(handles[0]),'Handle');
      const a=(await client.upload(new Float32Array([1,2,3,4]),2,2)).handle;
      const b=(await client.upload(new Float32Array([1,2,3]),3,1)).handle;
      await rejected('inner dimensions',client.matmul(a,b),'Shape');
      await rejected('transpose type',client.matmul(a,a,1,false),'Protocol');
      await client.release(a);await client.release(b);
      const large=[];
      for(let i=0;i<8;i++)large.push((await client.upload(new Float32Array(1024*1024).fill((i+1)/32),1024,1024)).handle);
      const full=await client.stats();if(full.total_bytes!==client.limits.bytes)throw Error('Resident byte accounting');
      await rejected('byte quota',client.upload(new Float32Array([1]),1,1),'Capacity');
      await rejected('readback transient quota',client.read(large[0]),'Capacity');
      await rejected('work quota',client.matmul(large[0],large[0]),'Capacity');
      await client.release(large.pop());const read=await client.read(large[0]);if(!read.every(value=>value===1/32))throw Error('Read after quota recovery');
      for(const handle of large)await client.release(handle);
      const ca=(await client.upload(new Float32Array(512*512).fill(.125),512,512)).handle;
      const cb=(await client.upload(new Float32Array(512*512).fill(.25),512,512)).handle;
      const ticket=client.send('matmul',{a:ca,b:cb,transposeA:false,transposeB:false});
      const outcome=ticket.promise.then(value=>({kind:'completed',value}),error=>({kind:'rejected',code:error.code}));
      const cancellation=await client.cancel(ticket.id),settled=await outcome;
      if(cancellation.cancelled){if(settled.code!=='Cancelled')throw Error('Cancelled output published');}
      else{if(settled.kind!=='completed')throw Error('Cancellation race response');await client.release(settled.value.handle);}
      await client.release(ca);await client.release(cb);
      const beforeClose=await Promise.all(clients.map(client=>client.stats()));
      if(beforeClose.some(value=>value.total_bytes!==0||value.resident_handles!==0))throw Error('GPU resources leaked');
      await Promise.all(clients.map(client=>client.close()));
      self.postMessage({type:'result',result:{status:'passed',worker:{secure_context:isSecureContext,origin:self.origin,gpu_exposed:!!navigator.gpu,pyodide:py.version},numerical,boundaries,cancellation:{requested:cancellation.cancelled,outcome:settled.kind,code:settled.code},before_close:beforeClose}});
    }catch(error){self.postMessage({type:'failure',error:String(error.stack||error)});}
  };
}

let browser;
try{
  browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
  const page=await browser.newPage();await page.goto(origin);
  page.on('console',message=>{if(message.type()==='error')console.log('BROWSER',message.text().slice(0,300));});
  const sourceText='('+workerMain.toString()+')('+JSON.stringify(origin)+','+JSON.stringify(config)+')';
  const result=await page.evaluate(async({base,sourceText,hostCount})=>{
    const hosts=[],disposals=[],frame=document.createElement('iframe');frame.setAttribute('sandbox','allow-scripts');
    const nonce=crypto.randomUUID();let resultResolve,resultReject,stoppedResolve;
    const stopped=new Promise(resolve=>stoppedResolve=resolve);
    const completed=new Promise((resolve,reject)=>{resultResolve=resolve;resultReject=reject;});
    const timer=setTimeout(()=>resultReject(Error('Fixture total timeout')),100000);
    for(let i=0;i<hostCount;i++){
      const worker=new Worker(base+'/rpc/gpu-service.mjs',{type:'module'}),channel=new MessageChannel();
      const host={worker,port:channel.port2,events:[]};
      host.disposed=new Promise(resolve=>host.disposedResolve=resolve);
      worker.onmessage=event=>{host.events.push(event.data);if(event.data?.type==='disposed')host.disposedResolve(event.data);if(event.data?.type==='unavailable')resultReject(Error(event.data.error));};
      worker.onerror=event=>resultReject(Error('Host worker: '+event.message));hosts.push(host);worker.postMessage({type:'connect'},[channel.port1]);
    }
    function receive(event){
      if(event.source!==frame.contentWindow||event.data?.nonce!==nonce)return;
      const data=event.data;
      if(data.type==='frame_ready'){
        if(event.origin!=='null'||!data.parent_blocked){resultReject(Error('Isolation boundary changed'));return;}
        frame.contentWindow.postMessage({nonce,type:'attach'},'*',hosts.map(host=>host.port));
      }
      if(data.type==='result'){if(!data.worker_terminated){resultReject(Error('Learner worker not terminated'));return;}resultResolve(data.result);}
      if(data.type==='failure')resultReject(Error(data.error));
      if(data.type==='stopped')stoppedResolve();
    }
    window.addEventListener('message',receive);
    const csp="default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval' blob: "+base+"/; worker-src blob:; connect-src "+base+'/;';
    const program='const nonce='+JSON.stringify(nonce)+';const hostCount='+hostCount+';let attached=false;let blocked=false;try{parent.document.body}catch{blocked=true;}const url=URL.createObjectURL(new Blob(['+JSON.stringify(sourceText)+'],{type:"text/javascript"}));const worker=new Worker(url);const stop=()=>{worker.terminate();URL.revokeObjectURL(url);};worker.onmessage=e=>{const terminal=e.data?.type==="result"||e.data?.type==="failure";if(terminal)stop();parent.postMessage({nonce,...e.data,worker_terminated:terminal},"*");};worker.onerror=e=>{stop();parent.postMessage({nonce,type:"failure",error:e.message,worker_terminated:true},"*");};addEventListener("message",e=>{if(e.source!==parent||e.data?.nonce!==nonce)return;if(e.data.type==="stop"){stop();parent.postMessage({nonce,type:"stopped"},"*");return;}if(!attached&&e.data.type==="attach"&&e.ports.length===hostCount){attached=true;worker.postMessage({type:"attach"},e.ports);}});parent.postMessage({nonce,type:"frame_ready",parent_blocked:blocked},"*");';
    frame.srcdoc='<meta http-equiv="Content-Security-Policy" content="'+csp.replaceAll('"','&quot;')+'"><script>'+program.replaceAll('</script','<\\/script')+'</script>';document.body.append(frame);
    try{
      const value=await completed;
      for(const host of hosts)host.worker.postMessage({type:'dispose'});
      for(const host of hosts)disposals.push(await Promise.race([host.disposed,new Promise((_,reject)=>setTimeout(()=>reject(Error('Device disposal timeout')),5000))]));
      return {...value,host_events:hosts.map(host=>host.events),host_disposals:disposals,isolation:{sandbox:frame.getAttribute('sandbox'),csp,parent_document_blocked:true,learner_worker_terminated_before_result:true}};
    }finally{
      clearTimeout(timer);frame.contentWindow?.postMessage({nonce,type:'stop'},'*');
      await Promise.race([stopped,new Promise(resolve=>setTimeout(resolve,500))]);window.removeEventListener('message',receive);frame.remove();
      for(const host of hosts){host.worker.postMessage({type:'dispose'});await Promise.race([host.disposed,new Promise(resolve=>setTimeout(resolve,1000))]);host.worker.terminate();host.port.close();}
    }
  },{base:origin,sourceText,hostCount:config.mode==='benchmark'?1:2});
  for(const [name,digest] of Object.entries(source))assert.equal(sha(path.join(root,name)),digest,name);
  assert.equal(result.status,'passed');assert.equal(result.worker.secure_context,false);assert.equal(result.worker.gpu_exposed,false);
  if(config.mode==='qualification')assert.equal(result.numerical.cases,36);
  else assert.equal(result.benchmark.status,'passed');
  assert(result.host_disposals.every(value=>value.stats.total_bytes===0&&value.stats.closed));
  const report={...result,observed_utc:new Date().toISOString(),browser:browser.version(),launch:{headless:true,extra_flags:[]},source_sha256:source,
    runtime_identity:{pyodide_module_sha256:sha(runtime+'/pyodide.mjs'),production_judge_sha256:sha(repo+'/web/src/browserJudge.ts')},
    requests,production_backend_changed:false,
    limits_scope:'API-accepted GPU allocations and handles are bounded. MessagePort transport queues, browser/driver resource use, malicious sender CPU and hard cross-origin denial-of-service isolation are not qualified.',
    config,scope:config.mode==='qualification'?'Real opaque-origin Pyodide -> MessagePort -> secure host Worker -> tiled WGSL matrix/VJP and readback. Two owned device sessions. No public torch GPU device, automatic autograd, production judge integration or performance qualification.':'One warm owned GPU device and opaque-origin Pyodide matrix program. CPU NumPy A/A, GPU per-call transfer and already-resident-input profiles. No native CPU or public torch/autograd comparison; adapter/pipeline/Python initialization excluded.'};
  const output=config.mode==='qualification'?'browser-result.json':'performance/results/'+config.case.name+'-'+config.cycle+'.json';
  fs.mkdirSync(path.dirname(path.join(root,output)),{recursive:true});fs.writeFileSync(path.join(root,output),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify(config.mode==='qualification'?{status:report.status,numerical:report.numerical.cases,boundaries:report.boundaries.length,cancellation:report.cancellation,disposals:report.host_disposals,browser:report.browser}:{status:report.status,case:config.case.name,cycle:config.cycle,ratios:report.benchmark.ratios,undersized_batches:report.benchmark.undersized_batches.length}));
}finally{if(browser)await browser.close();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
