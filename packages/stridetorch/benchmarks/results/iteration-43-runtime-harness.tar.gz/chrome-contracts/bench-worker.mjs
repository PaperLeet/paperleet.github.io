import {loadJudgePackages} from '../../../extraction-browser/packages.mjs';
self.onmessage=async({data})=>{try{
const plan=await(await fetch('./bench-source-plan.json')).json();const {loadPyodide}=await import('../../../runtime-0.29.4/pyodide.mjs');
const py=await loadPyodide({indexURL:new URL('../../../runtime-0.29.4/',self.location.href).href,stdout(){},stderr(){}});await loadJudgePackages(py,[]);
async function text(url){const response=await fetch(url);if(!response.ok)throw Error(url+':'+response.status);return await response.text();}
for(const [name,relative] of [['baseline','../../baseline-source/stridetorch/'],['candidate','./source/']]){py.FS.mkdirTree('/'+name);for(const file of plan[name])py.FS.writeFile('/'+name+'/'+file,await text(relative+file));}
py.FS.writeFile('/bench.py',await text('../../bench_max_pooling_3d.py'));py.FS.writeFile('/bench_max_pooling_1d.py',await text('../../bench_max_pooling_1d.py'));py.globals.set('reverse_order',data.reverse);
py.runPython(`import sys,runpy
sys.path.insert(0,'/')
sys.argv=['bench.py','--baseline-source','/baseline','--candidate-source','/candidate','--iterations','40','--samples','7','--output','/result.json']+(['--reverse'] if reverse_order else [])
runpy.run_path('/bench.py',run_name='__main__')`);
self.postMessage({...JSON.parse(py.FS.readFile('/result.json',{encoding:'utf8'})),runtime:'Chrome Worker/Pyodide',pyodide:py.version});
}catch(error){self.postMessage({error:String(error.stack||error)});}};
