import fs from 'node:fs';import path from 'node:path';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const py=await loadPyodide({indexURL:'/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/',packageCacheDir:'/Users/david/Developer/PaperLeet-torch-release/web/public/browser-runtime/pyodide-0.29.4/',stdout(){},stderr:console.error});
await loadJudgePackages(py,[]);py.FS.mkdirTree('/runtime/stridetorch');
for(const name of fs.readdirSync(process.argv[2]).filter(n=>n.endsWith('.py')||['LICENSE','NOTICE'].includes(n)))py.FS.writeFile('/runtime/stridetorch/'+name,fs.readFileSync(path.join(process.argv[2],name)));
py.runPython("import sys;sys.path.insert(0,'/runtime')");py.globals.set('bench_dtype',process.argv[3]);
py.runPython(fs.readFileSync(new URL('bench-layout.py',import.meta.url),'utf8'));
console.log(py.runPython('json.dumps(result)'));
