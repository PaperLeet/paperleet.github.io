from pathlib import Path
import hashlib,json,re,subprocess,tarfile

r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
def read(p):return json.loads(p.read_text())
def hashes(p):return {x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in p.iterdir() if x.is_file() and (x.suffix=='.py' or x.name in ('LICENSE','NOTICE'))}
source=hashes(repo/'packages/stridetorch/src/stridetorch');assert len(source)==45
assert source==hashes(r/'optimized/stridetorch')==hashes(r/'proof/source')==hashes(r/'proof/chrome-contracts/source')
node=read(r/'proof/source-wasm.json');chrome=read(r/'proof/chrome-contracts/result.json');wheel=read(r/'proof/wheel-stride027-result.json');coinstall=read(r/'proof/coinstall-result.json');performance=read(r/'performance-validated-summary.json');native=read(r/'native-ci.json')
for record in (node,chrome,wheel,coinstall):assert record['source_hashes']==source
assert node['passed']==chrome['passed']==841 and node['library']==chrome['library']=='0.27.0'
assert chrome['status']==wheel['status']==coinstall['status']=='success'
assert '27059 passed, 1 skipped' in (r/'full-native-final.log').read_text()
assert '256 passed' in (r/'focused-optimized.log').read_text()
assert '853 passed' in (r/'proof/python310-stride027-tests.log').read_text()
assert native['passed'] and native['problems']==78 and native['tests_executed']==10218 and native['repeats']==3 and not native['issues'] and sum(map(len,native['mutation'].values()))==342
assert performance['source_hashes']['optimized']==source and len(performance['receipts'])==16 and all(x['exit_code']==0 for x in performance['receipts'])
for receipt in performance['receipts']:
 data=read(r/'performance-validated'/(receipt['name']+'.json'))
 assert len(data['cases'])==8
 assert all(x['parameter_dtype']==x['seed_dtype']==x['gradient_dtype']==receipt['dtype'] for x in data['cases'].values())
plan=read(r/'proof/chrome-contracts/plan.json')
assert chrome['test_hashes']==plan['tests']=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'}
report=dict(status='local_core_gates_passed_application_integration_pending',version='0.27.0',baseline_commit='11434fb8fceaa765cad52802ac1355303a61211f',source_hashes=source,base=dict(passed=27059,optional_skips=1,warnings=34,elapsed_s=193.61),focused_passed=256,minimum=dict(passed=853,python=wheel['python'],numpy=wheel['numpy'],native_torch=wheel['native_torch'],artifacts=wheel['artifacts']),node=node,chrome=chrome,coinstall=coinstall,native_catalog={k:v for k,v in native.items() if k!='mutation'},native_mutants=342,performance=performance,earlier_trials=dict(initial='Generic allocation timings retained',optimized='Float32 first-copy inputs were accidentally promoted to float64 by NumPy scalar promotion;not valid float32 first-copy evidence',validated='Python integer divisor,explicit runtime dtype assertions and recorded layout metadata;adopted measurement'),failed_checks_retained=['First independent draft attempted six unsupported half optimizer cases;boundary retained and fixture corrected','Initial broad pytest included619problem fixtures without an implementation plan;all27059base tests passed;correct command laterterminal0','python -m build and python -m paperleet have no executable __main__ in this environment;actual uv build and paperleet console CLI used','Final metadata packaging recheck hit an existing destination in its copier;idempotent copier corrected and actual wheel/minimum/coinstall checks repeated successfully'],scope='First stored leaf gradient layouts and retained non-leaf snapshot ownership. No native buffer stealing;no sparse/complex/higher-order expansion. No independent publication.',remaining=['Preserve latest main UI changes and all published immutable data','Full actual exported WASM and frontend/profile/application distribution gates','Non-force main adoption and actual remoteQuality','Eligible actual Pages deployment and frozen live-byte verification'])
(r/'local-gates.json').write_text(json.dumps(report,indent=2)+'\n');(r/'implementation.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=repo))
files={}
def add(p,name=None):
 if p.is_file():files[name or str(p.relative_to(r))]=p
for folder in ('baseline/stridetorch','candidate/stridetorch','optimized/stridetorch','initial-harness','optimized-harness','performance','performance-optimized','performance-validated','proof/source','proof/chrome-contracts','proof/dist-preflight','proof/private-dist','proof/python310-stride027-tests'):
 for p in (r/folder).rglob('*'):
  if '__pycache__' not in p.parts and '.pytest_cache' not in p.parts:add(p)
for folder in (r,r/'proof'):
 for p in folder.iterdir():
  if p.suffix in ('.py','.mjs','.json','.log','.patch'):add(p)
for name in ('tests/test_torch_gradient_layout.py','packages/stridetorch/tests/test_gradient_layout.py','packages/stridetorch/README.md','packages/stridetorch/pyproject.toml','docs/validation/torch-runtime-iteration-27.md'):add(repo/name,'maintained/'+name)
archive=out/'iteration-27-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
report['archive']=dict(file=archive.name,files=len(files),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest());(out/'iteration-27.json').write_text(json.dumps(report,indent=2)+'\n')
state=read(r/'state.json');state.update(phase='0.27 complete core/native original catalog gates passed;application integration pending',source_hashes=source,local_report=str(out/'iteration-27.json'),archive=report['archive'],next=report['remaining'],turn_classification='progress:gradient layout/ownership compatibility and validated-dtype timing evidence;0.26 exact remoteQualityverified with actual deploy-skipped distinction',processes=dict(full_original=dict(session=20157,exit_code=1,reason='problem fixtures omitted implementation plan'),full_corrected=dict(session=68748,exit_code=0),native_catalog=dict(session=28308,exit_code=0),node=dict(session=48340,exit_code=0),chrome=dict(session=62162,exit_code=0),final_minimum_coinstall=dict(session=36031,exit_code=0),validated_performance=dict(session=22208,exit_code=0)),release26=dict(quality=38903517940,quality_success=True,source_pages=38904560589,actual_source_deploy_skipped=True,descendant='3c85b1783093be12ab079a713b581946fc00bfc2',descendant_quality=38904656048,observer_session=56554))
(r/'state.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(dict(status=report['status'],archive=report['archive'])))
