import json, itertools, warnings
import numpy as np
import torch as native
from stridetorch import torch

def arrays():
    a=np.arange(24,dtype='float64').reshape(2,3,4)
    for axes in itertools.permutations(range(3)):
        yield 'perm'+str(axes),a.transpose(axes)
    yield 'step',a[:,:,::2]
    yield 'overlap',np.broadcast_to(a[0,0,0],(2,3))
    for shape,strides in [((2,1,3),(3,0,1)),((2,1,3),(3,99,1)),((1,1),(0,0)),((1,1),(9,1)),((0,3),(3,1)),((2,0,3),(0,3,1)),((3,0,2),(2,22,1))]:
        yield str((shape,strides)),np.ndarray(shape,dtype='float64',buffer=np.arange(24,dtype='float64'),strides=tuple(s*8 for s in strides))

rows=[]
with warnings.catch_warnings():
    warnings.simplefilter('ignore')
    for name,data in arrays():
        row={'case':name,'shape':data.shape,'input_stride':tuple(s//8 for s in data.strides)}
        for api in (native,torch):
            x=api.from_numpy(data).requires_grad_(); seed=api.ones(x.shape,dtype=x.dtype)
            x.backward(seed)
            seed.fill_(99)
            middle=x*2;middle.retain_grad();middle.backward(api.ones(middle.shape,dtype=middle.dtype))
            row[api.__name__]={'leaf':x.grad.stride(),'retained':middle.grad.stride(),'independent':bool(np.all(middle.grad.numpy()==1))}
        rows.append(row)
print(json.dumps({'native':native.__version__,'rows':rows},indent=2))
