import gc,hashlib,json,os,platform,statistics,sys,time
from pathlib import Path
import numpy as np
from stridetorch import torch
import stridetorch

dtype=globals().get('bench_dtype',os.environ.get('BENCH_DTYPE','float32'))
results={};cases={}

def measure(name,operation,check,calls):
    for _ in range(3):operation()
    check();samples=[];gc.collect();gc.disable()
    try:
        for _ in range(9):
            start=time.perf_counter()
            for _ in range(calls):operation()
            samples.append((time.perf_counter()-start)*1000/calls)
    finally:gc.enable()
    check();results[name]={'median_ms':statistics.median(samples),'samples_ms':samples,'calls':calls}

for layout in ('C','F','permute','step'):
    for size in ('small','large'):
        shape=(8,16) if size=='small' else (128,256)
        raw=np.arange(np.prod(shape),dtype=dtype).reshape(shape)/int(np.prod(shape))
        data=np.array(raw,order=layout) if layout in ('C','F') else raw.reshape(4,shape[0]//4,shape[1]).transpose(1,2,0) if layout=='permute' else np.repeat(raw,2,axis=-1)[...,::2]
        x=torch.from_numpy(data).requires_grad_();seed=torch.full(x.shape,.5,dtype=getattr(torch,dtype))
        assert x.dtype==getattr(torch,dtype) and seed.dtype==getattr(torch,dtype)
        def first():x.grad=None;x.backward(seed)
        def check():
            np.testing.assert_array_equal(x.grad.numpy(),np.full(x.shape,.5))
            assert not np.shares_memory(x.grad.numpy(),seed.numpy())
            assert x.grad.dtype==getattr(torch,dtype)
            cases[layout+'_'+size+'_first']={'parameter_dtype':str(x.dtype),'seed_dtype':str(seed.dtype),'gradient_dtype':str(x.grad.dtype),'shape':x.shape,'parameter_stride':x.stride(),'seed_stride':seed.stride(),'gradient_stride':x.grad.stride()}
        measure(layout+'_'+size+'_first',first,check,500 if size=='small' else 60)

x=torch.ones(8,16,dtype=getattr(torch,dtype),requires_grad=True);y=(x*2).sum()
for reuse in (False,True):
    def backward():
        if reuse and x.grad is not None:x.grad.zero_()
        else:x.grad=None
        y.backward(retain_graph=True)
    measure('graph_C_'+('reuse' if reuse else 'first'),backward,lambda:np.testing.assert_array_equal(x.grad.numpy(),np.full(x.shape,2.)),300)
for order in ('C','F'):
    values=np.array(np.arange(32768,dtype=dtype).reshape(128,256)/32768,order=order)
    leaf=torch.from_numpy(values).requires_grad_();assert leaf.dtype==getattr(torch,dtype)
    def train_backward():
        leaf.grad=None;leaf.square().sum().backward()
    measure('square_backward_'+order,train_backward,lambda:np.testing.assert_array_equal(leaf.grad.numpy(),values*2),30)
control=torch.ones(128,dtype=getattr(torch,dtype))
measure('exp_control',lambda:control.exp(),lambda:np.testing.assert_allclose(control.exp().numpy(),np.full(128,np.e),rtol=2e-6),500)
source=Path(stridetorch.__file__).parent
result={'library':stridetorch.__version__,'python':sys.version,'numpy':np.__version__,'platform':platform.platform(),'dtype':dtype,
        'source_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')},'results':results,'cases':cases}
if 'bench_dtype' not in globals():print(json.dumps(result))
