from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=r/'late-ui-proof';out.mkdir(exist_ok=True)
a='e8954084bef906dab54b82f1f6e23969e681fa4f';b=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();paths=subprocess.check_output(['git','diff','--name-only',a,b],cwd=repo,text=True).splitlines();assert len(paths)==6 and all(name.startswith('web/') for name in paths)
env=dict(os.environ,PATH='/opt/homebrew/bin:'+os.environ['PATH'],PYTHON=str(r.parent/'torch-iteration-21/stride-dev-env/bin/python'));profile=json.loads((r/'integration-proof/pages-profile.json').read_text())['environment'];receipts=[]
checks=('interview-browse','interview-saved','interviews','interview-ui','interview-ranking','interview-search','interview-study','company-preparation','preparation-guides','interview-report-practice')
plans=[(['/opt/homebrew/bin/node','scripts/check-'+name+'.mjs'],name,{}) for name in checks]+[(['npm','run','build'],'production-build',{}),(['npm','run','build'],'pages-profile-build',profile)]
for args,name,overrides in plans:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:result=subprocess.run(args,cwd=repo/'web',env={**env,**overrides},stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(name=name,exit_code=result.returncode,elapsed_s=time.monotonic()-start,args=args));(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,'TERMINAL',result.returncode,flush=True);result.check_returncode()
for name,digest in json.loads((r/'proof/source-hashes.json').read_text()).items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==digest
for name,digest in json.loads((r/'integration-proof/live-expected-sha256.json').read_text()).items():assert hashlib.sha256((repo/'web/public/data'/name).read_bytes()).hexdigest()==digest
syncs=json.loads((r/'upstream-syncs.json').read_text());syncs.append(dict(before=a,after=b,paths={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in paths},receipts='late-ui-proof/receipts.json',scope='Six interview active-filter/browse/component/style/check files; ten affected canonical suites and both production builds. All50 runtime/license resources and161 active exports unchanged; no problem/SDK/native/package metadata/lock/release/driver changes. Prior UI input identities remain bound to original Git blobs.'))
(r/'upstream-syncs.json').write_text(json.dumps(syncs,indent=2)+'\n');print('LATE6_UI_TERMINAL0',flush=True)
