from pathlib import Path
import importlib,json,sys
import numpy as np
repo=Path('/Users/david/Developer/PaperLeet-torch-release');sys.path.insert(0,str(repo/'packages/stridetorch/benchmarks'))
from bench_max_pooling_1d import load,arrays,measure
from bench_max_pooling_3d import make_flow,make_training
r=Path(__file__).resolve().parent
base,bh=load('pilot_base',r/'baseline-source/stridetorch');candidate,ch=load('pilot_candidate',repo/'packages/stridetorch/src/stridetorch');control,_=load('pilot_control',repo/'packages/stridetorch/src/stridetorch');importlib.import_module(control.__name__+'._pooling3d')._SEPARABLE_MODE='off'
variants={'baseline':base.torch,'candidate':candidate.torch,'control':control.torch};rows=[]
for dtype in (np.float32,np.float64):
 for kind in ('cube','overlap','dilated'):
  for mode in ('forward','indices','backward','jvp'):
   calls={name:make_flow(api,kind,mode,True,dtype) for name,api in variants.items()};checked={name:arrays(call()) for name,call in calls.items()}
   for name,values in checked.items():
    for a,b in zip(values,checked['baseline']):np.testing.assert_allclose(a,b,rtol=3e-5,atol=3e-6)
   timings={name:measure(call,30,5) for name,call in calls.items()};reduction=100*(1-timings['candidate']['median_us']/timings['baseline']['median_us']);rows.append(dict(kind=kind,mode=mode,dtype=np.dtype(dtype).name,timings=timings,reduction_percent=reduction))
(r/'pilot.json').write_text(json.dumps(dict(status='success',source_hashes=dict(baseline=bh,candidate=ch),results=rows,scope='Exploratory CPU-only direct0.43 comparison; not final version evidence'),indent=2)+'\n')
for row in rows:print(row['dtype'],row['kind'],row['mode'],round(row['reduction_percent'],1))
