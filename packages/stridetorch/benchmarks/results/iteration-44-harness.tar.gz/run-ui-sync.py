from pathlib import Path
import hashlib,json,shutil,subprocess,time
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=r/'main-sync-proof';out.mkdir(exist_ok=True);py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';uv='/Users/david/.local/bin/uv'
a='3872b805c5e553170432087d9270caf88460a70f';b=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();paths=subprocess.check_output(['git','diff','--name-only',a,b],cwd=repo,text=True).splitlines();assert len(paths)==18
assert all(name.startswith('web/') or name in ('paperleet/interview_catalog.json','tests/test_interview_catalog.py') for name in paths)
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
source=json.loads((r/'proof/source-hashes.json').read_text());live=json.loads((r/'integration-proof/live-expected-sha256.json').read_text());harness=json.loads((r/'integration-proof/wasm-harness-identity.json').read_text())
for name,sha in source.items():assert digest(repo/'packages/stridetorch/src/stridetorch'/name)==sha
for name,sha in live.items():assert digest(repo/'web/public/data'/name)==sha
assert digest(repo/harness['file'])==harness['sha256'] and digest(repo/harness['driver_file'])==harness['driver_sha256']
for folder,files in [('integration-proof',['frontend-receipts.json','pages-profile.json','distribution-identity.json']),('proof',['gate-receipts.json','coinstall-result.json'])]:
 for name in files:shutil.copy2(r/folder/name,out/('before-'+name))
receipts=[]
def run(name,args,cwd=repo):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:result=subprocess.run([str(v) for v in args],cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
 receipt=dict(name=name,exit_code=result.returncode,elapsed_s=time.monotonic()-start,args=[str(v) for v in args]);receipts.append(receipt);(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,'TERMINAL',result.returncode,flush=True);result.check_returncode();return receipt
run('metadata-tests',[py,'-m','pytest','tests/test_interview_catalog.py','-q'])
build=run('build-private',[uv,'build','--out-dir',r/'proof/private-dist']);coinstall=run('coinstall',[py,r/'proof/check-coinstall.py'])
gates=json.loads((r/'proof/gate-receipts.json').read_text());gates['build-private']=build;gates['coinstall']=coinstall;(r/'proof/gate-receipts.json').write_text(json.dumps(gates,indent=2)+'\n')
for file in (r/'proof/private-dist').iterdir():
 if file.suffix in ('.whl','.gz'):shutil.copy2(file,r/'integration-proof/dist-paperleet'/file.name)
run('private-identity',[py,r/'integration-proof/verify-private.py'])
run('full-frontend',[py,r/'integration-proof/run-frontend.py'])
reuse=json.loads((r/'integration-proof/native-input-reuse.json').read_text());changes={}
for name,sha in reuse['files'].items():
 actual=digest(repo/name)
 if actual!=sha:changes[name]=dict(previous=sha,current=actual);reuse['files'][name]=actual
assert set(changes)=={'paperleet/interview_catalog.json','tests/test_interview_catalog.py'}
reuse['curriculum_metadata_sync']=dict(commit=b,changes=changes,validation='main-sync-proof/metadata-tests.log',scope='Auxiliary interview-curriculum resource and its static publishability test; no native problem/reference/test/SDK/runner changes. Existing native catalog oracle retained; updated metadata unit rerun,private distribution rebuilt,coinstall and full frontend/both builds revalidated.')
(r/'integration-proof/native-input-reuse.json').write_text(json.dumps(reuse,indent=2)+'\n')
for name,sha in source.items():assert digest(repo/'packages/stridetorch/src/stridetorch'/name)==sha
for name,sha in live.items():assert digest(repo/'web/public/data'/name)==sha
snapshot=dict(before=a,after=b,paths={name:digest(repo/name) for name in paths},receipts='main-sync-proof/receipts.json',source_resources_identical=50,export_identities_identical=161,scope='Retained18 upstream metadata/UI/test files. Full frontend and both builds,updated metadata unit,private wheel/sdist/coinstall checked. Runtime source,78-problem catalog,SDK,dependencies,release rules and maintained WASM drivers unchanged; in-flight full WASM remains bound to identical inputs.')
(r/'upstream-syncs.json').write_text(json.dumps([snapshot],indent=2)+'\n');print('UPSTREAM18_TERMINAL0',flush=True)
