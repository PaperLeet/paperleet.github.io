from pathlib import Path
import gzip,hashlib,json,os,pickle,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results';out.mkdir(exist_ok=True)
def read(name):return json.loads((r/name).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
source=repo/'packages/stridetorch/src/stridetorch';actual={p.name:sha(p) for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
plan=read('proof/chrome-contracts/plan.json');tests={p.name:sha(p) for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'}
assert len(actual)==50 and actual==read('proof/source-hashes.json')==plan['source'];assert len(tests)==42 and tests==plan['tests'] and plan['expected']==3977
full=read('full-root-receipt.json');assert full['exit_code']==0 and full['passed']==37605 and full['skipped']==1
assert '2395 passed' in (r/'focused-final.log').read_text()
gates=read('proof/gate-receipts.json');assert len(gates)==6 and all(v['exit_code']==0 for v in gates.values())
node=read('proof/source-wasm.json');chrome=read('proof/chrome-contracts/result.json');wheel=read('proof/wheel-stride044-result.json');coinstall=read('proof/coinstall-result.json')
assert node['passed']==chrome['passed']==3977 and chrome['test_hashes']==tests
assert node['source_hashes']==chrome['source_hashes']==wheel['source_hashes']==coinstall['source_hashes']==actual
assert all(v['status']=='success' for v in (chrome,wheel,coinstall)) and not wheel['native_torch']
assert '3990 passed' in (r/'proof/python310-stride044-tests.log').read_text();assert node['numpy']=='2.2.5' and node['library']=='0.44.0'
numeric={name:read(f'native-compare-{name}-receipt.json') for name in ('auto','scan','window','block','separable')}
assert all(x['status']=='passed' and x['trials']==236 and x['source_hashes']==actual for x in numeric.values())
with (r/'native-reference.pkl').open('rb') as f:reference=pickle.load(f)
numeric_scope=dict(per_algorithm_trials=len(reference),random_valid=sum('value' in x for x in reference[:220]),random_invalid=sum('error' in x for x in reference[:220]),random_derivative_trials=sum('grad' in x for x in reference[:220]),dtype_inference_trials=len(reference)-220,total_trials=5*len(reference))
performance=read('performance-summary.json');assert performance['status']=='success' and performance['children']==12 and all(v['exit_code']==0 for v in performance['receipts'].values())
baseline=read('baseline.json');assert len(baseline['source'])==50
for name in ('bench_max_pooling_1d.py','bench_max_pooling_3d.py','bench_pooling_separable.py'):assert (r/name).read_bytes()==(repo/'packages/stridetorch/benchmarks'/name).read_bytes()
for runtime in ('cpu','node','chrome'):
 for repeat in range(4):
  row=read(f'performance/{runtime}-{repeat}.json');assert row['status']=='success' and len(row['results'])==76 and row['source_hashes']==dict(baseline=baseline['source'],candidate=actual)
  assert row['baseline_version']=='0.43.0' and row['candidate_version']=='0.44.0'
native=read('integration-proof/native-ci.json');wasm=read('integration-proof/full-wasm-result.json')
assert native['passed'] and native['problems']==78 and native['tests_executed']==10218 and native['duration_s']<=600 and native['repeats']==3 and not native['issues']
assert sum(map(len,native['mutation'].values()))==342 and all(hit for rows in native['mutation'].values() for hit in rows.values())
assert wasm['passed'] and wasm['catalog_modules']==wasm['modules']==78 and not wasm['browser_budget_exceeded']
assert sum(v['mutants'] for v in wasm['results'])==342 and all(v['passed'] and not v['browser_budget_exceeded'] for v in wasm['results'])
contracts=next(v for v in wasm['results'] if v['id']=='architecture/attention')['independent_contracts'];assert contracts['passed']==3977 and len(contracts['suites'])==42
assert {v['suite']:v['source_sha256'] for v in contracts['suites']}==tests
assert contracts['runtime_profiles'][0]['supplemented_files']==[]
assert contracts['runtime_profiles'][1]['supplemented_files']==[dict(name='stridetorch/_legacy.py',source_sha256=actual['_legacy.py'])]
setup=read('integration-proof/setup-receipts.json');front=read('integration-proof/frontend-receipts.json');assert len(setup)==4 and len(front)==5 and all(v['exit_code']==0 for v in setup+front)
exports=read('integration-proof/export-identity.json');snapshot=read('integration-proof/release-snapshot.json')
assert exports['published_assets_unchanged']==9913 and exports['active_assets']==exports['new_assets']==158 and exports['all_new_assets_reachable'];assert snapshot['source_hashes']==actual
assert read('integration-proof/distribution-identity.json')['status']=='success'
native_reuse=read('integration-proof/native-input-reuse.json')
for name,digest in native_reuse['files'].items():assert sha(repo/name)==digest
assert native_reuse['status']=='unchanged_native_inputs'
live=read('integration-proof/live-expected-sha256.json');assert len(live)==161
for name,digest in live.items():assert sha(repo/'web/public/data'/name)==digest
harness=read('integration-proof/wasm-harness-identity.json');assert sha(repo/harness['file'])==harness['sha256'] and sha(repo/harness['driver_file'])==harness['driver_sha256']
policy=read('release-policy-identity.json');assert policy['status']=='unchanged'
for name,digest in policy['files'].items():assert sha(repo/name)==digest
syncs=read('upstream-syncs.json');latest={}
for sync in syncs:
 for name,digest in sync['paths'].items():
  assert hashlib.sha256(subprocess.check_output(['git','show',sync['after']+':'+name],cwd=repo)).hexdigest()==digest;latest[name]=digest
 if 'receipts' in sync:assert all(row['exit_code']==0 for row in read(sync['receipts']))
for name,digest in latest.items():assert sha(repo/name)==digest
changed={name for name,digest in baseline['source'].items() if actual.get(name)!=digest};assert changed=={'__init__.py','_pooling.py','_pooling3d.py'} and set(actual)==set(baseline['source'])
report=dict(status='validated_locally',version='0.44.0',source_hashes=actual,baseline=baseline,unchanged_resources=47,changed_resources=sorted(changed),full_cpu=full,focused_pooling=2395,focused_3d=675,native_reference=read('native-reference-receipt.json'),native_differential=numeric,native_differential_scope=numeric_scope,node_wasm=node,chrome_worker=chrome,minimal_wheel=wheel,coinstall=coinstall,performance=performance,source_footprint=read('source-footprint.json'),release_policy=policy,upstream_syncs=syncs)
integration=dict(status='validated_locally',version='0.44.0',native=native,wasm=wasm,frontend=front,setup=setup,export_identity=exports,release_snapshot=snapshot,live_export_sha256=live,source_hashes=actual,distribution=read('integration-proof/distribution-identity.json'),wasm_harness=harness,runtime_sizes=read('integration-proof/runtime-sizes.json'),native_input_reuse=native_reuse)
save(out/'iteration-44.json',report);save(out/'iteration-44-integration.json',integration)
metadata=r/'package-metadata';metadata.mkdir(exist_ok=True)
for name in ('README.md','pyproject.toml','LICENSE','NOTICE'):shutil.copy2(repo/'packages/stridetorch'/name,metadata/name)
shutil.copy2(repo/'packages/stridetorch/tests/test_standalone.py',metadata/'test_standalone.py')
archives={}
for name,folder,excluded in [('iteration-44-harness.tar.gz',r,{'integration-proof','proof','performance'}),('iteration-44-integration-harness.tar.gz',r/'integration-proof',{'dist-paperleet','live-expected'}),('iteration-44-runtime-harness.tar.gz',r/'proof',set()),('iteration-44-performance-harness.tar.gz',r/'performance',set())]:
 target=out/name
 with tarfile.open(target,'w:gz') as archive:
  for current,dirs,names in os.walk(folder):
   dirs[:]=[d for d in dirs if d not in excluded and d not in ('__pycache__','.pytest_cache') and not d.endswith(('-env','-venv'))]
   for name0 in sorted(names):
    path=Path(current)/name0
    if not path.is_symlink() and (path.name in ('LICENSE','NOTICE') or path.suffix in ('.py','.mjs','.json','.log','.md','.html','.toml','.pkl','.txt')):archive.add(path,arcname=str(path.relative_to(folder)),recursive=False)
 archives[name]=dict(sha256=sha(target),bytes=target.stat().st_size)
report['raw_archives']=archives;save(out/'iteration-44.json',report)
save(r/'state.json',dict(status='local_gates_passed',version='0.44.0',source_hashes=actual,export_sha256=live,all_owned_children_terminal=True,main_adoption_pending=True))
print('PASS0.44 exact local proof:50resources,3977Node/Chrome,37605CPU,3990minimum,1180native trials,78/342catalog,76flowsx12children',flush=True)
