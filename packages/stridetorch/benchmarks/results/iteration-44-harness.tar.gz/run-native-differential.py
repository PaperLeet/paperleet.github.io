from pathlib import Path
import subprocess,json
r=Path(__file__).resolve().parent;py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';native='/Users/david/Developer/PaperLeet-public/.venv/bin/python'
with (r/'native-reference.log').open('w') as log:subprocess.check_call([native,str(r/'native-differential.py'),'reference'],stdout=log,stderr=subprocess.STDOUT)
for algorithm in ('auto','scan','window','block','separable'):
 with (r/f'native-{algorithm}.log').open('w') as log:subprocess.check_call([str(py),str(r/'native-differential.py'),'compare','--algorithm',algorithm],stdout=log,stderr=subprocess.STDOUT)
 report=json.loads((r/f'native-compare-{algorithm}-receipt.json').read_text());assert report['source_hashes']==json.loads((r/'proof/source-hashes.json').read_text());print(algorithm,'PASS236',flush=True)
