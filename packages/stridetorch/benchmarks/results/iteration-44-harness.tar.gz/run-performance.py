from pathlib import Path
import hashlib,json,os,statistics,subprocess,time
r=Path(__file__).resolve().parent;out=r/'performance';out.mkdir(exist_ok=True)
py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';expected=json.loads((r/'proof/source-hashes.json').read_text());receipts={}
env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
assert json.loads((r/'full-root-receipt.json').read_text())['exit_code']==0
assert json.loads((r/'integration-proof/wasm-receipt.json').read_text())['exit_code']==0
assert len(json.loads((r/'integration-proof/frontend-receipts.json').read_text()))==5
assert all(row['exit_code']==0 for row in json.loads((r/'integration-proof/frontend-receipts.json').read_text()))
for sync in json.loads((r/'upstream-syncs.json').read_text()):
 if 'receipts' in sync:assert all(row['exit_code']==0 for row in json.loads((r/sync['receipts']).read_text()))
initial_load=os.getloadavg()
for repeat in range(4):
 for runtime in (('cpu','node','chrome') if repeat%2==0 else ('chrome','node','cpu')):
  name=f'{runtime}-{repeat}';output=out/(name+'.json');reverse=['--reverse'] if repeat%2 else []
  args=([str(py),str(r/'bench_pooling_separable.py'),'--baseline-source',str(r/'baseline-source/stridetorch'),'--candidate-source',str(r/'proof/source'),'--samples','7','--iterations','40','--output',str(output)]+reverse) if runtime=='cpu' else ['/opt/homebrew/bin/node',str(r/('bench-wasm.mjs' if runtime=='node' else 'bench-chrome.mjs')),str(output)]+reverse
  started=time.monotonic()
  with (out/(name+'.log')).open('w') as log:result=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  receipts[name]=dict(exit_code=result.returncode,elapsed_s=time.monotonic()-started,args=args);(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');result.check_returncode()
  report=json.loads(output.read_text());assert report['status']=='success' and len(report['results'])==76 and report['source_hashes']['candidate']==expected
  assert report['baseline_version']=='0.43.0' and report['candidate_version']=='0.44.0'
  print(name,'PASS76',round(receipts[name]['elapsed_s'],2),flush=True)
summary={}
for runtime in ('cpu','node','chrome'):
 reports=[json.loads((out/f'{runtime}-{repeat}.json').read_text()) for repeat in range(4)]
 rows=[]
 for case in range(76):
  first=reports[0]['results'][case];row={key:first[key] for key in ('dtype','kind','mode')};times={name:[x['results'][case]['timings'][name]['median_us'] for x in reports] for name in first['timings']}
  row.update(median_us={name:statistics.median(values) for name,values in times.items()},all_child_median_us=times)
  row['direct_time_reduction_percent']=100*(1-row['median_us']['candidate_direct']/row['median_us']['baseline_direct'])
  row['control_time_reduction_percent']=100*(1-row['median_us']['candidate_control']/row['median_us']['baseline_direct']);rows.append(row)
 summary[runtime]=rows
(r/'performance-summary.json').write_text(json.dumps(dict(status='success',children=len(receipts),receipts=receipts,summary=summary,load_average_before=initial_load,load_average_after=os.getloadavg(),scope='Four fresh processes/runtime,alternating order,7 samples/40 ordinary calls (5 training,4 larger-overlap);retain every sample. Shared host;no native Torch/GPU or cross-runtime speed claim.'),indent=2)+'\n')
