from pathlib import Path
import subprocess,shutil,json,hashlib
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');p=r/'integration-proof';py=r.parent/'torch-iteration-21/stride-dev-env/bin/python'
gates=json.loads((r/'proof/gate-receipts.json').read_text());assert len(gates)==6 and all(v['exit_code']==0 for v in gates.values())
old=json.loads((r/'before-small-tape-tuning/integration-proof/live-expected-sha256.json').read_text())
owned=[name for name in old if name.startswith(('browser-judge/','modules/'))];assert len(owned)==158
cached=set(subprocess.check_output(['git','ls-files','-z','--','web/public/data'],cwd=repo).decode().split('\0'))
for name in owned:
 file=repo/'web/public/data'/name;assert 'web/public/data/'+name not in cached;assert hashlib.sha256(file.read_bytes()).hexdigest()==old[name]
for name in owned:(repo/'web/public/data'/name).unlink()
(p/'retired-local-prototype-assets.json').write_text(json.dumps(dict(scope='158 owned/untracked preliminary0.44 payloads,bytes retained in before-small-tape-tuning/integration-proof/live-expected; all9913 prior tracked payloads preserved',assets={name:old[name] for name in owned}),indent=2)+'\n')
shutil.copytree(r/'proof/private-dist',p/'dist-paperleet',dirs_exist_ok=True)
subprocess.check_call([str(py),str(p/'run-setup.py')],cwd=repo)
expected=json.loads((r/'proof/source-hashes.json').read_text())
for name,digest in expected.items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==digest
receipts=json.loads((p/'setup-receipts.json').read_text());assert len(receipts)==3 and all(v['exit_code']==0 for v in receipts);receipts.append(dict(script='exact-source-recheck',exit_code=0,resources=len(expected)));(p/'setup-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
print('SETUP4_TERMINAL0',flush=True)
