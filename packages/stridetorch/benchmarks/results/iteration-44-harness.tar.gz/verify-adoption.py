from pathlib import Path
import datetime,hashlib,json,subprocess
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');source=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-44-main-adoption.json').read_text())['source_commit'];proof=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
assert git('rev-parse','HEAD')==proof and git('ls-remote','origin','refs/heads/main').split()[0]==proof
assert not git('status','--porcelain')
assert git('rev-parse','HEAD^')==source
resource=json.loads((r/'proof/source-hashes.json').read_text());exports=json.loads((r/'integration-proof/live-expected-sha256.json').read_text());policy=json.loads((r/'release-policy-identity.json').read_text())
for name,digest in resource.items():
 path='packages/stridetorch/src/stridetorch/'+name;assert hashlib.sha256((repo/path).read_bytes()).hexdigest()==digest
 assert hashlib.sha256(subprocess.check_output(['git','show',source+':'+path],cwd=repo)).hexdigest()==digest
for name,digest in exports.items():assert hashlib.sha256((repo/'web/public/data'/name).read_bytes()).hexdigest()==digest
for name,digest in policy['files'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
rows=subprocess.check_output(['git','ls-files','-z','--','web/public/data/browser-judge','web/public/data/modules'],cwd=repo).split(b'\0');assert len(rows)-1==10071
counts={}
for head in (source,proof):
 result=json.loads(subprocess.check_output(['gh','api',f'repos/PaperLeet/paperleet.github.io/actions/runs?head_sha={head}&per_page=100'],cwd=repo,text=True));assert result['total_count']==0;counts[head]=result['total_count']
proof_diff=git('diff','--name-only',source,proof).splitlines();assert proof_diff==['docs/validation/torch-runtime-iteration-44.md','packages/stridetorch/benchmarks/results/iteration-44-main-adoption.json']
identity=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-44-main-adoption.json').read_text());assert identity['source_commit']==source and identity['source_resources']==resource and identity['active_export_sha256']==exports
report=dict(status='adopted_on_main',version='0.44.0',source_commit=source,proof_commit=proof,observed_remote_main=proof,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actions_runs_by_sha=counts,source_resources=len(resource),active_export_identities=len(exports),immutable_payloads=10071,canonical_release_policies=len(policy['files']),clean_worktree=True,all_owned_children_terminal=True,scope='Exact final main/source/proof identity verification; no tag,dispatch,release,package upload or deployment initiated by this work. Overall library-efficiency/core-coverage/backend goal remains active.')
(r/'final-adoption-verification.json').write_text(json.dumps(report,indent=2)+'\n');state=json.loads((r/'state.json').read_text());state.update(report,main_adoption_pending=False);(r/'state.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(report),flush=True)
