from pathlib import Path
import json
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
proof=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-46.json').read_text());integration=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-46-integration.json').read_text());perf=proof['performance']['summary']
def row(runtime,kind,mode,dtype):return next(x for x in perf[runtime] if (x['kind'],x['mode'],x['dtype'])==(kind,mode,dtype))
lines=['# Torch runtime iteration 46: ordered inverse pooling adjoints','',
'## Result and bounds','',
'Version 0.46 optimizes fixed/adaptive 3D average-pooling backward. Seeds are scaled once, then gathered by input position and accumulated in native output Z/Y/X order. Public module/function signatures, mutation guards, float32/float64 VJP/JVP/reverse-over-forward, aliases and checkpoint behavior remain available.','',
'The direct baseline is adopted 0.45 source 7f98aebde57b6afc3486d0d55baef9956eba2379, with proof/main 8bfd8c5f74f493011b8f07beb44526054a555e5e. Forty-nine of 51 source/license resources are unchanged; only init/version and the 3D average implementation change.','',
'A separate 32-entry inverse-geometry cache holds readonly arrays and bounded immutable coordinate-byte keys. Each optional gather-index/mask plan is at most 128 KiB. No cache stores tensors or seed values. Admission checks input-axis construction, the full scaled seed copy and packing estimates before allocation. Nominal inverse work over twice scatter work retains the previous adjoint; forced-inverse tests cover those shapes independently. Selected inverse calls avoid allocating a discarded zero-gradient buffer; exact disjoint blocks fill an empty result directly.','',
'The 32 MiB workspace estimate excludes required input/output storage and resident cache metadata. It is not a measured total-process-memory limit. Oversized plans retain bounded loop/scatter paths; large-axis rejection is tested before coordinate allocation.','',
'## Verification','',
'| Check | Observed result |','|---|---|',
f"| Full CPU repository/package tests | {proof['full_cpu']['passed']:,} passed, {proof['full_cpu']['skipped']} skipped; {proof['full_cpu']['elapsed_s']:.2f} s |",
'| Targeted 3D pooling | 925 tests; five forward/backward route pairs |',
'| Native PyTorch 2.14.1 | 155 cases, five adapter routes, 3,715 arrays |',
'| Node/Pyodide and actual Chrome Worker | 4,902 independent contracts each; 43 suites |',
'| Installed public wheel | Python 3.10.19 / NumPy 1.26.4; 4,915 tests; native Torch absent |',
'| Distribution ownership | All 51 resources identical; coinstallation, aliases, checkpoint resume and independent uninstall survival |',
f"| Native original catalog | 78 problems, 10,218 executions, 342 mutants, three repeats; {integration['native']['duration_s']:.3f} s < 600 s |",
f"| Exported WASM application | 78/78, 342 mutants, 4,902 independent contracts; {json.loads((r/'integration-proof/wasm-receipt.json').read_text())['elapsed_s']:.3f} s |",
'| Frontend | Complete npm check, driver/policy checks, normal and current Pages-profile builds |',
'| Identities | 161 active export hashes; 10,229 prior immutable payloads preserved, 158 reachable payloads added |','',
'Native comparisons include CDHW/NCDHW, contiguous/Fortran/strided/channels-last inputs and seeds, local NaN/Inf, empty global input, dtype/shape boundaries, VJP, JVP and reverse-tangent differentiation. New cancellation-sensitive gradient seeds are checked against native Torch and the prior scatter order. Exact output strides and non-singleton leaf-gradient strides agree. Existing singleton-gradient-stride and ill-conditioned global-mean differences remain scoped as in 0.45; no cross-platform bitwise promise is added. The native catalog uses CI-style OMP/MKL/OpenBLAS/Accelerate thread caps of two. Its elapsed time is a budget check, not a backend speed comparison.','',
'## Complete-flow timings','',
'Direct 0.45 is compared with 0.46 and an independent same-source inverse-disabled control. Four fresh processes per CPU/Node/Chrome runtime alternate order. Five samples per flow contain 12 ordinary calls or three training steps. All 46 flows check values/gradients or a complete SGD update and record selected/fallback inverse calls before timing.','',
'Percent elapsed-time reduction versus direct 0.45; negative means slower. CNN flows contain Conv3d, SiLU, fixed downsampling, adaptive pooling, Linear, loss/backward and SGD.','',
'| Flow | Dtype | CPU | Node/WASM | Chrome/WASM |','|---|---|---:|---:|---:|']
for kind,mode in [('overlap','backward'),('upsample','backward'),('irregular','backward'),('fixed','backward'),('cnn_upsample','training'),('cnn_irregular','training'),('cnn','training')]:
 for dtype in ('float32','float64'):
  vals=[row(rt,kind,mode,dtype)['direct_time_reduction_percent'] for rt in ('cpu','node','chrome')]
  lines.append('| '+kind+' / '+mode+' | '+dtype+' | '+' | '.join(f'{v:.1f}%' for v in vals)+' |')
lines+=['','Every sample, child median and control is retained. Unselected paths/general CNNs have no uniform speedup; fallback overhead and shared-host/GC variation remain visible. Results support the measured overlapping/upsampling adjoints, not native Torch/GPU or cross-runtime performance claims.','',
'## Footprint and reproduction','',
'| Measure | 0.45 | 0.46 |','|---|---:|---:|']
for key,title in [('raw_source_license_bytes','Source/license bytes'),('local_concatenated_gzip_bytes','Local concatenated gzip estimate')]:lines.append(f"| {title} | {proof['source_footprint']['baseline'][key]:,} | {proof['source_footprint']['candidate'][key]:,} |")
lines+=['','These are source-concatenation estimates, not wheel size, network transfer or peak memory. Repository tool: [bench_average_pooling_inverse.py](../../packages/stridetorch/benchmarks/bench_average_pooling_inverse.py), importing the neighboring bench_average_pooling_3d.py helper. Pass baseline/candidate source directories, output path and optional samples/iterations/reverse order. [Machine-readable reports and four harness archives](../../packages/stridetorch/benchmarks/results/) retain exact source/test/export/dependency/distribution identities, native arrays and all timing samples.','',
'The numerically correct but slower per-plane prototype and initial packed versions remain in the local prototype-stage archive. All formal gates/timings are repeated on the final 0.46 identities. Seven release-policy files remain byte-identical to canonical commit 13d2782a494415ba72bc604a0ef7e4c4f875ba25. This work initiates no tag, workflow dispatch, release, package upload or online deployment. Broader independent-library/core-coverage/backend work remains active.','']
for sync in proof.get('upstream_syncs',[]):lines+=['## Upstream integration','',f"Retained {sync['before']} through {sync['after']}. {sync['scope']}",'']
(repo/'docs/validation/torch-runtime-iteration-46.md').write_text('\n'.join(lines))
p=repo/'packages/stridetorch/ROADMAP.md';s=p.read_text();marker='## Next implementation areas';entry='## 0.46: ordered inverse 3D pooling adjoints\n\n- Scale seeds once; gather inverse regions in native output order with bounded\n  readonly caches, cost fallback and workspace admission before allocation.\n- Avoid discarded gradient buffers and zero filling exact disjoint blocks. Keep\n  cancellation, nonfinite locality, strided seeds, JVP and reverse-tangent rules.\n- Complete CPU, installed-wheel, Node/Chrome, 78-problem application and whole-flow\n  evidence is retained; unselected paths have no universal speedup.\n- See [the 0.46 validation record](../../docs/validation/torch-runtime-iteration-46.md).\n\n'
if '## 0.46:' in s:a=s.index('## 0.46:');b=s.index(marker,a);s=s[:a]+s[b:]
p.write_text(s.replace(marker,entry+marker))
p=repo/'packages/stridetorch/benchmarks/README.md';s=p.read_text();marker='\n## Inverse volume-pooling adjoints (0.46)\n';s=s.split(marker)[0];s+=marker+'\n`bench_average_pooling_inverse.py` compares direct baseline 3D APIs with inverse\nadjoints and a same-source inverse-disabled control. It imports the neighboring\n`bench_average_pooling_3d.py` helper. Baseline/candidate source paths and output\nare required; samples/iterations/reverse order are optional. Each of 46 flows\nchecks values, gradients or SGD updates and actual route selection before timing.\nSee the [0.46 validation record](../../../docs/validation/torch-runtime-iteration-46.md).\n';p.write_text(s)
print('Wrote0.46 validation, roadmap and benchmark guide')
