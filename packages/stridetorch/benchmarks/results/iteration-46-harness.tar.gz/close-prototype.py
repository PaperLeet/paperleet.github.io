from pathlib import Path
import gzip,hashlib,json,subprocess
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
def read(name):return json.loads((r/name).read_text())
def hashes(directory):return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in directory.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
actual=hashes(r/'candidate-source/stridetorch');baseline=read('baseline.json');plan=read('proof/chrome-contracts/plan.json')
assert len(actual)==51 and actual==read('proof/source-hashes.json')==plan['source']==hashes(r/'proof/source')
assert hashes(repo/'packages/stridetorch/src/stridetorch')==baseline['source']
assert set(actual)==set(baseline['source']) and {name for name in actual if actual[name]!=baseline['source'][name]}=={'_average_pooling3d.py'}
assert '925 passed' in (r/'prototype-tests.log').read_text() and '925 passed' in (r/'prototype-python310.log').read_text()
native=read('native-differential-receipt.json');node=read('proof/source-wasm.json');chrome=read('proof/chrome-contracts/result.json')
assert native['status']=='pass' and native['cases']==155 and native['adapter_routes']==5 and native['array_comparisons']==3715
assert native['source_hashes']==node['source_hashes']==chrome['source_hashes']==actual
assert node['passed']==chrome['passed']==4902 and len(plan['tests'])==43 and chrome['test_hashes']==plan['tests']
assert plan['expected']==4902 and chrome['status']=='success'
assert hashlib.sha256((r/'tests/test_average_pooling_3d.py').read_bytes()).hexdigest()==plan['tests']['test_average_pooling_3d.py']
perf=read('performance-summary.json');assert perf['status']=='success' and perf['children']==12
for runtime in ('cpu','node','chrome'):
 for repeat in range(4):
  report=read(f'performance/{runtime}-{repeat}.json');assert len(report['results'])==46 and report['source_hashes']==dict(baseline=baseline['source'],candidate=actual)
  for row in report['results']:
   calls=row['qualification_inverse_calls']
   if row['kind'] in ('overlap','upsample','cnn_upsample') and row['mode'] in ('backward','training'):assert calls['candidate_inverse']['selected']>0
   assert calls['candidate_control']==dict(selected=0,fallback=0)
summary={}
for runtime,rows in perf['summary'].items():
 summary[runtime]=[]
 for row in rows:
  value={k:row[k] for k in ('dtype','kind','mode','median_us','direct_time_reduction_percent','control_time_reduction_percent')}
  value['inverse_vs_same_source_control_reduction_percent']=100*(1-row['median_us']['candidate_inverse']/row['median_us']['candidate_control'])
  summary[runtime].append(value)
report=dict(status='isolated_prototype_validated',release_ready=False,version='unversioned0.46 experiment, module metadata still0.45.0',source_hashes=actual,baseline=baseline,unchanged_resources=50,changed_resources=['_average_pooling3d.py'],cpu_targeted=925,python310_numpy126_source_targeted=925,node_wasm=node,chrome_worker=chrome,native_reference=native,performance=perf,summary=summary,scope='Scale each seed once, readonly bounded inverse geometry/gather caches, native output-order accumulation, cost-based auto fallback, bounded preflight and no discarded gradient-output buffer. Independent repository0.45 sources are unchanged. No installed candidate wheel, full CPU repository, native catalog or exported application integration gate has been run on this prototype; those remain required before promotion.',all_owned_prototype_children_terminal=True)
(r/'prototype-validation.json').write_text(json.dumps(report,indent=2)+'\n')
lines=['# Volumetric pooling inverse-adjoint prototype','',
'This isolated experiment targets a future 0.46 iteration. The module version is still 0.45.0; it is not a release-ready or adopted version. The repository remains on its separately validated 0.45 candidate.','',
'The first per-plane inverse loop was numerically valid but slower. The current path divides each output seed once, then gathers contributions in native output Z/Y/X order through readonly inverse coordinates and optional flat indices. Both geometry caches are bounded to 32 entries; each gather index/mask plan is at most 128 KiB. Input-coordinate allocation, seed-copy bytes and packing estimates are checked before admission. A nominal inverse-work/scatter-work ratio rejects unprofitable shapes; private forced-inverse tests still cover them. Full-block adjoints fill an empty result directly, and selected inverse calls avoid allocating a discarded zero-gradient buffer. The workspace estimate is not a measured total-memory limit.','',
'## Evidence','',
'- 925 targeted CPU tests and 925 targeted source tests on Python 3.10 / NumPy 1.26.4.','- 155 native Torch 2.14.1 cases across five routes: 3,715 array comparisons, including cancellation-sensitive seeds.','- 4,902 independent contracts / 43 suites in both actual Node/Pyodide and Chrome Worker/Pyodide.','- 46 complete direct-3D flows; four fresh processes per CPU/Node/Chrome runtime, five samples per flow and alternating order. Values/gradients or one complete SGD update and actual route selection are checked before timing. Same-source inverse-disabled controls are retained.','',
'## Elapsed-time reduction versus direct 0.45','',
'| Case | Dtype | CPU | Node/WASM | Chrome/WASM |','|---|---|---:|---:|---:|']
for kind,mode in [('overlap','backward'),('upsample','backward'),('irregular','backward'),('cnn_upsample','training'),('cnn_irregular','training'),('cnn','training')]:
 for dtype in ('float32','float64'):
  vals=[next(x for x in summary[rt] if (x['kind'],x['mode'],x['dtype'])==(kind,mode,dtype))['direct_time_reduction_percent'] for rt in ('cpu','node','chrome')]
  lines.append('| '+kind+' / '+mode+' | '+dtype+' | '+' | '.join(f'{v:.1f}%' for v in vals)+' |')
lines+=['','Negative values mean slower. Unselected paths have no uniform improvement; shared-host/GC variation and fallback overhead remain visible in every child sample and the same-source controls. Full native/repository/catalog/installed-wheel/exported-application gates and formal versioning are still required before this implementation can replace the repository runtime.','',
'The prior per-plane implementation and initial packed implementation are retained under `prototype-history/`. Source identities, native arrays, contract logs and every timing sample are preserved beside this report. No CI, tag, workflow dispatch, package upload or deployment was initiated for this experiment.','']
(r/'prototype-report.md').write_text('\n'.join(lines))
(r/'state.json').write_text(json.dumps(dict(status='prototype_validated_promotion_pending',release_ready=False,source_hashes=actual,baseline_source_hashes=baseline['source'],all_owned_children_terminal=True,next='After0.45 main adoption, port this candidate and tests into repository, assign0.46 version, freeze new identities and run full repository/installed-wheel/exported-catalog/frontend gates plus timings before any main adoption.'),indent=2)+'\n')
print('PROTOTYPE PASS:925CPU/minimum-source,4902Node/Chrome,3715native arrays,46flowsx12children; repository0.45 unchanged')
