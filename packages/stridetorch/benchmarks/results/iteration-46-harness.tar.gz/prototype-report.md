# Volumetric pooling inverse-adjoint prototype

This isolated experiment targets a future 0.46 iteration. The module version is still 0.45.0; it is not a release-ready or adopted version. The repository remains on its separately validated 0.45 candidate.

The first per-plane inverse loop was numerically valid but slower. The current path divides each output seed once, then gathers contributions in native output Z/Y/X order through readonly inverse coordinates and optional flat indices. Both geometry caches are bounded to 32 entries; each gather index/mask plan is at most 128 KiB. Input-coordinate allocation, seed-copy bytes and packing estimates are checked before admission. A nominal inverse-work/scatter-work ratio rejects unprofitable shapes; private forced-inverse tests still cover them. Full-block adjoints fill an empty result directly, and selected inverse calls avoid allocating a discarded zero-gradient buffer. The workspace estimate is not a measured total-memory limit.

## Evidence

- 925 targeted CPU tests and 925 targeted source tests on Python 3.10 / NumPy 1.26.4.
- 155 native Torch 2.14.1 cases across five routes: 3,715 array comparisons, including cancellation-sensitive seeds.
- 4,902 independent contracts / 43 suites in both actual Node/Pyodide and Chrome Worker/Pyodide.
- 46 complete direct-3D flows; four fresh processes per CPU/Node/Chrome runtime, five samples per flow and alternating order. Values/gradients or one complete SGD update and actual route selection are checked before timing. Same-source inverse-disabled controls are retained.

## Elapsed-time reduction versus direct 0.45

| Case | Dtype | CPU | Node/WASM | Chrome/WASM |
|---|---|---:|---:|---:|
| overlap / backward | float32 | 35.4% | 26.3% | 26.4% |
| overlap / backward | float64 | 38.9% | 29.2% | 31.6% |
| upsample / backward | float32 | 30.5% | 23.9% | 25.1% |
| upsample / backward | float64 | 34.0% | 35.3% | 26.2% |
| irregular / backward | float32 | -2.2% | 1.3% | -3.7% |
| irregular / backward | float64 | -2.3% | -1.1% | -2.1% |
| cnn_upsample / training | float32 | 5.6% | 7.4% | 8.6% |
| cnn_upsample / training | float64 | 8.8% | 7.6% | 7.0% |
| cnn_irregular / training | float32 | -1.5% | 0.7% | 1.2% |
| cnn_irregular / training | float64 | -0.7% | 0.9% | -1.3% |
| cnn / training | float32 | 1.4% | -2.0% | 1.3% |
| cnn / training | float64 | 0.3% | -5.0% | 8.0% |

Negative values mean slower. Unselected paths have no uniform improvement; shared-host/GC variation and fallback overhead remain visible in every child sample and the same-source controls. Full native/repository/catalog/installed-wheel/exported-application gates and formal versioning are still required before this implementation can replace the repository runtime.

The prior per-plane implementation and initial packed implementation are retained under `prototype-history/`. Source identities, native arrays, contract logs and every timing sample are preserved beside this report. No CI, tag, workflow dispatch, package upload or deployment was initiated for this experiment.
