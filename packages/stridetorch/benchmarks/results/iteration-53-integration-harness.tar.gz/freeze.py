from pathlib import Path
import gzip,hashlib,json,shutil,subprocess
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');data=repo/'web/public/data'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,obj):(r/name).write_text(json.dumps(obj,indent=2)+'\n')
subprocess.run(['/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-21/stride-dev-env/bin/python',str(r/'verify-export.py')],cwd=repo,check=True,stdout=subprocess.DEVNULL)
index=json.loads((data/'index.json').read_text());names={'catalog.json','index-v3.json','index.json'};runtimes=set()
for entry in index['problems']:
 names.update([entry['detail_url'],entry['browser_judge']['bundle_url']]);payload=json.loads((data/entry['browser_judge']['bundle_url']).read_text());runtimes.add(payload['runtime_bundle_url'])
names.update(runtimes);assert len(names)==161
for name in names:
 target=r/'live-expected'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(data/name,target)
hashes={name:digest(data/name) for name in sorted(names)};save('live-expected-sha256.json',hashes)
save('release-snapshot.json',dict(version='0.53.0',files=len(names),source_hashes=json.loads((r/'context.json').read_text())['source_hashes'],export_sha256=hashes))
sizes={}
for name in sorted(runtimes):
 raw=(data/name).read_bytes();payload=json.loads(raw);files=payload['files'];package=[p for p in files if p.startswith('stridetorch/')]
 sizes[name]=dict(backend=payload['backend'],raw_bytes=len(raw),local_gzip_estimate_bytes=len(gzip.compress(raw,mtime=0)),sha256=digest(data/name),python_modules=sum(p.endswith('.py') for p in files),files=len(files),package_python_modules=sum(p.endswith('.py') for p in package),package_files=len(package),compatibility_files=sorted(set(files)-set(package)))
save('runtime-sizes.json',sizes)
plan=json.loads((r.parent/'proof/chrome-contracts/plan.json').read_text())
tests={p.name:digest(p) for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'}
assert len(tests)==50 and plan['expected']==6635 and tests==plan['tests']
harness=dict(status='frozen_before_complete_run',file='web/scripts/check-browser-wasm.mjs',driver_file='web/scripts/wasm-cases.mjs',expected_passed=6635,expected_suites=50,test_hashes=tests,requested_concurrency=2)
harness['sha256']=digest(repo/harness['file']);harness['driver_sha256']=digest(repo/harness['driver_file']);save('wasm-harness-identity.json',harness)
shutil.copy2(repo/harness['file'],r/'maintained-check-browser-wasm.mjs')
old=json.loads((r.parent.parent/'torch-iteration-41/integration-proof/owned-dependencies.json').read_text())
assert not (repo/'web/node_modules').is_symlink();actual={p.name:digest(p) for p in (repo/'web/node_modules/pyodide').iterdir() if p.is_file()};assert actual==old['pyodide_sha256'];assert digest(repo/'web/package-lock.json')==old['lock_sha256']
old.update(scope='Reused owned npm-ci tree from iteration27;all14Pyodide files and lockfile rechecked before iteration44 integration',reverified_for='0.53.0');save('owned-dependencies.json',old)
print(json.dumps(dict(status='frozen',files=len(names),runtime_sizes=sizes),indent=2))
