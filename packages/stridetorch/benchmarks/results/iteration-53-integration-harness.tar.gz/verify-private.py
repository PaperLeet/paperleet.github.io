from pathlib import Path
import hashlib,json,tarfile,zipfile

repo=Path('/Users/david/Developer/PaperLeet-torch-release');root=Path(__file__).parent;baseline=root.parent/'proof'
expected=json.loads((baseline/'source-hashes.json').read_text())
wheel=next((root/'dist-paperleet').glob('*.whl'))
sdist=next((root/'dist-paperleet').glob('*.tar.gz'))
standalone=next((root.parent/'proof/dist-preflight').glob('*.whl'))
with zipfile.ZipFile(wheel) as archive:
    private={name for name in archive.namelist() if name.endswith('.py')}
    for name,digest in expected.items():
        assert hashlib.sha256(archive.read('paperleet/_vendor/torch/'+name)).hexdigest()==digest,name
    for name in ('interview_catalog.json','server.py'):
        assert archive.read('paperleet/'+name)==(repo/'paperleet'/name).read_bytes(),name
with tarfile.open(sdist) as archive:
    for name,digest in expected.items():
        assert hashlib.sha256(archive.extractfile('paperleet-0.1.0/packages/stridetorch/src/stridetorch/'+name).read()).hexdigest()==digest,name
    for name in ('interview_catalog.json','server.py'):
        assert archive.extractfile('paperleet-0.1.0/paperleet/'+name).read()==(repo/'paperleet'/name).read_bytes(),name
with zipfile.ZipFile(standalone) as archive:
    assert not private.intersection(name for name in archive.namelist() if name.endswith('.py'))
    for name,digest in expected.items():
        assert hashlib.sha256(archive.read('stridetorch/'+name)).hexdigest()==digest,name
for name,digest in expected.items():
    assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==digest,name
report=dict(status='success',version='0.53.0',core_modules=55,all_57_core_license_hashes_identical=True,
            installed_paths_disjoint=True,latest_application_catalog_and_server_identical=True,
            artifacts={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (wheel,sdist,standalone)})
(root/'distribution-identity.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
