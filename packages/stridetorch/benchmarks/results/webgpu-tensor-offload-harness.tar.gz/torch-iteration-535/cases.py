"""Shared deterministic layouts/inputs; reference math is performed by native Torch."""
import hashlib
import numpy as np

def specs():
 rows=[]
 for shape in [(3,5,4),(37,53,29),(64,64,64)]:
  for layout in ['C','F','slice']:
   for activity in ['none','left','right','both']:rows.append(dict(shape=shape,layout=layout,activity=activity,alias=False))
 for shape in [(256,256,256),(512,512,512),(1024,512,512)]:
  for activity in ['none','left','right','both']:rows.append(dict(shape=shape,layout='C',activity=activity,alias=False))
 for layout in ['C','F','slice']:rows.append(dict(shape=(37,37,37),layout=layout,activity='both',alias=True))
 return rows

def array(rows,cols,offset,layout):
 value=((np.arange(rows*cols,dtype='float32')%17-8)*.0625+offset).reshape(rows,cols)
 if layout=='F':return np.array(value,order='F')
 if layout=='slice':
  storage=np.empty((rows,cols*2),dtype='float32');storage[:,::2]=value;return storage[:,::2]
 return value

def exercise(api,spec,operation):
 m,k,n=spec['shape'];layout=spec['layout'];activity=spec['activity'];aa=array(m,k,0.,layout);bb=array(k,n,.125,layout);seed=array(m,n,.0625,layout)
 fingerprints=[hashlib.sha256(v.tobytes()).hexdigest() for v in [aa,bb,seed]]
 a=api.from_numpy(aa).requires_grad_(activity in ['left','both']);b=a if spec['alias'] else api.from_numpy(bb).requires_grad_(activity in ['right','both'])
 assert a.stride()==tuple(v//aa.itemsize for v in aa.strides)
 targets=tuple({id(v):v for v in [a,b] if v.requires_grad}.values());buffers=[]
 for value in targets:value.grad=api.full_like(value,7.);buffers.append(value.grad)
 y=operation(a,b);g=api.from_numpy(seed);grads=api.autograd.grad(y,targets,g) if targets else ()
 assert all(value.grad is saved and np.all(value.grad.numpy()==7.) for value,saved in zip(targets,buffers))
 assert fingerprints==[hashlib.sha256(v.tobytes()).hexdigest() for v in [aa,bb,seed]]
 return tuple(value.detach().numpy().copy() for value in (y,*grads))

def training(api,operation):
 weight=api.tensor([[.25,.375,.5],[.125,-.25,.375]],requires_grad=True);bias=api.tensor([.125,-.125],requires_grad=True);x=api.tensor([[1.,2.,3.],[-1.,.5,.25]])
 optimizer=api.optim.SGD([weight,bias],lr=.05,momentum=.2,weight_decay=.01);values=[]
 for _ in range(5):
  optimizer.zero_grad();y=operation(x,weight.T)+bias;loss=y.sin().square().mean();loss.backward()
  values.extend(v.detach().numpy().copy() for v in [loss,weight.grad,bias.grad]);optimizer.step()
 values.extend(v.detach().numpy().copy() for v in [weight,bias]);return values
