from pathlib import Path
import hashlib,json,os,subprocess,time,traceback
r=Path(__file__).resolve().parent;b=r.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n');receipts=[]
plan=read(r/'source-plan.json');node='/Users/david/.local/share/fnm/node-versions/v22.22.1/installation/bin/node'
def verify():
 for n,h in plan['files'].items():assert sha(r/n)==h,n
try:
 assert not (r/'progress.json').exists()
 for cycle in [0,1,2]:
  verify();target=r/f'browser-result-{cycle}.json';assert not target.exists();start=time.monotonic()
  with (r/f'run-{cycle}.log').open('w') as log:
   child=subprocess.Popen([node,str(r/'run-browser.mjs'),str(cycle)],cwd=r,stdout=log,stderr=subprocess.STDOUT);write(r/'progress.json',dict(status='running',cycle=cycle,pid=child.pid,supervisor_pid=os.getpid(),receipts=receipts));code=child.wait()
  receipt=dict(cycle=cycle,exit_code=code,seconds=time.monotonic()-start,log_sha256=sha(r/f'run-{cycle}.log'));receipts.append(receipt);write(r/'receipts.json',receipts);print(json.dumps(receipt),flush=True);assert code==0,(cycle,(r/f'run-{cycle}.log').read_text()[-2000:]);verify()
  report=read(target);rows=report['numerical']['rows'];assert len(rows)==4
  ledger=[json.loads(line.removeprefix('BROWSER OFFLOAD_SAMPLE ')) for line in (r/f'run-{cycle}.log').read_text().splitlines() if line.startswith('BROWSER OFFLOAD_SAMPLE ')]
  assert ledger==rows,(cycle,'durable row ledger mismatch')
 write(r/'progress.json',dict(status='completed',receipts=receipts));print('Completed all three fresh browser timing processes',flush=True)
except BaseException as error:write(r/'progress.json',dict(status='failed',error=str(error),traceback=traceback.format_exc(),receipts=receipts));raise
