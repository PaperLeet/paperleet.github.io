import gc,itertools,json,math,statistics,time
import numpy as np
import stridetorch
from pyodide.ffi import run_sync
from js import matrix_rpc
import torch_workload as workloads
from torch_bridge import MatmulOffload

config=json.load(open('/config.json'));cycle=int(_cycle);assert cycle in config['cycles'] and gc.isenabled()
assert stridetorch.__version__=='0.83.0'
limits=json.loads(_limits_json);assert limits==dict(bytes=33554432,matrixBytes=4194304,dimension=1024,macs=268435456,handles=24,pending=8,requests=4096,leaseMs=120000,programInputs=8,programNodes=8,programOutputs=8)
refs=[np.load('/native26.npz',allow_pickle=False),np.load('/native214.npz',allow_pickle=False)]
initial_err,initial_handler=np.geterr(),np.geterrcall()

class OffloadStep(workloads.TorchMatrixStep):
 def __init__(self,*args,**kwargs):super().__init__(*args,**kwargs);self.offload=MatmulOffload()
 def __call__(self):
  if self.closed:raise RuntimeError('Workload closed')
  a,b,g=self.inputs if self.resident else self._tensors();y=self.offload(a,b);da,db=self.api.autograd.grad(y,(a,b),g)
  assert a.grad is None and b.grad is None
  return tuple(v.detach().numpy().copy() for v in (y,da,db))

def verify(values,index,inputs,reference=None):
 assert len(values)==3
 for value,label in zip(values,['forward','left_vjp','right_vjp']):
  assert value.dtype==np.dtype('float32') and value.flags.owndata and value.base is None
  assert all(not np.shares_memory(value,original) for original in inputs)
  for ref in refs:np.testing.assert_allclose(value,ref[f'case{index}_{label}'],rtol=config['rtol'],atol=config['atol'])
 assert all(not np.shares_memory(a,b) for i,a in enumerate(values) for b in values[i+1:])
 if reference is not None:
  for value,expected in zip(values,reference):np.testing.assert_array_equal(value,expected)

def timed(call,count):
 gc.collect();start=time.perf_counter()
 for _ in range(count):result=call()
 return time.perf_counter()-start,result

orders=list(itertools.permutations(['A0','A1','G']));offset=cycle%len(orders);orders=orders[offset:]+orders[:offset];orders+=list(reversed(orders))
shapes=list(enumerate(workloads.specifications()));shapes=shapes[cycle:]+shapes[:cycle];rows=[]
for index,shape in shapes:
 values=workloads.make_inputs(shape);fingerprint=workloads.fingerprint(values);operations={};setup={};references={};counts={};calibration={}
 try:
  for label in ['A0','A1','G']:
   start=time.perf_counter();operations[label]=(OffloadStep if label=='G' else workloads.TorchMatrixStep)(stridetorch.torch,values,resident=True);setup[label]=time.perf_counter()-start
   references[label]=operations[label]();verify(references[label],index,values)
   if label=='G':
    for _ in range(config['gpu_warmup_calls']):operations[label]()
   else:
    start=time.perf_counter()
    while time.perf_counter()-start<config['warmup_seconds']:operations[label]()
  for label in ['A0','A1','G']:
   cap=config['gpu_iteration_cap'] if label=='G' else config['cpu_iteration_cap'];count=1;samples=[]
   while True:
    elapsed,result=timed(operations[label],count);verify(result,index,values,references[label]);samples.append(dict(iterations=count,seconds=elapsed))
    if elapsed>=config['calibration_seconds'] or count>=cap:break
    count=min(cap,count*2)
   counts[label]=min(cap,max(1,math.ceil(count*config['target_batch_seconds']/elapsed)));calibration[label]=samples
  raw=[]
  for order in orders:
   samples={}
   for label in order:
    elapsed,result=timed(operations[label],counts[label]);verify(result,index,values,references[label]);samples[label]=dict(iterations=counts[label],seconds=elapsed,seconds_per_call=elapsed/counts[label])
   raw.append(dict(order=order,samples=samples))
  medians={label:statistics.median(v['samples'][label]['seconds_per_call'] for v in raw) for label in ['A0','A1','G']}
  aa=medians['A1']/medians['A0'];paired_aa=statistics.median(v['samples']['A1']['seconds_per_call']/v['samples']['A0']['seconds_per_call'] for v in raw)
  ratio=medians['G']/medians['A0'];paired_ratio=statistics.median(v['samples']['G']['seconds_per_call']/v['samples']['A0']['seconds_per_call'] for v in raw)
  floor=min(v['samples'][label]['seconds'] for v in raw for label in ['A0','A1','G'])
  stats=run_sync(matrix_rpc.stats()).to_py();assert stats['resident_handles']==stats['total_bytes']==stats['allocations']==0
  assert workloads.fingerprint(values)==fingerprint and gc.isenabled()
  row=dict(index=index,shape=shape,reused_cpu_tensor_inputs=True,gpu_residency=False,setup_seconds=setup,counts=counts,calibration=calibration,raw=raw,medians=medians,aa_ratio=aa,paired_aa_ratio=paired_aa,gpu_over_cpu_ratio=ratio,paired_gpu_over_cpu_ratio=paired_ratio,minimum_batch_seconds=floor,aa_passed=all(.95<=v<=1.05 for v in [aa,paired_aa]),floor_passed=floor>=config['minimum_batch_seconds'],normal_gc_enabled=True,resource_stats=stats,owned_outputs=True,inputs_unchanged=True,native_controls_passed=True)
  rows.append(row);print('OFFLOAD_SAMPLE '+json.dumps(row),flush=True)
 finally:
  for operation in operations.values():operation.close()
assert len(rows)==4 and gc.isenabled() and np.geterr()==initial_err and np.geterrcall() is initial_handler
report=dict(status='passed_actual_autograd_whole_call_measurement',cases=4,cycle=cycle,rows=rows,config=config,source_version=stridetorch.__version__,numpy=np.__version__,final_stats=run_sync(matrix_rpc.stats()).to_py(),latency_measured=True,automatic_dispatch_enabled=False,resident_torch_gpu_storage=False,all_aa_controls_passed=all(v['aa_passed'] for v in rows))
