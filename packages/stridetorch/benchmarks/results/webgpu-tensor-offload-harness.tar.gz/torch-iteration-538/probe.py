"""Actual host GPU forward/first-order autograd and implicit-yield controls."""
import asyncio,json
import numpy as np
from pyodide.ffi import run_sync
from js import matrix_rpc
from stridetorch import torch,__version__
import torch_bridge
from torch_bridge import MatmulOffload
import cases
assert __version__=='0.83.0'
limits=json.loads(_limits_json)
assert limits==dict(bytes=33554432,matrixBytes=4194304,dimension=1024,macs=268435456,handles=24,pending=8,requests=4096,leaseMs=120000,programInputs=8,programNodes=8,programOutputs=8)
oracles=[np.load('/native26.npz',allow_pickle=False),np.load('/native214.npz',allow_pickle=False)]
loop=asyncio.get_running_loop();offload=MatmulOffload();rows=[];controls=[]

def check(actual,key):
 for reference in oracles:
  expected=reference[key];assert actual.shape==expected.shape and actual.dtype==expected.dtype
  np.testing.assert_allclose(actual,expected,rtol=1e-5,atol=1e-6)

for i,spec in enumerate(cases.specs()):
 before=int(matrix_rpc.nextId);values=cases.exercise(torch,spec,offload)
 for j,value in enumerate(values):check(value,f'case{i}_{j}')
 count=int(matrix_rpc.nextId)-before;expected=1 if spec['activity']=='none' else 3 if tuple(spec['shape'])==(1024,512,512) and spec['activity']=='both' else 2
 assert count==expected,(i,count,expected)
 rows.append(dict(spec=spec,outputs=len(values),gpu_programs=count))
 assert not torch_bridge._busy and torch.is_grad_enabled()
for i,value in enumerate(cases.training(torch,offload)):check(value,f'training{i}')
controls.append(dict(kind='five_step_optimizer_with_nonleaf_transposed_weight',passed=True))

def fresh():return torch.ones(2,2,requires_grad=True),torch.ones(2,2,requires_grad=True)
for kind in ['input','view_alias','activity','mode','reentry']:
 a,b=fresh();a.grad=torch.full_like(a,7.);buffer=a.grad;seen=[];start=int(matrix_rpc.nextId)
 def callback():
  assert torch.is_grad_enabled()
  seen.append(dict(grad_enabled=torch.is_grad_enabled(),unrelated_requires_grad=(a*2.).requires_grad))
  if kind in ['input','view_alias']:
   with torch.no_grad():(a if kind=='input' else a.view(4)).add_(1.)
  elif kind=='activity':a.requires_grad_(False)
  elif kind=='mode':torch.set_grad_enabled(False)
  else:
   try:MatmulOffload()(a,b)
   except RuntimeError as error:assert 'already active' in str(error)
   else:raise AssertionError('Nested GPU submission was accepted')
 loop.call_soon(callback)
 try:
  result=offload(a,b)
  assert kind=='reentry','Changed state was published as a result'
 except RuntimeError as error:
  assert kind!='reentry' and 'changed' in str(error),(kind,str(error))
 finally:torch.set_grad_enabled(True)
 assert len(seen)==1 and seen[0]==dict(grad_enabled=True,unrelated_requires_grad=True)
 assert int(matrix_rpc.nextId)-start==1 and not torch_bridge._busy
 assert a.grad is buffer and buffer.tolist()==[[7.,7.],[7.,7.]]
 controls.append(dict(kind='forward_'+kind,passed=True,callback=seen[0],gpu_programs=1))

for kind in ['operand','seed']:
 a,b=fresh();result=offload(a,b);seed=torch.ones_like(result);seen=[]
 def callback():
  seen.append(True)
  with torch.no_grad():(b if kind=='operand' else seed).add_(1.)
 loop.call_soon(callback)
 try:torch.autograd.grad(result,(a,b),seed)
 except RuntimeError as error:assert ('changed' in str(error))
 else:raise AssertionError('Backward published a changed operand or seed')
 assert seen==[True] and a.grad is None and b.grad is None and not torch_bridge._busy
 controls.append(dict(kind='backward_'+kind+'_mutation',passed=True))

a,b=fresh();seen=[];stage='before';start=int(matrix_rpc.nextId)
def callback():seen.append(dict(stage=stage,grad_enabled=torch.is_grad_enabled(),unrelated_requires_grad=(a*2.).requires_grad))
loop.call_soon(callback)
with torch.no_grad():
 stage='inside_no_grad';value=offload(a,b);assert not value.requires_grad
stage='after_no_grad';run_sync(asyncio.sleep(0))
assert seen==[dict(stage='after_no_grad',grad_enabled=True,unrelated_requires_grad=True)] and int(matrix_rpc.nextId)==start
controls.append(dict(kind='no_grad_cpu_route_does_not_suspend_or_expose_temporary_mode',passed=True,callback=seen[0],gpu_programs=0))

for kind in ['jvp','hvp','float64']:
 a,b=fresh();start=int(matrix_rpc.nextId)
 if kind=='jvp':
  _,value=torch.func.jvp(lambda x:offload(x,b),(a,),(torch.ones_like(a),));np.testing.assert_array_equal(value.numpy(),np.full((2,2),2.))
 elif kind=='hvp':
  _,value=torch.autograd.functional.hvp(lambda x:offload(x,b).square().sum(),a,torch.ones_like(a));np.testing.assert_array_equal(value.numpy(),np.full((2,2),8.))
 else:np.testing.assert_array_equal(offload(a.double(),b.double()).numpy(),np.full((2,2),2.))
 assert int(matrix_rpc.nextId)==start
 controls.append(dict(kind=kind+'_cpu_fallback',passed=True,gpu_programs=0))

a,b=fresh();y=offload(a,b);y.retain_grad();y.register_hook(lambda g:g*2.);y.sum().backward()
np.testing.assert_array_equal(a.grad.numpy(),np.full((2,2),4.));np.testing.assert_array_equal(b.grad.numpy(),np.full((2,2),4.));np.testing.assert_array_equal(y.grad.numpy(),np.full((2,2),2.))
controls.append(dict(kind='real_backward_accumulation_output_hook_and_retain_grad',passed=True))

a,b=fresh();y=offload(a,b);first=torch.autograd.grad(y,(a,b),torch.ones_like(y),retain_graph=True)
with torch.no_grad():first[0].fill_(99.)
second=torch.autograd.grad(y,(a,b),torch.ones_like(y));np.testing.assert_array_equal(second[0].numpy(),np.full((2,2),2.));assert not np.shares_memory(first[0].numpy(),second[0].numpy())
try:torch.autograd.grad(y,(a,b),torch.ones_like(y))
except RuntimeError as error:assert 'second time' in str(error)
else:raise AssertionError('Consumed graph was accepted')
controls.append(dict(kind='retained_graph_fresh_gradient_buffers_and_consumption',passed=True))

# Raw NumPy writes bypass Tensor versions, including signed-zero changes.
for kind in ['forward_raw','backward_operand_raw','backward_seed_raw','signed_zero_raw']:
 a,b=fresh()
 if kind=='signed_zero_raw':a=torch.zeros(2,2,requires_grad=True)
 y=offload(a,b) if kind.startswith('backward') else None
 seed=torch.ones_like(y) if y is not None else None
 target=b if kind=='backward_operand_raw' else seed if kind=='backward_seed_raw' else a
 seen=[]
 def callback():
  seen.append(True);target.detach().numpy()[0,0]=-0. if kind=='signed_zero_raw' else 3.
 loop.call_soon(callback)
 try:
  if y is None:offload(a,b)
  else:torch.autograd.grad(y,a,seed)
 except RuntimeError as error:assert 'changed' in str(error)
 else:raise AssertionError('A raw NumPy byte change during GPU submission was accepted')
 assert seen==[True] and a.grad is None and b.grad is None and not torch_bridge._busy
 controls.append(dict(kind=kind,passed=True))
a=torch.ones(2,2,requires_grad=True);b=torch.ones(2,2);y=offload(a,b)
old_version=int(b._version);b.numpy()[:]=3.;assert int(b._version)==old_version
value,=torch.autograd.grad(y,a,torch.ones_like(y));np.testing.assert_array_equal(value.numpy(),np.full((2,2),6.))
controls.append(dict(kind='numpy_changes_between_calls_use_current_backward_values',passed=True))

assert not torch_bridge._busy and torch.is_grad_enabled()
report=dict(status='passed_guarded_tensor_offload',cases=len(rows),rows=rows,controls=controls,version=__version__,numpy=np.__version__,independent_native_oracles=['2.6.0','2.14.1'],rtol=1e-5,atol=1e-6,production_changed=False,resident_torch_gpu_storage=False,performance_qualified=False)
