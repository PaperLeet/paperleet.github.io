from pathlib import Path
import hashlib,io,json,os,shutil,stat,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');root=repo/'web/dist';public=repo/'web/public';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((b/'torch-iteration-521/result.json').read_text())['status']=='passed_current_083_frontend_followup'
assert json.loads((b/'torch-iteration-526/result.json').read_text())['main_adopted']
entries={};payloads={};total=0
for p in sorted(root.rglob('*')):
 name=str(p.relative_to(root));s=p.lstat();entry=dict(mode=stat.S_IMODE(s.st_mode))
 if p.is_symlink():entry.update(type='symlink',link=os.readlink(p))
 elif p.is_dir():entry.update(type='directory')
 elif p.is_file():
  h=sha(p);total+=s.st_size;external=public/name
  entry.update(type='file',sha256=h,bytes=s.st_size)
  if external.is_file() and not external.is_symlink() and sha(external)==h:entry['external']=str(external)
  else:entry['blob']='blobs/'+h;payloads.setdefault(h,p)
 else:raise AssertionError(name)
 entries[name]=entry
manifest=dict(root=str(root),entries=entries,scope='Exact final 0.83 build backup; thin archive depends on unchanged explicitly hashed immutable web/public copies; no public source/assets removed')
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');target=r/'qualified-build-thin-backup.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as stream:
 for h,p in payloads.items():stream.add(p,arcname='blobs/'+h,recursive=False)
 stream.add(r/'manifest.json',arcname='manifest.json',recursive=False);stream.add(Path(__file__),arcname='backup.py',recursive=False)
with tarfile.open(target) as stream:
 restored=json.load(stream.extractfile('manifest.json'));assert restored==manifest
 for n,e in entries.items():
  p=root/n;assert stat.S_IMODE(p.lstat().st_mode)==e['mode']
  if e['type']=='file':
   assert sha(p)==e['sha256']
   data=Path(e['external']).read_bytes() if 'external' in e else stream.extractfile(e['blob']).read()
   assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256'],n
  elif e['type']=='symlink':assert os.readlink(p)==e['link']
receipt=dict(status='verified_thin_backup',source_root=str(root),files=sum(e['type']=='file' for e in entries.values()),source_bytes=total,external_files=sum('external' in e for e in entries.values()),unique_stored_payloads=len(payloads),archive_sha256=sha(target),archive_bytes=target.stat().st_size,manifest_sha256=sha(r/'manifest.json'),public_assets_retained=True)
(r/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');shutil.rmtree(root);print(json.dumps(receipt))
