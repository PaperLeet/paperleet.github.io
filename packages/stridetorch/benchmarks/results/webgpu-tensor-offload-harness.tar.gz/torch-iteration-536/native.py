from pathlib import Path
import hashlib,json,sys,warnings
import numpy as np
import torch
from torch_workload import TorchMatrixStep,make_inputs,specifications,fingerprint
r=Path(__file__).resolve().parent;label=sys.argv[1];outputs={};meta=[]
with warnings.catch_warnings():
 warnings.simplefilter('ignore')
 for i,shape in enumerate(specifications()):
  values=make_inputs(shape);before=fingerprint(values)
  with TorchMatrixStep(torch,values,resident=True) as step:results=step()
  assert fingerprint(values)==before
  meta.append(dict(shape=shape,input_fingerprint=before))
  for name,value in zip(['forward','left_vjp','right_vjp'],results):outputs[f'case{i}_{name}']=value
np.savez_compressed(r/(label+'.npz'),**outputs);(r/(label+'.json')).write_text(json.dumps(dict(torch=torch.__version__,numpy=np.__version__,cases=meta,workloads_sha256=hashlib.sha256((r/'torch_workload.py').read_bytes()).hexdigest()),indent=2)+'\n');print(json.dumps(dict(torch=torch.__version__,cases=len(meta))))
