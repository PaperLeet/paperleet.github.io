from pathlib import Path
import hashlib,io,json,shutil,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
summary=read(r/'result.json');assert read(b/'torch-iteration-543/result.json')['totals']==dict(tests=5,failures=5,errors=0,skipped=0)
summary['negative_control']=read(b/'torch-iteration-543/result.json');(r/'qualified-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[r/'archive.py',r/'result.json',r/'qualified-summary.json']
for stage in [532,533,534,535,536,537,538,539,540,541,543]:
 folder=b/f'torch-iteration-{stage}';files.extend(p for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for stage in [534,537,538,539]:
 folder=b/f'torch-iteration-{stage}'
 for n,h in read(folder/'source-plan.json')['files'].items():assert sha(folder/n)==h,(stage,n)
for n in ['torch_bridge.py','test_torch_bridge.py','README.md']:
 p=r/'repository'/n;p.parent.mkdir(exist_ok=True);shutil.copy2(repo/'packages/stridetorch/benchmarks/webgpu_rpc'/n,p);files.append(p)
(r/'replay-dependencies.json').write_text(json.dumps(dict(entrypoints=['537/test_bridge.py (native tests; replace stage with torch-iteration prefix)','538/run-browser.mjs (actual GPU numerical/state controls)','539/run-all.py (all three planned timing processes)'],external=['Canonical 0.83 CPU runtime snapshots are included in each browser payload','Local Pyodide0.29.4 runtime and NumPy wheel closure at torch-iteration-76/runtime (not bundled)','Node22.22.1, Chrome155, Playwright; native Py3.12 NumPy2.5.4 Torch2.14.1 and Py3.10 NumPy1.26.4 Torch2.6','Adapt recorded absolute paths before replay'],notes=['532 first invocation remains failed (74 passed/2 failed);534 corrects harness and preserves actual strided inputs','535 original GPU gate passed but did not cover raw NumPy mutation;537/538 fix and validate this boundary;543 old prototype fails all five new regressions as expected','536 native oracle generation was reused; its earlier prepared timing driver was not executed;539 measures final537 prototype','533 is a verified thin backup of the preceding qualified web/dist; external immutable public files are retained, while the generated build tree was removed after verification','No timing process is rerun for favorable outcomes; ordinary GC and batch floors are preserved','Default CPU/WASM source, exports, quotas, version, device routing and package API remain unchanged']),indent=2)+'\n');files.append(r/'replay-dependencies.json')
files=sorted(set(files));manifest={str(p.relative_to(b)):sha(p) for p in files};seen={};target=r/'webgpu-tensor-offload-harness.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as stream:
 for p in files:
  name=str(p.relative_to(b));h=manifest[name]
  if h in seen:
   info=stream.gettarinfo(str(p),arcname=name);info.type=tarfile.LNKTYPE;info.linkname=seen[h];info.size=0;stream.addfile(info)
  else:stream.add(p,arcname=name,recursive=False);seen[h]=name
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256.json');info.size=len(data);stream.addfile(info,io.BytesIO(data))
with tarfile.open(target) as stream:
 for n,h in manifest.items():assert hashlib.sha256(stream.extractfile(n).read()).hexdigest()==h,n
receipt=dict(path='packages/stridetorch/benchmarks/results/'+target.name,sha256=sha(target),files=len(files),unique_payloads=len(seen),bytes=target.stat().st_size,all_payloads_verified=True);(r/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');summary['raw_archive']=receipt
(repo/'packages/stridetorch/benchmarks/results/webgpu-tensor-offload.json').write_text(json.dumps(summary,indent=2)+'\n');shutil.copy2(target,repo/receipt['path']);print(json.dumps(receipt))
