from pathlib import Path
import hashlib,json,statistics
r=Path(__file__).resolve().parent;b=r.parent;read=lambda p:json.loads(p.read_text());write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
config=read(b/'torch-iteration-539/config.json');assert read(b/'torch-iteration-539/progress.json')['status']=='completed';reports=[read(b/'torch-iteration-539'/f'browser-result-{i}.json') for i in config['cycles']]
for report in reports:
 assert report['status']=='passed' and report['numerical']['config']==config
 assert all(x['stats']['closed'] and x['stats']['total_bytes']==x['stats']['allocations']==x['stats']['resident_handles']==0 for x in report['host_disposals'])
rows=[];flags=[]
for index in range(4):
 samples=[next(v for v in report['numerical']['rows'] if v['index']==index) for report in reports];shape=samples[0]['shape'];assert all(v['shape']==shape for v in samples)
 aa=[statistics.median(v[key] for v in samples) for key in ['aa_ratio','paired_aa_ratio']];gpu=[statistics.median(v[key] for v in samples) for key in ['gpu_over_cpu_ratio','paired_gpu_over_cpu_ratio']]
 gate=all(.95<=v<=1.05 for v in aa) and all(.9<=v[key]<=1.1 for v in samples for key in ['aa_ratio','paired_aa_ratio']) and all(v['floor_passed'] for v in samples)
 individual=[dict(cycle=i,aa=s['aa_ratio'],paired_aa=s['paired_aa_ratio'],floor=s['minimum_batch_seconds']) for i,s in enumerate(samples) if not s['aa_passed'] or not s['floor_passed']]
 flags.extend(dict(shape=shape,**v) for v in individual)
 row=dict(shape=shape,aggregate_aa_ratio=aa[0],aggregate_paired_aa_ratio=aa[1],aggregate_gpu_ratio=gpu[0],aggregate_paired_gpu_ratio=gpu[1],all_preplanned_controls_passed=gate,measured_gpu_benefit=gate and all(v<1. for v in gpu),cpu_median_ms=1000*statistics.median(v['medians']['A0'] for v in samples),gpu_median_ms=1000*statistics.median(v['medians']['G'] for v in samples),minimum_batch_ms=1000*min(v['minimum_batch_seconds'] for v in samples),individual_flags=individual,paired_gpu_ratio_range=[min(v['paired_gpu_over_cpu_ratio'] for v in samples),max(v['paired_gpu_over_cpu_ratio'] for v in samples)])
 rows.append(row)
summary=dict(status='analyzed_preplanned_actual_autograd_gpu_whole_call_campaign',version='0.83.0',prototype_source_sha256=sha(b/'torch-iteration-537/torch_bridge.py'),processes=3,contexts=12,rows=rows,individual_flags=flags,normal_gc=True,cpu_tensor_inputs_reused_but_no_gpu_residency=True,all_input_copies_and_guard_scans_and_transfers_and_actual_autograd_included=True,returned_owned_cpu_arrays=3,all_default_quotas_unchanged=True,automatic_dispatch_enabled=False,resident_torch_gpu_storage=False,general_device_threshold_qualified=False,production_changed=False,ci_triggered=False,goal_status='active');write(r/'result.json',summary);print(json.dumps(summary,indent=2))
