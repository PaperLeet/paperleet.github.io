"""Native-only HVP caller-state inventory across every argument and seed."""
import json
import torch

def record(value):
    if isinstance(value,tuple): return [record(v) for v in value]
    return dict(shape=list(value.shape),dtype=str(value.dtype),requires_grad=value.requires_grad,
                values=value.detach().numpy().tolist())

rows=[]
for dtype in [torch.float32,torch.float64]:
    for requires_grad in [False,True]:
        for seed_grad in [False,True]:
            for strict in [False,True]:
                for case in ['mixed','unused','duplicate','captured','detach','no_grad','force_numpy','empty']:
                    x=torch.tensor([.2,.7],dtype=dtype,requires_grad=requires_grad)
                    y=torch.tensor([.4,.9],dtype=dtype,requires_grad=requires_grad)
                    if case=='empty': x=torch.empty(0,dtype=dtype,requires_grad=requires_grad)
                    inputs=(x,x) if case=='duplicate' else (x,y)
                    seed=tuple(torch.ones_like(a,requires_grad=seed_grad)*.3 for a in inputs)
                    # Make caller seeds leaves so their gradient buffers and hooks
                    # have the same observable status as the input tensors.
                    seed=tuple(a.detach().requires_grad_(seed_grad) for a in seed)
                    observed=[]; hooks=[]; handles=[]; snapshots=[]
                    for value in (*inputs,*seed):
                        if any(value is prior for prior in observed): continue
                        observed.append(value)
                        value.grad=torch.ones_like(value)*3
                        snapshots.append((value,value.detach().clone(),value.grad,value.grad.clone(),value.requires_grad))
                        if value.requires_grad: handles.append(value.register_hook(lambda g:hooks.append(g)))
                    calls=[]
                    def callback(a,b):
                        calls.append(dict(grad_enabled=torch.is_grad_enabled(),
                            first_is_original=a is x,second_is_original=b is inputs[1],arguments_same=a is b,
                            input_grad_flags=[a.requires_grad,b.requires_grad]))
                        if case=='mixed': return (a*b+a.pow(3)).sum()
                        if case=='unused': return a.square().sum()
                        if case=='duplicate': return (a*b+a.pow(3)).sum()
                        if case=='captured': return (a.pow(3)+x.square()).sum()+b.square().sum()
                        if case=='detach': return a.detach().square().sum()
                        if case=='no_grad':
                            with torch.no_grad(): return a.square().sum()
                        if case=='force_numpy': return torch.from_numpy(a.numpy(force=True)).sum()
                        return a.sum()+b.square().sum()
                    row=dict(case=case,dtype=str(dtype),requires_grad=requires_grad,seed_grad=seed_grad,strict=strict)
                    try:
                        with torch.no_grad():
                            output=torch.autograd.functional.hvp(callback,inputs,seed,strict=strict)
                            assert not torch.is_grad_enabled()
                        row.update(status='success',result=record(output))
                    except Exception as error:
                        row.update(status='error',exception=type(error).__name__,message=str(error))
                    preserved=[bool(v.requires_grad==flag and torch.equal(v.detach(),data) and v.grad is buffer and torch.equal(v.grad,grad))
                        for v,data,buffer,grad,flag in snapshots]
                    assert all(preserved) and not hooks
                    assert len(calls)==1 and calls[0]['grad_enabled']
                    for handle in handles: handle.remove()
                    row.update(calls=calls,distinct_observed_tensors=len(observed),caller_preserved=preserved,hooks=len(hooks))
                    rows.append(row)
print(json.dumps(dict(torch=torch.__version__,native_git=torch.version.git_version,
    scope='Native-only caller state for all distinct inputs and seeds; no adapter implementation or performance claim.',
    cases=len(rows),rows=rows),allow_nan=False,indent=2))
