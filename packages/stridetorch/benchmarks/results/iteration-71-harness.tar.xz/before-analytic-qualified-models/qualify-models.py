"""Replay native scalarized model HVPs, preserving all mismatches."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
import numpy as np

r=Path(__file__).resolve().parent
p=r/'model-proof';p.mkdir(exist_ok=True)
candidate=r/'candidate/packages/stridetorch/src'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
source=(r/'probe-model-hvp.py').read_text().replace('import torch','from stridetorch import torch, __version__ as library_version').replace('torch.__version__','library_version').replace('native_git=torch.version.git_version',"native_git='adapter-not-native'")
source=source.replace('torch.nn.attention.sdpa_kernel([torch.nn.attention.SDPBackend.MATH])','contextlib.nullcontext()')
(p/'probe-model-hvp.py').write_text(source)
env=dict(os.environ,PYTHONPATH=str(candidate),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
with (p/'candidate-model-hvp.json').open('w') as stdout,(p/'candidate.stderr').open('w') as stderr:
    child=subprocess.run([sys.executable,str(p/'probe-model-hvp.py')],env=env,stdout=stdout,stderr=stderr)
child.check_returncode()
native=json.loads((r/'native-model-hvp.json').read_text());actual=json.loads((p/'candidate-model-hvp.json').read_text())
assert native['cases']==actual['cases']==208
maximum=0.
def compare(a,b,path):
    global maximum
    if isinstance(a,dict):
        assert set(a)==set(b),(path,set(a),set(b))
        if 'values' in a:
            for key in ['shape','dtype','requires_grad']:assert a[key]==b[key],(path,key,a[key],b[key])
            av=np.asarray(a['values']);bv=np.asarray(b['values'])
            if av.size:maximum=max(maximum,float(np.max(np.abs(av-bv))))
            np.testing.assert_allclose(bv,av,rtol=1e-4 if a['dtype']=='float32' else 1e-8,atol=3e-6 if a['dtype']=='float32' else 2e-10,err_msg=path)
        else:
            for key in a:compare(a[key],b[key],path+'.'+key)
    elif isinstance(a,list):
        assert len(a)==len(b),(path,len(a),len(b))
        for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+f'[{i}]')
    else:assert a==b,(path,a,b)
failures=[]
for a,b in zip(native['rows'],actual['rows']):
    try:
        for key in ['case','dtype','strict','strided','status','calls','hooks','caller_preserved']:compare(a[key],b[key],key)
        compare(a['model_buffers'],b['model_buffers'],'buffers')
        if a['status']=='success':compare(a['result'],b['result'],'result')
    except (AssertionError,TypeError,KeyError) as error:
        failures.append(dict(case=a['case'],dtype=a['dtype'],strict=a['strict'],strided=a['strided'],error=str(error),native=a,actual=b))
report=dict(status='failed' if failures else 'passed',cases=208,failures=failures,max_abs_difference=maximum,
    source_hashes={q.name:sha(q) for q in (candidate/'stridetorch').iterdir() if q.suffix=='.py' or q.name in ['LICENSE','NOTICE']},
    native_sha256=sha(r/'native-model-hvp.json'),candidate_sha256=sha(p/'candidate-model-hvp.json'),probe_sha256=sha(r/'probe-model-hvp.py'),replayed_probe_sha256=sha(p/'probe-model-hvp.py'))
(p/'qualification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],cases=208,max_abs_difference=maximum,failures=[{k:v[k] for k in ['case','dtype','strict','strided','error']} for v in failures])),flush=True)
sys.exit(bool(failures))
