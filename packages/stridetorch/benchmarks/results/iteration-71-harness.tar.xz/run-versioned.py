"""Full final-version CPU/native/Node/Chrome qualification; no application edits."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time

r=Path(__file__).resolve().parent
piecewise=sys.argv[1:]==['--piecewise'];portable=sys.argv[1:]==['--portable'] or piecewise;assert not sys.argv[1:] or portable
v=r/('piecewise-release' if piecewise else 'portable-release' if portable else 'versioned-release');snapshot=v/'snapshot/packages/stridetorch'
cpu_count=8363 if piecewise else 8331;wasm_count=8350 if piecewise else 8318;suites=71 if piecewise else 70
read=lambda q:json.loads(q.read_text())
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
freeze=read(v/'source-freeze.json')
env=dict(os.environ,PYTHONPATH=str(snapshot/'src'),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
receipts=[]
def verify():
    for base in [snapshot,r/'candidate/packages/stridetorch']:
        for directory,key in [('src/stridetorch','source_hashes'),('tests','test_hashes')]:
            for name,digest in freeze[key].items():assert sha(base/directory/name)==digest
        for name,digest in freeze['package_hashes'].items():assert sha(base/name)==digest
def run(label,args):
    verify();started=time.monotonic()
    with (v/(label+'.log')).open('w') as log:
        child=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
    item=dict(label=label,exit_code=child.returncode,seconds=time.monotonic()-started,log_sha256=sha(v/(label+'.log')),
        summary=(v/(label+'.log')).read_text().splitlines()[-1:])
    receipts.append(item);(v/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
    child.check_returncode();verify();print(label,'TERMINAL0',item['summary'],flush=True)
    return item
cpu=run('cpu-sdk',[sys.executable,'-m','pytest',str(snapshot/'tests'),'-q','-p','no:cacheprovider','--basetemp',str(v/'pytest-tmp')])
assert cpu['summary'][0].startswith(str(cpu_count)+' passed, 1 warning')
(v/'cpu-sdk-receipt.json').write_text(json.dumps(dict(**cpu,version='0.71.0',source_hashes=freeze['source_hashes'],test_hashes=freeze['test_hashes']),indent=2)+'\n')
jobs=[('precision',[sys.executable,str(r/'candidate-instance-precision.py')]),
    ('boundary',[sys.executable,str(r/'qualify-boundaries.py')]),
    ('models',[sys.executable,str(r/'qualify-models.py')]),
    ('singular',[sys.executable,str(r/'qualify-singular.py')]),
    ('singular-extended',[sys.executable,str(r/'qualify-singular.py'),'--extended'])]
if piecewise:jobs.append(('piecewise',[sys.executable,str(r/'qualify-piecewise.py')]))
for label,args in jobs:
    run(label,args)
    if label=='precision':
        value=read(v/'precision.log');assert max(value['rows'][0]['max_abs_errors_vs_analytic'])<1e-6
        # The model qualifier binds the exact native FP32 inputs and vectors
        # to this independent analytic/native-FP64 witness.
        (r/'candidate-instance-precision.json').write_bytes((v/'precision.log').read_bytes())
proofs={name:read(r/path) for name,path in [('boundary','boundary-proof/qualification.json'),('models','model-proof/qualification.json'),('singular','singular-proof/qualification.json'),('singular_extended','singular-extended-proof/qualification.json')]}
if piecewise:proofs['piecewise']=read(r/'piecewise-proof/qualification.json')
for name,value in proofs.items():
    assert value['status']=='passed' and value['source_hashes']==freeze['source_hashes'] and not value['failures']
    (v/(name+'-qualification.json')).write_text(json.dumps(value,indent=2)+'\n')
for label,driver,result in [('node','node.mjs','node-result.json'),('chrome','chrome-contracts/run.mjs','chrome-contracts/result.json')]:
    run(label,['/opt/homebrew/bin/node',str(v/'wasm-proof'/driver)])
    value=read(v/'wasm-proof'/result)
    assert value['status']=='success' and value['library']=='0.71.0' and value['passed']==wasm_count and value['suites']==suites
    assert value['source_hashes']==freeze['source_hashes']
    assert value['test_hashes']=={k:h for k,h in freeze['test_hashes'].items() if k!='test_standalone.py'}
verify()
extension_count=sum(len(proofs[k].get('polynomial_extension_controls',[])) for k in ['singular','singular_extended'])
assert extension_count==(40 if portable else 0)
result=dict(status='final_version_cpu_native_wasm_sdk_passed',version='0.71.0',source_hashes=freeze['source_hashes'],test_hashes=freeze['test_hashes'],
    cpu_cases=cpu_count,wasm_cases_each=wasm_count,wasm_suites=suites,native_cpu_cases=256+208+64+160+(32 if piecewise else 0),
    direct_native_cases=256+204+64+160-extension_count+(32 if piecewise else 0),independent_fp32_precision_controls=4,polynomial_extension_controls=extension_count,receipts=receipts,
    scope='CPU SDK and CPU native fixtures plus Node/Chrome SDK only. Does not qualify installed minimum-runtime packages, all native fixtures in WASM, performance, application integration or main adoption.',
    main_adopted=False,ci_triggered=False,deployed=False)
(v/'qualification.json').write_text(json.dumps(result,indent=2)+'\n')
print('EXACT FINAL0.71 CPU/NATIVE/NODE/CHROME SDK QUALIFIED; NO APPLICATION ADOPTION',flush=True)
