"""Freeze native HVP oracle programs for independent actual WASM replay."""
from pathlib import Path
import hashlib,json,shutil,sys

r=Path(__file__).resolve().parent
piecewise=sys.argv[1:]==['--piecewise'];portable=sys.argv[1:]==['--portable'] or piecewise;assert not sys.argv[1:] or portable
v=r/('piecewise-release' if piecewise else 'portable-release' if portable else 'versioned-release');p=v/'native-wasm-proof';p.mkdir()
(p/'fixtures').mkdir();(p/'chrome').mkdir()
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
freeze=json.loads((v/'source-freeze.json').read_text())
shutil.copytree(v/'snapshot/packages/stridetorch/src/stridetorch',p/'source',ignore=shutil.ignore_patterns('__pycache__'))
jobs=[('boundary','probe-hvp.py','native-hvp.json',128),('caller','probe-hvp-caller-state.py','native-hvp-caller-state.json',128),
    ('models','probe-model-hvp.py','native-model-hvp.json',208),('singular','probe-singular-det-hvp.py','native-singular-det-hvp.json',64),
    ('singular_extended','probe-singular-det-hvp-extended.py','native-singular-det-hvp-extended.json',160)]
if piecewise:jobs.append(('piecewise','probe-piecewise-jvp.py','native-piecewise-jvp.json',32))
fixtures={};programs=[]
for label,script,oracle,cases in jobs:
    source=(r/script).read_text().replace('import torch','from stridetorch import torch, __version__ as library_version').replace('torch.__version__','library_version').replace('torch.version.git_version',"'adapter-not-native'")
    source=source.replace('torch.nn.attention.sdpa_kernel([torch.nn.attention.SDPBackend.MATH])','contextlib.nullcontext()')
    (p/'fixtures'/script).write_text(source);shutil.copy2(r/oracle,p/'fixtures'/oracle)
    programs.append(dict(label=label,script=script,oracle=oracle,cases=cases))
for name in ['native-instance-precision.json','determinant_reference.py']:
    shutil.copy2(r/name,p/'fixtures'/name)
fixtures={q.name:sha(q) for q in (p/'fixtures').iterdir()}
plan=dict(version='0.71.0',source=freeze['source_hashes'],fixtures=fixtures,programs=programs,expected=720 if piecewise else 688,
    scope='CPU native oracles plus four analytic/native-FP64 precision controls and forty explicit polynomial extensions to native SVD-tape NaNs; native SDPA reference uses the math backend.')
(p/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(p/'chrome/index.html').write_text('<!doctype html><meta charset="utf-8"><title>Native HVP replay</title>')
print('Prepared 688 native HVP fixtures with exact source and payload hashes')
