_original_build=build
def build(module,case,candidate):
 t=module.torch;rng=np.random.default_rng(7123)
 if case=='batchnorm_step':
  m=t.nn.BatchNorm2d(8,dtype=t.float64);x=t.tensor(rng.normal(size=(2,8,8,8)),dtype=t.float64,requires_grad=True)
  def fn():
   m.zero_grad(set_to_none=True);x.grad=None;loss=m(x).square().mean();loss.backward();return loss
  def capture():
   loss=fn();return flatten((loss,x.grad,*[p.grad for p in m.parameters()]))
  return fn,capture,'float64'
 if case in ['layernorm_jvp_reverse','instancenorm_jvp_reverse']:
  shape=(4,32) if case.startswith('layer') else (2,4,8)
  channels=32 if case.startswith('layer') else 4
  values=tuple(t.tensor(rng.normal(size=s)*.2,dtype=t.float64,requires_grad=True) for s in [shape,(channels,),(channels,)])
  directions=tuple(t.tensor(rng.normal(size=s),dtype=t.float64,requires_grad=True) for s in [shape,(channels,),(channels,)])
  function=(lambda a,w,b:t.nn.functional.layer_norm(a,(32,),w,b)) if case.startswith('layer') else (lambda a,w,b:t.nn.functional.instance_norm(a,weight=w,bias=b))
 elif case in ['solve_jvp_reverse','slogdet_jvp_reverse']:
  a=rng.normal(size=(8,8))*.03+np.eye(8)*2
  data=[a,rng.normal(size=(8,4))*.2] if case.startswith('solve') else [a]
  values=tuple(t.tensor(a,dtype=t.float64,requires_grad=True) for a in data)
  directions=tuple(t.tensor(rng.normal(size=a.shape)*.1,dtype=t.float64,requires_grad=True) for a in data)
  function=t.linalg.solve if case.startswith('solve') else lambda a:t.linalg.slogdet(a).logabsdet
 else:return _original_build(module,case,candidate)
 def fn():
  for value in (*values,*directions):value.grad=None
  primal,tangent=t.func.jvp(function,values,directions)
  loss=primal.square().mean()+tangent.square().mean();loss.backward();return loss
 def capture():
  loss=fn();return flatten((loss,*[v.grad for v in (*values,*directions)]))
 return fn,capture,'float64'

def build_hvp(module,case,candidate):
 t=module.torch;rng=np.random.default_rng(7131);counter=[0]
 if case=='hvp_linear':
  arrays=[rng.normal(size=s).astype('float32')*.2 for s in [(2,4),(3,4),(3,)]]
  vectors=[rng.normal(size=a.shape).astype('float32') for a in arrays];dtype='float32'
  def raw(a,w,b):return t.nn.functional.linear(a,w,b).tanh().square().sum()
  a,w,b=[v.astype('float64') for v in arrays];da,dw,db=[v.astype('float64') for v in vectors]
  z=np.tanh(a@w.T+b);dz=da@w.T+a@dw.T+db
  g=2*z*(1-z*z);dg=2*(1-z*z)*(1-3*z*z)*dz
  expected=[dg@w+g@dw,dg.T@a+g.T@da,dg.sum(0)]
 elif case=='hvp_scalar':
  arrays=[np.sin(np.arange(64)*.17)];vectors=[np.cos(np.arange(64)*.11)];dtype='float64'
  def raw(a):return (a.sin()*a.square()).sum()
  a=arrays[0];expected=[(2*np.sin(a)+4*a*np.cos(a)-a*a*np.sin(a))*vectors[0]]
 else:
  arrays=[rng.normal(size=16) for _ in range(2)];vectors=[rng.normal(size=16) for _ in arrays];dtype='float64'
  def raw(a,b):return a.sin().sum()
  expected=[-np.sin(arrays[0])*vectors[0],np.zeros_like(arrays[1])]
 values=tuple(t.tensor(a,dtype=getattr(t,dtype),requires_grad=bool(i%2)) for i,a in enumerate(arrays))
 directions=tuple(t.tensor(a,dtype=getattr(t,dtype),requires_grad=True) for a in vectors)
 buffers=[];hooks=[]
 for value in (*values,*directions):
  value.grad=t.ones_like(value)*3;buffers.append(value.grad)
  if value.requires_grad:value.register_hook(lambda g:hooks.append(g))
 def callback(*args):counter[0]+=1;return raw(*args)
 def fn():
  if candidate:return t.autograd.functional.hvp(callback,values,directions)
  # Qualified pure callbacks only. This is a composition of released0.70
  # public AD primitives, not a released0.70 functional HVP entry point.
  with t.enable_grad():
   args=tuple(a.detach().requires_grad_(True) for a in values)
   seeds=tuple(v.detach() for v in directions)
   primal,tangent=t.func.jvp(callback,args,seeds)
   derivatives=t.autograd.grad(tangent,args,allow_unused=True)
   derivatives=tuple(t.zeros_like(a) if g is None else g.detach() for a,g in zip(args,derivatives))
   return primal.detach(),derivatives
 def capture():
  before=counter[0];primal,products=fn();assert counter[0]==before+1 and not hooks
  for actual,target in zip(products,expected):np.testing.assert_allclose(actual.numpy(),target,rtol=3e-5 if dtype=='float32' else 1e-11,atol=3e-6 if dtype=='float32' else 1e-11)
  for value,buffer in zip((*values,*directions),buffers):assert value.grad is buffer
  for value,data in zip(values,arrays):np.testing.assert_array_equal(value.numpy(),data)
  for value,data in zip(directions,vectors):np.testing.assert_array_equal(value.numpy(),data)
  assert all(not value.requires_grad for value in (primal,*products))
  assert all(not np.shares_memory(product.numpy(),value.numpy()) for product in products for value in values)
  return flatten((primal,products))
 return fn,capture,dtype

def run(baseline,candidate,jacobian_baseline,cycle,check_only=False):
 labels=['baseline','duplicate','candidate'];orders=list(itertools.permutations(labels));load_order=orders[cycle%6]
 families=dict(legacy=(baseline,['mha_step','groupnorm_step','linear_deepcopy','transformer_deepcopy','transformer_pickle','export_numpy','export_asarray','vjp_scalar','vjp_linear','batchnorm_step','layernorm_jvp_reverse','instancenorm_jvp_reverse','solve_jvp_reverse','slogdet_jvp_reverse']),
  jacobian=(jacobian_baseline,['jacobian_sin64','jacobian_linear','jacobian_unused']),hvp=(baseline,['hvp_scalar','hvp_linear','hvp_unused']))
 family_order=list(itertools.permutations(families))[cycle%6];rows=[];family_hashes={}
 for family in family_order:
  old,cases=families[family];modules={};hashes={};paths=dict(baseline=old,duplicate=old,candidate=candidate)
  for label in load_order:modules[label],hashes[label]=load('_'+family+'_'+label,paths[label])
  assert hashes['baseline']==hashes['duplicate'];family_hashes[family]=hashes
  for case in cases:
   functions={};captures={}
   for label in load_order:
    factory=build_jacobian if family=='jacobian' else build_hvp if family=='hvp' else build
    args=(modules[label],case) if family=='jacobian' else (modules[label],case,label=='candidate')
    functions[label],captures[label],dtype=factory(*args)
   expected=captures['baseline']()
   for label in ['duplicate','candidate']:
    actual=captures[label]();assert len(actual)==len(expected)
    for a,b in zip(actual,expected):
     assert a.shape==b.shape and a.dtype==b.dtype
     np.testing.assert_allclose(a,b,rtol=3e-5 if dtype=='float32' else 3e-11,atol=3e-6 if dtype=='float32' else 3e-11)
   if check_only:rows.append(dict(family=family,case=case,status='numerically_checked'));continue
   del expected,actual;gc.collect();calls=1
   for label in load_order:
    batch=1
    while True:
     started=time.perf_counter()
     for _ in range(batch):functions[label]()
     if time.perf_counter()-started>=.02:break
     batch*=2
    calls=max(calls,batch)
   samples={label:[] for label in labels}
   for order in orders+list(reversed(orders)):
    for label in order:
     fn=functions[label];started=time.perf_counter()
     for _ in range(calls):fn()
     samples[label].append((time.perf_counter()-started)/calls)
   medians={label:statistics.median(values) for label,values in samples.items()}
   rows.append(dict(family=family,case=case,dtype=dtype,calls=calls,samples_s=samples,median_s=medians,
    duplicate_over_baseline=medians['duplicate']/medians['baseline'],candidate_over_baseline=medians['candidate']/medians['baseline'],candidate_over_duplicate=medians['candidate']/medians['duplicate'],
    reference='Validated released0.70 public AD composition; not a functional HVP API' if family=='hvp' else 'Released0.70 public API on both sides'))
 rows.sort(key=lambda row:(row['family'],row['case']))
 assert all(h['candidate']==family_hashes['legacy']['candidate'] for h in family_hashes.values())
 hashes=dict(baseline=family_hashes['legacy']['baseline'],duplicate=family_hashes['legacy']['duplicate'],candidate=family_hashes['legacy']['candidate'],jacobian_baseline=family_hashes['jacobian']['baseline'])
 return dict(cycle=cycle,load_order=list(load_order),family_order=list(family_order),source_hashes=hashes,family_source_hashes=family_hashes,rows=rows,python=sys.version,numpy=np.__version__,program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
  scope='Seventeen released0.70 public API flows and three independently checked pure-callback HVP compositions. Six source/family load orders;12 balanced common >=20ms batches with same-source A/A. No nativeTorch/GPU/cold-start/universal speedup claim.')

if __name__=='__main__':print(json.dumps(run(sys.argv[1],sys.argv[2],sys.argv[3],int(sys.argv[4]),check_only='--check-only' in sys.argv),indent=2))
