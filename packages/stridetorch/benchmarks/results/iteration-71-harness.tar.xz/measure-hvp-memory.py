"""Bounded CPU allocation comparison; run only after latency is terminal."""
from pathlib import Path
import gc,hashlib,importlib.util,itertools,json,statistics,sys,tracemalloc
import numpy as np

r=Path(__file__).resolve().parent
assert json.loads((r/'performance/summary.json').read_text())['status']=='completed'
receipts=json.loads((r/'performance/results/receipts.json').read_text())
assert len(receipts)==18 and all(v['exit_code']==0 for v in receipts)
source=r/'piecewise-release/snapshot/packages/stridetorch/src/stridetorch'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected=json.loads((r/'piecewise-release/source-freeze.json').read_text())['source_hashes']
assert {p.name:sha(p) for p in source.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']}==expected
spec=importlib.util.spec_from_file_location('_hvp_allocation',source/'__init__.py',submodule_search_locations=[str(source)])
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
t=module.torch
assert module.__version__=='0.71.0' and not tracemalloc.is_tracing()
rows=[]
for shape in [(8,8),(8,16),(16,16)]:
    n=int(np.prod(shape));data=np.sin(np.arange(n)*.13).reshape(shape);direction=np.cos(np.arange(n)*.17).reshape(shape)
    x=t.tensor(data,dtype=t.float64,requires_grad=True);v=t.tensor(direction,dtype=t.float64,requires_grad=True)
    x.grad=t.full_like(x,3);v.grad=t.full_like(v,4);buffers=(x.grad,v.grad);hooks=[]
    x.register_hook(lambda g:hooks.append(g));v.register_hook(lambda g:hooks.append(g))
    target=-np.sin(data)*direction
    def direct():return t.autograd.functional.hvp(lambda a:a.sin().sum(),x,v)[1]
    def dense():
        matrix=np.empty((n,n),dtype=np.float64)
        for column in range(n):
            basis=np.zeros(n,dtype=np.float64);basis[column]=1
            _,value=t.autograd.functional.hvp(lambda a:a.sin().sum(),x,t.tensor(basis.reshape(shape)))
            matrix[:,column]=value.numpy().reshape(-1)
        return (matrix@direction.reshape(-1)).reshape(shape)
    functions=dict(direct=direct,dense=dense,dense_duplicate=dense)
    for fn in functions.values():fn()
    samples=[]
    for order in itertools.permutations(functions):
        for label in order:
            gc.collect();tracemalloc.start();tracemalloc.reset_peak()
            value=functions[label]();current,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
            actual=value.numpy() if hasattr(value,'numpy') else value
            np.testing.assert_allclose(actual,target,rtol=1e-12,atol=1e-12)
            assert x.grad is buffers[0] and v.grad is buffers[1] and not hooks
            np.testing.assert_array_equal(x.numpy(),data);np.testing.assert_array_equal(v.numpy(),direction)
            samples.append(dict(order=list(order),label=label,current_bytes=current,peak_bytes=peak))
            del value,actual
    medians={label:statistics.median(v['peak_bytes'] for v in samples if v['label']==label) for label in functions}
    rows.append(dict(shape=list(shape),input_elements=n,dense_hessian_bytes=n*n*8,samples=samples,median_peak_bytes=medians,
        direct_over_dense_peak=medians['direct']/medians['dense'],dense_duplicate_over_dense_peak=medians['dense_duplicate']/medians['dense']))
report=dict(status='passed',version=module.__version__,numpy=np.__version__,python=sys.version,source_hashes=expected,rows=rows,
    scope='One CPU process, three real float64 sin objectives, six balanced call orders and repeated dense A/A control. Dense reference assembles a full Hessian from the selected library HVP basis calls; it is not a released0.70 API or a different derivative implementation. Tracks Python/NumPy allocations only, not RSS or WASM/GPU memory. Not a latency benchmark.')
(r/'performance/hvp-memory.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],rows=[dict(shape=v['shape'],direct_over_dense=v['direct_over_dense_peak'],aa=v['dense_duplicate_over_dense_peak']) for v in rows])),flush=True)
