"""Native piecewise gradients, forward directions and both reverse channels."""
import json
import torch

def record(value):
    if value is None:return None
    return dict(shape=list(value.shape),dtype=str(value.dtype).split('.')[-1],requires_grad=value.requires_grad,
        values=value.detach().clone().numpy().tolist())
rows=[]
for dtype in [torch.float32,torch.float64]:
    for gx in [False,True]:
        for gv in [False,True]:
            for case in ['abs','clamp','clamp_min','clamp_max']:
                x=torch.tensor([-.2,-.1,0.,.1,.2],dtype=dtype,requires_grad=gx)
                v=torch.tensor([.3,.5,.7,.9,1.1],dtype=dtype,requires_grad=gv)
                x.grad=torch.ones_like(x)*3;v.grad=torch.ones_like(v)*4;buffers=(x.grad,v.grad)
                def function(a):
                    if case=='abs':return a.abs()
                    if case=='clamp':return a.clamp(-.1,.1)
                    return getattr(a,case)(-.1 if case=='clamp_min' else .1)
                primal,tangent=torch.func.jvp(function,(x,),(v,))
                inputs=tuple(a for a in (x,v) if a.requires_grad)
                gradients=torch.autograd.grad(tangent,inputs,torch.ones_like(tangent),allow_unused=True) if tangent.requires_grad else (None,)*len(inputs)
                raw=function(x)
                raw_gradient=torch.autograd.grad(raw,x,torch.ones_like(raw))[0] if gx else None
                output,hvp=torch.autograd.functional.hvp(lambda a:function(a).square().sum(),x,v)
                assert x.grad is buffers[0] and v.grad is buffers[1]
                assert x.grad.tolist()==[3.]*5 and v.grad.tolist()==[4.]*5
                rows.append(dict(case=case,dtype=str(dtype).split('.')[-1],gx=gx,gv=gv,primal=record(primal),tangent=record(tangent),
                    reverse_channels=[record(a) for a in gradients],raw_gradient=record(raw_gradient),squared_hvp=record(hvp),caller_preserved=True))
print(json.dumps(dict(torch=torch.__version__,native_git=torch.version.git_version,cases=len(rows),rows=rows),indent=2,allow_nan=False))
