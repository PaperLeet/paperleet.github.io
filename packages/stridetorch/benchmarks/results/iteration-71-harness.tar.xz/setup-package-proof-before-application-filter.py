"""Prepare an exact current-application packaging fixture for frozen0.71."""
from pathlib import Path
import hashlib,json,shutil,subprocess

r=Path(__file__).resolve().parent;v=r/'versioned-release';p=v/'package-proof';p.mkdir()
snapshot=v/'snapshot';repo=Path('/Users/david/Developer/PaperLeet-torch-release')
old=r.parent/'torch-iteration-70/versioned-release'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
freeze=json.loads((v/'source-freeze.json').read_text())
assert not (snapshot/'paperleet').exists() and not (snapshot/'pyproject.toml').exists()
names=[n for n in subprocess.check_output(['git','ls-files','-z','--','paperleet','pyproject.toml','setup.py','LICENSE','NOTICE','README.md','MANIFEST.in'],cwd=repo).decode().split('\0') if n]
application={}
for name in names:
    source=repo/name;target=snapshot/name
    target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
    if name.startswith('paperleet/'):application[name]=sha(source)
assert len(application)==37
(p/'application-source-hashes.json').write_text(json.dumps(application,indent=2)+'\n')
(p/'application-fixture.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),files={n:sha(repo/n) for n in names}),indent=2)+'\n')
(p/'source-hashes.json').write_text(json.dumps(freeze['source_hashes'],indent=2)+'\n')
for name in ['check-wheel.py','check-coinstall.py','fresh-load.py']:
    text=(old/'package-proof'/name).read_text().replace('0.70.0','0.71.0').replace('stride070','stride071').replace('8213','8331')
    if name=='check-wheel.py':
        text=text.replace("'numpy==1.26.4','pytest',wheel","'numpy==1.26.4','pytest==8.4.2',wheel")
        text=text.replace("tests,'-q','--noconftest'","tests,'-q','--noconftest','-p','no:cacheprovider'")
    elif name=='check-coinstall.py':
        text=text.replace('saved.jacobian_operator is t.autograd.functional.jacobian','saved.jacobian_operator is t.autograd.functional.jacobian and saved.hvp_operator is t.autograd.functional.hvp')
        text=text.replace('saved.jacobian_operator=t.autograd.functional.jacobian','saved.jacobian_operator=t.autograd.functional.jacobian;saved.hvp_operator=t.autograd.functional.hvp')
        addition='''for name in NAMES:
 m=importlib.import_module(name);t=m.torch
 with m.as_torch() as api:
  from torch.autograd.functional import hvp
  assert hvp is api.autograd.functional.hvp
  x=api.tensor([2.,3.],requires_grad=True);x.grad=api.full_like(x,17);buffer=x.grad
  value,product=hvp(lambda a:a.pow(3).sum(),x,api.ones_like(x),strict=True)
  assert value.item()==35 and product.tolist()==[12.,18.] and x.grad is buffer and not product.requires_grad
  a=api.tensor([[0.,0.,0.],[0.,2.,0.],[0.,0.,3.]],dtype=api.float64)
  _,product=hvp(api.det,a,api.ones_like(a),strict=True)
  np.testing.assert_allclose(product.numpy(),[[5.,-3.,-2.],[-3.,3.,0.],[-2.,0.,2.]])
 assert sys.modules.get('torch') is host
'''
        needle="print('PASS isolated ownership,aliases,ZIP resume,triangular,Cholesky and Cholesky solve VJP/JVP/full tangent reverse')"
        assert needle in text;text=text.replace(needle,addition+needle)
    else:
        text+='''
assert model.hvp_operator is m.torch.autograd.functional.hvp
primal,product=model.hvp_operator(lambda a:a.pow(3).sum(),value,m.torch.ones_like(value),strict=True)
assert primal.item()==35 and product.tolist()==[12.,18.] and not product.requires_grad and value.grad is None
assert sys.modules['torch'] is host
print('PASS fresh-process HVP operator restore',name)
'''
    compile(text,str(p/name),'exec');(p/name).write_text(text)
text=(old/'run-package-proof.py').read_text().replace('0.70.0','0.71.0').replace('stride070','stride071').replace('8213','8331')
text=text.replace('activation,VJP andJacobian operator pickle','activation,VJP,Jacobian andHVP operator pickle')
compile(text,str(v/'run-package-proof.py'),'exec');(v/'run-package-proof.py').write_text(text)
print('Prepared exact0.71 wheel/sdist/private-wheel tests;37 current application identities; no build or install started')
