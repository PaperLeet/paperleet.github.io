from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
freeze=json.loads((p.parent/'source-freeze.json').read_text())
receipts=[]
for label,driver,result in [('node','node.mjs','node-result.json'),('chrome','chrome/run.mjs','chrome/result.json')]:
    started=time.monotonic()
    with (p/(label+'.log')).open('w') as log:
        child=subprocess.run(['/opt/homebrew/bin/node',str(p/driver)],cwd=p,env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2'),stdout=log,stderr=subprocess.STDOUT)
    receipts.append(dict(label=label,exit_code=child.returncode,seconds=time.monotonic()-started,log_sha256=sha(p/(label+'.log'))))
    (p/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');child.check_returncode()
    value=json.loads((p/result).read_text())
    assert value['source_hashes']==freeze['source_hashes'] and value['cases']==688 and len(value['independent_precision_controls'])==4 and not value['failures']
    print(label,'688 native fixtures PASSED',flush=True)
print('Actual Node and Chrome native HVP fixtures passed; no application adoption',flush=True)
