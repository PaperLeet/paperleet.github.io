from pathlib import Path
import hashlib,json,os,subprocess,time

p=Path(__file__).resolve().parent;r=p.parent
read=lambda q:json.loads(q.read_text())
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
freeze=read(r/'prototype-source-freeze.json')
def verify():
    root=r/'candidate/packages/stridetorch'
    for directory,key in [('src/stridetorch','source_hashes'),('tests','test_hashes')]:
        for name,digest in freeze[key].items():assert sha(root/directory/name)==digest
verify();receipts=[]
for label,driver,result in [('node','node.mjs','node-result.json'),('chrome','chrome-contracts/run.mjs','chrome-contracts/result.json')]:
    started=time.monotonic()
    with (p/(label+'.log')).open('w') as log:
        child=subprocess.run(['/opt/homebrew/bin/node',str(p/driver)],cwd=p,
            env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2'),stdout=log,stderr=subprocess.STDOUT)
    receipts.append(dict(label=label,exit_code=child.returncode,seconds=time.monotonic()-started,log_sha256=sha(p/(label+'.log'))))
    (p/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
    child.check_returncode()
    value=read(p/result)
    assert value['source_hashes']==freeze['source_hashes'] and value['passed']==8262 and value['suites']==69
    assert value['test_hashes']=={k:v for k,v in freeze['test_hashes'].items() if k!='test_standalone.py'}
    verify();print(label,'PASSED',value['passed'],'SDK cases /',value['suites'],'suites',flush=True)
print('Isolated prototype SDK passed in Node and Chrome; no application adoption or release',flush=True)
