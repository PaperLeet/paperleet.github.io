"""Freeze released0.70 and the selected0.71 for balanced public-API timing."""
from pathlib import Path
import hashlib,json,shutil,subprocess

r=Path(__file__).resolve().parent;p=r/'performance';assets=p/'assets';assets.mkdir(parents=True)
repo=Path('/Users/david/Developer/PaperLeet-torch-release')
old=r.parent/'torch-iteration-70/performance';selected=r/'piecewise-release'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
manifest=lambda p:{q.name:sha(q) for q in p.iterdir() if q.suffix=='.py' or q.name in ['LICENSE','NOTICE']}
freeze=json.loads((selected/'source-freeze.json').read_text())
assert json.loads((selected/'qualification.json').read_text())['status']=='final_version_cpu_native_wasm_sdk_passed'
assert json.loads((selected/'package-proof/package-identity.json').read_text())['status']=='success'
assert not subprocess.check_output(['git','status','--porcelain','-z'],cwd=repo)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
for label,origin in [('baseline',repo/'packages/stridetorch/src/stridetorch'),('candidate',selected/'snapshot/packages/stridetorch/src/stridetorch'),('jacobian_baseline',repo/'packages/stridetorch/src/stridetorch')]:
    shutil.copytree(origin,assets/label/'stridetorch',ignore=shutil.ignore_patterns('__pycache__'))
hashes={label:manifest(assets/label/'stridetorch') for label in ['baseline','candidate','jacobian_baseline']}
hashes['duplicate']=hashes['baseline']
assert hashes['candidate']==freeze['source_hashes'] and hashes['jacobian_baseline']==hashes['baseline']
for name,digest in hashes['baseline'].items():
    actual=subprocess.check_output(['git','show',head+':packages/stridetorch/src/stridetorch/'+name],cwd=repo)
    assert hashlib.sha256(actual).hexdigest()==digest
prefix=(old/'assets/bench_vjp.py').read_text().split('\ndef run(')[0]
assert 'fn=lambda:t.autograd.functional.vjp(function,values,seed)' in prefix
program=prefix+'\n'+(r/'performance-fragment.py').read_text()
compile(program,str(assets/'bench_vjp.py'),'exec');(assets/'bench_vjp.py').write_text(program)
plan=dict(source_hashes=hashes,programs={'bench_vjp.py':sha(assets/'bench_vjp.py')},baseline_version='0.70.0',candidate_version='0.71.0',baseline_main=head,
    flows=20,legacy_public_flows=17,qualified_hvp_composition_flows=3,
    hvp_reference='Released0.70 public JVP/grad composition for three pure callbacks, analytically checked; not an existing functional HVP API.')
(assets/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(assets/'source-freeze.json').write_text(json.dumps(dict(source_hashes=hashes,baseline_main=head),indent=2)+'\n')
for source,target in [('bench-node.mjs',p/'bench-node.mjs'),('bench-chrome.mjs',p/'bench-chrome.mjs'),('assets/worker.mjs',assets/'worker.mjs')]:
    text=(old/source).read_text().replace("'naive'","'jacobian_baseline'").replace('/naive/','/jacobian_baseline/').replace("'naive/","'jacobian_baseline/")
    text=text.replace('rows.length,12','rows.length,20').replace('/torch-iteration-70/performance/','/torch-iteration-71/performance/')
    text=text.replace("from '../fixture-server.mjs'","from '../../torch-iteration-70/fixture-server.mjs'")
    target.write_text(text)
shutil.copy2(old/'assets/index.html',assets/'index.html')
text=(old/'run.py').read_text().replace("'naive/stridetorch'","'jacobian_baseline/stridetorch'").replace('==12','==20').replace('range(12)','range(20)').replace('flows_per_child=12','flows_per_child=20')
text=text.replace('Nine existing public0.69API flows (publicVJP on both sides) and three separately labeled naiveprototype Jacobian comparisons.',
    'Seventeen existing public0.70API flows (including publicVJP/Jacobian) and three analytically validated HVP compositions of released0.70 public AD primitives.')
text=text.replace('ALL18 FRESH12-FLOW','ALL18 FRESH20-FLOW')
compile(text,str(p/'run.py'),'exec');(p/'run.py').write_text(text)
print('Prepared18fresh CPU/Node/Chrome processes,17public0.70 flows and3qualified HVP compositions; no timing started')
