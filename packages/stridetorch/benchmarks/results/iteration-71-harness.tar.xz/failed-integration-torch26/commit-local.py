"""Commit only the fully qualified implementation, exports and evidence."""
from pathlib import Path
import hashlib, json, subprocess

p=Path(__file__).resolve().parent
repo=Path('/Users/david/Developer/PaperLeet-torch-release')
read=lambda q: json.loads(q.read_text())
sha=lambda q: hashlib.sha256(q.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=repo)
local=read(p/'local-validation.json')
report=read(repo/'packages/stridetorch/benchmarks/results/iteration-71.json')
assert local['status']=='passed' and len(local['receipts'])==11 and all(v['exit_code']==0 for v in local['receipts'])
assert report['local_integration']==local
assert report['status']=='validated_locally' and report['version']=='0.71.0'
head=git('rev-parse','HEAD').decode().strip()
assert head==local['upstream']
for group,prefix in [('source-hashes.json','packages/stridetorch/src/stridetorch'),
    ('test-hashes.json','packages/stridetorch/tests'),('owned-input-sha256.json',''),
    ('new-assets-sha256.json',''),('application-input-sha256.json',''),('frontend-input-sha256.json',''),
    ('live-export-sha256.json','web/public/data'),('baseline-immutable-sha256.json','')]:
    for name,digest in read(p/group).items(): assert sha(repo/prefix/name)==digest, name
archive=report['raw_archive']
assert sha(repo/'packages/stridetorch/benchmarks/results'/archive['name'])==archive['sha256']
assert read(p/'archive-identity.json')==archive
expected=set(read(p/'owned-input-sha256.json'))|set(read(p/'new-assets-sha256.json'))
expected.update('web/public/data/'+n for n in ['catalog.json','index.json','index-v3.json'])
expected.update(['packages/stridetorch/benchmarks/results/iteration-71.json',
    'packages/stridetorch/benchmarks/results/iteration-71-harness.tar.gz',
    'docs/validation/torch-runtime-iteration-71.md'])
rows=[row.decode() for row in git('status','--porcelain','-z','--untracked-files=all').split(b'\0') if row]
assert {row[3:] for row in rows}==expected, ({row[3:] for row in rows}-expected,expected-{row[3:] for row in rows})
assert len(expected)==196 and all(row[:2] in [' M','??'] for row in rows)
subprocess.run(['git','diff','--check'],cwd=repo,check=True)
subprocess.run(['git','add','--',*sorted(expected)],cwd=repo,check=True)
assert set(git('diff','--cached','--name-only','-z').decode().split('\0'))-{''}==expected
subprocess.run(['git','commit','-m','feat(torch): add matrix-free HVP and differentiable curvature rules'],cwd=repo,check=True,stdout=subprocess.DEVNULL)
commit=git('rev-parse','HEAD').decode().strip()
assert not git('status','--porcelain','-z')
own=dict(expected_remote=head,source_commit=commit,adoption_candidate_commit=commit,
    qualified_application_baseline=local['upstream'],implementation_paths=len(expected))
(p/'own-commits.json').write_text(json.dumps(own,indent=2)+'\n')
print(json.dumps(own),flush=True)
