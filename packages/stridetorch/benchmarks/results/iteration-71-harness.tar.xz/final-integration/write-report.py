"""Write the human report from the terminal, exact-source machine report."""
from pathlib import Path
import json

p = Path(__file__).resolve().parent
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
report = json.loads((repo / 'packages/stridetorch/benchmarks/results/iteration-71.json').read_text())
assert report['status'] == 'validated_locally' and report['version'] == '0.71.0'
archive = report['raw_archive']
local = report['local_integration']
export = report['export_identity']
rows = report['performance']['rows']
legacy = []
for runtime in ['cpu', 'node', 'chrome']:
    selected = [row for row in rows if row['runtime'] == runtime and row['family'] != 'hvp']
    assert len(selected) == 17
    ratios = [row['medians']['candidate_over_baseline'] for row in selected]
    controls = [row['medians']['duplicate_over_baseline'] for row in selected]
    legacy.append(f'| {runtime} | {min(ratios):.4f}–{max(ratios):.4f} | {min(controls):.4f}–{max(controls):.4f} |')
hvp = []
for row in rows:
    if row['family'] != 'hvp':
        continue
    med = row['medians']
    ns = row['median_ns']
    hvp.append(f"| {row['runtime']} | {row['case']} | {med['duplicate_over_baseline']:.4f} | "
               f"{med['candidate_over_baseline']:.4f} | {med['candidate_over_duplicate']:.4f} | "
               f"{ns['baseline']/1000:.2f} → {ns['candidate']/1000:.2f} |")
memory = []
for row in report['cpu_allocations']['rows']:
    memory.append(f"| {row['shape']} | {row['dense_hessian_bytes']:,} | "
                  f"{row['direct_over_dense_peak']:.4f} | {row['dense_duplicate_over_dense_peak']:.4f} |")
hvp_ratios = [row['medians']['candidate_over_baseline'] for row in rows if row['family'] == 'hvp']
hvp_percent_range = f'{(min(hvp_ratios)-1)*100:.1f}% to {(max(hvp_ratios)-1)*100:.1f}%'
allocation_ratios = [row['direct_over_dense_peak'] for row in report['cpu_allocations']['rows']]
allocation_percent_range = f'{min(allocation_ratios)*100:.1f}%–{max(allocation_ratios)*100:.1f}%'
text = f'''# Torch runtime iteration 71: matrix-free Hessian-vector products

Version 0.71 adds `torch.autograd.functional.hvp(func, inputs, v=None,
create_graph=False, strict=False)` for supported real float32/float64 operators.
It returns the detached scalar objective and its Hessian-vector product without
assembling a dense Hessian. Tensor/tuple input structure is preserved; the
callback executes once with distinct detached input leaves, including repeated
arguments. Original data, gradient flags, `.grad` buffers and tensor hooks remain
intact. As with native functional AD, callbacks may update their own buffers:
training BatchNorm updates its tracked running statistics once.

The implementation differentiates a forward directional result in reverse.
LayerNorm, training BatchNorm/InstanceNorm, linear solves, slogdet and logdet
retain the dependencies needed for curvature. Ordinary JVP keeps its existing
native-compatible saved-statistic/factor behavior outside the scoped HVP path.
Near-singular determinant curvature uses cofactor products without division by
singular-value gaps. The general determinant rule uses quadratic matrix storage;
the nonsingular 2×2 path uses a direct polynomial expression.

There is one deliberate numerical extension: native higher-order SVD tapes can
produce NaNs at repeated singular values even though determinant is polynomial.
This library returns the finite polynomial curvature, checked with an independent
minor/cofactor chain-rule reference. These cases are identified separately below;
they are not claimed as exact native-output matches.

`strict=True` rejects independent objectives or constant derivatives as qualified
against native Torch 2.14.1. Omitted `v` requires a single one-element input;
supplied vectors follow input structure and are detached and converted to the
corresponding input dtype. `create_graph=True`, complex inputs, nested forward AD
and unsupported forward rules reject explicitly. Deliberate `detach()`,
`no_grad()` and `numpy(force=True)` disconnect the graph; implicit NumPy export
during the recorded callback is rejected. Module HVP attributes survive copy,
deepcopy, pickle and fresh-process restoration in both distribution namespaces.
This version adds no GPU backend or `torch.func.hessian` API.

Scalar `clamp`, `clamp_min` and `clamp_max` preserve the production Torch 2.6
inclusive-boundary derivative of one. A full-application regression rejected the
earlier attempt to follow Torch 2.14 strict boundaries; all 32 piecewise fixtures
now replay an isolated native Torch 2.6.0 oracle. Generic
absolute-value JVP retains an explicit zero reverse derivative with respect to
its primal while preserving functional-HVP constant-derivative strictness.

## Verification

- Full current application plus standalone CPU suite: **{report['full_cpu']['summary'][0]}**.
- Actual Pyodide application catalog: **{local['catalog_modules']} modules / {local['mutants']} mutants**, with no browser-budget exceedance.
- Exact selected source in Node and Chrome WASM: **8,350 SDK cases / 71 suites each**.
- Numerical and caller-state fixtures on CPU and independently replayed in Node and Chrome: **720 cases each**. Of these, **676** directly compare native results or expected errors, **4** use analytic/native-FP64 normalization precision controls, and **40** check the finite determinant polynomial extension described above. Groups cover 128 boundary cases, 128 caller-state cases, 208 model cases, 64 singular/empty determinant cases, 160 extended determinant cases and 32 piecewise cases.
- Models include linear layers, normalization, convolution, SDPA with the native math backend, captured MultiheadAttention, solve/inverse, Cholesky, determinant objectives, classifier, stateful BatchNorm and embedding. Shapes, dtypes, strided inputs, tuple structure, callback counts, existing gradients and hooks are checked where applicable. The other native fixture groups use Torch 2.14.1, git `5c4886908584029761b579af026dcfb627c84070`.
- Public wheel/sdist and private application wheel: **8,363 installed SDK cases** on Python 3.10.19 / NumPy 1.26.4 without native Torch. All 61 runtime/license resources and 37 application source identities match. Co-installation/uninstall ownership, explicit aliases, checkpoint resume and fresh-process activation/VJP/Jacobian/HVP restoration passed.
- **{local['frontend_commands']} frontend commands**, WASM-driver and release-policy checks, two Node 22.23.3 local build profiles and exact generated Worker derivation from its tracked source graph.
- **{export['preserved_assets']:,}** older immutable assets retained; **{export['new_assets']}** new reachable assets and **{export['active_export_and_index_hashes']}** live export/index identities verified.
- Application baseline: `{report['upstream']}`. Main adoption is recorded separately after the guarded push.

## Latency and allocation

The latency run uses 18 fresh processes: six each for CPU, Node WASM and Chrome
WASM, all six source-load orders, twelve balanced common batches of at least
20 ms per flow, and an identical-source A/A control. Each child runs 20 flows
after numerical, dtype, shape, alias and caller-state checks. Seventeen flows
compare existing public 0.70 and 0.71 APIs, including public VJP and Jacobian.
The three HVP flows use an analytically checked composition of released 0.70
public JVP/grad primitives as reference; 0.70 had no public functional HVP API.

Ratios are medians of per-process ratios, not ratios of pooled absolute medians.
Lower B/A means faster. Across the old APIs, measured medians remain close to
same-source control variation; this is a bounded observation, not a universal
no-regression guarantee.

| Runtime | Existing API B/A range | Same-source A/A range |
| --- | --- | --- |
{chr(10).join(legacy)}

The HVP entry point has measured runtime changes of {hvp_percent_range} relative
to its composed reference across these three flows and runtimes. The measurements do not isolate the cause of that difference.
Absolute values below are pooled median microseconds, reported alongside the
separately computed paired ratios.

| Runtime | HVP flow | A/A | B/A | B/AA | Reference → candidate µs |
| --- | --- | --- | --- | --- | --- |
{chr(10).join(hvp)}

A separate CPU `tracemalloc` experiment checks three float64 sin objectives,
six balanced call orders and a dense duplicate A/A control. Its dense reference
assembles the full Hessian from the **same selected HVP implementation's basis
calls** and then multiplies by the vector. Analytic `-sin(x) * v` and caller state
are checked. This tests the storage advantage of direct products, not a distinct
released Hessian API or an independent derivative implementation.

| Input shape | Dense Hessian bytes | Direct / dense peak allocation | Dense A/A peak |
| --- | --- | --- | --- |
{chr(10).join(memory)}

Direct products use {allocation_percent_range} of the dense reference's tracked peak allocation
in these cases. These are Python/NumPy CPU allocations from one process, not
RSS, WASM heap, GPU memory, latency or a universal gain. Our heavy package tests,
application gates and allocation experiment did not overlap the latency children.

## Evidence and remaining scope

Machine report: `packages/stridetorch/benchmarks/results/iteration-71.json`.
Raw archive: `{archive['name']}` ({archive['bytes']:,} bytes), SHA256
`{archive['sha256']}`. Every one of {archive['files']} logical payloads was verified
after writing. Content-identical hardlinks require matching mode and ownership;
timestamps are not comparison inputs. The archive preserves original failed
prototypes, native and analytic fixtures, exact source/test snapshots, package
artifacts, latency samples and current-application gate logs. Scripts retain
absolute paths and require dependency setup and path adjustment for replay.

Only `production-release/snapshot/packages/stridetorch` is the selected final
source. Earlier snapshots and failed native-WASM NaN-mask attempts retain their
own original identities. General nonfinite piecewise behavior remains a future
audit target. GPU suitability work remains separate; this version enables no
GPU dispatch. No CI workflow, tag, package publication or deployment was initiated
by these checks. The library remains named StrideTorch pending a naming decision.
'''
(repo / 'docs/validation/torch-runtime-iteration-71.md').write_text(text)
print('Wrote exact-source terminal-evidence report; no commit or push', flush=True)
