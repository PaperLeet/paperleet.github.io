"""Publish evidence only after the complete current-application gates pass."""
from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, tarfile

p = Path(__file__).resolve().parent
r = p.parent
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
out = repo / 'packages/stridetorch/benchmarks/results'
read = lambda q: json.loads(q.read_text())
sha = lambda q: hashlib.sha256(q.read_bytes()).hexdigest()
def save(q, value): q.write_text(json.dumps(value, indent=2) + '\n')

source = read(p / 'source-hashes.json')
tests = read(p / 'test-hashes.json')
assert len(source) == 61 and len(tests) == 72
for name, digest in source.items(): assert sha(repo / 'packages/stridetorch/src/stridetorch' / name) == digest
for name, digest in tests.items(): assert sha(repo / 'packages/stridetorch/tests' / name) == digest
for manifest, prefix in [('application-input-sha256.json', repo), ('frontend-input-sha256.json', repo),
    ('owned-input-sha256.json', repo), ('baseline-immutable-sha256.json', repo),
    ('new-assets-sha256.json', repo), ('live-export-sha256.json', repo / 'web/public/data')]:
    for name, digest in read(p / manifest).items(): assert sha(prefix / name) == digest, (manifest, name)
local = read(p / 'local-validation.json')
assert local['status'] == 'passed' and local['source_hashes'] == source
assert len(local['receipts']) == 11 and all(v['exit_code'] == 0 for v in local['receipts'])
for receipt in local['receipts']: assert sha(p / (receipt['label'] + '.log')) == receipt['log_sha256']
cpu = read(p / 'cpu-receipt.json')
assert cpu['exit_code'] == 0 and cpu['source_hashes'] == source
cpu_cases = int(re.search(r'(\d+) passed', cpu['summary'][0]).group(1))
assert cpu_cases == 41989
wasm = read(p / 'full-wasm-result.json')
count = read(p / 'context.json')['catalog_modules']
assert wasm['passed'] and wasm['catalog_modules'] == wasm['modules'] == count
assert len(wasm['results']) == count and not wasm['browser_budget_exceeded']
assert all(v['passed'] and not v['browser_budget_exceeded'] for v in wasm['results'])
contracts = next(v for v in wasm['results'] if v['id'] == 'architecture/attention')['independent_contracts']
assert contracts['passed'] == 8350 and len(contracts['suites']) == 71
assert {v['suite']: v['source_sha256'] for v in contracts['suites']} == {n:h for n,h in tests.items() if n != 'test_standalone.py'}
selected=r/'production-release'
freeze=read(selected/'source-freeze.json')
assert freeze['source_hashes']==source and freeze['test_hashes']==tests and freeze['version']=='0.71.0'
for name,digest in freeze['package_hashes'].items(): assert sha(repo/'packages/stridetorch'/name)==digest
core=read(selected/'core-and-package-proof.json')
assert core['source_hashes']==source and core['test_hashes']==tests
for name,digest in core['evidence_sha256'].items(): assert sha(selected/name)==digest
package_root=selected/'package-proof'
package=read(package_root/'package-identity.json')
assert package['status']=='success' and package['source_hashes']==source
assert package['standalone_installed_tests']==8363 and package['native_torch'] is False
for name,digest in package['application_source_hashes'].items():assert sha(repo/name)==digest
for name,digest in package['artifacts'].items():assert sha(package_root/name)==digest
runtime_proofs={}
for label,name in [('node','node-result.json'),('chrome','chrome-contracts/result.json')]:
    proof=read(selected/'wasm-proof'/name)
    assert proof['status']=='success' and proof['source_hashes']==source and proof['test_hashes']=={k:h for k,h in tests.items() if k!='test_standalone.py'}
    assert proof['library']=='0.71.0' and proof['passed']==8350 and proof['suites']==71 and not proof['failures']
    runtime_proofs[label]=proof
native_wasm={}
plan=read(selected/'native-wasm-proof/plan.json')
for name,digest in plan['fixtures'].items():assert sha(selected/'native-wasm-proof/fixtures'/name)==digest
for label,name in [('node','node-result.json'),('chrome','chrome/result.json')]:
    proof=read(selected/'native-wasm-proof'/name)
    assert proof['status']=='success' and proof['source_hashes']==source and not proof['failures']
    assert proof['cases']==720 and proof['direct_native_cases']==676 and proof['fixture_hashes']==plan['fixtures']
    assert len(proof['polynomial_extension_controls'])==40 and len(proof['independent_precision_controls'])==4
    assert proof['native_reference_profiles']==plan['native_reference_profiles']
    native_wasm[label]=proof
native={key:read(selected/(key+'-qualification.json')) for key in ['boundary','models','singular','singular_extended','piecewise']}
assert sum(v['cases'] for v in native.values())==720
for proof in native.values():assert proof['status']=='passed' and proof['source_hashes']==source and not proof['failures']
formal=read(r/'production-performance/summary.json')
memory=read(r/'production-performance/hvp-memory.json')
assert formal['status']=='completed' and formal['fresh_children']==18 and formal['flows_per_child']==20
assert len(formal['rows'])==60 and sum(v['family']=='hvp' for v in formal['rows'])==9
assert formal['source_hashes']['candidate']==memory['source_hashes']==source
baseline=read(p/'baseline-source-sha256.json')
assert formal['source_hashes']==dict(baseline=baseline,candidate=source,duplicate=baseline,jacobian_baseline=baseline)
assert memory['status']=='passed' and len(memory['rows'])==3
review=read(p/'performance-reviewed.json')
assert review['proceed_local_validation'] and review['performance_sha256']==sha(r/'production-performance/summary.json')
assert review['memory_sha256']==sha(r/'production-performance/hvp-memory.json')
if 'controls_sha256' in review: assert review['controls_sha256']==sha(r/review['controls_path'])
worker = read(p / 'generated-worker-proof.json')
assert worker['status'] == 'verified'
for name, digest in worker['inputs'].items(): assert sha(repo / name) == digest
assert sha(repo / worker['asset']) == worker['asset_sha256']
policy = read(p / 'release-policy-identity.json')
for group in [policy['files'], policy['workflows']]:
    for name, digest in group.items(): assert sha(repo / name) == digest
head = subprocess.check_output(['git','rev-parse','HEAD'], cwd=repo, text=True).strip()
assert head == local['upstream']
export = read(p / 'export-identity.json')
assert export['version'] == '0.71.0' and export['source_hashes'] == source and export['catalog_modules'] == count
snapshot = p / 'published-inputs'
snapshot.mkdir(exist_ok=True)
for name, target in [('src/stridetorch','runtime-source'), ('tests','runtime-tests')]:
    shutil.copytree(repo / 'packages/stridetorch' / name, snapshot / target,
        ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'), dirs_exist_ok=True)
for name in ['README.md','pyproject.toml','LICENSE','NOTICE']: shutil.copy2(repo / 'packages/stridetorch' / name, snapshot / name)
archive = out / 'iteration-71-harness.tar.gz'
assert not archive.exists()
seen = {}; payloads = {}; hardlinks = 0; logical_bytes = 0
excluded = {'__pycache__','.pytest_cache','.git','pytest-tmp','sdk-pytest-tmp','node_modules','build','dist'}
allowed = {'.py','.mjs','.json','.log','.md','.html','.toml','.npz','.txt','.whl','.pkl','.patch','.in','.ini','.yaml','.yml','.csv','.cjs','.ts','.tsx','.css'}
with tarfile.open(archive,'w:gz') as target:
    for current, dirs, files in os.walk(r):
        dirs[:] = sorted(n for n in dirs if n not in excluded and not n.endswith(('-env','-venv','.egg-info')))
        for name in sorted(files):
            q = Path(current) / name
            if q.is_symlink() or not (q.name in ['LICENSE','NOTICE','.gitignore'] or q.suffix in allowed or q.name.endswith('.tar.gz')): continue
            arc = str(q.relative_to(r)); digest = sha(q); payloads[arc] = digest
            info = target.gettarinfo(str(q), arcname=arc); logical_bytes += q.stat().st_size
            key = (digest,info.mode,info.uid,info.gid,info.uname,info.gname)
            if key in seen:
                info.type = tarfile.LNKTYPE; info.linkname = seen[key]; info.size = 0; target.addfile(info); hardlinks += 1
            else:
                seen[key] = arc
                with q.open('rb') as data: target.addfile(info,data)
with tarfile.open(archive,'r:gz') as target:
    assert len(target.getmembers()) == len(payloads)
    for member in target.getmembers(): assert hashlib.sha256(target.extractfile(member).read()).hexdigest() == payloads[member.name]
record = dict(name=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),files=len(payloads),
              unique_payloads=len(seen),hardlinks=hardlinks,logical_bytes=logical_bytes,
              all_logical_payloads_verified=True,filesystem_timestamps_not_comparison_inputs=True)
assert record['bytes'] < 95*1024*1024
save(p / 'archive-identity.json',record)
report=dict(status='validated_locally',version='0.71.0',baseline_version='0.70.0',upstream=head,
    source_hashes=source,test_hashes=tests,owned_inputs=read(p/'owned-input-sha256.json'),full_cpu=cpu,
    full_wasm=wasm,independent_package=package,versioned_runtime_contracts=runtime_proofs,native_hvp=native,
    native_and_analytic_wasm=native_wasm,native_fixture_plan=plan,core_package_qualification=core,
    local_integration=local,export_identity=export,active_export_sha256=read(p/'live-export-sha256.json'),
    release_policies=policy,generated_worker_derivation=worker,performance=formal,
    performance_review=review,cpu_allocations=memory,raw_archive=record,
    limitations=['Detached real float32/64 HVP results only; create_graph,complex,nested forward AD and unsupported forward rules reject. No GPU backend.',
        '676 direct native cases include expected errors;4 FP32 normalization cases use independent analytic/native-FP64 controls;40 determinant cases deliberately provide finite polynomial curvature where the native SVD tape gives NaNs.',
        'HVP latency reference is a validated composition of released0.70 public AD primitives, not a public0.70 functional HVP API. Interpret exact measured ratios together with both A/A denominators and the recorded review.',
        'Allocation evidence is one CPU process,three float64 sin objectives;dense reference assembles a Hessian from the same selected HVP basis calls. Not RSS,WASM/GPU memory,latency or a universal gain.',
        'Archive preserves rejected earlier candidates and failures with their original source/version identities. Scripts retain absolute paths and require dependency setup/path adjustment.',
        'Local validation does not imply main adoption,CI,release or deployment.'])
save(out/'iteration-71.json',report)
save(p/'state.json',dict(status='all_local_gates_passed',version='0.71.0',source_hashes=source,upstream=head,main_adopted=False))
print(json.dumps(dict(status=report['status'],cpu=cpu['summary'],wasm_modules=count,mutants=local['mutants'],raw_archive=record)),flush=True)
