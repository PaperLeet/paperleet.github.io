"""Replay immutable native fixtures against the isolated HVP candidate."""
from pathlib import Path
import hashlib, json, os, subprocess, sys
import numpy as np

r=Path(__file__).resolve().parent
candidate=r/'candidate/packages/stridetorch/src'
out=r/'boundary-proof';out.mkdir(exist_ok=True)
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
env=dict(os.environ,PYTHONPATH=str(candidate),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
results=[];failures=[]
def normalized(value):
    if isinstance(value,dict):return {k:(v.removeprefix('torch.') if k=='dtype' else normalized(v)) for k,v in value.items()}
    if isinstance(value,list):return [normalized(v) for v in value]
    return value
def compare(a,b,path):
    if isinstance(a,dict):
        assert set(a)==set(b),(path,set(a),set(b))
        for key in a:compare(a[key],b[key],path+'.'+key)
    elif isinstance(a,list):
        assert len(a)==len(b),(path,len(a),len(b))
        for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+f'[{i}]')
    elif isinstance(a,(float,int)) and not isinstance(a,bool):
        np.testing.assert_allclose(b,a,rtol=3e-6,atol=2e-7,err_msg=path)
    else:assert a==b,(path,a,b)
for probe,native_name in [('probe-hvp.py','native-hvp.json'),('probe-hvp-caller-state.py','native-hvp-caller-state.json')]:
    source=(r/probe).read_text().replace('import torch','from stridetorch import torch, __version__ as library_version').replace('torch.__version__','library_version').replace('native_git=torch.version.git_version',"native_git='adapter-not-native'")
    script=out/probe;script.write_text(source)
    output=out/native_name
    with output.open('w') as stdout,(out/(probe+'.stderr')).open('w') as stderr:
        child=subprocess.run([sys.executable,str(script)],env=env,stdout=stdout,stderr=stderr)
    child.check_returncode()
    native=json.loads((r/native_name).read_text());actual=json.loads(output.read_text())
    assert native['cases']==actual['cases']==128
    for i,(a,b) in enumerate(zip(native['rows'],actual['rows'])):
        try:
            assert a['case']==b['case'] and a['status']==b['status'],('status',a['status'],b['status'],b.get('message'))
            for key in ['strict','original_grad','requires_grad','seed_grad','calls','hooks','caller_preserved','distinct_observed_tensors']:
                if key in a:compare(a[key],b[key],key)
            if a['status']=='success':compare(normalized(a['result']),normalized(b['result']),'result')
        except (AssertionError,TypeError,KeyError) as error:
            failures.append(dict(probe=probe,index=i,case=a['case'],strict=a['strict'],error=str(error),native=a,actual=b))
    results.append(dict(probe=probe,cases=actual['cases'],native_sha256=sha(r/native_name),candidate_sha256=sha(output),replayed_program_sha256=sha(script)))
report=dict(status='failed' if failures else 'passed',cases=256,source_hashes={q.name:sha(q) for q in (candidate/'stridetorch').iterdir() if q.suffix=='.py' or q.name in ['LICENSE','NOTICE']},results=results,failures=failures)
(out/'qualification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],cases=report['cases'],failures=[dict(probe=v['probe'],index=v['index'],case=v['case'],error=v['error']) for v in failures])),flush=True)
sys.exit(bool(failures))
