"""Boundary inventory for determinant HVPs at singular and empty matrices."""
import json,math
import numpy as np
from stridetorch import torch, __version__ as library_version

def values(array):
    if isinstance(array,list):return [values(a) for a in array]
    return array if math.isfinite(array) else ('nan' if math.isnan(array) else ('inf' if array>0 else '-inf'))
def record(tensor):
    return dict(shape=list(tensor.shape),dtype=str(tensor.dtype).split('.')[-1],
        requires_grad=tensor.requires_grad,values=values(tensor.detach().numpy().tolist()))
matrices={'empty':np.empty((0,0)),'scalar_zero':np.zeros((1,1)),
    'rank_one_two':np.diag([0.,2.]),'rank_two_three':np.diag([0.,2.,3.]),
    'rank_one_three':np.diag([0.,0.,3.]),'nonsymmetric_rank_two':np.array([[1.,2.,3.],[2.,4.,6.],[0.,1.,1.]]),
    'rank_one_ones':np.ones((3,3)),'full_rank_three':np.diag([2.,3.,4.])}
rows=[]
for dtype in [torch.float32,torch.float64]:
    for strict in [False,True]:
        for squared in [False,True]:
            for case,data in matrices.items():
                x=torch.tensor(data,dtype=dtype,requires_grad=True);x.grad=torch.ones_like(x)*3
                buffer=x.grad;hooks=[];handle=x.register_hook(lambda g:hooks.append(g))
                vector=torch.ones_like(x);calls=[]
                def callback(a):
                    calls.append(torch.is_grad_enabled());out=torch.det(a)
                    return out.square() if squared else out
                row=dict(case=case,dtype=str(dtype).split('.')[-1],strict=strict,squared=squared)
                try:
                    with torch.no_grad():result=torch.autograd.functional.hvp(callback,x,vector,strict=strict)
                    row.update(status='success',result=[record(a) for a in result])
                except Exception as error:row.update(status='error',exception=type(error).__name__,message=str(error))
                assert x.grad is buffer and torch.equal(x.grad,torch.ones_like(x)*3) and not hooks
                row.update(calls=calls,caller_preserved=True);handle.remove();rows.append(row)
print(json.dumps(dict(torch=library_version,native_git='adapter-not-native',cases=len(rows),rows=rows),indent=2,allow_nan=False))
