"""Independent analytical HVP for the failing FP32 instance-normalization case."""
import json
import numpy as np
import torch

rng=np.random.default_rng(7021)
arrays=[(rng.normal(size=s)*.2).astype('float32') for s in [(2,2,3),(2,),(2,)]]
directions=[np.cos(np.arange(a.size)*.11+i).reshape(a.shape).astype('float32') for i,a in enumerate(arrays)]
x,w,b=[a.astype('float64') for a in arrays]
dx,dw,db=[a.astype('float64') for a in directions]
w=w.reshape(1,2,1);b=b.reshape(1,2,1);dw=dw.reshape(1,2,1);db=db.reshape(1,2,1)
c=x-x.mean(-1,keepdims=True);dc=dx-dx.mean(-1,keepdims=True)
r=(np.mean(c*c,-1,keepdims=True)+1e-5)**-.5
dr=-r**3*np.mean(c*dc,-1,keepdims=True)
n=c*r;dn=dc*r+c*dr
y=n*w+b;dy=dn*w+n*dw+db
g=2*y*w;dg=2*dy*w+2*y*dw
projected=g-g.mean(-1,keepdims=True)-n*np.mean(g*n,-1,keepdims=True)
hx=dr*projected+r*(dg-dg.mean(-1,keepdims=True)-dn*np.mean(g*n,-1,keepdims=True)-n*np.mean(dg*n+g*dn,-1,keepdims=True))
hw=np.sum(2*dy*n+2*y*dn,axis=(0,2));hb=np.sum(2*dy,axis=(0,2))
reference=[hx,hw,hb]
rows=[]
for dtype in [torch.float32,torch.float64]:
    inputs=tuple(torch.tensor(a,dtype=dtype) for a in arrays)
    vectors=tuple(torch.tensor(a,dtype=dtype) for a in directions)
    value,hvp=torch.autograd.functional.hvp(lambda a,w,b:torch.nn.functional.instance_norm(a,weight=w,bias=b).square().sum(),inputs,vectors)
    values=[a.numpy().tolist() for a in hvp]
    errors=[float(np.max(np.abs(np.asarray(a)-b))) for a,b in zip(values,reference)]
    rows.append(dict(dtype=str(dtype).split('.')[-1],output=value.item(),hvp=values,max_abs_errors_vs_analytic=errors))
print(json.dumps(dict(scope='Same FP32-quantized inputs and vectors in both runtimes/dtypes. Independent NumPy chain rule; no AD or finite differences in reference.',
    arrays=[a.tolist() for a in arrays],directions=[a.tolist() for a in directions],reference=[a.tolist() for a in reference],rows=rows),indent=2,allow_nan=False))
