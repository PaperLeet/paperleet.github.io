"""Dense rank defects, batched branch selection, empty inputs and caller state."""
import json,math
import numpy as np
import torch

def values(a):
    if isinstance(a,list):return [values(v) for v in a]
    return a if math.isfinite(a) else ('nan' if math.isnan(a) else ('inf' if a>0 else '-inf'))
def record(a):
    if isinstance(a,tuple):return [record(v) for v in a]
    return dict(shape=list(a.shape),dtype=str(a.dtype).split('.')[-1],requires_grad=a.requires_grad,values=values(a.detach().numpy().tolist()))
cases=['dense_rank_two','dense_rank_three','dense_rank_four','mixed_batch','full_rank_five',
       'empty_batch','empty_cores','two_zero','tiny_identity','mixed_empty_input']
rows=[]
for dtype in [torch.float32,torch.float64]:
    np_dtype=np.float32 if dtype==torch.float32 else np.float64
    for strict in [False,True]:
        for squared in [False,True]:
            for strided in [False,True]:
                for case in cases:
                    rng=np.random.default_rng(7109)
                    if case.startswith('dense_rank'):
                        n={'dense_rank_two':3,'dense_rank_three':4,'dense_rank_four':5}[case]
                        u=np.linalg.qr(rng.normal(size=(n,n)))[0];v=np.linalg.qr(rng.normal(size=(n,n)))[0]
                        data=u@np.diag([0.,*(.2*np.arange(2,n+1))])@v.T
                    elif case=='mixed_batch':data=np.array([np.diag([0.,2.,3.]),[[2.,.2,0.],[.1,3.,.3],[0.,.4,4.]],[[1.,2.,3.],[2.,4.,6.],[0.,1.,1.]]])
                    elif case=='full_rank_five':data=np.diag(.4*np.arange(1,6))+.03
                    elif case=='empty_batch':data=np.empty((0,3,3))
                    elif case=='empty_cores':data=np.empty((2,0,0))
                    elif case=='two_zero':data=np.zeros((2,2))
                    elif case=='tiny_identity':data=np.eye(2)*np.sqrt(np.finfo(np_dtype).eps)
                    else:data=np.empty((0,0))
                    def tensor(array):
                        array=np.asarray(array,dtype=np_dtype)
                        if strided:
                            storage=np.empty(array.shape+(2,),dtype=np_dtype);storage[...,0]=array;storage[...,1]=-7;array=storage[...,0]
                        return torch.from_numpy(array).requires_grad_(True)
                    x=tensor(data)
                    inputs=(x,tensor([.3,.7])) if case=='mixed_empty_input' else (x,)
                    vectors=tuple(tensor(np.cos(np.arange(a.numel())*.13+i).reshape(a.shape)) for i,a in enumerate(inputs))
                    snapshots=[];hooks=[];handles=[]
                    for a in (*inputs,*vectors):
                        a.grad=torch.ones_like(a)*3
                        snapshots.append((a,a.detach().clone(),a.grad,a.grad.clone(),a.stride(),a.requires_grad))
                        handles.append(a.register_hook(lambda g:hooks.append(g)))
                    calls=[]
                    def callback(*args):
                        calls.append(torch.is_grad_enabled());result=torch.det(args[0])
                        if case=='mixed_empty_input':result=result*args[1].square().sum()
                        elif case=='mixed_batch':result=(result*torch.tensor([.7,-.2,.4],dtype=dtype)).sum()
                        else:result=result.sum()
                        return result.square() if squared else result
                    row=dict(case=case,dtype=str(dtype).split('.')[-1],strict=strict,squared=squared,strided=strided,
                        fixture_inputs=record(inputs),fixture_vectors=record(vectors))
                    try:
                        with torch.no_grad():result=torch.autograd.functional.hvp(callback,inputs,vectors,strict=strict)
                        row.update(status='success',result=record(result))
                    except Exception as error:row.update(status='error',exception=type(error).__name__,message=str(error))
                    preserved=all(torch.equal(a.detach(),before) and a.grad is buffer and torch.equal(a.grad,gradient) and a.stride()==stride and a.requires_grad==flag for a,before,buffer,gradient,stride,flag in snapshots)
                    assert preserved and not hooks and calls==[True]
                    for handle in handles:handle.remove()
                    row.update(caller_preserved=bool(preserved),hooks=len(hooks),calls=calls);rows.append(row)
print(json.dumps(dict(torch=torch.__version__,native_git=torch.version.git_version,cases=len(rows),rows=rows),indent=2,allow_nan=False))
