"""Select and freeze 0.71 source before repeating the complete SDK gates."""
from pathlib import Path
import hashlib,json,shutil,sys

r=Path(__file__).resolve().parent
piecewise=sys.argv[1:]==['--piecewise'];portable=sys.argv[1:]==['--portable'] or piecewise;assert not sys.argv[1:] or portable
v=r/('production-release' if piecewise else 'portable-release' if portable else 'versioned-release');v.mkdir()
package=r/'candidate/packages/stridetorch';snapshot=v/'snapshot/packages/stridetorch'
shutil.copytree(package,snapshot,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
source={q.name:sha(q) for q in (snapshot/'src/stridetorch').iterdir() if q.suffix=='.py' or q.name in ['LICENSE','NOTICE']}
tests={q.name:sha(q) for q in (snapshot/'tests').glob('test_*.py')}
assert len(source)==61 and len(tests)==(72 if piecewise else 71)
freeze=dict(source_hashes=source,test_hashes=tests,version='0.71.0',package_hashes={n:sha(snapshot/n) for n in ['pyproject.toml','README.md','LICENSE','NOTICE']})
(v/'source-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
(v/'source-hashes.json').write_text(json.dumps(source,indent=2)+'\n')
(v/'test-hashes.json').write_text(json.dumps(tests,indent=2)+'\n')
p=v/'wasm-proof';c=p/'chrome-contracts';c.mkdir(parents=True)
for name in ['node.mjs','sdk.py']:
    shutil.copy2(r/'wasm-proof'/name,p/name)
for directory,manifest,origin in [('source',source,snapshot/'src/stridetorch'),('tests',{k:h for k,h in tests.items() if k!='test_standalone.py'},snapshot/'tests')]:
    (c/directory).mkdir()
    for name,digest in manifest.items():
        assert sha(origin/name)==digest;shutil.copy2(origin/name,c/directory/name)
plan=dict(source=source,tests={k:h for k,h in tests.items() if k!='test_standalone.py'},version='0.71.0',prototype_iteration=71,expected=8350 if piecewise else 8318,
    scope='Exact final-version candidate SDK. Native boundary/model fixtures, packaging, performance and application adoption are recorded separately.')
(c/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
shutil.copy2(r/'wasm-proof/chrome-contracts/index.html',c/'index.html')
worker=(r/'wasm-proof/chrome-contracts/worker.mjs').read_text().replace('../../../extraction-browser/','../../../../extraction-browser/').replace('../../../runtime-0.29.4/','../../../../runtime-0.29.4/')
(c/'worker.mjs').write_text(worker)
driver=(r/'wasm-proof/chrome-contracts/run.mjs').read_text().replace('../../../torch-iteration-70/','../../../../torch-iteration-70/').replace('/torch-iteration-71/wasm-proof/','/torch-iteration-71/'+v.name+'/wasm-proof/')
(c/'run.mjs').write_text(driver)
print('Frozen selected0.71:',len(source),'source identities',len(tests),'test files,8318 WASM SDK cases')
