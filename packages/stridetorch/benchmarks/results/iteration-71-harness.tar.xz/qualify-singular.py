"""Tolerance-qualified singular/empty determinant replay, including NaN masks."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
import numpy as np
from determinant_reference import reference

r=Path(__file__).resolve().parent
extended=sys.argv[1:]==['--extended'];assert not sys.argv[1:] or extended
p=r/('singular-extended-proof' if extended else 'singular-proof');p.mkdir(exist_ok=True)
probe=r/('probe-singular-det-hvp-extended.py' if extended else 'probe-singular-det-hvp.py')
native_path=r/('native-singular-det-hvp-extended.json' if extended else 'native-singular-det-hvp.json')
candidate=r/'candidate/packages/stridetorch/src'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
script=probe.read_text().replace('import torch','from stridetorch import torch, __version__ as library_version').replace('torch.__version__','library_version').replace('torch.version.git_version',"'adapter-not-native'")
(p/'probe.py').write_text(script)
with (p/'candidate.json').open('w') as output,(p/'stderr.log').open('w') as error:
    child=subprocess.run([sys.executable,str(p/'probe.py')],env=dict(os.environ,PYTHONPATH=str(candidate),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2'),stdout=output,stderr=error)
child.check_returncode()
native=json.loads(native_path.read_text());actual=json.loads((p/'candidate.json').read_text())
count=160 if extended else 64
assert native['cases']==actual['cases']==count
failures=[];maximum=0.;polynomial_extensions=[]
def compare(x,y,dtype):
    global maximum
    if isinstance(x,list):
        assert len(x)==len(y)
        for a,b in zip(x,y):compare(a,b,dtype)
        return
    for key in ['shape','dtype','requires_grad']:assert x[key]==y[key],(key,x[key],y[key])
    nx=np.asarray(x['values'],dtype=float);ny=np.asarray(y['values'],dtype=float)
    np.testing.assert_allclose(ny,nx,rtol=3e-5 if dtype=='float32' else 1e-9,atol=3e-6 if dtype=='float32' else 2e-10,equal_nan=True)
    finite=np.isfinite(nx)&np.isfinite(ny)
    if np.any(finite):maximum=max(maximum,float(np.max(np.abs(nx[finite]-ny[finite]))))
for a,b in zip(native['rows'],actual['rows']):
    try:
        for key in ['case','dtype','strict','squared','status','caller_preserved','calls']:assert a[key]==b[key],(key,a[key],b[key],b.get('message'))
        for key in ['strided','hooks']:
            if key in a:assert a[key]==b[key],key
        assert a['fixture_inputs']==b['fixture_inputs'] and a['fixture_vectors']==b['fixture_vectors']
        if a['status']=='success':
            native_values=a['result'][1] if isinstance(a['result'][1],list) else [a['result'][1]]
            if any(np.isnan(np.asarray(value['values'],dtype=float)).any() for value in native_values):
                assert len(native_values)==1
                native_value=native_values[0]
                compare(a['result'][0],b['result'][0],a['dtype'])
                actual=b['result'][1][0] if isinstance(b['result'][1],list) else b['result'][1]
                assert actual['shape']==native_value['shape'] and actual['dtype']==native_value['dtype'] and not actual['requires_grad']
                target=reference(a['fixture_inputs'],a['fixture_vectors'],a['squared'])
                data=np.asarray(actual['values'],dtype=float)
                assert np.isfinite(data).all()
                np.testing.assert_allclose(data,target,rtol=1e-5,atol=np.finfo(a['dtype']).tiny)
                polynomial_extensions.append(dict(case=a['case'],dtype=a['dtype'],strict=a['strict'],squared=a['squared'],strided=a.get('strided'),max_abs_error=float(np.max(np.abs(data-target)))))
            else:compare(a['result'],b['result'],a['dtype'])
    except (AssertionError,TypeError,KeyError) as error:
        failures.append(dict(case=a['case'],dtype=a['dtype'],strict=a['strict'],squared=a['squared'],error=str(error),native=a,actual=b))
assert len(polynomial_extensions)==(32 if extended else 8),len(polynomial_extensions)
report=dict(status='failed' if failures else 'passed',cases=count,failures=failures,max_finite_abs_difference=maximum,
    direct_native_cases=count-len(polynomial_extensions),polynomial_extension_controls=polynomial_extensions,
    polynomial_reference_sha256=sha(r/'determinant_reference.py'),
    source_hashes={q.name:sha(q) for q in (candidate/'stridetorch').iterdir() if q.suffix=='.py' or q.name in ['LICENSE','NOTICE']},
    native_sha256=sha(native_path),candidate_sha256=sha(p/'candidate.json'),probe_sha256=sha(p/'probe.py'),
    scope='Current isolated prototype; native singular/empty determinant fixtures only, with matching finite values, NaN masks, strictness, shapes, callback count and observed caller state. Not a full candidate requalification.')
(p/'qualification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],cases=count,max_abs_difference=maximum,failures=[{k:v[k] for k in ['case','dtype','strict','squared','error']} for v in failures])),flush=True)
sys.exit(bool(failures))
