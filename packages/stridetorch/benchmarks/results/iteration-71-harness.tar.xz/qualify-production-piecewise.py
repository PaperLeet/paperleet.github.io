from pathlib import Path
import hashlib,json,os,subprocess,sys
import numpy as np

r=Path(__file__).resolve().parent;p=r/'production-piecewise-proof';p.mkdir(exist_ok=True)
source=r/'candidate/packages/stridetorch/src'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
program=(r/'probe-piecewise-jvp.py').read_text().replace('import torch','from stridetorch import torch, __version__ as library_version').replace('torch.__version__','library_version').replace('torch.version.git_version',"'adapter-not-native'")
(p/'probe.py').write_text(program)
with (p/'candidate.json').open('w') as output,(p/'stderr.log').open('w') as error:
    child=subprocess.run([sys.executable,str(p/'probe.py')],env=dict(os.environ,PYTHONPATH=str(source),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2'),stdout=output,stderr=error)
child.check_returncode()
native=json.loads((r/'native-piecewise-jvp-torch26.json').read_text());candidate=json.loads((p/'candidate.json').read_text());assert native['cases']==candidate['cases']==32
def compare(a,b):
    if a is None:assert b is None
    elif isinstance(a,dict):
        assert set(a)==set(b)
        if 'values' in a:
            for key in ['shape','dtype','requires_grad']:assert a[key]==b[key],(key,a[key],b[key])
            np.testing.assert_allclose(b['values'],a['values'],rtol=1e-6,atol=1e-8)
        else:
            for key in a:compare(a[key],b[key])
    elif isinstance(a,list):
        assert len(a)==len(b)
        for x,y in zip(a,b):compare(x,y)
    else:assert a==b,(a,b)
failures=[]
for a,b in zip(native['rows'],candidate['rows']):
    try:compare(a,b)
    except (AssertionError,TypeError,KeyError) as error:failures.append(dict(case=a['case'],dtype=a['dtype'],gx=a['gx'],gv=a['gv'],error=str(error),native=a,actual=b))
report=dict(status='failed' if failures else 'passed',cases=32,failures=failures,source_hashes={q.name:sha(q) for q in (source/'stridetorch').iterdir() if q.suffix=='.py' or q.name in ['LICENSE','NOTICE']},native_sha256=sha(r/'native-piecewise-jvp-torch26.json'),candidate_sha256=sha(p/'candidate.json'),probe_sha256=sha(p/'probe.py'))
(p/'qualification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],cases=32,failures=[{k:v[k] for k in ['case','dtype','gx','gv','error']} for v in failures])),flush=True)
sys.exit(bool(failures))
