"""Join exact-source terminal evidence; does not adopt or publish anything."""
from pathlib import Path
import hashlib
import json

r = Path(__file__).resolve().parent
p = r / 'production-release'
read = lambda q: json.loads(q.read_text())
sha = lambda q: hashlib.sha256(q.read_bytes()).hexdigest()
freeze = read(p / 'source-freeze.json')
source, tests = freeze['source_hashes'], freeze['test_hashes']
assert len(source) == 61 and len(tests) == 72
for name, digest in source.items():
    assert sha(p / 'snapshot/packages/stridetorch/src/stridetorch' / name) == digest
for name, digest in tests.items():
    assert sha(p / 'snapshot/packages/stridetorch/tests' / name) == digest
sdk = read(p / 'qualification.json')
assert sdk['status'] == 'final_version_cpu_native_wasm_sdk_passed'
assert sdk['source_hashes'] == source and sdk['test_hashes'] == tests
assert sdk['cpu_cases'] == 8363 and sdk['wasm_cases_each'] == 8350 and sdk['wasm_suites'] == 71
for row in read(p / 'receipts.json'):
    assert row['exit_code'] == 0 and sha(p / (row['label'] + '.log')) == row['log_sha256']
package = read(p / 'package-proof/package-identity.json')
assert package['status'] == 'success' and package['source_hashes'] == source
assert package['standalone_installed_tests'] == 8363 and package['native_torch'] is False
assert all(row['status'] == 'success' for row in package['receipts'])
for name, digest in package['artifacts'].items():
    assert sha(p / 'package-proof' / name) == digest
plan = read(p / 'native-wasm-proof/plan.json')
assert plan['source'] == source
assert [v['torch'] for v in plan['native_reference_profiles']] == ['2.14.1', '2.6.0']
for name, digest in plan['fixtures'].items():
    assert sha(p / 'native-wasm-proof/fixtures' / name) == digest
for name in ['node-result.json', 'chrome/result.json']:
    value = read(p / 'native-wasm-proof' / name)
    assert value['status'] == 'success' and value['source_hashes'] == source and not value['failures']
    assert value['cases'] == 720 and value['direct_native_cases'] == 676
    assert len(value['independent_precision_controls']) == 4 and len(value['polynomial_extension_controls']) == 40
    assert value['fixture_hashes'] == plan['fixtures']
    assert value['native_reference_profiles'] == plan['native_reference_profiles']
for row in read(p / 'native-wasm-proof/receipts.json'):
    assert row['exit_code'] == 0 and sha(p / 'native-wasm-proof' / (row['label'] + '.log')) == row['log_sha256']
evidence = ['qualification.json', 'package-proof/package-identity.json',
            'native-wasm-proof/node-result.json', 'native-wasm-proof/chrome/result.json']
result = dict(status='selected_core_runtime_and_minimum_packages_qualified', version='0.71.0',
              source_hashes=source, test_hashes=tests, cpu_sdk_cases=8363, wasm_sdk_cases_each=8350,
              wasm_suites=71, installed_minimum_cases=8363, numerical_cases_each=720,
              direct_native_cases=676, independent_fp32_controls=4, polynomial_extensions=40,
              native_reference_profiles=plan['native_reference_profiles'],
              production_contract_decision_sha256=sha(r / 'production-contract-decision.json'),
              evidence_sha256={name: sha(p / name) for name in evidence},
              main_adopted=False, ci_triggered=False, deployed=False,
              scope='Exact production-contract-corrected0.71 source. Runtime/numerical/installed-package '
                    'qualification only; new-source performance/allocation review and all11 current-application '
                    'integration gates are required before main adoption. Earlier source evidence remains separate.')
(p / 'core-and-package-proof.json').write_text(json.dumps(result, indent=2) + '\n')
print('Exact production source core/native-WASM/minimum-package evidence joined', flush=True)
