import {withFixtureServer} from '../../../../torch-iteration-70/fixture-server.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
await withFixtureServer(async origin=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 try{
  const page=await browser.newPage();await page.goto(origin+'/torch-iteration-71/portable-release/native-wasm-proof/chrome/');
  const result=await page.evaluate(()=>new Promise((resolve,reject)=>{
   const worker=new Worker('./worker.mjs',{type:'module'});
   const timer=setTimeout(()=>{worker.terminate();reject(Error('Native fixture worker exceeded180seconds'));},180000);
   worker.onmessage=({data})=>{clearTimeout(timer);worker.terminate();resolve(data);};
   worker.onerror=event=>{clearTimeout(timer);worker.terminate();reject(Error(event.message));};worker.postMessage({});
  }));
  result.browser=browser.version();
  result.harness=Object.fromEntries(['run.mjs','worker.mjs','../plan.json','../replay.py'].map(name=>[name,createHash('sha256').update(fs.readFileSync(new URL(name,import.meta.url))).digest('hex')]));
  fs.writeFileSync(new URL('./result.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
  assert(!result.error,JSON.stringify(result));assert.equal(result.status,'success');assert.equal(result.cases,688);
  assert.equal(result.version,'0.71.0');assert.equal(result.pyodide,'0.29.4');assert.equal(result.numpy,'2.2.5');
  console.log(JSON.stringify({status:result.status,cases:result.cases,browser:result.browser,max_abs_difference:result.max_finite_abs_difference}));
 }finally{await browser.close();}
});
