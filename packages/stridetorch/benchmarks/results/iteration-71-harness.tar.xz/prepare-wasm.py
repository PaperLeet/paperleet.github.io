"""Freeze the candidate SDK for real Node and Chrome Pyodide qualification."""
from pathlib import Path
import hashlib,json,shutil

r=Path(__file__).resolve().parent
p=r/'wasm-proof';c=p/'chrome-contracts';c.mkdir(parents=True)
package=r/'candidate/packages/stridetorch'
freeze=json.loads((r/'prototype-source-freeze.json').read_text())
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
for directory,manifest,source in [('source',freeze['source_hashes'],package/'src/stridetorch'),
    ('tests',{k:v for k,v in freeze['test_hashes'].items() if k!='test_standalone.py'},package/'tests')]:
    target=c/directory;target.mkdir()
    for name,digest in manifest.items():
        assert sha(source/name)==digest
        shutil.copy2(source/name,target/name)
plan=dict(source=freeze['source_hashes'],tests={k:v for k,v in freeze['test_hashes'].items() if k!='test_standalone.py'},
    version='0.70.0',prototype_iteration=71,expected=8262,
    scope='Isolated HVP prototype, full SDK only. Native boundary/model fixtures and release packaging are qualified separately.')
(c/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(c/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>HVP prototype qualification</title>')
(p/'sdk.py').write_text('''import sys,json,pathlib,hashlib
sys.path.insert(0,'/runtime')
plan=json.loads(plan_json)
actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path('/runtime/stridetorch').iterdir() if p.is_file()}
assert actual==plan['source']
for name,expected in plan['tests'].items():assert hashlib.sha256(pathlib.Path('/runtime',name).read_bytes()).hexdigest()==expected
import pytest,stridetorch,numpy
assert stridetorch.__version__==plan['version']
class Record:
    passed=0
    failures=[]
    def pytest_runtest_logreport(self,report):
        if report.when=='call' and report.passed:self.passed+=1
        if report.failed:self.failures.append(dict(test=report.nodeid,phase=report.when,error=str(report.longrepr)))
record=Record()
code=pytest.main(['/runtime/'+name for name in plan['tests']]+['-q','--noconftest','-p','no:cacheprovider','--import-mode=importlib'],plugins=[record])
json.dumps(dict(status='success' if int(code)==0 and record.passed==plan['expected'] else 'failed',exit_code=int(code),
    library=stridetorch.__version__,prototype_iteration=plan['prototype_iteration'],numpy=numpy.__version__,python=sys.version.split()[0],
    passed=record.passed,failures=record.failures,source_hashes=actual,test_hashes=plan['tests'],suites=len(plan['tests'])))
''')
print('Prepared frozen prototype WASM SDK:',len(plan['source']),'resources',len(plan['tests']),'suites',plan['expected'],'cases')
