from pathlib import Path
import base64,concurrent.futures,gzip,hashlib,json,urllib.request

root=Path(__file__).parent;expected=root.parent/'integration-proof/live-expected'
commit=json.loads((root/'publication.json').read_text())['commit'];base='https://paperleet.com/'
hashes=json.loads((root.parent/'integration-proof/live-expected-sha256.json').read_text())
def local_hashes():return {name:hashlib.sha256((expected/name).read_bytes()).hexdigest() for name in hashes}
assert local_hashes()==hashes
def fetch(relative):
    request=urllib.request.Request(base+relative+'?torch029='+commit,headers={'Cache-Control':'no-cache'})
    return urllib.request.urlopen(request,timeout=40).read()
catalog=json.loads((expected/'index.json').read_text())
index=json.loads(fetch('data/index-v3.json'))
starters=json.loads(gzip.decompress(base64.b64decode(index['starters']['data'])))
remote={entry['id']:entry for entry in index['problems']}
assert set(starters)==set(remote)=={entry['id'] for entry in catalog['problems']}
for entry in catalog['problems']:
    assert starters[entry['id']]==entry['starter'],entry['id']
    assert remote[entry['id']]['browser_judge']==entry['browser_judge'],entry['id']
    assert remote[entry['id']]['detail_url']==entry['detail_url'],entry['id']
def verify(entry):
    files={};runtime=None
    for name in [entry['detail_url'],entry['browser_judge']['bundle_url']]:
        raw=fetch('data/'+name);assert raw==(expected/name).read_bytes(),name
        files[name]=hashlib.sha256(raw).hexdigest()
        if name.startswith('browser-judge/'):runtime=json.loads(raw)['runtime_bundle_url']
    return files,runtime
verified={};runtimes=set()
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
    for files,runtime in pool.map(verify,catalog['problems']):verified.update(files);runtimes.add(runtime)
runtime_reports=[]
for name in sorted(runtimes):
    raw=fetch('data/'+name);assert raw==(expected/name).read_bytes(),name
    payload=json.loads(raw);verified[name]=hashlib.sha256(raw).hexdigest()
    assert "__version__ = '0.29.0'" in payload['files']['stridetorch/__init__.py']
    for resource in ('LICENSE','NOTICE'):
        assert payload['files']['stridetorch/'+resource]==(root.parent/'proof-refined/chrome-contracts/source'/resource).read_text()
    runtime_reports.append(dict(path=name,bytes=len(raw),sha256=verified[name],package_python_modules=sum(path.startswith('stridetorch/') and path.endswith('.py') for path in payload['files'])))
assert len(verified)==158 and local_hashes()==hashes
report=dict(status='success',commit=commit,url=base,modules=len(remote),starters_equal=True,manifests_equal=True,module_details_equal=True,
            immutable_assets_equal=len(verified),runtimes=runtime_reports,license='Apache-2.0 and NOTICE verified in both profiles',verified_sha256=verified,
            index_comparison='Compressed starters decoded before comparison; runtime and module/manifest payloads compared byte-for-byte.')
(root/'live-assets.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:value for key,value in report.items() if key!='verified_sha256'},indent=2))
