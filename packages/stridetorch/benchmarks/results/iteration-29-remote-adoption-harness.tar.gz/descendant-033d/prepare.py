from pathlib import Path
import hashlib,json,subprocess,shutil
r=Path(__file__).parent;root=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');publication=json.loads((root/'publication.json').read_text());source=publication['commit'];desc='033dc1bc47edadae2df85124e4814e022e471d1e'
subprocess.run(['git','merge-base','--is-ancestor',source,desc],cwd=repo,check=True)
files=subprocess.check_output(['git','diff','--name-only',source,desc],cwd=repo,text=True).splitlines();assert len(files)==7 and all(name.startswith(('web/','docs/validation/')) for name in files)
for name,h in publication['source_hashes'].items():assert hashlib.sha256(subprocess.check_output(['git','show',desc+':packages/stridetorch/src/stridetorch/'+name],cwd=repo)).hexdigest()==h
for name,h in publication['export_sha256'].items():assert hashlib.sha256(subprocess.check_output(['git','show',desc+':web/public/data/'+name],cwd=repo)).hexdigest()==h
(r/'equivalence.json').write_text(json.dumps(dict(status='success',source_commit=source,descendant=desc,changed_files=files,source_resources_identical=45,exports_identical=161,scope='Only UI/test/styles/docs;all45 library/resources and161 frozen exports identical'),indent=2)+'\n')
publication.update(commit=desc,quality_id=38929257323,quality_url='https://github.com/PaperLeet/paperleet.github.io/actions/runs/38929257323',source_commit=source);(r/'publication.json').write_text(json.dumps(publication,indent=2)+'\n');shutil.copy2(root/'watch-remote.py',r/'watch-remote.py')
s=(root/'integration-proof/verify-live.py').read_text().replace("expected=root/'live-expected'", "expected=root.parent/'integration-proof/live-expected'").replace("(root/'live-expected-sha256.json')", "(root.parent/'integration-proof/live-expected-sha256.json')").replace("(root.parent/'publication.json')", "(root/'publication.json')");(r/'verify-live.py').write_text(s)
print('PASS45 library/resource and161 export hashes identical')
