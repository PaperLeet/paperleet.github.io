from pathlib import Path
import hashlib,json,re,subprocess,tarfile
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
def read(name):return json.loads((r/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def blob(commit,path):return subprocess.check_output(['git','show',commit+':'+path],cwd=repo)
publication=read('publication.json');commit=publication['commit'];source=read('remote-observer-terminal.json');first=read('descendant-050c/remote-observer-terminal.json');actual=read('descendant-033d/remote-observer-terminal.json');desc=actual['commit']
assert source['status']=='superseded_after_quality' and first['status']=='pages_not_published' and actual['status']=='success'
assert source['runs']['quality']['id']==38926381186 and first['runs']['quality']['id']==38927408279 and actual['runs']['quality']['id']==38929257323 and actual['runs']['pages']['id']==38930642945
assert first['runs']['pages']['id']==38929018902
assert any(s['conclusion']=='skipped' and 'deploy-pages@' in s['name'] for j in first['runs']['pages']['jobs'] for s in j['steps'])
for event in (source,first,actual):
 quality=event['runs']['quality'];assert quality['conclusion']=='success' and quality['head_sha']==event['commit']
 for name in ('native','infrastructure','browser-wasm','pilot'):
  jobs=[j for j in quality['jobs'] if j['name']==name];assert len(jobs)==1 and jobs[0]['status']=='completed' and jobs[0]['conclusion']=='success'
pages=actual['runs']['pages'];assert pages['head_sha']==desc and pages['conclusion']=='success'
deploy=[j for j in pages['jobs'] if j['name']=='deploy'];assert len(deploy)==1 and deploy[0]['conclusion']=='success' and all(s['conclusion']=='success' for s in deploy[0]['steps'])
assert len(publication['source_hashes'])==45 and len(publication['export_sha256'])==161
for head in (commit,first['commit'],desc):
 subprocess.run(['git','merge-base','--is-ancestor',commit,head],cwd=repo,check=True)
 for name,h in publication['source_hashes'].items():assert hashlib.sha256(blob(head,'packages/stridetorch/src/stridetorch/'+name)).hexdigest()==h
 for name,h in publication['export_sha256'].items():assert sha(r/'integration-proof/live-expected'/name)==h and hashlib.sha256(blob(head,'web/public/data/'+name)).hexdigest()==h
local_n=read('native-ci.json');local_w=read('integration-proof/full-wasm-result.json');reference={c['id']:c for c in local_w['results']};frozen=read('integration-proof/wasm-harness-identity.json');contexts={}
for folder,event in (('',source),('descendant-050c',first),('descendant-033d',actual)):
 prefix=folder+'/' if folder else '';n=read(prefix+'remote-native/ci.json');w=read(prefix+'remote-wasm/browser-wasm.json')
 assert n['passed'] and not n['issues'] and n['problems']==78 and n['tests_executed']==10218 and n['repeats']==3 and n['duration_s']<=600
 assert n['mutation']==local_n['mutation'] and sum(map(len,n['mutation'].values()))==342
 assert w['passed'] and w['scope']=='catalog' and w['modules']==w['catalog_modules']==78 and not w['browser_budget_exceeded'] and len(w['results'])==78
 for case in w['results']:
  expected=reference[case['id']]
  for key in ('tests','mutants','pyodide','numpy','backend','packages','bundle_url','runtime_bundle_url','source_sha256','budgets'):assert case[key]==expected[key],(folder,case['id'],key)
  assert case['passed'] and not case['browser_budget_exceeded'];b=case['budgets'];assert case['calibration_ms']<=b['calibration'] and case['learner_ms']<=b['run'] and case['preparation_ms']+case['calibration_ms']+case['learner_ms']<=b['total']
 contracts=next(c['independent_contracts'] for c in w['results'] if 'independent_contracts' in c);assert contracts['passed']==904 and len(contracts['suites'])==29
 assert {s['suite']:s['source_sha256'] for s in contracts['suites']}==frozen['test_hashes']
 contexts[event['commit']]=dict(observer=event,native=n,wasm={k:v for k,v in w.items() if k!='results'},wasm_mutants=sum(c['mutants'] for c in w['results']),independent_contracts=contracts)
m=re.search(r'29853 passed, 1 skipped, 37 warnings in ([\d.]+)s',(r/'remote-infrastructure.log').read_text());assert m
live=read('descendant-033d/live-assets.json');assert live['status']=='success' and live['commit']==desc and live['modules']==78 and live['immutable_assets_equal']==158 and all(live[k] for k in ('starters_equal','manifests_equal','module_details_equal'))
files=['close-remote.py','publication.json','remote-observer-terminal.json','watch-remote.py','remote-infrastructure.log','remote-native/ci.json','remote-wasm/browser-wasm.json','integration-proof/live-expected-sha256.json','integration-proof/release-snapshot.json','integration-proof/wasm-harness-identity.json']
for d in ('descendant-050c','descendant-033d'):
 files += [d+'/'+name for name in ('publication.json','remote-observer-terminal.json','watch-remote.py','prepare.py','equivalence.json','remote-native/ci.json','remote-wasm/browser-wasm.json')]
files += ['descendant-033d/'+name for name in ('verify-live.py','live-assets.json','live.log')]
archive=out/'iteration-29-remote-adoption-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name in files:tar.add(r/name,arcname=name,recursive=False)
report=dict(status='actual_equivalent_descendant_quality_pages_and_live_verified',version='0.29.0',source_commit=commit,deployed_commit=desc,source_base_passed=29853,source_optional_skips=1,source_infrastructure_s=float(m[1]),source_hashes=publication['source_hashes'],export_files=161,contexts=contexts,equivalence=[read(d+'/equivalence.json') for d in ('descendant-050c','descendant-033d')],live=live,receipts=dict(source_observer=dict(session=36150,exit_code=3,classification='superseded_after_quality'),first_observer=dict(session=99885,exit_code=3,classification='actual_deploy_skipped'),actual_observer=dict(session=32092,exit_code=0),live=dict(session=24243,exit_code=0),actual_native_download=dict(session=57749,exit_code=0),actual_wasm_download=dict(session=2024,exit_code=0)),archive=dict(file=archive.name,files=len(files),bytes=archive.stat().st_size,sha256=sha(archive)),scope='Frozen0.29 runtime45 source/resources and161 exported bytes identical at all three refs;UI/test/style/docs descendants only. First overall-success Pages skipped deploy action,so only033d proves publication. Runner timings are budget gates,no comparative speedup claim.')
(out/'iteration-29-remote-adoption.json').write_text(json.dumps(report,indent=2)+'\n');(r/'remote-adoption.json').write_text(json.dumps(report,indent=2)+'\n')
state=read('state.json');state.update(phase='0.29 source Quality plus byte-identical033d actual Pages/live fully verified',remote_adoption={k:report[k] for k in ('status','source_commit','deployed_commit','source_base_passed','source_optional_skips','source_infrastructure_s','archive')});(r/'state.json').write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],source_infrastructure_s=float(m[1]),deployed_native_s=contexts[desc]['native']['duration_s'],deployed_wasm_ms=contexts[desc]['wasm']['elapsed_ms'],archive=report['archive']),indent=2))
