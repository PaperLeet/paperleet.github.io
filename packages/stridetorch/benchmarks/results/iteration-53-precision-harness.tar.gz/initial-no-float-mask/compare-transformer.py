from pathlib import Path
import json,numpy as np

r=Path(__file__).resolve().parent
n=json.loads((r/'native-transformer.json').read_text());a=json.loads((r/'adapter-transformer.json').read_text())
assert n['script_sha256']==a['script_sha256']
differences=[]
for i,(nr,ar) in enumerate(zip(n['rows'],a['rows'])):
    if nr!=ar:differences.append(dict(row=i,name=nr.get('name',nr.get('kind')),keys=[key for key in nr if nr.get(key)!=ar.get(key)]))
if differences:
    print(json.dumps(dict(schema_differences=differences[:10])))
    (r/'transformer-schema-differences.json').write_text(json.dumps(differences,indent=2)+'\n')
    raise AssertionError('Case metadata, state shapes, None gradients or initialization versions differ')
want=np.load(r/'native-transformer.npz');got=np.load(r/'adapter-transformer.npz')
assert want.files==got.files
errors=[];maximum={}
for name in want.files:
    x,y=got[name],want[name]
    options=dict(rtol=5e-5,atol=8e-6) if x.dtype==np.float32 else dict(rtol=3e-10,atol=3e-11)
    try:np.testing.assert_allclose(x,y,equal_nan=False,**options)
    except AssertionError:
        errors.append(dict(name=name,max_absolute_error=float(np.max(abs(x-y),initial=0))))
    key=('initialization' if name.startswith('init') else name.split('.')[1].rstrip('0123456789'))+'-'+str(x.dtype)
    maximum[key]=max(maximum.get(key,0),float(np.max(abs(x-y),initial=0)))
result=dict(status='success' if not errors else 'failed',cases=len(n['rows']),arrays=len(want.files),
    backend_scope='Native Torch 2.14.1 dense math; MHA fastpath disabled; SDPA MATH; nested optimization disabled where exposed',
    max_absolute_error=maximum,failures=errors[:20],failure_count=len(errors))
(r/'transformer-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result));assert not errors
