"""Pinned native math vs isolated adapter Transformer fixtures and mixed AD."""
from pathlib import Path
import argparse,contextlib,hashlib,itertools,json,sys,warnings
import numpy as np

p=argparse.ArgumentParser();p.add_argument('backend',choices=['native','adapter']);a=p.parse_args()
if a.backend=='native':
    import torch
    from torch.nn.attention import sdpa_kernel,SDPBackend
    torch.set_num_threads(1);torch.backends.mha.set_fastpath_enabled(False)
    context=lambda:sdpa_kernel(SDPBackend.MATH)
    version=torch.__version__
else:
    sys.path.insert(0,'/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src')
    from stridetorch import torch,__version__
    context=contextlib.nullcontext;version=__version__
r=Path(__file__).resolve().parent;arrays={};rows=[]
def put(name,value):
    if value is None:return None
    data=value.detach().numpy().copy();arrays[name]=data
    return dict(key=name,shape=list(data.shape),dtype=str(data.dtype))
def create(kind,dt,layout,pre,activation,bias=True,ff=7):
    opts=dict(dim_feedforward=ff,dropout=0.,activation=activation,norm_first=pre,batch_first=layout=='batch',bias=bias,dtype=dt)
    if kind=='encoder_layer':return torch.nn.TransformerEncoderLayer(4,2,**opts)
    if kind=='decoder_layer':return torch.nn.TransformerDecoderLayer(4,2,**opts)
    if kind=='encoder':return torch.nn.TransformerEncoder(torch.nn.TransformerEncoderLayer(4,2,**opts),2,torch.nn.LayerNorm(4,bias=bias,dtype=dt),enable_nested_tensor=False)
    if kind=='decoder':return torch.nn.TransformerDecoder(torch.nn.TransformerDecoderLayer(4,2,**opts),2,torch.nn.LayerNorm(4,bias=bias,dtype=dt))
    return torch.nn.Transformer(4,2,2,2,**opts)

cases=itertools.product(['float32','float64'],['sequence','batch','unbatched'],[False,True],['relu','gelu'],['none','boolean','causal'],['encoder_layer','decoder_layer','encoder','decoder','full'])
for index,(dtype,layout,pre,activation,mask_kind,kind) in enumerate(cases):
    rng=np.random.default_rng(530000+index);dt=getattr(torch,dtype)
    with warnings.catch_warnings():
        warnings.simplefilter('ignore');module=create(kind,dt,layout,pre,activation,bias=index%7!=0)
    with torch.no_grad():
        for name,parameter in module.named_parameters():
            values=rng.normal(1 if 'norm' in name and name.endswith('weight') else 0,.2,size=parameter.shape).astype(dtype)
            parameter.copy_(torch.tensor(values))
    def shape(length):return (length,4) if layout=='unbatched' else (2,length,4) if layout=='batch' else (length,2,4)
    encoder=kind in ['encoder_layer','encoder']
    inputs=[torch.tensor(np.asfortranarray(rng.normal(0,.5,size=shape(4 if encoder else 3)).astype(dtype)),requires_grad=True)]
    if not encoder:inputs.append(torch.tensor(np.asfortranarray(rng.normal(0,.5,size=shape(4)).astype(dtype)),requires_grad=True))
    batch=1 if layout=='unbatched' else 2;length=4 if encoder else 3
    mask=padding=memory_mask=memory_padding=None
    if mask_kind=='boolean':
        data=rng.random((length,length))<.2;data[:,0]=False;mask=torch.tensor(data)
        data=rng.random((batch,length))<.2;data[:,0]=False;padding=torch.tensor(data[0] if layout=='unbatched' else data)
        if not encoder:
            data=rng.random((length,4))<.2;data[:,0]=False;memory_mask=torch.tensor(data)
            data=rng.random((batch,4))<.2;data[:,0]=False;memory_padding=torch.tensor(data[0] if layout=='unbatched' else data)
    elif mask_kind=='causal':mask=torch.nn.Transformer.generate_square_subsequent_mask(length,dtype=dt)
    def call(*x):
        if kind=='encoder_layer':return module(x[0],src_mask=mask,src_key_padding_mask=padding,is_causal=mask_kind=='causal')
        if kind=='encoder':return module(x[0],mask=mask,src_key_padding_mask=padding)
        if kind=='full':return module(x[1],x[0],tgt_mask=mask,tgt_key_padding_mask=padding,memory_mask=memory_mask,memory_key_padding_mask=memory_padding)
        return module(*x,tgt_mask=mask,tgt_key_padding_mask=padding,memory_mask=memory_mask,memory_key_padding_mask=memory_padding,**({'tgt_is_causal':True} if mask_kind=='causal' and kind=='decoder_layer' else {}))
    row=dict(index=index,kind=kind,dtype=dtype,layout=layout,pre_norm=pre,activation=activation,mask=mask_kind)
    prefix=f'case{index}'
    try:
        with context():
            output=call(*inputs);seed=torch.tensor(rng.normal(size=output.shape).astype(dtype))
            active=inputs+list(module.parameters())
            gradients=torch.autograd.grad((output*seed).sum(),active,allow_unused=True)
            directions=tuple(torch.tensor(rng.normal(size=x.shape).astype(dtype),requires_grad=True) for x in inputs)
            primal,tangent=torch.func.jvp(call,tuple(inputs),directions)
            mixed=torch.autograd.grad((primal*seed+tangent*seed).sum(),active+list(directions),allow_unused=True)
        row.update(status='success',output=put(prefix+'.output',output),gradients=[put(prefix+f'.g{i}',g) for i,g in enumerate(gradients)],
            primal=put(prefix+'.primal',primal),tangent=put(prefix+'.tangent',tangent),mixed=[put(prefix+f'.m{i}',g) for i,g in enumerate(mixed)])
    except Exception as error:row.update(status=type(error).__name__,error=str(error)[:500])
    rows.append(row)

for dtype,layout,pre,bias,kind,activation in itertools.product(['float32','float64'],['sequence','batch'],[False,True],[False,True],['encoder_layer','decoder_layer','encoder','decoder','full'],['relu','gelu']):
    torch.manual_seed(5311)
    with warnings.catch_warnings():
        warnings.simplefilter('ignore');module=create(kind,getattr(torch,dtype),layout,pre,activation,bias=bias)
    name=f'init-{dtype}-{layout}-{pre}-{bias}-{kind}-{activation}'
    rows.append(dict(name=name,status='success',versions={n:p._version for n,p in module.named_parameters()},
        state={n:put(name+'.'+n,t) for n,t in module.state_dict().items()}))

np.savez_compressed(r/(a.backend+'-transformer.npz'),**arrays)
result=dict(backend=a.backend,version=version,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows)
(r/(a.backend+'-transformer.json')).write_text(json.dumps(result,indent=2)+'\n')
errors=[row for row in rows if row['status']!='success']
print(json.dumps(dict(backend=a.backend,cases=len(rows),arrays=len(arrays),errors=len(errors),examples=errors[:4])))
if errors:sys.exit(1)
