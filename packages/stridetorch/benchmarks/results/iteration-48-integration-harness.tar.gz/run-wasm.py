from pathlib import Path
import json,os,shutil,subprocess,time
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');n=json.loads((r/'native-ci.json').read_text());front=json.loads((r/'frontend-receipts.json').read_text());setup=json.loads((r/'setup-receipts.json').read_text())
assert n['passed'] and n['problems']==78 and n['tests_executed']==10218 and n['duration_s']<=600 and n['repeats']==3
assert len(front)==5 and len(setup)==4 and all(x['exit_code']==0 for x in front+setup)
args=['/opt/homebrew/bin/node','web/scripts/check-browser-wasm.mjs','--all'];start=time.monotonic()
with (r/'full-wasm.log').open('w') as log:p=subprocess.run(args,cwd=repo,env=dict(os.environ,PAPERLEET_WASM_CONCURRENCY='2'),stdout=log,stderr=subprocess.STDOUT)
(r/'wasm-receipt.json').write_text(json.dumps(dict(args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-start,concurrency=2),indent=2)+'\n');p.check_returncode();shutil.copy2(repo/'reports/browser-wasm.json',r/'full-wasm-result.json');print('FULL EXPORTED WASM TERMINAL0',flush=True)
