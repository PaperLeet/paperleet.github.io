from pathlib import Path
import json,subprocess,time
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');bin=Path('/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-21/stride-dev-env/bin');receipts=[]
for command,name in [([str(bin/'paperleet'),'export'],'export'),([str(bin/'python'),str(r/'verify-export.py')],'export-identity'),([str(bin/'paperleet'),'vizdata','all'],'vizdata'),([str(bin/'python'),str(r/'verify-export.py')],'post-vizdata-identity')]:
 start=time.monotonic()
 with (r/(name+'.log')).open('w') as log:p=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(command=command,log=name+'.log',exit_code=p.returncode,elapsed_s=time.monotonic()-start));(r/'export-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode();print(name,'terminal0',flush=True)
