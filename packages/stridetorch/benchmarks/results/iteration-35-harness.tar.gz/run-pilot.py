from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;out=r/'performance-first';out.mkdir();receipts=[]
for lane in ('previous','composition'):
 sources=dict(baseline=str(r/'baseline/stridetorch' if lane=='previous' else r.parent/'torch-iteration-33/main-baseline/stridetorch'),candidate=str(r/'candidate-first'))
 for runtime in ('cpu','wasm'):
  label=lane+'-'+runtime;env=dict(os.environ,BENCH_SOURCES=json.dumps(sources),BENCH_DTYPE='float64',BENCH_LANE=lane,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');args=[str(r.parent/'torch-iteration-21/stride-dev-env/bin/python'),str(r/'bench-library.py')] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(r/'bench-library-wasm.mjs')];start=time.monotonic()
  with (out/(label+'.json')).open('w') as output,(out/(label+'.stderr.log')).open('w') as error:p=subprocess.run(args,cwd=r,env=env,stdout=output,stderr=error)
  receipts.append(dict(label=label,exit_code=p.returncode,elapsed_s=time.monotonic()-start));(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode();j=json.loads((out/(label+'.json')).read_text());print(label,{k:round(v['median_time_reduction_percent'],1) for k,v in j['results'].items() if 'jvp' in k},flush=True)
