from pathlib import Path
import json,os,subprocess,time,statistics,gzip
r=Path(__file__).resolve().parent;out=r/'performance-final';out.mkdir(exist_ok=True);py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';receipts={};requested=dict(OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
for lane in ('previous','composition'):
 paths=dict(baseline=str((r/'baseline/stridetorch' if lane=='previous' else r.parent/'torch-iteration-33/main-baseline/stridetorch')),candidate=str(r/'proof/source'))
 for repeat in (1,2):
  for runtime in (('cpu','wasm') if repeat==1 else ('wasm','cpu')):
   for dtype in ('float32','float64'):
    label=f'{lane}-{runtime}-{dtype}-{repeat}';env=dict(os.environ,**requested,BENCH_SOURCES=json.dumps(paths),BENCH_DTYPE=dtype,BENCH_LANE=lane)
    args=[str(py),str(r/'bench-library.py')] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(r/'bench-library-wasm.mjs')];start=time.monotonic()
    with (out/(label+'.json')).open('w') as output,(out/(label+'.stderr.log')).open('w') as error:p=subprocess.run(args,cwd=r,env=env,stdout=output,stderr=error)
    receipts[label]=dict(command=args,exit_code=p.returncode,elapsed_s=time.monotonic()-start,requested_thread_environment=requested);(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode();data=json.loads((out/(label+'.json')).read_text());assert data['source_hashes']['candidate']==json.loads((r/'proof/source-hashes.json').read_text())
    print('TERMINAL',label,0,{k:round(v['median_time_reduction_percent'],1) for k,v in data['results'].items()},flush=True)
summary={}
for lane in ('previous','composition'):
 for runtime in ('cpu','wasm'):
  reports=[json.loads((out/f'{lane}-{runtime}-{dtype}-{repeat}.json').read_text()) for dtype in ('float32','float64') for repeat in (1,2)]
  summary[lane+'/'+runtime]={key:dict(median_reductions_percent=[p['results'][key]['median_time_reduction_percent'] for p in reports],baseline_median_us=[statistics.median(statistics.mean(b['samples_us']['baseline']) for b in p['results'][key]['blocks']) for p in reports],candidate_median_us=[statistics.median(statistics.mean(b['samples_us']['candidate']) for b in p['results'][key]['blocks']) for p in reports]) for key in reports[0]['results']}
footprint={}
for label,path in [('previous_034',r/'baseline/stridetorch'),('candidate_035',r/'proof/source')]:
 raw=b''.join(p.read_bytes() for p in sorted(path.iterdir()) if p.suffix=='.py' or p.name in ('LICENSE','NOTICE'));footprint[label]=dict(raw_bytes=len(raw),local_gzip_estimate_bytes=len(gzip.compress(raw,mtime=0)))
(r/'performance-final-summary.json').write_text(json.dumps(dict(scope='16sequential paired children after local heavy gates;2dtypes and2fresh processes/runtime/lane;previous fused and old composition lanes separated;GC enabled;all numerical/state assertions passed;shared host;effective vendor threads unverified;no cloud CI run or cross-runtime throughput claim.',summary=summary,source_footprint=footprint,receipts=receipts),indent=2)+'\n');print('ALL16 performance children terminal0',flush=True)
