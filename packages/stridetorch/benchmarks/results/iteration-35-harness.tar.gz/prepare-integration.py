from pathlib import Path
import json,shutil,hashlib,subprocess
r=Path(__file__).resolve().parent;i=r/'integration-proof';i.mkdir();repo=Path('/Users/david/Developer/PaperLeet-torch-release');old=r.parent/'torch-iteration-34/integration-proof';upstream='e21b136c2431d2aeeea52b0d1b1124a09c413f6a'
for name in ('verify-export.py','run-export.py','freeze.py','verify-private.py','run-frontend.py','run-setup.py','run-native.py','run-wasm.py'):
 s=(old/name).read_text().replace('0.34.0','0.35.0').replace('proof-final','proof').replace('==8333','==8491').replace('1439','1495').replace('iteration34 integration','iteration35 integration');s=s.replace("'torch-iteration-33/integration-proof/owned-dependencies.json'","'torch-iteration-34/integration-proof/owned-dependencies.json'")
 (i/name).write_text(s)
source=json.loads((r/'proof/source-hashes.json').read_text());assert len(source)==47 and all(hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/k).read_bytes()).hexdigest()==v for k,v in source.items())
(i/'context.json').write_text(json.dumps(dict(upstream=upstream,source_hashes=source,core_report='iteration-35.json',release_policy='No automatic CI for ordinary pushes or PRs. No agent-created tags,Actions dispatch or online releases;user will tag later.',scope='All prior8491 main immutable assets retained;fresh exported runtime/completeWASM and frontend/builds required. Fresh native original catalog runs in isolation after other heavy gates.'),indent=2)+'\n');(i/'dist-paperleet').mkdir()
for p in (r/'proof/private-dist').iterdir():shutil.copy2(p,i/'dist-paperleet'/p.name)
print('Prepared application integration against exact quiet0.33main;8491prior assets')
