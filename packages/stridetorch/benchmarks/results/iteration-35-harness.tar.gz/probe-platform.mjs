import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
const py=await loadPyodide({indexURL:'/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/',stdout:console.error,stderr:console.error});
console.log(py.runPython('import sys,json\njson.dumps(dict(platform=sys.platform,python=sys.version))'));
