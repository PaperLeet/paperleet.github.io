from pathlib import Path
import json,hashlib,shutil
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');old=r.parent/'torch-iteration-34/proof';p=r/'proof';p.mkdir();source=repo/'packages/stridetorch/src/stridetorch'
for dest in (p/'source',p/'chrome-contracts/source'):shutil.copytree(source,dest,ignore=shutil.ignore_patterns('__pycache__'))
shutil.copytree(repo/'packages/stridetorch/tests',p/'chrome-contracts/tests',ignore=shutil.ignore_patterns('__pycache__'))
hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in source.iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')};tests={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (repo/'packages/stridetorch/tests').glob('test_*.py') if f.name!='test_standalone.py'};assert len(hashes)==47 and len(tests)==34
(p/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n');(p/'chrome-contracts/plan.json').write_text(json.dumps(dict(version='0.35.0',expected=1495,source=hashes,tests=tests),indent=2)+'\n')
for name in ('chrome-contracts/run.mjs','chrome-contracts/worker.mjs','chrome-contracts/index.html','wasm-contracts.mjs','check-wheel.py','check-coinstall.py'):
 s=(old/name).read_text().replace('torch-iteration-34/proof','torch-iteration-35/proof').replace('0.34','0.35').replace('stride034','stride035').replace('1439','1495')
 (p/name).write_text(s)
s=(r.parent/'torch-iteration-34/run-gates.py').read_text();(r/'run-gates.py').write_text(s)
s=(r.parent/'torch-iteration-34/run-full.py').read_text();(r/'run-full.py').write_text(s)
print('Frozen0.35:47resources,34suites1495browserchecks,minimal1507')
