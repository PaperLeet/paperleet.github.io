from pathlib import Path
import hashlib,json,os,re,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results';proof=r/'proof';i=r/'integration-proof'
def read(name):return json.loads((r/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
actual={p.name:sha(p) for p in (repo/'packages/stridetorch/src/stridetorch').iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};assert len(actual)==47 and actual==read('proof/source-hashes.json')
plan=read('proof/chrome-contracts/plan.json');tests={p.name:sha(p) for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'};assert plan['source']==actual and plan['expected']==1495 and len(tests)==34 and plan['tests']==tests
gates=read('proof/gate-receipts.json');assert len(gates)==6 and all(x['exit_code']==0 for x in gates.values());full=read('full-root-receipt.json');assert full['exit_code']==0;log=(r/'full-native.log').read_text();m=re.search(r'(\d+) passed, (\d+) skipped, (\d+) warnings in ([\d.]+)s',log);assert m and int(m[1])>=32235 and int(m[2])==1;full.update(passed=int(m[1]),optional_skipped=int(m[2]),warnings=int(m[3]),duration_s=float(m[4]))
node=read('proof/source-wasm.json');chrome=read('proof/chrome-contracts/result.json');wheel=read('proof/wheel-stride035-result.json');coinstall=read('proof/coinstall-result.json');assert node['passed']==chrome['passed']==1495 and node['source_hashes']==chrome['source_hashes']==wheel['source_hashes']==coinstall['source_hashes']==actual and chrome['test_hashes']==tests and chrome['status']==wheel['status']==coinstall['status']=='success' and not wheel['native_torch'];assert '1507 passed' in (proof/'python310-stride035-tests.log').read_text();assert '859 passed' in (r/'focus-final-policy.log').read_text()
performance=read('performance-final-summary.json');imports=read('import-summary.json');assert len(performance['receipts'])==16 and all(x['exit_code']==0 for x in performance['receipts'].values());assert len(imports['receipts'])==16 and all(x['exit_code']==0 for x in imports['receipts'])
for report in (r/'performance-final').glob('*.json'):
 if report.name!='receipts.json':assert json.loads(report.read_text())['source_hashes']['candidate']==actual
native_ci=read('integration-proof/native-ci.json');wasm=read('integration-proof/full-wasm-result.json');setup=read('integration-proof/setup-receipts.json');front=read('integration-proof/frontend-receipts.json');snapshot=read('integration-proof/release-snapshot.json');exports=read('integration-proof/export-identity.json');private=read('integration-proof/distribution-identity.json')
assert native_ci['passed'] and native_ci['problems']==78 and native_ci['tests_executed']==10218 and native_ci['repeats']==3 and native_ci['duration_s']<=600
assert len(native_ci['mutation'])==78 and sum(len(v) for v in native_ci['mutation'].values())==342
assert all(hits for mutants in native_ci['mutation'].values() for hits in mutants.values()) and not native_ci['issues']
assert wasm['passed'] and wasm['catalog_modules']==wasm['modules']==78 and not wasm['browser_budget_exceeded'];assert sum(x['mutants'] for x in wasm['results'])==342 and all(x['passed'] and not x['browser_budget_exceeded'] for x in wasm['results'])
assert len(setup)==4 and len(front)==5 and all(x['exit_code']==0 for x in setup+front);assert snapshot['source_hashes']==actual and exports['published_assets_unchanged']==8491 and exports['all_new_assets_reachable'] and private['status']=='success'
assert exports['active_assets']==exports['new_assets']==158 and len(read('integration-proof/live-expected-sha256.json'))==161
for name,digest in read('integration-proof/live-expected-sha256.json').items():assert sha(repo/'web/public/data'/name)==digest,name
native=r/'native-contracts';native.mkdir(exist_ok=True)
for p in (repo/'tests').glob('test_torch_*'):
 if p.is_file():shutil.copy2(p,native/p.name)
metadata=r/'package-metadata';metadata.mkdir(exist_ok=True)
for name in ('README.md','pyproject.toml','LICENSE','NOTICE'):shutil.copy2(repo/'packages/stridetorch'/name,metadata/name)
def archive(name,root,excluded):
 files=[]
 for folder,dirs,names in os.walk(root):
  dirs[:]=[d for d in dirs if not d.endswith('-env') and d not in excluded and d not in ('__pycache__','.pytest_cache')]
  for name2 in names:
   p=Path(folder)/name2
   if p.is_symlink():continue
   if p.name in ('LICENSE','NOTICE') or p.suffix in ('.py','.mjs','.cjs','.json','.log','.txt','.md','.html','.toml'):files.append(p)
 path=out/name
 with tarfile.open(path,'w:gz') as tar:
  for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
 return dict(file=path.name,files=len(files),bytes=path.stat().st_size,sha256=sha(path))
core_archive=archive('iteration-35-harness.tar.gz',r,{'dist-preflight','private-dist','dist-paperleet','integration-proof','integration-proof-first','main-sync-proof','retired-first-assets'})
core=dict(status='complete_local_core_and_application_gates_passed_main_adoption_pending',version='0.35.0',baseline_main='89382022e6afe55a966ed14c89fa53aaf707ec9f',source_hashes=actual,standalone_test_hashes=tests,native_test_hashes={p.name:sha(p) for p in native.iterdir()},full_cpu=full,focused_passed=859,minimal_passed=1507,minimal_wheel=wheel,node_wasm=node,actual_chrome_worker=chrome,coinstall=coinstall,gate_receipts=gates,pilot_reports={name:read(name+'/receipts.json') for name in ('performance-first','performance-frozen-pilot','performance-dispatch-pilot','performance-policy-pilot')},final_performance=performance,cold_namespace_imports=imports,archive=core_archive,scope='Actual finite triangular factors reuse primal, tangent and adjoint solve intermediates in the full unmasked four-input JVP pullback. General/nonfinite factors retain the prior product fallback; wide/small JVPs retain their previous rule. Runtime/RHS policy avoids additional triangle scans for frozen CPU factors and small Emscripten RHSs. Float32/64 AD, complex inference and documented unsupported boundaries are unchanged. No cross-call numerical cache, native Torch or SciPy runtime.',retained_failures=['First prototype adds a public forwarding layer and new triangle classification for frozen CPU factors;pilot CPU small/frozen/no-reverse JVP regresses4to6percent. Direct validated-primal dispatch removes repeated validation,then measuredruntime/RHS policy avoids unjustifiedCPU/smallWASM scans. All pilots and source snapshots retained.','Final policy is restricted to observedEmscripten runtime for newfrozenfactor classification;existing gradient-factor classification and all fallbackAPIsemantics retained. No newWASI orGPUperformance claim.'],primary_sources=['https://github.com/pytorch/pytorch/blob/v2.14.0/torch/csrc/autograd/FunctionsManual.cpp#L4719','https://docs.pytorch.org/docs/2.14/generated/torch.cholesky_solve.html'],release_policy='No agent tag,dispatch or online publication;ordinary main updates trigger no CI;user will tag later.')
followup=read('cpu-followup-summary.json');assert len(followup['receipts'])==4 and all(x['exit_code']==0 for x in followup['receipts'].values())
for p in (r/'performance-cpu-followup').glob('previous-*.json'):assert json.loads(p.read_text())['source_hashes']['candidate']==actual
core['cpu_variability_followup']=followup
save('iteration-35.json',core)
integration_archive=archive('iteration-35-integration-harness.tar.gz',i,{'dist-paperleet'})
integration=dict(status='complete_local_application_gates_passed_main_adoption_pending',version='0.35.0',upstream=read('integration-proof/context.json')['upstream'],source_hashes=actual,core_report='iteration-35.json',native=native_ci,exported_wasm=wasm,setup_receipts=setup,frontend_receipts=front,release_snapshot=snapshot,export_integrity=exports,distribution_identity=private,runtime_sizes=read('integration-proof/runtime-sizes.json'),wasm_harness=read('integration-proof/wasm-harness-identity.json'),context=read('integration-proof/context.json'),archive=integration_archive,publication='Local results do not assert deployment. No CI,tag or dispatch triggered;user will release later.')
save('iteration-35-integration.json',integration);print(json.dumps(dict(core=core_archive,integration=integration_archive,full_cpu=full,native_duration=native_ci['duration_s'],wasm_ms=wasm['elapsed_ms']),indent=2))
