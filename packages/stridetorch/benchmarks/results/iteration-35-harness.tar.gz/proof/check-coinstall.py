from pathlib import Path
import hashlib,json,os,subprocess,time,zipfile
r=Path(__file__).parent;expected=json.loads((r/'source-hashes.json').read_text());public=next((r/'dist-preflight').glob('*.whl'));private=next((r/'private-dist').glob('*.whl'));uv='/Users/david/.local/bin/uv';env=os.environ.copy();env.pop('PYTHONPATH',None);receipts=[]
for wheel,prefix in [(public,'stridetorch/'),(private,'paperleet/_vendor/torch/')]:
 with zipfile.ZipFile(wheel) as z:
  actual={n.removeprefix(prefix):hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith(prefix)}
  assert actual==expected,(wheel,actual.keys()^expected.keys())
venv=r/'coinstall-env';python=venv/'bin/python'
def run(cmd,label):
 start=time.monotonic()
 with (r/(label+'.log')).open('w') as log:p=subprocess.run([str(x) for x in cmd],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(label=label,command=[str(x) for x in cmd],exit_code=p.returncode,elapsed_s=time.monotonic()-start));(r/'coinstall-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode();print(label,'terminal0',flush=True)
run([uv,'venv','--clear',venv,'--python','/Users/david/.local/share/uv/python/cpython-3.10.19-macos-aarch64-none/bin/python3.10'],'coinstall-venv')
run([uv,'pip','install','--python',python,'--no-deps','numpy==1.26.4',public,private],'coinstall-install')
check="""import importlib,importlib.util,hashlib,json,pathlib
expected=json.loads(pathlib.Path('source-hashes.json').read_text())
for name in NAMES:
 m=importlib.import_module(name);p=pathlib.Path(m.__file__).parent
 actual={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in p.iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')}
 assert actual==expected and m.__version__=='0.35.0'
 t=m.torch;x=t.tensor([1.,float('nan'),3.],requires_grad=True);y=t.nanmean(x);assert y.item()==2.;y.backward();assert x.grad.tolist()==[.5,0.,.5]
assert importlib.util.find_spec('torch') is None
import numpy as np
for name in NAMES:
 t=importlib.import_module(name).torch
 x=t.from_numpy(np.array([[1.,2.,3.],[4.,5.,6.]],order='F')).requires_grad_()
 x.sum().backward();assert x.grad.stride()==x.stride()
 assert x.t().shape==(3,2) and x.mT.stride()==(2,1)
 assert t.movedim(x,0,1).shape==(3,2)
 y=x*2;y.retain_grad();y.sum().backward(retain_graph=True);old=y.grad
 y.sum().backward();assert y.grad is not old;assert old.tolist()==[[1.,1.,1.],[1.,1.,1.]]
for name in NAMES:
 t=importlib.import_module(name).torch
 a=t.tensor([[[3.,0.],[0.,2.]],[[4.,0.],[0.,5.]]],dtype=t.float64,requires_grad=True)
 b=t.tensor([[[1.,2.]],[[3.,4.]]],dtype=t.float64,requires_grad=True)
 x=t.linalg.solve(a,b,left=False)
 np.testing.assert_allclose(x.numpy(),[[[1/3,1.]],[[.75,.8]]])
 x.sum().backward()
 np.testing.assert_allclose(b.grad.numpy(),[[[1/3,.5]],[[.25,.2]]])
 primal,tangent=t.func.jvp(lambda aa,bb:t.linalg.solve(aa,bb,left=False),(a,b),(t.ones_like(a),t.ones_like(b)))
 assert primal.shape==tangent.shape==(2,1,2) and np.isfinite(tangent.numpy()).all()
import io
for name in NAMES:
 m=importlib.import_module(name);t=m.torch
 with m.as_torch() as aliased:
  import torch
  from torch.serialization import save,load
  assert torch is aliased and save is torch.save and load is torch.load
  base=torch.arange(12,dtype=torch.float64);state={'base':base,'view':base[1::2]}
  stream=io.BytesIO();save(state,stream);stream.seek(0);loaded=load(stream,weights_only=True)
  np.testing.assert_array_equal(loaded['view'].numpy(),[1,3,5,7,9,11]);loaded['base'][1]=23.;assert loaded['view'][0].item()==23.
  layer=torch.nn.Linear(2,1).double();opt=torch.optim.AdamW(layer.parameters(),lr=.01);sched=torch.optim.lr_scheduler.StepLR(opt,2)
  x=torch.tensor([[1.,2.]],dtype=torch.float64);layer(x).square().mean().backward();opt.step();sched.step()
  stream=io.BytesIO();save({'model':layer.state_dict(),'optimizer':opt.state_dict(),'scheduler':sched.state_dict()},stream);stream.seek(0);loaded=load(stream)
  target=torch.nn.Linear(2,1).double();newopt=torch.optim.AdamW(target.parameters());newsched=torch.optim.lr_scheduler.StepLR(newopt,2)
  target.load_state_dict(loaded['model']);newsched.load_state_dict(loaded['scheduler']);newopt.load_state_dict(loaded['optimizer'])
  np.testing.assert_array_equal(target(x).numpy(),layer(x).numpy())
  newopt.zero_grad();target(x).square().mean().backward();newopt.step();newsched.step()
for name in NAMES:
 t=importlib.import_module(name).torch
 a=t.tensor([[2.,.2],[.9,3.]],dtype=t.float64,requires_grad=True);b=t.ones(2,2,dtype=t.float64,requires_grad=True)
 x=t.linalg.solve_triangular(a,b,upper=True,left=False,unitriangular=True)
 np.testing.assert_allclose(x.numpy(),[[1.,.8],[1.,.8]]);assert x.stride()==(1,2)
 x.square().mean().backward();assert a.grad[0,0].item()==a.grad[1,1].item()==a.grad[1,0].item()==0.
 a.grad=b.grad=None
 primal,tangent=t.func.jvp(lambda aa,bb:t.linalg.solve_triangular(aa,bb,upper=True,left=False,unitriangular=True),(a,b),(t.ones_like(a),t.ones_like(b)))
 np.testing.assert_allclose(tangent.numpy(),[[1.,-.2],[1.,-.2]])
 tangent.sum().backward();assert np.isfinite(a.grad.numpy()).all() and np.isfinite(b.grad.numpy()).all()
for name in NAMES:
 t=importlib.import_module(name).torch
 a=t.tensor([[4.,1.],[1.,3.]],dtype=t.float64,requires_grad=True)
 factor=t.linalg.cholesky(a);np.testing.assert_allclose(factor.numpy(),[[2.,0.],[.5,np.sqrt(2.75)]])
 factor.square().sum().backward();np.testing.assert_allclose(a.grad.numpy(),np.eye(2),atol=1e-14)
 a.grad=None;direction=t.tensor([[.2,.3],[.7,.4]],dtype=t.float64,requires_grad=True)
 _,tangent=t.func.jvp(lambda v:t.linalg.cholesky(v,upper=True),(a,),(direction,))
 np.testing.assert_allclose(tangent.numpy(),[[.05,.3375],[0.,.048995593493886595]])
 tangent.square().sum().backward();assert np.isfinite(a.grad.numpy()).all() and np.isfinite(direction.grad.numpy()).all()
for name in NAMES:
 t=importlib.import_module(name).torch
 f=t.tensor([[2.,0.],[.4,3.]],dtype=t.float64,requires_grad=True);b=t.ones(2,2,dtype=t.float64,requires_grad=True)
 x=t.cholesky_solve(b,f);np.testing.assert_allclose(x.numpy(),np.linalg.solve(f.numpy()@f.numpy().T,b.numpy()))
 x.square().sum().backward();assert np.isfinite(b.grad.numpy()).all() and np.isfinite(f.grad.numpy()).all()
 f.grad=b.grad=None
 dF=t.ones_like(f)*.13;dB=t.ones_like(b)*.27
 _,tangent=t.func.jvp(lambda bb,ff:bb.cholesky_solve(ff),(b,f),(dB,dF))
 tangent.square().sum().backward();assert np.isfinite(b.grad.numpy()).all() and np.isfinite(f.grad.numpy()).all()
for name in NAMES:
 t=importlib.import_module(name).torch
 f=(t.eye(64,dtype=t.float64)*2).requires_grad_();b=t.full((64,2),.2,dtype=t.float64,requires_grad=True)
 db=t.full_like(b,.03,requires_grad=True);df=t.full_like(f,.01,requires_grad=True)
 x,tangent=t.func.jvp(lambda bb,ff:t.cholesky_solve(bb,ff),(b,f),(db,df))
 np.testing.assert_allclose(x.numpy(),.05);np.testing.assert_allclose(tangent.numpy(),-.0245)
 (x.square().sum()+tangent.square().sum()).backward()
 assert all(a.grad is not None and np.isfinite(a.grad.numpy()).all() for a in (b,f,db,df))
print('PASS isolated ownership,aliases,ZIP resume,triangular,Cholesky and Cholesky solve VJP/JVP/full tangent reverse')
"""
run([python,'-c','NAMES='+repr(['stridetorch','paperleet._vendor.torch'])+'\n'+check],'coinstall-both')
run([uv,'pip','uninstall','--python',python,'paperleet'],'coinstall-uninstall-private')
run([python,'-c',"NAMES=['stridetorch']\n"+check],'coinstall-public-survives')
run([uv,'pip','install','--python',python,'--no-deps',private],'coinstall-reinstall-private')
run([uv,'pip','uninstall','--python',python,'stridetorch'],'coinstall-uninstall-public')
run([python,'-c',"NAMES=['paperleet._vendor.torch']\n"+check+"\nassert importlib.util.find_spec('stridetorch') is None"],'coinstall-private-survives')
(r/'coinstall-result.json').write_text(json.dumps(dict(status='success',source_hashes=expected,wheels={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (public,private)},receipts=receipts,scope='ZIP checkpoint alias/shared-storage/model-optimizer-scheduler resume verified in each namespace. Both no-deps distributions coinstalled in a new NumPy-only Python3.10 environment; both namespaces execute nanmean/VJP,matrix views and batched right-solve VJP/JVP; uninstall each owner without changing the other; native Torch absent. This is not an installed PaperLeet application dependency gate.'),indent=2)+'\n')
