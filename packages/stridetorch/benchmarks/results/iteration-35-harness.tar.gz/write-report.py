from pathlib import Path
import json

r = Path(__file__).resolve().parent
repo = Path('/Users/david/Developer/PaperLeet-torch-release')
out = repo / 'packages/stridetorch/benchmarks/results'
core = json.loads((out / 'iteration-35.json').read_text())
app = json.loads((out / 'iteration-35-integration.json').read_text())
perf = core['final_performance']

def interval(lane, runtime, key):
    values = perf['summary'][lane + '/' + runtime][key]['median_reductions_percent']
    return f'{min(values):.1f} to {max(values):.1f}%'

keys = ['jvp', 'narrow-jvp', 'narrow-jvp-backward', 'quarter-jvp',
        'quarter-jvp-backward', 'batch-jvp-backward', 'fixed-factor-jvp',
        'fixed-factor-jvp-backward', 'no-reverse-jvp', 'no-reverse-tiny-jvp',
        'generic-control', 'cholesky-control', 'unary-control']
available = perf['summary']['previous/cpu']
assert all(k in available for k in keys), sorted(available)
table = '\n'.join(f'| {k} | {interval("previous", "cpu", k)} | {interval("previous", "wasm", k)} |' for k in keys)
imports = core['cold_namespace_imports']['summary']
footprint = perf['source_footprint']
followup = core['cpu_variability_followup']['summary']
def followup_range(key):
    values = followup[key]
    return f'{min(values):.1f} to {max(values):.1f}%'
f = core['full_cpu']
text = f'''# StrideTorch 0.35: reuse Cholesky JVP solve intermediates

Version 0.35 improves the narrow real float32/64 `cholesky_solve` JVP and its
four-input reverse rule. It remains an independent NumPy-only runtime. The
current package name stays `stridetorch` pending the user's choice of a new
browser-oriented name; no rename or public package release is implied.

## Numerical rule and dispatch

Let S(R) denote two triangular solves using F's selected triangle and X = S(B).
For a lower factor, the full native derivative uses H = DF Fᵀ + F DFᵀ and
T = S(DB − H X). Upper factors transpose the corresponding products. The
[native derivative rules](https://github.com/pytorch/pytorch/blob/v2.14.0/torch/csrc/autograd/FunctionsManual.cpp#L4719)
are validated against installed native Torch 2.14.1, including the unused half
of F and DF. This is a compatibility implementation, not native Torch in WASM.

When F is actually finite triangular, the first primal solve already provides
Y = FᵀX (lower) or FX (upper). For the lower case, compute
U = solve(F, DB − DF Y), then T = solve(Fᵀ, U − DFᵀX).
The upper case computes U = solve(Fᵀ, DB − DFᵀY), then
T = solve(F, U − DFX). This replaces two factor-times-solution products with
already available arrays. The adjoint's first solve similarly supplies FᵀQ/FQ,
and the second tangent RHS supplies FᵀT/FT.

These identities optimize values at the triangular factor. The analytical
pullback still has all four inputs X, F, DB and DF and the full unmasked factor
and direction edges. Differentiating only the simplified triangular expression
would lose those edges. No numerical values or seeds are cached across calls.
Conditional direction snapshots, alias mutation guards and selective saved-array
ownership from 0.34 remain in force.

The narrow branch requires n ≥ 64 and RHS width ≤ n/4. General full factors
retain 0.34's cached-product rule. Nonfinite intermediate checks fall back to
the prior product/residual/solve ordering; small/wide cases keep their existing
rule. No API, dtype or gradient domain is removed to obtain speedups.
Complex inference remains supported; complex AD, half factorization, output
buffers and general higher-order reverse retain their documented boundaries.

The first prototype regressed CPU frozen-factor and small JVP flows by about
4–6%. Public validation now dispatches directly to a private validated primal
helper, avoiding recursive validation. Gradient factors already require the
triangle scan for their VJP; new scans for frozen factors are enabled only on
the measured Emscripten runtime, and not for n=64 with RHS width ≤4. CPU frozen
factors retain the prior unclassified rule. WASI and WebGPU receive no new
performance claim. All four pilot source/result sets are retained.

## Local correctness and application validation

- Complete merged Python suite: **{f['passed']:,} passes, 1 optional skip,
  {f['warnings']} warnings, {f['duration_s']:.2f}s**.
- Focused Cholesky, native-reference, mutation, ownership and retained-reverse
  tests: **859 passes**. New cases cover both dispatch boundaries, ignored-half
  nonzero entries, full/triangular directions, batches, strided final axes,
  both triangles and extreme positive/negative scales in float32/64.
- Independent exact scaled adjoints and constructed no-reverse/no-grad systems
  complement native comparisons. Node Pyodide and actual Chrome Worker each
  pass **1,495 checks in 34 suites** on pinned Pyodide 0.29.4 / NumPy 2.2.5.
- Installed independent wheel: **1,507 passes** on Python 3.10.19 / NumPy 1.26.4
  without native Torch. Public/private wheel ownership, all 47 core/license
  resources, aliases, CLI, ZIP training resume and independent uninstall pass.
- Original native catalog: **78 problems, 10,218 executions, 342 mutants,
  3 repeats, {app['native']['duration_s']:.2f}s**, unchanged budgets.
- Actual exported WASM: **78/78 modules, 342 mutants,
  {app['exported_wasm']['elapsed_ms']}ms**, concurrency 2, no deadline exceeded.
- Full frontend check and both typed builds pass. All **8,491** previous
  immutable assets remain byte-identical; **158** new payloads are reachable,
  and all **161** active index/payload files are SHA-256 frozen.

## Paired whole-workflow measurements

Sixteen sequential children cover two dtypes and two fresh processes per
runtime and comparison, after the heavy correctness/native/frontend gates.
Each uses nine ABBA/BAAB paired blocks, warmups, GC enabled, real SGD updates,
and value/dtype/gradient/state checks. The 20 workflows include fixed-factor and
no-reverse cases that exposed the initial regression. Native tests separately
cover full unmasked derivative semantics outside the projected benchmark domain.

| Workflow | CPU time reduction vs 0.34 | WASM time reduction vs 0.34 |
| --- | ---: | ---: |
{table}

Negative values mean slower. Against the separately retained 0.32 public
two-triangular-solve composition, WASM quarter-width forward JVP changes by
**{interval('composition', 'wasm', 'quarter-jvp')}** and its full reverse by
**{interval('composition', 'wasm', 'quarter-jvp-backward')}**. These older-baseline
comparisons remain visible so a gain against 0.34 does not hide inherited costs.
The older-composition frozen-factor full reverse changes by
**{interval('composition', 'wasm', 'fixed-factor-jvp-backward')}** on WASM;
these remaining reverse-workflow gaps are still optimization targets.

The initial CPU set includes a -10.6% small-JVP result and sizable unchanged
control variability, with some absolute latencies moving by nearly a factor of
two between children. Four additional complete paired CPU children run after
the exported WASM gate, with unchanged source and all original data retained.
Their small JVP range is **{followup_range('jvp')}**, tiny backward
**{followup_range('tiny-backward')}**, and unchanged Cholesky control
**{followup_range('cholesky-control')}**. This follow-up assesses the unresolved
small-workflow concern; it does not replace the original table or establish a
uniform CPU gain.

Cold CPU namespace import medians (four fresh alternating processes per set):
NumPy included {imports['0']['previous_034']['median_ms']:.2f} →
{imports['0']['candidate_035']['median_ms']:.2f}ms; preloaded
{imports['1']['previous_034']['median_ms']:.2f} →
{imports['1']['candidate_035']['median_ms']:.2f}ms. Source bytes
{footprint['previous_034']['raw_bytes']} → {footprint['candidate_035']['raw_bytes']};
local gzip estimates {footprint['previous_034']['local_gzip_estimate_bytes']} →
{footprint['candidate_035']['local_gzip_estimate_bytes']}. These shared-host
measurements request thread limits but do not verify vendor thread counts.
They are not statistical guarantees, browser wire sizes or CPU/WASM throughput
comparisons. No WebGPU backend is enabled by this iteration.

## Reproduction and adoption boundary

[`iteration-35.json`](../../packages/stridetorch/benchmarks/results/iteration-35.json)
and [`iteration-35-integration.json`](../../packages/stridetorch/benchmarks/results/iteration-35-integration.json)
record exact source/test hashes, receipts, initial pilots and hashed reproduction
archives. Application checks use upstream `{app['upstream']}` including its
current catalog in the rebuilt private wheel.

Local gates do not establish remote Linux CI or online deployment. The
canonical [explicit-release policy](../releasing.md) remains unchanged. No tag,
workflow dispatch, package publication or CI run is requested by this iteration;
the user will explicitly release later. Main adoption is recorded separately.
'''
(repo / 'docs/validation/torch-runtime-iteration-35.md').write_text(text)
roadmap = repo / 'packages/stridetorch/ROADMAP.md'
content = roadmap.read_text()
marker = '## Next implementation areas'
addition = '''## Version 0.35: reuse narrow Cholesky JVP intermediates

- Actual finite triangular factors reuse primal/tangent/adjoint solve arrays
  while retaining all four full-factor reverse channels and mutation semantics.
  Validated-primal dispatch and measured Emscripten/RHS scan policy address
  prototype regressions for small and frozen-factor workflows.
- Full core 32,235 passes; Node/Chrome 1,495 each; minimum installed wheel 1,507.
  Original native/exported WASM catalogs and full application gates pass.
- [Paired measurements and retained pilots](../../docs/validation/torch-runtime-iteration-35.md)
  include the older 0.32 composition baseline and frozen/no-reverse workflows.
  Main adoption is separate from online publication; no CI/tag/dispatch occurs.

'''
assert marker in content and '## Version 0.35:' not in content
roadmap.write_text(content.replace(marker, addition + marker))
print('Wrote 0.35 validation and roadmap from completed evidence')
