"""Whole Cholesky-solve workflows vs existing composition or initial fused rule."""
import contextlib,gc,hashlib,importlib.util,json,os,statistics,sys,time
from pathlib import Path
import numpy as np
paths=globals().get('bench_sources') or json.loads(os.environ['BENCH_SOURCES']);dtype=globals().get('bench_dtype',os.environ.get('BENCH_DTYPE','float64'));lane=globals().get('bench_lane',os.environ.get('BENCH_LANE','release'));packages={};hashes={}
for label,folder in paths.items():
 root=Path(folder);name='csolve_'+label;spec=importlib.util.spec_from_file_location(name,root/'__init__.py',submodule_search_locations=[str(root)]);package=importlib.util.module_from_spec(spec);sys.modules[name]=package;spec.loader.exec_module(package);packages[label]=package
 hashes[label]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
assert packages['candidate'].__version__=='0.35.0';assert packages['baseline'].__version__==('0.32.0' if lane=='composition' else '0.34.0')
configs=[('tiny-backward',2,2,(),False),('sgd-factor',16,4,(),False),('batch-b-only',64,4,(4,),False),('narrow-backward',256,4,(),False),('upper-narrow-backward',256,4,(),True),('wide-backward',256,128,(),True),('spd-chain',64,4,(),False),('jvp',16,4,(),False),('narrow-jvp',128,4,(),True),('narrow-jvp-backward',65,4,(),False),('quarter-jvp',128,32,(),False),('quarter-jvp-backward',128,32,(),True),('batch-jvp-backward',64,4,(2,),False),('fixed-factor-jvp',128,4,(),False),('fixed-factor-jvp-backward',128,32,(),True),('no-reverse-jvp',128,32,(),True),('no-reverse-tiny-jvp',64,4,(),False),('generic-control',16,4,(),False),('cholesky-control',7,2,(),False),('unary-control',8,4,(),False)]
results={}
for operation,n,width,batch,upper in configs:
 calls={};checks={}
 for label,package in packages.items():
  lib=package.torch;tdtype=getattr(lib,dtype);rng=np.random.default_rng(33);raw=(rng.normal(size=batch+(n,n))*.02).astype(dtype);raw[...,np.arange(n),np.arange(n)]=2
  parameter=lib.tensor(raw,requires_grad=operation not in ('batch-b-only','fixed-factor-jvp','fixed-factor-jvp-backward','no-reverse-jvp','no-reverse-tiny-jvp'));rhs=lib.tensor((rng.normal(size=batch+(n,width))*.2).astype(dtype),requires_grad=operation not in ('no-reverse-jvp','no-reverse-tiny-jvp'));inputs=[parameter,rhs];identity=lib.eye(n,dtype=tdtype)
  def solve(b,f,lib=lib,label=label,upper=upper):
   if label=='candidate' or lane=='previous':return lib.cholesky_solve(b,f,upper)
   first,second=(f.transpose(-1,-2),f) if upper else (f,f.transpose(-1,-2))
   y=lib.linalg.solve_triangular(first,b,upper=False)
   return lib.linalg.solve_triangular(second,y,upper=True)
  frozen=lib.tensor(np.triu(raw) if upper else np.tril(raw)) if operation=='batch-b-only' else None
  optimizer=lib.optim.SGD(inputs,lr=.00001) if operation=='sgd-factor' else None
  if operation in ('jvp','narrow-jvp','narrow-jvp-backward','quarter-jvp','quarter-jvp-backward','batch-jvp-backward','fixed-factor-jvp','fixed-factor-jvp-backward','no-reverse-jvp','no-reverse-tiny-jvp'):
   direction=lib.full_like(parameter,.03,requires_grad=operation in ('narrow-jvp-backward','quarter-jvp-backward','batch-jvp-backward'));drhs=lib.full_like(rhs,.07,requires_grad=operation in ('narrow-jvp-backward','quarter-jvp-backward','batch-jvp-backward'))
   if operation in ('narrow-jvp-backward','quarter-jvp-backward','batch-jvp-backward','fixed-factor-jvp-backward'):inputs.extend((direction,drhs))
   def call(parameter=parameter,rhs=rhs,direction=direction,drhs=drhs,solve=solve,upper=upper,lib=lib,operation=operation):
    f=parameter.triu() if upper else parameter.tril();df=direction.triu() if upper else direction.tril()
    value,tangent=lib.func.jvp(lambda b,f:solve(b,f),(rhs,f),(drhs,df))
    if operation in ('narrow-jvp-backward','quarter-jvp-backward','batch-jvp-backward','fixed-factor-jvp-backward'):
     parameter.grad=rhs.grad=direction.grad=drhs.grad=None
     (.17*value.square().mean()+.23*tangent.square().mean()).backward()
    if operation.startswith('no-reverse'):assert not value.requires_grad and not tangent.requires_grad
    return value,tangent
  else:
   def call(parameter=parameter,rhs=rhs,solve=solve,operation=operation,optimizer=optimizer,identity=identity,frozen=frozen,upper=upper,lib=lib):
    parameter.grad=rhs.grad=None
    if operation=='unary-control':x=parameter.sin().exp().tanh()
    elif operation=='generic-control':x=lib.linalg.solve(parameter,rhs)
    elif operation=='cholesky-control':x=lib.linalg.cholesky(parameter@parameter.transpose(-1,-2)+identity)
    else:
     f=frozen if frozen is not None else lib.linalg.cholesky(parameter@parameter.transpose(-1,-2)+identity) if operation=='spd-chain' else parameter.triu() if upper else parameter.tril()
     x=solve(rhs,f)
    x.square().mean().backward()
    if optimizer is not None:optimizer.step()
    return x
  calls[label]=call
  def check(call=call,inputs=inputs,operation=operation):
   value=call();outputs=value if operation in ('jvp','narrow-jvp','narrow-jvp-backward','quarter-jvp','quarter-jvp-backward','batch-jvp-backward','fixed-factor-jvp','fixed-factor-jvp-backward','no-reverse-jvp','no-reverse-tiny-jvp') else (value,)
   return [x.detach().numpy().copy() for x in outputs]+[None if item.grad is None else item.grad.numpy().copy() for item in inputs]+[item.numpy().copy() for item in inputs]
  checks[label]=check
 loops=1 if n>=128 else 8 if n>=64 else 50;warmup=3 if n>=64 else 30
 for call in calls.values():
  for _ in range(warmup):call()
 gc.collect();before=gc.get_stats();blocks=[]
 for block in range(9):
  order=('baseline','candidate','candidate','baseline') if block%2==0 else ('candidate','baseline','baseline','candidate');times={'baseline':[],'candidate':[]}
  for label in order:
   call=calls[label];start=time.perf_counter()
   for _ in range(loops):call()
   times[label].append((time.perf_counter()-start)*1e6/loops)
  blocks.append(dict(samples_us=times,time_reduction_percent=100*(1-statistics.mean(times['candidate'])/statistics.mean(times['baseline']))))
 values={label:check() for label,check in checks.items()}
 for actual,expected in zip(values['candidate'],values['baseline']):
  if expected is None:assert actual is None
  else:
   assert actual.dtype==expected.dtype==np.dtype(dtype);np.testing.assert_allclose(actual,expected,rtol=8e-5,atol=5e-6)
 results[operation]=dict(n=n,width=width,batch=batch,upper=upper,loops_per_sample=loops,warmup=warmup,blocks=blocks,median_time_reduction_percent=statistics.median(b['time_reduction_percent'] for b in blocks),checks='Values,dtypes,gradients/JVP channels and actually updated parameter states matched',gc_before=before,gc_after=gc.get_stats())
result=dict(python=sys.version,numpy=np.__version__,dtype=dtype,lane=lane,source_hashes=hashes,results=results,scope='Two isolated namespaces sharing NumPy;9 paired ABBA/BAAB blocks;GC enabled;real SGD updates. Previous lane compares0.34 fused API to0.35 through identical projected factors/directions;composition lane compares0.32 two-public-triangular-solve composition to0.35. Unchanged controls retained. JVP timings forward only except explicit narrow-jvp-backward which differentiates both channels through4inputs. Full unmasked native-gradient semantics separately validated. Thread environment requested2;shared host/effective vendor threads unverified;no CPU-WASM/nativeTorch relative-throughput claim.')
if 'bench_sources' not in globals():print(json.dumps(result))
