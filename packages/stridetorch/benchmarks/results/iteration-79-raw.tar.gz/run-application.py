"""Sequential application qualification; numeric budgets never overlap own work."""
from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent;p=r/'local-integration';repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
python=r.parent/'torch-iteration-69/integration-dev-env/bin/python';node='/Users/david/.npm/_npx/d18f28baf1132559/node_modules/node/bin/node'
env=dict(os.environ,PYTHON=str(python),PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0',PYTHONPATH=os.pathsep.join([str(repo/'packages/stridetorch/src'),str(repo)]),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
env['PATH']=str(Path(node).parent)+':/opt/homebrew/bin:'+str(python.parent)+':'+env['PATH']
context=read(p/'context.json');receipts=[]
names=[n for n in subprocess.check_output(['git','ls-files','-z','--','web/src','web/scripts','web/index.html','web/package.json','web/package-lock.json','web/vite.config.ts','web/tsconfig*.json','web/public/browser-judge','web/public/favicon.ico','web/public/favicon.png'],cwd=repo).decode().split('\0') if n]
frontend={n:sha(repo/n) for n in names};(p/'frontend-inputs.json').write_text(json.dumps(frontend,indent=2)+'\n')
def verify():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==context['upstream']
 for root,values in [(repo/'packages/stridetorch/src/stridetorch',context['source_hashes']),(repo/'packages/stridetorch/tests',read(p/'test-inputs.json')),(repo,read(p/'application-inputs.json')),(repo,read(p/'policy-identity.json')),(repo,read(p/'immutable-assets.json')),(repo,frontend)]:
  for n,h in values.items():assert sha(root/n)==h,n
 if (p/'live-export-sha256.json').exists():
  for n,h in read(p/'live-export-sha256.json').items():assert sha(repo/'web/public/data'/n)==h,n
def run(label,args,cwd=repo,extra=None):
 verify();start=time.monotonic()
 with (p/(label+'.log')).open('w') as log:
  child=subprocess.Popen(args,cwd=cwd,env={**env,**(extra or {})},stdout=log,stderr=subprocess.STDOUT)
  (p/'gate-progress.json').write_text(json.dumps(dict(status='running',label=label,pid=child.pid,receipts=receipts),indent=2)+'\n');code=child.wait()
 receipt=dict(label=label,exit_code=code,seconds=time.monotonic()-start,command=args,cwd=str(cwd),log_sha256=sha(p/(label+'.log')),summary=[line[:1000] for line in (p/(label+'.log')).read_text().splitlines()[-2:]])
 receipts.append(receipt);(p/'gate-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(receipt),flush=True)
 if code:raise SystemExit(code)
 verify()
run('cpu-suite',[str(python),'-B',str(p/'run-cpu.py')])
assert read(p/'cpu-receipt.json')['status']=='passed'
run('native-catalog',[str(python),'-B','-m','paperleet.cli','ci','--budget','600'])
run('export',[str(python),'-B','-m','paperleet.cli','export'])
run('verify-export',[str(python),'-B',str(p/'verify-export.py')])
run('full-wasm',[node,'web/scripts/check-browser-wasm.mjs','--all'])
wasm=read(repo/'reports/browser-wasm.json');assert wasm['passed'] and wasm['modules']==wasm['catalog_modules']==context['catalog_modules'] and not wasm['browser_budget_exceeded']
(p/'full-wasm-result.json').write_text(json.dumps(wasm,indent=2)+'\n')
run('full-frontend-check',['npm','run','check'],repo/'web')
run('wasm-driver',[node,'web/scripts/check-wasm-cases.mjs'])
run('pages-policy',[node,'web/scripts/check-pages-release.cjs'])
run('build',['npm','run','build'],repo/'web',dict(VITE_PATH_ROUTING='0'))
value=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED','--jq','.value'],cwd=repo,text=True).strip();assert value in ['0','1']
profile=dict(VITE_PATH_ROUTING='1',PAPERLEET_MAIN_SITE_ENABLED=value,VITE_PUBLIC_SITE='0' if value=='1' else '1',VITE_APP_EDITION='hosted' if value=='1' else 'local',VITE_API_ORIGIN='https://app.paperleet.com' if value=='1' else '',VITE_HOSTED_APP_AVAILABLE='1',VITE_HOSTED_APP_URL='https://app.paperleet.com')
(p/'current-pages-profile.json').write_text(json.dumps(profile,indent=2)+'\n');run('pages-profile-build',['npm','run','build'],repo/'web',profile)
run('pages-assets',[str(python),'-B','web/scripts/check-pages-assets.py'])
run('retain-production-assets-check',[str(python),'-B','web/scripts/retain-pages-assets.py','web/dist','--check'])
run('generated-worker',[node,str(p/'verify-generated-worker.mjs')])
run('nested-wasm',[node,str(p/'check-nested-wasm.mjs')])
verify();result=dict(status='passed',source_hashes=context['source_hashes'],upstream=context['upstream'],integration_base=context['integration_base'],original_core_numeric_execution_base=context['original_numeric_execution_base'],receipts=receipts,modules=wasm['modules'],mutants=sum(v['mutants'] for v in wasm['results']),ci_triggered=False,published=False,deployed=False)
(p/'gates-result.json').write_text(json.dumps(result,indent=2)+'\n');(p/'gate-progress.json').write_text(json.dumps(dict(status='completed',receipts=receipts),indent=2)+'\n');print('ALL LOCAL APPLICATION GATES PASSED',flush=True)
