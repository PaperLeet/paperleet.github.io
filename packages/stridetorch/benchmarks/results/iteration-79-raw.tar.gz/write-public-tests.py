from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');native=json.loads((r/'native-empty-dispatch.json').read_text())
shapes=[((0,),(0,)),((2,0),(0,)),((0,3),(3,)),((0,),(0,2)),((2,0),(0,2)),((2,2,0),(0,2)),((2,2,3),(3,0)),((2,0),(2,0,2)),((0,3),(2,3,2)),((0,),(2,0,2)),((2,2,0),(2,0,2)),((1,2,0),(3,0,2)),((3,2,0),(1,0,2)),((0,2,3),(1,3,2)),((1,2,3),(0,3,2)),((2,1,0,3),(1,3,3,2))]
lookup={}
for row in native['rows']:
 key=(tuple(map(tuple,row['shapes'])),tuple(row['dtypes']),tuple(row['requires_grad']),row['layout']);lookup[key]=row
fixture=[]
for sa,sb in shapes:
 for flags in [(False,False),(True,False),(False,True)]:
  for layout in ['C','F']:
   x=lookup[((sa,sb),('float32','float64'),flags,layout)];y=lookup[((sa,sb),('float64','float32'),flags,layout)];assert x['accepted']==y['accepted']
   code='error' if not x['accepted'] else 'L' if x['dtype']=='float32' else 'R';shape=tuple(x.get('shape',()))
   if x['accepted']:assert y['dtype']==('float64' if code=='L' else 'float32') and y['shape']==x['shape']
   fixture.append((sa,sb,flags,layout,code,shape))
header='''"""Vector/matrix entry points, independent derivative algebra and native empty controls."""
import copy
import gc
import pickle
import tracemalloc
import weakref
import numpy as np
import pytest
from stridetorch import torch, as_torch, UnsupportedOperation, _tensor


# Measured native PyTorch 2.6 controls, independent of the implementation's
# dispatch planner. L/R select the original left/right dtype; error is a
# native rejection. Both float32/64 orders were independently checked.
'''
header+='# Native record SHA-256: '+hashlib.sha256((r/'native-empty-dispatch.json').read_bytes()).hexdigest()+'\n'
header+='EMPTY_CONTRACTS = [\n'+''.join('    '+repr(row)+',\n' for row in fixture)+']\n\n'
(repo/'packages/stridetorch/tests/test_vector_products.py').write_text(header+(r/'public-test-body.py.txt').read_text())
print('Public native control rows:',len(fixture))
