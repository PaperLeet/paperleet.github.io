from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;p=r/'local-integration';repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
gates=read(p/'gates-result.json');assert gates['status']=='passed' and read(p/'gate-progress.json')['status']=='completed'
native=read(repo/'reports/ci.json');assert native['passed'] and not native['issues'] and native['repeats']==3 and native['problems']==gates['modules']==89
assert native['tests_executed']>0 and native['duration_s']<=600
log=(p/'native-catalog.log').read_text();lines=log.splitlines()
assert lines[0]==f"PASS · {native['problems']} problems · {native['tests_executed']} test cases · {native['repeats']} runs · {native['duration_s']:.2f}s"
for name,mutants in native['mutation'].items():assert f"  {name}: {sum(bool(v) for v in mutants.values())}/{len(mutants)} mutants caught" in lines
shutil.copyfile(repo/'reports/ci.json',p/'native-catalog-result.json')
out=p/'native-references';out.mkdir(exist_ok=False)
refs={}
for name in native['mutation']:
 q=repo/'reports'/(name.replace('/','-')+'-reference.json');shutil.copyfile(q,out/q.name);refs[q.name]=sha(q)
assert len(refs)==89
for record in gates['receipts']:assert record['exit_code']==0 and sha(p/(record['label']+'.log'))==record['log_sha256'],record['label']
wasm=read(p/'full-wasm-result.json');assert wasm['passed'] and not wasm['browser_budget_exceeded'] and sum(v['mutants'] for v in wasm['results'])==406
worker=read(p/'generated-worker-proof.json');assert sha(repo/worker['asset'])==worker['asset_sha256'] and sha(repo/worker['generated_module'])==worker['generated_module_sha256']
assert read(p/'nested-wasm-result.json')['status']=='passed'
tests=r/'selected-tests';tests.mkdir(exist_ok=False)
for name,digest in read(p/'test-inputs.json').items():
 source=repo/'packages/stridetorch/tests'/name;assert sha(source)==digest,name
 shutil.copyfile(source,tests/name)
result=dict(status='verified',native_repeats=3,native_modules=89,native_tests_executed=native['tests_executed'],native_seconds=native['duration_s'],native_issues=[],native_reference_sha256=refs,wasm_modules=89,wasm_mutants=406,all_gate_log_hashes_match=True,worker_digest=worker['asset_sha256'],nested_real_browser='passed',ci_triggered=False,published=False,deployed=False)
(p/'evidence-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='native_reference_sha256'}),flush=True)
