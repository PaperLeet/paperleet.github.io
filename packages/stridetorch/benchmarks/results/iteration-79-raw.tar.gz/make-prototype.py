from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');dest=r/'prototype/stridetorch';assert not dest.exists();shutil.copytree(repo/'packages/stridetorch/src/stridetorch',dest,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
f=dest/'_ops.py';s=f.read_text();start=s.index('def _empty_bmm(');end=s.index('\ndef _matrix_product(',start)
s=s[:start]+'''def _empty_product(input, mat2, shape, dtype):
    if isinstance(input, _autograd.ForwardTensor) or isinstance(mat2, _autograd.ForwardTensor):
        a, da = _autograd.forward_parts(input)
        b, db = _autograd.forward_parts(mat2)
        return _autograd.ForwardTensor(_empty_product(a, b, shape, dtype),
            _empty_product(da, b, shape, dtype) + _empty_product(a, db, shape, dtype))
    shape_a, shape_b = tuple(input.shape), tuple(mat2.shape)
    dtype_a, dtype_b = input.dtype, mat2.dtype
    value = np.zeros(shape, dtype=dtype)
    if np.dtype(dtype).kind not in 'fc':
        return _tensor.Tensor(value, _metadata_owned=True)
    saved = []
    if input.requires_grad:saved.append(mat2)
    if mat2.requires_grad:saved.append(input)
    return _autograd.result(value,
        (input, lambda gradient: np.zeros(shape_a, dtype=dtype_a)),
        (mat2, lambda gradient: np.zeros(shape_b, dtype=dtype_b)), versioned=saved)


def _empty_bmm(input, mat2):
    return _empty_product(input, mat2, (input.shape[0], input.shape[1], mat2.shape[2]), mat2.dtype)


def _matmul_fold(input, other):
    large, small = (input, other) if input.ndim >= other.ndim else (other, input)
    if large.ndim < 3 or small.ndim > 2:return False
    if small.requires_grad:return True
    if input.ndim == 2:return False
    if not large.numel():return True
    shape, strides = tuple(large.shape), tuple(large.stride())
    if other.ndim > input.ndim:
        shape = (*shape[:-2], shape[-1], shape[-2])
        strides = (*strides[:-2], strides[-1], strides[-2])
    return all(strides[i] == strides[i+1] * shape[i+1] for i in range(large.ndim - 2))


def _matmul_mode(input, other):
    if input.ndim == other.ndim == 1:return 'dot'
    if input.ndim == 2 and other.ndim == 1:return 'mv'
    if max(input.ndim, other.ndim) <= 2:return 'mm'
    if _matmul_fold(input, other):return 'mv' if min(input.ndim, other.ndim) == 1 else 'mm'
    if input.ndim == other.ndim == 3 and input.shape[0] != other.shape[0]:
        if input.shape[0] == 1 and (input.requires_grad or isinstance(input, _autograd.ForwardTensor)):
            return _matmul_mode(input.squeeze(0), other)
        if other.shape[0] == 1 and (other.requires_grad or isinstance(other, _autograd.ForwardTensor)):
            return _matmul_mode(input, other.squeeze(0))
    return 'bmm'


def _matmul_special(input, other):
    # Native 2.6 routes matrix-vector, folded and batched products differently.
    # This boundary uses geometry only; no operand cast/copy or numerical work.
    a, b = input.shape, other.shape
    if not a or not b:raise RuntimeError('matmul requires at least 1D operands')
    if a[-1] != (b[-2] if len(b) > 1 else b[0]):
        raise RuntimeError('matmul contraction dimensions do not match')
    aa, bb = a[:-2] if len(a) > 1 else (), b[:-2] if len(b) > 1 else ()
    size = max(len(aa), len(bb));aa = (1,) * (size-len(aa)) + tuple(aa);bb = (1,) * (size-len(bb)) + tuple(bb)
    batch = []
    for x, y in zip(aa, bb):
        if x == y:batch.append(x)
        elif x == 1:batch.append(y)
        elif y == 1:batch.append(x)
        else:raise RuntimeError('matmul batch dimensions do not match')
    mode = _matmul_mode(input, other)
    empty = not input.numel() or not other.numel()
    if mode in ('dot', 'mm') or not empty:
        if input.dtype != other.dtype:raise RuntimeError('matmul operands must have the same dtype')
        if (input.dtype.kind == 'b' or input.dtype.kind == 'u' and input.dtype.itemsize > 1) and (mode == 'dot' or not empty):
            raise RuntimeError('matmul is not implemented for this dtype')
        dtype = input.dtype
    else:
        dtype = (input.dtype if other.ndim > input.ndim else other.dtype) if mode == 'mv' else other.dtype
    if empty:
        shape = tuple(batch) + (tuple(a[-2:-1]) if len(a) > 1 else ()) + (tuple(b[-1:]) if len(b) > 1 else ())
        return shape, dtype
    return None

''' +s[end:];f.write_text(s)
f=dest/'_tensor.py';s=f.read_text();needle="        a, b = self._data, other._data\n        if a.dtype != b.dtype: raise RuntimeError('matmul operands must have the same dtype')";assert s.count(needle)==1;s=s.replace(needle,"""        a, b = self._data, other._data
        if a.dtype != b.dtype or a.dtype.kind in 'bu' or not a.size or not b.size:
            special = _ops._matmul_special(self, other)
            if special is not None:return _ops._empty_product(self, other, *special)
        if a.dtype != b.dtype: raise RuntimeError('matmul operands must have the same dtype')""");f.write_text(s)
f=dest/'_autograd.py';s=f.read_text()
for name,left,right in [('__matmul__','self','other'),('__rmatmul__','other','self')]:
 needle=f'    def {name}(self, other):\n        p, t = forward_parts(other)';assert s.count(needle)==1
 replacement=f'''    def {name}(self, other):
        other = _ops.wrap(other)
        if self.dtype != other.dtype or self.dtype.kind in 'bu' or not self.numel() or not other.numel():
            special = _ops._matmul_special({left}, {right})
            if special is not None:return _ops._empty_product({left}, {right}, *special)
        p, t = forward_parts(other)'''
 s=s.replace(needle,replacement)
f.write_text(s)
record=dict(status='unqualified_prototype',based_on=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),version_literal_unchanged=True,production_worktree_modified=False,source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.iterdir() if p.is_file()})
(r/'prototype-source.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='source_hashes'}))
