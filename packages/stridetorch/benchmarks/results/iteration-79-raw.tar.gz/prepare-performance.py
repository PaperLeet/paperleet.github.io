from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;files={}
for prefix in ['baseline','candidate']:
 for p in (r/prefix/'stridetorch').iterdir():
  if p.is_file():files[str(p.relative_to(r))]=hashlib.sha256(p.read_bytes()).hexdigest()
(r/'fixtures').mkdir(exist_ok=True)
for p in (r.parent/'torch-iteration-77/fixtures').glob('*.py'):shutil.copyfile(p,r/'fixtures'/p.name)
if not list((r/'fixtures').glob('*.py')):
 src=Path('/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/benchmarks/fixtures/batched_attention')
 for p in src.glob('*.py'):shutil.copyfile(p,r/'fixtures'/p.name)
for p in (r/'fixtures').glob('*.py'):files[str(p.relative_to(r))]=hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['benchmark.py']:files[n]=hashlib.sha256((r/n).read_bytes()).hexdigest()
(r/'performance-plan.json').write_text(json.dumps(dict(files=files,phase='pilot',all_batches_at_least_20_ms=True,not_a_final_speedup_claim=True),indent=2)+'\n')
