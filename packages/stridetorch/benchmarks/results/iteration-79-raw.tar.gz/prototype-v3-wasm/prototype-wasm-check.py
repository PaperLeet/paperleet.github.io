import json,os,runpy,sys
from pathlib import Path
import stridetorch
from stridetorch import _tensor
assert _tensor._WASM_MATMUL
os.chdir('/checks');comparisons=[]
for script,suffix in [('probe-matmul-contracts.py','matmul-contracts'),('probe-empty-dispatch.py','empty-dispatch'),('probe-matmul-ad.py','matmul-ad')]:
 sys.argv=[script,'candidate'];runpy.run_path('/checks/'+script,run_name='__main__')
 native=json.loads(Path('/controls/native-'+suffix+'.json').read_text());actual=json.loads(Path('/checks/candidate-'+suffix+'.json').read_text());assert native['probe_sha256']==actual['probe_sha256'];assert len(native['rows'])==len(actual['rows']);failures=[]
 for a,b in zip(native['rows'],actual['rows']):
  keys=['op','label','shapes','dtypes','requires_grad','layout','channel']
  assert all(a.get(k)==b.get(k) for k in keys)
  different=a['accepted']!=b['accepted']
  if a['accepted'] and b['accepted']:
   different|=any(a.get(k)!=b.get(k) for k in ['dtype','shape','values','requires_grad_output','result'])
  if different:failures.append(dict(native=a,actual=b))
 comparisons.append(dict(suite=suffix,cases=len(native['rows']),differences=len(failures),failures=failures))
import pytest
class Record:
 def __init__(self):self.passed=0;self.failures=[]
 def pytest_runtest_logreport(self,report):
  if report.when=='call' and report.passed:self.passed+=1
  if report.failed:self.failures.append(dict(test=report.nodeid,error=str(report.longrepr)[-2000:]))
record=Record();code=pytest.main(['/contracts','-q','--noconftest','-p','no:cacheprovider','--import-mode=importlib'],plugins=[record])
wasm_report=dict(status='passed' if code==0 and not any(c['differences'] for c in comparisons) else 'failed',implementation_version_literal=stridetorch.__version__,prototype=True,comparisons=comparisons,sdk=dict(passed=record.passed,exit_code=int(code),failures=record.failures))
