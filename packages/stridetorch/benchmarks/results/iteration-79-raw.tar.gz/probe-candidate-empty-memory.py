from pathlib import Path
import gc,hashlib,json,sys,tracemalloc,weakref
import numpy as np
import stridetorch
from stridetorch import torch
source=np.ones((1,8,128,256),dtype='float64');ref=weakref.ref(source)
a=torch.ones(32,1,0,128,requires_grad=True);b=torch.from_numpy(source)
source_bytes=source.nbytes;gc.collect();tracemalloc.start()
try:
 y=torch.matmul(a,b);current,peak=tracemalloc.get_traced_memory()
finally:tracemalloc.stop()
versions=len(y._grad_node.versions)
with torch.no_grad():b.fill_(7)
del source,b;gc.collect();released=ref() is None
gradient,=torch.autograd.grad(y,(a,),torch.ones_like(y))
assert released and peak<128*1024 and gradient.shape==a.shape
result=dict(status='passed',version=stridetorch.__version__,python=sys.version,numpy=np.__version__,shape_a=list(a.shape),input_b_shape=[1,8,128,256],input_b_bytes=source_bytes,output_shape=list(y.shape),traced_current_bytes=current,traced_peak_bytes=peak,saved_input_version_counters=versions,original_non_grad_b_released=released,gradient_shape=list(gradient.shape),gradient_dtype=str(gradient.dtype),source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(stridetorch.__file__).parent.iterdir() if p.is_file()},probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='CPython tracemalloc allocations after inputs exist, original source lifetime and saved input counters; not process RSS or physical VRAM.')
Path(__file__).with_name('candidate-empty-memory-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='source_hashes'}))
