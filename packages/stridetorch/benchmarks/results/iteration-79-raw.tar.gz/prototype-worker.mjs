import{loadPyodide}from'../torch-iteration-76/runtime/pyodide.mjs';
import{loadJudgePackages}from'../torch-iteration-76/chrome-sdk/packages.mjs';
self.onmessage=async()=>{
 try{
  const plan=await(await fetch('./prototype-wasm-plan.json')).json(),py=await loadPyodide({indexURL:new URL('../torch-iteration-76/runtime/',self.location.href).href,stdout(){},stderr(){}});await loadJudgePackages(py,[]);
  for(const[name,digest]of Object.entries(plan.files)){
   const bytes=new Uint8Array(await(await fetch('./'+name)).arrayBuffer()),actual=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),v=>v.toString(16).padStart(2,'0')).join('');if(actual!==digest)throw Error('Source mismatch: '+name);
   const target=name.startsWith('prototype/')?'/'+name:name.startsWith('tests/')?'/contracts/'+name.slice(6):name.startsWith('native-')?'/controls/'+name:'/checks/'+name;
   py.FS.mkdirTree(target.split('/').slice(0,-1).join('/'));py.FS.writeFile(target,bytes);
  }
  py.runPython("import sys\nsys.path.insert(0,'/prototype')");py.runPython("exec(compile(open('/checks/prototype-wasm-check.py').read(),'/checks/prototype-wasm-check.py','exec'))");
  self.postMessage({...JSON.parse(py.runPython('json.dumps(wasm_report)')),files:plan.files,pyodide:py.version,expected_sdk:plan.expected_sdk,expected_native_cases:plan.expected_native_cases});
 }catch(error){self.postMessage({status:'failed',error:String(error),stack:error.stack});}
};
