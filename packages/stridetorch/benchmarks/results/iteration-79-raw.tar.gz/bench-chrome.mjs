import fs from 'node:fs';import assert from 'node:assert/strict';
import {withFixtureServer} from '../torch-iteration-70/fixture-server.mjs';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const cycle=Number(process.argv[2]);
await withFixtureServer(async origin=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 try{
  const page=await browser.newPage();await page.goto(origin+'/torch-iteration-79/index.html');
  const result=await page.evaluate(cycle=>new Promise((resolve,reject)=>{const worker=new Worker('./bench-worker.mjs',{type:'module'});const timer=setTimeout(()=>{worker.terminate();reject(Error('batch benchmark timeout'));},360000);worker.onmessage=({data})=>{clearTimeout(timer);worker.terminate();resolve(data);};worker.onerror=e=>{clearTimeout(timer);worker.terminate();reject(Error(e.message));};worker.postMessage({cycle});}),cycle);
  fs.writeFileSync(new URL('latency-chrome-'+cycle+'.json',import.meta.url),JSON.stringify({...result,browser:browser.version()},null,2)+'\n');assert.equal(result.status,'completed',JSON.stringify(result));assert.equal(result.report.rows.length,98);console.log(JSON.stringify({status:'completed',cycle,rows:result.report.rows.length}));
 }finally{await browser.close();}
});
