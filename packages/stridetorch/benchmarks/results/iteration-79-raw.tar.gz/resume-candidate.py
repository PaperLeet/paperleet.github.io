from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');source=repo/'packages/stridetorch/src/stridetorch';head='e64e88956d796f2d8bd06d3854257575fa4e9856'
f=source/'_api.py';s=f.read_text();s=s.replace("        'matmul': lambda input,other: _ops.wrap(input) @ other, 'pow': _ops.power,","        'pow': _ops.power,")
s=s.replace("{'mm': _ops.mm, 'bmm': _ops.bmm}","{'mm': _ops.mm, 'bmm': _ops.bmm, 'matmul': _ops.matmul, 'dot': _ops.dot, 'mv': _ops.mv}")
start=s.index('    def dot(input, other):');end=s.index("    registry.group('torch', {\n        'reciprocal'",start);assert "{'outer': outer, 'dot': dot}" in s[start:end];s=s[:start]+"    registry.group('torch', {'outer': outer}, reverse='analytic')\n"+s[end:];f.write_text(s)
f=source/'_tensor.py';s=f.read_text();needle='    def __matmul__(self, other):\n        other = _ops.wrap(other)';assert s.count(needle)==1
replacement='''    def matmul(self, other):
        return _ops.matmul(self, other)
    def dot(self, tensor):
        return _ops.dot(self, tensor)
    def mv(self, vec):
        return _ops.mv(self, vec)
    def __matmul__(self, other):
        if not isinstance(self, Tensor):raise TypeError('matmul receiver must be a Tensor')
        if not isinstance(other, Tensor):return NotImplemented''';s=s.replace(needle,replacement)
s=s.replace('        a, b = self._data, other._data\n        if a.dtype != b.dtype or',"        a, b = self._data, other._data\n        if not a.ndim or not b.ndim:raise RuntimeError('matmul requires at least 1D operands')\n        if a.dtype != b.dtype or",1)
needle="        output=_autograd.result(\n            _matmul.product(a, b) if _WASM_MATMUL and a.size >= 4096 else a @ b,\n            (self, left), (other, right), versioned=())";assert s.count(needle)==1
s=s.replace(needle,"""        try:value = _matmul.product(a, b) if _WASM_MATMUL and a.size >= 4096 else a @ b
        except ValueError as error:raise RuntimeError(str(error)) from None
        output=_autograd.result(value, (self, left), (other, right), versioned=())""")
needle='    def __rmatmul__(self, other): return _ops.wrap(other) @ self';assert s.count(needle)==1
s=s.replace(needle,"""    def __rmatmul__(self, other):
        if not isinstance(self, Tensor):raise TypeError('matmul receiver must be a Tensor')
        return other @ self if isinstance(other, Tensor) else NotImplemented

    def __array_wrap__(self, array, context=None, return_scalar=False):
        # NumPy matmul inference follows Python's NotImplemented fallback.
        # __array__ keeps the existing guard against implicit graph escapes.
        if context is not None and context[0] is np.matmul:
            return Tensor(array, _metadata_owned=True)
        return array[()] if return_scalar else array""");f.write_text(s)
f=source/'_autograd.py';s=f.read_text();needle='        other = _ops.wrap(other)\n        if self.dtype != other.dtype or';assert s.count(needle)==2;s=s.replace(needle,'        if not isinstance(other, _tensor.Tensor):return NotImplemented\n        if self.dtype != other.dtype or');f.write_text(s)
for f in [source/'__init__.py',repo/'packages/stridetorch/pyproject.toml']:
 s=f.read_text();assert s.count('0.76.0')==1;f.write_text(s.replace('0.76.0','0.77.0'))
record=dict(status='in_repository_candidate_under_validation',version='0.77.0',baseline=head,source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.is_file()},prototype_version_literal_changed=True,main_not_updated=True)
(r/'candidate-source.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='source_hashes'}))
