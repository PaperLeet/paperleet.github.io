from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');source=repo/'packages/stridetorch/src/stridetorch';files={};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(r/'candidate/stridetorch').mkdir(parents=True,exist_ok=True);(r/'baseline/stridetorch').mkdir(parents=True,exist_ok=True);(r/'core-tests').mkdir(exist_ok=True)
source_hashes={};baseline={}
for p in source.iterdir():
 if not p.is_file():continue
 n=p.name;target=r/'candidate/stridetorch'/n;shutil.copyfile(p,target);files[str(target.relative_to(r))]=sha(target);source_hashes[n]=sha(target)
 b=subprocess.check_output(['git','show','e64e88956d796f2d8bd06d3854257575fa4e9856:packages/stridetorch/src/stridetorch/'+n],cwd=repo);target=r/'baseline/stridetorch'/n;target.write_bytes(b);baseline[n]=sha(target)
assert baseline==json.loads((r/'state.json').read_text())['source_hashes']
for p in (repo/'packages/stridetorch/tests').glob('test_*.py'):
 if p.name=='test_standalone.py':continue
 target=r/'core-tests'/p.name;shutil.copyfile(p,target);files[str(target.relative_to(r))]=sha(target)
for n in ['probe-matmul-contracts.py','probe-empty-dispatch.py','probe-matmul-ad.py','probe-empty-storage.py','probe-one-sided-grad.py','probe-matrix-entrypoints.py','native-matmul-contracts.json','native-empty-dispatch.json','native-matmul-ad.json','native-empty-storage.json','native-one-sided-grad.json','native26-matrix-entrypoints.json','core-wasm-check.py']:files[n]=sha(r/n)
freeze=dict(status='core_candidate_frozen_for_qualification',version='0.77.0',base='e64e88956d796f2d8bd06d3854257575fa4e9856',source_hashes=source_hashes,baseline_source_hashes=baseline,tests={p.name:sha(p) for p in (repo/'packages/stridetorch/tests').glob('test_*.py')},cpu_sdk_summary=next(line for line in reversed((r/'full-sdk.log').read_text().splitlines()) if line.startswith('11876 passed')),cpu_sdk_log_sha256=sha(r/'full-sdk.log'))
(r/'core-source-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n');(r/'core-wasm-plan.json').write_text(json.dumps(dict(files=files,expected_sdk=11863,native_cases_examined=11341,explicit_boundaries=dict(nonleaf_mutation=180,complex_autograd=79,output_buffers=3)),indent=2)+'\n');print(json.dumps(dict(source_files=len(source_hashes),wasm_test_files=len(list((r/'core-tests').glob('test_*.py'))),expected_sdk=11863)))
