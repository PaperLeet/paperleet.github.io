from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
freeze=read(r/'core-source-freeze.json');core=read(r/'core-qualification.json');gates=read(r/'local-integration/gates-result.json');performance=read(r/'performance-summary.json');archive=read(r/'archive-verification.json');cpu=read(r/'local-integration/cpu-receipt.json');export=read(r/'local-integration/export-identity.json');context=read(r/'local-integration/context.json')
integration=read(r/'integration-reconciliation.json');ui=read(r/'rebased-ui/result.json')
assert integration['status']=='rebased_ui_qualified' and ui['status']=='passed'
assert gates['status']=='passed' and archive['status']=='verified' and cpu['status']=='passed' and performance['status']=='completed'
assert gates['source_hashes']==performance['source_hashes']==freeze['source_hashes']
for name,h in freeze['source_hashes'].items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==h,name
selected=['core-qualification.json','core-source-freeze.json','performance-summary.json','package-proof/result.json','package-proof/sdist-identities.json','installed-matrix-result.json','candidate-empty-memory-result.json','native-empty-memory-result.json','local-integration/gates-result.json','local-integration/cpu-receipt.json','local-integration/export-identity.json','local-integration/generated-worker-proof.json','local-integration/nested-wasm-result.json','local-integration/evidence-verification.json','local-integration/native-catalog-result.json','runtime-identity.json','application-host-observation.json','upstream-ui-reconciliation.json']
selected.extend(['rebased-ui/result.json','rebased-ui/context.json','rebased-ui/generated-worker-proof.json','rebased-ui/nested-wasm-result.json','integration-reconciliation.json'])
selected.append('qualification-review.json')
result=dict(status='qualified_locally',version='0.77.0',iteration=79,source_hashes=freeze['source_hashes'],original_core_numeric_execution_base=freeze['base'],application_execution_head=context['upstream'],original_integration_base=context['integration_base'],integration_base=integration['integration_base'],frontend_execution_head=integration['execution_head'],rebased_ui=ui,core=core,cpu_application=cpu,application_gates=gates,exports=export,performance=performance,memory={'native':read(r/'native-empty-memory-result.json'),'candidate':read(r/'candidate-empty-memory-result.json'),'comparison_limit':'Native logical retained storage and CPython tracemalloc incremental allocation are distinct metrics. Neither measures process RSS or physical VRAM.'},raw_archive=archive,evidence_sha256={name:sha(r/name) for name in selected},main_adopted=False,ci_triggered=False,tags_created=False,published=False,deployed=False)
result['qualification_review']=read(r/'qualification-review.json')
(repo/'packages/stridetorch/benchmarks/results/iteration-79.json').write_text(json.dumps(result,indent=2)+'\n')
rows=[]
for kind,v in performance['runtimes'].items():
 groups=v['groups'];rows.append(f"| {kind} | {groups['tiny_inference']['ratio_geomean']:.3f} | {groups['empty_broadcast_backward']['ratio_geomean']:.3f} | {groups['paperleet_attention_gqa']['ratio_geomean']:.3f} | {v['AA_geomean']:.3f} |")
regressions=[]
for kind,v in performance['runtimes'].items():
 for row in v['rows']:
  if row['consistent_over_5_percent_regression']:regressions.append(f"- {kind}: `{row['key']}`, median ratio {row['candidate_over_baseline_median']:.3f}; process ratios "+', '.join(f'{x:.3f}' for x in row['candidate_over_baseline_processes'])+'.')
text=f'''# Iteration 79: vector APIs and lower matmul inference overhead

Version 0.77 adds `torch.mv`, `Tensor.mv`, `Tensor.dot` and `Tensor.matmul`, with native Tensor-only binding and keyword names for root `dot`/`matmul`. Existing `import torch` aliases and installed launchers expose the same APIs. Normal CPU/WASM numerical kernels, including the qualified batched matmul and SDPA engines, retain their 0.76 bytes. This iteration reduces Python graph setup for ordinary inference and handles empty products from metadata.

## Contracts and gradients

`dot` requires two vectors, `mv` a matrix and vector, and `matmul` supports vector promotion and batch broadcasting. Root `out=None` is accepted; actual output buffers remain explicitly unsupported and methods reject `out`. Foreign operands follow Python reflected-operator handling. NumPy reflected matmul inference requires detached inputs when gradients are enabled. Real float32/float64 paths cover reverse gradients, JVP, functional reverse-based JVP and HVP. Existing complex-autograd and nonleaf mutation boundaries remain explicit.

Native Torch 2.6 empty products dispatch differently depending on rank, stride, gradient flags and broadcast/folding. Matching those routes requires shape/dtype rules, including mixed-dtype empty results and the correct saved-input storage guards. The implementation does not expand or cast source arrays for those zero results. Empty output element strides are contiguous. Floating gradients cannot silently disappear into an integer/bool result. An LRU cache stores only plain integer geometry, with a regression proving that user dtype metadata is released.

The 680 new public regressions include independent bilinear Jacobian-column, VJP and HVP expectations, literal native controls, strict signatures, dtype/error behavior, alias mutations, lifetime checks and installed aliases. Final CPU library suite: {freeze['cpu_sdk_summary']}. Final Node and real Chrome Workers each pass 11,863 library tests plus 11,341 native controls examined: 11,079 matched cases and 262 explicit existing unsupported boundaries (180 nonleaf mutations, 79 complex-AD cases, three output buffers). Unsupported cases are reported separately rather than counted as matches. Pyodide is pinned to 0.29.4 with NumPy 2.2.5.

The independent wheel on Python 3.10.19 / NumPy 1.26.4 passes 11,873 tests with three existing rank-limit skips. Public/private wheels contain the exact 62 selected source/notice resources, both sdists are actually rebuilt, and co-installed namespaces plus unchanged `import torch` CLI execution pass without native Torch. No artifacts are published.

## Warm latency

Each runtime uses three fresh processes, 98 flows, three rotated batches per flow and identical-iteration A0/A1/B comparisons. A0/A1 independently import the same 0.76 baseline. Values and full gradients are checked before calibration; batches target 100 ms and every recorded batch exceeds 20 ms. The 78 existing flows are retained and 20 tiny/empty flows added. The `mv16` flow measures the existing `@` route so the baseline remains runnable; these are not direct timings of a previously absent API.

Ratios below compare 0.77 elapsed time with 0.76. Group values are geometric means of per-flow median process ratios, not whole-application speedups.

| Runtime | Tiny inference | Empty broadcast backward | PaperLeet Attention/GQA | A/A control |
|---|---:|---:|---:|---:|
{chr(10).join(rows)}

All flow/process ratios and raw timings are retained. Stable regressions above five percent across every process are listed here:

{chr(10).join(regressions) if regressions else 'None in these three-process measurements.'}

Small backward calls also carry strict dispatch/stride bookkeeping costs; speed improvements are scoped to the measured paths. These results exclude cold import, native-Torch/GPU comparisons, transfers and whole-application throughput. The benchmark and original PaperLeet fixtures are retained for reproduction.

## Allocation evidence

For A=(32,1,0,128) float32 with gradients and B=(1,8,128,256) float64 without gradients, native Torch 2.6 retains a separate expanded 64 MiB saved matrix. The candidate probe traces {read(r/'candidate-empty-memory-result.json')['traced_peak_bytes']:,} bytes of peak new CPython allocation and releases original B. Native logical retained storage and CPython traced allocations are distinct metrics; no RSS or physical VRAM comparison is claimed.

## Application integration

Full native application/library suite: {cpu['summary']}.

The native catalog reference/mutation/determinism run retains three repetitions and every per-module CPU budget under the aggregate 600-second deadline. All {gates['modules']} maintained browser modules and {gates['mutants']} mutants pass their actual WASM budgets. Complete frontend checks, release-policy checks, default and current Pages path-routing profile builds, asset-retention checks and exact worker regeneration pass. A fresh real Chrome session loads the nested Attention page, edits its canonical solution through CodeMirror and passes 7/7 actual Worker/Pyodide tests plus explicit mm/bmm/mv/dot/matmul assertions. Only health and anonymous-account responses are trusted fixtures; all other external requests, including writes, are blocked. No live API/backend integration is claimed.

The full WASM catalog uses concurrency {read(r/'local-integration/full-wasm-result.json')['concurrency']}. A separate native test process was observed on this host during that application run and left untouched. Those results establish actual per-module budget compliance; they are not a whole-catalog speed comparison with an earlier run or a causal host-load measurement. The separately completed three-process latency records retain their own controls.

The export preserves all {export['preserved_assets']:,} previous immutable resources and adds {export['new_assets']} reachable assets with {export['active_export_and_index_hashes']} live export/index identities. Core numerical execution retains its original base `{freeze['base']}` and frozen candidate bytes. Application qualification executes on `{context['upstream']}`, rebased onto `{context['integration_base']}` with the 24 reviewed external UI paths preserved. Numerical runs are not relabeled after rebasing.

This is local qualification; main adoption is recorded separately when verified. Experimental WebGPU code is unchanged and does not provide a Torch GPU device. No CI, tag, publication or deployment was initiated.

## Concurrent notification UI integration

Main advanced by three notification/inbox/admin commits to `{integration['integration_base']}` while the original application gates ran. The 16 reviewed external paths change UI/docs and add one frontend check; dependencies, other scripts, compute/application inputs and seven release-policy files are unchanged. The locally qualified source/export commits were preserved at a checkpoint and rebased without conflicts. All 62 source resources, 79 library tests, 1,426 application inputs, 183 live exports and 15,319 prior immutable resources retain their qualified identities.

Complete frontend checks including the new review-notification check, both default/current Pages builds, asset-retention and release checks, exact worker regeneration and a fresh nested-page real Chrome judge run all pass on `{integration['execution_head']}`. The latter again passes 7/7 Attention tests and the explicit new API assertions. Numerical CPU/WASM and latency records retain their original execution bases and frozen bytes; no rerun on the rebased parent is claimed. No CI, tag, publication or deployment was initiated.

[Machine record](../../packages/stridetorch/benchmarks/results/iteration-79.json). [Raw evidence](../../packages/stridetorch/benchmarks/results/iteration-79-raw.tar.gz): {archive['bytes']:,} bytes, SHA-256 `{archive['sha256']}`.
'''
(repo/'docs/validation/torch-runtime-iteration-79.md').write_text(text)
shutil.copyfile(r/'benchmark.py',repo/'packages/stridetorch/benchmarks/bench_vector_matmul.py')
path=repo/'packages/stridetorch/benchmarks/README.md';old=path.read_text();marker='`bench_vector_matmul.py`'
assert marker not in old
paragraph='''`bench_vector_matmul.py` compares 98 warm float32/float64 flows, retaining
the batched Tensor/SDPA and original PaperLeet attention/GQA workloads and adding
tiny vector/matrix and empty forward/backward calls. Pass `--baseline-source`,
`--candidate-source`, `--fixtures benchmarks/fixtures/batched_attention`, and
`--output result.json`; use three fresh processes with `--cycle 0` through `2`.
A0/A1 are independent baseline imports and B is the candidate. Each flow checks
values/gradients, calibrates all variants to 100 ms targets, then uses their
maximum iteration count for three rotated batches. Check that every recorded
batch exceeds 20 ms. Source hashes and every sample are retained. `mv16` uses
the existing `@` route so an older baseline can execute it. No import, transfer,
native Torch, GPU or whole-application throughput is timed. See iteration 79
for the three-process CPU/Node/real Chrome results and measured regressions.

'''
path.write_text(old.replace('`bench_batched_matmul.py`',paragraph+'`bench_batched_matmul.py`',1))
print(json.dumps(dict(status='report_written',raw_sha256=archive['sha256'],benchmark_flows=98)),flush=True)
