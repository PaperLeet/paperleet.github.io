"""Archive explicit evidence only; never include runtimes, environments or test temps."""
from pathlib import Path
import gzip,hashlib,io,json,os,tarfile
root=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
gates=json.loads((root/'local-integration/gates-result.json').read_text());assert gates['status']=='passed'
assert json.loads((root/'local-integration/gate-progress.json').read_text())['status']=='completed'
assert json.loads((root/'local-integration/cpu-receipt.json').read_text())['status']=='passed'
assert json.loads((root/'core-node-result.json').read_text())['sdk']['passed']==11863
assert json.loads((root/'core-chrome-result.json').read_text())['sdk']['passed']==11863
assert json.loads((root/'rebased-ui/result.json').read_text())['status']=='passed'
assert json.loads((root/'integration-reconciliation.json').read_text())['status']=='rebased_ui_qualified'
assert json.loads((root/'qualification-review.json').read_text())['status']=='qualified_for_guarded_main_adoption'
allowed={p for p in root.iterdir() if p.is_file() and p.suffix in ['.py','.mjs','.json','.log','.html','.diff','.txt','.npz']}
for folder in ['entrypoint-baseline','candidate','baseline','prototype','prototype-results','prototype-v3-wasm','tests','core-tests','fixtures','main-integration/before-completion-cutoff','attempt-1-complex-json','attempt-2-runtime-metadata','attempt-3-forward-dispatch','attempt-4-forward-subclass','attempt-5-saved-storage','attempt-6-integration-script','attempt-7-core-fixture-path','attempt-8-mv-scalar-error','attempt-9-pre-fastpath','attempt-10-pre-geometry-cache']:
    allowed.update(p for p in (root/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
for folder in ['local-integration','main-integration','package-proof','rebased-ui']:
    if (root/folder).exists():allowed.update(p for p in (root/folder).iterdir() if p.is_file() and p.suffix in ['.py','.mjs','.json','.log','.txt','.diff'])
for folder in ['package-proof/dist','package-proof/app-dist','package-proof/sdist-rebuild/dist/wheels','package-proof/sdist-rebuild/app-dist/wheels']:
    if (root/folder).exists():allowed.update(p for p in (root/folder).iterdir() if p.is_file())
allowed={p for p in allowed if p.name not in ['archive-manifest.json','archive-verification.json']}
allowed={p for p in allowed if str(p.relative_to(root)) not in ['main-integration/qualified-git-blobs.json','main-integration/final-qualified-git-blobs.json','main-integration/source-qualified-git-blobs.json','main-integration/owned-files.json']}
note=root/'raw-evidence-README.txt'
note.write_text('Iteration 79 / candidate 0.77.0 evidence\n\nCore numerical execution used frozen candidate source bytes on base e64e88956d796f2d8bd06d3854257575fa4e9856. The source was subsequently committed and rebased onto separately reviewed UI changes. Core numerical runs are not relabeled as executions on a new parent. Application gate context records its actual execution head.\n\nNative Torch 2.6 controls cover dtype/empty dispatch, differential rules, saved-storage mutations, one-sided gradients and entry-point binding. Explicit existing unsupported operations are counted separately from matched cases. The selected source, tests and exact pinned Pyodide results identify final qualification. Prototype/attempt folders and their older results are diagnostic evidence, never substituted for final source qualification.\n\nLatency records retain all three fresh CPU/Node/Chrome processes, balanced A/A controls, calibration iterations and raw timings. Allocation probes run separately: native retained logical storage bytes and CPython tracemalloc allocations are different metrics and not RSS/VRAM comparisons. No new WebGPU support or native-Torch speed claim is made.\n\nBoth wheel/sdist pairs and actual rebuilt public/private wheels are retained. Environments, runtime binaries, pytest temporaries and extracted source trees are excluded. No package publication occurred.\n\nAll tar mtimes are zero; payloads, modes and owner metadata are verified independently. Deduplication requires both identical payload digest and identical mode/uid/gid/uname/gname.\n')
allowed.add(note)
allowed.update(p for p in (root/'local-integration/native-references').glob('*.json') if p.is_file())
allowed.update(p for p in (root/'selected-tests').glob('*.py') if p.is_file())
paths=sorted(allowed,key=lambda p:str(p.relative_to(root)))
manifest={};entries=[];unique={};regular=hardlinks=0
for path in paths:
    relative=str(path.relative_to(root));digest=hashlib.sha256(path.read_bytes()).hexdigest()
    with tarfile.open(fileobj=io.BytesIO(),mode='w') as temp:info=temp.gettarinfo(str(path),arcname=relative)
    assert info.isfile(),relative
    info.mtime=0
    info.mode &= 0o7777
    key=(digest,info.mode,info.uid,info.gid,info.uname,info.gname)
    manifest[relative]=dict(sha256=digest,size=info.size,mode=info.mode,uid=info.uid,gid=info.gid,uname=info.uname,gname=info.gname)
    if key in unique:
        info.type=tarfile.LNKTYPE;info.linkname=unique[key];info.size=0;hardlinks+=1
    else:unique[key]=relative;regular+=1
    entries.append((path,info))
manifest_path=root/'archive-manifest.json';manifest_path.write_text(json.dumps(dict(files=manifest,normalization='mtime=0; preserved mode and owner metadata; manifest itself is not self-hashed'),indent=2)+'\n')
archive=repo/'packages/stridetorch/benchmarks/results/iteration-79-raw.tar.gz'
with archive.open('wb') as output,gzip.GzipFile(fileobj=output,filename='',mode='wb',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
    for path,info in entries:
        if info.islnk():tar.addfile(info)
        else:
            with path.open('rb') as payload:tar.addfile(info,payload)
    info=tar.gettarinfo(str(manifest_path),arcname='archive-manifest.json');info.mtime=0;info.mode &= 0o7777
    manifest_metadata={field:getattr(info,field) for field in ['mode','uid','gid','uname','gname']}
    with manifest_path.open('rb') as payload:tar.addfile(info,payload)
with tarfile.open(archive,'r:gz') as tar:
    members={m.name:m for m in tar.getmembers()};assert len(members)==len(manifest)+1
    assert tar.extractfile('archive-manifest.json').read()==manifest_path.read_bytes()
    for field,value in manifest_metadata.items():assert getattr(members['archive-manifest.json'],field)==value,field
    for name,expected in manifest.items():
        actual=members[name];data=tar.extractfile(actual).read()
        assert hashlib.sha256(data).hexdigest()==expected['sha256'] and len(data)==expected['size'],name
        for field in ['mode','uid','gid','uname','gname']:assert getattr(actual,field)==expected[field],(name,field)
result=dict(status='verified',archive=str(archive),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size,logical_payloads=len(manifest)+1,unique_payloads=regular+1,hardlinks=hardlinks,all_logical_payloads_and_owner_modes_verified=True)
(root/'archive-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
