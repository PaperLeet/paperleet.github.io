from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).resolve().parent;p=r/'rebased-ui';repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
result=read(p/'result.json');assert result['status']=='passed' and read(p/'progress.json')['status']=='completed'
context=read(p/'context.json');assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==context['execution_head']
assert not subprocess.check_output(['git','status','--porcelain','-z'],cwd=repo)
for root,values in [(repo/'packages/stridetorch/src/stridetorch',context['source_hashes']),(repo/'packages/stridetorch/tests',read(r/'local-integration/test-inputs.json')),(repo,read(r/'local-integration/application-inputs.json')),(repo,read(p/'policy-identity.json')),(repo,read(r/'local-integration/immutable-assets.json')),(repo/'web/public/data',read(r/'local-integration/live-export-sha256.json')),(repo,read(p/'frontend-inputs.json')),(repo,context['external_inputs'])]:
 for n,h in values.items():assert sha(root/n)==h,n
for record in result['receipts']:assert record['exit_code']==0 and sha(p/(record['label']+'.log'))==record['log_sha256'],record['label']
worker=read(p/'generated-worker-proof.json');assert worker['inputs']==read(r/'local-integration/generated-worker-proof.json')['inputs'];assert sha(repo/worker['asset'])==worker['asset_sha256'] and sha(repo/worker['generated_module'])==worker['generated_module_sha256']
assert read(p/'nested-wasm-result.json')['status']=='passed'
integration=read(r/'integration-reconciliation.json');integration.update(status='rebased_ui_qualified',core_resources_unchanged=62,library_tests_unchanged=79,application_inputs_unchanged=1426,live_exports_unchanged=183,prior_immutable_resources_unchanged=15319,no_numeric_rerun_claimed=True)
(r/'integration-reconciliation.json').write_text(json.dumps(integration,indent=2)+'\n')
for name in ['source-hashes.json','live-export-sha256.json']:(r/'main-integration'/name).write_bytes((r/'local-integration'/name).read_bytes())
state=read(r/'state.json');state.update(status='077_qualified_with_latest_ui_pending_guarded_main_adoption',goal_status='active',previous_goal_turn_classification='progress',application_gates='passed',main_adopted=False,active_processes=[],local_candidate=context['execution_head'],integration_base=context['integration_base'],application_numeric_execution_head=read(r/'local-integration/context.json')['upstream'],ci_triggered=False,tags_created=False,published=False,deployed=False);state.pop('application_gate_process',None);state.pop('application_gate_label',None);(r/'state.json').write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps(dict(status=integration['status'],execution_head=context['execution_head'],external_paths=integration['external_paths'],source_resources_unchanged=62,no_numeric_rerun_claimed=True)),flush=True)
