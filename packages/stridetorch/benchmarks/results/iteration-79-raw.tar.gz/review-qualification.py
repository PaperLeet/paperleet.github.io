"""Audit this iteration's qualification without treating the long-term goal as done."""
from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
freeze=read(r/'core-source-freeze.json');core=read(r/'core-qualification.json');assert core['status']=='core_and_packaging_passed' and core['source_hashes']==freeze['source_hashes']
for n,h in freeze['source_hashes'].items():assert sha(repo/'packages/stridetorch/src/stridetorch'/n)==h,n
native_controls={}
for kind in ['node','chrome']:
 d=read(r/f'core-{kind}-result.json');assert d['status']=='passed' and d['prototype'] is False and d['sdk']['passed']==11863 and not d['sdk']['failures']
 assert all(c['differences']==0 and not c['failures'] for c in d['comparisons'])
 assert all(d[k]['differences']==0 and not d[k]['failures'] for k in ['one_sided','entrypoints','storage'])
 total=sum(c['cases'] for c in d['comparisons'])+sum(d[k]['cases'] for k in ['one_sided','entrypoints','storage']);assert total==11341
 unsupported=d['one_sided']['explicit_complex_autograd_boundaries']+d['storage']['explicit_unsupported_nonleaf_mutations']+len(d['entrypoints']['explicit_output_buffer_boundaries']);assert unsupported==262
 native_controls[kind]=dict(examined=total,matched=total-unsupported,explicit_existing_unsupported=unsupported)
assert read(r/'package-proof/result.json')['status']=='passed' and read(r/'package-proof/result.json')['source_hashes']==freeze['source_hashes']
assert read(r/'local-integration/gates-result.json')['status']=='passed' and read(r/'local-integration/evidence-verification.json')['status']=='verified'
assert read(r/'integration-reconciliation.json')['status']=='rebased_ui_qualified' and read(r/'rebased-ui/result.json')['status']=='passed'
performance=read(r/'performance-summary.json');assert performance['status']=='completed' and performance['source_hashes']==freeze['source_hashes']
accepted=[]
for kind,d in performance['runtimes'].items():
 assert d['fresh_processes']==3 and d['flows']==98 and d['batches']==2646 and d['minimum_batch_seconds']>=.02
 assert not d['consistent_regressions_over_10_percent']
 for key in d['consistent_regressions_over_5_percent']:
  assert key.endswith('_empty_mv_backward'),(kind,key)
  row=next(v for v in d['rows'] if v['key']==key);accepted.append(dict(runtime=kind,key=key,ratio=row['candidate_over_baseline_median'],reason='Empty-output contiguous strides and stricter product semantics add bookkeeping; the measured small-call cost is retained explicitly.'))
result=dict(status='qualified_for_guarded_main_adoption',version='0.77.0',goal_status='active',core_source_resources=len(freeze['source_hashes']),public_regressions_added=680,native_controls_each=native_controls,cpu_application_summary=read(r/'local-integration/cpu-receipt.json')['summary'],all_89_wasm_modules_and_406_mutants_within_budgets=True,three_fresh_latency_processes_each_cpu_node_chrome=True,accepted_measured_costs=accepted,core_stage_snapshot='core-qualification.json is the historical core/packaging-stage receipt; its remaining list predates the completed latency/application/UI receipts audited here.',rebased_ui_qualified=True,main_adopted=False,fresh_release_chain_audit_required=True,ci_triggered=False,tags_created=False,published=False,deployed=False)
(r/'qualification-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['core_stage_snapshot','accepted_measured_costs']}),flush=True)
