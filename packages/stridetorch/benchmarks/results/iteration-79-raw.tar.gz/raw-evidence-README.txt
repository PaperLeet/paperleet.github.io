Iteration 79 / candidate 0.77.0 evidence

Core numerical execution used frozen candidate source bytes on base e64e88956d796f2d8bd06d3854257575fa4e9856. The source was subsequently committed and rebased onto separately reviewed UI changes. Core numerical runs are not relabeled as executions on a new parent. Application gate context records its actual execution head.

Native Torch 2.6 controls cover dtype/empty dispatch, differential rules, saved-storage mutations, one-sided gradients and entry-point binding. Explicit existing unsupported operations are counted separately from matched cases. The selected source, tests and exact pinned Pyodide results identify final qualification. Prototype/attempt folders and their older results are diagnostic evidence, never substituted for final source qualification.

Latency records retain all three fresh CPU/Node/Chrome processes, balanced A/A controls, calibration iterations and raw timings. Allocation probes run separately: native retained logical storage bytes and CPython tracemalloc allocations are different metrics and not RSS/VRAM comparisons. No new WebGPU support or native-Torch speed claim is made.

Both wheel/sdist pairs and actual rebuilt public/private wheels are retained. Environments, runtime binaries, pytest temporaries and extracted source trees are excluded. No package publication occurred.

All tar mtimes are zero; payloads, modes and owner metadata are verified independently. Deduplication requires both identical payload digest and identical mode/uid/gid/uname/gname.
