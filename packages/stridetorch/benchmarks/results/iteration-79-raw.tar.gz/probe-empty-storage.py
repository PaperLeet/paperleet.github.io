from pathlib import Path
import hashlib,json,sys
import numpy as np
kind=sys.argv[1]
if kind=='native':
 import torch
 version=torch.__version__
else:
 import stridetorch
 from stridetorch import torch
 version=stridetorch.__version__
shapes=[((2,0),(0,)),((0,3),(3,)),((2,2,0),(0,)),((0,),(2,0,3)),((2,0),(2,0,3)),((0,3),(2,3,2)),((1,2,0),(3,0,2)),((3,2,0),(1,0,2)),((0,2,3),(1,3,2)),((1,2,3),(0,3,2)),((2,1,0,3),(1,3,3,2)),((2,1,2,3),(1,3,3,0))]
rows=[]
for sa,sb in shapes:
 for da,db in [('float32','float32'),('float32','float64')]:
  for ga,gb in [(True,False),(False,True),(True,True)]:
   for layout in ['C','F','stride']:
    for target in ['input','other','output','output_detached']:
     arrays=[np.ones(s,dtype=d) for s,d in [(sa,da),(sb,db)]]
     if layout=='F':arrays=[np.asfortranarray(a) for a in arrays]
     if layout=='stride':arrays=[np.ones((*s[:-1],s[-1]*2),dtype=d)[...,::2] for s,d in [(sa,da),(sb,db)]]
     a,b=[torch.from_numpy(z).requires_grad_(g) for z,g in zip(arrays,[ga,gb])];row=dict(shapes=[sa,sb],dtypes=[da,db],requires_grad=[ga,gb],layout=layout,target=target)
     try:y=torch.matmul(a,b)
     except Exception as e:row.update(forward_accepted=False,error=type(e).__name__,message=str(e));rows.append(row);continue
     row['forward_accepted']=True
     try:
      with torch.no_grad():{'input':a,'other':b,'output':y,'output_detached':y.detach()}[target].fill_(2)
      gradients=torch.autograd.grad(y,tuple(x for x in [a,b] if x.requires_grad),torch.ones_like(y));row.update(backward_accepted=True,gradients=[dict(shape=list(g.shape),dtype=str(g.detach().numpy().dtype),values=g.detach().numpy().tolist()) for g in gradients])
     except Exception as e:row.update(backward_accepted=False,error=type(e).__name__,message=str(e))
     rows.append(row)
result=dict(kind=kind,runtime_version=version,probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows);Path(__file__).with_name(kind+'-empty-storage.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(kind=kind,cases=len(rows),forward_accepted=sum(r['forward_accepted'] for r in rows))))
