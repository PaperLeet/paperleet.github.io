"""Independent metadata model for native 2.6 matmul's CPU dispatch boundary.

Reference: PyTorch v2.6.0 ATen/native/LinearAlgebra.cpp should_fold/_matmul_impl.
This model chooses only shape/dtype acceptance; it performs no numerical work.
"""
from dataclasses import dataclass,replace
import math

@dataclass(frozen=True)
class Operand:
    shape: tuple
    strides: tuple
    dtype: str
    requires_grad: bool=False
    subclass: bool=False
    @property
    def ndim(self):return len(self.shape)
    @property
    def numel(self):return math.prod(self.shape)
    def squeeze_batch(self):return replace(self,shape=self.shape[1:],strides=self.strides[1:])

def fold(a,b):
    large,small=(a,b) if a.ndim>=b.ndim else (b,a)
    if large.ndim<3 or small.ndim>2:return False
    if small.requires_grad:return True
    if a.ndim==2:return False
    if not large.numel:return True
    shape,strides=large.shape,large.strides
    if b.ndim>a.ndim:
        shape=(*shape[:-2],shape[-1],shape[-2]);strides=(*strides[:-2],strides[-1],strides[-2])
    return all(strides[i]==strides[i+1]*shape[i+1] for i in range(large.ndim-2))

def broadcast(a,b):
    size=max(len(a),len(b));a=(1,)*(size-len(a))+tuple(a);b=(1,)*(size-len(b))+tuple(b)
    result=[]
    for x,y in zip(a,b):
        if x==y:result.append(x)
        elif x==1:result.append(y)
        elif y==1:result.append(x)
        else:raise RuntimeError('incompatible batch dimensions')
    return tuple(result)

def infer(a,b):
    if not a.ndim or not b.ndim:raise RuntimeError('matmul requires at least 1D')
    if a.shape[-1]!=(b.shape[-2] if b.ndim>1 else b.shape[0]):raise RuntimeError('incompatible contraction dimensions')
    shape=broadcast(a.shape[:-2] if a.ndim>1 else (),b.shape[:-2] if b.ndim>1 else ())
    shape+=a.shape[-2:-1] if a.ndim>1 else ()
    shape+=b.shape[-1:] if b.ndim>1 else ()
    if a.ndim==b.ndim==1:mode='dot'
    elif a.ndim==2 and b.ndim==1:mode='mv'
    elif max(a.ndim,b.ndim)<=2:mode='mm'
    elif fold(a,b):mode='mv' if min(a.ndim,b.ndim)==1 else 'mm'
    else:
        if a.ndim==b.ndim==3 and a.shape[0]!=b.shape[0]:
            if a.shape[0]==1 and (a.requires_grad or a.subclass):return infer(a.squeeze_batch(),b)
            if b.shape[0]==1 and (b.requires_grad or b.subclass):return infer(a,b.squeeze_batch())
        mode='bmm'
    empty=not a.numel or not b.numel
    exceptional=a.dtype in ('bool','uint16','uint32','uint64')
    if mode=='dot' or mode=='mm' or not empty:
        if a.dtype!=b.dtype:raise RuntimeError('matching dtype required')
        if exceptional and (mode=='dot' or not empty):raise RuntimeError('CPU kernel unavailable for dtype')
        dtype=a.dtype
    else:
        dtype=(a.dtype if b.ndim>a.ndim else b.dtype) if mode=='mv' else b.dtype
    return dict(mode=mode,dtype=dtype,shape=list(shape))
