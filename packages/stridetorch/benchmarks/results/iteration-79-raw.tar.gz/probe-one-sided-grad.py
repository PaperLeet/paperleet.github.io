from pathlib import Path
import hashlib,json,sys,warnings
import numpy as np
kind=sys.argv[1]
if kind=='native':
 import torch
 version=torch.__version__
else:
 import stridetorch
 from stridetorch import torch
 version=stridetorch.__version__
pairs=[('float32','int64'),('int64','float64'),('float32','bool'),('bool','float64'),('float64','complex64'),('complex128','float32')]
def shapes(m,k,n):
 return [('vv',(k,),(k,)),('mv',(m,k),(k,)),('vm',(k,),(k,n)),('mm',(m,k),(k,n)),('bm_m',(2,m,k),(k,n)),('m_bm',(m,k),(2,k,n)),('bm_v',(2,m,k),(k,)),('v_bm',(k,),(2,k,n)),('same_bmm',(2,m,k),(2,k,n)),('left_one_batch',(1,m,k),(3,k,n)),('right_one_batch',(3,m,k),(1,k,n)),('broadcast4',(2,1,m,k),(1,3,k,n)),('left_zero_batch',(0,m,k),(1,k,n)),('right_zero_batch',(1,m,k),(0,k,n))]
def array(s,d,layout):
 if layout=='C':return np.ones(s,dtype=d)
 if layout=='F':return np.asfortranarray(np.ones(s,dtype=d))
 shape=(*s[:-1],s[-1]*2)
 return np.ones(shape,dtype=d)[...,::2]
rows=[]
with warnings.catch_warnings(record=True) as notices:
 warnings.simplefilter('always')
 for dims in [(2,3,2),(2,0,2),(0,3,2),(2,3,0),(0,0,0)]:
  for label,sa,sb in shapes(*dims):
   for da,db in pairs:
    states=[(ga,gb) for ga in ([False,True] if da.startswith('float') else [False]) for gb in ([False,True] if db.startswith('float') else [False])]
    for ga,gb in states:
     for layout in ['C','F','stride']:
      a,b=[torch.from_numpy(array(s,d,layout)).requires_grad_(g) for s,d,g in [(sa,da,ga),(sb,db,gb)]]
      row=dict(label=label,shapes=[sa,sb],dtypes=[da,db],requires_grad=[ga,gb],layout=layout,input_strides=[list(a.stride()),list(b.stride())])
      try:
       y=torch.matmul(a,b);v=y.detach().numpy();row.update(accepted=True,dtype=str(v.dtype),shape=list(v.shape),requires_grad_output=y.requires_grad,values=dict(real=v.real.tolist(),imag=v.imag.tolist()))
      except Exception as e:row.update(accepted=False,error=type(e).__name__,message=str(e))
      rows.append(row)
 result=dict(kind=kind,runtime_version=version,numpy_version=np.__version__,probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows,warnings=[str(n.message) for n in notices])
Path(__file__).with_name(kind+'-one-sided-grad.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(kind=kind,cases=len(rows),accepted=sum(r['accepted'] for r in rows),warnings=len(notices))))
