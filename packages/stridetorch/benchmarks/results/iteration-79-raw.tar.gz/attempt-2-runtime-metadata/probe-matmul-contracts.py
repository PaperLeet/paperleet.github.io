from pathlib import Path
import hashlib,json,sys,warnings
import numpy as np
kind=sys.argv[1]
if kind=='native':import torch
else:from stridetorch import torch
names=['bool','uint8','int8','int16','int32','int64','uint16','uint32','uint64','float16','float32','float64','complex64','complex128']
shapes=[('dot',(3,),(3,)),('dot',(0,),(0,)),('matmul',(3,),(3,)),('matmul',(0,),(0,)),('matmul',(2,3),(3,2)),('matmul',(2,0),(0,2)),('matmul',(0,3),(3,2)),('matmul',(2,2,3),(2,3,2)),('matmul',(2,2,0),(2,0,2)),('matmul',(0,2,3),(0,3,2)),('matmul',(2,1,2,3),(1,4,3,2)),('matmul',(2,1,2,0),(1,4,0,2))]
rows=[]
with warnings.catch_warnings(record=True) as notices:
 warnings.simplefilter('always')
 for op,sa,sb in shapes:
  for da in names:
   for db in names:
    row=dict(op=op,shapes=[sa,sb],dtypes=[da,db]);a,b=[torch.from_numpy(np.ones(s,dtype=d)) for s,d in [(sa,da),(sb,db)]]
    try:
     y=getattr(torch,op)(a,b);v=y.detach().numpy();row.update(accepted=True,dtype=str(v.dtype),shape=list(v.shape),values=dict(real=v.real.tolist(),imag=v.imag.tolist()))
    except Exception as e:row.update(accepted=False,error=type(e).__name__,message=str(e))
    rows.append(row)
 out=dict(kind=kind,torch_version=torch.__version__,numpy_version=np.__version__,probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows,warnings=[str(n.message) for n in notices])
Path(__file__).with_name(kind+'-matmul-contracts.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(kind=kind,cases=len(rows),accepted=sum(r['accepted'] for r in rows),warnings=len(notices))))
