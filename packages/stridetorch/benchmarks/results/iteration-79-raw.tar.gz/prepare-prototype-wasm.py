from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');files={};freeze=json.loads((r/'prototype-selected-v4-source.json').read_text())
for name,h in freeze['source_hashes'].items():
 p=r/'prototype/stridetorch'/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==h;files[str(p.relative_to(r))]=h
for name in ['probe-matmul-contracts.py','probe-empty-dispatch.py','probe-matmul-ad.py','native-matmul-contracts.json','native-empty-dispatch.json','native-matmul-ad.json','prototype-wasm-check.py','probe-empty-storage.py','native-empty-storage.json']:files[name]=hashlib.sha256((r/name).read_bytes()).hexdigest()
(r/'tests').mkdir(exist_ok=True)
for name in ['test_matrix_products.py','test_matmul_wasm.py','test_batched_matmul_wasm.py','test_matmul_saved_values.py']:
 target=r/'tests'/name;shutil.copyfile(repo/'packages/stridetorch/tests'/name,target);files['tests/'+name]=hashlib.sha256(target.read_bytes()).hexdigest()
(r/'prototype-wasm-plan.json').write_text(json.dumps(dict(files=files,expected_sdk=2453,expected_native_cases=7882,base=freeze['based_on'],scope='Unreleased prototype, version literal unchanged; not a replacement for qualified 0.76.'),indent=2)+'\n')
(r/'index.html').write_text('<!doctype html><title>Prototype matrix dispatch qualification</title>')
