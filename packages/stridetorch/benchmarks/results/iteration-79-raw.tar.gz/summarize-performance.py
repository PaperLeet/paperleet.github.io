"""Retain all flow ratios across three independent CPU/Node/Chrome processes."""
from pathlib import Path
import hashlib,json,math,statistics
r=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();freeze=read(r/'core-source-freeze.json')
assert read(r/'performance-progress.json')['status']=='completed'
geo=lambda values:math.exp(statistics.mean(math.log(x) for x in values))
out=dict(status='completed',version='0.77.0',baseline_version='0.76.0',source_hashes=freeze['source_hashes'],runtimes={},scope='Warm public Tensor/SDPA and original PaperLeet attention/GQA calls. Three fresh processes per runtime, three rotated batches per flow, 98 flows. A0/A1 are independent imports of identical baseline bytes; B is the candidate. Values and complete gradients checked before timing. Calibration targets 100 ms and every timed batch must exceed 20 ms. Excludes import, native Torch, transfer, GPU and whole-application speed claims.')
for kind in ['cpu','node','chrome']:
 records=[];by_key={};controls=[];batches=[];identities={}
 for cycle in range(3):
  file=r/f'latency-{kind}-{cycle}.json';raw=read(file);data=raw.get('report',raw)
  assert data['cycle']==cycle and len(data['rows'])==98
  assert data['source_hashes']['candidate']==freeze['source_hashes']
  assert data['source_hashes']['baseline']==freeze['baseline_source_hashes']
  identities[file.name]=sha(file);records.append(dict(cycle=cycle,python=data['python'],numpy=data['numpy'],platform=data['platform']))
  for row in data['rows']:
   by_key.setdefault(row['key'],[]).append(row)
   controls.append(row['control_over_baseline'])
   counts={s['iterations'] for samples in row['samples'].values() for s in samples};assert len(counts)==1
   batches.extend(s['elapsed_seconds'] for samples in row['samples'].values() for s in samples)
 assert min(batches)>=.02 and len(by_key)==98
 rows=[]
 for key,values in sorted(by_key.items()):
  assert len(values)==3
  ratios=[v['candidate_over_baseline'] for v in values];aa=[v['control_over_baseline'] for v in values]
  rows.append(dict(key=key,name=values[0]['name'],mode=values[0]['mode'],dtype=values[0]['dtype'],candidate_over_baseline_median=statistics.median(ratios),candidate_over_baseline_processes=ratios,AA_median=statistics.median(aa),AA_processes=aa,consistent_over_5_percent_regression=all(x>1.05 for x in ratios),consistent_over_10_percent_regression=all(x>1.10 for x in ratios)))
 groups={}
 for name,predicate in [('tiny_inference',lambda v:v['mode']=='forward' and v['name'] in ['tiny2d','dot8','mv16','vector_batch']),('empty_broadcast_backward',lambda v:v['mode']=='backward' and v['name']=='empty_broadcast'),('paperleet_attention_gqa',lambda v:v['name'].startswith('paper_')),('all_backward',lambda v:v['mode']=='backward'),('existing_78_flows',lambda v:v['name'] not in ['dot8','mv16','vector_batch','empty_mv','empty_broadcast'])]:
  values=[v['candidate_over_baseline_median'] for v in rows if predicate(v)]
  groups[name]=dict(flows=len(values),ratio_geomean=geo(values),ratio_min=min(values),ratio_max=max(values))
 result=dict(flows=len(rows),fresh_processes=3,batches=len(batches),minimum_batch_seconds=min(batches),AA_geomean=geo(controls),AA_min=min(controls),AA_max=max(controls),record_sha256=identities,records=records,groups=groups,rows=rows,consistent_regressions_over_5_percent=[v['key'] for v in rows if v['consistent_over_5_percent_regression']],consistent_regressions_over_10_percent=[v['key'] for v in rows if v['consistent_over_10_percent_regression']])
 out['runtimes'][kind]=result
(r/'performance-summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({kind:{k:v for k,v in value.items() if k in ['flows','fresh_processes','batches','minimum_batch_seconds','AA_geomean','groups','consistent_regressions_over_5_percent','consistent_regressions_over_10_percent']} for kind,value in out['runtimes'].items()},indent=2),flush=True)
