from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda p:json.loads(p.read_text());freeze=read(r/'core-source-freeze.json');plan=read(r/'performance-plan.json');receipts=[]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');env.pop('PYTHONPATH',None)
def verify():
 for n,h in freeze['source_hashes'].items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/n).read_bytes()).hexdigest()==h,n
 for n,h in plan['files'].items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
for cycle in range(3):
 for kind in ['cpu','node','chrome']:
  if cycle==0 and kind in ['node','chrome']:continue
  verify();output=r/f'latency-{kind}-{cycle}.json';assert not output.exists(),output
  if kind=='cpu':args=[str(r.parent/'torch-iteration-69/integration-dev-env/bin/python'),'-B',str(r/'benchmark.py'),'--baseline-source',str(r/'baseline/stridetorch'),'--candidate-source',str(r/'candidate/stridetorch'),'--fixtures',str(r/'fixtures'),'--cycle',str(cycle),'--output',str(output)]
  else:args=['/opt/homebrew/bin/node',str(r/f'bench-{kind}.mjs'),str(cycle)]
  log=r/f'latency-{kind}-{cycle}.log';start=time.monotonic()
  with log.open('w') as f:
   child=subprocess.Popen(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
   (r/'performance-progress.json').write_text(json.dumps(dict(status='running',kind=kind,cycle=cycle,pid=child.pid,command=args,receipts=receipts),indent=2)+'\n');code=child.wait()
  receipt=dict(runtime=kind,cycle=cycle,exit_code=code,seconds=time.monotonic()-start,command=args,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest());receipts.append(receipt);(r/'performance-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(receipt),flush=True);assert code==0,(kind,cycle)
  raw=read(output);data=raw.get('report',raw);assert len(data['rows'])==98 and data['source_hashes']['candidate']==freeze['source_hashes']
  assert min(s['elapsed_seconds'] for row in data['rows'] for samples in row['samples'].values() for s in samples)>=.02,(kind,cycle,'short batch')
  verify()
(r/'performance-progress.json').write_text(json.dumps(dict(status='completed',receipts=receipts),indent=2)+'\n');print('ALL PERFORMANCE PROCESSES COMPLETED',flush=True)
