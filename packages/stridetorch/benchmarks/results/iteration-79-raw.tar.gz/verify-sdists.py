from pathlib import Path
import hashlib,json,os,subprocess,tarfile,time,zipfile
root=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');p=root/'package-proof';expected=json.loads((root/'core-source-freeze.json').read_text())['source_hashes'];rows=[]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONPATH',None)
for folder,prefix,wheel_prefix in [('dist','src/stridetorch/','stridetorch/'),('app-dist','packages/stridetorch/src/stridetorch/','paperleet/_vendor/torch/')]:
    archive=next((p/folder).glob('*.tar.gz'));target=p/'sdist-rebuild'/folder;target.mkdir(parents=True,exist_ok=True)
    with tarfile.open(archive,'r:gz') as tar:
        found={m.name.split('/',1)[1][len(prefix):]:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar.getmembers() if m.isfile() and '/' in m.name and m.name.split('/',1)[1].startswith(prefix)}
        assert found==expected,(folder,sorted(set(found)^set(expected)))
        readme=next(m for m in tar.getmembers() if m.name.endswith('/README.md') and len(m.name.split('/'))==2)
        actual=repo/'packages/stridetorch/README.md' if folder=='dist' else repo/'README.md';assert tar.extractfile(readme).read()==actual.read_bytes()
        tar.extractall(target,filter='data')
    source=next(q for q in target.iterdir() if q.is_dir());out=target/'wheels'
    command=['/Users/david/.local/bin/uv','build','--wheel','--no-build-isolation','--python',str(root.parent/'torch-iteration-69/integration-dev-env/bin/python'),'--out-dir',str(out),str(source)];start=time.monotonic()
    with (p/(folder+'-sdist-rebuild.log')).open('w') as log:child=subprocess.run(command,env=env,cwd=root,stdout=log,stderr=subprocess.STDOUT)
    child.check_returncode();wheel=next(out.glob('*.whl'))
    with zipfile.ZipFile(wheel) as z:actual={n[len(wheel_prefix):]:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith(wheel_prefix)}
    assert actual==expected
    rows.append(dict(archive=str(archive.relative_to(root)),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),source_prefix=prefix,source_resources=len(found),readme_exact=True,rebuild_command=command,rebuild_exit=0,seconds=time.monotonic()-start,rebuilt_wheel=str(wheel.relative_to(root)),rebuilt_wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),rebuilt_source_resources=len(actual)))
(p/'sdist-identities.json').write_text(json.dumps(dict(status='passed',rows=rows),indent=2)+'\n');print('Both source archives rebuild to wheels with exact selected code and notices.',flush=True)
