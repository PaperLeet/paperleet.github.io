from pathlib import Path
import hashlib,json,sys
import numpy as np
kind=sys.argv[1]
if kind.startswith('native'):
 import torch
 version=torch.__version__
else:
 import stridetorch
 from stridetorch import torch
 version=stridetorch.__version__
a=torch.from_numpy(np.arange(6,dtype='float32').reshape(2,3));b=torch.from_numpy(np.arange(6,dtype='float32').reshape(3,2));v=torch.from_numpy(np.arange(3,dtype='float32'));w=torch.ones(3);out={}
for op,lhs,rhs,correct in [('matmul',a,b,'other'),('dot',v,w,'tensor'),('mv',a,v,'vec')]:
 f=lambda *args,**kw:getattr(torch,op)(*args,**kw)
 method=lambda *args,**kw:getattr(lhs,op)(*args,**kw)
 cases=[('root-pos',lambda:f(lhs,rhs)),('root-keyword',lambda:f(input=lhs,**{correct:rhs})),('root-none-out',lambda:f(lhs,rhs,out=None)),('root-tensor-out',lambda:f(lhs,rhs,out=torch.empty(2,2) if op=='matmul' else torch.empty(2) if op=='mv' else torch.empty(()))),('root-input-array',lambda:f(lhs.numpy(),rhs)),('root-other-array',lambda:f(lhs,rhs.numpy())),('root-input-list',lambda:f(lhs.numpy().tolist(),rhs)),('root-input-scalar',lambda:f(2,rhs)),('root-other-list',lambda:f(lhs,rhs.numpy().tolist())),('root-scalar-tensor',lambda:f(torch.tensor(2.),rhs)),('root-extra-pos',lambda:f(lhs,rhs,None)),('root-missing',lambda:f(lhs)),('method-pos',lambda:method(rhs)),('method-keyword-other',lambda:method(other=rhs)),('method-keyword-tensor',lambda:method(tensor=rhs)),('method-keyword-vec',lambda:method(vec=rhs)),('method-none-out',lambda:method(rhs,out=None)),('method-tensor-out',lambda:method(rhs,out=torch.empty(2,2))),('method-other-array',lambda:method(rhs.numpy())),('method-extra-pos',lambda:method(rhs,None)),('method-unbound-input-array',lambda:getattr(torch.Tensor,op)(lhs.numpy(),rhs))]
 if op=='dot':cases.extend([('root-keyword-other',lambda:f(input=lhs,other=rhs)),('root-keyword-vec',lambda:f(input=lhs,vec=rhs))])
 for label,call in cases:
  row=dict(op=op,case=label)
  try:
   y=call();z=y.detach().numpy();row.update(accepted=True,dtype=str(z.dtype),shape=list(z.shape),values=z.tolist())
  except Exception as e:row.update(accepted=False,error=type(e).__name__,message=str(e))
  out[op+'/'+label]=row
for label,call in [('dunder-list',lambda:a.__matmul__(b.numpy().tolist())),('dunder-array',lambda:a.__matmul__(b.numpy())),('operator-array',lambda:a@b.numpy()),('dunder-number',lambda:a.__matmul__(2)),('dunder-unbound-array',lambda:torch.Tensor.__matmul__(a.numpy(),b))]:
 row=dict(op='operator',case=label)
 try:
  y=call()
  if y is NotImplemented:row.update(accepted=True,value='NotImplemented')
  else:
   z=y.detach().numpy();row.update(accepted=True,dtype=str(z.dtype),shape=list(z.shape),values=z.tolist())
 except Exception as e:row.update(accepted=False,error=type(e).__name__,message=str(e))
 out['operator/'+label]=row
result=dict(kind=kind,runtime_version=version,probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cases=out);Path(__file__).with_name(kind+'-matrix-entrypoints.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(kind=kind,cases=len(out),accepted=sum(v['accepted'] for v in out.values()))))
