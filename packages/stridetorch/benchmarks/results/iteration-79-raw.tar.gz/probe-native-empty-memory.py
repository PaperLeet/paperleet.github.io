from pathlib import Path
import hashlib,json,sys
import torch
shape_a=(32,1,0,128);shape_b=(1,8,128,256)
a=torch.ones(shape_a,dtype=torch.float32,requires_grad=True);b=torch.ones(shape_b,dtype=torch.float64);y=torch.matmul(a,b)
queue=[y.grad_fn];seen=set();saved=[];keepalive=[]
while queue:
 node=queue.pop()
 if node is None or id(node) in seen:continue
 seen.add(id(node));keepalive.append(node)
 for key in dir(node):
  if key.startswith('_saved_'):
   try:value=getattr(node,key)
   except (RuntimeError,AttributeError):continue
   if isinstance(value,torch.Tensor):
    saved.append(dict(node=type(node).__name__,attribute=key,shape=list(value.shape),dtype=str(value.dtype),storage_bytes=value.untyped_storage().nbytes(),shares_original_a_storage=value.untyped_storage().data_ptr()==a.untyped_storage().data_ptr(),shares_original_b_storage=value.untyped_storage().data_ptr()==b.untyped_storage().data_ptr()))
 queue.extend(item[0] for item in node.next_functions)
result=dict(status='observed_native_saved_storage',torch=torch.__version__,python=sys.version,shape_a=shape_a,shape_b=shape_b,output_shape=list(y.shape),input_b_storage_bytes=b.untyped_storage().nbytes(),saved=saved,probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Read native autograd saved tensor storage sizes; this is retained logical storage, not process RSS or device VRAM.')
Path(__file__).with_name('native-empty-memory-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
