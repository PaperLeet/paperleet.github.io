"""Freeze current application inputs after latency children have terminated."""
from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;p=r/'local-integration';repo=Path('/Users/david/Developer/PaperLeet-torch-release');old=r.parent/'torch-iteration-78'
read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
assert read(r/'performance-progress.json')['status']=='completed'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head==read(r/'upstream-ui-reconciliation.json')['local_candidate']
assert not subprocess.check_output(['git','status','--porcelain','-z'],cwd=repo)
assert read(r/'core-qualification.json')['status']=='core_and_packaging_passed'
p.mkdir(exist_ok=False)
source=read(r/'core-source-freeze.json')['source_hashes']
for n,h in source.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/n)==h,n
tests={q.name:sha(q) for q in (repo/'packages/stridetorch/tests').glob('*.py')};assert len(tests)==79
assert tests==read(r/'core-source-freeze.json')['tests']
application={n:sha(repo/n) for n in read(old/'local-integration/application-inputs.json')}
assert application==read(old/'local-integration/application-inputs.json')
policy=read(old/'main-integration/release-policy-identity.json')['files']
for n,h in policy.items():assert sha(repo/n)==h,n
assets={str(q.relative_to(repo)):sha(q) for d in ['browser-judge','modules'] for q in (repo/'web/public/data'/d).glob('*.json')}
entries=subprocess.check_output(['git','ls-tree','-r','-z',head,'--','web/public/data/browser-judge','web/public/data/modules'],cwd=repo)
(p/'immutable-tree.txt').write_bytes(entries)
context=dict(upstream=head,integration_base=read(r/'upstream-ui-reconciliation.json')['integration_base'],original_numeric_execution_base=read(r/'core-source-freeze.json')['base'],source_hashes=source,catalog_modules=len(read(repo/'web/public/data/index.json')['problems']),preserved_assets=len(assets))
for name,value in [('context',context),('source-hashes',source),('test-inputs',tests),('application-inputs',application),('policy-identity',policy),('immutable-assets',assets)]:
 (p/(name+'.json')).write_text(json.dumps(value,indent=2)+'\n')
for name in ['run-cpu.py','verify-export.py']:shutil.copyfile(old/'local-integration'/name,p/name)
shutil.copyfile(old/'recovery-ui/verify-generated-worker.mjs',p/'verify-generated-worker.mjs')
script=(old/'recovery-ui/check-nested-wasm.mjs').read_text().replace('v076','v077').replace("0.76.0","0.77.0")
script=script.replace('del _pl_a, _pl_empty', '''_pl_v = torch.ones(3, requires_grad=True)
torch.mv(input=torch.ones(2, 3), vec=_pl_v).sum().backward()
assert _pl_v.grad.tolist() == [2.0] * 3
assert torch.ones(3).dot(torch.ones(3)).item() == 3.0
assert torch.ones(2, 3).matmul(torch.ones(3, 4)).sum().item() == 24.0
del _pl_a, _pl_empty, _pl_v''')
script=script.replace('explicit mm/bmm/empty-dtype assertions','explicit mm/bmm/mv/dot/matmul and empty-dtype assertions')
(p/'check-nested-wasm.mjs').write_text(script)
print(json.dumps(dict(status='application_inputs_frozen',execution_head=head,source_resources=len(source),test_files=len(tests),application_files=len(application),preserved_assets=len(assets),catalog_modules=context['catalog_modules'])),flush=True)
