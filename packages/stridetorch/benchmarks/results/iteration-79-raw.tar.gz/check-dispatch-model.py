from pathlib import Path
import hashlib,importlib.util,json
r=Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('dispatch_model',r/'dispatch-model.py');m=importlib.util.module_from_spec(s);import sys;sys.modules[s.name]=m;s.loader.exec_module(m)
native=json.loads((r/'native-empty-dispatch.json').read_text());failures=[];modes={}
for row in native['rows']:
    operands=[m.Operand(tuple(sh),tuple(st),dt,g) for sh,st,dt,g in zip(row['shapes'],row['input_strides'],row['dtypes'],row['requires_grad'])]
    try:predicted=dict(accepted=True,**m.infer(*operands))
    except RuntimeError as e:predicted=dict(accepted=False,error=str(e))
    if predicted['accepted']!=row['accepted'] or predicted['accepted'] and any(predicted[k]!=row[k] for k in ['shape','dtype']):failures.append(dict(observed=row,predicted=predicted))
    if predicted['accepted']:modes[predicted['mode']]=modes.get(predicted['mode'],0)+1
result=dict(status='passed' if not failures else 'failed',cases=len(native['rows']),mismatches=len(failures),failures=failures,modes=modes,model_sha256=hashlib.sha256((r/'dispatch-model.py').read_bytes()).hexdigest(),native_record_sha256=hashlib.sha256((r/'native-empty-dispatch.json').read_bytes()).hexdigest(),reference='https://raw.githubusercontent.com/pytorch/pytorch/v2.6.0/aten/src/ATen/native/LinearAlgebra.cpp',scope='Plain and requires_grad metadata model only; inference values, AD channels, mutation guards, allocation and real WASM need separate qualification.')
(r/'dispatch-model-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='failures'}));assert not failures
