import json,os,runpy,sys
from pathlib import Path
import stridetorch
assert stridetorch.__version__ == '0.77.0'
from stridetorch import _tensor
assert _tensor._WASM_MATMUL
os.chdir('/checks');comparisons=[]
for script,suffix in [('probe-matmul-contracts.py','matmul-contracts'),('probe-empty-dispatch.py','empty-dispatch'),('probe-matmul-ad.py','matmul-ad')]:
 sys.argv=[script,'candidate'];runpy.run_path('/checks/'+script,run_name='__main__')
 native=json.loads(Path('/controls/native-'+suffix+'.json').read_text());actual=json.loads(Path('/checks/candidate-'+suffix+'.json').read_text());assert native['probe_sha256']==actual['probe_sha256'];assert len(native['rows'])==len(actual['rows']);failures=[]
 for a,b in zip(native['rows'],actual['rows']):
  keys=['op','label','shapes','dtypes','requires_grad','layout','channel']
  assert all(a.get(k)==b.get(k) for k in keys)
  different=a['accepted']!=b['accepted']
  if a['accepted'] and b['accepted']:
   different|=any(a.get(k)!=b.get(k) for k in ['dtype','shape','values','requires_grad_output','result'])
  if different:failures.append(dict(native=a,actual=b))
 comparisons.append(dict(suite=suffix,cases=len(native['rows']),differences=len(failures),failures=failures))
sys.argv=['probe-empty-storage.py','candidate'];runpy.run_path('/checks/probe-empty-storage.py',run_name='__main__')
native=json.loads(Path('/controls/native-empty-storage.json').read_text());actual=json.loads(Path('/checks/candidate-empty-storage.json').read_text());assert native['probe_sha256']==actual['probe_sha256'];storage_failures=[];explicit_unsupported=[]
for a,b in zip(native['rows'],actual['rows']):
 assert all(a[k]==b[k] for k in ['shapes','dtypes','requires_grad','layout','target'])
 if a['target']=='output' and a['forward_accepted']:
  if b.get('error')=='BrowserUnsupported' and 'non-leaf' in b.get('message',''):explicit_unsupported.append(dict(native=a,actual=b));continue
 different=a['forward_accepted']!=b['forward_accepted'] or a['forward_accepted'] and any(a.get(k)!=b.get(k) for k in ['backward_accepted','gradients'])
 if different:storage_failures.append(dict(native=a,actual=b))
storage=dict(cases=len(native['rows']),differences=len(storage_failures),failures=storage_failures,explicit_unsupported_nonleaf_mutations=len(explicit_unsupported),matched_supported_or_rejected_cases=len(native['rows'])-len(explicit_unsupported))
one_native=json.loads(Path('/controls/native-one-sided-grad.json').read_text());sys.argv=['probe-one-sided-grad.py','candidate'];runpy.run_path('/checks/probe-one-sided-grad.py',run_name='__main__');one_actual=json.loads(Path('/checks/candidate-one-sided-grad.json').read_text());assert one_native['probe_sha256']==one_actual['probe_sha256'];one_failures=[];complex_boundary=[]
for a,b in zip(one_native['rows'],one_actual['rows']):
 different=a['accepted']!=b['accepted'] or a['accepted'] and any(a.get(k)!=b.get(k) for k in ['dtype','shape','values','requires_grad_output'])
 if different:
  if a['accepted'] and b.get('error')=='BrowserUnsupported' and 'Complex autograd' in b.get('message',''):complex_boundary.append(dict(native=a,actual=b))
  else:one_failures.append(dict(native=a,actual=b))
one_sided=dict(cases=len(one_native['rows']),differences=len(one_failures),failures=one_failures,explicit_complex_autograd_boundaries=len(complex_boundary))
sys.argv=['probe-matrix-entrypoints.py','candidate'];runpy.run_path('/checks/probe-matrix-entrypoints.py',run_name='__main__');entry_native=json.loads(Path('/controls/native26-matrix-entrypoints.json').read_text());entry_actual=json.loads(Path('/checks/candidate-matrix-entrypoints.json').read_text());assert entry_native['probe_sha256']==entry_actual['probe_sha256'];entry_failures=[];out_boundaries=[]
for k,a in entry_native['cases'].items():
 b=entry_actual['cases'][k];different=a['accepted']!=b['accepted'] or a['accepted'] and any(a.get(f)!=b.get(f) for f in ['value','dtype','shape','values']) or not a['accepted'] and a.get('error')!=b.get('error')
 if different:
  if k.endswith('/root-tensor-out') and b.get('error')=='BrowserUnsupported':out_boundaries.append(k)
  else:entry_failures.append(dict(case=k,native=a,actual=b))
entrypoints=dict(cases=len(entry_native['cases']),differences=len(entry_failures),failures=entry_failures,explicit_output_buffer_boundaries=out_boundaries)
import pytest
class Record:
 def __init__(self):self.passed=0;self.failures=[]
 def pytest_runtest_logreport(self,report):
  if report.when=='call' and report.passed:self.passed+=1
  if report.failed:self.failures.append(dict(test=report.nodeid,error=str(report.longrepr)[-2000:]))
record=Record();code=pytest.main(['/contracts','-q','--noconftest','-p','no:cacheprovider','--import-mode=importlib'],plugins=[record])
wasm_report=dict(status='passed' if code==0 and not any(c['differences'] for c in comparisons) and not storage_failures and len(explicit_unsupported)==180 and not one_failures and len(complex_boundary)==79 and not entry_failures and len(out_boundaries)==3 else 'failed',implementation_version_literal=stridetorch.__version__,prototype=False,one_sided=one_sided,entrypoints=entrypoints,storage=storage,comparisons=comparisons,sdk=dict(passed=record.passed,exit_code=int(code),failures=record.failures))
