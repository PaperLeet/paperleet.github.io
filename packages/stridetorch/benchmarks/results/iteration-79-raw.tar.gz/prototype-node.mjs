import fs from 'node:fs';import assert from 'node:assert/strict';import{createHash}from'node:crypto';
import{loadPyodide}from'../torch-iteration-76/runtime/pyodide.mjs';
import{loadJudgePackages}from'../torch-iteration-76/chrome-sdk/packages.mjs';
const root=new URL('./',import.meta.url),plan=JSON.parse(fs.readFileSync(new URL('prototype-wasm-plan.json',root)));
const py=await loadPyodide({indexURL:new URL('../torch-iteration-76/runtime/',root).pathname,stdout(){},stderr(){}});await loadJudgePackages(py,[]);
for(const[name,digest]of Object.entries(plan.files)){
 const bytes=fs.readFileSync(new URL(name,root));assert.equal(createHash('sha256').update(bytes).digest('hex'),digest);
 const target=name.startsWith('prototype/')?'/'+name:name.startsWith('tests/')?'/contracts/'+name.slice(6):name.startsWith('native-')?'/controls/'+name:'/checks/'+name;
 py.FS.mkdirTree(target.split('/').slice(0,-1).join('/'));py.FS.writeFile(target,bytes);
}
py.runPython("import sys\nsys.path.insert(0,'/prototype')");py.runPython("exec(compile(open('/checks/prototype-wasm-check.py').read(),'/checks/prototype-wasm-check.py','exec'))");
const result={...JSON.parse(py.runPython('json.dumps(wasm_report)')),files:plan.files,pyodide:py.version,node:process.version};fs.writeFileSync(new URL('prototype-node-result.json',root),JSON.stringify(result,null,2)+'\n');
assert.equal(result.status,'passed',JSON.stringify(result.sdk.failures));assert.equal(result.sdk.passed,plan.expected_sdk);assert.equal(result.comparisons.reduce((n,c)=>n+c.cases,0),plan.expected_native_cases);
console.log(JSON.stringify({status:result.status,comparisons:result.comparisons.map(({failures,...c})=>c),sdk:result.sdk,pyodide:result.pyodide}));
