"""Preserve qualified exports, review upstream-only UI, then rebase local commits."""
from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;p=r/'rebased-ui';repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=repo)
assert read(r/'local-integration/gates-result.json')['status']=='passed'
assert read(r/'local-integration/evidence-verification.json')['status']=='verified'
old='f2540530bfc7ccf71d3ac9b0a77eafd6052560f5';new='1535c6bc492726119ef10afc850bf7b52bcc0cfd';head=git('rev-parse','HEAD').decode().strip();assert head=='b4b06237893fbdfe70efd3afbf0ee38b8b7cb4fe'
names=[n for n in git('diff','--name-only','-z',old,new).decode().split('\0') if n];assert len(names)==16
assert all(n.startswith(('web/src/','web/scripts/','docs/')) or n=='web/package.json' for n in names)
a=json.loads(git('show',old+':web/package.json'));b=json.loads(git('show',new+':web/package.json'));sa=a.pop('scripts');sb=b.pop('scripts');assert a==b and set(sa)==set(sb)
for k in sa:
 if k!='check':assert sa[k]==sb[k]
before=sa['check'].split(' && ');after=sb['check'].split(' && ');assert [n for n in after if n in before]==before
added=[n for n in after if n not in before];assert added==['node scripts/check-review-notifications.mjs']
policy=read(r/'main-integration/release-policy-identity.json')['files']
for name,digest in policy.items():assert hashlib.sha256(git('show',new+':'+name)).hexdigest()==digest,name
source_owned={n for n in git('diff','--name-only','-z',old,head).decode().split('\0') if n};assert len(source_owned)==9 and all(n.startswith('packages/stridetorch/') for n in source_owned)
exports=set(read(r/'local-integration/new-assets-sha256.json'));exports.update('web/public/data/'+n for n in ['index.json','index-v3.json','catalog.json'])
entries=[n for n in git('status','--porcelain','-z','--untracked-files=all').decode().split('\0') if n];assert {n[3:] for n in entries}==exports and all(n[:2] in [' M','??'] for n in entries)
for root,values in [(repo/'packages/stridetorch/src/stridetorch',read(r/'core-source-freeze.json')['source_hashes']),(repo/'packages/stridetorch/tests',read(r/'local-integration/test-inputs.json')),(repo,read(r/'local-integration/application-inputs.json')),(repo,read(r/'local-integration/immutable-assets.json')),(repo/'web/public/data',read(r/'local-integration/live-export-sha256.json'))]:
 for n,h in values.items():assert sha(root/n)==h,n
p.mkdir(exist_ok=False);(p/'upstream.diff').write_bytes(git('diff',old,new));(r/'source-owned-paths.json').write_text(json.dumps(sorted(source_owned),indent=2)+'\n')
paths=p/'export-paths.txt';paths.write_bytes(b'\0'.join(n.encode() for n in sorted(exports))+b'\0');git('diff','--check')
subprocess.run(['git','add','--pathspec-from-file='+str(paths),'--pathspec-file-nul'],cwd=repo,check=True);assert {n for n in git('diff','--cached','--name-only','-z').decode().split('\0') if n}==exports
subprocess.run(['git','commit','-m','Qualify 0.77 browser bundles against complete local application gates'],cwd=repo,check=True)
qualified=git('rev-parse','HEAD').decode().strip();subprocess.run(['git','update-ref','refs/codex/checkpoints/torch-iteration-79-before-notification-ui',qualified],cwd=repo,check=True)
subprocess.run(['git','rebase','--onto',new,old],cwd=repo,check=True);head=git('rev-parse','HEAD').decode().strip();assert not git('status','--porcelain','-z')
context=dict(execution_head=head,integration_base=new,previous_integration_base=old,original_numeric_execution_base=read(r/'local-integration/context.json')['upstream'],original_core_numeric_execution_base=read(r/'core-source-freeze.json')['base'],pre_rebase_qualified_commit=qualified,source_hashes=read(r/'core-source-freeze.json')['source_hashes'],external_inputs={n:sha(repo/n) for n in names},combined_owned_paths=len(source_owned|exports),added_check_commands=added)
(p/'context.json').write_text(json.dumps(context,indent=2)+'\n');(p/'policy-identity.json').write_text(json.dumps(policy,indent=2)+'\n')
for name in ['verify-generated-worker.mjs','check-nested-wasm.mjs']:shutil.copyfile(r/'local-integration'/name,p/name)
script=(r.parent/'torch-iteration-78/recovery-ui/run-checks.py').read_text()
script=script.replace("verify();result=dict(status='passed'", "run('nested-wasm',[node,str(p/'check-nested-wasm.mjs')])\nverify();result=dict(status='passed'")
(p/'run-checks.py').write_text(script)
(r/'integration-reconciliation.json').write_text(json.dumps(dict(status='rebased_ui_qualification_pending',execution_head=head,integration_base=new,previous_integration_base=old,pre_rebase_qualified_commit=qualified,source_owned_paths=sorted(source_owned),external_paths=len(names),added_check_commands=added),indent=2)+'\n')
print(json.dumps(dict(status='reviewed_and_rebased',head=head,integration_base=new,external_paths=len(names),added_check_commands=added,qualified_source_and_exports_unchanged=True)),flush=True)
