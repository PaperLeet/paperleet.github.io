"""Stage exactly the locally qualified iteration; no network mutations."""
from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;p=r/'main-integration';repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
context=read(r/'local-integration/context.json');integration=read(r/'integration-reconciliation.json');assert integration['status']=='rebased_ui_qualified'
assert git('rev-parse','HEAD').decode().strip()==integration['execution_head']
assert read(r/'rebased-ui/result.json')['status']=='passed'
assert read(r/'qualification-review.json')['status']=='qualified_for_guarded_main_adoption'
assert read(r/'local-integration/gates-result.json')['status']=='passed'
assert read(r/'performance-summary.json')['status']=='completed'
assert read(r/'archive-verification.json')['status']=='verified'
for name,digest in read(r/'runtime-identity.json')['files'].items():assert sha(repo/name)==digest,name
profile=read(r/'rebased-ui/pages-profile.json')
value=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED','--jq','.value'],cwd=repo,text=True).strip()
assert profile['PAPERLEET_MAIN_SITE_ENABLED']==value
public=read(repo/'packages/stridetorch/benchmarks/results/iteration-79.json')
assert public['raw_archive']['sha256']==sha(repo/'packages/stridetorch/benchmarks/results/iteration-79-raw.tar.gz')
source=read(r/'core-source-freeze.json')['source_hashes']
for n,h in source.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/n)==h,n
base=integration['integration_base'];initial={n for n in git('diff','--name-only','-z',base,'HEAD').decode().split('\0') if n}
source_owned=set(read(r/'source-owned-paths.json'));assert len(source_owned)==9
exports=set(read(r/'local-integration/new-assets-sha256.json'));exports.update('web/public/data/'+n for n in ['index.json','index-v3.json','catalog.json'])
assert initial==source_owned|exports
new=set(['docs/validation/torch-runtime-iteration-79.md','packages/stridetorch/benchmarks/results/iteration-79.json','packages/stridetorch/benchmarks/results/iteration-79-raw.tar.gz','packages/stridetorch/benchmarks/bench_vector_matmul.py','packages/stridetorch/benchmarks/README.md'])
entries=[v for v in git('status','--porcelain','-z','--untracked-files=all').decode().split('\0') if v]
actual={v[3:] for v in entries};assert actual==new,(sorted(actual-new),sorted(new-actual));assert all(v[:2] in [' M','??'] for v in entries)
owned=initial|new
for name in ['source-hashes.json','live-export-sha256.json']:shutil.copyfile(r/'local-integration'/name,p/name)
frontend=read(r/'rebased-ui/frontend-inputs.json')
for n,h in frontend.items():assert sha(repo/n)==h,n
for n,h in read(r/'rebased-ui/context.json')['external_inputs'].items():assert sha(repo/n)==h,n
qualified={n:sha(repo/n) for n in read(r/'local-integration/application-inputs.json')}
qualified.update({'packages/stridetorch/src/stridetorch/'+n:h for n,h in source.items()})
qualified.update({'packages/stridetorch/tests/'+n:h for n,h in read(r/'local-integration/test-inputs.json').items()})
qualified.update({'web/public/data/'+n:h for n,h in read(p/'live-export-sha256.json').items()})
qualified.update(frontend);qualified.update(read(p/'release-policy-identity.json')['files']);qualified.update({n:sha(repo/n) for n in owned})
qualified.update({n:sha(repo/n) for n in git('ls-files','-z','--','.github/workflows').decode().split('\0') if n})
(p/'qualified-git-blobs.json').write_text(json.dumps(qualified,indent=2)+'\n')
(p/'owned-files.json').write_text(json.dumps({n:sha(repo/n) for n in owned},indent=2)+'\n')
(p/'integration-context.json').write_text(json.dumps(dict(ownership_base=base,approved_owned_paths=sorted(owned),original_numeric_execution_base=context['original_numeric_execution_base'],application_execution_head=context['upstream'],rebased_frontend_execution_head=integration['execution_head']),indent=2)+'\n')
before={row.split(b'\t',1)[1]:row.split(b'\t',1)[0] for row in (r/'local-integration/immutable-tree.txt').read_bytes().split(b'\0') if row}
now={row.split(b'\t',1)[1]:row.split(b'\t',1)[0] for row in git('ls-tree','-r','-z','HEAD','--','web/public/data/browser-judge','web/public/data/modules').split(b'\0') if row}
assert all(now[n]==value for n,value in before.items())
git('diff','--check');paths=p/'owned-paths.txt';paths.write_bytes(b'\0'.join(n.encode() for n in sorted(new))+b'\0')
subprocess.run(['git','add','--pathspec-from-file='+str(paths),'--pathspec-file-nul'],cwd=repo,check=True)
staged={n for n in git('diff','--cached','--name-only','-z').decode().split('\0') if n};assert staged==new
git('diff','--cached','--check')
print(json.dumps(dict(status='ready_to_commit',qualified_git_blobs=len(qualified),owned_paths=len(owned),newly_staged_paths=len(new),prior_immutable_entries_preserved=len(before))),flush=True)
