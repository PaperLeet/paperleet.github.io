import fs from 'node:fs';import crypto from 'node:crypto';import assert from 'node:assert/strict';
import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
async function main(){
 const root=new URL('./',import.meta.url),plan=JSON.parse(fs.readFileSync(new URL('performance-plan.json',root))),cycle=Number(process.argv[2]);
 const py=await loadPyodide({indexURL:new URL('../torch-iteration-76/runtime/',root).pathname,stdout(message){if(message.startsWith('PERF_PROGRESS'))console.log(message);},stderr(){}});await py.loadPackage('numpy');
 for(const [name,digest] of Object.entries(plan.files)){
  const bytes=fs.readFileSync(new URL(name,root));assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),digest,name);py.FS.mkdirTree('/'+name.split('/').slice(0,-1).join('/'));py.FS.writeFile('/'+name,bytes);
 }
 py.globals.set('cycle',cycle);
 const report=JSON.parse(py.runPython("import sys,json\nsys.path.insert(0,'/')\nfrom benchmark import run\njson.dumps(run('/baseline/stridetorch','/candidate/stridetorch','/fixtures',cycle))"));assert.equal(report.rows.length,98);
 fs.writeFileSync(new URL('latency-node-'+cycle+'.json',root),JSON.stringify({...report,node:process.version,pyodide:py.version,programs:plan.files},null,2)+'\n');console.log(JSON.stringify({status:'completed',cycle,rows:report.rows.length}));
}
main().catch(error=>{console.error(String(error));process.exitCode=1;});
