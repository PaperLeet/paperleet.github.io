import fs from'node:fs';import assert from'node:assert/strict';
import{withFixtureServer}from'../torch-iteration-70/fixture-server.mjs';
import{chromium}from'/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
await withFixtureServer(async origin=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 try{
  const page=await browser.newPage();await page.goto(origin+'/torch-iteration-79/index.html');
  const result=await page.evaluate(()=>new Promise((resolve,reject)=>{const worker=new Worker('./prototype-worker.mjs',{type:'module'}),timer=setTimeout(()=>{worker.terminate();reject(Error('Prototype WASM observation limit'));},360000);worker.onmessage=({data})=>{clearTimeout(timer);worker.terminate();resolve(data);};worker.onerror=e=>{clearTimeout(timer);worker.terminate();reject(Error(e.message));};worker.postMessage({});}));
  fs.writeFileSync(new URL('prototype-chrome-result.json',import.meta.url),JSON.stringify({...result,browser:browser.version()},null,2)+'\n');assert.equal(result.status,'passed',JSON.stringify(result.sdk?.failures||result));assert.equal(result.sdk.passed,result.expected_sdk);assert.equal(result.comparisons.reduce((n,c)=>n+c.cases,0),result.expected_native_cases);
  console.log(JSON.stringify({status:result.status,comparisons:result.comparisons.map(({failures,...c})=>c),sdk:result.sdk,browser:browser.version()}));
 }finally{await browser.close();}
});
