from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).resolve().parent;r=p.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();python=str(r.parent/'torch-iteration-69/integration-dev-env/bin/python')
assert read(p/'proof-push-receipt.json')['exit_code']==0
subprocess.run([python,'-B',str(p/'verify-commit.py'),'final-qualified-git-blobs.json','final-git-blob-verification.json'],cwd=repo,check=True)
subprocess.run([python,'-B',str(p/'verify-immutable.py')],cwd=repo,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=repo,text=True).split()[0];api=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/git/ref/heads/main','--jq','.object.sha'],cwd=repo,text=True).strip();assert head==remote==api
source=read(p/'source-main-adoption.json')['source_commit'];subprocess.run(['git','merge-base','--is-ancestor',source,head],cwd=repo,check=True)
actions={}
for commit in [source,head]:
 data=json.loads(subprocess.check_output(['gh','api',f'repos/PaperLeet/paperleet.github.io/actions/runs?head_sha={commit}&per_page=100'],cwd=repo,text=True));assert data['total_count']==0 and not data['workflow_runs'];actions[commit]=0
freeze=read(r/'core-source-freeze.json')
for n,h in freeze['source_hashes'].items():assert sha(repo/'packages/stridetorch/src/stridetorch'/n)==h,n
for n,h in read(p/'release-policy-identity.json')['files'].items():assert sha(repo/n)==h,n
for n,h in read(r/'runtime-identity.json')['files'].items():assert sha(repo/n)==h,n
worker=read(r/'local-integration/generated-worker-proof.json')
assert sha(repo/worker['asset'])==worker['asset_sha256'] and sha(repo/worker['generated_module'])==worker['generated_module_sha256']
result=dict(status='verified_077_on_main',goal_status='active',main_commit=head,source_commit=source,remote_main=remote,github_api_main=api,qualified_git_blobs=read(p/'final-git-blob-verification.json')['qualified_git_blobs'],source_resources=len(freeze['source_hashes']),active_exports=len(read(p/'live-export-sha256.json')),prior_immutable_entries=read(p/'immutable-verification.json')['prior_tree_entries_preserved'],actions_runs=actions,worktree_clean=True,ci_triggered=False,tags_created=False,published=False,deployed=False)
(p/'final-adoption-verification.json').write_text(json.dumps(result,indent=2)+'\n')
state=read(r/'state.json');state.update(status=result['status'],goal_status='active',previous_goal_turn_classification='progress',main_library_version='0.77.0',main_adopted=True,main_commit=head,source_commit=source,active_processes=[],application_gates='passed',ci_triggered=False,tags_created=False,published=False,deployed=False,next_actions=['Keep BrowserTorch as an unaccepted naming proposal; no rename yet.','Continue CPU/WASM API/autodiff improvements against qualified 0.77, including measured empty-mv backward overhead.','Re-evaluate experimental WebGPU resident/program benefits against current public Tensor APIs and actual copy/transfer costs before choosing a supported GPU backend.'])
state.pop('application_gate_process',None);state.pop('application_gate_label',None);(r/'state.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(result),flush=True)
