from pathlib import Path
import hashlib,json,subprocess,sys
p=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
expected=json.loads((p/(sys.argv[1] if len(sys.argv)>1 else 'qualified-git-blobs.json')).read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain','-z'],cwd=repo)
child=subprocess.Popen(['git','cat-file','--batch'],cwd=repo,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for name,digest in expected.items():
    child.stdin.write((head+':'+name+'\n').encode());child.stdin.flush();header=child.stdout.readline().decode().split()
    assert len(header)==3 and header[1]=='blob',(name,header)
    data=child.stdout.read(int(header[2]));assert child.stdout.read(1)==b'\n'
    assert hashlib.sha256(data).hexdigest()==digest,name
child.stdin.close();assert child.wait()==0
integration=json.loads((p/'integration-context.json').read_text()) if (p/'integration-context.json').exists() else None
base=integration['ownership_base'] if integration else json.loads((p.parent/'selected-source-freeze.json').read_text())['upstream']
changed=[name for name in subprocess.check_output(['git','diff','--name-only','-z',base,head],cwd=repo).decode().split('\0') if name]
if integration:
    allowed=set(integration['approved_owned_paths'])
    receipt='packages/stridetorch/benchmarks/results/iteration-79-main-adoption.json'
    if receipt in expected:allowed.add(receipt)
    assert set(changed)==allowed,(sorted(set(changed)-allowed),sorted(allowed-set(changed)))
result=dict(status='verified',commit=head,qualified_git_blobs=len(expected),owned_paths=len(changed),worktree_clean=True)
(p/(sys.argv[2] if len(sys.argv)>2 else 'commit-verification.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
