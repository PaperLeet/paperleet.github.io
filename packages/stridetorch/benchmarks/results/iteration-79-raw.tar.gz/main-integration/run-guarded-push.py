from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');kind=sys.argv[1];expected=sys.argv[2]
assert kind in ['adoption','proof']
wrapper=p.parent.parent/'torch-iteration-67/final-integration/push-main-native.py'
assert hashlib.sha256(wrapper.read_bytes()).hexdigest()==json.loads((p/'guard-provenance.json').read_text())['mandatory_wrapper_sha256']
env=dict(os.environ);count=int(env.get('GIT_CONFIG_COUNT','0'))
settings={'http.postBuffer':'134217728','http.lowSpeedTime':'30','http.lowSpeedLimit':'1'}
for offset,(key,value) in enumerate(settings.items()):env[f'GIT_CONFIG_KEY_{count+offset}']=key;env[f'GIT_CONFIG_VALUE_{count+offset}']=value
env['GIT_CONFIG_COUNT']=str(count+len(settings));env['GIT_TERMINAL_PROMPT']='0'
args=[sys.executable,str(wrapper),expected,str(p/'audit-main.py')];start=time.monotonic()
with (p/(kind+'-push.log')).open('w') as log:child=subprocess.run(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt=dict(kind=kind,exit_code=child.returncode,expected_remote=expected,seconds=time.monotonic()-start,command=args,scoped_git_config=settings,mandatory_wrapper_unchanged=True,ordinary_no_tag_push=True,log_sha256=hashlib.sha256((p/(kind+'-push.log')).read_bytes()).hexdigest())
(p/(kind+'-push-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True);child.check_returncode()
