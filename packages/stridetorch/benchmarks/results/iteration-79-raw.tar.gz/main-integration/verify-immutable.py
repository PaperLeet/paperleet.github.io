from pathlib import Path
import json,subprocess
p=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
before={row.split(b'\t',1)[1]:row.split(b'\t',1)[0] for row in (p.parent/'local-integration/immutable-tree.txt').read_bytes().split(b'\0') if row}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
raw=subprocess.check_output(['git','ls-tree','-r','-z',head,'--','web/public/data/browser-judge','web/public/data/modules'],cwd=repo)
now={row.split(b'\t',1)[1]:row.split(b'\t',1)[0] for row in raw.split(b'\0') if row}
assert all(now.get(n)==value for n,value in before.items())
expected_new=json.loads((p.parent/'local-integration/new-assets-sha256.json').read_text())
assert {n.decode() for n in set(now)-set(before)}==set(expected_new)
result=dict(status='verified',commit=head,prior_tree_entries_preserved=len(before),new_entries=len(set(now)-set(before)),prior_blob_ids_and_modes_unchanged=True)
(p/'immutable-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
