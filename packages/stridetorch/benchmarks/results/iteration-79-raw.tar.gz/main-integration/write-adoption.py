"""Record a completed guarded main adoption, then stage its small receipt."""
from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).resolve().parent;r=p.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');read=lambda q:json.loads(q.read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=repo,text=True)
assert read(p/'adoption-push-receipt.json')['exit_code']==0
assert not git('status','--porcelain')
subprocess.run([str(r.parent/'torch-iteration-69/integration-dev-env/bin/python'),'-B',str(p/'verify-commit.py')],cwd=repo,check=True)
subprocess.run([str(r.parent/'torch-iteration-69/integration-dev-env/bin/python'),'-B',str(p/'verify-immutable.py')],cwd=repo,check=True)
head=git('rev-parse','HEAD').strip();remote=git('ls-remote','origin','refs/heads/main').split()[0];api=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/git/ref/heads/main','--jq','.object.sha'],cwd=repo,text=True).strip();assert head==remote==api
actions=read_actions=json.loads(subprocess.check_output(['gh','api',f'repos/PaperLeet/paperleet.github.io/actions/runs?head_sha={head}&per_page=100'],cwd=repo,text=True));assert actions['total_count']==0 and not actions['workflow_runs']
freeze=read(r/'core-source-freeze.json')
for n,h in freeze['source_hashes'].items():assert sha(repo/'packages/stridetorch/src/stridetorch'/n)==h,n
for n,h in read(p/'release-policy-identity.json')['files'].items():assert sha(repo/n)==h,n
audit=read(p/'latest-main-audit.json');assert audit['allowed']
result=dict(status='verified_077_on_main',version='0.77.0',source_commit=head,remote_main=remote,github_api_main=api,qualified_git_blobs=read(p/'commit-verification.json')['qualified_git_blobs'],owned_paths=read(p/'commit-verification.json')['owned_paths'],source_resources=len(freeze['source_hashes']),active_export_identities=len(read(p/'live-export-sha256.json')),prior_immutable_entries=read(p/'immutable-verification.json')['prior_tree_entries_preserved'],worktree_clean_at_source_verification=True,actions_runs_for_source=0,guarded_push=read(p/'adoption-push-receipt.json'),original_core_numeric_execution_base=freeze['base'],application_execution_head=read(r/'local-integration/context.json')['upstream'],goal_status='active',ci_triggered=False,tags_created=False,published=False,deployed=False)
(p/'source-main-adoption.json').write_text(json.dumps(result,indent=2)+'\n')
receipt='packages/stridetorch/benchmarks/results/iteration-79-main-adoption.json';(repo/receipt).write_text(json.dumps(result,indent=2)+'\n')
doc='docs/validation/torch-runtime-iteration-79.md';path=repo/doc;body=path.read_text();assert '## Main adoption' not in body
path.write_text(body+f'\n## Main adoption\n\nVersion 0.77.0 was adopted on main at `{head}` through the unchanged guarded ordinary-push wrapper. Git/GitHub refs, the clean source tree and {result["qualified_git_blobs"]:,} qualified Git blobs were verified. All {result["prior_immutable_entries"]:,} prior immutable blob identities and modes are preserved. The source commit had zero Actions runs at verification. No CI, tag, publication or deployment was initiated. [Adoption receipt](../../{receipt}).\n')
entries=[line for line in git('status','--porcelain','-z','--untracked-files=all').split('\0') if line];assert {line[3:] for line in entries}=={doc,receipt}
qualified=read(p/'qualified-git-blobs.json');qualified.update({n:sha(repo/n) for n in [doc,receipt]});(p/'final-qualified-git-blobs.json').write_text(json.dumps(qualified,indent=2)+'\n')
subprocess.run(['git','add','--',doc,receipt],cwd=repo,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=repo,check=True)
print(json.dumps(dict(status='adoption_verified_receipt_staged',source_commit=head,qualified_git_blobs=result['qualified_git_blobs'],actions_runs=0)),flush=True)
