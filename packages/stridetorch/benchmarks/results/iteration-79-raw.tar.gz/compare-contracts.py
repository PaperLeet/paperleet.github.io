from pathlib import Path
import collections,hashlib,json,subprocess
r=Path(__file__).resolve().parent;read=lambda q:json.loads(q.read_text());native=read(r/'native-matmul-contracts.json');candidate=read(r/'candidate-matmul-contracts.json');assert native['probe_sha256']==candidate['probe_sha256']==hashlib.sha256((r/'probe-matmul-contracts.py').read_bytes()).hexdigest()
rows=[];groups=collections.Counter()
for a,b in zip(native['rows'],candidate['rows']):
 assert (a['op'],a['shapes'],a['dtypes'])==(b['op'],b['shapes'],b['dtypes'])
 if a['accepted']!=b['accepted'] or a['accepted'] and any(a[k]!=b[k] for k in ['dtype','shape','values']):
  row=dict(op=a['op'],shapes=a['shapes'],dtypes=a['dtypes'],native=a,candidate=b);rows.append(row);groups[(a['op'],str(a['shapes']),'native accepts' if a['accepted'] else 'candidate accepts')]+=1
result=dict(status='diagnostic_completed',execution_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/Users/david/Developer/PaperLeet-torch-release',text=True).strip(),cases=len(native['rows']),mismatches=len(rows),native_runtime=native['runtime_version'],candidate_runtime=candidate['runtime_version'],groups=[dict(op=k[0],shapes=k[1],direction=k[2],cases=v) for k,v in groups.items()],rows=rows,scope='Diagnostic only; small ones-filled arrays compare acceptance, output dtype, shape and full real/imaginary values against native Torch 2.6. No implementation change or broad compatibility claim.')
(r/'contract-differences.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
