from pathlib import Path
import hashlib,json,sys,warnings
import numpy as np
kind=sys.argv[1]
if kind=='native':
 import torch
 version=torch.__version__
else:
 import stridetorch
 from stridetorch import torch
 version=stridetorch.__version__
shapes=[((2,3),(3,)),((2,0),(0,)),((0,3),(3,)),((2,2,0),(0,)),((0,),(2,0,3)),((3,),(2,3,0)),((2,0),(2,0,3)),((0,3),(2,3,2)),((1,2,0),(3,0,2)),((3,2,0),(1,0,2)),((0,2,3),(1,3,2)),((1,2,3),(0,3,2)),((2,1,2,0),(1,3,0,2)),((2,1,0,3),(1,3,3,2))]
def serialize(value):
 if isinstance(value,(tuple,list)):return [serialize(v) for v in value]
 v=value.detach().numpy();return dict(dtype=str(v.dtype),shape=list(v.shape),values=v.tolist())
rows=[]
with warnings.catch_warnings(record=True) as notices:
 warnings.simplefilter('always')
 for sa,sb in shapes:
  for da,db in [('float32','float32'),('float64','float64'),('float32','float64'),('float64','float32')]:
   for ga,gb in [(False,False),(True,False),(False,True),(True,True)]:
    for channel in ['vjp','jvp','hvp']:
     a,b=[torch.from_numpy(np.ones(s,dtype=d)).requires_grad_(g) for s,d,g in [(sa,da,ga),(sb,db,gb)]];fn=lambda x,w:torch.matmul(x,w)
     row=dict(shapes=[sa,sb],dtypes=[da,db],requires_grad=[ga,gb],channel=channel)
     try:
      if channel=='vjp':
       y=fn(a,b);active=tuple(x for x in (a,b) if x.requires_grad);value=(y,torch.autograd.grad(y,active,torch.ones_like(y))) if active else (y,())
      elif channel=='jvp':value=torch.func.jvp(fn,(a,b),(torch.ones_like(a),torch.ones_like(b)))
      else:value=torch.autograd.functional.hvp(lambda x,w:fn(x,w).square().sum()*.5,(a,b),(torch.ones_like(a),torch.ones_like(b)))
      row.update(accepted=True,result=serialize(value))
     except Exception as e:row.update(accepted=False,error=type(e).__name__,message=str(e))
     rows.append(row)
 result=dict(kind=kind,runtime_version=version,numpy_version=np.__version__,probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows,warnings=[str(n.message) for n in notices])
Path(__file__).with_name(kind+'-matmul-ad.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(kind=kind,cases=len(rows),accepted=sum(r['accepted'] for r in rows),warnings=len(notices))))
