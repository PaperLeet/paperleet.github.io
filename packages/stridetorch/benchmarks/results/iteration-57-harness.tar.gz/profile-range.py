from pathlib import Path
import cProfile,hashlib,importlib.util,json,pstats,sys
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');rows=[]
for label,path in [('baseline',r/'baseline-source/stridetorch'),('candidate',repo/'packages/stridetorch/src/stridetorch')]:
 name='_profile_range_'+label;spec=importlib.util.spec_from_file_location(name,path/'__init__.py',submodule_search_locations=[str(path)]);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);t=m.torch;t.arange(16,dtype=t.float32)
 profile=cProfile.Profile();profile.enable()
 for _ in range(100000):t.arange(16,dtype=t.float32)
 profile.disable()
 with (r/(label+'-range-profile.txt')).open('w') as f:stats=pstats.Stats(profile,stream=f).strip_dirs().sort_stats('tottime');stats.print_stats(25)
 rows.append(dict(label=label,version=m.__version__,calls=stats.total_calls,source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in path.iterdir() if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']}))
(r/'profile-comparison.json').write_text(json.dumps(dict(rows=rows,scope='100,000 profiled arange(16,float32) calls used to explain call overhead. Timing claims come from the separate unprofiled benchmark.'),indent=2)+'\n');print([(x['label'],x['calls']) for x in rows])
