from pathlib import Path
import json,sys,warnings
import numpy as np

backend=sys.argv[1]
if backend=='native':import torch as t
else:from stridetorch import torch as t
r=Path(__file__).resolve().parent;rows={};arrays={}
def record(key,fn,metadata):
 try:
  with warnings.catch_warnings():warnings.simplefilter('ignore');value=fn()
  values=value if isinstance(value,(tuple,list)) else [value]
  schema=[]
  for i,x in enumerate(values):
   if x is None:schema.append(None);continue
   x=x.detach().numpy() if isinstance(x,t.Tensor) else np.asarray(x)
   schema.append(dict(dtype=str(x.dtype),shape=list(x.shape)));arrays[f'{key}.{i}']=x.copy()
  rows[key]=dict(status='ok',values=schema,**metadata)
  if backend=='native' and metadata.get('factory')=='logspace' and metadata.get('count',0)>=2 and schema[0]['dtype'].startswith(('int','uint')):
   # Use native double powers after native integer endpoint conversion to
   # identify undefined/out-of-storage-range float-to-integer kernel casts.
   start,end=endpoints[metadata['endpoint_index']];target=getattr(t,metadata['target'])
   a=t.empty((),dtype=target).fill_(start).item();b=t.empty((),dtype=target).fill_(end).item()
   raw=t.logspace(a,b,metadata['count'],base=metadata['base'],dtype=t.float64).numpy()
   limits=np.iinfo(np.dtype(schema[0]['dtype']))
   rows[key]['defined_integer_cast']=all(np.isfinite(v) and limits.min<=int(v)<=limits.max for v in raw)
 except Exception as e:rows[key]=dict(status='error',error=type(e).__name__,message=str(e)[:160],**metadata)

types=['float16','float32','float64','int8','uint8','int16','int32','int64','complex64','complex128','bool','uint16','uint32','uint64']
endpoints=[(-1,1),(1,-1),(-1.8,2.8),(.1,.9),(0,0),(-0.,0.),(1e-30,1e-29),
           (1e8,1e8+20),(-32768,32767),(1j,2+3j),(0j,2+0j),(float('inf'),2),(float('nan'),1),
           (np.float32(.1),np.float64(.9)),(t.tensor(.1,dtype=t.float32),t.tensor(.9,dtype=t.float64))]
for dtype in types:
 for count in [0,1,2,3,4,5,17]:
  for pair_index,(start,end) in enumerate(endpoints):
   for name in ['linspace','logspace']:
    for base in ([10.,2.,-2.,0.] if name=='logspace' and pair_index in [0,2,3] else [10.]):
     record(f'{name}.{dtype}.{count}.{pair_index}.{base}',lambda name=name,start=start,end=end,count=count,dtype=dtype,base=base:getattr(t,name)(start,end,count,dtype=getattr(t,dtype),**({'base':base} if name=='logspace' else {})),dict(factory=name,target=dtype,count=count,endpoint_index=pair_index,base=base))
ranges=[(0,5,1),(3,-3,-2),(.2,3.,.5),(-1.8,3.5,1.2),(.1,1.,.1),
        (1e8,1e8+20,1),(2048,2056,.5),(2**53-3,2**53+4,1),
        (2**63-5,2**63-1,1),(3,1,1),(1,3,-1),(1,1,1),(0,1,0),
        (0,1,float('inf')),(0,float('inf'),1),(float('nan'),1,1),(0j,3+0j,1),
        (1j,3+0j,1),(np.float32(0),np.float64(2),np.float32(.25))]
for dtype in types:
 for index,args in enumerate(ranges):
  record(f'arange.{dtype}.{index}',lambda args=args,dtype=dtype:t.arange(*args,dtype=getattr(t,dtype)),dict(factory='arange',target=dtype,range_index=index,start=str(args[0]),end=str(args[1]),step=str(args[2])))
for dtype in ['float16','float32','float64']:
 t.set_default_dtype(getattr(t,dtype))
 for name in ['arange','linspace','logspace']:
  record(f'inferred.{dtype}.{name}',lambda name=name:getattr(t,name)(0.,3.,**({'step':.5} if name=='arange' else {'steps':7})),dict(factory=name,target=dtype))
 for index,start in enumerate([1j,np.complex64(1j),t.tensor(1j,dtype=t.complex128),t.tensor(.1,dtype=t.float64)]):
  for name in ['linspace','logspace']:
   for count in [0,1,3]:
    record(f'inferred_endpoint.{dtype}.{index}.{name}.{count}',lambda start=start,name=name,count=count:getattr(t,name)(start,2.,count),dict(factory=name,target='default',default=dtype,count=count))
for dtype in ['float32','float64']:
 t.set_default_dtype(getattr(t,dtype))
 for name in ['arange','linspace','logspace']:
  def lifecycle(name=name):
   x=t.tensor(0.,requires_grad=True)
   fn=(lambda p:t.arange(p,3.)) if name=='arange' else (lambda p:getattr(t,name)(p,2.,3))
   y,j=t.func.jvp(fn,(x,),(t.ones_like(x),))
   leaf=getattr(t,name)(0.,2.,**({'step':1.} if name=='arange' else {'steps':3}),requires_grad=True)
   leaf.square().sum().backward()
   return y,j,leaf,leaf.grad
  record(f'lifecycle.{dtype}.{name}',lifecycle,dict(factory=name,target=dtype))
  def leaf(name=name):
   x=t.tensor(0.,requires_grad=True)
   with t.no_grad():y=getattr(t,name)(x,2.,requires_grad=True,**({'step':1.} if name=='arange' else {'steps':3}))
   y.square().sum().backward()
   return y,y.grad,x.grad,np.array([y.is_leaf,y.requires_grad])
  record(f'leaf.{dtype}.{name}',leaf,dict(factory=name,target=dtype))
for index,(args,kw) in enumerate([((3,),dict(step=2)),((),dict(end=3,step=2)),((),dict(start=1,end=3)),((),dict(start=3)),((1,),dict(end=3)),((1,3),dict(start=0)),((1,3),dict(step=2)),((1,3,2),dict(step=2)),((),dict(end=3))]):
 record(f'arity.arange.{index}',lambda args=args,kw=kw:t.arange(*args,**kw),dict(factory='arange',target='default'))
for name in ['linspace','logspace']:
 for index,steps in enumerate([True,np.bool_(True),np.int64(3),t.tensor(3),t.tensor([3]),-1,3.,2**64]):
  record(f'arity.{name}.{index}',lambda name=name,steps=steps:getattr(t,name)(0,1,steps),dict(factory=name,target='default',steps_index=index))
for index,base in enumerate(['10',np.complex64(2+1j),np.complex128(2+1j),np.array(2.),np.array([2.]),t.tensor(2.),t.tensor([2.]),t.tensor(2+0j),t.tensor(2+1j)]):
 record(f'base.{index}',lambda base=base:t.logspace(0,1,3,base=base),dict(factory='logspace',target='default'))
for dtype in types:
 for count in [0,1,17,257,65521]:
  for form in range(4):
   def unit_range(dtype=dtype,count=count,form=form):
    options={'dtype':getattr(t,dtype)}
    if form==0:return t.arange(count,**options)
    if form==1:return t.arange(0,count,**options)
    if form==2:return t.arange(0,count,1,**options)
    return t.arange(end=count,**options)
   record(f'unit_range.{dtype}.{count}.{form}',unit_range,dict(factory='arange',target=dtype,count=count,form=form))
np.savez_compressed(r/(backend+'-sequences.npz'),**arrays)
(r/(backend+'-sequences.json')).write_text(json.dumps(dict(backend=backend,python=sys.version,numpy=np.__version__,rows=rows),indent=2)+'\n')
print(backend,len(rows),'cases',len(arrays),'arrays',sum(v['status']=='error' for v in rows.values()),'errors')
