from pathlib import Path
from fractions import Fraction
import collections,hashlib,json
import numpy as np

r=Path(__file__).resolve().parent
a=json.loads((r/'adapter-sequences.json').read_text())['rows'];b=json.loads((r/'native-sequences.json').read_text())['rows'];aa=np.load(r/'adapter-sequences.npz');bb=np.load(r/'native-sequences.npz')
assert set(a)==set(b) and len(a)==4495
counts=collections.Counter();excluded=[];special=[];errors=collections.Counter();worst={}
for key,left in a.items():
 right=b[key];assert left['status']==right['status'],(key,left,right)
 if left['status']=='error':
  if left['error']=='BrowserUnsupported':
   assert right['error']=='NotImplementedError' or 'ComplexHalf' in right['message'] or 'ComplexHalf' in str(right),(key,left,right)
  else:assert left['error']==right['error'],(key,left,right)
  errors[right['error']+' -> '+left['error']]+=1;counts['error_cases']+=1;continue
 assert left['values']==right['values'],(key,left,right)
 if right.get('defined_integer_cast') is False:
  excluded.append(key);counts['platform_dependent_integer_cast_cases']+=1;continue
 if key.startswith('linspace.float16.') and right.get('endpoint_index')==8 and right.get('count',0)>=2:
  count=right['count'];oracle=np.array([float(Fraction(-32768)+Fraction(65536)*Fraction(i,count-1)) for i in range(count)]).astype('float16')
  np.testing.assert_array_equal(aa[key+'.0'],oracle);special.append(key);counts['widened_half_oracle_cases']+=1;continue
 for i,schema in enumerate(left['values']):
  if schema is None:continue
  name=f'{key}.{i}';x,y=aa[name],bb[name]
  if x.dtype.kind not in 'fc':np.testing.assert_array_equal(x,y,err_msg=name)
  else:
   tol=(3e-3,2e-3) if x.dtype==np.dtype('float16') else (2e-13,2e-14) if x.dtype in [np.dtype('float64'),np.dtype('complex128')] else (2e-6,2e-7)
   for field in (['real','imag'] if x.dtype.kind=='c' else ['real']):
    xx,yy=getattr(x,field),getattr(y,field)
    for mask in [np.isnan,np.isposinf,np.isneginf]:np.testing.assert_array_equal(mask(xx),mask(yy),err_msg=name+'.'+field)
    finite=np.isfinite(xx)&np.isfinite(yy)
    if x.dtype.kind=='c':
     reference=y[finite];scale=np.hypot(np.where(np.isfinite(reference.real),reference.real,0),np.where(np.isfinite(reference.imag),reference.imag,0));bound=tol[1]+tol[0]*scale;assert np.all(np.abs(xx[finite]-yy[finite])<=bound),(name,field,float(np.max(np.abs(xx[finite]-yy[finite])-bound,initial=0)))
    else:np.testing.assert_allclose(xx[finite],yy[finite],rtol=tol[0],atol=tol[1],err_msg=name+'.'+field)
    delta=float(np.max(np.abs(xx[finite]-yy[finite]),initial=0));kind=str(x.dtype)
    if delta>worst.get(kind,{}).get('absolute',-1):worst[kind]=dict(absolute=delta,array=name,component=field)
  counts['native_numeric_arrays']+=1
 counts['native_numeric_cases']+=1
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
import stridetorch
source=Path(stridetorch.__file__).parent
report=dict(status='qualified',cases=len(a),counts=dict(counts),error_categories=dict(errors),platform_dependent_integer_cast_cases=excluded,widened_half_oracle_cases=special,worst_absolute_differences=worst,source_hashes={p.name:sha(p) for p in source.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']},input_sha256={n:sha(r/n) for n in ['differential-sequences.py','qualify-sequences.py','native-sequences.json','native-sequences.npz','adapter-sequences.json','adapter-sequences.npz']},scope='Dtype/shape exact; integer values exact; floating and real/imag components use separate finite/NaN/signed-infinity checks. Complex component finite error is bounded by atol+rtol*abs(reference complex value), accounting for phase-rounding near zero components across libm implementations. Half 3e-3/2e-3, float32/complex64 2e-6/2e-7, float64/complex128 2e-13/2e-14 rtol/atol. Five wide half spans use an independent rational oracle, not native numeric passes. Undefined float-to-integer overflows are retained but excluded from portable numeric claims. Unsupported/error categories checked separately.')
(r/'sequences-qualification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],cases=len(a),counts=counts,error_categories=errors)))
