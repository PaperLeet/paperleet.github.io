from pathlib import Path
import hashlib,json,re,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
def read(name):return json.loads((r/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
p=read('publication.json');commit=p['commit'];observer=read('remote-observer-terminal.json');assert observer['status']=='success' and observer['commit']==commit
quality=observer['runs']['quality'];pages=observer['runs']['pages'];assert quality['id']==38944777730 and pages['id']==38946337720 and quality['head_sha']==pages['head_sha']==commit and quality['conclusion']==pages['conclusion']=='success'
for name in ('native','infrastructure','browser-wasm','pilot'):
 jobs=[j for j in quality['jobs'] if j['name']==name];assert len(jobs)==1 and jobs[0]['status']=='completed' and jobs[0]['conclusion']=='success'
deploy=[j for j in pages['jobs'] if j['name']=='deploy'];assert len(deploy)==1 and deploy[0]['conclusion']=='success' and all(s['conclusion']=='success' for s in deploy[0]['steps']);assert any('deploy-pages@' in s['name'] for s in deploy[0]['steps'])
assert len(p['source_hashes'])==46 and len(p['export_sha256'])==161
for name,h in p['source_hashes'].items():assert hashlib.sha256(subprocess.check_output(['git','show',commit+':packages/stridetorch/src/stridetorch/'+name],cwd=repo)).hexdigest()==h
for name,h in p['export_sha256'].items():assert sha(r/'integration-proof/live-expected'/name)==h and hashlib.sha256(subprocess.check_output(['git','show',commit+':web/public/data/'+name],cwd=repo)).hexdigest()==h
n=read('remote-native/ci.json');w=read('remote-wasm/browser-wasm.json');localn=read('integration-proof/native-ci.json');localw=read('integration-proof/full-wasm-result.json');reference={c['id']:c for c in localw['results']}
assert n['passed'] and not n['issues'] and n['problems']==78 and n['tests_executed']==10218 and n['repeats']==3 and n['duration_s']<=600 and n['mutation']==localn['mutation'] and sum(map(len,n['mutation'].values()))==342
assert w['passed'] and w['scope']=='catalog' and w['modules']==w['catalog_modules']==78 and len(w['results'])==78 and not w['browser_budget_exceeded']
for c in w['results']:
 expected=reference[c['id']]
 for key in ('tests','mutants','pyodide','numpy','backend','packages','bundle_url','runtime_bundle_url','source_sha256','budgets'):assert c[key]==expected[key],(c['id'],key)
 b=c['budgets'];assert c['passed'] and not c['browser_budget_exceeded'] and c['calibration_ms']<=b['calibration'] and c['learner_ms']<=b['run'] and c['preparation_ms']+c['calibration_ms']+c['learner_ms']<=b['total']
contracts=next(c['independent_contracts'] for c in w['results'] if 'independent_contracts' in c);assert contracts['passed']==1113 and len(contracts['suites'])==31 and {c['suite']:c['source_sha256'] for c in contracts['suites']}==read('integration-proof/wasm-harness-identity.json')['test_hashes']
m=re.search(r'30879 passed, 1 skipped, 37 warnings in ([\d.]+)s',(r/'remote-infrastructure.log').read_text());assert m
live=read('integration-proof/live-assets.json');assert live['status']=='success' and live['commit']==commit and live['modules']==78 and live['immutable_assets_equal']==158 and all(live[k] for k in ('starters_equal','manifests_equal','module_details_equal'))
download=read('remote-download-receipts.json');assert len(download)==3 and all(c['exit_code']==0 for c in download.values())
p.update(eligible_pages_run=pages['id'],live_verified=True,last_verified_site=dict(version='0.31.0',commit=commit));(r/'publication.json').write_text(json.dumps(p,indent=2)+'\n')
files=['close-remote.py','download-remote.py','publication.json','push-receipts.json','post-push-main.log','remote-observer-terminal.json','watch-remote.py','remote-infrastructure.log','remote-native/ci.json','remote-wasm/browser-wasm.json','remote-download-receipts.json','integration-proof/verify-live.py','integration-proof/live-assets.json','integration-proof/live.log','integration-proof/live-expected-sha256.json','integration-proof/release-snapshot.json','integration-proof/wasm-harness-identity.json']
archive=out/'iteration-31-remote-adoption-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name in files:tar.add(r/name,arcname=name,recursive=False)
report=dict(status='actual_exact_source_quality_pages_and_live_verified',version='0.31.0',source_commit=commit,source_quality=quality,source_pages=pages,all_four_jobs_and_actual_deploy_steps_verified=True,source_hashes=p['source_hashes'],export_files=161,source_base_passed=30879,source_optional_skips=1,source_infrastructure_s=float(m[1]),native=n,native_mutants=342,wasm={k:v for k,v in w.items() if k!='results'},wasm_mutants=sum(c['mutants'] for c in w['results']),independent_contracts=contracts,live=live,receipts=dict(observer=dict(session=97354,exit_code=0),live=dict(session=75722,exit_code=0),downloads=dict(session=60578,exit_code=0,children=download),main_push=dict(session=91390,exit_code=0)),download_note='All3 artifact/log commands ran in owned repository and succeeded;Quality and Pages are pinned to exact main source b3b56a19.',archive=dict(file=archive.name,files=len(files),bytes=archive.stat().st_size,sha256=sha(archive)),scope='Pinned Git b3b56a19 and frozen0.31 proof used;current0.32 WIP is not substituted. Remote runner durations are compatibility/budget gates,no cross-run speedup inference.')
(out/'iteration-31-remote-adoption.json').write_text(json.dumps(report,indent=2)+'\n');(r/'remote-adoption.json').write_text(json.dumps(report,indent=2)+'\n')
state=read('state.json');state.update(phase='0.30 exact source Quality,actual Pages and live fully verified',remote_observer=dict(session=97354,quality=38944777730,terminal_collected=True,exit_code=0),remote_adoption={k:report[k] for k in ('status','source_commit','source_base_passed','source_optional_skips','source_infrastructure_s','archive')});(r/'state.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(dict(status=report['status'],native_s=n['duration_s'],wasm_ms=w['elapsed_ms'],infrastructure_s=float(m[1]),archive=report['archive']),indent=2))
