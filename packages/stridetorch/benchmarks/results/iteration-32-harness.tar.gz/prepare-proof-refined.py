from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');old=r.parent/'torch-iteration-31/proof-refined';proof=r/'proof-refined';proof.mkdir(exist_ok=True);source=repo/'packages/stridetorch/src/stridetorch'
for target in (proof/'source',proof/'chrome-contracts/source'):shutil.copytree(source,target,ignore=shutil.ignore_patterns('__pycache__'),dirs_exist_ok=True)
shutil.copytree(repo/'packages/stridetorch/tests',proof/'chrome-contracts/tests',ignore=shutil.ignore_patterns('__pycache__'),dirs_exist_ok=True)
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};assert len(hashes)==47
plan=dict(version='0.32.0',expected=1128,source=hashes,tests={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'});assert len(plan['tests'])==32
(proof/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n');(proof/'chrome-contracts/plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for name in ('run.mjs','worker.mjs','index.html'):
 s=(old/'chrome-contracts'/name).read_text().replace('torch-iteration-31/proof-refined','torch-iteration-32/proof-refined');(proof/'chrome-contracts'/name).write_text(s)
s=(old/'wasm-contracts.mjs').read_text().replace('torch-iteration-31/proof-refined','torch-iteration-32/proof-refined').replace('0.31.0','0.32.0').replace("'triangular']","'triangular','cholesky']").replace('==1113','==1128');(proof/'wasm-contracts.mjs').write_text(s)
s=(old/'check-wheel.py').read_text().replace('0.31','0.32').replace('stride031','stride032').replace('==44','==45').replace('package_modules=44','package_modules=45');(proof/'check-wheel.py').write_text(s)
s=(old/'check-coinstall.py').read_text().replace('0.31.0','0.32.0')
anchor="print('PASS isolated ownership,aliases,ZIP resume and triangular VJP/JVP/full tangent reverse')"
addition="""for name in NAMES:
 t=importlib.import_module(name).torch
 a=t.tensor([[4.,1.],[1.,3.]],dtype=t.float64,requires_grad=True)
 factor=t.linalg.cholesky(a);np.testing.assert_allclose(factor.numpy(),[[2.,0.],[.5,np.sqrt(2.75)]])
 factor.square().sum().backward();np.testing.assert_allclose(a.grad.numpy(),np.eye(2),atol=1e-14)
 a.grad=None;direction=t.tensor([[.2,.3],[.7,.4]],dtype=t.float64,requires_grad=True)
 _,tangent=t.func.jvp(lambda v:t.linalg.cholesky(v,upper=True),(a,),(direction,))
 np.testing.assert_allclose(tangent.numpy(),[[.05,.3375],[0.,.048995593493886595]])
 tangent.square().sum().backward();assert np.isfinite(a.grad.numpy()).all() and np.isfinite(direction.grad.numpy()).all()
print('PASS isolated ownership,aliases,ZIP resume,triangular and Cholesky VJP/JVP/full tangent reverse')"""
assert anchor in s;s=s.replace(anchor,addition);(proof/'check-coinstall.py').write_text(s)
print('Frozen47 resources,32 suites1128 browser checks')
