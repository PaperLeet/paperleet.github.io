from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,subprocess,time
r=Path(__file__).resolve().parent;p=r/'proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release');py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';uv='/Users/david/.local/bin/uv';receipts={}
def run(name,args,cwd=repo):
 start=time.monotonic()
 with (p/(name+'.log')).open('w') as log:result=subprocess.run([str(x) for x in args],cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
 receipt=dict(exit_code=result.returncode,elapsed_s=time.monotonic()-start,args=[str(x) for x in args],cwd=str(cwd))
 return name,receipt
plans={'build-public':([uv,'build','--out-dir',p/'dist-preflight'],repo/'packages/stridetorch'),'build-private':([uv,'build','--out-dir',p/'private-dist'],repo),'node-wasm':(['/opt/homebrew/bin/node',p/'wasm-contracts.mjs'],repo),'chrome-worker':(['/opt/homebrew/bin/node',p/'chrome-contracts/run.mjs'],repo)}
with ThreadPoolExecutor(max_workers=4) as pool:
 for future in as_completed([pool.submit(run,name,args,cwd) for name,(args,cwd) in plans.items()]):
  name,receipt=future.result();receipts[name]=receipt;(p/'gate-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print('TERMINAL',name,receipt['exit_code'],round(receipt['elapsed_s'],2),flush=True)
assert all(v['exit_code']==0 for v in receipts.values()),receipts
with ThreadPoolExecutor(max_workers=2) as pool:
 for future in as_completed([pool.submit(run,name,[py,p/script]) for name,script in [('minimal-wheel','check-wheel.py'),('coinstall','check-coinstall.py')]]):
  name,receipt=future.result();receipts[name]=receipt;(p/'gate-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print('TERMINAL',name,receipt['exit_code'],round(receipt['elapsed_s'],2),flush=True)
assert all(v['exit_code']==0 for v in receipts.values()),receipts
print('ALL EXTRA GATES PASS',flush=True)
