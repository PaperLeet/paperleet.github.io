from pathlib import Path
import hashlib,json,subprocess,shutil
root=Path(__file__).resolve().parent;r=root/'integration-proof';r.mkdir(exist_ok=True);repo=Path('/Users/david/Developer/PaperLeet-torch-release');old=root.parent/'torch-iteration-31/integration-proof';upstream='b3b56a19f403cc9fb7e1f0d9c4e109ecb66ac545'
def save(name,obj):(r/name).write_text(json.dumps(obj,indent=2)+'\n')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source={p.name:digest(p) for p in (repo/'packages/stridetorch/src/stridetorch').iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};assert len(source)==47 and source==json.loads((root/'proof-refined/source-hashes.json').read_text())
assert subprocess.check_output(['git','rev-parse','origin/main'],cwd=repo,text=True).strip()==upstream
assert not (repo/'web/node_modules').is_symlink()
for name in ('web/package.json','web/package-lock.json'):
 assert (repo/name).read_bytes()==subprocess.check_output(['git','show',upstream+':'+name],cwd=repo)
for name in ('verify-export.py','run-frontend.py','verify-live.py','run-export.py','verify-private.py','run-native.py'):
 s=(old/name).read_text().replace('0.31.0','0.32.0').replace('==7704','==7862').replace('core_modules=44','core_modules=45').replace('all_46_core_license_hashes_identical','all_47_core_license_hashes_identical').replace('torch031','torch032');(r/name).write_text(s)
s=(old/'freeze.py').read_text().replace('0.31.0','0.32.0').replace('==31','==32').replace('1113','1128').replace('expected_suites=31','expected_suites=32').replace("'torch-iteration-30/integration-proof/owned-dependencies.json'","'torch-iteration-31/integration-proof/owned-dependencies.json'").replace('iteration31 integration','iteration32 integration');(r/'freeze.py').write_text(s)
context=dict(upstream=upstream,source_hashes=source,core_report='iteration-32.json',dependency_inputs_unchanged=True,upstream_changes_since_previous_release=[],scope='0.31 main retained exactly;only library0.32 source/tests/docs and new immutable exports change. Original catalog,judges,frontend and dependency lock unchanged. Complete frontend/native/WASM gates required.')
save('context.json',context)
(r/'dist-paperleet').mkdir(exist_ok=True)
for p in (root/'proof-refined/private-dist').iterdir():shutil.copy2(p,r/'dist-paperleet'/p.name)
print('Prepared47 resource integration,7862 existing immutable assets preserved')
