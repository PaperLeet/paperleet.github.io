from pathlib import Path
import json,hashlib,subprocess
import numpy as np
import torch
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');source=r/'baseline/stridetorch';source.mkdir(parents=True,exist_ok=True)
for p in (repo/'packages/stridetorch/src/stridetorch').iterdir():
 if p.suffix=='.py' or p.name in ('LICENSE','NOTICE'):(source/p.name).write_bytes(p.read_bytes())
print('NATIVE',torch.__version__)
for upper in (False,True):
 for variant in ('full','bad-unused','bad-used'):
  a=torch.tensor([[4.,1.],[1.,3.]],dtype=torch.float64,requires_grad=True)
  with torch.no_grad():
   if variant!='full':a[1 if upper else 0,0 if upper else 1]=float('nan')
   if variant=='bad-used':a[0 if upper else 1,1 if upper else 0]=float('nan')
  try:
   x=torch.linalg.cholesky(a,upper=upper);x.sum().backward();print('VALUE',upper,variant,x.tolist(),x.stride(),'grad',a.grad.tolist())
  except Exception as e:print('VALUEERROR',upper,variant,type(e).__name__)
 for mutated in ('a','x'):
  a=torch.tensor([[4.,1.],[1.,3.]],requires_grad=True);x=torch.linalg.cholesky(a,upper=upper)
  with torch.no_grad():{'a':a,'x':x}[mutated].add_(.1)
  try:x.sum().backward();error=False
  except RuntimeError:error=True
  print('GUARD',upper,mutated,error)
 for shape in ((0,0),(1,1),(2,2),(0,3,3),(2,0,0),(2,1,1),(2,3,3)):
  a=torch.eye(shape[-1],dtype=torch.float64).expand(shape).clone();x=torch.linalg.cholesky(a,upper=upper);print('LAYOUT',upper,shape,x.stride())
 for direction in ([[.2,.3],[.7,.4]],[[.2,.3],[.3,.4]]):
  a=torch.tensor([[4.,1.],[1.,3.]],dtype=torch.float64,requires_grad=True);d=torch.tensor(direction,dtype=torch.float64,requires_grad=True)
  x,t=torch.func.jvp(lambda a:torch.linalg.cholesky(a,upper=upper),(a,),(d,));grads=torch.autograd.grad(t.sum(),(a,d),allow_unused=True)
  print('JVP',upper,direction,'x',x.tolist(),'t',t.tolist(),'strides',x.stride(),t.stride(),'grads',[None if g is None else g.tolist() for g in grads])
