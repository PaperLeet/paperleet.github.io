from pathlib import Path
import hashlib,json,os,re,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results';proof=r/'proof-refined'
def read(name):return json.loads((r/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
actual={p.name:sha(p) for p in (repo/'packages/stridetorch/src/stridetorch').iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};assert actual==read('proof-refined/source-hashes.json') and len(actual)==47
plan=read('proof-refined/chrome-contracts/plan.json');assert plan['source']==actual and plan['expected']==1128 and len(plan['tests'])==32 and plan['tests']=={p.name:sha(p) for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'}
gates=read('proof-refined/gate-receipts.json');assert len(gates)==7 and all(v['exit_code']==0 for v in gates.values());m=re.search(r'31042 passed, 1 skipped, 34 warnings in ([\d.]+)s',(proof/'full-native.log').read_text());assert m
assert '163 passed' in (r/'focused-refined.log').read_text();wheel=read('proof-refined/wheel-stride032-result.json');assert wheel['status']=='success' and not wheel['native_torch'] and wheel['source_hashes']==actual and '1140 passed' in (proof/'python310-stride032-tests.log').read_text()
node=read('proof-refined/source-wasm.json');chrome=read('proof-refined/chrome-contracts/result.json');assert node['passed']==chrome['passed']==1128 and node['source_hashes']==chrome['source_hashes']==actual and chrome['test_hashes']==plan['tests'] and chrome['status']=='success'
coinstall=read('proof-refined/coinstall-result.json');assert coinstall['status']=='success' and coinstall['source_hashes']==actual and all(v['exit_code']==0 for v in coinstall['receipts'])
initial=read('performance-summary.json');final=read('performance-refined-summary.json');imports=read('import-summary.json')
for p in (initial,final):assert len(p['receipts'])==8 and all(v['exit_code']==0 for v in p['receipts'].values())
assert len(imports['receipts'])==16 and all(v['exit_code']==0 for v in imports['receipts'])
assert read('performance-refined-plan.json')['candidate_hashes']==actual
native=r/'native-contracts';native.mkdir(exist_ok=True);shutil.copy2(repo/'tests/test_torch_cholesky.py',native/'test_torch_cholesky.py')
repro=r/'package-metadata';repro.mkdir(exist_ok=True)
for name in ('README.md','pyproject.toml','LICENSE','NOTICE'):shutil.copy2(repo/'packages/stridetorch'/name,repro/name)
files=[]
for directory,dirs,names in os.walk(r):
 dirs[:]=[d for d in dirs if not d.endswith('-env') and d not in ('__pycache__','.pytest_cache','dist-preflight','private-dist','integration-proof','performance-refined-native-context')]
 for name in names:
  p=Path(directory)/name
  if (name in ('LICENSE','NOTICE') or p.suffix in ('.py','.mjs','.json','.log','.txt','.md','.html','.toml')) and name!='local-gates.json':files.append(p)
archive=out/'iteration-32-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
report=dict(status='refined_core_candidate_validated_application_integration_pending',version='0.32.0',baseline_release_commit='b3b56a19f403cc9fb7e1f0d9c4e109ecb66ac545',source_hashes=actual,standalone_test_hashes=plan['tests'],native_test_sha256=sha(native/'test_torch_cholesky.py'),full_cpu=dict(passed=31042,optional_skipped=1,warnings=34,duration_s=float(m[1])),focused_passed=163,minimal_wheel=wheel,node_wasm=node,actual_chrome_worker=chrome,coinstall=coinstall,initial_performance=initial,final_performance=final,cold_namespace_imports=imports,gate_receipts=gates,scope='Cholesky real float32/64 values,VJP,JVP and full reverse through primal/direction;complex64/128 inference;selected triangles,batches,strided/empty layouts,output-only save/guard. Tiny analytical pullbacks,small already-triangular LAPACK calls and large blocked substitution. No out/half/complex AD,no nativeTorch runtime or SciPy,no tensor-value caches.',primary_sources=['https://docs.pytorch.org/docs/2.14/generated/torch.linalg.cholesky.html','https://github.com/pytorch/pytorch/blob/v2.14.0/torch/csrc/autograd/FunctionsManual.cpp#L2125'],retained_failures=['Initial focused133pass/30fail:20invalid test assumptions about constructing complex-grad tensors in no_grad corrected within existing explicit unsupported boundary;8empty tangent stride and2infinite-diagonal backward contamination product defects corrected.','First Node/Chrome pytest runs exited0 with1128passes;harness expected1130 due arithmetic miscount. Corrected1113+15=1128,all32 suites retained;first logs/plan retained.','Initial8 paired timing children allpassed correctness but small flows regressed;raw measurements retained. Refined tiny scalar adjoints and direct small factor systems are compared to original generic-LU0.32 baseline.0.31 has no Cholesky;no speedup over missing API is claimed.'],archive=dict(file=archive.name,files=len(files),bytes=archive.stat().st_size,sha256=sha(archive)),remaining=['Original PaperLeet native catalog and actual exported WASM gates','Complete latest frontend and immutable asset preservation','Non-force main adoption','Exact remote Quality,actual Pages and live byte verification'])
(out/'iteration-32.json').write_text(json.dumps(report,indent=2)+'\n');(r/'local-gates.json').write_text(json.dumps(report,indent=2)+'\n');s=read('state.json');s.update(phase='Refined0.32 core validated;complete app integration next',core_report='iteration-32.json',archive=report['archive']);(r/'state.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(dict(status=report['status'],full_cpu=report['full_cpu'],archive=report['archive']),indent=2))
