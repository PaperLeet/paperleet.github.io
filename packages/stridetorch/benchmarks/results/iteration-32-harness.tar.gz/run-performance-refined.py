from pathlib import Path
import json,os,subprocess,time,statistics,hashlib,gzip
r=Path(__file__).resolve().parent;plan=json.loads((r/'performance-refined-plan.json').read_text());out=r/'performance-refined';out.mkdir(exist_ok=True);receipts={};py=r.parent/'torch-iteration-21/stride-dev-env/bin/python'
paths={k:plan[k] for k in ('baseline','candidate')}
for runtime in ('cpu','wasm'):
 for dtype in ('float32','float64'):
  for repetition in (1,2):
   label=f'{runtime}-{dtype}-{repetition}';env=os.environ.copy();env.update(BENCH_SOURCES=json.dumps(paths),BENCH_DTYPE=dtype)
   command=[str(py),str(r/'bench-library.py')] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(r/'bench-library-wasm.mjs')]
   start=time.monotonic()
   with (out/(label+'.json')).open('w') as output,(out/(label+'.stderr.log')).open('w') as error:p=subprocess.run(command,cwd=r,env=env,stdout=output,stderr=error)
   receipts[label]=dict(command=command,exit_code=p.returncode,elapsed_s=time.monotonic()-start);(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode()
   data=json.loads((out/(label+'.json')).read_text());assert data['source_hashes']['candidate']==plan['candidate_hashes'] and data['source_hashes']['baseline']==plan['baseline_hashes']
   print('TERMINAL',label,0,{k:round(v['median_time_reduction_percent'],1) for k,v in data['results'].items()},flush=True)
summary={}
for runtime in ('cpu','wasm'):
 reports=[json.loads((out/f'{runtime}-{dtype}-{rep}.json').read_text()) for dtype in ('float32','float64') for rep in (1,2)]
 summary[runtime]={key:dict(median_reductions_percent=[report['results'][key]['median_time_reduction_percent'] for report in reports],baseline_median_us=[statistics.median(statistics.mean(block['samples_us']['baseline']) for block in report['results'][key]['blocks']) for report in reports],candidate_median_us=[statistics.median(statistics.mean(block['samples_us']['candidate']) for block in report['results'][key]['blocks']) for report in reports]) for key in reports[0]['results']}
footprint={}
for label,path in [('previous_031',r/'baseline/stridetorch'),('candidate_032',r/'proof-refined/source')]:
 payload=b''.join(p.read_bytes() for p in sorted(path.iterdir()) if p.suffix=='.py' or p.name in ('LICENSE','NOTICE'));footprint[label]=dict(raw_bytes=len(payload),gzip_estimate_bytes=len(gzip.compress(payload,mtime=0)))
result=dict(scope='Within-runtime paired complete-flow comparison of refined tiny/small/large pullback vs original generic-LU pullback in same0.32 API;not release0.31 speedup. 2processes per dtype;float32,float64;9 paired blocks each;all numerical/state checks passed;GC enabled;shared host and BLAS threads unverified. Source footprint is not network wire size.',summary=summary,source_footprint=footprint,receipts=receipts)
(r/'performance-refined-summary.json').write_text(json.dumps(result,indent=2)+'\n');print('ALL8 performance children terminal0',flush=True)
