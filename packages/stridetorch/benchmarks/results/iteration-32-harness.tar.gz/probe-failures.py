import numpy as np
import torch
for kind in ('nan-diag','nan-used','inf-diag','complex-imag-diag','negative'):
 a=np.array([[4.,1.],[1.,3.]],dtype=np.complex128 if kind=='complex-imag-diag' else np.float64)
 if kind=='nan-diag':a[0,0]=np.nan
 if kind=='nan-used':a[1,0]=np.nan
 if kind=='inf-diag':a[0,0]=np.inf
 if kind=='complex-imag-diag':a[0,0]+=np.nan*1j
 if kind=='negative':a[0,0]=-1.
 for name,call in [('numpy',lambda:np.linalg.cholesky(a)),('torch',lambda:torch.linalg.cholesky(torch.tensor(a)).numpy())]:
  try:print(kind,name,call())
  except Exception as e:print(kind,name,type(e).__name__,str(e))
