import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const repo='/Users/david/Developer/PaperLeet-torch-release';
const source="/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-32/proof/source";
const py=await loadPyodide({indexURL:path.join(repo,'web/node_modules/pyodide/'),packageCacheDir:path.join(repo,'web/public/browser-runtime/pyodide-0.29.4/'),stdout:console.log,stderr:console.error});
await loadJudgePackages(py,[]);py.FS.mkdirTree('/runtime/stridetorch');
const hashes={};
for(const name of fs.readdirSync(source).filter(name=>name.endsWith('.py')||['LICENSE','NOTICE'].includes(name))){
 const bytes=fs.readFileSync(path.join(source,name));
 py.FS.writeFile('/runtime/stridetorch/'+name,bytes);
 hashes[name]=crypto.createHash('sha256').update(bytes).digest('hex');
}
const suites=['module_lifecycle','optimizer_lifecycle','conversion_modes','scheduler_lifecycle','nn_workflows','module_hooks','graph_lifecycle','tensor_hooks','numpy_inputs','construction','promotion','arithmetic','ieee','linear_wasm','batchnorm','groupnorm','classification','convolution','layout','shape_ops','statistics','dispatch','mean','nan_reductions','joint_vjp','indexing','gradient_layout','axis_transforms','solve','serialization','triangular','cholesky'];
for(const name of suites)py.FS.writeFile('/runtime/test_'+name+'.py',fs.readFileSync(path.join("/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-32/proof/chrome-contracts/tests",'test_'+name+'.py'),'utf8'));
py.globals.set('expected_hashes',JSON.stringify(hashes));py.globals.set('test_paths',suites.map(name=>'/runtime/test_'+name+'.py').join('|'));
const result=JSON.parse(py.runPython(`
import sys,json,pathlib,hashlib
sys.path.insert(0,'/runtime')
actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path('/runtime/stridetorch').iterdir() if p.is_file()}
assert actual==json.loads(expected_hashes)
import pytest,stridetorch,numpy
assert stridetorch.__version__=='0.32.0'
class Results:
    passed=0
    def pytest_runtest_logreport(self,report):
        if report.when=='call' and report.passed:self.passed+=1
record=Results()
code=pytest.main([*test_paths.split('|'),'-q','--noconftest','-p','no:cacheprovider','--import-mode=importlib'],plugins=[record])
assert int(code)==0 and record.passed==1130,(code,record.passed)
previous_error_mode=numpy.seterr(all='raise')
try:
    try: numpy.divide(1.,0.)
    except FloatingPointError: numpy_fenv_traps=True
    else: numpy_fenv_traps=False
finally: numpy.seterr(**previous_error_mode)
json.dumps(dict(numpy_fenv_traps=numpy_fenv_traps,library=stridetorch.__version__,numpy=numpy.__version__,passed=record.passed,source_hashes=actual))
`));
assert.equal(result.numpy,'2.2.5');fs.writeFileSync(new URL('source-wasm.json',import.meta.url),JSON.stringify(result,null,2));
console.log('PASS actual Pyodide',py.version,result.library,result.passed,'contracts and source hashes');
