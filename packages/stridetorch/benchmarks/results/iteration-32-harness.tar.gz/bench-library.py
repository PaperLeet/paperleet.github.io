"""Complete Cholesky flows: generic-LU pullback vs structured pullback."""
import gc,hashlib,importlib.util,json,os,statistics,sys,time
from pathlib import Path
import numpy as np
paths=globals().get('bench_sources') or json.loads(os.environ['BENCH_SOURCES']);dtype=globals().get('bench_dtype',os.environ.get('BENCH_DTYPE','float64'));packages={};hashes={}
for label,path in paths.items():
 root=Path(path);name='chol_'+label;spec=importlib.util.spec_from_file_location(name,root/'__init__.py',submodule_search_locations=[str(root)]);p=importlib.util.module_from_spec(spec);sys.modules[name]=p;spec.loader.exec_module(p);packages[label]=p
 hashes[label]={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in root.iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')}
 assert p.__version__=='0.32.0'
configs=[('tiny-backward',2,(),False),('sgd-spd',16,(),False),('batch-backward',64,(4,),False),('large-backward',256,(),False),('upper-backward',256,(),True),('gaussian-backward',64,(),False),('jvp-control',16,(),True),('unary-control',0,(),False)];results={}
for operation,n,batch,upper in configs:
 calls={};checks={}
 for label,p in packages.items():
  lib=p.torch;tdtype=getattr(lib,dtype);rng=np.random.default_rng(32)
  raw=(rng.normal(size=batch+(n,n))*.02).astype(dtype)
  a=raw@raw.swapaxes(-1,-2)+np.eye(n,dtype=dtype)*2
  source=lib.tensor(raw if operation=='sgd-spd' else a,dtype=tdtype,requires_grad=True)
  identity=lib.eye(n,dtype=tdtype);optimizer=lib.optim.SGD([source],lr=.0001) if operation=='sgd-spd' else None
  if operation=='unary-control':
   source=lib.tensor(np.linspace(-.4,.7,32,dtype=dtype).reshape(4,8),requires_grad=True)
   def call(source=source):
    source.grad=None;x=source.sin().exp().tanh();x.square().mean().backward();return x
  elif operation=='jvp-control':
   direction=lib.ones_like(source)*.03
   def call(source=source,direction=direction,lib=lib,upper=upper):
    return lib.func.jvp(lambda a:lib.linalg.cholesky(a,upper=upper),(source,),(direction,))
  else:
   rhs=lib.tensor(rng.normal(size=batch+(n,4)).astype(dtype)*.1,dtype=tdtype)
   def call(source=source,lib=lib,upper=upper,operation=operation,identity=identity,optimizer=optimizer,rhs=rhs):
    source.grad=None;a=source@source.transpose(-1,-2)+identity if operation=='sgd-spd' else source
    factor=lib.linalg.cholesky(a,upper=upper)
    if operation=='gaussian-backward':
     z=lib.linalg.solve_triangular(factor,rhs,upper=False)
     loss=z.square().mean()+factor.diagonal(0,-2,-1).log().mean()
    else:loss=factor.square().mean()
    loss.backward()
    if optimizer is not None:optimizer.step()
    return factor
  calls[label]=call
  def check(call=call,source=source,operation=operation):
   x=call();outputs=x if operation=='jvp-control' else (x,)
   return [v.detach().numpy().copy() for v in outputs]+[source.numpy().copy(),None if source.grad is None else source.grad.numpy().copy()]
  checks[label]=check
 loops=3 if n>=256 else 10 if n>=64 else 60;warmup=5 if n>=64 else 30
 for call in calls.values():
  for _ in range(warmup):call()
 gc.collect();before=gc.get_stats();blocks=[]
 for block in range(9):
  order=('baseline','candidate','candidate','baseline') if block%2==0 else ('candidate','baseline','baseline','candidate');times={'baseline':[],'candidate':[]}
  for label in order:
   call=calls[label];start=time.perf_counter()
   for _ in range(loops):call()
   times[label].append((time.perf_counter()-start)*1e6/loops)
  blocks.append(dict(samples_us=times,time_reduction_percent=100*(1-statistics.mean(times['candidate'])/statistics.mean(times['baseline']))))
 values={label:check() for label,check in checks.items()}
 for actual,expected in zip(values['candidate'],values['baseline']):
  if expected is None:assert actual is None
  else:
   assert actual.dtype==expected.dtype==np.dtype(dtype);np.testing.assert_allclose(actual,expected,rtol=6e-5,atol=4e-6)
 results[operation]=dict(n=n,batch=batch,upper=upper,loops_per_sample=loops,warmup=warmup,blocks=blocks,median_time_reduction_percent=statistics.median(b['time_reduction_percent'] for b in blocks),final_checks='values,dtypes,gradients,JVP channels and actual updated parameters agree',gc_before=before,gc_after=gc.get_stats())
result=dict(python=sys.version,numpy=np.__version__,dtype=dtype,source_hashes=hashes,results=results,scope='Same0.32 forward/JVP implementation;baseline replaces only finite-diagonal pullback triangular systems with generic NumPy LU systems. This is not a0.31 release comparison:0.31 lacks Cholesky. Two isolated namespaces;GC enabled;9 paired ABBA/BAAB blocks;SGD includes SPD construction,forward,backward and parameter updates. Shared host;BLAS threading unverified. No CPU-WASM or nativeTorch relative-throughput claim.')
if 'bench_sources' not in globals():print(json.dumps(result))
