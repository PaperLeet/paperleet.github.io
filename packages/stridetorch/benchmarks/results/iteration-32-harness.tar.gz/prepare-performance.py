from pathlib import Path
import shutil,json,hashlib
r=Path(__file__).resolve().parent;source=r/'proof/source';target=r/'generic-lu-baseline';shutil.copytree(source,target,dirs_exist_ok=True)
p=target/'_cholesky.py';s=p.read_text();old='return _linalg._triangular_values(data, rhs, upper, left, False)';assert s.count(old)==1;s=s.replace(old,'return _linalg._solve_values(data, rhs, left)');p.write_text(s)
plan=dict(candidate=str(source),baseline=str(target),baseline_patch=dict(file='_cholesky.py',before=old,after='return _linalg._solve_values(data, rhs, left)'),candidate_hashes=json.loads((r/'proof/source-hashes.json').read_text()),baseline_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in target.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')})
(r/'performance-plan.json').write_text(json.dumps(plan,indent=2)+'\n');print('Frozen same-candidate generic-LU comparison')
