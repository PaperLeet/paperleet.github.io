from pathlib import Path
import json,subprocess,time
r=Path(__file__).resolve().parent;py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';deadline=time.monotonic()+900
while True:
 try:
  gates=json.loads((r/'proof-refined/gate-receipts.json').read_text());setup=json.loads((r/'integration-proof/setup-receipts.json').read_text());native=json.loads((r/'integration-proof/native-receipt.json').read_text())
 except (FileNotFoundError,json.JSONDecodeError):gates={};setup=[];native={}
 if any(v['exit_code']!=0 for v in gates.values()) or any(v['exit_code']!=0 for v in setup) or native.get('exit_code',0)!=0:raise RuntimeError('Compatibility/application pre-gate failure')
 if len(gates)==7 and len(setup)==4 and native.get('exit_code')==0:break
 if time.monotonic()>deadline:raise TimeoutError('Heavy compatibility/application gates pending')
 time.sleep(2)
print('All heavy pre-gates terminal0;sequential imports and paired timing begin',flush=True)
receipts=[]
for script in ('run-imports.py','run-performance-refined.py','close-core.py','integration-proof/run-wasm.py'):
 start=time.monotonic()
 with (r/(Path(script).stem+'-runner.log')).open('w') as log:p=subprocess.run([str(py),str(r/script)],cwd=r,stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(script=script,exit_code=p.returncode,elapsed_s=time.monotonic()-start));(r/'after-gates-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(script,'terminal',p.returncode,flush=True);p.check_returncode()
