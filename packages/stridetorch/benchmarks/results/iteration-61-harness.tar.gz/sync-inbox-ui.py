from pathlib import Path
import json,subprocess,hashlib,shutil
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');i=r/'integration-proof';d=r/'pre-adoption-f68';d.mkdir()
for source in [repo/'docs/validation/torch-runtime-iteration-61.md',repo/'packages/stridetorch/benchmarks/results/iteration-61.json',repo/'packages/stridetorch/benchmarks/results/iteration-61-harness.tar.gz',i/'latest-ui-qualification.json',r/'upstream-sync.json',r/'latest-main-audit.json']:shutil.copy2(source,d/source.name)
shutil.copy2(i/'latest-ui-qualification.json',i/'earlier-ui-qualification-f68.json')
for source in [repo/'docs/validation/torch-runtime-iteration-61.md',repo/'packages/stridetorch/benchmarks/results/iteration-61.json',repo/'packages/stridetorch/benchmarks/results/iteration-61-harness.tar.gz']:source.unlink()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head=='f68a351433318fea82beff85c7bb76aebf8b77b1'
paths=subprocess.check_output(['git','diff','--name-only','HEAD..origin/main'],cwd=repo,text=True).splitlines();assert len(paths)==10 and all(n.startswith(('web/src/','web/scripts/')) or n=='web/package.json' for n in paths)
owned=json.loads((r/'owned-input-sha256.json').read_text());sync=json.loads((r/'upstream-sync.json').read_text())
for name,h in owned.items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==h
subprocess.run(['git','merge','--ff-only','origin/main'],cwd=repo,check=True);after=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
for name,h in owned.items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==h
for name,h in sync['paths'].items():
 if name not in paths:assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==h
all_paths=sorted(set(sync['paths'])|set(paths));sync.update(after=after,intermediates=[sync['intermediate'],head],paths={n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in all_paths},scope='Disjoint article-outline, code-disclosure and inbox updates; unchanged earlier UI files and all numerical source/tests/owned inputs verified exactly.')
(r/'upstream-sync.json').write_text(json.dumps(sync,indent=2)+'\n');(i/'context.json').write_text(json.dumps(dict(upstream=after),indent=2)+'\n')
p=r/'verify-latest-ui.py';s=p.read_text();start=s.index('checks=[');end=s.index('\ndef run(',start);checks=['inbox','inbox-reading','browser-notifications','account','journey','workspace-intent','code-disclosure','reading-section-filter'];s=s[:start]+'checks='+repr(checks)+s[end:];s=s.replace('Affected article-outline filtering, long-code disclosure, reference/community code reading, keyboard, preview and workspace regression checks','Supplemental inbox/notification/account/journey ownership checks plus shared reading/workspace integration after disjoint inbox sync');p.write_text(s)
print('Latest UI sync',after,'supplemental checks',len(checks),'union paths',len(all_paths))
