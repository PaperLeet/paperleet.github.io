from pathlib import Path
import gc,importlib.util,json,sys,statistics,time
import numpy as np
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sys.path.insert(0,str(repo/'packages/stridetorch/benchmarks'));from bench_distances import load
old,oh=load('_det_old',r/'baseline-source/stridetorch');new,nh=load('_det_new',repo/'packages/stridetorch/src/stridetorch');rows=[]
for dtype in ['float32','float64']:
 for shape in [(2,2),(8,8),(32,32),(64,64),(4,8,8),(4,32,32)]:
  data=np.sin(np.arange(np.prod(shape))*.19+.2).reshape(shape);data=(data@data.swapaxes(-1,-2)/shape[-1]+np.eye(shape[-1])).astype(dtype)
  for kind in ['det','logdet','slogdet']:
   calls={};captures={}
   for label,module in [('baseline',old),('candidate',new)]:
    t=module.torch;x=t.tensor(data,requires_grad=True)
    def call(x=x,t=t,label=label,kind=kind):
     x.grad=None
     y=t.det(x) if kind=='det' else t.logdet(x) if label=='candidate' and kind=='logdet' else t.slogdet(x).logabsdet if label=='candidate' else t.det(x).abs().log()
     y.sum().backward();return y,x.grad
    calls[label]=call;captures[label]=[v.numpy().copy() for v in call()]
   for i,(a,b) in enumerate(zip(captures['candidate'],captures['baseline'])):
    if dtype=='float32' and i==1:
     error=a.astype('float64')-b.astype('float64');assert np.linalg.norm(error)/max(np.linalg.norm(b),np.finfo('float64').tiny)<3e-6;assert np.max(np.abs(error),initial=0)/max(np.max(np.abs(b),initial=0),np.finfo('float64').tiny)<3e-6
    else:np.testing.assert_allclose(a,b,rtol=3e-5 if dtype=='float32' else 3e-11,atol=3e-6 if dtype=='float32' else 3e-11)
   batches=32;samples={k:[] for k in calls}
   for rep in range(5):
    for label in (['baseline','candidate'] if rep%2==0 else ['candidate','baseline']):
     start=time.perf_counter()
     for _ in range(batches):calls[label]()
     samples[label].append((time.perf_counter()-start)/batches)
   med={k:statistics.median(v) for k,v in samples.items()};rows.append(dict(dtype=dtype,shape=shape,kind=kind,ratio=med['candidate']/med['baseline'],samples_s=samples))
(r/'det-performance-pilot.json').write_text(json.dumps(dict(rows=rows,source_hashes=dict(baseline=oh,candidate=nh),scope='CPU single-process pilot; fixed batches of 32, 5 alternating samples; ordinary SPD matrices only. Float32 gradients use a separately declared 3e-6 normwise old/new comparison because baseline SVD cofactors differ in cancellation-prone components; native/FP64 accuracy is checked separately. Log functions compare with old det.abs.log composition.'),indent=2)+'\n')
for row in rows:print(row['dtype'],row['shape'],row['kind'],round(row['ratio'],3))
