from pathlib import Path
import shutil,hashlib,json
r=Path(__file__).resolve().parent;p=r/'proof';d=r/'development-capability';d.mkdir()
for name in ['source','source-hashes.json','gate-receipts.json','node-wasm.log','chrome-worker.log','chrome-contracts/result.json']:
 q=p/name
 if q.is_dir():shutil.copytree(q,d/q.name)
 else:shutil.copy2(q,d/q.name)
for name in ['oracle-receipts.json','node-determinants.log','chrome-determinants.log']:shutil.copy2(r/name,d/name)
source=Path('/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src/stridetorch')
for f in [*source.glob('*.py'),source/'LICENSE',source/'NOTICE']:
 for dest in [p/'source',p/'chrome-contracts/source']:shutil.copy2(f,dest/f.name)
hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (p/'source').iterdir()};(p/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n');q=p/'chrome-contracts/plan.json';j=json.loads(q.read_text());j['source']=hashes;q.write_text(json.dumps(j,indent=2)+'\n')
repo=Path('/Users/david/Developer/PaperLeet-torch-release');owned=json.loads((r/'owned-source-paths.json').read_text());(r/'owned-input-sha256.json').write_text(json.dumps({n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in owned},indent=2)+'\n')
(r/'final-validation-context.json').write_text(json.dumps(dict(base=json.loads((r/'integration-proof/context.json').read_text())['upstream'],source_hashes=hashes,tests=j['tests']),indent=2)+'\n')
