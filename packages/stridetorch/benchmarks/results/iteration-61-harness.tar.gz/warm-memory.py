from pathlib import Path
import importlib.util,json,shutil,subprocess,time,os
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');path=repo/'packages/stridetorch/benchmarks/bench_determinants.py'
for name in ['memory.json','memory-receipt.json']:shutil.copy2(r/'performance'/name,r/'performance'/name.replace('memory','memory-cold-first'))
spec=importlib.util.spec_from_file_location('warm_memory_benchmark',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
baseline=r/'baseline-source/stridetorch';candidate=repo/'packages/stridetorch/src/stridetorch';started=time.monotonic()
for label,source in [('baseline',baseline),('candidate',candidate)]:
 module,_=m.load('_memory_priming_'+label,source)
 for dtype in ['float32','float64']:
  for shape in [(64,64),(4,32,32)]:
   data=m._data(shape,dtype)
   for operation in ['det','logdet','slogdet']:
    call,_=m._method(module,data,operation,True,label=='baseline');call()
result=m.memory(baseline,candidate);result['scope']+=' Both source namespaces and all measured determinant/log/weighted-backward paths are primed before tracing; the first-cold diagnostic is retained separately and is not interpreted as tape savings.'
(r/'performance/memory.json').write_text(json.dumps(result,indent=2)+'\n');(r/'performance/memory-receipt.json').write_text(json.dumps(dict(exit_code=0,elapsed_s=time.monotonic()-started,script=str(Path(__file__).resolve()),warmup=True,source_hashes=result['source_hashes']),indent=2)+'\n')
print(json.dumps([v for v in result['rows'] if v['operation']=='det' and v['input_shape']==[64,64]]))
