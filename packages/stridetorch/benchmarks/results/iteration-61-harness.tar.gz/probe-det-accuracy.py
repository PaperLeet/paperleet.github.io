from pathlib import Path
import sys,json
import numpy as np,torch as native
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sys.path.insert(0,str(repo/'packages/stridetorch/benchmarks'));from bench_distances import load
old,_=load('_accuracy_old',r/'baseline-source/stridetorch');new,_=load('_accuracy_new',repo/'packages/stridetorch/src/stridetorch');rows=[]
for shape in [(32,32),(64,64),(4,32,32)]:
 data=np.sin(np.arange(np.prod(shape))*.19+.2).reshape(shape);data=(data@data.swapaxes(-1,-2)/shape[-1]+np.eye(shape[-1])).astype('float32');x=native.tensor(data,requires_grad=True);native.det(x).sum().backward();ref=x.grad.numpy();d=native.tensor(data.astype('float64'),requires_grad=True);native.det(d).sum().backward();double=d.grad.numpy();arrays={}
 for label,m in [('baseline',old),('candidate',new)]:
  t=m.torch;a=t.tensor(data,requires_grad=True);t.det(a).sum().backward();arrays[label]=a.grad.numpy()
 metrics={}
 for label,a in [('native',ref),*arrays.items()]:
  delta=a.astype('float64')-double;metrics[label]=dict(relative_l2=float(np.linalg.norm(delta)/np.linalg.norm(double)),relative_linf=float(np.max(np.abs(delta))/np.max(np.abs(double))),native_component_failures=int(np.count_nonzero(np.abs(a-ref)>3e-6+3e-5*np.abs(ref))))
 rows.append(dict(shape=shape,metrics=metrics));print(shape,metrics)
(r/'det-accuracy-pilot.json').write_text(json.dumps(dict(native=native.__version__,rows=rows,scope='Exact float32 input matrices; FP64 native-Torch determinant gradient reference. Per-element native-float32 comparisons and separate normwise errors are reported, not conflated.'),indent=2)+'\n')
