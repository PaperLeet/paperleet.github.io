from pathlib import Path
import hashlib,json
import numpy as np
r=Path(__file__).resolve().parent;arrays={}
for dtype in ['float32','float64','complex64','complex128']:
    d=np.dtype(dtype);real=np.dtype('float32' if d.char in 'fF' else 'float64');small=1e-30 if real.itemsize==4 else 1e-200;large=1e20 if real.itemsize==4 else 1e100
    cases=[np.array([[2.,.3],[.4,3.]]),np.array([[1.,2.],[3.,4.]]),np.array([[1.,2.],[2.,4.]]),np.diag([1.,0.]),np.zeros((2,2)),np.empty((0,0)),np.empty((0,3,3)),np.broadcast_to(np.eye(3)*2,(2,1,3,3)).copy()]
    def dense(shape):
        x=np.sin(np.arange(np.prod(shape))*.19+.2).reshape(shape);return x@x.swapaxes(-1,-2)/shape[-1]+np.eye(shape[-1])
    cases+=[dense((2,3,8,8)),dense((32,32)),np.eye(4)*(1e-20 if real.itemsize==4 else 1e-100),np.eye(4)*large,np.diag([np.inf,1.]),np.diag([np.nan,1.]),np.array([[[2.,.3],[.4,3.]],[[1.,0.],[0.,0.]],[[1.,2.],[3.,4.]]]),np.array([[[np.nan,0.],[0.,1.]],[[0.,0.],[0.,0.]],[[np.inf,0.],[0.,1.]]]),np.zeros((1,1)),dense((64,64)),np.eye(2)*small,np.array([[-2.]])]
    for index,a in enumerate(cases):
        a=a.astype(d)
        if d.kind=='c' and index in [0,1,7,8,9,17]:a=a+np.asarray(1j,dtype=d)*np.eye(a.shape[-1])*.15
        key=f'{dtype}.{index}';arrays[key+'.a']=a;shape=a.shape[:-2]
        arrays[key+'.seed']=(np.sin(np.arange(np.prod(shape))+.3)+.5).reshape(shape).astype(real)
        if d.kind!='c':arrays[key+'.direction']=(np.cos(np.arange(a.size)*.13+.2)*.2).reshape(a.shape).astype(d)
np.savez_compressed(r/'determinant-inputs.npz',**arrays)
(r/'determinant-inputs.json').write_text(json.dumps(dict(arrays=len(arrays),cases=20,dtypes=4,sha256=hashlib.sha256((r/'determinant-inputs.npz').read_bytes()).hexdigest(),scope='Frozen exact matrices, weighted seeds and real directions. Positive-stride layouts are reconstructed identically in each runtime.'),indent=2)+'\n');print('frozen',len(arrays),'arrays')
