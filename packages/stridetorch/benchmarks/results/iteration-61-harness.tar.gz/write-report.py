from pathlib import Path
import json
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');j=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-61.json').read_text());rows=j['performance']['rows']
def table(selected):
 text='| Runtime | Operation | Dtype | Shape | Mode | Candidate / baseline | Four-child range |\n|---|---|---|---|---|---:|---:|\n'
 for v in selected:
  a,b=v['ratio_range'];text+=f"| {v['runtime']} | {v['operation']} | {v['dtype']} | {v['input_shape']} | {v['mode']} | {v['ratio_median']:.3f} | {a:.3f}–{b:.3f} |\n"
 return text
selected=[v for v in rows if v['operation']=='det' and v['shape']=='larger' and v['mode']=='full_step']
controls=[v for v in rows if v['operation']=='graph']
small=[v for v in rows if v['operation']=='det' and v['shape']=='small' and v['mode']=='forward']
worst=sorted([v for v in rows if v['matched'] and v['operation']!='graph'],key=lambda v:v['ratio_median'],reverse=True)[:8]
memory='| Variant | Operation | Dtype | Shape | Newly retained after forward | Forward peak | Backward peak |\n|---|---|---|---|---:|---:|---:|\n'
for v in j['memory']['rows']:
 if v['operation']=='det' and v['input_shape']==[64,64]:memory+=f"| {v['variant']} | {v['operation']} | {v['dtype']} | {v['input_shape']} | {v['new_retained_bytes']:,} | {v['forward_peak_bytes']:,} | {v['backward_peak_bytes']:,} |\n"
a=j['raw_archive'];b=j['source_footprint']['baseline'];c=j['source_footprint']['candidate']
text=f'''# Torch runtime iteration 61 — stable log determinants and adjoint det solves

Version **0.61.0** adds `torch.slogdet`, `torch.linalg.slogdet`, `torch.logdet`
and their Tensor methods. Ordinary invertible real `det` backward now solves the
adjoint system instead of computing an SVD and auxiliary determinants. Source
and final integration use base main `{j['baseline_main']}`. The full CPU/frontend/
catalog baseline is `{j['full_validation_baseline']}`; 29 affected checks at the code-reading update
and 8 supplemental checks at the inbox update, each with driver/policy/two-build
gates, qualify the later disjoint UI changes. Naming remains
StrideTorch pending the user's choice; no rename is bundled into this iteration.

## Behavior and implementation

Log determinants factor the matrix in log space, so an already overflowed or
underflowed determinant is not passed through `log`. Real float32/64 support
first-order reverse and JVP; complex64/128 support forward only. Batches, empty
matrices and strided layouts are covered. The result is a sign/logabsdet named
tuple. Output buffers, complex AD and det JVP remain explicit unsupported cases.
The [NumPy reference](https://numpy.org/doc/2.1/reference/generated/numpy.linalg.slogdet.html)
describes LU-based log determinants and their scale advantage;
[PyTorch slogdet](https://docs.pytorch.org/docs/2.14/generated/torch.linalg.slogdet.html)
and [logdet](https://docs.pytorch.org/docs/2.14/generated/torch.logdet.html) define
the public entry points. The concrete derivative and mutation behavior here is
verified against native PyTorch **2.14.1**, git
`5c4886908584029761b579af026dcfb627c84070`, rather than assumed from newer main.

Real slogdet sign is a differentiable output with an unused edge. Backward on
sign alone leaves input `.grad` as `None`, while both outputs share saved-graph
lifetime. The graph engine now supports an unused VJP edge without converting
it into a zero array, and releases its saved ancestors consistently with the
tested grad/backward frontiers. Input/sign saved-value mutation guards,
retained graphs and storage release are tested. Logabs output edits follow the
native unsaved-output behavior.

Real negative logdet gives NaN with zero slope. Singular log derivatives are
undefined; pivoted IEEE fallback solves preserve the tested Inf/NaN outcomes
without clipping or replacing zero pivots. JVP uses an immutable factor input
snapshot. Reverse through the JVP differentiates the direction and has no edge
to the original matrix, matching the pinned native saved-factor implementation.
This is not a claim of arbitrary higher derivatives or future-version parity.
The [pinned derivative source](https://github.com/pytorch/pytorch/blob/5c4886908584029761b579af026dcfb627c84070/torch/csrc/autograd/FunctionsManual.cpp)
is the implementation reference.

NaN pivot propagation is probed once on import with a 2×2 matrix. NumPy 1.26
CPU and the tested WASM build can otherwise misclassify NaN as a zero pivot.
Those runtimes scan for NaN batches; newer CPU NumPy avoids that scan. Complex
logdet assigns real/imaginary components separately: singular real `-Inf` must
survive a NaN phase. Qualification checks the two components independently;
complex `equal_nan` alone previously concealed a wrong real component.

Existing singular/extreme det polynomial-cofactor gradients and finite-real-input
restriction are retained and qualified separately from native log derivatives.
Raw log VJP/JVP reverse results match native column-major matrix layout. Stored
leaf gradients retain owned buffers. Native can reuse different positive
singleton-axis strides; ten arrays use the documented equivalent layout contract,
with all meaningful non-singleton strides checked exactly.

## Correctness and integration evidence

- Final frozen-source CPU regression: **40,970 passed, 1 skipped**. Source hashes
  are captured before and checked after the test process.
- Actual Node/Pyodide and Chrome Worker: **7,340 contracts each**, 54 independent
  suites, Pyodide 0.29.4 / NumPy 2.2.5. Chrome 155.0.8059.82.
- Installed public wheel on Python 3.10.19 / NumPy 1.26.4: **7,353 passed**,
  with native Torch absent. Public wheel/sdist and private vendored wheel match
  all **59 Python modules + LICENSE/NOTICE** byte for byte.
- Public/private packages coexist, each survives uninstalling the other, and
  aliases/state remain isolated. New logs, sign-only None gradients, JVP reverse
  and detached namedtuple pickle are checked in both installed namespaces.
  Fresh-process activation/model restores and native Torch isolation also pass.
  Direct pickle of live autograd graph outputs retains the existing limitation;
  the failed development probe is preserved, not reported as a passing check.
- **600 frozen cases per CPU/Node/Chrome**, also repeated on the isolated
  Python 3.10 / NumPy 1.26.4 installed wheel, from 200 exact input/seed/direction
  arrays: 480 native log cases; 54 ordinary native det cases; 48 separate legacy
  cofactor cases; 18 retained input-restriction cases. Each runtime checks 1,764
  numeric arrays and 360 None-gradient fields. Real logs include VJP, JVP and
  reverse through direction; complex cases are forward only. C/F/sliced layouts,
  batches, empty shapes, singular/negative determinants, tiny/huge scales and
  NaN/Inf are represented. The 48/18 legacy cases are **not native parity passes**.
- All **78 exported modules and 342 mutants** pass under original browser budgets.
  The 1,152 frozen native catalog input hashes are unchanged. All 54 independent
  suites are embedded in and checked by the exported application runtime.
- Full frontend checks, release-policy checks and both build profiles pass at
  the recorded full-validation baseline. The affected UI checks and driver/
  policy/two-build gates also pass at the final main UI base. After final runtime refresh, the WASM driver and
  both build profiles are repeated; numerical catalog tests use that final export.
  All **12,599 previously published payloads** remain byte-identical. The 158
  new assets are reachable; 161 active export/index identities are recorded.
- Seven release-policy files remain byte-identical to canonical
  `13d2782a494415ba72bc604a0ef7e4c4f875ba25`. No CI trigger, tag, dispatch,
  release, package upload or deployment is initiated.

Development failures and pilots remain in the raw archive. An owned pre-final
CPU run was explicitly stopped after its capability-probe source became obsolete;
its termination is recorded separately from the final completed regression.

## Performance against 0.60

Twelve fresh children (four each CPU/Node/Chrome) run 100 workflows each:
**88 matched** ordinary SPD determinant/log-composition or graph controls and
**12 candidate-only** complex forward workflows. Old logs are `det.log` and
`det.abs.log` compositions on positive SPD matrices; they are not equivalent
negative/singular APIs. Each child uses common calibrated batches of at least
20 ms and five alternating samples. Tables show the median of four per-child
ratios; below 1 is faster. Inputs/conversions/seeds are outside timing; dispatch,
graph construction, kernels, weighted backward and gradient clearing are inside.
Heavy correctness gates finish before formal timing. An observed unrelated local
WASM catalog job is also allowed to finish before timing; host-wide background
activity is not controlled. CPU thread caps are two.
There is no native-Torch, GPU, cold-start or universal-throughput comparison.

64×64 determinant forward + weighted backward:

{table(selected)}
Small determinant forward control:

{table(small)}
Unchanged scalar/vector graph controls:

{table(controls)}
The 64×64 logdet forward-only comparisons cost about 1.10–1.18 times the old
composition. Small forward-only logdet costs reach about 1.72 times; these
new-API common-path costs are a follow-up optimization target. Existing small
det forward is approximately unchanged, while full determinant/log backward
workflows benefit from the solve path. Graph-control medians include small
losses and remain visible below.

Largest matched ratios, including any losses:

{table(worst)}
All 300 runtime/workflow aggregate rows, child samples, candidate-only timings,
source hashes and calibration values are retained in the machine report/archive.
Float32 old/new SVD-versus-solve gradients have a separately labeled 1e-5
normwise comparison. Native accuracy uses the independent frozen oracle above.

## Memory and footprint

Warm CPU tracemalloc incremental tracked bytes, with inputs/seeds allocated before
tracing. Both source namespaces and all measured forward/backward paths are
primed by the archived `warm-memory.py` driver. The first-cold diagnostic is
retained separately; NumPy lazy initialization is not counted as tape savings. Forward retained/peak and backward peak are separate measurements;
these are not total tape bytes, RSS, LAPACK workspace or WASM heap size.

{memory}
The full 24-row allocation table is in the machine report. Source/license bytes
change from {b['source_license_bytes']:,} to {c['source_license_bytes']:,}; local
concatenated gzip from {b['local_concatenated_gzip_bytes']:,} to
{c['local_concatenated_gzip_bytes']:,} bytes. Gzip is a local footprint diagnostic,
not wheel or network transfer size.

## Reproduction and limits

[Machine report](../../packages/stridetorch/benchmarks/results/iteration-61.json)
and [raw harness](../../packages/stridetorch/benchmarks/results/iteration-61-harness.tar.gz).
Raw archive: {a['bytes']:,} bytes, SHA-256 `{a['sha256']}`. It contains baseline
and final sources, frozen native arrays/results, programs, runtime plans,
package artifacts, child receipts, full outputs and preserved development trials.
The repository benchmark is
`packages/stridetorch/benchmarks/bench_determinants.py`.

This iteration remains dense CPU/WASM. No WebGPU speedup or backend parity is
claimed. A diagnostic also reproduces an existing NumPy 2.5.4 strict-error-policy issue:
64×64 identity det raises a floating-point exception under `numpy.seterr(all="raise")`
in both baseline and candidate. It is not introduced by this change and remains
a follow-up; default-policy warnings and both probes are retained.
Existing half/complex AD, unsupported API and prior numerical limits
remain in force. GPU routing and independent-library quality remain part of the
active broader goal. This local milestone does not mark that goal complete.
'''
(repo/'docs/validation/torch-runtime-iteration-61.md').write_text(text);print('Wrote iteration-61 validation report')
