import fs from 'node:fs';import path from 'node:path';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const py=await loadPyodide({indexURL:'/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/',packageCacheDir:'/Users/david/Developer/PaperLeet-torch-release/web/public/browser-runtime/pyodide-0.29.4/',stdout(){},stderr(){}});await loadJudgePackages(py,[]);py.FS.mkdirTree('/runtime/stridetorch');
const source='/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src/stridetorch';
for(const name of fs.readdirSync(source).filter(n=>n.endsWith('.py')))py.FS.writeFile('/runtime/stridetorch/'+name,fs.readFileSync(path.join(source,name)));
console.log(py.runPython(`
import sys,json,numpy as np
sys.path.insert(0,'/runtime')
from stridetorch import torch as t
rows=[]
for dtype in [np.float32,np.float64,np.complex64,np.complex128]:
 for v in [0.,np.nan,np.inf]:
  a=np.diag(np.array([v,1.],dtype=dtype));s,l=np.linalg.slogdet(a);o=t.slogdet(t.tensor(a));z=t.logdet(t.tensor(a))
  rows.append(dict(dtype=str(a.dtype),entry=str(v),numpy_sign=str(s),numpy_log=str(l),sign=str(o.sign.item()),logabs=str(o.logabsdet.item()),logdet=str(z.item())))
json.dumps(rows)
`));
