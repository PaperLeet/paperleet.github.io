from pathlib import Path
import json,torch
r=Path(__file__).resolve().parent;rows=[]
for name,data in [('eye',[[1.,0.],[0.,1.]]),('positive',[[2.,.3],[.4,3.]]),('negative',[[1.,2.],[3.,4.]]),('rank1',[[1.,2.],[2.,4.]]),('zero',[[0.,0.],[0.,0.]])]:
 for op in ['det','logdet','slogdet']:
  for seed in [0.,1.,float('inf'),float('nan')]:
   x=torch.tensor(data,dtype=torch.float64,requires_grad=True);y=getattr(torch,op)(x);y=y.logabsdet if op=='slogdet' else y;y.backward(torch.tensor(seed));rows.append(dict(case=name,op=op,seed=seed,gradient=x.grad.tolist()))
(r/'native-determinant-seeds.json').write_text(json.dumps(rows,indent=2)+'\n')
for v in rows:
 if v['seed'] in [1.,float('inf')] and v['case'] in ['eye','negative','rank1']:print(v)
