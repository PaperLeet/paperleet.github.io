from pathlib import Path
import json,torch
r=Path(__file__).resolve().parent;rows=[]
for op in ['logdet','slogdet']:
 for agrad,egrad in [(False,False),(True,False),(False,True),(True,True)]:
  for changed in ['none','input','direction','tangent','sign','logabs']:
   a=torch.tensor([[2.,.3],[.4,3.]],dtype=torch.float64,requires_grad=agrad);e=torch.full_like(a,.2,requires_grad=egrad);p,t=torch.func.jvp(getattr(torch,op),(a,),(e,));value=t.logabsdet if op=='slogdet' else t;target={'none':None,'input':a,'direction':e,'tangent':value,'sign':p.sign if op=='slogdet' else None,'logabs':p.logabsdet if op=='slogdet' else p}[changed]
   with torch.no_grad():
    if target is not None:target.add_(1.)
   item=dict(op=op,agrad=agrad,egrad=egrad,changed=changed,tangent_requires_grad=value.requires_grad)
   try:value.sum().backward();item.update(status='ok',a_grad=a.grad is not None,e_grad=None if e.grad is None else e.grad.tolist())
   except Exception as err:item.update(status='error',error=type(err).__name__,message=str(err)[:90])
   rows.append(item)
(r/'native-log-jvp-guards.json').write_text(json.dumps(rows,indent=2)+'\n')
print([v for v in rows if v['agrad'] and v['egrad']]);print([v for v in rows if v['changed']=='none'])
