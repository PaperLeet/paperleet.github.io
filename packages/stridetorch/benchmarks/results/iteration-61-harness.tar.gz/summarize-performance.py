from pathlib import Path
import json,statistics,math
r=Path(__file__).resolve().parent;results=[]
for runtime in ['cpu','node','chrome']:
 runs=[]
 for repeat in range(4):
  j=json.loads((r/f'performance/{runtime}-{repeat}.json').read_text());runs.append(j.get('benchmark',j))
 assert all(len(v['rows'])==100 for v in runs)
 for index,first in enumerate(runs[0]['rows']):
  keys=['operation','dtype','shape','input_shape','mode','matched','baseline_kind'];meta={k:first[k] for k in keys};rows=[v['rows'][index] for v in runs]
  assert all({k:v[k] for k in keys}==meta for v in rows)
  ratios=[v['candidate_over_baseline'] for v in rows] if first['matched'] else []
  results.append(dict(runtime=runtime,**meta,candidate_median_us=statistics.median(v['median_s']['candidate'] for v in rows)*1e6,baseline_median_us=statistics.median(v['median_s']['baseline'] for v in rows)*1e6 if ratios else None,ratio_median=statistics.median(ratios) if ratios else None,ratio_range=[min(ratios),max(ratios)] if ratios else None,child_ratios=ratios))
summary=dict(status='measured',children=12,rows_per_child=100,matched_rows=88,candidate_only_rows=12,rows=results,scope=runs[0]['scope'])
(r/'performance-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for row in results:
 if (row['operation']=='det' and row['shape'] in ['small','larger']) or row['operation']=='graph' or (row['operation']=='logdet' and row['shape']=='larger'):
  print(row['runtime'],row['operation'],row['dtype'],row['shape'],row['mode'],round(row['ratio_median'],3),[round(v,3) for v in row['ratio_range']])
