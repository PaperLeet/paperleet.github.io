from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');p=r/'proof';i=r/'integration-proof';out=repo/'packages/stridetorch/benchmarks/results'
read=lambda n:json.loads((r/n).read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def save(f,v):f.write_text(json.dumps(v,indent=2)+'\n')
owned=read('owned-input-sha256.json')
for name,digest in owned.items():assert sha(repo/name)==digest,name
source={f.name:sha(f) for f in (repo/'packages/stridetorch/src/stridetorch').iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')};plan=read('proof/chrome-contracts/plan.json')
assert source==read('proof/source-hashes.json')==plan['source'] and len(source)==61
tests={f.name:sha(f) for f in (repo/'packages/stridetorch/tests').glob('test_*.py') if f.name!='test_standalone.py'};assert tests==plan['tests'] and len(tests)==54
cpu=read('full-root-receipt.json');assert cpu['exit_code']==0 and cpu['passed']==40970 and cpu['skipped']==1 and cpu['source_hashes']==source
node=read('proof/source-wasm.json');chrome=read('proof/chrome-contracts/result.json');wheel=read('proof/wheel-stride061-result.json');co=read('proof/coinstall-result.json')
assert node['passed']==chrome['passed']==7340 and chrome['test_hashes']==tests
assert node['source_hashes']==chrome['source_hashes']==wheel['source_hashes']==co['source_hashes']==source
assert all(v['status']=='success' for v in [chrome,wheel,co]) and not wheel['native_torch']
assert '7353 passed' in (p/'python310-stride061-tests.log').read_text()
gates=read('proof/gate-receipts.json');assert len(gates)==6 and all(v['exit_code']==0 for v in gates.values())
oracle_receipts=read('oracle-receipts.json');assert len(oracle_receipts)==2 and all(v['exit_code']==0 for v in oracle_receipts.values())
qual=read('determinants-qualification.json');on=read('proof/oracle-node-result.json');oc=read('proof/chrome-contracts/oracle-result.json')
for q in [qual,on['qualification'],oc['qualification']]:
 assert q['status']=='success' and q['source_hashes']==source
 assert q['counts']==dict(log_native_cases=480,det_native_cases=54,det_legacy_cases=48,det_restricted_cases=18,numeric_arrays=1764,none_gradients=360,singleton_layout_contract_arrays=10)
 assert q['input_sha256']==sha(r/'determinant-inputs.npz')
minimum=read('minimum-oracle-result.json');assert minimum['status']=='success' and minimum['source_hashes']==source and minimum['qualification']['counts']==qual['counts']
front=read('integration-proof/frontend-receipts.json');integration=read('integration-proof/receipts.json');assert len(front)==5 and len(integration)==2 and all(v['exit_code']==0 for v in front+integration)
builds=read('integration-proof/final-export-build-receipts.json');assert len(builds)==3 and all(v['exit_code']==0 for v in builds)
wasm=read('integration-proof/full-wasm-result.json');assert wasm['passed'] and wasm['modules']==wasm['catalog_modules']==78 and sum(v['mutants'] for v in wasm['results'])==342 and all(v['passed'] for v in wasm['results'])
assert not wasm['browser_budget_exceeded'] and all(not v['browser_budget_exceeded'] for v in wasm['results'])
contracts=next(v for v in wasm['results'] if v['id']=='architecture/attention')['independent_contracts'];assert contracts['passed']==7340 and len(contracts['suites'])==54 and {v['suite']:v['source_sha256'] for v in contracts['suites']}==tests
exports=read('integration-proof/export-identity.json');assert exports['published_assets_unchanged']==12599 and exports['new_assets']==exports['active_assets']==158
live={};data=repo/'web/public/data';index=json.loads((data/'index.json').read_text())
for entry in index['problems']:
 for name in [entry['detail_url'],entry['browser_judge']['bundle_url']]:live[name]=sha(data/name)
 manifest=json.loads((data/entry['browser_judge']['bundle_url']).read_text());name=manifest['runtime_bundle_url'];live[name]=sha(data/name)
for name in ['index.json','index-v3.json','catalog.json']:live[name]=sha(data/name)
assert len(live)==161;save(i/'live-expected-sha256.json',live)
policy=read('release-policy-identity.json')
for name,digest in policy['files'].items():assert sha(repo/name)==digest
runtime_identity=read('runtime-identity.json');assert runtime_identity['status']=='success' and len(runtime_identity['public_runtime_files'])==18
native=read('native-catalog-reuse.json');assert native['files']==1152
for name,digest in native['native_input_sha256'].items():assert sha(repo/name)==digest
isolation=read('native-isolation-result.json');assert isolation['status']=='success' and isolation['library_version']=='0.61.0'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head==read('integration-proof/context.json')['upstream']
full_baseline=read('integration-proof/full-suite-baseline.json')['upstream'];assert full_baseline==cpu['base_commit']
sync=read('upstream-sync.json');ui=read('integration-proof/latest-ui-qualification.json');assert sync['before']==full_baseline and sync['after']==head and ui['status']=='qualified' and ui['upstream']==head and ui['full_suite_baseline']==full_baseline
ui_stages=[read('integration-proof/earlier-ui-qualification-f68.json'),ui]
assert ui_stages[0]['upstream']=='f68a351433318fea82beff85c7bb76aebf8b77b1'
for stage in ui_stages:assert stage['status']=='qualified' and stage['full_suite_baseline']==full_baseline and len(stage['receipts'])==len(stage['checks'])+4 and all(v['exit_code']==0 for v in stage['receipts'])
for name,digest in sync['paths'].items():assert sha(repo/name)==digest
perf=read('performance/identity.json');receipts=read('performance/receipts.json');assert perf['status']=='success' and perf['children']==len(receipts)==12 and all(v['exit_code']==0 for v in receipts)
baseline=json.loads((r.parent/'torch-iteration-60/proof/source-hashes.json').read_text());assert perf['source_hashes']==dict(baseline=baseline,candidate=source);assert sha(repo/'packages/stridetorch/benchmarks/bench_determinants.py')==perf['benchmark_sha256']
for runtime in ['cpu','node','chrome']:
 for repeat in range(4):
  j=read(f'performance/{runtime}-{repeat}.json');j=j.get('benchmark',j);assert len(j['rows'])==100 and sum(v['matched'] for v in j['rows'])==88 and j['versions']==dict(baseline='0.60.0',candidate='0.61.0') and j['source_hashes']==perf['source_hashes']
environment=read('performance/environment.json');assert environment['numpy']=='2.5.4' and environment['machine']=='arm64'
memory=read('performance/memory.json');assert memory['source_hashes']==perf['source_hashes'] and len(memory['rows'])==24
fresh=[]
for name,python,path in [('stridetorch',p/'python310-stride061-env/bin/python',p/'stridetorch-activation.pkl'),('paperleet._vendor.torch',p/'coinstall-env/bin/python',p/'paperleet-_vendor-torch-activation.pkl')]:
 result=subprocess.run([str(python),'-I',str(r/'fresh-load.py'),name,str(path)],capture_output=True,text=True,cwd=r);assert result.returncode==0,result.stderr;fresh.append(dict(namespace=name,exit_code=0,output=result.stdout.strip()))
save(r/'fresh-load-result.json',fresh)
metadata=r/'package-metadata';metadata.mkdir(exist_ok=True)
for name in ['README.md','pyproject.toml','LICENSE','NOTICE']:shutil.copy2(repo/'packages/stridetorch'/name,metadata/name)
shutil.copy2(repo/'packages/stridetorch/tests/test_standalone.py',metadata/'test_standalone.py')
footprint={}
for label,folder,names in [('baseline',r/'baseline-source/stridetorch',baseline),('candidate',repo/'packages/stridetorch/src/stridetorch',source)]:
 payload=b''.join((folder/n).read_bytes() for n in sorted(names));footprint[label]=dict(source_license_bytes=len(payload),local_concatenated_gzip_bytes=len(gzip.compress(payload,mtime=0)))
archive=out/'iteration-61-harness.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as target:
 for current,dirs,files in os.walk(r):
  dirs[:]=[d for d in dirs if d not in ['__pycache__','.pytest_cache'] and not d.endswith(('-env','-venv'))]
  for name in sorted(files):
   f=Path(current)/name
   if f.name.endswith('.tar.gz') and any(part.startswith('pre-adoption-') for part in f.relative_to(r).parts):continue
   if not f.is_symlink() and (f.name in ['LICENSE','NOTICE'] or f.suffix in ['.py','.mjs','.json','.log','.md','.html','.toml','.npz','.txt','.whl','.pkl'] or f.name.endswith('.tar.gz')):target.add(f,arcname=f.relative_to(r),recursive=False)
assert archive.stat().st_size<95*1024*1024
report=dict(status='validated_locally',version='0.61.0',baseline_main=head,source_hashes=source,test_hashes=tests,owned_inputs=owned,additional_root_test_hashes={},changed_resources=sorted(n for n in baseline if source[n]!=baseline[n]),added_resources=sorted(source.keys()-baseline.keys()),added_tests=89,full_cpu=cpu,node_wasm=node,chrome_worker=chrome,minimal_wheel=wheel,coinstall=co,fresh_process=fresh,native_qualification=qual,minimum_qualification=minimum,node_qualification=on,chrome_qualification=oc,runtime_identity=runtime_identity,native_catalog_reuse=native,native_dtype_isolation=isolation,export_identity=exports,active_export_sha256=live,frontend=front,full_validation_baseline=full_baseline,upstream_sync=sync,latest_ui_qualification=ui,ui_qualification_stages=ui_stages,final_export_builds=builds,full_wasm=dict(modules=78,mutants=342,contracts=7340,suites=54,passed=True,browser_budget_exceeded=False),release_policy=policy,performance_identity=perf,performance=read('performance-summary.json'),performance_environment=environment,memory=memory,source_footprint=footprint,limitations=['Real first-order VJP/JVP only; complex64/128 forward only; no complex AD or output buffers.','Reverse-over-JVP matches pinned native 2.14.1 saved-factor behavior, not arbitrary higher derivatives.','Singular log derivatives are undefined; tested IEEE outcomes are preserved without regularization.','Existing singular/extreme det cofactor gradients and nonfinite-input rejection remain separate legacy contracts.','Native positive singleton gradient strides may differ under the documented shared layout contract; meaningful non-singleton strides match.','Direct pickle of live autograd graph outputs retains the existing limitation; detached Slogdet namedtuple pickle is verified.','88 matched SPD/composition/control benchmark rows and 12 candidate-only complex rows are measured separately; no native GPU or universal throughput claim.'],raw_archive=dict(name=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)))
save(out/'iteration-61.json',report);save(r/'state.json',dict(status='local_gates_passed',version='0.61.0',main_adoption_pending=True,source_hashes=source,active_export_sha256=live))
print(json.dumps(dict(status=report['status'],cpu=cpu['passed'],wasm=7340,wheel=7353,catalog=78,mutants=342,raw_archive=report['raw_archive'])))
