from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;i=r/'integration-proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release');receipts=[]
assert all(v['exit_code']==0 for v in json.loads((i/'export-receipts.json').read_text()))
env=dict(os.environ,PATH='/opt/homebrew/bin:'+os.environ['PATH'],PYTHON=str(r.parent/'torch-iteration-21/stride-dev-env/bin/python'));profile=json.loads((i/'pages-profile.json').read_text())['environment']
for label,args,cwd,extra in [('final-wasm-driver',['/opt/homebrew/bin/node','web/scripts/check-wasm-cases.mjs'],repo,{}),('final-default-build',['npm','run','build'],repo/'web',{}),('final-pages-build',['npm','run','build'],repo/'web',profile)]:
 started=time.monotonic()
 with (i/(label+'.log')).open('w') as log:p=subprocess.run(args,cwd=cwd,env={**env,**extra},stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(label=label,args=args,cwd=str(cwd),environment=extra,exit_code=p.returncode,elapsed_s=time.monotonic()-started));(i/'final-export-build-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(label,'terminal',p.returncode,flush=True);p.check_returncode()
