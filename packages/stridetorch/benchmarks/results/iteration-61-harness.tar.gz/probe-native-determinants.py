from pathlib import Path
import json,warnings
import numpy as np,torch
r=Path(__file__).resolve().parent
cases={'positive':[[2.,.3],[.4,3.]],'negative':[[1.,2.],[3.,4.]],'rank1':[[1.,2.],[2.,4.]],'diagzero':[[1.,0.],[0.,0.]],'zero':[[0.,0.],[0.,0.]],'infdiag':[[float('inf'),0.],[0.,1.]],'nanentry':[[float('nan'),0.],[0.,1.]],'empty':np.empty((0,0)),'small':np.eye(4)*1e-30,'large':np.eye(4)*1e30}
def array(t):
 x=t.detach().clone().numpy();return dict(shape=list(x.shape),dtype=str(x.dtype),real=x.real.tolist(),imag=x.imag.tolist() if np.iscomplexobj(x) else None,requires_grad=t.requires_grad)
rows=[]
for dtype in [torch.float32,torch.float64,torch.complex64,torch.complex128]:
 for name,data in cases.items():
  for op in ['det','slogdet','logdet']:
   x=torch.tensor(data,dtype=dtype,requires_grad=not dtype.is_complex);fn=getattr(torch,op);item=dict(dtype=str(dtype),case=name,op=op)
   try:
    y=fn(x);outs=tuple(y) if op=='slogdet' else (y,);item['values']=[array(v) for v in outs]
    if not dtype.is_complex:
     selected=outs[-1];selected.sum().backward();item['grad']=array(x.grad)
     a=torch.tensor(data,dtype=dtype,requires_grad=True);e=torch.full_like(a,.2,requires_grad=True)
     primal,tangent=torch.func.jvp(fn,(a,),(e,));ts=tuple(tangent) if op=='slogdet' else (tangent,);item['tangent']=[array(v) for v in ts]
     total=ts[-1].sum();ga,ge=torch.autograd.grad(total,(a,e),allow_unused=True);item['jvp_reverse']=[array(v) if v is not None else None for v in [ga,ge]]
    item['status']='ok'
   except Exception as exc:item.update(status='error',error=type(exc).__name__,message=str(exc)[:160])
   rows.append(item)
(r/'native-determinant-probe.json').write_text(json.dumps(dict(version=torch.__version__,rows=rows),indent=2)+'\n')
for v in rows:
 if v['dtype']=='torch.float64' and v['op'] in ['slogdet','logdet']:
  print(v['case'],v['op'],v['status'],'values',v.get('values'),'grad',v.get('grad'),'tangent',v.get('tangent'),'jvp_reverse',v.get('jvp_reverse'))
