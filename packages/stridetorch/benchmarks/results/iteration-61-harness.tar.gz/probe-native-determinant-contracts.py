from pathlib import Path
import json,torch
r=Path(__file__).resolve().parent;rows=[]
for op in ['det','slogdet','logdet']:
 for part in (['sign','logabs','both'] if op=='slogdet' else ['value']):
  for mutation in ['none','input','sign','logabs']:
   x=torch.tensor([[2.,.3],[.4,3.]],dtype=torch.float64,requires_grad=True);raw=getattr(torch,op)(x);sign,logabs=raw if op=='slogdet' else (None,raw);value=sign if part=='sign' else sign+logabs if part=='both' else logabs
   with torch.no_grad():
    target={'none':None,'input':x,'sign':sign,'logabs':logabs}[mutation]
    if target is not None:target.add_(1.)
   row=dict(op=op,part=part,mutation=mutation)
   try:value.sum().backward();row.update(status='ok',gradient=None if x.grad is None else x.grad.tolist())
   except Exception as e:row.update(status='error',error=type(e).__name__,message=str(e)[:100])
   rows.append(row)
(r/'native-determinant-contracts.json').write_text(json.dumps(dict(native=torch.__version__,git=torch.version.git_version,rows=rows),indent=2)+'\n')
print('native',torch.__version__,torch.version.git_version)
for row in rows:print(row)
