from pathlib import Path
import hashlib,json,subprocess,shutil
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-60';repo=Path('/Users/david/Developer/PaperLeet-torch-release');i=r/'integration-proof';i.mkdir(exist_ok=True)
for name in ['integration-proof/run-export.py','integration-proof/run-frontend.py','integration-proof/verify-export.py','run-front-only.py','run-full-wasm-only.py']:
 s=(old/name).read_text().replace('torch-iteration-60','torch-iteration-61').replace('len(published)==12441','len(published)==12599');(r/name).write_text(s)
(i/'context.json').write_text(json.dumps(dict(upstream='6bea37defe5950867a87b6b69acccaf5b9a93606'),indent=2)+'\n')
policies=['.github/workflows/ci.yml','.github/workflows/pages.yml','web/scripts/check-release-request.cjs','web/scripts/pages-release-gate.cjs','web/scripts/check-pages-release.cjs','web/scripts/check-pages-backfill.cjs','docs/releasing.md'];hashes={}
for name in policies:
 data=(repo/name).read_bytes();assert data==subprocess.check_output(['git','show','13d2782a494415ba72bc604a0ef7e4c4f875ba25:'+name],cwd=repo);hashes[name]=hashlib.sha256(data).hexdigest()
(r/'release-policy-identity.json').write_text(json.dumps(dict(canonical='13d2782a494415ba72bc604a0ef7e4c4f875ba25',files=hashes),indent=2)+'\n')
owned=[line[3:] for line in subprocess.check_output(['git','status','--short'],cwd=repo,text=True).splitlines()];assert len(owned)==10 and all(n.startswith('packages/stridetorch/') for n in owned)
(r/'owned-source-paths.json').write_text(json.dumps(owned,indent=2)+'\n');(r/'owned-input-sha256.json').write_text(json.dumps({n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in owned},indent=2)+'\n')
print('Integration prepared; seven canonical policies unchanged;',len(owned),'owned source paths')
