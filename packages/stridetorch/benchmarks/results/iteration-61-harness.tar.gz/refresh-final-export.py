from pathlib import Path
import json,subprocess,hashlib,shutil
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');i=r/'integration-proof'
assert len(json.loads((i/'frontend-receipts.json').read_text()))==5 and all(v['exit_code']==0 for v in json.loads((i/'frontend-receipts.json').read_text()))
d=r/'development-export';d.mkdir()
for name in ['export-identity.json','export-receipts.json','frontend-receipts.json','receipts.json','pages-profile.json']:
 shutil.copy2(i/name,d/name)
paths=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z','--','web/public/data/browser-judge','web/public/data/modules'],cwd=repo).decode().strip('\0').split('\0')
assert len(paths)==158 and all(n.endswith('.json') for n in paths)
record={n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in paths};(d/'obsolete-export-sha256.json').write_text(json.dumps(record,indent=2)+'\n')
for name in paths:(repo/name).unlink()
print('Removed exactly 158 owned obsolete untracked exports; published assets preserved')
