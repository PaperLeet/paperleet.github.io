from pathlib import Path
import importlib.util,json,sys,warnings
import numpy as np
r=Path(__file__).resolve().parent;variant=sys.argv[1];p=r/'baseline-source/stridetorch' if variant=='baseline' else Path('/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src/stridetorch');spec=importlib.util.spec_from_file_location('_fenv_probe_'+variant,p/'__init__.py',submodule_search_locations=[str(p)]);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m
np.seterr(all='raise');rows=[]
with warnings.catch_warnings(record=True) as records:
 spec.loader.exec_module(m);t=m.torch
 for dtype in [np.float32,np.float64]:
  for n in [2,64]:
   try:
    x=t.tensor(np.eye(n,dtype=dtype),requires_grad=True);y=x.det();y.backward();rows.append(dict(dtype=str(np.dtype(dtype)),size=n,status='ok',value=y.item(),gradient_finite=bool(np.isfinite(x.grad.numpy()).all())))
   except Exception as e:rows.append(dict(dtype=str(np.dtype(dtype)),size=n,status='error',error=type(e).__name__,message=str(e)))
 j=dict(variant=variant,rows=rows,warnings=[str(x.message) for x in records],error_policy=np.geterr())
(r/('fenv-import-'+variant+'.json')).write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j))
