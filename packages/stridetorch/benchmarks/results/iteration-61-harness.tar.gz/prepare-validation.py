from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-60';repo=Path('/Users/david/Developer/PaperLeet-torch-release');p=r/'proof';c=p/'chrome-contracts';c.mkdir(parents=True,exist_ok=True)
source=repo/'packages/stridetorch/src/stridetorch';tests=repo/'packages/stridetorch/tests'
def hashes(files):return {f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
for f in [*source.glob('*.py'),source/'LICENSE',source/'NOTICE']:
 (p/'source').mkdir(exist_ok=True);shutil.copy2(f,p/'source'/f.name)
prior=json.loads((old/'proof/chrome-contracts/plan.json').read_text());testnames=[*prior['tests'],'test_logdet.py']
(c/'tests').mkdir(exist_ok=True)
for name in testnames:shutil.copy2(tests/name,c/'tests'/name)
shutil.copytree(p/'source',c/'source',dirs_exist_ok=True)
plan=dict(source=hashes((p/'source').iterdir()),tests=hashes((c/'tests').glob('*.py')),version='0.61.0',expected=7340)
assert len(plan['source'])==61 and len(plan['tests'])==54
(c/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');(p/'source-hashes.json').write_text(json.dumps(plan['source'],indent=2)+'\n');(p/'test-hashes.json').write_text(json.dumps(plan['tests'],indent=2)+'\n')
for target,origin in [('fixture-server.mjs','fixture-server.mjs'),('run-gates.py','run-gates.py'),('proof/wasm-contracts.mjs','proof/wasm-contracts.mjs'),('proof/chrome-contracts/run.mjs','proof/chrome-contracts/run.mjs'),('proof/chrome-contracts/worker.mjs','proof/chrome-contracts/worker.mjs'),('proof/chrome-contracts/index.html','proof/chrome-contracts/index.html'),('proof/check-wheel.py','proof/check-wheel.py'),('proof/check-coinstall.py','proof/check-coinstall.py')]:
 text=(old/origin).read_text().replace('torch-iteration-60','torch-iteration-61').replace('0.60.0','0.61.0').replace('stride060','stride061').replace('==7251','==7340').replace('==58','==59').replace('package_modules=58','package_modules=59')
 (r/target).write_text(text)
# Native qualification uses the exact same programs and frozen arrays in CPU/Node/Chrome.
s=(old/'prepare-oracle.py').read_text();start=s.index("files=[");end=s.index('\nfor name in files:',start)
s=s[:start]+"files=['differential-determinants.py','qualify-determinants.py','native-determinants.json','native-determinants.npz','baseline-determinants.json','baseline-determinants.npz','determinant-inputs.npz','determinant-inputs.json']"+s[end:]
start=s.index("sys.argv=['/oracle/differential-distance-controls.py'");end=s.index("script='/oracle/qualify-distances.py'",start)
s=s[:start]+s[end:];s=s.replace('differential-distances','differential-determinants').replace('qualify-distances','qualify-determinants').replace('distances-qualification','determinants-qualification').replace('Distance qualification','Determinant qualification')
(r/'prepare-oracle.py').write_text(s)
s=(old/'prepare-bench.py').read_text().replace('bench_distances','bench_determinants');(r/'prepare-bench.py').write_text(s)
s=(old/'run-bench-final.py').read_text().replace('bench_distances','bench_determinants').replace("len(actual['rows'])==78","len(actual['rows'])==100");(r/'run-bench-final.py').write_text(s)
print('Prepared',len(plan['source']),'resources and',len(plan['tests']),'SDK suites')
