from pathlib import Path
import json,sys,warnings
import numpy as np
from stridetorch import torch
r=Path(__file__).resolve().parent;native=json.loads((r/'native-determinant-probe.json').read_text());cases={'positive':[[2.,.3],[.4,3.]],'negative':[[1.,2.],[3.,4.]],'rank1':[[1.,2.],[2.,4.]],'diagzero':[[1.,0.],[0.,0.]],'zero':[[0.,0.],[0.,0.]],'infdiag':[[np.inf,0.],[0.,1.]],'nanentry':[[np.nan,0.],[0.,1.]],'empty':np.empty((0,0)),'small':np.eye(4)*1e-30,'large':np.eye(4)*1e30};failures=[];passed=0

def compare(actual,expected,label):
 global passed
 if expected is None:assert actual is None,label;return
 x=actual.detach().numpy();dtype=np.dtype(expected['dtype']);want=np.asarray(expected['real'],dtype='float64')
 if expected['imag'] is not None:want=want+1j*np.asarray(expected['imag'])
 want=want.reshape(expected['shape']);assert x.shape==want.shape and x.dtype==dtype,(label,x.shape,x.dtype,want.shape,dtype)
 assert actual.requires_grad==expected['requires_grad'],(label,'requires_grad',actual.requires_grad,expected['requires_grad'])
 np.testing.assert_allclose(x,want,rtol=3e-5 if dtype.itemsize in [4,8] and dtype.char in 'fF' else 3e-12,atol=3e-6 if dtype.char in 'fF' else 3e-12,equal_nan=True,err_msg=label);passed+=1
for n in native['rows']:
 if n['op']=='det':continue
 key='.'.join([n['dtype'],n['case'],n['op']]);dtype=getattr(torch,n['dtype'].split('.')[-1]);x=torch.tensor(cases[n['case']],dtype=dtype,requires_grad=np.dtype(dtype).kind!='c')
 try:
  out=getattr(torch,n['op'])(x);outs=tuple(out) if n['op']=='slogdet' else (out,)
  for i,v in enumerate(outs):compare(v,n['values'][i],key+'.value'+str(i))
  if np.dtype(dtype).kind!='c':
   outs[-1].sum().backward();compare(x.grad,n['grad'],key+'.grad')
   a=torch.tensor(cases[n['case']],dtype=dtype,requires_grad=True);e=torch.full_like(a,.2,requires_grad=True);p,t=torch.func.jvp(getattr(torch,n['op']),(a,),(e,));ts=tuple(t) if n['op']=='slogdet' else (t,)
   for i,v in enumerate(ts):compare(v,n['tangent'][i],key+'.tangent'+str(i))
   ga,ge=torch.autograd.grad(ts[-1].sum(),(a,e),allow_unused=True)
   for i,v in enumerate([ga,ge]):compare(v,n['jvp_reverse'][i],key+'.reverse'+str(i))
 except Exception as err:failures.append(dict(key=key,error=str(err)[:650]))
print('arrays passed',passed,'failures',len(failures));print(json.dumps(failures,indent=2));(r/'first-native-comparison.json').write_text(json.dumps(dict(passed=passed,failures=failures),indent=2)+'\n')
