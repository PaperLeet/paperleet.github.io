"""Collect actual WASM controls serially, preserving the existing raw failure."""
from pathlib import Path
import hashlib,json,os,subprocess,time,traceback

r=Path(__file__).resolve().parent;b=r.parent
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
plan=read(r/'execution-plan.json');receipts=[];reviews={}

def verify():
    for path,digest in plan['inputs'].items():assert sha(Path(path))==digest,path
    assert sha(Path(__file__))==plan['runner_sha256']

def progress(status,**details):
    write(r/'progress.json',dict(status=status,supervisor_pid=os.getpid(),observed_unix=time.time(),receipts=receipts,**details))

try:
    assert read(b/'torch-iteration-288/progress.json')['status']=='completed'
    assert read(b/'torch-iteration-288/result.json')['status']=='passed_source284_full_sdk_cpu_minimum'
    for runtime in ['node','chrome']:
        verify();command=['/opt/homebrew/bin/node',str(r/(runtime+'.mjs')),'norm']
        with (r/(runtime+'.log')).open('w') as log:
            child=subprocess.Popen(command,cwd=r,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=log,stderr=subprocess.STDOUT)
            progress('running',runtime=runtime,pid=child.pid,command=command);code=child.wait()
        receipt=dict(runtime=runtime,exit_code=code,command=command,log_sha256=sha(r/(runtime+'.log')))
        receipts.append(receipt);write(r/'receipts.json',receipts);print(json.dumps(receipt),flush=True)
        assert code==0,receipt;verify()
        wrapped=read(r/(runtime+'-norm.json'));report=wrapped.get('report',wrapped)
        assert report['dont_write_bytecode']
        assert report['tests']==dict(passed=12212,expected_passed=12212,skipped=0,exit_code=0,failures=[])
        assert all(not report[key]['findings'] for key in ['comparison','composition','zero_chains'])
        assert report['paths']['selections']==dict(three_reverse=4480) and not report['paths']['missing_rules'] and report['paths']['context_restored']
        assert all(value['matched']==612 and not value['findings'] for value in report['binary'].values())
        assert report['private_lifetime']['status']=='passed' and report['private_lifetime']['calls']==300
        previous=read(b/('torch-iteration-279/'+runtime+'-norm.json'));previous=previous.get('report',previous)
        same_hvp=report['hvp_probe']['rows']==previous['hvp_probe']['rows']
        same_power=report['power']==previous['power']
        review=dict(tests=report['tests'],raw_native_status=report['status'],raw_hvp_counts=report['hvp']['counts'],
                    raw_hvp_findings=report['hvp']['findings'],hvp_rows_equal_parent272=same_hvp,
                    power_findings_equal_parent272=same_power,binary_cases_per_native=612,
                    private_lifetime_calls=300,private_owners_remaining=0,
                    report_sha256=sha(r/(runtime+'-norm.json')))
        reviews[runtime]=review;write(r/'review.json',reviews)
        assert same_hvp and same_power,'New WASM differences require review; original raw results retained'
    result=dict(status='completed_wasm_observations_existing_raw_native_point_gate_failed',reviews=reviews,
                original_raw_native_point_gate_passed=False,new_binary_findings=0,new_hvp_or_power_changes=0,
                selected=False,performance_qualified=False,main_adopted=False,ci_triggered=False,
                canonical_source_changed=False,goal_status='active',receipts=receipts)
    write(r/'result.json',result);progress('completed',result_status=result['status'])
    print(json.dumps(dict(status=result['status'],sdk_passed_per_runtime=12212,new_binary_findings=0,new_hvp_or_power_changes=0)),flush=True)
except BaseException as error:
    progress('failed',error=str(error),traceback=traceback.format_exc());raise
