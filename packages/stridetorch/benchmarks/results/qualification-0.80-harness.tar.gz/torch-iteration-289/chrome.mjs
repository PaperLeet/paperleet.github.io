import fs from 'node:fs';
import assert from 'node:assert/strict';
import {withFixtureServer} from '../torch-iteration-70/fixture-server.mjs';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';

const variant=process.argv[2];
assert.ok(['registry','norm'].includes(variant));
await withFixtureServer(async origin=>{
  const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
  try{
    const page=await browser.newPage();
    page.on('console',event=>console.log(event.text()));
    await page.goto(origin+'/torch-iteration-289/index.html');
    const result=await page.evaluate(variant=>new Promise((resolve,reject)=>{
      const worker=new Worker('./worker.mjs',{type:'module'});
      worker.onmessage=({data})=>{
        if(data.type==='progress'||data.type==='diagnostic'){console.log(data.message);return;}
        worker.terminate();resolve(data);
      };
      worker.onerror=event=>{worker.terminate();reject(Error(event.message));};
      worker.postMessage({variant});
    }),variant);
    fs.writeFileSync(new URL(`chrome-${variant}.json`,import.meta.url),JSON.stringify({...result,browser:browser.version()},null,2)+'\n');
    assert.equal(result.status,'completed',JSON.stringify(result));
    assert.equal(result.report.dont_write_bytecode,true);
    console.log(JSON.stringify({variant,status:result.report.status,tests:result.report.tests}));
  }finally{await browser.close();}
});
