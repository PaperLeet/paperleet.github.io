import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
import {loadJudgePackages} from '../torch-iteration-76/chrome-sdk/packages.mjs';

self.onmessage=async ({data:{variant}})=>{
  try{
    if(!['registry','norm'].includes(variant))throw Error('Unknown variant');
    const response=await fetch(`./wasm-plan-${variant}.json`);
    if(!response.ok)throw Error('Missing frozen runtime plan');
    const plan=await response.json();
    const py=await loadPyodide({indexURL:new URL('../torch-iteration-76/runtime/',self.location.href).href,
      stdout(message){self.postMessage({type:'progress',message});},
      stderr(message){self.postMessage({type:'diagnostic',message});}});
    await loadJudgePackages(py,[]);
    for(const [name,item] of Object.entries(plan.files)){
      const fetched=await fetch(new URL(item.source,self.location.href));
      if(!fetched.ok)throw Error('Missing frozen input '+name);
      const bytes=new Uint8Array(await fetched.arrayBuffer());
      const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
      if(digest!==item.sha256)throw Error('Source mismatch '+name);
      py.FS.mkdirTree('/'+name.split('/').slice(0,-1).join('/'));
      py.FS.writeFile('/'+name,bytes);
    }
    py.runPython("exec(compile(open('/wasm-check.py').read(), '/wasm-check.py', 'exec'))");
    const report=JSON.parse(py.runPython('json.dumps(wasm_report)'));
    self.postMessage({type:'result',status:'completed',variant,report,pyodide:py.version,programs:plan.files});
  }catch(error){self.postMessage({type:'result',status:'failed',error:String(error),stack:error.stack});}
};
