import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
import {loadJudgePackages} from '../torch-iteration-76/chrome-sdk/packages.mjs';

const variant=process.argv[2];
assert.ok(['registry','norm'].includes(variant));
const root=new URL('./',import.meta.url);
const plan=JSON.parse(fs.readFileSync(new URL(`wasm-plan-${variant}.json`,root)));
const py=await loadPyodide({indexURL:new URL('../torch-iteration-76/runtime/',root).pathname,
  stdout(message){console.log(message);},stderr(message){console.error(message);}});
await loadJudgePackages(py,[]);
for(const [name,item] of Object.entries(plan.files)){
  const bytes=fs.readFileSync(new URL(item.source,root));
  assert.equal(createHash('sha256').update(bytes).digest('hex'),item.sha256,name);
  py.FS.mkdirTree('/'+name.split('/').slice(0,-1).join('/'));
  py.FS.writeFile('/'+name,bytes);
}
py.runPython("exec(compile(open('/wasm-check.py').read(), '/wasm-check.py', 'exec'))");
const report=JSON.parse(py.runPython('json.dumps(wasm_report)'));
assert.equal(report.dont_write_bytecode,true);
assert.equal(report.tests.expected_passed,plan.expected_tests);
fs.writeFileSync(new URL(`node-${variant}.json`,root),JSON.stringify({...report,pyodide:py.version,node:process.version,programs:plan.files},null,2)+'\n');
console.log(JSON.stringify({variant,status:report.status,tests:report.tests}));
