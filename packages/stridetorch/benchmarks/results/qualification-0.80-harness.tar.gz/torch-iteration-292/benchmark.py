"""Measure all12 HVP flows including both norm compositions.

Four-label Williams blocks retain duplicate-main controls and pairwise version
comparisons. Correctness, data fingerprints and imports are outside timings.
"""
from pathlib import Path
from collections import Counter
import argparse,gc,hashlib,importlib.util,json,math,random,statistics,sys,time
import numpy as np

r=Path(__file__).resolve().parent
sys.dont_write_bytecode=True

def load_file(name,filename):
    spec=importlib.util.spec_from_file_location(name,r/filename)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

common=load_file('_hvp_benchmark_common','benchmark-common.py')
hvp=load_file('_hvp_benchmark_flows','benchmark-hvp.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def elapsed(function,count):
    wall,cpu=time.perf_counter(),time.process_time()
    for _ in range(count):function()
    return dict(iterations=count,elapsed_seconds=time.perf_counter()-wall,
                process_seconds=time.process_time()-cpu,started_monotonic=wall)

def balanced_orders(labels,seed):
    assert len(labels)==4 and len(set(labels))==4
    indices=[[(value+offset)%4 for value in [0,1,3,2]] for offset in range(4)]
    random.Random(seed).shuffle(indices)
    rows=[[labels[index] for index in row] for row in indices]
    assert Counter((i,label) for row in rows for i,label in enumerate(row))==Counter(
        {(i,label):1 for i in range(4) for label in labels})
    assert Counter((a,b) for row in rows for a,b in zip(row,row[1:]))==Counter(
        {(a,b):1 for a in labels for b in labels if a!=b})
    return rows


def calibrate(functions,labels):
    assert not gc.isenabled()
    count=max(common.calibrate(functions[label]) for label in labels)
    history=[]
    for attempt in range(5):
        observations=[{label:elapsed(functions[label],count) for label in order}
                      for order in [labels,list(reversed(labels))]]
        fastest=min(value['elapsed_seconds'] for observation in observations for value in observation.values())
        history.append(dict(iterations=count,observations=observations,minimum_chunk_seconds=fastest))
        if fastest>=.1:return count,history
        count=max(count+1,math.ceil(count*.15/max(fastest,1e-9)))
    print('HVP_CALIBRATION_FAILURE '+json.dumps(history),flush=True)
    raise RuntimeError('Calibration failed to establish 100ms chunks with measurement GC mode')

def run(cycle,validate_only):
    plan=json.loads((r/'plan.json').read_text())
    for name,digest in plan['files'].items():assert sha(r/name)==digest,name
    if not validate_only:
        prerequisites=json.loads((r/'measurement-prerequisites.json').read_text())
        assert prerequisites['owned_heavy_jobs_terminal'] and prerequisites['numerical_controls_inspected']
        assert prerequisites['plan_sha256']==sha(r/'plan.json')
    before={name:{p.name:sha(p) for p in (r/'variants'/name/'stridetorch').iterdir() if p.is_file()}
            for name in set(plan['labels'].values())}
    modules={label:common.load(r/'variants'/variant/'stridetorch','hvp_'+label)
             for label,variant in plan['labels'].items()}
    specs=list(hvp.specifications());assert len(specs)==12
    random.Random(194000+cycle).shuffle(specs);rows=[]
    pairs=[('A1','A0'),('B','A0'),('C','A0'),('C','B')]
    for index,spec in enumerate(specs):
        raw=hvp.make_inputs(spec);arrays=[*raw[0],*raw[1]]
        fingerprints=[hashlib.sha256(array.tobytes()).hexdigest() for array in arrays]
        for module in modules.values():
            for array in arrays:
                tensor=module.torch.from_numpy(array)
                assert tensor.data_ptr()==array.__array_interface__['data'][0]
                del tensor
        functions={label:hvp.flow(module,spec,raw,label not in ['A0','A1'])
                   for label,module in modules.items()}
        expected=functions['A0']()
        for function in functions.values():
            actual=function();assert len(actual)==len(expected)
            for a,b in zip(actual,expected):
                assert a.shape==b.shape and a.dtype==b.dtype
                np.testing.assert_allclose(a.detach().numpy(),b.detach().numpy(),rtol=1e-5,atol=1e-5,equal_nan=True)
        del expected,actual,a,b,function
        if validate_only:
            item=dict(**spec,numerically_validated=True,shared_operand_and_seed_storage=True)
        else:
            labels=list(plan['labels']);offset=(cycle+index)%4;labels=labels[offset:]+labels[:offset]
            gc.collect();enabled=gc.isenabled();gc.disable();samples=[]
            try:
                count,calibration=calibrate(functions,labels)
                for block in range(3):
                    rounds=[]
                    for order in balanced_orders(labels,1940000+cycle*10000+index*100+block):
                        timings={label:elapsed(functions[label],count) for label in order}
                        ratios={a+'/'+b:timings[a]['elapsed_seconds']/timings[b]['elapsed_seconds'] for a,b in pairs}
                        rounds.append(dict(order=order,timings=timings,ratios=ratios))
                    samples.append(dict(rounds=rounds,ratios={a+'/'+b:statistics.median(q['ratios'][a+'/'+b] for q in rounds) for a,b in pairs}))
            finally:
                if enabled:gc.enable()
            minimum=min(t['elapsed_seconds'] for sample in samples for q in sample['rounds'] for t in q['timings'].values())
            item=dict(**spec,samples=samples,calibration=calibration,calibration_gc_disabled=True,
                      minimum_chunk_seconds=minimum,timing_valid=minimum>=.04,
                      ratios={a+'/'+b:statistics.median(sample['ratios'][a+'/'+b] for sample in samples) for a,b in pairs},
                      shared_operand_and_seed_storage=True)
        assert fingerprints==[hashlib.sha256(array.tobytes()).hexdigest() for array in arrays]
        item['operands_and_directions_unchanged']=True;rows.append(item)
        print('HVP_SAMPLE '+json.dumps(dict(cycle=cycle,row=item)),flush=True)
        if not validate_only:assert item['timing_valid'],(spec['key'],item['minimum_chunk_seconds'])
        print('HVP_PROGRESS '+json.dumps(dict(cycle=cycle,completed=index+1,total=12,key=spec['key'])),flush=True)
    after={name:{p.name:sha(p) for p in (r/'variants'/name/'stridetorch').iterdir() if p.is_file()} for name in before}
    assert before==after
    return dict(status='validated' if validate_only else 'completed',cycle=cycle,rows=rows,
                python=sys.version,numpy=np.__version__,platform=sys.platform,labels=plan['labels'],source_hashes=before,
                method='All12 HVP flows including norm2 and norm2.9; not overall library performance qualification. 3 blocks of4 Williams4 orders; each position and ordered adjacent pair once per block. GC disabled for calibration and measurement; >=100ms calibration and >=40ms actual chunks. Identical main A0/A1; same physical operand and vector arrays across all versions. Pairwise ratios per round, median rounds per block, median blocks per process. Whole HVP calls; no import/transfer/GPU or end-to-end speed claim.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--cycle',type=int,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--validate-only',action='store_true')
    a=p.parse_args();a.output.write_text(json.dumps(run(a.cycle,a.validate_only),indent=2)+'\n')
