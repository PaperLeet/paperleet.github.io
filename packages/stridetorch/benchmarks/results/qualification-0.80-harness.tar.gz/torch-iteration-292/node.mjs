import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {loadPyodide} from '../torch-iteration-76/runtime/pyodide.mjs';
const root=new URL('./',import.meta.url);
const cycle=Number(process.argv[2]);
const validateOnly=process.argv.includes('--validate-only');
assert(Number.isInteger(cycle)&&cycle>=0&&cycle<3);
const plan=JSON.parse(fs.readFileSync(new URL('wasm-plan.json',root)));
const py=await loadPyodide({indexURL:new URL('../torch-iteration-76/runtime/',root).pathname,
  stdout(message){if(message.startsWith('HVP_PROGRESS')||message.startsWith('HVP_SAMPLE'))console.log(message);},stderr(message){console.error(message);}});
await py.loadPackage('numpy');
    py.runPython('import sys;sys.dont_write_bytecode=True');
for(const [name,digest] of Object.entries(plan.files)){
  const bytes=fs.readFileSync(new URL(name,root));
  assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),digest,name);
  py.FS.mkdirTree('/'+name.split('/').slice(0,-1).join('/'));
  py.FS.writeFile('/'+name,bytes);
}
if(!validateOnly){const bytes=fs.readFileSync(new URL('measurement-prerequisites.json',root));py.FS.writeFile('/measurement-prerequisites.json',bytes);}
py.globals.set('cycle',cycle);py.globals.set('validate_only',validateOnly);
const report=JSON.parse(py.runPython("import sys,json,importlib.util\nsys.path.insert(0,'/')\nspec=importlib.util.spec_from_file_location('_paired_run','/benchmark.py')\nbench=importlib.util.module_from_spec(spec)\nspec.loader.exec_module(bench)\njson.dumps(bench.run(cycle,validate_only))"));
assert.equal(report.rows.length,12);
fs.writeFileSync(new URL(`${validateOnly?'validation':'latency'}-node-${cycle}.json`,root),
  JSON.stringify({...report,node:process.version,pyodide:py.version,programs:plan.files},null,2)+'\n');
console.log(JSON.stringify({status:report.status,cycle,rows:report.rows.length}));
