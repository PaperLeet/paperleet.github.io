import fs from 'node:fs';
import assert from 'node:assert/strict';
import {withFixtureServer} from '../torch-iteration-70/fixture-server.mjs';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const cycle=Number(process.argv[2]),validateOnly=process.argv.includes('--validate-only');
assert(Number.isInteger(cycle)&&cycle>=0&&cycle<3);
await withFixtureServer(async origin=>{
  const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
  try{
    const page=await browser.newPage();
    page.on('console',event=>console.log(event.text()));
    await page.goto(origin+'/torch-iteration-292/index.html');
    const result=await page.evaluate(({cycle,validateOnly})=>new Promise((resolve,reject)=>{
      const worker=new Worker('./worker.mjs',{type:'module'});
      worker.onmessage=({data})=>{
        if(data.status==='progress'||data.status==='diagnostic'){console.log(data.message);return;}
        worker.terminate();resolve(data);
      };
      worker.onerror=event=>{worker.terminate();reject(Error(event.message));};
      worker.postMessage({cycle,validateOnly});
    }),{cycle,validateOnly});
    fs.writeFileSync(new URL(`${validateOnly?'validation':'latency'}-chrome-${cycle}.json`,import.meta.url),
      JSON.stringify({...result,browser:browser.version()},null,2)+'\n');
    assert.equal(result.status,'completed',JSON.stringify(result));
    assert.equal(result.report.rows.length,12);
    console.log(JSON.stringify({status:result.report.status,cycle,rows:result.report.rows.length}));
  }finally{await browser.close();}
});
