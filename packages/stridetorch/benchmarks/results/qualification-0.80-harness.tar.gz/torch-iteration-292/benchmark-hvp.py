"""Complete HVP flows, including legacy fallback and new norm compositions."""
import numpy as np

def specifications():
 for dtype in ['float32','float64']:
  for name,shapes in [('polynomial',[(32,)]),('matrix',[(16,32),(32,16)]),('batched_matrix',[(2,4,16,32),(32,16)]),('sdpa',[(1,2,8,8)]*3),('norm2',[(16,32)]),('norm2.9',[(16,32)])]:
   yield dict(key=dtype+'/'+name,dtype=dtype,kind='hvp',name=name,mode='hvp',shapes=shapes)

def make_inputs(spec):
 rng=np.random.default_rng(126081)
 values=[np.asarray(rng.integers(1,9,size=shape)/8,dtype=spec['dtype']) for shape in spec['shapes']]
 directions=[np.asarray(rng.integers(-4,5,size=shape)/16,dtype=spec['dtype']) for shape in spec['shapes']]
 return values,directions

def flow(module,spec,raw,new_norm):
 api=module.torch;inputs=tuple(api.from_numpy(x) for x in raw[0]);vectors=tuple(api.from_numpy(x) for x in raw[1]);name=spec['name']
 if name=='polynomial':function=lambda x:x.pow(3).sum()
 elif name in ['matrix','batched_matrix']:function=lambda x,w:(x@w).square().sum()*.5
 elif name=='sdpa':function=lambda q,k,v:api.nn.functional.scaled_dot_product_attention(q,k,v).square().sum()*.5
 else:
  order=2 if name=='norm2' else 2.9
  if new_norm:function=lambda x:api.linalg.vector_norm(x,ord=order,dim=-1).sum()
  else:function=lambda x:x.abs().pow(order).sum(-1).pow(1/order).sum()
 def invoke():
  value,product=api.autograd.functional.hvp(function,inputs if len(inputs)>1 else inputs[0],vectors if len(vectors)>1 else vectors[0])
  return (value,*product) if isinstance(product,tuple) else (value,product)
 return invoke
