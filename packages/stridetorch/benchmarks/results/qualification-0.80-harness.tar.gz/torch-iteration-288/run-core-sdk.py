"""Complete isolated SDK contracts with implementation-path and rank controls."""
from pathlib import Path
import json
import sys

sys.dont_write_bytecode = True
r = Path(__file__).resolve().parent
sys.path.insert(0, str(r / 'prototype'))
import stridetorch
assert Path(stridetorch.__file__).resolve() == r / 'prototype/stridetorch/__init__.py'
import numpy as np
import pytest


class Record:
    def __init__(self):
        self.passed = self.skipped = 0
        self.failures = []
    def pytest_runtest_logreport(self, report):
        if report.when == 'call' and report.passed:
            self.passed += 1
            if self.passed % 1000 == 0:
                print('SDK_PROGRESS ' + str(self.passed), flush=True)
        if report.skipped:
            self.skipped += 1
        if report.failed:
            self.failures.append(dict(test=report.nodeid, error=str(report.longrepr)[-3000:]))


minimum = '--minimum' in sys.argv
expected_passed, expected_skipped = (12222, 3) if minimum else (12225, 0)
record = Record()
code = pytest.main([str(r / 'tests'), '-q', '--noconftest', '-p', 'no:cacheprovider'], plugins=[record])
complete = int(code) == 0 and record.passed == expected_passed and record.skipped == expected_skipped
result = dict(exit_code=int(code), passed=record.passed, skipped=record.skipped,
              expected_passed=expected_passed, expected_skipped=expected_skipped,
              complete=complete, failures=record.failures,
              implementation=str(stridetorch.__file__), version=stridetorch.__version__, numpy=np.__version__)
(r / ('minimum-sdk-result.json' if minimum else 'core-sdk-result.json')).write_text(json.dumps(result, indent=2) + '\n')
raise SystemExit(0 if complete else 1)
