"""Complete SDK tests after the fused-factory point and lifetime controls."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,traceback
r=Path(__file__).resolve().parent;b=r.parent
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
plan=read(r/'plan.json');receipts=[]
def verify():
 for path,digest in plan['inputs'].items():assert sha(Path(path))==digest,path
 assert sha(Path(__file__))==plan['runner_sha256']
def progress(status,**details):write(r/'progress.json',dict(status=status,supervisor_pid=os.getpid(),observed_unix=time.time(),receipts=receipts,**details))
try:
 verify();assert read(b/'torch-iteration-287/progress.json')['status']=='completed'
 assert read(b/'torch-iteration-287/result.json')['status']=='passed_source284_targeted_cpu_minimum_full_sdk_wasm_latency_pending'
 shutil.copytree(b/'torch-iteration-284/prototype',r/'prototype')
 shutil.copytree(b/'torch-iteration-220/tests',r/'tests',ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
 shutil.copy2(b/'torch-iteration-220/run-core-sdk.py',r/'run-core-sdk.py')
 staged=[p for folder in ['prototype','tests'] for p in (r/folder).rglob('*') if p.is_file()]+[r/'run-core-sdk.py']
 write(r/'executed-inputs.json',{str(p.relative_to(r)):sha(p) for p in staged})
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2',PYTHONPATH=str(r/'prototype'))
 for key in ['PYTHONTRACEMALLOC','PYTHONPROFILEIMPORTTIME','PYTHONMALLOC','NODE_OPTIONS']:env.pop(key,None)
 for label,number,rest in [('core-sdk','82',[]),('minimum-sdk','118',['--minimum'])]:
  python=b/('torch-iteration-'+number)/('application-env/bin/python' if number=='82' else 'minimum-env/bin/python')
  command=[str(python),'-B',str(r/'run-core-sdk.py'),*rest];verify()
  with (r/(label+'.log')).open('w') as log:
   child=subprocess.Popen(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT);progress('running',label=label,pid=child.pid,command=command);code=child.wait()
  receipts.append(dict(label=label,command=command,exit_code=code,log_sha256=sha(r/(label+'.log'))));write(r/'receipts.json',receipts);assert code==0,receipts[-1];verify()
 cpu=read(r/'core-sdk-result.json');minimum=read(r/'minimum-sdk-result.json');assert cpu['passed']==12225 and cpu['skipped']==0 and minimum['passed']==12222 and minimum['skipped']==3
 for path,digest in read(r/'executed-inputs.json').items():assert sha(r/path)==digest,path
 result=dict(status='passed_source284_full_sdk_cpu_minimum',sdk=cpu,minimum_sdk=minimum,targeted_result_sha256=sha(b/'torch-iteration-287/result.json'),selected=False,main_adopted=False,ci_triggered=False,goal_status='active')
 write(r/'result.json',result);progress('completed');print(json.dumps(dict(status=result['status'],cpu_passed=12225,minimum_passed=12222)),flush=True)
except BaseException as error:progress('failed',error=str(error),traceback=traceback.format_exc());raise
