"""Count explicit dtype constructors, with no latency or allocation claim."""
from pathlib import Path
import hashlib,importlib.util,json,os,sys,time,traceback
import numpy as np
sys.dont_write_bytecode=True
r=Path(__file__).resolve().parent;b=r.parent
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
plan=read(r/'plan.json')
def verify():
 for path,digest in plan['inputs'].items():assert sha(Path(path))==digest,path
 assert sha(Path(__file__))==plan['runner_sha256']
def progress(status,**details):write(r/'progress.json',dict(status=status,supervisor_pid=os.getpid(),observed_unix=time.time(),**details))
def load(name,path,package=False):
 spec=importlib.util.spec_from_file_location(name,path,submodule_search_locations=[str(path.parent)] if package else None)
 module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
class NumpyObserver:
 def __init__(self):self.calls=0
 def dtype(self,*args,**kwargs):
  self.calls+=1;return np.dtype(*args,**kwargs)
 def __getattr__(self,name):return getattr(np,name)
try:
 verify();previous=b/'torch-iteration-290';state=read(previous/'progress.json');pid=state['supervisor_pid']
 while True:
  try:os.kill(pid,0)
  except ProcessLookupError:break
  progress('waiting_for_source284_qualification',waiting_pid=pid);time.sleep(2)
 assert read(previous/'progress.json')['status']=='completed'
 assert read(previous/'result.json')['status']=='completed_source284_cpu_minimum_wasm_functional_controls'
 flows=load('_dtype_count_flows',b/'torch-iteration-225/benchmark-hvp.py')
 trees=dict(parent272=b/'torch-iteration-272/prototype/stridetorch',candidate284=b/'torch-iteration-284/prototype/stridetorch')
 modules={name:load('_dtype_count_'+name,path/'__init__.py',True) for name,path in trees.items()};rows=[];progress('running')
 for spec in flows.specifications():
  raw=flows.make_inputs(spec);arrays=[*raw[0],*raw[1]];before=[sha_bytes.tobytes() for sha_bytes in arrays]
  functions={name:flows.flow(module,spec,raw,True) for name,module in modules.items()}
  snapshots={};counts={}
  for name,module in modules.items():
   for array in arrays:assert module.torch.from_numpy(array).data_ptr()==array.__array_interface__['data'][0]
   observer=NumpyObserver();saved=(module._autograd.np,module._arithmetic.np)
   module._autograd.np=module._arithmetic.np=observer
   try:
    actual=functions[name]();snapshots[name]=[(str(v.dtype),tuple(v.shape),v.detach().numpy().tobytes()) for v in actual]
   finally:module._autograd.np,module._arithmetic.np=saved
   counts[name]=observer.calls
  assert snapshots['parent272']==snapshots['candidate284']
  assert counts['candidate284']<counts['parent272'],(spec['key'],counts)
  assert before==[array.tobytes() for array in arrays]
  rows.append(dict(key=spec['key'],explicit_dtype_calls=counts,parent_candidate_output_bytes_equal=True,inputs_unchanged=True))
 verify();assert len(rows)==12
 result=dict(status='observed_explicit_dtype_construction_reduction',rows=rows,scope='One instrumented whole HVP per each of 12 flows. A module-local NumPy proxy counts explicit np.dtype calls from _autograd and _arithmetic only. Import-time constants are outside the count; no claim about all NumPy internals, timing, memory or global performance.',qualification_sha256=sha(previous/'result.json'),latency_measured=False,selected=False,main_adopted=False,ci_triggered=False,goal_status='active')
 write(r/'result.json',result);progress('completed');print(json.dumps(result),flush=True)
except BaseException as error:progress('failed',error=str(error),traceback=traceback.format_exc());raise
