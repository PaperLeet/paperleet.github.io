"""Qualify dtype-constant caching only after all source272 measurements finish."""
from pathlib import Path
import hashlib,json,os,subprocess,time,traceback
r=Path(__file__).resolve().parent;b=r.parent
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
plan=read(r/'plan.json');receipts=[]
def verify():
 for path,digest in plan['inputs'].items():assert sha(Path(path))==digest,path
 assert sha(Path(__file__))==plan['runner_sha256']
def progress(status,**details):write(r/'progress.json',dict(status=status,supervisor_pid=os.getpid(),observed_unix=time.time(),receipts=receipts,**details))
try:
 verify();previous=b/'torch-iteration-283';state=read(previous/'progress.json');pid=state['supervisor_pid']
 while True:
  try:os.kill(pid,0)
  except ProcessLookupError:break
  progress('waiting_for_all_source272_measurements',waiting_pid=pid);time.sleep(2)
 assert read(previous/'progress.json')['status']=='completed'
 assert read(previous/'result.json')['status']=='completed_source272_all_hvp_measurement_pipeline'
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
 for key in ['PYTHONPATH','PYTHONTRACEMALLOC','PYTHONPROFILEIMPORTTIME','PYTHONMALLOC','NODE_OPTIONS']:env.pop(key,None)
 jobs=[(286,'run-layout-controls.py'),(287,'run-targeted.py'),(288,'run-sdk.py'),(289,'run-wasm-observations.py')]
 for number,script in jobs:
  root=b/('torch-iteration-'+str(number));verify()
  command=[str(b/'torch-iteration-82/application-env/bin/python'),'-B',str(root/script)]
  with (r/(str(number)+'.log')).open('w') as log:
   child=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
   progress('running',iteration=number,pid=child.pid,command=command);code=child.wait()
  receipts.append(dict(iteration=number,exit_code=code,command=command,log_sha256=sha(r/(str(number)+'.log'))));write(r/'receipts.json',receipts);verify();assert code==0,receipts[-1]
  assert read(root/'progress.json')['status']=='completed'
 layout=read(b/'torch-iteration-286/result.json');target=read(b/'torch-iteration-287/result.json');cpu=read(b/'torch-iteration-288/result.json');wasm=read(b/'torch-iteration-289/result.json')
 assert layout['comparisons']==384 and target['points_exact_references']
 assert not any(value['increases'] for value in target['memory'].values())
 assert cpu['sdk']['passed']==12225 and cpu['minimum_sdk']['passed']==12222
 assert wasm['new_binary_findings']==0 and wasm['new_hvp_or_power_changes']==0
 result=dict(status='completed_source284_cpu_minimum_wasm_functional_controls',source=284,layout_sha256=sha(b/'torch-iteration-286/result.json'),targeted_sha256=sha(b/'torch-iteration-287/result.json'),cpu_sdk_sha256=sha(b/'torch-iteration-288/result.json'),wasm_sha256=sha(b/'torch-iteration-289/result.json'),sdk_cpu_passed=12225,sdk_minimum_passed=12222,sdk_wasm_passed_each=12212,raw_wasm_native_point_gate_passed=False,performance_pending=True,selected=False,main_adopted=False,ci_triggered=False,goal_status='active')
 write(r/'result.json',result);progress('completed');print(json.dumps(result),flush=True)
except BaseException as error:progress('failed',error=str(error),traceback=traceback.format_exc());raise
