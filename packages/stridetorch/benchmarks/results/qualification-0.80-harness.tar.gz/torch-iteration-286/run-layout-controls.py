"""Run output-layout controls only after all source272 timings are terminal."""
from pathlib import Path
import hashlib,json,os,subprocess,time,traceback
r=Path(__file__).resolve().parent;b=r.parent;probe=b/'torch-iteration-285'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
plan=read(r/'plan.json');probe_plan=read(probe/'plan.json');receipts=[]
def verify():
 for path,digest in plan['inputs'].items():assert sha(Path(path))==digest,path
 for path,digest in probe_plan['inputs'].items():assert sha(Path(path))==digest,path
 for name,digest in probe_plan['scripts'].items():assert sha(probe/name)==digest,name
 assert sha(Path(__file__))==plan['runner_sha256']
def progress(status,**details):write(r/'progress.json',dict(status=status,supervisor_pid=os.getpid(),observed_unix=time.time(),receipts=receipts,**details))
try:
 verify();previous=b/'torch-iteration-283';state=read(previous/'progress.json');pid=state['supervisor_pid']
 while True:
  try:os.kill(pid,0)
  except ProcessLookupError:break
  progress('waiting_for_source272_timings',waiting_pid=pid);time.sleep(2)
 assert read(previous/'progress.json')['status']=='completed'
 assert read(previous/'result.json')['status']=='completed_source272_all_hvp_measurement_pipeline'
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
 for name in ['PYTHONPATH','PYTHONTRACEMALLOC','PYTHONPROFILEIMPORTTIME','PYTHONMALLOC','NODE_OPTIONS']:env.pop(name,None)
 commands=[]
 for runtime,python in [('cpu',b/'torch-iteration-82/application-env/bin/python'),('minimum',b/'torch-iteration-118/minimum-env/bin/python')]:
  commands.append((runtime,[python,'-B',probe/'probe-layouts.py','--parent',b/'torch-iteration-272/prototype/stridetorch','--candidate',b/'torch-iteration-284/prototype/stridetorch','--output',r/(runtime+'-result.json')],r/(runtime+'-result.json')))
 for runtime in ['node','chrome']:commands.append((runtime,['/opt/homebrew/bin/node',probe/(runtime+'.mjs')],probe/(runtime+'-result.json')))
 results={}
 for runtime,command,result_path in commands:
  verify()
  with (r/(runtime+'.log')).open('w') as log:
   child=subprocess.Popen(list(map(str,command)),cwd=probe,env=env,stdout=log,stderr=subprocess.STDOUT)
   progress('running',runtime=runtime,pid=child.pid,command=list(map(str,command)));code=child.wait()
  receipts.append(dict(runtime=runtime,command=list(map(str,command)),exit_code=code,log_sha256=sha(r/(runtime+'.log'))));write(r/'receipts.json',receipts);assert code==0,receipts[-1];verify()
  wrapped=read(result_path);report=wrapped.get('report',wrapped);assert report['status']=='passed' and report['cases']==96
  assert len(report['rows'])==96 and all(v['input_unchanged'] and v['outputs_independent'] for v in report['rows'])
  results[runtime]=dict(cases=96,numpy=report['numpy'],python=report['python'],path=str(result_path),sha256=sha(result_path))
 result=dict(status='passed_all_four_runtime_output_layout_controls',comparisons=384,results=results,probe_plan_sha256=sha(probe/'plan.json'),timing_result_sha256=sha(previous/'result.json'),selected=False,main_adopted=False,ci_triggered=False,goal_status='active')
 write(r/'result.json',result);progress('completed');print(json.dumps(result),flush=True)
except BaseException as error:progress('failed',error=str(error),traceback=traceback.format_exc());raise
