"""Retain higher-derivative observations for norm compositions at singularities."""
from pathlib import Path
import argparse
import hashlib
import itertools
import json
import math
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--backend', choices=('native', 'prototype'), required=True)
parser.add_argument('--output', type=Path, required=True)
options = parser.parse_args()
if options.backend == 'prototype':
    sys.path.insert(0, str(Path(__file__).resolve().parent / 'prototype'))
    from stridetorch import torch
else:
    import torch


def pack(value):
    data = value.detach().cpu().clone().numpy()
    def scalar(number):
        number = float(number)
        return number if math.isfinite(number) else 'nan' if math.isnan(number) else 'inf' if number > 0 else '-inf'
    return dict(shape=list(data.shape), dtype=str(data.dtype), values=[scalar(v) for v in data.reshape(-1)], requires_grad=value.requires_grad)


def observe(fn):
    try:
        primal, product = fn()
        return dict(status='ok', value=dict(primal=pack(primal), tangent=pack(product)))
    except Exception as error:
        return dict(status='error', type=type(error).__name__, message=str(error))


families = dict(
    finite_small=[[1e-10, -1e-10, 0.], [2e-10, 0., -3e-10]],
    finite_large=[[1e10, -1e10, 0.], [2e10, 0., -3e10]],
    ordinary=[[.75, -1.25, 2.], [-2.5, 1.75, -.5]],
    zeros=[[0.] * 3] * 2,
    mixed_zero=[[0., -2., 3.], [4., 0., -1.]],
    nonfinite=[[float('nan'), 1., 0.], [float('inf'), -float('inf'), -2.]],
    inf_zero=[[float('inf'), 0., 1.], [-float('inf'), 0., -1.]],
    nonfinite_zero_row=[[float('nan'), float('inf'), 0.], [0.] * 3])
orders = [.25, .5, .75, 1, 1.5, 2, 2.1, 2.5, 2.9, 3, 3.1, 3.5, 4, 5, -.5, -1, -2, -3, float('inf'), -float('inf')]
chains = ['identity', 'square_in', 'cube_in', 'exp_in', 'square_out', 'sin_out', 'normalize', 'shifted_normalize', 'sin_in', 'tanh_in', 'relu_in', 'abs_in', 'reciprocal_in', 'affine_in']
rows = []
for dtype, family, order, chain in itertools.product(['float32', 'float64'], families, orders, chains):
    x = torch.tensor(families[family], dtype=getattr(torch, dtype), requires_grad=True)
    v = torch.tensor([[-.2, .3, -.2], [.3, -.2, .3]], dtype=getattr(torch, dtype), requires_grad=True)
    def function(a):
        source = a.square() if chain == 'square_in' else a ** 3 if chain == 'cube_in' else a.exp() if chain == 'exp_in' else a
        if chain in ['sin_in', 'tanh_in', 'relu_in', 'abs_in', 'reciprocal_in']:
            source = getattr(a, chain.removesuffix('_in'))()
        elif chain == 'affine_in':
            source = a * 2. + .5
        normalized = chain in ['normalize', 'shifted_normalize']
        norm = torch.linalg.vector_norm(source, ord=order, dim=-1, keepdim=normalized)
        if chain == 'square_out':
            result = norm.square()
        elif chain == 'sin_out':
            result = norm.sin()
        elif normalized:
            numerator = a + .125 if chain == 'shifted_normalize' else a
            result = (numerator / (norm + .5)).square()
        else:
            result = norm
        return result.sum()
    rows.append(dict(key=f'{dtype}/{family}/{order}/{chain}', hvp=observe(lambda: torch.autograd.functional.hvp(function, x, v))))
assert len(rows) == 4480
report = dict(backend=options.backend, torch=getattr(torch, '__version__', None),
    probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), rows=rows)
options.output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
print(json.dumps(dict(backend=options.backend, cases=len(rows))))
