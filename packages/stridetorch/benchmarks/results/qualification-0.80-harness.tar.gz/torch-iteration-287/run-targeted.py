"""Reuse the validated primal order; qualify exact points and Tensor lifetimes."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,traceback
r=Path(__file__).resolve().parent;b=r.parent
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
plan=read(r/'plan.json');receipts=[]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
for key in ['PYTHONPATH','PYTHONTRACEMALLOC','PYTHONPROFILEIMPORTTIME','PYTHONMALLOC','NODE_OPTIONS']:env.pop(key,None)
def verify():
 for path,digest in plan['inputs'].items():assert sha(Path(path))==digest,path
 assert sha(Path(__file__))==plan['runner_sha256']
def comparable_observations(rows, expected_filename):
 result=[]
 for row in rows:
  item=dict(row)
  if 'test' in item:
   filename,separator,case=item['test'].partition('::')
   assert separator and Path(filename).name==expected_filename
   item['test']=expected_filename+'::'+case
  result.append(item)
 return result
def progress(status,**details):write(r/'progress.json',dict(status=status,supervisor_pid=os.getpid(),observed_unix=time.time(),receipts=receipts,**details))
def run(label,command):
 verify()
 with (r/(label+'.log')).open('w') as log:
  child=subprocess.Popen(list(map(str,command)),cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  progress('running',label=label,pid=child.pid,command=list(map(str,command)));code=child.wait()
 receipt=dict(label=label,command=list(map(str,command)),exit_code=code,log_sha256=sha(r/(label+'.log')))
 receipts.append(receipt);write(r/'receipts.json',receipts);print(json.dumps(receipt),flush=True);verify();assert code==0,receipt
try:
 verify();previous=b/'torch-iteration-286';state=read(previous/'progress.json');pid=state['supervisor_pid']
 while True:
  try:os.kill(pid,0)
  except ProcessLookupError:break
  progress('waiting_for_existing_timing_and_layout_controls',waiting_pid=pid);time.sleep(2)
 assert read(previous/'progress.json')['status']=='completed'
 assert read(previous/'result.json')['status']=='passed_all_four_runtime_output_layout_controls'
 shutil.copytree(b/'torch-iteration-284/prototype',r/'prototype')
 for name in ['run-observed-probe.py','probe-norm-hvp-boundaries.py']:shutil.copy2(b/'torch-iteration-153'/name,r/name)
 staged=[p for p in (r/'prototype').rglob('*') if p.is_file()]+[r/'run-observed-probe.py',r/'probe-norm-hvp-boundaries.py']
 write(r/'executed-inputs.json',{str(p.relative_to(r)):sha(p) for p in staged})
 cpu=b/'torch-iteration-82/application-env/bin/python';minimum=b/'torch-iteration-118/minimum-env/bin/python';source=r/'prototype/stridetorch'
 for runtime,python in [('cpu',cpu),('minimum',minimum)]:
  for kind,iteration,script,reference,count in [('cleanup','219','run-targeted.py',b/'torch-iteration-219/cpu.json',6),('branches','210','run-targeted.py',b/'torch-iteration-210/cpu-targeted.json',16),('barriers','167','run-probe.py',b/('torch-iteration-277/'+runtime+'-barriers.json'),56)]:
   label=runtime+'-'+kind;run(label,[python,'-B',b/('torch-iteration-'+iteration)/script,'--source',source,'--output',r/(label+'.json')])
   actual=read(r/(label+'.json'));old=read(reference);assert actual['passed']==count and not actual['failures']
   expected_filename={'cleanup':'test_hvp_reverse_cleanup.py','branches':'test_hvp_reachable_branches.py','barriers':'test_hvp_graph_barriers.py'}[kind]
   assert comparable_observations(actual['observations'],expected_filename)==comparable_observations(old['observations'],expected_filename)
   if kind=='barriers':assert comparable_observations(actual['jvp_observations'],expected_filename)==comparable_observations(old['jvp_observations'],expected_filename)
  for kind,iteration,script,count in [('binary','134','probe-binary-hvp.py',612),('power','112','probe-scalar-power.py',14616)]:
   label=runtime+'-'+kind;run(label,[python,'-B',b/('torch-iteration-'+iteration)/script,'--source',source,'--output',r/(label+'.json')])
   actual=read(r/(label+'.json'));old=read(b/('torch-iteration-277/'+label+'.json'));assert len(actual['rows'])==count and actual['rows']==old['rows']
 run('hvp',[cpu,'-B',r/'run-observed-probe.py']);actual=read(r/'hvp-prototype.json');old=read(b/'torch-iteration-277/hvp-prototype.json');assert len(actual['rows'])==4480 and actual['rows']==old['rows']
 paths=read(r/'path-observations.json');assert paths['selections']==dict(three_reverse=4480) and not paths['missing_rules'] and paths['context_restored']
 memory={}
 for runtime,python in [('cpu',cpu),('minimum',minimum)]:
  observations={}
  for name,tree in [('parent272',b/'torch-iteration-272/prototype/stridetorch'),('candidate284',source)]:
   label=runtime+'-'+name+'-storage';run(label,[python,'-B',b/'torch-iteration-183/probe-scoped-storage.py','--source',tree,'--output',r/(label+'.json')])
   result=read(r/(label+'.json'));assert result['status']=='passed' and result['calls']==300
   observations[name]={row['key']:max(c['peak_tracked_noninput_owner_bytes'] for c in row['calls']) for row in result['rows']}
  increases={key:observations['candidate284'][key]-value for key,value in observations['parent272'].items() if observations['candidate284'][key]>value}
  memory[runtime]=dict(peaks=observations,increases=increases)
 for path,digest in read(r/'executed-inputs.json').items():assert sha(r/path)==digest,path
 result=dict(status='passed_source284_targeted_cpu_minimum_full_sdk_wasm_latency_pending',source=284,cleanup_cases_each=6,branch_cases_each=16,barrier_cases_each=56,hvp_cases=4480,binary_cases_each=612,power_cases_each=14616,points_exact_references=True,memory=memory,output_layout_result_sha256=sha(previous/'result.json'),selected=False,main_adopted=False,ci_triggered=False,goal_status='active')
 write(r/'result.json',result);progress('completed');print(json.dumps({k:v for k,v in result.items() if k!='memory'}),flush=True)
except BaseException as error:progress('failed',error=str(error),traceback=traceback.format_exc());raise
