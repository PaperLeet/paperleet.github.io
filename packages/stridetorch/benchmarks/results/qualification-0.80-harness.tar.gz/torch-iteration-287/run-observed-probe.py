"""Record path selection without replacing numerical rules or probe cases."""
from pathlib import Path
import collections
import hashlib
import json
import runpy
import sys

r = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(r / 'prototype'))
from stridetorch import _higher_order, _state

selected = collections.Counter()
original = _higher_order.Context.can_reverse
missing = collections.Counter()
def observe(self, output):
    answer = original(self, output)
    selected['three_reverse' if answer else 'legacy'] += 1
    if not answer:
        for node in self.order((output,)):
            if node._parents and id(node) not in self.rules:
                missing[str(type(node))] += 1
    return answer

_higher_order.Context.can_reverse = observe
try:
    sys.argv = [str(r / 'probe-norm-hvp-boundaries.py'), '--backend', 'prototype', '--output', str(r / 'hvp-prototype.json')]
    runpy.run_path(sys.argv[0], run_name='__main__')
finally:
    _higher_order.Context.can_reverse = original
assert _state._tensor_reverse_context is None
(r / 'path-observations.json').write_text(json.dumps(dict(selections=selected,
    missing_rules=missing, context_restored=True,
    probe_sha256=hashlib.sha256((r/'probe-norm-hvp-boundaries.py').read_bytes()).hexdigest()), indent=2)+'\n')
print(json.dumps(dict(selections=selected, missing_rules=missing, context_restored=True)))
