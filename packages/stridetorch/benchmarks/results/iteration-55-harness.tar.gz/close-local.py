from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,tarfile

r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results';p=r/'proof';i=r/'integration-proof'
def read(name):return json.loads((r/name).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
source={f.name:sha(f) for f in (repo/'packages/stridetorch/src/stridetorch').iterdir() if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']}
plan=read('proof/chrome-contracts/plan.json');assert source==read('proof/source-hashes.json')==plan['source'] and len(source)==58
tests={f.name:sha(f) for f in (repo/'packages/stridetorch/tests').glob('test_*.py') if f.name!='test_standalone.py'}
assert plan['tests']==tests and len(tests)==51 and plan['expected']==6867
baseline=json.loads((r.parent/'torch-iteration-54/proof/source-hashes.json').read_text())
changed=sorted(n for n in baseline if source[n]!=baseline[n]);assert len(changed)==15 and set(source)-set(baseline)=={'_defaults.py'}
cpu=read('full-root-receipt.json');assert cpu['exit_code']==0 and cpu['passed']==40497 and cpu['skipped']==1
gates=read('proof/gate-receipts.json');assert len(gates)==6 and all(v['exit_code']==0 for v in gates.values())
node=read('proof/source-wasm.json');chrome=read('proof/chrome-contracts/result.json');wheel=read('proof/wheel-stride055-result.json');co=read('proof/coinstall-result.json')
assert node['passed']==chrome['passed']==6867 and chrome['test_hashes']==tests
assert node['source_hashes']==chrome['source_hashes']==wheel['source_hashes']==co['source_hashes']==source
assert all(v['status']=='success' for v in [chrome,wheel,co]) and not wheel['native_torch']
assert '6880 passed' in (p/'python310-stride055-tests.log').read_text()
qualification=read('defaults-qualification.json');assert qualification['status']=='qualified' and qualification['source_hashes']==source
assert qualification['cases']==1701 and qualification['numeric_cases']==1664 and qualification['arrays']==1962 and len(qualification['unsupported_complex_half_cases'])==37
assert qualification['following_random_stream_arrays']==180
for name,digest in qualification['oracle_sha256'].items():assert sha(r/name)==digest
receipts=read('integration-proof/receipts.json');front=read('integration-proof/frontend-receipts.json')
assert len(receipts)==2 and len(front)==5 and all(v['exit_code']==0 for v in receipts+front)
wasm=read('integration-proof/full-wasm-result.json');assert wasm['passed'] and wasm['modules']==wasm['catalog_modules']==78 and not wasm['browser_budget_exceeded']
assert sum(v['mutants'] for v in wasm['results'])==342 and all(v['passed'] and not v['browser_budget_exceeded'] for v in wasm['results'])
contracts=next(v for v in wasm['results'] if v['id']=='architecture/attention')['independent_contracts'];assert contracts['passed']==6867 and len(contracts['suites'])==51
assert {v['suite']:v['source_sha256'] for v in contracts['suites']}==tests
exports=read('integration-proof/export-identity.json');assert exports['published_assets_unchanged']==11651 and exports['new_assets']==exports['active_assets']==158
live=read('integration-proof/live-expected-sha256.json');assert len(live)==161
for name,digest in live.items():assert sha(repo/'web/public/data'/name)==digest
policy=read('release-policy-identity.json')
for name,digest in policy['files'].items():assert sha(repo/name)==digest
native=read('native-catalog-reuse.json');assert native['files']==1152
isolation=read('native-isolation-result.json');assert isolation['status']=='success' and isolation['library_version']=='0.55.0'
for name,digest in native['native_input_sha256'].items():assert sha(repo/name)==digest
context=read('integration-proof/context.json');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head==context['upstream']
sync=read('upstream-sync.json') if (r/'upstream-sync.json').exists() else None
if sync:
 assert sync['after']==head
 for name,digest in sync['paths'].items():assert sha(repo/name)==digest
 sync.update(frontend_rerun_pending=False,frontend_receipts='integration-proof/frontend-receipts.json');save(r/'upstream-sync.json',sync)
perf=read('performance/identity.json');perf_receipts=read('performance/receipts.json')
assert perf['status']=='success' and perf['children']==len(perf_receipts)==12 and all(v['exit_code']==0 for v in perf_receipts)
assert perf['source_hashes']==dict(baseline=baseline,candidate=source)
assert sha(repo/'packages/stridetorch/benchmarks/bench_transformer.py')==perf['benchmark_sha256']
for runtime in ['cpu','node','chrome']:
 for repeat in range(4):
  data=read(f'performance/{runtime}-{repeat}.json');data=data.get('benchmark',data)
  assert len(data['rows'])==60 and data['versions']==dict(baseline='0.54.0',candidate='0.55.0')
  assert data['source_hashes']==perf['source_hashes']
fresh=[]
for name,python,path in [('stridetorch',p/'python310-stride055-env/bin/python',p/'stridetorch-activation.pkl'),('paperleet._vendor.torch',p/'coinstall-env/bin/python',p/'paperleet-_vendor-torch-activation.pkl')]:
 result=subprocess.run([str(python),'-I',str(r/'fresh-load.py'),name,str(path)],capture_output=True,text=True,cwd=r)
 assert result.returncode==0,result.stderr;fresh.append(dict(namespace=name,exit_code=0,output=result.stdout.strip()))
save(r/'fresh-load-result.json',fresh)
metadata=r/'package-metadata';metadata.mkdir(exist_ok=True)
for name in ['README.md','pyproject.toml','LICENSE','NOTICE']:shutil.copy2(repo/'packages/stridetorch'/name,metadata/name)
shutil.copy2(repo/'packages/stridetorch/tests/test_standalone.py',metadata/'test_standalone.py')
footprint={}
for label,folder,names in [('baseline',r/'baseline-source/stridetorch',baseline),('candidate',repo/'packages/stridetorch/src/stridetorch',source)]:
 payload=b''.join((folder/name).read_bytes() for name in sorted(names))
 footprint[label]=dict(source_license_bytes=len(payload),local_concatenated_gzip_bytes=len(gzip.compress(payload,mtime=0)))
archive=out/'iteration-55-harness.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as target:
 for current,dirs,files in os.walk(r):
  dirs[:]=[d for d in dirs if d not in ['__pycache__','.pytest_cache'] and not d.endswith(('-env','-venv'))]
  for name in sorted(files):
   f=Path(current)/name
   if not f.is_symlink() and (f.name in ['LICENSE','NOTICE'] or f.suffix in ['.py','.mjs','.json','.log','.md','.html','.toml','.npz','.txt','.whl','.pkl'] or f.name.endswith('.tar.gz')):target.add(f,arcname=f.relative_to(r),recursive=False)
assert archive.stat().st_size<95*1024*1024
report=dict(status='validated_locally',version='0.55.0',baseline_main=head,numerical_baseline_main='ef5f03dfd92b4ee4597525ab7230e511eb966703',source_hashes=source,test_hashes=tests,changed_resources=changed,added_resources=['_defaults.py'],added_tests=171,
 full_cpu=cpu,node_wasm=node,chrome_worker=chrome,minimal_wheel=wheel,coinstall=co,fresh_process=fresh,
 native_qualification=qualification,native_catalog_reuse=native,native_dtype_isolation=isolation,export_identity=exports,active_export_sha256=live,frontend=front,upstream_sync=sync,
 full_wasm=dict(modules=78,mutants=342,contracts=6867,suites=51,passed=True,browser_budget_exceeded=False),release_policy=policy,
 performance_identity=perf,performance=read('performance-summary.json'),source_footprint=footprint,
 limitations=['NumPy cannot represent complex32 storage; 37 native complex-half cases are separately classified, not numeric passes.','Real half sampling/storage is supported; half neural-network kernels and forward AD remain unsupported.','The raw Tensor constructor retains NumPy storage inference. Modern namespaces share dtype state per distribution; public/private/native installations remain independent.','Existing 0.53 float32 mixed-AD qualification and dense CPU/WASM backend limits remain.'],
 raw_archive=dict(name=archive.name,sha256=sha(archive),bytes=archive.stat().st_size))
save(out/'iteration-55.json',report);save(r/'state.json',dict(status='local_gates_passed',version='0.55.0',main_adoption_pending=True,source_hashes=source,active_export_sha256=live))
print(json.dumps(dict(status=report['status'],cpu=40497,wasm=6867,wheel=6880,catalog=78,mutants=342,raw_archive=report['raw_archive'])))
