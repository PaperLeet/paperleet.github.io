from pathlib import Path
import json,statistics
r=Path(__file__).resolve().parent;summary={}
for runtime in ['cpu','node','chrome']:
 processes=[]
 for repeat in range(4):
  data=json.loads((r/f'performance/{runtime}-{repeat}.json').read_text());processes.append(data.get('benchmark',data))
 summary[runtime]={}
 for dtype in ['float32','float64']:
  summary[runtime][dtype]={}
  for mode in ['forward','reverse','jvp','mixed','training4']:
   ratios={name:[] for name in ['core','layer']}
   for data in processes:
    rows=[v for v in data['rows'] if v['dtype']==dtype and v['mode']==mode];assert len(rows)==6
    for name,key in [('core','candidate_core_over_baseline'),('layer','candidate_layer_over_baseline')]:ratios[name].append(100*(statistics.median(v[key] for v in rows)-1))
   summary[runtime][dtype][mode]=dict(core_time_increase_percent=statistics.median(ratios['core']),core_process_range_percent=[min(ratios['core']),max(ratios['core'])],layer_time_increase_percent=statistics.median(ratios['layer']),layer_process_range_percent=[min(ratios['layer']),max(ratios['layer'])])
summary['method']='For each child, median of six matched shape/normalization time ratios; median and full range of four fresh children. Positive means slower. Same explicit-dtype encoder math, not a claim about every API, cold load, peak RSS or GPU.'
(r/'performance-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({runtime:{mode:round(summary[runtime]['float32'][mode]['core_time_increase_percent'],2) for mode in ['forward','reverse','jvp','mixed','training4']} for runtime in ['cpu','node','chrome']}))
