from pathlib import Path
import io,json,sys,warnings
import numpy as np

backend=sys.argv[1]
if backend=='native':
 import torch as t
 t.backends.cuda.enable_flash_sdp(False);t.backends.cuda.enable_mem_efficient_sdp(False)
else:from stridetorch import torch as t
r=Path(__file__).resolve().parent;rows={};arrays={}
def record(key,fn):
 try:
  with warnings.catch_warnings():warnings.simplefilter('ignore');value=fn()
  values=list(value) if isinstance(value,(list,tuple)) else [value]
  result=[]
  for i,x in enumerate(values):
   if x is None:result.append(None);continue
   if isinstance(x,t.Tensor):x=x.detach().numpy()
   array=np.asarray(x);arrays[f'{key}.{i}']=array.copy()
   result.append(dict(dtype=str(array.dtype),shape=list(array.shape)))
  rows[key]=dict(status='ok',values=result)
 except Exception as e:rows[key]=dict(status='error',error=type(e).__name__,message=str(e)[:180])

data=[.125,[.125,.25],[.125]*12,[[1.,2],[3.,4.]],[],[[],[]],True,[True,False],2,[1,2],
      1+2j,[1j,2.],[[1j],[2.]],np.float16(.125),np.float32(.125),np.float64(.125),np.int16(3),np.bool_(True),
      np.complex64(1j),np.complex128(1j),[np.float32(.125),.25],[np.float64(.125),.25],
      [np.complex64(1j),2.],np.array([.125,.25],dtype='f4'),np.array([1j],dtype='c16')]
for scalar_type in [np.float32,np.float64,np.complex64,np.complex128]:
 for scalar in [scalar_type(1),t.tensor(scalar_type(1))]:
  for values in [[scalar,1j],[1j,scalar]]:data.extend([values,[values]])
for bits in [16,32,64]:
 dtype=getattr(t,'float'+str(bits));t.set_default_dtype(dtype);prefix=f'd{bits}'
 for i,value in enumerate(data):
  for factory in ['tensor','as_tensor']:
   record(f'{prefix}.{factory}.{i}',lambda value=value,factory=factory:getattr(t,factory)(value))
 for name in ['zeros','ones','empty','rand','randn']:
  for explicit in [False,True]:
   for size in [0,5,21]:
    def fn(name=name,size=size,explicit=explicit):
     t.manual_seed(5503)
     return getattr(t,name)(size,**({'dtype':t.float32} if explicit else {}))
    # Uninitialized values are deliberately excluded from comparison.
    if name!='empty' or size==0:record(f'{prefix}.{name}.{explicit}.{size}',fn)
 for i,value in enumerate([.125,1,True,1+2j,np.float32(.125),np.complex64(1+2j),np.bool_(True)]):
  record(f'{prefix}.full.{i}',lambda value=value:t.full((2,3),value))
 for name,args in [('arange',(0.,2.,.5)),('arange',(np.float32(3),)),('arange',(3,)),
                   ('linspace',(-1,1,5)),('linspace',(0,1j,3)),('eye',(3,))]:
  key=f'{prefix}.{name}.{repr(args)}'
  record(key,lambda name=name,args=args:getattr(t,name)(*args))
 for target in ['int64','bool','float16','float32','float64','complex64','complex128']:
  for rank in [0,1]:
   a=t.tensor(1 if rank==0 else [1,2],dtype=getattr(t,target))
   for i,number in enumerate([.25,2,True,1+2j,np.float32(.25),np.complex64(1+2j)]):
    for op in ['add','mul','div']:
     record(f'{prefix}.{target}.r{rank}.{op}.scalar{i}',lambda a=a,number=number,op=op:getattr(t,op)(a,number))
   if target in ['int64','bool']:
    for unary in ['sqrt','rsqrt','exp','log','sin','cos','tanh','sigmoid','acos','reciprocal']:
     record(f'{prefix}.{target}.r{rank}.{unary}',lambda a=a,unary=unary:getattr(a,unary)())
    record(f'{prefix}.{target}.r{rank}.pow_float',lambda a=a:a**.5)
    record(f'{prefix}.{target}.r{rank}.logsumexp',lambda a=a:a.logsumexp(0))
 if bits==16:continue
 for name,args,kw in [('Linear',(3,4),{}),('Embedding',(5,4),{}),('LayerNorm',(4,),{}),('RMSNorm',(4,),{}),('GroupNorm',(2,4),{}),
                       *[(n,(4,),dict(affine=True,track_running_stats=True)) for n in ['BatchNorm1d','BatchNorm2d','BatchNorm3d','InstanceNorm1d','InstanceNorm2d','InstanceNorm3d']],
                       *[(n,(2,4,3),{}) for n in ['Conv1d','Conv2d','Conv3d','ConvTranspose1d','ConvTranspose2d','ConvTranspose3d']],
                       ('MultiheadAttention',(4,2),dict(add_bias_kv=True)),('TransformerEncoderLayer',(4,2,7),dict(dropout=0.)),
                       ('TransformerDecoderLayer',(4,2,7),dict(dropout=0.)),('Transformer',(4,2,1,1),dict(dim_feedforward=7,dropout=0.))]:
  t.manual_seed(5504);model=getattr(t.nn,name)(*args,**kw)
  for key,value in model.state_dict().items():record(f'{prefix}.model.{name}.{key}',lambda value=value:value)
 for opt_name in ['Adam','AdamW']:
  def train(opt_name=opt_name,dtype=dtype,bits=bits):
   t.set_default_dtype(dtype);t.manual_seed(5505)
   model=t.nn.Sequential(t.nn.Linear(3,4),t.nn.SiLU(),t.nn.LayerNorm(4),t.nn.Linear(4,2))
   optimizer=getattr(t.optim,opt_name)(model.parameters(),lr=.01)
   x=t.tensor([[.1,.2,.3],[.4,.5,.6]],requires_grad=True)
   out,j=t.func.jvp(model,(x,),(t.ones_like(x)*.13,))
   active=[x,*model.parameters()]
   first=t.autograd.grad(out.square().sum(),active,retain_graph=True)
   mixed=t.autograd.grad(j.square().sum(),active,allow_unused=True)
   mixed=[t.zeros_like(p) if g is None else g for p,g in zip(active,mixed)]
   for p,g in zip(model.parameters(),first[1:]):p.grad=g
   t.set_default_dtype(t.float32 if bits==64 else t.float64);optimizer.step()
   stream=io.BytesIO();t.save({'model':model.state_dict(),'optimizer':optimizer.state_dict()},stream);stream.seek(0);loaded=t.load(stream,weights_only=True)
   target=t.nn.Sequential(t.nn.Linear(3,4,dtype=dtype),t.nn.SiLU(),t.nn.LayerNorm(4,dtype=dtype),t.nn.Linear(4,2,dtype=dtype))
   opt=getattr(t.optim,opt_name)(target.parameters(),lr=.01);target.load_state_dict(loaded['model']);opt.load_state_dict(loaded['optimizer'])
   target(x).square().sum().backward();opt.step()
   return [out,j,*first,*mixed,*target.parameters(),*[v['step'] for v in opt.state.values()]]
  record(f'{prefix}.training.{opt_name}',train)
 t.set_default_dtype(dtype)
 t.manual_seed(5506);p=t.ones(2,requires_grad=True);o=t.optim.Adam([p]);p.sum().backward();o.step()
 state=o.state_dict();state['state'][0]['step']=2.
 restored=t.optim.Adam([p]);restored.load_state_dict(state)
 record(f'{prefix}.legacy_step',lambda:restored.state[p]['step'])
t.set_default_dtype(t.float16)
for name in ['LayerNorm','RMSNorm','GroupNorm','BatchNorm2d','InstanceNorm2d']:
 def parameterless(name=name):
  x=t.tensor(np.sin(np.arange(72)).reshape(2,4,3,3).astype('float32'),requires_grad=True)
  if name in ['LayerNorm','RMSNorm']:m=getattr(t.nn,name)((3,3),elementwise_affine=False)
  elif name=='GroupNorm':m=t.nn.GroupNorm(2,4,affine=False)
  else:m=getattr(t.nn,name)(4,affine=False,track_running_stats=False)
  y,j=t.func.jvp(m,(x,),(t.ones_like(x)*.13,));g,=t.autograd.grad((y.square().sum()+j.square().sum()),[x])
  return y,j,g
 record('parameterless.'+name,parameterless)
record('pretrained.float32',lambda:t.nn.Embedding.from_pretrained(t.ones(3,4,dtype=t.float32))(t.tensor([0,2])))
for seed in [1,5507,90210]:
 for size in [0,1,5,15,16,17,21,31,32,33,47,48,49,100,4096]:
  for factory in ['rand','randn']:
   def sample(seed=seed,size=size,factory=factory):
    t.set_default_dtype(t.float16);t.manual_seed(seed)
    first=getattr(t,factory)(size)
    # Observe both normal-cache continuity and subsequent raw RNG position.
    t.set_default_dtype(t.float64);second=t.randn(3)
    t.set_default_dtype(t.float32);third=t.rand(4)
    return [first,second,third]
   record(f'half_random.{seed}.{size}.{factory}',sample)
np.savez_compressed(r/(backend+'-defaults.npz'),**arrays)
(r/(backend+'-defaults.json')).write_text(json.dumps(dict(backend=backend,python=sys.version,numpy=np.__version__,rows=rows),indent=2)+'\n')
print(backend,'cases',len(rows),'arrays',len(arrays),'errors',sum(v['status']=='error' for v in rows.values()))
