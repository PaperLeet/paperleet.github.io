from pathlib import Path
import json,subprocess,sys
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');py=sys.executable
baseline=json.loads((r/'integration-proof/context.json').read_text())['upstream']
def call(*args,cwd=r):subprocess.check_call([str(x) for x in args],cwd=cwd)
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
assert git('rev-parse','HEAD')==baseline
call(py,r/'audit-main.py',baseline)
call(py,r/'close-local.py')
call(py,r/'write-report.py')
paths=git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
source=json.loads((r/'owned-source-paths.json').read_text())
generated=['docs/validation/torch-runtime-iteration-55.md','packages/stridetorch/benchmarks/results/iteration-55.json','packages/stridetorch/benchmarks/results/iteration-55-harness.tar.gz']
indices=['web/public/data/'+n for n in ['catalog.json','index-v3.json','index.json']]
assets=[n for n in paths if n.startswith(('web/public/data/browser-judge/','web/public/data/modules/'))]
expected=sorted(source+generated+indices+assets)
assert len(assets)==158 and len(expected)==184 and sorted(paths)==expected,(len(paths),set(paths)^set(expected))
call('git','add','--',*expected,cwd=repo)
assert git('diff','--cached','--name-only').splitlines()==expected
call('git','diff','--cached','--check',cwd=repo)
call('git','commit','--quiet','-m','feat(torch): support default floating dtype and half random streams',cwd=repo)
source_head=git('rev-parse','HEAD');print('SOURCE_COMMIT',source_head,flush=True)
call(py,r/'push-main-node.py',baseline)
call(py,r/'record-adoption.py')
proof=['docs/validation/torch-runtime-iteration-55.md','packages/stridetorch/benchmarks/results/iteration-55-main-adoption.json']
call('git','add','--',*proof,cwd=repo)
assert git('diff','--cached','--name-only').splitlines()==proof
call('git','commit','--quiet','-m','docs(torch): record validated 0.55 main adoption',cwd=repo)
print('PROOF_COMMIT',git('rev-parse','HEAD'),flush=True)
call(py,r/'push-main-node.py',source_head)
call(py,r/'verify-adoption.py')
print('ITERATION_55_ADOPTED_GOAL_REMAINS_ACTIVE',flush=True)
