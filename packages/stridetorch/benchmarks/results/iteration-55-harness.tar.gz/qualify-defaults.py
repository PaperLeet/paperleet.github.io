from pathlib import Path
import hashlib,json
import numpy as np

r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
a=json.loads((r/'adapter-defaults.json').read_text())['rows'];b=json.loads((r/'native-defaults.json').read_text())['rows']
aa=np.load(r/'adapter-defaults.npz');bb=np.load(r/'native-defaults.npz')
assert set(a)==set(b) and len(a)==1701
unsupported=[];arrays=0;worst={};following=0
for key in a:
 left,right=a[key],b[key];assert left['status']==right['status'],key
 if left['status']=='error':
  assert left['error']=='BrowserUnsupported' and 'ComplexHalf' in right['message'],(key,left,right)
  unsupported.append(dict(case=key,adapter=left,native=right));continue
 assert left['values']==right['values'],key
 for i,value in enumerate(left['values']):
  if value is None:continue
  name=f'{key}.{i}';x,y=aa[name],bb[name]
  if x.dtype.kind not in 'fc':np.testing.assert_array_equal(x,y)
  else:
   tol=(3e-10,3e-11) if x.dtype in (np.dtype('float64'),np.dtype('complex128')) else (3e-3,2e-3) if x.dtype==np.dtype('float16') else (5e-5,8e-6)
   np.testing.assert_allclose(x,y,rtol=tol[0],atol=tol[1],equal_nan=True,err_msg=name)
   difference=float(np.max(np.abs(x-y),initial=0));kind=str(x.dtype)
   if np.isfinite(difference) and difference>worst.get(kind,{}).get('absolute',-1):worst[kind]=dict(absolute=difference,key=name)
  if key.startswith('half_random.') and i in [1,2]:
   if i==1:np.testing.assert_allclose(x,y,rtol=3e-14,atol=3e-14,err_msg=name)
   else:np.testing.assert_array_equal(x,y)
   following+=1
  arrays+=1
assert arrays==1962 and len(unsupported)==37 and following==180
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={p.name:sha(p) for p in (repo/'packages/stridetorch/src/stridetorch').iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']}
report=dict(status='qualified',cases=1701,numeric_cases=1664,arrays=arrays,unsupported_complex_half_cases=unsupported,
 following_random_stream_arrays=following,tolerances=dict(float16=[3e-3,2e-3],float32=[5e-5,8e-6],float64=[3e-10,3e-11]),
 worst_absolute_differences=worst,source_hashes=source,
 oracle_sha256={name:sha(r/name) for name in ['differential-defaults.py','adapter-defaults.npz','native-defaults.npz','adapter-defaults.json','native-defaults.json']},
 scope='Strict dtype/shape and tolerance-based values for supported storage. The 37 cases requiring unrepresentable complex-half storage or unsupported native complex-half kernels are explicitly classified, not counted as numeric passes. No GPU or universal bitwise random equivalence claim.')
(r/'defaults-qualification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','cases','numeric_cases','arrays','following_random_stream_arrays','worst_absolute_differences']}))
