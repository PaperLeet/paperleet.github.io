from pathlib import Path
import json
import torch
from torch.nn.attention import sdpa_kernel,SDPBackend
rows=[]
for changed in range(4):
 values=[torch.ones(shape,dtype=torch.float64,requires_grad=True) for shape in [(1,4,3,2),(1,2,5,2),(1,2,5,3)]]+[torch.zeros(3,5,dtype=torch.float64,requires_grad=True)]
 def call(*x):return torch.nn.functional.scaled_dot_product_attention(*x[:3],attn_mask=x[3],enable_gqa=True,dropout_p=.25)
 with sdpa_kernel(SDPBackend.MATH):y=torch.func.jvp(call,tuple(values),tuple(torch.ones_like(x) for x in values))[1]
 values[changed].detach().add_(1.)
 try:y.sum().backward();error=None
 except Exception as exc:error=dict(type=type(exc).__name__,message=str(exc))
 rows.append(dict(changed=changed,error=error))
r=Path(__file__).resolve().parent;result=dict(torch=torch.__version__,rows=rows);(r/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
