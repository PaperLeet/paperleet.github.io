from pathlib import Path
import hashlib,importlib,importlib.util,json,sys
import numpy as np
import torch as native
r=Path(__file__).resolve().parent;b=r.parent
source=b/'torch-iteration-420/prototype/stridetorch'
spec=importlib.util.spec_from_file_location('_gradient420',source/'__init__.py',submodule_search_locations=[str(source)]);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
api=module.torch;assert native.__version__=='2.6.0'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((b/'torch-iteration-420/source-plan.json').read_text())
for name,h in plan['inputs'].items():assert sha(b/'torch-iteration-420'/name)==h,name
rows=[]
def execute(torch,dtype,kind,foreach,enabled):
 p=torch.tensor([0.,0.],dtype=getattr(torch,dtype),requires_grad=True)
 g=torch.tensor([6.,8.],dtype=getattr(torch,dtype));p.grad=g
 with torch.set_grad_enabled(enabled):
  if kind=='norm':value=torch.nn.utils.clip_grad_norm_((x for x in [p]),2.,foreach=foreach)
  else:value=torch.nn.utils.clip_grad_value_(p,1.5,foreach=foreach)
  assert torch.is_grad_enabled() is enabled and p.grad is g
 assert not value.requires_grad if value is not None else True
 return dict(value=None if value is None else value.numpy().copy(),gradient=g.numpy().copy())
for dtype in ['float32','float64']:
 for kind in ['norm','value']:
  for foreach in [None,False,True]:
   for enabled in [False,True]:
    expected=execute(native,dtype,kind,foreach,enabled);actual=execute(api,dtype,kind,foreach,enabled)
    assert (expected['value'] is None)==(actual['value'] is None)
    for key in ['value','gradient']:
     if expected[key] is not None:np.testing.assert_allclose(actual[key],expected[key],rtol=3e-6 if dtype=='float32' else 3e-12,atol=1e-7 if dtype=='float32' else 1e-12)
    rows.append(dict(dtype=dtype,kind=kind,foreach=foreach,caller_grad_enabled=enabled))
saved={name:value for name,value in sys.modules.items() if name=='torch' or name.startswith('torch.')}
with module.as_torch():
 direct=importlib.import_module('torch.nn.utils');nested=importlib.import_module('torch.nn.utils.clip_grad')
 assert direct.clip_grad_norm_ is api.nn.utils.clip_grad_norm_ is nested.clip_grad_norm_
 assert direct.clip_grad_value_ is nested.clip_grad_value_
assert {name:value for name,value in sys.modules.items() if name=='torch' or name.startswith('torch.')}==saved
result=dict(status='passed_basic_gradient_utility_prototype',cases=len(rows),rows=rows,native_torch=native.__version__,numpy=np.__version__,alias_restore_passed=True,broader_oracle_pending=True,production_changed=False,owned_latency_processes_running=False,script_sha256=sha(Path(__file__)),source_plan_sha256=sha(b/'torch-iteration-420/source-plan.json'),goal_status='active')
(r/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
