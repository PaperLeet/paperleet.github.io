"""Independent native controls for exactly which binary values backward saves."""
from pathlib import Path
import importlib.util,itertools,json,sys
import numpy as np
import torch as native
r=Path(__file__).resolve().parent;b=r.parent
source=b/'torch-iteration-434/prototype/stridetorch';spec=importlib.util.spec_from_file_location('_binary433',source/'__init__.py',submodule_search_locations=[str(source)]);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)

def exercise(torch,operation,activity,mutation):
 a=torch.tensor([2.,3.],dtype=torch.float64,requires_grad=activity[0]);c=torch.tensor([4.,5.],dtype=torch.float64,requires_grad=activity[1])
 if operation=='multiply':y=a*c
 elif operation=='divide':y=a/c
 elif operation=='scalar_multiply':y=a*2.
 elif operation=='scalar_divide':y=a/2.
 elif operation=='reflected_divide':y=2./a
 else:raise AssertionError(operation)
 targets=[x for x in [a,c] if x.requires_grad];target={'left':a,'right':c,'output':y}[mutation]
 with torch.no_grad():target.detach().fill_(7.)
 error=None;values=None
 try:values=[x.detach().numpy().copy().tolist() for x in torch.autograd.grad(y.sum(),targets,allow_unused=True) if x is not None]
 except Exception as exc:error=dict(type=type(exc).__name__,message=str(exc))
 return dict(error=error,gradients=values)
rows=[]
for operation in ['multiply','divide','scalar_multiply','scalar_divide','reflected_divide']:
 for activity in [(True,False),(False,True),(True,True)]:
  if operation not in ['multiply','divide'] and not activity[0]:continue
  for mutation in ['left','right','output']:
   expected=exercise(native,operation,activity,mutation);actual=exercise(module.torch,operation,activity,mutation)
   same=(expected['error'] is None)==(actual['error'] is None)
   if same and expected['gradients'] is not None:same=np.allclose(expected['gradients'],actual['gradients'],rtol=1e-12,atol=1e-12)
   rows.append(dict(operation=operation,activity=activity,mutation=mutation,native=expected,candidate=actual,matched=bool(same)))
result=dict(status='observed',rows=rows,mismatches=sum(not x['matched'] for x in rows),native_torch=native.__version__,production_changed=False)
assert not (r/'result.json').exists();(r/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(cases=len(rows),mismatches=result['mismatches'])))
