from pathlib import Path
import hashlib,io,json,shutil,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
assert read(b/'torch-iteration-442/result.json')['status']=='passed_full_native_sdk_and_gradient_binary_controls'
assert read(b/'torch-iteration-444/result.json')['report']['passed']==12285
assert read(b/'torch-iteration-447/result.json')['passed']==12285
assert read(b/'torch-iteration-453/result.json')['version']=='0.82.0'
for folder,target in [(repo/'packages/stridetorch/src/stridetorch',r/'canonical/stridetorch'),(repo/'packages/stridetorch/tests',r/'contracts')]:
 target.mkdir(parents=True)
 for p in folder.iterdir():
  if p.is_file() and (p.suffix=='.py' or p.name in ['LICENSE','NOTICE']):shutil.copy2(p,target/p.name)
for origin,name in [(repo/'packages/stridetorch/README.md','README.md'),(repo/'packages/stridetorch/pyproject.toml','pyproject.toml'),(repo/'tests/test_torch_gradient_utilities.py','application-test.py')]:shutil.copy2(origin,r/name)
files=[]
for stage in [420,424,425,426,428,429,430,431,433,434,435,436,437,438,439,440,441,442,443,444,447,448,449,454]:
 files += [p for p in (b/f'torch-iteration-{stage}').rglob('*') if p.is_file() and '__pycache__' not in p.parts]
for stage in [450,451,452,453]:
 folder=b/f'torch-iteration-{stage}'
 for p in folder.iterdir():
  if p.is_file() and not (stage==451 and p.name not in ['run.py','plan.json']):files.append(p)
 if stage==453:
  files += [p for sub in ['public-dist','private-dist','public-rebuild','private-rebuild'] for p in (folder/sub).iterdir() if p.is_file()]
for name in ['torch-iteration-76/chrome-sdk/packages.mjs','torch-iteration-70/fixture-server.mjs']:files.append(b/name)
source_manifest={p.name:sha(p) for p in (r/'canonical/stridetorch').iterdir()};assert len(source_manifest)==66
for p in (b/'torch-iteration-441/prototype/stridetorch').iterdir():
 if p.is_file() and p.name!='__init__.py':assert source_manifest[p.name]==sha(p),p.name
secondary=read(b/'torch-iteration-454/numpy25.json');assert len(secondary['mismatches'])==3 and all(x['issues']==['error_class'] for x in secondary['mismatches'])
summary=dict(status='development_candidate_functional_evidence_complete_application_gate_pending',version='0.82.0',source_resources=source_manifest,native_isolated=read(b/'torch-iteration-442/result.json'),wasm_node=read(b/'torch-iteration-447/result.json'),wasm_chrome=read(b/'torch-iteration-444/result.json'),packaging=read(b/'torch-iteration-453/result.json'),secondary_native214=dict(cases=478,matching_all_checks=475,error_class_differences=[dict(case=x['key'],native=x['native']['error']['type'],candidate=x['candidate']['error']['type']) for x in secondary['mismatches']],numerical_or_mutation_mismatches=0),canonical_sdk25=read(b/'torch-iteration-450/progress.json')['results'][0],final_application_gate='451live;notcapturedascompleted',wasm_version_note='IsolatedWASMsourceversionliteral0.81.0;canonical0.82differsonly__init__version;finalapplicationexportandcatalogvalidationpending',terminal_hvp_optimization_adopted=False,main_updated=False,ci_triggered=False,published=False,goal_status='active')
write(r/'development-results.json',summary)
write(r/'replay-dependencies.json',dict(external=['Python3.12.11NumPy2.5.4Torch2.14.1','Python3.10.19NumPy1.26.4Torch2.6.0','Node22.22.1','Chrome155.0.8059.82','Pyodide0.29.4Python3.13.2NumPy2.2.5andpytestwheels;runtime76notincluded'],notes=['Adaptabsoluteenvironmentpathswhenreplaying','Generatedwheel/sdistpayloadsandallstandalonesourcesareincluded','Noqualifiedenvironmentsremovedorchanged','Originalfailuresretained:424aliasexpectation,437attentionguard,443dynamiccount,450minimumenvprivateimport,452generatedegg-infomanifest']))
files += [p for p in r.rglob('*') if p.is_file() and p.suffix not in ['.gz'] and p.name!='archive-receipt.json']
files=sorted(set(files));manifest={str(p.relative_to(b)):sha(p) for p in files};target=r/'gradient-utilities-0.82-development-harness.tar.gz';assert not target.exists();seen={}
with tarfile.open(target,'w:gz') as archive:
 for p in files:
  name=str(p.relative_to(b));h=manifest[name]
  if h in seen:
   info=archive.gettarinfo(str(p),arcname=name);info.type=tarfile.LNKTYPE;info.linkname=seen[h];info.size=0;archive.addfile(info)
  else:archive.add(p,arcname=name,recursive=False);seen[h]=name
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256.json');info.size=len(data);archive.addfile(info,io.BytesIO(data))
with tarfile.open(target) as archive:
 for name,h in manifest.items():assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==h,name
receipt=dict(path=str(target),files=len(files),unique_payloads=len(seen),bytes=target.stat().st_size,sha256=sha(target),all_payloads_verified=True);write(r/'archive-receipt.json',receipt);print(json.dumps(receipt))
