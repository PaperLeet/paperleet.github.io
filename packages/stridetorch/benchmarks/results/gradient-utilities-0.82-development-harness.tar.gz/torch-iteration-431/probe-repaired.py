"""One-shot checks of the repaired isolated gradient prototype after all timing."""
from pathlib import Path
import hashlib,json,os,subprocess,time,traceback
r=Path(__file__).resolve().parent;b=r.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
plan=read(r/'plan.json');receipts=[]
def verify():
 assert sha(Path(__file__))==plan['runner_sha256']
 for name,h in plan['files'].items():assert sha(b/name)==h,name
 for name,h in read(b/'torch-iteration-430/source-plan.json')['inputs'].items():assert sha(b/'torch-iteration-430'/name)==h,name
def progress(status,**details):write(r/'progress.json',dict(status=status,pid=os.getpid(),receipts=receipts,observed_unix=time.time(),**details))
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
for key in ['PYTHONPATH','PYTHONTRACEMALLOC','PYTHONPROFILEIMPORTTIME']:env.pop(key,None)
try:
 verify();progress('waiting_for_post_timing_diagnostics',predecessor_pid=plan['predecessor_pid'])
 while True:
  state=read(b/'torch-iteration-428/progress.json')
  if state['status']=='failed':raise RuntimeError('Predecessor failed; preserve evidence and stop dependent probes')
  if state['status']=='completed':break
  observed=subprocess.run(['/bin/ps','-p',str(plan['predecessor_pid']),'-o','command='],capture_output=True,text=True)
  assert observed.returncode==0 and 'torch-iteration-428/after-timing.py' in observed.stdout,'Predecessor handle missing without completion'
  time.sleep(3)
 for job in plan['jobs']:
  verify();log=r/(job['label']+'.log');assert not log.exists();progress('running_probe',label=job['label']);started=time.time();jobenv=dict(env)
  if job.get('pytest'):jobenv['PYTHONPATH']=str(b/'torch-iteration-430/prototype')
  with log.open('w') as output:
   child=subprocess.Popen(job['command'],cwd=r,env=jobenv,stdout=output,stderr=subprocess.STDOUT);progress('running_probe',label=job['label'],child_pid=child.pid);code=child.wait()
  receipts.append(dict(label=job['label'],exit_code=code,seconds=time.time()-started,log_sha256=sha(log)));verify()
 result=dict(status='completed_repaired_prototype_checks',receipts=receipts,reports={name:read(r/(name+'.json'))['status'] for name in ['numpy126','numpy25'] if (r/(name+'.json')).exists()},production_changed=False,goal_status='active')
 write(r/'result.json',result);progress('completed');print(json.dumps(result),flush=True)
except BaseException as error:progress('failed',error=str(error),traceback=traceback.format_exc());raise
