Fresh corrected smoke after retained 424 assertion failure.
Original numerical implementation 420 unchanged; only wrapper-identity expectation corrected.
Compare imports with as_torch()'s yielded namespace, not wrappers from a separate create_torch factory.
Do not execute concurrently with latency jobs.
