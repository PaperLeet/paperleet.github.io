"""Dense NumPy gradient utilities; execution hints do not imply fused kernels."""
import warnings

import numpy as np

from . import _autograd, _defaults, _ops, _tensor, _vector_norm


def _parameters(parameters):
    return [parameters] if isinstance(parameters, _tensor.Tensor) else list(parameters)


def _execution_hint(foreach):
    # All supported hints currently use per-gradient NumPy kernels. Preserve
    # ordinary truth-value validation, without claiming a native foreach/GPU API.
    if foreach is not None:
        bool(foreach)


def _total_norm(gradients, norm_type, error_if_nonfinite, foreach):
    order = float(norm_type)
    if not gradients:
        return _tensor.Tensor(np.asarray(0., dtype=_defaults._float_dtype), _metadata_owned=True)
    _execution_hint(foreach)
    norms = [_vector_norm.vector_norm(gradient, ord=order) for gradient in gradients]
    total = _vector_norm.vector_norm(_ops.stack(norms), ord=order)
    if error_if_nonfinite and not np.isfinite(total._data).item():
        raise RuntimeError('The total gradient norm is non-finite; set error_if_nonfinite=False to scale by it.')
    return total


@_autograd.no_grad()
def clip_grad_norm_(parameters, max_norm, norm_type=2., error_if_nonfinite=False, foreach=None):
    parameters = _parameters(parameters)
    gradients = [parameter.grad for parameter in parameters if parameter.grad is not None]
    total = _total_norm(gradients, norm_type, error_if_nonfinite, foreach)
    maximum = float(max_norm)
    if gradients:
        coefficient = (maximum / (total + 1e-6)).clamp(max=1.)
        for gradient in gradients:
            gradient.mul_(coefficient)
    return total


def clip_grad_norm(parameters, max_norm, norm_type=2., error_if_nonfinite=False, foreach=None):
    warnings.warn('clip_grad_norm is deprecated; use clip_grad_norm_ instead.', FutureWarning, stacklevel=2)
    return clip_grad_norm_(parameters, max_norm, norm_type, error_if_nonfinite, foreach)


@_autograd.no_grad()
def clip_grad_value_(parameters, clip_value, foreach=None):
    parameters = _parameters(parameters)
    bound = float(clip_value)
    gradients = [parameter.grad for parameter in parameters if parameter.grad is not None]
    if not gradients:
        # Kept explicit until the pinned native empty-list oracle is observed.
        raise RuntimeError('Gradient value clipping requires at least one gradient.')
    _execution_hint(foreach)
    for gradient in gradients:
        if gradient.dtype.kind != 'f':
            raise RuntimeError('Gradient value clipping requires real floating storage.')
        if np.isfinite(bound) and abs(bound) > np.finfo(gradient.dtype).max:
            raise RuntimeError('The clipping bound cannot be represented by the gradient dtype.')
        with np.errstate(all='ignore'):
            low, high = np.asarray(-bound, dtype=gradient.dtype), np.asarray(bound, dtype=gradient.dtype)
            # Explicit maximum/minimum also preserve NaN-bound semantics on
            # minimum NumPy; older np.clip can treat scalar NaN as no bound.
            value = np.minimum(np.maximum(gradient._data, low), high)
        gradient[...] = _tensor.Tensor(value, _metadata_owned=True)
