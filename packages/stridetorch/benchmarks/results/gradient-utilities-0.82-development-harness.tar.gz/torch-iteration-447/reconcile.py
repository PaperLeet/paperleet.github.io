from pathlib import Path
import collections,hashlib,json,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent;b=r.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
plan=read(b/'torch-iteration-443/source-plan.json')
for name,h in plan['files'].items():assert sha(b/'torch-iteration-443'/name)==h,name
report=read(b/'torch-iteration-443/result.json');assert report['exit_code']==0 and not report['failures'] and report['skipped']==0 and report['status']=='failed' and report['expected_passed']==12283
old=collections.Counter((x.attrib['classname'],x.attrib['name']) for x in ET.parse(b/'torch-iteration-382/numpy25.xml').iter('testcase'))
new=collections.Counter((x.attrib['classname'],x.attrib['name']) for x in ET.parse(b/'torch-iteration-442/numpy25.xml').iter('testcase'))
assert not old-new
extra=new-old;dynamic={k:v for k,v in extra.items() if k[0]};assert dynamic=={('tests.test_feature_detection','test_namespace_missing_symbols_support_default_and_typed_lookup[torch.nn.utils]'):1,('tests.test_feature_detection','test_namespace_missing_symbols_support_default_and_typed_lookup[torch.nn.utils.clip_grad]'):1}
assert sum(v for k,v in extra.items() if not k[0])==71
assert report['passed']==12212+71+2==12285
assert report['gradient_oracle']==dict(status='passed',cases=478,mismatches=0,version_differences=0)
assert '\n12285 passed,' in (b/'torch-iteration-443/run.log').read_text()
for p in (b/'torch-iteration-386/contracts').glob('*.py'):assert sha(p)==sha(b/'torch-iteration-443/contracts'/p.name)
result=dict(status='verified_full_functional_node_wasm_sdk_with_reconciled_dynamic_count',passed=report['passed'],skipped=0,failures=[],gradient_oracle=report['gradient_oracle'],initial_fixed_count_guard_status='failed_preserved',expected_count_derivation=dict(unchanged_wasm_contracts=12212,new_explicit_cases=71,new_module_feature_detection_cases=2,total=12285),measurement_repeated=False,runtime_or_tests_changed=False,original_result_sha256=sha(b/'torch-iteration-443/result.json'),original_failure_sha256=sha(b/'torch-iteration-443/failure.json'),source_plan_sha256=sha(b/'torch-iteration-443/source-plan.json'),native_xml_sha256=sha(b/'torch-iteration-442/numpy25.xml'))
(r/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
