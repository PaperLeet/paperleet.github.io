from pathlib import Path
import hashlib,json,sys,warnings
import torch
import numpy as np
from cases import specs,exercise
r=Path(__file__).resolve().parent;target=Path(sys.argv[1]);assert not target.exists()
with warnings.catch_warnings():
 warnings.simplefilter('ignore');rows=[exercise(torch,spec) for spec in specs()]
result=dict(torch=torch.__version__,numpy=np.__version__,cases_sha256=hashlib.sha256((r/'cases.py').read_bytes()).hexdigest(),rows=rows)
target.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(torch=torch.__version__,cases=len(rows),errors=sum(x['error'] is not None for x in rows))))
