Prepared during serial latency runs; no numerical execution overlaps the timing campaign.
Oracle must be generated on actual native Torch 2.6 before probing the isolated runtime.
The earlier 424 alias test compared wrappers from different namespace factories.
Its correction must compare imports to the namespace yielded by as_torch(), then restore all cached native modules.
Value and mutation behavior is compared independently across dense/strided/shared/duplicate/no-gradient/nonfinite/complex/half/scalar cases.
Version deltas are retained separately as a diagnostic until implementation repair; value/state mismatches are failures.
