"""One-shot dependent numerical probes; never overlap the owned latency campaign."""
from pathlib import Path
import hashlib,json,os,subprocess,time,traceback
r=Path(__file__).resolve().parent;b=r.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,value:p.write_text(json.dumps(value,indent=2)+'\n')
plan=read(r/'plan.json');receipts=[]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
for key in ['PYTHONPATH','PYTHONTRACEMALLOC','PYTHONPROFILEIMPORTTIME']:env.pop(key,None)
def progress(status,**details):write(r/'progress.json',dict(status=status,pid=os.getpid(),receipts=receipts,observed_unix=time.time(),**details))
def verify():
 assert sha(Path(__file__))==plan['runner_sha256']
 for name,wanted in plan['files'].items():assert sha(b/name)==wanted,name
 for name,wanted in read(b/'torch-iteration-420/source-plan.json')['inputs'].items():assert sha(b/'torch-iteration-420'/name)==wanted,name
try:
 verify();progress('waiting_for_live_latency_campaign',latency_supervisor_pid=plan['latency_supervisor_pid'])
 while True:
  state=read(b/'torch-iteration-423/progress.json')
  if state['status']=='failed':raise RuntimeError('Latency supervisor failed; preserve failure, do not start dependent numerical probes')
  if state['status']=='completed':
   assert read(b/'torch-iteration-423/result.json')['status']=='completed_four_unrun_processes'
   break
  observed=subprocess.run(['/bin/ps','-p',str(plan['latency_supervisor_pid']),'-o','command='],capture_output=True,text=True)
  assert observed.returncode==0 and 'torch-iteration-423/campaign.py' in observed.stdout,'Latency handle missing without completed result'
  time.sleep(3)
 verify()
 for job in plan['jobs']:
  log=r/(job['label']+'.log');assert not log.exists();progress('running_dependent_probe',label=job['label']);started=time.time()
  with log.open('w') as output:
   child=subprocess.Popen(job['command'],cwd=b,env=env,stdout=output,stderr=subprocess.STDOUT);progress('running_dependent_probe',label=job['label'],child_pid=child.pid);code=child.wait()
  receipts.append(dict(label=job['label'],exit_code=code,seconds=time.time()-started,log_sha256=sha(log)))
  assert code==0,receipts[-1];verify()
 result=dict(status='completed_planned_post_timing_diagnostics',receipts=receipts,precision_status=read(b/'torch-iteration-427/result.json')['status'],corrected_smoke_status=read(b/'torch-iteration-426/result.json')['status'],prototype_numpy126_status=read(r/'prototype-numpy126.json')['status'],prototype_numpy25_status=read(r/'prototype-numpy25.json')['status'],production_changed=False,goal_status='active')
 write(r/'result.json',result);progress('completed');print(json.dumps(result),flush=True)
except BaseException as error:progress('failed',error=str(error),traceback=traceback.format_exc());raise
