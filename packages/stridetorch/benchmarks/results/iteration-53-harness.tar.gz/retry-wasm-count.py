from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib,json,os,subprocess,time

r=Path(__file__).resolve().parent;p=r/'proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release')
receipts=json.loads((p/'gate-receipts.json').read_text())
assert receipts['build-public']['exit_code']==receipts['build-private']['exit_code']==0
expected=json.loads((p/'source-hashes.json').read_text())
for name,h in expected.items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==h
env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
py=r.parent/'torch-iteration-21/stride-dev-env/bin/python'
def run(name,args):
    start=time.monotonic()
    with (p/(name+'.log')).open('w') as log:child=subprocess.run([str(x) for x in args],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
    return name,dict(exit_code=child.returncode,elapsed_s=time.monotonic()-start,args=[str(x) for x in args],cwd=str(repo))
with ThreadPoolExecutor(max_workers=2) as pool:
    plans=[('node-wasm',['/opt/homebrew/bin/node',p/'wasm-contracts.mjs']),('chrome-worker',['/opt/homebrew/bin/node',p/'chrome-contracts/run.mjs'])]
    for future in as_completed([pool.submit(run,*plan) for plan in plans]):
        name,row=future.result();receipts[name]=row
        (p/'gate-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,'TERMINAL',row['exit_code'],flush=True)
assert all(v['exit_code']==0 for v in receipts.values())
with ThreadPoolExecutor(max_workers=2) as pool:
    plans=[('minimal-wheel',[py,p/'check-wheel.py']),('coinstall',[py,p/'check-coinstall.py'])]
    for future in as_completed([pool.submit(run,*plan) for plan in plans]):
        name,row=future.result();receipts[name]=row
        (p/'gate-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,'TERMINAL',row['exit_code'],flush=True)
assert len(receipts)==6 and all(v['exit_code']==0 for v in receipts.values())
