from pathlib import Path
import hashlib,json,subprocess

r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
before='a09a548597002d1dba7ed81ff29c59837b31be1c';after='1eb718f26f3d7ba4f48a61d5011a17fe66aef7f9'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
assert git('rev-parse','HEAD')==before and git('rev-parse','FETCH_HEAD')==after
assert not git('diff','--cached','--name-only')
incoming=git('diff','--name-only',before,after).splitlines()
assert len(incoming)==18 and all(n.startswith('web/') and not n.startswith(('web/public/','web/scripts/check-browser-wasm','web/scripts/wasm-cases')) for n in incoming)
assert 'web/package-lock.json' not in incoming
dirty=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert not dirty.intersection(incoming)
records=[(repo/'packages/stridetorch/src/stridetorch',r/'proof/source-hashes.json'),(repo/'web/public/data',r/'integration-proof/live-expected-sha256.json')]
for root,f in records:
    for n,h in json.loads(f.read_text()).items():assert sha(root/n)==h
subprocess.run(['git','merge','--ff-only',after],cwd=repo,check=True)
for root,f in records:
    for n,h in json.loads(f.read_text()).items():assert sha(root/n)==h
for n,h in json.loads((r/'native-catalog-input-identity.json').read_text())['files'].items():assert sha(repo/n)==h
paths={n:sha(repo/n) for n in incoming}
for n,h in paths.items():assert hashlib.sha256(subprocess.check_output(['git','show',after+':'+n],cwd=repo)).hexdigest()==h
record=dict(before=before,after=after,paths=paths,receipts='integration-proof/frontend-receipts.json',
    numerical_source_and_exports_identical=True,native_catalog_inputs_identical=1152,
    scope='Fast-forward before local feature commit; preserve all 18 incoming UI files as exact Git blobs. Final frontend/build checks run on the synchronized tree; CPU/native/package/benchmark inputs are unchanged.')
(r/'upstream-syncs.json').write_text(json.dumps([record],indent=2)+'\n')
print(json.dumps(dict(status='synchronized',before=before,after=after,paths=len(paths))))
