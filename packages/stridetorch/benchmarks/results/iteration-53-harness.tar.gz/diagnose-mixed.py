from pathlib import Path
import contextlib,itertools,json,warnings
import numpy as np
import torch
from torch.nn.attention import sdpa_kernel,SDPBackend

torch.set_num_threads(1);torch.backends.mha.set_fastpath_enabled(False)
r=Path(__file__).resolve().parent
native=np.load(r/'native-transformer.npz');adapter=np.load(r/'adapter-transformer.npz')
cases=list(itertools.product(['float32','float64'],['sequence','batch','unbatched'],[False,True],['relu','gelu'],['none','boolean','causal'],['encoder_layer','decoder_layer','encoder','decoder','full']))
def create(kind,layout,pre,activation,bias):
    opts=dict(dim_feedforward=7,dropout=0.,activation=activation,norm_first=pre,batch_first=layout=='batch',bias=bias,dtype=torch.float32)
    if kind=='encoder_layer':return torch.nn.TransformerEncoderLayer(4,2,**opts)
    if kind=='decoder_layer':return torch.nn.TransformerDecoderLayer(4,2,**opts)
    if kind=='encoder':return torch.nn.TransformerEncoder(torch.nn.TransformerEncoderLayer(4,2,**opts),2,torch.nn.LayerNorm(4,bias=bias),enable_nested_tensor=False)
    if kind=='decoder':return torch.nn.TransformerDecoder(torch.nn.TransformerDecoderLayer(4,2,**opts),2,torch.nn.LayerNorm(4,bias=bias))
    return torch.nn.Transformer(4,2,2,2,**opts)
rows=[]
for index in [34,49,92,162,179]:
    dtype,layout,pre,activation,mask_kind,kind=cases[index];rng=np.random.default_rng(530000+index)
    with warnings.catch_warnings():warnings.simplefilter('ignore');m=create(kind,layout,pre,activation,index%7!=0)
    with torch.no_grad():
        for name,p in m.named_parameters():p.copy_(torch.tensor(rng.normal(1 if 'norm' in name and name.endswith('weight') else 0,.2,size=p.shape).astype(dtype)))
    def shape(length):return (length,4) if layout=='unbatched' else (2,length,4) if layout=='batch' else (length,2,4)
    encoder=kind in ['encoder_layer','encoder'];length=4 if encoder else 3
    inputs=[torch.tensor(np.asfortranarray(rng.normal(0,.5,size=shape(length)).astype(dtype)),requires_grad=True)]
    if not encoder:inputs.append(torch.tensor(np.asfortranarray(rng.normal(0,.5,size=shape(4)).astype(dtype)),requires_grad=True))
    batch=1 if layout=='unbatched' else 2;mask=padding=memory_mask=memory_padding=None
    if mask_kind=='boolean':
        data=rng.random((length,length))<.2;data[:,0]=False;mask=torch.tensor(data)
        data=rng.random((batch,length))<.2;data[:,0]=False;padding=torch.tensor(data[0] if layout=='unbatched' else data)
        if not encoder:
            data=rng.random((length,4))<.2;data[:,0]=False;memory_mask=torch.tensor(data)
            data=rng.random((batch,4))<.2;data[:,0]=False;memory_padding=torch.tensor(data[0] if layout=='unbatched' else data)
    elif mask_kind=='causal':mask=torch.nn.Transformer.generate_square_subsequent_mask(length,dtype=torch.float64)
    # Match all float32 fixture values before promoting to the float64 oracle.
    seed=torch.tensor(rng.normal(size=inputs[0].shape).astype(dtype),dtype=torch.float64)
    directions=tuple(torch.tensor(rng.normal(size=x.shape).astype(dtype),dtype=torch.float64,requires_grad=True) for x in inputs)
    m.double();inputs=[x.detach().double().requires_grad_() for x in inputs]
    def call(*x):
        if kind=='encoder_layer':return m(x[0],src_mask=mask,src_key_padding_mask=padding,is_causal=mask_kind=='causal')
        if kind=='encoder':return m(x[0],mask=mask,src_key_padding_mask=padding)
        if kind=='full':return m(x[1],x[0],tgt_mask=mask,tgt_key_padding_mask=padding,memory_mask=memory_mask,memory_key_padding_mask=memory_padding)
        return m(*x,tgt_mask=mask,tgt_key_padding_mask=padding,memory_mask=memory_mask,memory_key_padding_mask=memory_padding,**({'tgt_is_causal':True} if mask_kind=='causal' and kind=='decoder_layer' else {}))
    with sdpa_kernel(SDPBackend.MATH):
        p,t=torch.func.jvp(call,tuple(inputs),directions)
        grads=torch.autograd.grad((p*seed+t*seed).sum(),inputs+list(m.parameters())+list(directions),allow_unused=True)
    details=[]
    for i,g in enumerate(grads):
        key=f'case{index}.m{i}'
        if g is None:continue
        high=g.detach().numpy();n=native[key];a=adapter[key]
        ne=float(np.max(abs(high-n),initial=0));ae=float(np.max(abs(high-a),initial=0))
        scale=float(np.max(abs(high),initial=0))
        if ne>1e-5 or ae>1e-5:details.append(dict(key=key,scale=scale,native32_error_to_64=ne,adapter32_error_to_64=ae,native_adapter_error=float(np.max(abs(n-a),initial=0))))
    rows.append(dict(index=index,kind=kind,layout=layout,pre_norm=pre,activation=activation,mask=mask_kind,arrays=details))
(r/'mixed-roundoff-diagnosis.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
