from pathlib import Path
import argparse,runpy,shutil,sys
import numpy as np

p=argparse.ArgumentParser();p.add_argument('variant',choices=['stats64','tangent64','both','projection']);a=p.parse_args()
r=Path(__file__).resolve().parent;target=r/('precision-'+a.variant);target.mkdir(exist_ok=True)
shutil.copy2(r/'differential-transformer.py',target/'differential-transformer.py')
sys.path.insert(0,'/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src')
from stridetorch import _normalization as n,_autograd as ad,_tensor as tensor
original=n._layer_statistics
def statistics(source,axes,shape):
    if source.dtype!=np.float32:return original(source,axes,shape)
    high=source.astype(np.float64);delta=high-high.mean(axis=axes,keepdims=True)
    return delta.astype(np.float32),np.mean(delta*delta,axis=axes,keepdims=True).astype(np.float32)
if a.variant in ['stats64','both']:n._layer_statistics=statistics
if a.variant in ['tangent64','both']:
    previous=n._forward
    def forward(kind,input,shape,weight,bias,eps):
        x,dx=ad.forward_parts(input)
        if kind!='layer' or x.dtype!=np.float32 or not x.numel():return previous(kind,input,shape,weight,bias,eps)
        w,dw=ad.forward_parts(weight) if weight is not None else (None,None)
        b,db=ad.forward_parts(bias) if bias is not None else (None,None)
        primal=n._normalize(kind,x,shape,w,b,eps)
        axes=tuple(range(x.ndim-len(shape),x.ndim))
        high=x._data.astype(np.float64);centered=high-high.mean(axis=axes,keepdims=True)
        inverse=tensor.Tensor(1/np.sqrt(np.mean(centered*centered,axis=axes,keepdims=True)+eps))
        center=ad.result(centered,(x,lambda g:g))
        direction=dx.to(dtype=np.float64);projected=direction-direction.mean(axes,True)
        slope=(-inverse.pow(3)*projected*center).mean(axes,True)
        tangent=projected*inverse+center*slope
        if w is not None:tangent=tangent*w.to(dtype=np.float64)+(center*inverse)*dw.to(dtype=np.float64)
        if b is not None:tangent=tangent+db.to(dtype=np.float64)
        return ad.ForwardTensor(primal,tangent.to(dtype=np.float32))
    n._forward=forward
elif a.variant=='projection':
    previous=n._forward
    def forward(kind,input,shape,weight,bias,eps):
        x,dx=ad.forward_parts(input)
        if kind!='layer' or not x.numel():return previous(kind,input,shape,weight,bias,eps)
        w,dw=ad.forward_parts(weight) if weight is not None else (None,None)
        b,db=ad.forward_parts(bias) if bias is not None else (None,None)
        primal=n._normalize(kind,x,shape,w,b,eps)
        axes=tuple(range(x.ndim-len(shape),x.ndim));data,variance=n._layer_statistics(x._data,axes,shape)
        inverse=tensor.Tensor(1/np.sqrt(variance+eps));center=ad.result(data,(x,lambda g:g))
        projected=dx-dx.mean(axes,True);normalized=center*inverse
        tangent=(projected-normalized*(projected*normalized).mean(axes,True))*inverse
        if w is not None:tangent=tangent*w+normalized*dw
        if b is not None:tangent=tangent+db
        return ad.ForwardTensor(primal,tangent)
    n._forward=forward
sys.argv=[str(target/'differential-transformer.py'),'adapter']
runpy.run_path(sys.argv[0],run_name='__main__')
