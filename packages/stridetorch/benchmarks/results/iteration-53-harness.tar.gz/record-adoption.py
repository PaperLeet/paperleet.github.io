from pathlib import Path
import datetime,hashlib,json,subprocess

r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
def command(*args):return subprocess.check_output(args,cwd=repo,text=True).strip()
def read(name):return json.loads((r/name).read_text())
head=command('git','rev-parse','HEAD')
remote=command('gh','api','repos/PaperLeet/paperleet.github.io/git/ref/heads/main','--jq','.object.sha')
assert head==remote and not command('git','status','--porcelain')
actions=json.loads(command('gh','api',f'repos/PaperLeet/paperleet.github.io/actions/runs?head_sha={head}&per_page=100'))
assert actions['total_count']==0
source=read('proof/source-hashes.json');live=read('integration-proof/live-expected-sha256.json');policy=read('release-policy-identity.json')
for name,h in source.items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==h
for name,h in live.items():assert hashlib.sha256((repo/'web/public/data'/name).read_bytes()).hexdigest()==h
for name,h in policy['files'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==h
immutable=len(subprocess.check_output(['git','ls-files','-z','--','web/public/data/browser-judge','web/public/data/modules'],cwd=repo).split(b'\0'))-1
assert len(source)==57 and len(live)==161 and immutable==11493
record=dict(status='source_adopted_on_main',version='0.53.0',source_commit=head,observed_remote_main=remote,
    observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actions_runs_for_source_sha=0,
    source_resources=source,active_export_sha256=live,canonical_release_policy=policy,immutable_payloads=immutable,
    scope='Ordinary non-force main push after exact source/test/package/frontend/native-oracle/exported-catalog gates. Fresh 12-process CPU/Node/Chrome timing covers the final source, with explicit FP32 mixed-AD roundoff qualification. No tag,workflow dispatch,release,package upload or deployment initiated. Separate proof commit follows; final proof identity is recorded outside Git to avoid recursive commit identities.')
(repo/'packages/stridetorch/benchmarks/results/iteration-53-main-adoption.json').write_text(json.dumps(record,indent=2)+'\n')
doc=repo/'docs/validation/torch-runtime-iteration-53.md';text=doc.read_text();assert '## Main adoption' not in text
text+=f'''\n## Main adoption

Validated source `{head}` was adopted on remote main by ordinary non-force push.
The remote SHA matched exactly, with zero observed Actions runs for that SHA.
All 57 source/license resources, 161 active exports, 11,493 immutable payloads
and seven canonical release-policy files were rechecked. A separate proof commit
records this observation; its final main identity is checked outside the repository.
No tag, workflow dispatch, release, PyPI upload or deployment was initiated.
The broader library efficiency/core-coverage/backend objective remains active.
'''
doc.write_text(text)
print('RECORDED SOURCE_MAIN',head,flush=True)
