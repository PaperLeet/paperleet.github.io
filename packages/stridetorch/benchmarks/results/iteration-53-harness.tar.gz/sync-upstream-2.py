from pathlib import Path
import hashlib,json,shutil,subprocess

r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
old='1eb718f26f3d7ba4f48a61d5011a17fe66aef7f9';new='0ef753cc0c194edf66b4aaf759ec7ee169511f41'
base='a09a548597002d1dba7ed81ff29c59837b31be1c'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
assert git('rev-parse','HEAD')==old and git('rev-parse','FETCH_HEAD')==new and not git('diff','--cached','--name-only')
incoming=git('diff','--name-only',old,new).splitlines()
assert len(incoming)==9 and all(n.startswith('web/') and not n.startswith('web/public/') for n in incoming)
assert 'web/package-lock.json' not in incoming
dirty=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert not dirty.intersection(incoming)
out=repo/'packages/stridetorch/benchmarks/results';record=json.loads((out/'iteration-53.json').read_text())
backup=r/'pre-sync-0ef-local-proof';backup.mkdir()
owned=[out/n for n in record['raw_archives']]+[out/'iteration-53.json',out/'iteration-53-integration.json']
for name,data in record['raw_archives'].items():assert sha(out/name)==data['sha256']
for f in owned:
    assert subprocess.run(['git','ls-files','--error-unmatch',str(f.relative_to(repo))],cwd=repo,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==1
    shutil.move(str(f),str(backup/f.name))
i=r/'integration-proof';front=json.loads((i/'frontend-receipts.json').read_text());assert len(front)==5 and all(v['exit_code']==0 for v in front)
previous=i/'frontend-before-sync-0ef';previous.mkdir()
for n in ['frontend-receipts.json','pages-profile.json',*[v['log'] for v in front]]:shutil.copy2(i/n,previous/n)
subprocess.run(['git','merge','--ff-only',new],cwd=repo,check=True)
for folder,f in [(repo/'packages/stridetorch/src/stridetorch',r/'proof/source-hashes.json'),(repo/'web/public/data',i/'live-expected-sha256.json')]:
    for n,h in json.loads(f.read_text()).items():assert sha(folder/n)==h
for n,h in json.loads((r/'native-catalog-input-identity.json').read_text())['files'].items():assert sha(repo/n)==h
allpaths=git('diff','--name-only',base,new).splitlines();paths={n:sha(repo/n) for n in allpaths}
assert len(paths)==25
for n,h in paths.items():assert hashlib.sha256(subprocess.check_output(['git','show',new+':'+n],cwd=repo)).hexdigest()==h
sync=dict(before=base,after=new,paths=paths,receipts='integration-proof/frontend-receipts.json',
    numerical_source_and_exports_identical=True,native_catalog_inputs_identical=1152,
    steps=[dict(before=base,after=old,frontend_receipts='integration-proof/frontend-before-sync-0ef/frontend-receipts.json'),dict(before=old,after=new)],
    scope='Preserve the latest upstream versions of all 25 UI paths by fast-forward before feature commit. Prior local proof retained externally, earlier frontend logs archived. Final frontend/build checks rerun; numerical/test/export inputs unchanged.')
(r/'upstream-syncs.json').write_text(json.dumps([sync],indent=2)+'\n')
print(json.dumps(dict(status='synchronized',after=new,latest_paths=len(paths))))
