from pathlib import Path
import subprocess,sys,json,os

r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
expected='0ef753cc0c194edf66b4aaf759ec7ee169511f41'
def run(args):subprocess.run([str(x) for x in args],cwd=repo,check=True)
remote=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/git/ref/heads/main','--jq','.object.sha'],cwd=repo,text=True).strip()
assert remote==expected,dict(expected=expected,actual=remote)
front=json.loads((r/'integration-proof/frontend-receipts.json').read_text())
assert len(front)==5 and all(v['exit_code']==0 for v in front)
run([sys.executable,r/'audit-main.py',expected])
run([sys.executable,r/'close-local.py'])
run([sys.executable,r/'write-report.py'])
paths=['packages/stridetorch/README.md','packages/stridetorch/pyproject.toml',
       *['packages/stridetorch/src/stridetorch/'+n for n in ['__init__.py','_activation.py','_api.py','_multihead.py','_nn.py','_normalization.py','_transformer.py']],
       'packages/stridetorch/tests/test_transformer.py','packages/stridetorch/benchmarks/bench_transformer.py',
       'docs/validation/torch-runtime-iteration-53.md',
       *['packages/stridetorch/benchmarks/results/'+n for n in ['iteration-53.json','iteration-53-integration.json',
          'iteration-53-harness.tar.gz','iteration-53-precision-harness.tar.gz','iteration-53-runtime-harness.tar.gz','iteration-53-integration-harness.tar.gz','iteration-53-performance-harness.tar.gz']],
       'web/public/data/catalog.json','web/public/data/index.json','web/public/data/index-v3.json',
       'web/public/data/browser-judge','web/public/data/modules']
run(['git','add',*paths]);run(['git','diff','--cached','--check'])
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True).splitlines()
assert len(staged)==180,len(staged)
assert sum(n.startswith(('web/public/data/browser-judge/','web/public/data/modules/')) for n in staged)==158
hooks=Path(subprocess.check_output(['git','rev-parse','--git-path','hooks'],cwd=repo,text=True).strip())
print('LOCAL_EXECUTABLE_HOOKS',[f.name for f in hooks.iterdir() if f.is_file() and not f.name.endswith('.sample') and os.access(f,os.X_OK)],flush=True)
run(['git','commit','--quiet','-m','feat(torch): adopt validated 0.53 dense Transformer runtime'])
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
print('LOCAL_VALIDATED_SOURCE',head,flush=True)
run([sys.executable,r/'push-main-node.py',expected])
