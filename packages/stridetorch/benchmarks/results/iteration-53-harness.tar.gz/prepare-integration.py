from pathlib import Path
import hashlib,json,shutil,subprocess

r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-52-final'
repo=Path('/Users/david/Developer/PaperLeet-torch-release');i=r/'integration-proof';i.mkdir()
for name in ['run-setup.py','run-export.py','freeze.py','verify-private.py','verify-export.py','run-frontend.py','run-wasm.py']:
    s=(old/'integration-proof'/name).read_text().replace('torch-iteration-52-final','torch-iteration-53').replace('0.52.0','0.53.0')
    if name=='freeze.py':s=s.replace('len(tests)==49','len(tests)==50').replace('6402','6635').replace('expected_suites=49','expected_suites=50')
    if name=='verify-export.py':s=s.replace('len(published)==11177','len(published)==11335')
    if name=='verify-private.py':s=s.replace('core_modules=54','core_modules=55').replace('all_56_core_license_hashes','all_57_core_license_hashes')
    (i/name).write_text(s)
s=(old/'run-setup-final.py').read_text().replace('torch-iteration-52-final','torch-iteration-53').replace('0.52.0','0.53.0')
(r/'run-setup-final.py').write_text(s)
source=json.loads((r/'proof/source-hashes.json').read_text())
for name,h in source.items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==h
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
(i/'context.json').write_text(json.dumps(dict(upstream=head,version='0.53.0',source_hashes=source),indent=2)+'\n')
for name in ['native-ci.json','native-receipt.json','native-ci.log']:shutil.copy2(old/'integration-proof'/name,i/name)
shutil.copy2(old/'native-catalog-input-identity.json',r/'native-catalog-input-identity.json')
identity=json.loads((r/'native-catalog-input-identity.json').read_text())
for name,h in identity['files'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==h
(i/'native-reference-reuse.json').write_text(json.dumps(dict(status='unchanged_native_reference_reused',files=len(identity['files']),
    original='../torch-iteration-50/integration-proof/native-ci.json',previous='../torch-iteration-52-final/integration-proof/native-ci.json',
    reason='All original native catalog/runner/reference/mutant/test/configuration bytes are unchanged. New Transformer has fresh separate native oracles; final adapter/root/package/WASM/export gates run separately.'),indent=2)+'\n')
print(dict(source_resources=len(source),original_native_inputs=len(identity['files']),upstream=head))
