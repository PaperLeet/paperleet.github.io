from pathlib import Path
import hashlib,json,shutil

r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-52-final'
repo=Path('/Users/david/Developer/PaperLeet-torch-release');p=r/'proof';c=p/'chrome-contracts';c.mkdir(parents=True)
def hashes(d):return {f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in d.iterdir() if f.is_file()}
for d in [p/'source',c/'source']:
    d.mkdir()
    for f in (repo/'packages/stridetorch/src/stridetorch').iterdir():
        if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']:shutil.copy2(f,d/f.name)
source=hashes(p/'source');assert len(source)==57
(p/'source-hashes.json').write_text(json.dumps(source,indent=2)+'\n')
tests=c/'tests';tests.mkdir()
for f in (repo/'packages/stridetorch/tests').glob('test_*.py'):
    if f.name!='test_standalone.py':shutil.copy2(f,tests/f.name)
assert len(hashes(tests))==50
plan=dict(version='0.53.0',expected=6635,source=source,tests=hashes(tests))
(c/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
shutil.copy2(old/'fixture-server.mjs',r/'fixture-server.mjs')
for name in ['run.mjs','worker.mjs','index.html']:
    (c/name).write_text((old/'proof/chrome-contracts'/name).read_text().replace('torch-iteration-52-final','torch-iteration-53'))
for name in ['wasm-contracts.mjs','check-wheel.py','check-coinstall.py']:
    s=(old/'proof'/name).read_text().replace('torch-iteration-52-final','torch-iteration-53').replace('0.52.0','0.53.0').replace('stride052','stride053')
    if name=='wasm-contracts.mjs':s=s.replace("'multihead_attention'","'multihead_attention','transformer'").replace('6402','6635')
    if name=='check-wheel.py':s=s.replace('==54','==55').replace('package_modules=54','package_modules=55')
    if name=='check-coinstall.py':
        needle="print('PASS isolated ownership,aliases,ZIP resume,triangular,Cholesky and Cholesky solve VJP/JVP/full tangent reverse')"
        extra="""for name in NAMES:
 t=importlib.import_module(name).torch
 layer=t.nn.Transformer(4,2,1,1,dim_feedforward=8,dropout=0.,batch_first=True,dtype=t.float64)
 x=t.tensor(np.sin(np.arange(24)).reshape(2,3,4),requires_grad=True)
 y,j=t.func.jvp(lambda a:layer(a,a,tgt_mask=t.nn.Transformer.generate_square_subsequent_mask(3,dtype=t.float64)),(x,),(t.ones_like(x),))
 (y.square().sum()+j.square().sum()).backward()
 assert y.shape==j.shape==(2,3,4) and np.isfinite(x.grad.numpy()).all()
 assert all(p.grad is not None for p in layer.parameters())
"""
        assert needle in s;s=s.replace(needle,extra+needle)
    (p/name).write_text(s)
for name in ['run-full.py','run-gates.py']:(r/name).write_text((old/name).read_text().replace('torch-iteration-52-final','torch-iteration-53'))
shutil.copy2(old/'release-policy-identity.json',r/'release-policy-identity.json')
for name,digest in json.loads((r/'release-policy-identity.json').read_text())['files'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
print(dict(resources=len(source),suites=50,expected_contracts=6635))
