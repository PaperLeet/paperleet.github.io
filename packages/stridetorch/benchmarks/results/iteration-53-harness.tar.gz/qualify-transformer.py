"""Keep strict native differences visible; qualify FP32 mixed AD vs exact-input FP64."""
from pathlib import Path
import hashlib,json,subprocess,sys
import numpy as np

r=Path(__file__).resolve().parent
with (r/'strict-native-comparison.log').open('w') as log:
    child=subprocess.run([sys.executable,str(r/'compare-transformer.py')],cwd=r,stdout=log,stderr=subprocess.STDOUT)
strict=json.loads((r/'transformer-comparison.json').read_text())
assert child.returncode in (0,1) and strict['cases']==640 and strict['arrays']==36850
assert child.returncode==int(bool(strict['failures']))
native=np.load(r/'native-transformer.npz');adapter=np.load(r/'adapter-transformer.npz')
nh=np.load(r/'native-fp32-as-fp64-transformer.npz');ah=np.load(r/'adapter-fp32-as-fp64-transformer.npz')
assert nh.files==ah.files and len(nh.files)==16536
for failure in strict['failures']:
    name=failure['name']
    assert native[name].dtype==np.float32 and name.split('.')[1].startswith('m'),failure
for name in nh.files:
    assert nh[name].dtype==ah[name].dtype==np.float64 and name in native.files
    np.testing.assert_allclose(ah[name],nh[name],rtol=3e-10,atol=3e-11,equal_nan=False)
rows=[];failures=[];worst={name:dict(error=0,key=None) for name in ['native','adapter']}
budget=1e-5
for name in nh.files:
    if not name.split('.')[1].startswith('m'):continue
    high=nh[name];scale=max(1.,float(np.max(abs(high),initial=0)))
    row=dict(key=name,scale=scale)
    for label,source in [('native',native),('adapter',adapter)]:
        error=float(np.max(abs(source[name]-high),initial=0))/scale
        row[label+'_relative_max_error']=error
        if error>worst[label]['error']:worst[label]=dict(error=error,key=name)
        if not np.isfinite(error) or error>budget:failures.append(dict(key=name,backend=label,relative_max_error=error))
    rows.append(row)
identity={}
for label in ['native','adapter','native-fp32-as-fp64','adapter-fp32-as-fp64']:
    data=json.loads((r/(label+'-transformer.json')).read_text())
    assert data['script_sha256']==hashlib.sha256((r/'differential-transformer.py').read_bytes()).hexdigest()
    identity[label]=hashlib.sha256((r/(label+'-transformer.npz')).read_bytes()).hexdigest()
result=dict(status='qualified' if not failures else 'failed',cases=640,arrays=36850,
    direct_strict_native_failures=strict['failures'],direct_strict_native_failure_count=len(strict['failures']),
    strict_scope='Values, first VJPs, JVPs, FP64 mixed AD and initialization use strict elementwise native tolerances. Only FP32 mixed arrays can require roundoff qualification; original strict discrepancies are retained.',
    promoted_control_cases=240,promoted_control_arrays=len(nh.files),promoted_mixed_arrays=len(rows),
    bound=budget,definition='max_abs(float32_mixed - native_float64_mixed) / max(1,max_abs(native_float64_mixed)) <= 1e-5, separately for native and adapter. Float64 starts from exactly the same representable float32 inputs/parameters/seeds/directions.',
    promoted_adapter_native_strict=True,worst=worst,failures=failures,rows=rows,oracle_sha256=identity)
source=Path('/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src/stridetorch')
result['source_hashes']={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in source.iterdir() if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']}
(r/'transformer-qualification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key not in ['rows','direct_strict_native_failures']}))
assert not failures
