from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,tarfile

r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
out=repo/'packages/stridetorch/benchmarks/results'
def read(name):return json.loads((r/name).read_text())
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def save(f,data):f.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
source=repo/'packages/stridetorch/src/stridetorch'
actual={f.name:sha(f) for f in source.iterdir() if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']}
plan=read('proof/chrome-contracts/plan.json')
tests={f.name:sha(f) for f in (repo/'packages/stridetorch/tests').glob('test_*.py') if f.name!='test_standalone.py'}
assert len(actual)==57 and actual==read('proof/source-hashes.json')==plan['source']
assert len(tests)==50 and tests==plan['tests'] and plan['expected']==6635
cpu=read('full-root-receipt.json');assert cpu['exit_code']==0 and cpu['passed']==40265 and cpu['skipped']==1
gates=read('proof/gate-receipts.json');assert len(gates)==6 and all(v['exit_code']==0 for v in gates.values())
node=read('proof/source-wasm.json');chrome=read('proof/chrome-contracts/result.json')
wheel=read('proof/wheel-stride053-result.json');coinstall=read('proof/coinstall-result.json')
assert node['passed']==chrome['passed']==6635 and chrome['test_hashes']==tests
assert node['source_hashes']==chrome['source_hashes']==wheel['source_hashes']==coinstall['source_hashes']==actual
assert all(v['status']=='success' for v in [chrome,wheel,coinstall]) and not wheel['native_torch']
assert '6648 passed' in (r/'proof/python310-stride053-tests.log').read_text()
assert node['numpy']=='2.2.5' and node['library']=='0.53.0'
qualification=read('transformer-qualification.json')
assert qualification['status']=='qualified' and qualification['source_hashes']==actual
assert qualification['cases']==640 and qualification['arrays']==36850 and qualification['direct_strict_native_failure_count']==5
assert qualification['promoted_control_cases']==240 and qualification['promoted_control_arrays']==16536
assert qualification['promoted_mixed_arrays']==8196 and qualification['promoted_adapter_native_strict'] and not qualification['failures']
assert qualification['worst']['adapter']['error']<=qualification['bound']==1e-5
for name,h in qualification['oracle_sha256'].items():assert sha(r/(name+'-transformer.npz'))==h
performance=read('performance/identity.json');receipts=read('performance/receipts.json')
assert performance['status']=='success' and performance['all_children_terminal'] and performance['children']==len(receipts)==12
assert all(v['exit_code']==0 for v in receipts)
baseline=performance['source_hashes']['baseline'];assert len(baseline)==56 and performance['source_hashes']['candidate']==actual
assert performance['benchmark_sha256']==sha(repo/'packages/stridetorch/benchmarks/bench_transformer.py')
for runtime in ['cpu','node','chrome']:
    for repeat in range(4):
        data=read(f'performance/{runtime}-{repeat}.json');data=data.get('benchmark',data)
        assert data['source_hashes']==dict(baseline=baseline,candidate=actual) and len(data['rows'])==60
changed={n for n,h in baseline.items() if actual.get(n)!=h};added=set(actual)-set(baseline)
assert changed=={'__init__.py','_activation.py','_api.py','_multihead.py','_nn.py','_normalization.py'} and added=={'_transformer.py'}
for n,h in read('native-catalog-input-identity.json')['files'].items():assert sha(repo/n)==h
native=read('integration-proof/native-ci.json');wasm=read('integration-proof/full-wasm-result.json')
assert native['passed'] and native['problems']==78 and native['tests_executed']==10218 and native['duration_s']<=600 and native['repeats']==3 and not native['issues']
assert sum(map(len,native['mutation'].values()))==342 and all(hit for values in native['mutation'].values() for hit in values.values())
assert wasm['passed'] and wasm['catalog_modules']==wasm['modules']==78 and not wasm['browser_budget_exceeded']
assert sum(v['mutants'] for v in wasm['results'])==342 and all(v['passed'] and not v['browser_budget_exceeded'] for v in wasm['results'])
contracts=next(v for v in wasm['results'] if v['id']=='architecture/attention')['independent_contracts']
assert contracts['passed']==6635 and len(contracts['suites'])==50
assert {v['suite']:v['source_sha256'] for v in contracts['suites']}==tests
assert contracts['runtime_profiles'][0]['supplemented_files']==[]
assert contracts['runtime_profiles'][1]['supplemented_files']==[dict(name='stridetorch/_legacy.py',source_sha256=actual['_legacy.py'])]
setup=read('integration-proof/setup-receipts.json');front=read('integration-proof/frontend-receipts.json')
assert len(setup)==4 and len(front)==5 and all(v['exit_code']==0 for v in setup+front)
exports=read('integration-proof/export-identity.json');snapshot=read('integration-proof/release-snapshot.json')
assert exports['published_assets_unchanged']==11335 and exports['new_assets']==exports['active_assets']==158 and exports['all_new_assets_reachable']
assert snapshot['source_hashes']==actual and read('integration-proof/distribution-identity.json')['status']=='success'
live=read('integration-proof/live-expected-sha256.json');assert len(live)==161
for n,h in live.items():assert sha(repo/'web/public/data'/n)==h
policy=read('release-policy-identity.json');assert policy['status']=='unchanged'
for n,h in policy['files'].items():assert sha(repo/n)==h
syncs=read('upstream-syncs.json') if (r/'upstream-syncs.json').exists() else []
for sync in syncs:
    for n,h in sync['paths'].items():
        assert sha(repo/n)==h and hashlib.sha256(subprocess.check_output(['git','show',sync['after']+':'+n],cwd=repo)).hexdigest()==h
    check=read(sync['receipts']);assert len(check)==5 and all(v['exit_code']==0 for v in check)
sizes={}
for label,folder,names in [('baseline',r/'baseline-source/stridetorch',baseline),('candidate',source,actual)]:
    data=b''.join((folder/n).read_bytes() for n in sorted(names))
    sizes[label]=dict(raw_source_license_bytes=len(data),local_concatenated_gzip_bytes=len(gzip.compress(data,mtime=0)))
metadata=r/'package-metadata';metadata.mkdir(exist_ok=True)
for n in ['README.md','pyproject.toml','LICENSE','NOTICE']:shutil.copy2(repo/'packages/stridetorch'/n,metadata/n)
shutil.copy2(repo/'packages/stridetorch/tests/test_standalone.py',metadata/'test_standalone.py')
shutil.copy2(repo/'packages/stridetorch/benchmarks/bench_transformer.py',metadata/'bench_transformer.py')
archives={}
for name,folder,excluded in [
    ('iteration-53-harness.tar.gz',r,{'integration-proof','proof','performance','pre-sync-0ef-local-proof','initial-no-float-mask','precision-stats64','precision-tangent64','precision-projection','precision-both'}),
    ('iteration-53-precision-harness.tar.gz',r,{'integration-proof','proof','performance','pre-sync-0ef-local-proof','baseline-source','package-metadata','bench-pilots-before-mixed'}),
    ('iteration-53-runtime-harness.tar.gz',r/'proof',set()),
    ('iteration-53-integration-harness.tar.gz',r/'integration-proof',{'dist-paperleet','live-expected'}),
    ('iteration-53-performance-harness.tar.gz',r/'performance',set())]:
    target=out/name;assert not target.exists()
    with tarfile.open(target,'w:gz') as archive:
        for current,dirs,names in os.walk(folder):
            dirs[:]=[d for d in dirs if d not in ['__pycache__','.pytest_cache'] and not d.endswith(('-env','-venv')) and not (Path(current)==folder and d in excluded)]
            for n in sorted(names):
                f=Path(current)/n
                if f.name=='native-transformer-source.py' or f.is_symlink():continue
                if name=='iteration-53-precision-harness.tar.gz' and Path(current)==r:continue
                if f.name in ['LICENSE','NOTICE'] or f.suffix in ['.py','.mjs','.json','.log','.md','.html','.toml','.npz','.txt','.whl'] or f.name.endswith('.tar.gz'):
                    archive.add(f,arcname=f.relative_to(folder),recursive=False)
    assert target.stat().st_size<95*1024*1024
    archives[name]=dict(sha256=sha(target),bytes=target.stat().st_size)
compact_qualification={k:v for k,v in qualification.items() if k!='rows'}
report=dict(status='validated_locally',version='0.53.0',source_hashes=actual,changed_resources=sorted(changed),added_resources=sorted(added),unchanged_resources=50,
    full_cpu=cpu,new_transformer_tests=232,additional_namespace_cases=dict(library=1,root=1),
    node_wasm=node,chrome_worker=chrome,minimal_wheel=wheel,coinstall=coinstall,native_qualification=compact_qualification,
    performance_identity=performance,performance=read('performance-summary.json'),source_footprint=sizes,
    release_policy=policy,upstream_syncs=syncs,raw_archives=archives)
integration=dict(status='validated_locally',version='0.53.0',native=native,wasm=wasm,frontend=front,setup=setup,
    source_hashes=actual,export_identity=exports,release_snapshot=snapshot,live_export_sha256=live,
    distribution=read('integration-proof/distribution-identity.json'),runtime_sizes=read('integration-proof/runtime-sizes.json'),
    wasm_harness=read('integration-proof/wasm-harness-identity.json'),native_reference_reuse=read('integration-proof/native-reference-reuse.json'),upstream_syncs=syncs)
save(out/'iteration-53.json',report);save(out/'iteration-53-integration.json',integration)
save(r/'state.json',dict(status='local_gates_passed',version='0.53.0',source_hashes=actual,export_sha256=live,
    all_owned_children_terminal=True,main_adoption_pending=True,immutable_payloads=11493))
print(json.dumps(dict(status='validated_locally',resources=57,cpu=40265,wasm_contracts=6635,minimum_wheel=6648,catalog=78,mutants=342,archives=archives)))
