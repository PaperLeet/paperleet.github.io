from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,tarfile

r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
out=repo/'packages/stridetorch/benchmarks/results'
def read(name):return json.loads((r/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,data):p.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
source=repo/'packages/stridetorch/src/stridetorch'
actual={f.name:sha(f) for f in source.iterdir() if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']}
plan=read('proof/chrome-contracts/plan.json')
tests={f.name:sha(f) for f in (repo/'packages/stridetorch/tests').glob('test_*.py') if f.name!='test_standalone.py'}
assert len(actual)==56 and actual==read('proof/source-hashes.json')==plan['source']
assert len(tests)==49 and tests==plan['tests'] and plan['expected']==6402
full=read('full-root-receipt.json');assert full['exit_code']==0 and full['passed']==40031 and full['skipped']==1
gates=read('proof/gate-receipts.json');assert len(gates)==6 and all(v['exit_code']==0 for v in gates.values())
node=read('proof/source-wasm.json');chrome=read('proof/chrome-contracts/result.json')
wheel=read('proof/wheel-stride052-result.json');coinstall=read('proof/coinstall-result.json')
assert node['passed']==chrome['passed']==6402 and chrome['test_hashes']==tests
assert node['source_hashes']==chrome['source_hashes']==wheel['source_hashes']==coinstall['source_hashes']==actual
assert all(v['status']=='success' for v in [chrome,wheel,coinstall]) and not wheel['native_torch']
assert '6415 passed' in (r/'proof/python310-stride052-tests.log').read_text()
assert node['numpy']=='2.2.5' and node['library']=='0.52.0'
comparison=read('mha-comparison.json');assert comparison['status']=='passed' and comparison['cases']==208 and comparison['arrays']==4107
native_mha=read('native-mha.json');adapter=read('adapter-mha.json')
assert native_mha['script_sha256']==adapter['script_sha256']==sha(r/'differential-mha.py')
assert native_mha['rows']==adapter['rows'] and adapter['version']=='0.52.0'
reuse=read('preflight-reuse.json');assert reuse['status']=='exact_mathematical_source_reused' and reuse['final_source_sha256']==actual
assert sha(repo/reuse['previous_evidence'])==reuse['previous_evidence_sha256']
assert sha(repo/'packages/stridetorch/benchmarks/bench_multihead.py')==reuse['benchmark_sha256']
for name,digest in read('native-catalog-input-identity.json')['files'].items():assert sha(repo/name)==digest
assert read('integration-proof/native-reference-reuse.json')['status']=='unchanged_native_reference_reused'
native=read('integration-proof/native-ci.json');wasm=read('integration-proof/full-wasm-result.json')
assert native['passed'] and native['problems']==78 and native['tests_executed']==10218 and native['duration_s']<=600 and native['repeats']==3 and not native['issues']
assert sum(map(len,native['mutation'].values()))==342 and all(hit for rows in native['mutation'].values() for hit in rows.values())
assert wasm['passed'] and wasm['catalog_modules']==wasm['modules']==78 and not wasm['browser_budget_exceeded']
assert sum(v['mutants'] for v in wasm['results'])==342 and all(v['passed'] and not v['browser_budget_exceeded'] for v in wasm['results'])
contracts=next(v for v in wasm['results'] if v['id']=='architecture/attention')['independent_contracts']
assert contracts['passed']==6402 and len(contracts['suites'])==49
assert {v['suite']:v['source_sha256'] for v in contracts['suites']}==tests
assert contracts['runtime_profiles'][0]['supplemented_files']==[]
assert contracts['runtime_profiles'][1]['supplemented_files']==[dict(name='stridetorch/_legacy.py',source_sha256=actual['_legacy.py'])]
setup=read('integration-proof/setup-receipts.json');front=read('integration-proof/frontend-receipts.json')
assert len(setup)==4 and len(front)==5 and all(v['exit_code']==0 for v in setup+front)
exports=read('integration-proof/export-identity.json');snapshot=read('integration-proof/release-snapshot.json')
assert exports['published_assets_unchanged']==11177 and exports['active_assets']==exports['new_assets']==158 and exports['all_new_assets_reachable']
assert snapshot['source_hashes']==actual and read('integration-proof/distribution-identity.json')['status']=='success'
live=read('integration-proof/live-expected-sha256.json');assert len(live)==161
for name,digest in live.items():assert sha(repo/'web/public/data'/name)==digest
harness=read('integration-proof/wasm-harness-identity.json')
assert sha(repo/harness['file'])==harness['sha256'] and sha(repo/harness['driver_file'])==harness['driver_sha256']
policy=read('release-policy-identity.json');assert policy['status']=='unchanged'
for name,digest in policy['files'].items():assert sha(repo/name)==digest
syncs=read('upstream-syncs.json') if (r/'upstream-syncs.json').exists() else []
for sync in syncs:
    for name,digest in sync['paths'].items():
        assert sha(repo/name)==digest
        assert hashlib.sha256(subprocess.check_output(['git','show',sync['after']+':'+name],cwd=repo)).hexdigest()==digest
    refreshed=read(sync['receipts']);assert len(refreshed)==5 and all(v['exit_code']==0 for v in refreshed)
old=r.parent/'torch-iteration-51/proof/source';baseline={f.name:sha(f) for f in old.iterdir() if f.is_file()}
changed={name for name,digest in baseline.items() if actual.get(name)!=digest};added=set(actual)-set(baseline)
assert len(baseline)==55 and changed=={'__init__.py','_api.py'} and added=={'_multihead.py'}
sizes={}
for label,folder,names in [('baseline',old,baseline),('candidate',source,actual)]:
    raw=b''.join((folder/name).read_bytes() for name in sorted(names))
    sizes[label]=dict(raw_source_license_bytes=len(raw),local_concatenated_gzip_bytes=len(gzip.compress(raw,mtime=0)))
metadata=r/'package-metadata';metadata.mkdir(exist_ok=True)
for name in ['README.md','pyproject.toml','LICENSE','NOTICE']:shutil.copy2(repo/'packages/stridetorch'/name,metadata/name)
shutil.copy2(repo/'packages/stridetorch/tests/test_standalone.py',metadata/'test_standalone.py')
shutil.copy2(repo/'packages/stridetorch/benchmarks/bench_multihead.py',metadata/'bench_multihead.py')
archives={}
for name,folder,excluded in [('iteration-52-harness.tar.gz',r,{'integration-proof','proof'}),
                            ('iteration-52-integration-harness.tar.gz',r/'integration-proof',{'dist-paperleet','live-expected'}),
                            ('iteration-52-runtime-harness.tar.gz',r/'proof',set())]:
    target=out/name;assert not target.exists(),target
    with tarfile.open(target,'w:gz') as archive:
        for current,dirs,names in os.walk(folder):
            dirs[:]=[d for d in dirs if d not in ['__pycache__','.pytest_cache'] and not d.endswith(('-env','-venv')) and not (Path(current)==folder and d in excluded)]
            for name0 in sorted(names):
                f=Path(current)/name0
                if not f.is_symlink() and (f.name in ['LICENSE','NOTICE'] or f.suffix in ['.py','.mjs','.json','.log','.md','.html','.toml','.npz','.txt','.whl'] or f.name.endswith('.tar.gz')):
                    archive.add(f,arcname=f.relative_to(folder),recursive=False)
    archives[name]=dict(sha256=sha(target),bytes=target.stat().st_size)
report=dict(status='validated_locally',version='0.52.0',source_hashes=actual,changed_resources=sorted(changed),added_resources=sorted(added),unchanged_resources=53,
    full_cpu=full,new_mha_tests=218,node_wasm=node,chrome_worker=chrome,minimal_wheel=wheel,coinstall=coinstall,
    native_mha=comparison,native_mha_oracle_sha256={name:sha(r/name) for name in ['native-mha.json','native-mha.npz','differential-mha.py']},
    preflight_reuse=reuse,source_footprint=sizes,release_policy=policy,raw_archives=archives,upstream_syncs=syncs)
integration=dict(status='validated_locally',version='0.52.0',native=native,wasm=wasm,frontend=front,setup=setup,
    export_identity=exports,release_snapshot=snapshot,live_export_sha256=live,source_hashes=actual,
    distribution=read('integration-proof/distribution-identity.json'),wasm_harness=harness,
    runtime_sizes=read('integration-proof/runtime-sizes.json'),native_reference_reuse=read('integration-proof/native-reference-reuse.json'),upstream_syncs=syncs)
save(out/'iteration-52.json',report);save(out/'iteration-52-integration.json',integration)
save(r/'state.json',dict(status='local_gates_passed',version='0.52.0',source_hashes=actual,export_sha256=live,
    all_owned_children_terminal=True,main_adoption_pending=True,immutable_payloads=11335))
print(json.dumps(dict(status='validated_locally',resources=56,cpu=40031,wasm_contracts=6402,minimal_wheel=6415,
    catalog=78,mutants=342,archives=archives)))
