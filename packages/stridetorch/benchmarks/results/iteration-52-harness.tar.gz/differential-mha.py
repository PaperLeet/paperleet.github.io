"""Same explicit input/state fixtures in isolated native and adapter processes."""
from pathlib import Path
import argparse
import contextlib
import hashlib
import itertools
import json
import sys
import numpy as np

p = argparse.ArgumentParser()
p.add_argument('backend', choices=['native', 'adapter'])
a = p.parse_args()
if a.backend == 'native':
    import torch
    from torch.nn.attention import sdpa_kernel, SDPBackend
    torch.set_num_threads(1)
    torch.backends.mha.set_fastpath_enabled(False)
    context = lambda: sdpa_kernel(SDPBackend.MATH)
else:
    sys.path.insert(0, '/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src')
    from stridetorch import torch
    context = contextlib.nullcontext

root = Path(__file__).resolve().parent
saved, rows = {}, []
def put(prefix, value):
    if value is None:
        return None
    array = value.detach().numpy() if hasattr(value, 'detach') else np.asarray(value)
    saved[prefix] = array.copy()
    return dict(key=prefix, shape=list(array.shape), dtype=str(array.dtype))

cases = itertools.product(['float32', 'float64'], ['sequence', 'batch', 'unbatched'],
                          ['self', 'shared', 'cross', 'separate'],
                          ['none', 'bool2d', 'bool3d', 'float'], [True, False])
for index, (dtype, layout, projection, mask_kind, need) in enumerate(cases):
    rng = np.random.default_rng(520000 + index)
    dt = getattr(torch, dtype)
    extra = index % 3
    options = dict(embed_dim=4, num_heads=2, batch_first=layout == 'batch',
                   bias=index % 5 != 0, add_bias_kv=extra == 1,
                   add_zero_attn=extra == 2, dtype=dt, dropout=1. if index % 11 == 0 else 0.)
    if projection == 'separate': options.update(kdim=3, vdim=5)
    module = torch.nn.MultiheadAttention(**options)
    module.train(index % 7 != 0)
    with torch.no_grad():
        for parameter in module.parameters():
            parameter.copy_(torch.tensor(rng.normal(0, .3, parameter.shape).astype(dtype)))
    source = 3 if projection == 'self' else 4
    dims = [(3, 4)] if projection == 'self' else [(3, 4), (source, 4)] if projection == 'shared' else [(3, 4), (source, options.get('kdim', 4)), (source, options.get('vdim', 4))]
    def shape(length, width):
        return (length, width) if layout == 'unbatched' else (2, length, width) if layout == 'batch' else (length, 2, width)
    inputs = [torch.tensor(np.asfortranarray(rng.normal(0, .5, shape(*d)).astype(dtype)), requires_grad=True) for d in dims]
    batch = 1 if layout == 'unbatched' else 2
    mask, padding = None, None
    if mask_kind.startswith('bool'):
        ms = (batch * 2, 3, source) if mask_kind == 'bool3d' else (3, source)
        mask_array = rng.random(ms) < .2
        mask_array[..., 0] = False
        mask = torch.tensor(mask_array)
        padding_array = rng.random((batch, source)) < .2
        padding_array[:, 0] = False
        padding = torch.tensor(padding_array[0] if layout == 'unbatched' else padding_array)
    elif mask_kind == 'float':
        mask = torch.tensor(rng.normal(0, .2, (3, source)).astype(dtype), requires_grad=True)
        padding_array = rng.normal(0, .2, (batch, source)).astype(dtype)
        padding = torch.tensor(padding_array[0] if layout == 'unbatched' else padding_array, requires_grad=True)
    average = index % 3 != 0
    def call(*values):
        q = values[0]
        k = q if projection == 'self' else values[1]
        v = k if projection in ('self', 'shared') else values[2]
        y, w = module(q, k, v, key_padding_mask=padding, attn_mask=mask,
                      need_weights=need, average_attn_weights=average)
        return (y, w) if need else (y,)
    active = inputs + list(module.parameters()) + ([mask, padding] if mask_kind == 'float' else [])
    row = dict(index=index, dtype=dtype, layout=layout, projection=projection,
               mask=mask_kind, need_weights=need, average=average, extra=extra)
    prefix = f'case{index}'
    try:
        with context():
            outputs = call(*inputs)
            seeds = [torch.tensor(rng.normal(size=o.shape).astype(dtype)) for o in outputs]
            loss = sum((o * s).sum() for o, s in zip(outputs, seeds))
            grads = torch.autograd.grad(loss, active, allow_unused=True)
            directions = tuple(torch.tensor(rng.normal(size=x.shape).astype(dtype), requires_grad=True) for x in inputs)
            primal, tangent = torch.func.jvp(call, tuple(inputs), directions)
            mixed_loss = sum((t * s).sum() for t, s in zip(tangent, seeds))
            mixed = torch.autograd.grad(mixed_loss, active + list(directions), allow_unused=True)
        row.update(status='success', outputs=[put(f'{prefix}.output{i}', x) for i,x in enumerate(outputs)],
                   gradients=[put(f'{prefix}.grad{i}', x) for i,x in enumerate(grads)],
                   primal=[put(f'{prefix}.primal{i}', x) for i,x in enumerate(primal)],
                   tangent=[put(f'{prefix}.tangent{i}', x) for i,x in enumerate(tangent)],
                   mixed=[put(f'{prefix}.mixed{i}', x) for i,x in enumerate(mixed)])
    except Exception as error:
        row.update(status=type(error).__name__, error=str(error)[:500])
    rows.append(row)

# Seeded initialization is checked separately from overwritten differential state.
for dtype, separate, extra, bias in itertools.product(['float32', 'float64'], [False, True], [False, True], [False, True]):
    torch.manual_seed(5210)
    module = torch.nn.MultiheadAttention(4, 2, dtype=getattr(torch, dtype), bias=bias,
        add_bias_kv=extra, **(dict(kdim=3, vdim=5) if separate else {}))
    prefix = f'init-{dtype}-{separate}-{extra}-{bias}'
    rows.append(dict(name=prefix, status='success', state={k: put(prefix+'.'+k, v) for k,v in module.state_dict().items()},
                     versions={k: v._version for k,v in module.named_parameters()}))
np.savez_compressed(root / (a.backend + '-mha.npz'), **saved)
version = torch.__version__ if a.backend == 'native' else __import__('stridetorch').__version__
result = dict(backend=a.backend, version=version, rows=rows,
              script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(root / (a.backend + '-mha.json')).write_text(json.dumps(result, indent=2)+'\n')
errors = [r for r in rows if r['status'] != 'success']
print(json.dumps(dict(backend=a.backend, cases=len(rows), arrays=len(saved), errors=len(errors), examples=errors[:4])))
if errors: sys.exit(1)
