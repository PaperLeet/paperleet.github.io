from pathlib import Path
import shutil

r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-51'
remote_old="subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=repo,text=True).split()[0]"
remote_new="subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/git/ref/heads/main','--jq','.object.sha'],cwd=repo,text=True).strip()"
for name in ['audit-main.py','push-main-node.py']:
    s=(old/name).read_text();assert remote_old in s
    (r/name).write_text(s.replace(remote_old,remote_new))
shutil.copy2(old/'push-via-node.mjs',r/'push-via-node.mjs')
print('Prepared read-only Actions/main audit and ordinary branch-only push transport')
