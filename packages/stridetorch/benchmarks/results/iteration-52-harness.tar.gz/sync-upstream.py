from pathlib import Path
import hashlib,json,shutil,subprocess

r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
before='ab8e930dd3de37a2f2412fe86c860bf5e771c4c6';after='cd48bff0c0ac2933bb765ba40e458560a6a974d8'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD')=='f4cce1be4a937ae7bcc4ec03ae502113d48c6b6d'
assert git('rev-parse','FETCH_HEAD')==after and not git('diff','--cached','--name-only')
incoming=git('diff','--name-only',before,after).splitlines()
assert len(incoming)==16 and all(name.startswith('web/') and not name.startswith(('web/public/','web/scripts/check-browser-wasm','web/scripts/wasm-cases')) for name in incoming)
assert 'web/package-lock.json' not in incoming
dirty=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert not dirty.intersection(incoming)
snapshots={}
for folder,record in [(repo/'packages/stridetorch/src/stridetorch',r/'proof/source-hashes.json'),(repo/'web/public/data',r/'integration-proof/live-expected-sha256.json')]:
    expected=json.loads(record.read_text())
    for name,h in expected.items():assert sha(folder/name)==h
    snapshots[folder]=expected
front=r/'integration-proof';receipts=json.loads((front/'frontend-receipts.json').read_text())
assert len(receipts)==5 and all(v['exit_code']==0 for v in receipts)
backup=front/'frontend-before-sync-cd48bff0';backup.mkdir()
for name in ['frontend-receipts.json','pages-profile.json',*[v['log'] for v in receipts]]:shutil.copy2(front/name,backup/name)
subprocess.run(['git','merge','--no-edit',after],cwd=repo,check=True)
for folder,expected in snapshots.items():
    for name,h in expected.items():assert sha(folder/name)==h
for name,h in json.loads((r/'native-catalog-input-identity.json').read_text())['files'].items():assert sha(repo/name)==h
paths={name:sha(repo/name) for name in incoming}
for name,h in paths.items():assert hashlib.sha256(subprocess.check_output(['git','show',after+':'+name],cwd=repo)).hexdigest()==h
record=dict(before=before,after=after,merge_commit=git('rev-parse','HEAD'),paths=paths,
    receipts='integration-proof/frontend-after-cd48bff0-receipts.json',
    numerical_source_and_exports_identical=True,native_catalog_inputs_identical=1152,
    scope='Preserve all 16 upstream UI files as exact Git blobs. Native/core/test/export inputs are unchanged; final frontend checks/build profiles rerun after merge.')
(r/'upstream-syncs.json').write_text(json.dumps([record],indent=2)+'\n')
print(json.dumps(record))
