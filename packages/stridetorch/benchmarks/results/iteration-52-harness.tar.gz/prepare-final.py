from pathlib import Path
import hashlib,json,shutil,subprocess

r=Path(__file__).resolve().parent;root=r.parent
repo=Path('/Users/david/Developer/PaperLeet-torch-release')
old=root/'torch-iteration-51';pre=root/'torch-iteration-52'
p=r/'proof';c=p/'chrome-contracts';c.mkdir(parents=True)
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def save(f,data):f.write_text(json.dumps(data,indent=2)+'\n')
def hashes(folder):return {f.name:sha(f) for f in folder.iterdir() if f.is_file()}
for destination in [p/'source',c/'source']:
    destination.mkdir()
    for f in (repo/'packages/stridetorch/src/stridetorch').iterdir():
        if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']:shutil.copy2(f,destination/f.name)
source=hashes(p/'source');assert len(source)==56
save(p/'source-hashes.json',source)
tests=c/'tests';tests.mkdir()
for f in (repo/'packages/stridetorch/tests').glob('test_*.py'):
    if f.name!='test_standalone.py':shutil.copy2(f,tests/f.name)
assert len(hashes(tests))==49
save(c/'plan.json',dict(version='0.52.0',expected=6402,source=source,tests=hashes(tests)))
shutil.copy2(old/'fixture-server.mjs',r/'fixture-server.mjs')
for name in ['run.mjs','worker.mjs','index.html']:
    (c/name).write_text((pre/'proof/chrome-contracts'/name).read_text().replace('torch-iteration-52/','torch-iteration-52-final/'))
(p/'wasm-contracts.mjs').write_text((pre/'proof/wasm-contracts.mjs').read_text().replace('torch-iteration-52/','torch-iteration-52-final/').replace('0.51.0','0.52.0'))
for name in ['check-wheel.py','check-coinstall.py']:
    (p/name).write_text((pre/'proof'/name).read_text().replace('0.51.0','0.52.0').replace('stride052-preflight','stride052'))
for name in ['run-full.py','run-gates.py','run-setup-final.py']:
    (r/name).write_text((old/name).read_text().replace('torch-iteration-51','torch-iteration-52-final').replace('0.51.0','0.52.0'))
i=r/'integration-proof';i.mkdir()
for name in ['run-setup.py','run-export.py','freeze.py','verify-private.py','verify-export.py','run-frontend.py','run-wasm.py']:
    s=(old/'integration-proof'/name).read_text().replace('torch-iteration-51','torch-iteration-52-final').replace('0.51.0','0.52.0')
    if name=='freeze.py':s=s.replace('len(tests)==48','len(tests)==49').replace('6184','6402').replace('expected_suites=48','expected_suites=49')
    if name=='verify-export.py':s=s.replace('len(published)==11019','len(published)==11177')
    if name=='verify-private.py':s=s.replace('core_modules=53','core_modules=54').replace('all_55_core_license_hashes','all_56_core_license_hashes')
    (i/name).write_text(s)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
save(i/'context.json',dict(upstream=head,version='0.52.0',source_hashes=source))
for name in ['native-ci.json','native-receipt.json','native-ci.log']:shutil.copy2(old/'integration-proof'/name,i/name)
shutil.copy2(old/'native-catalog-input-identity.json',r/'native-catalog-input-identity.json')
identity=json.loads((r/'native-catalog-input-identity.json').read_text())
for name,digest in identity['files'].items():assert sha(repo/name)==digest,name
save(i/'native-reference-reuse.json',dict(status='unchanged_native_reference_reused',files=len(identity['files']),
    original='../torch-iteration-50/integration-proof/native-ci.json',previous='../torch-iteration-51/integration-proof/native-ci.json',
    reason='Native original catalog/runner/solutions/mutants/tests/configuration are byte-identical. New MHA has separate native numerical oracles. Final adapter CPU/WASM/package/export gates rerun.'))
shutil.copy2(old/'release-policy-identity.json',r/'release-policy-identity.json')
for name,digest in json.loads((r/'release-policy-identity.json').read_text())['files'].items():assert sha(repo/name)==digest
preflight=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-52-mha-preflight.json').read_text())
changed={k for k in source if source[k]!=preflight['source_hashes'][k]}
assert changed=={'__init__.py'} and set(source)==set(preflight['source_hashes'])
before=(pre/'proof/source/__init__.py').read_text();after=(p/'source/__init__.py').read_text()
assert before.replace("__version__ = '0.51.0'","__version__ = '0.52.0'")==after
assert sha(repo/'packages/stridetorch/benchmarks/bench_multihead.py')==json.loads((pre/'fairbench/identity.json').read_text())['benchmark_sha256']
save(r/'preflight-reuse.json',dict(status='exact_mathematical_source_reused',only_source_change='__init__.py version 0.51.0 to 0.52.0',
    previous_source_sha256=preflight['source_hashes'],final_source_sha256=source,
    previous_evidence='packages/stridetorch/benchmarks/results/iteration-52-mha-preflight.json',
    previous_evidence_sha256=sha(repo/'packages/stridetorch/benchmarks/results/iteration-52-mha-preflight.json'),
    previous_archive_sha256=preflight['archive']['sha256'],performance=preflight['performance'],
    benchmark_sha256=sha(repo/'packages/stridetorch/benchmarks/bench_multihead.py'),
    reason='No numerical, AD, MHA, lifecycle or benchmark code changed. Existing 12-process timing evidence remains identified to exactly the same engine. Full final CPU/WASM/package/catalog gates rerun; adapter native-oracle comparison reruns.'))
for name in ['differential-mha.py','compare-mha.py','native-mha.json','native-mha.npz']:
    shutil.copy2(pre/name,r/name)
print(dict(resources=len(source),suites=49,contracts=6402,baseline=head))
