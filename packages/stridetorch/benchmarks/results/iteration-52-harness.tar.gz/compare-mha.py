from pathlib import Path
import json
import numpy as np

r = Path(__file__).resolve().parent
native = json.loads((r/'native-mha.json').read_text())
adapter = json.loads((r/'adapter-mha.json').read_text())
assert native['script_sha256'] == adapter['script_sha256'], 'Reference must use the same fixture script'
assert native['rows'] == adapter['rows'], 'Case schema, None gradients, parameter versions or shapes differ'
reference = np.load(r/'native-mha.npz')
got = np.load(r/'adapter-mha.npz')
assert reference.files == got.files
failures = []
maximum = {}
for name in reference.files:
    expected, actual = reference[name], got[name]
    tolerance = dict(rtol=8e-5, atol=8e-6) if expected.dtype == np.float32 else dict(rtol=2e-10, atol=2e-11)
    try:
        np.testing.assert_allclose(actual, expected, equal_nan=False, **tolerance)
    except AssertionError:
        failures.append(dict(name=name, maximum_absolute_error=float(np.max(abs(expected-actual), initial=0))))
    category = 'initialization' if name.startswith('init-') else name.split('.')[1].rstrip('0123456789')
    maximum[category] = max(maximum.get(category, 0), float(np.max(abs(expected-actual), initial=0)))
result = dict(status='passed' if not failures else 'failed', cases=len(native['rows']), arrays=len(reference.files),
              backend_scope='Native Torch CPU MHA fastpath disabled; SDPA math backend',
              max_absolute_error=maximum, failures=failures[:12])
(r/'mha-comparison.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result))
assert not failures
