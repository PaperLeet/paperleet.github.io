from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');old='acce1f3ae4448cdb61fb15dafbe9a7a7d95b50f6';upstream='9d35c9360c4652a06e4ae1283f015f5cb8a7cf49';env={**os.environ,'PATH':'/opt/homebrew/bin:'+os.environ['PATH']};receipts=[]
def save(name,value):(r/name).write_text(json.dumps(value,indent=2)+'\n')
new=subprocess.check_output(['git','diff','--name-only',old,upstream],cwd=repo,text=True).splitlines();assert set(new)=={'docs/organization-affiliations.md','web/scripts/check-profile-settings.mjs','web/src/AffiliationBadge.tsx','web/src/community.css','web/src/organization-logo.css'}
for name in new:assert (repo/name).read_bytes()==subprocess.check_output(['git','show',upstream+':'+name],cwd=repo)
for name in ('context.json','latest-upstream.json','react-review.json'):shutil.copy2(r/name,r/('before-followup-'+name))
context=json.loads((r/'context.json').read_text());context.update(upstream=upstream,merge_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),upstream_files_preserved=subprocess.check_output(['git','diff','--name-only','0d5975a0',upstream],cwd=repo,text=True).splitlines(),python_scope='Complete29960 final core before15-file UI/style/check/docs-only upstream merges;no mathematical,Python,package,catalog or lockfile inputs changed');save('context.json',context);save('latest-upstream.json',context)
review=json.loads((r/'react-review.json').read_text());review['observations'].append('Latest AffiliationBadge removes a decorative logo;hook order,localized text and accessible label remain;profile-settings contracts and both builds repeated');review['upstream_files_preserved']=context['upstream_files_preserved'];save('react-review.json',review)
value=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED','--jq','.value'],text=True).strip();profile=json.loads((r/'pages-profile.json').read_text());assert value==profile['observed_value'];save('pages-profile-latest.json',profile)
for args,name,overrides in [(['/opt/homebrew/bin/node','scripts/check-profile-settings.mjs'],'profile-settings-latest.log',{}),(['npm','run','build'],'frontend-build-latest.log',{}),(['npm','run','build'],'pages-profile-build-latest.log',profile['environment'])]:
 start=time.monotonic()
 with (r/name).open('w') as log:p=subprocess.run(args,cwd=repo/'web',env={**env,**overrides},stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(args=args,log=name,cwd=str(repo/'web'),exit_code=p.returncode,elapsed_s=time.monotonic()-start,environment=overrides));save('followup-receipts.json',receipts);print(name,'terminal',p.returncode,flush=True);p.check_returncode()
