"""Observe hidden suspension without changing production Tensor/GPU code."""
import asyncio,json
from contextlib import nullcontext
import numpy as np
from stridetorch import torch,__version__
from matrix_client import Matrix
assert __version__=='0.83.0'
loop=asyncio.get_running_loop()
rows=[]
for kind in ['ordinary_live_input','no_grad_live_input','owned_snapshot_before_yield']:
 x=torch.tensor([[1.,2.],[3.,4.]],dtype=torch.float32,requires_grad=True)
 before=x.detach().numpy().copy();version_before=int(x._version)
 payload=before.copy() if kind=='owned_snapshot_before_yield' else x.detach().numpy()
 callback_rows=[];stage='before_upload'
 def callback():
  row=dict(stage=stage,grad_enabled=torch.is_grad_enabled(),version_before=int(x._version))
  row['unrelated_result_requires_grad']=(x*2.).requires_grad
  with torch.no_grad():x.add_(10.)
  row['version_after']=int(x._version);callback_rows.append(row)
 loop.call_soon(callback)
 with torch.no_grad() if kind=='no_grad_live_input' else nullcontext():
  stage='inside_upload'
  with Matrix.upload(payload) as matrix:
   stage='inside_read';uploaded=matrix.numpy()
  stage='after_close'
 # Drain an observed callback if the runtime happened not to run it during RPC.
 await asyncio.sleep(0)
 assert len(callback_rows)==1 and torch.is_grad_enabled()
 assert int(x._version)>version_before
 if kind=='owned_snapshot_before_yield':np.testing.assert_array_equal(uploaded,before)
 assert np.array_equal(uploaded,before) or np.array_equal(uploaded,before+10.)
 rows.append(dict(kind=kind,callback=callback_rows[0],original=before.tolist(),uploaded=uploaded.tolist(),final_input=x.detach().numpy().tolist(),version_before=version_before,version_after=int(x._version),version_guard_captured_before_yield_would_reject=int(x._version)!=version_before,grad_mode_restored=True,input_snapshot_owned=bool(payload.flags.owndata)))
report=dict(status='observed_jspi_callback_semantics',cases=3,rows=rows,version=__version__,numpy=np.__version__,production_changed=False,automatic_torch_gpu_backend=False,performance_qualified=False)
