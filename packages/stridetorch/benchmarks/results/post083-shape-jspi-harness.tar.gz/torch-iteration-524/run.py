from pathlib import Path
import hashlib,json,os,subprocess,time,traceback,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent;b=r.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
plan=read(r/'execution-plan.json');receipts=[]
def verify():
 for n,h in plan['files'].items():assert sha(r/n)==h,n

def run(label,command,env):
 verify();p=r/(label+'.log');assert not p.exists();start=time.monotonic()
 with p.open('w') as out:
  child=subprocess.Popen(command,cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT);write(r/'progress.json',dict(status='running',label=label,pid=child.pid,supervisor_pid=os.getpid(),receipts=receipts));code=child.wait()
 receipt=dict(label=label,exit_code=code,seconds=time.monotonic()-start,command=command,log_sha256=sha(p));receipts.append(receipt);write(r/'receipts.json',receipts);verify();print(json.dumps(receipt),flush=True);assert code==0,(label,p.read_text()[-2500:])
try:
 for label,python in plan['pythons'].items():
  env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONPATH=str(r/'candidate'),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
  for k in ['PYTHONTRACEMALLOC','PYTHONPROFILEIMPORTTIME']:env.pop(k,None)
  for variant in ['baseline','candidate']:run(label+'-'+variant,[python,'-B',str(r/'corpus.py'),'--source',str(r/variant/'stridetorch'),'--output',str(r/(label+'-'+variant+'.json'))],env)
  old=read(r/(label+'-baseline.json'));new=read(r/(label+'-candidate.json'));assert old==new,(label,'arithmetic bitwise corpus differs');assert old['cases']==882
  run(label+'-sdk',[python,'-B','-m','pytest',str(r/'contracts'),'-q','-p','no:cacheprovider','--basetemp='+str(r/(label+'-tmp')),'--junitxml='+str(r/(label+'.xml'))],env)
  suites=list(ET.parse(r/(label+'.xml')).getroot().iter('testsuite'));totals={k:sum(int(v.attrib.get(k,0)) for v in suites) for k in ['tests','failures','errors','skipped']};assert totals==dict(tests=12308,failures=0,errors=0,skipped=0 if label=='numpy25' else 3),totals;write(r/(label+'-summary.json'),dict(totals=totals,arithmetic_cases=882,all_baseline_candidate_fields_bitwise_equal=True))
 write(r/'result.json',dict(status='passed_native_parent_shape_reuse_semantic_gates',receipts=receipts,pythons=plan['pythons'],summaries={k:read(r/(k+'-summary.json')) for k in plan['pythons']},performance_qualified=False,wasm_qualified=False,production_changed=False,ci_triggered=False,goal_status='active'));write(r/'progress.json',dict(status='completed',receipts=receipts));print('Native semantic gates passed',flush=True)
except BaseException as error:write(r/'progress.json',dict(status='failed',error=str(error),traceback=traceback.format_exc(),receipts=receipts));raise
