"""Recognize only provably stale, unstarted manual quality requests."""
import re


def ignorable_stale_queued_quality(run, current_sha, jobs, *,
                                  canonical_policies_verified=False,
                                  ancestor_verified=False):
    """This never authorizes cancelling or changing a workflow.

    The caller verifies the pinned CI/Pages policies at both immutable SHAs.
    Those policies bind execution to the requested SHA and reject publication
    unless it is still current main. A non-force main advance cannot make an
    ancestor request current again. Active Pages and current quality runs
    remain blocking.
    """
    return (
        run.get('name') == 'PaperLeet quality gate'
        and run.get('path') == '.github/workflows/ci.yml'
        and run.get('status') == 'queued'
        and run.get('conclusion') is None
        and run.get('event') == 'workflow_dispatch'
        and run.get('head_branch') == 'main'
        and run.get('repository', {}).get('full_name') == 'PaperLeet/paperleet.github.io'
        and run.get('head_repository', {}).get('full_name') == 'PaperLeet/paperleet.github.io'
        and re.fullmatch('[0-9a-f]{40}', run.get('head_sha', '')) is not None
        and re.fullmatch('[0-9a-f]{40}', current_sha) is not None
        and run['head_sha'] != current_sha
        and isinstance(jobs, list)
        and not jobs
        and canonical_policies_verified is True
        and ancestor_verified is True
    )


def pages_after_quality_completion(quality, pages):
    """A Pages run from before this successful completion cannot close its gap.

    workflow_run children use the current default-branch SHA, which can also
    appear on a skipped child of an older cancelled quality run. Completion
    time is necessary in addition to matching the top-level SHA.
    """
    from datetime import datetime
    if (quality.get('status') != 'completed' or quality.get('conclusion') != 'success'
            or pages.get('name') != 'Publish PaperLeet public site'
            or pages.get('event') not in ('workflow_run', 'workflow_dispatch')
            or not quality.get('head_sha') or pages.get('head_sha') != quality['head_sha']):
        return False
    try:
        completed = datetime.fromisoformat(quality['updated_at'].replace('Z', '+00:00'))
        created = datetime.fromisoformat(pages['created_at'].replace('Z', '+00:00'))
        return completed.tzinfo is not None and created.tzinfo is not None and created >= completed
    except (KeyError, TypeError, AttributeError, ValueError):
        return False
