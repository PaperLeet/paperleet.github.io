from pathlib import Path
import hashlib,io,json,shutil,tarfile
r=Path(__file__).resolve().parent;b=r.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[r/'archive.py',r/'result.json']
for stage in [524,525,526,527,528,529]:
 folder=b/f'torch-iteration-{stage}'
 files.extend(p for p in folder.rglob('*') if p.is_file() and not any(part in ['numpy25-tmp','numpy126-tmp','__pycache__'] for part in p.relative_to(folder).parts))
for stage,planfile,key in [(524,'execution-plan.json','files'),(527,'screen-plan.json','inputs'),(528,'source-plan.json','files'),(529,'source-plan.json','files')]:
 folder=b/f'torch-iteration-{stage}';plan=json.loads((folder/planfile).read_text())
 for n,h in plan[key].items():assert sha(folder/n)==h,(stage,n)
files=sorted(set(files));manifest={str(p.relative_to(b)):sha(p) for p in files};seen={};target=r/'post083-shape-jspi-harness.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz') as stream:
 for p in files:
  name=str(p.relative_to(b));h=manifest[name]
  if h in seen:
   info=stream.gettarinfo(str(p),arcname=name);info.type=tarfile.LNKTYPE;info.linkname=seen[h];info.size=0;stream.addfile(info)
  else:stream.add(p,arcname=name,recursive=False);seen[h]=name
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256.json');info.size=len(data);stream.addfile(info,io.BytesIO(data))
with tarfile.open(target) as stream:
 for name,h in manifest.items():assert hashlib.sha256(stream.extractfile(name).read()).hexdigest()==h,name
receipt=dict(path='packages/stridetorch/benchmarks/results/'+target.name,files=len(files),unique_payloads=len(seen),bytes=target.stat().st_size,sha256=sha(target),all_payloads_verified=True)
(r/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');summary=json.loads((r/'result.json').read_text());summary['raw_archive']=receipt
(repo/'packages/stridetorch/benchmarks/results/post083-shape-jspi.json').write_text(json.dumps(summary,indent=2)+'\n');shutil.copy2(target,repo/receipt['path']);print(json.dumps(receipt))
