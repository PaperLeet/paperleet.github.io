from pathlib import Path
import hashlib,json
import numpy as np
r=Path(__file__).resolve().parent;inputs={}
shapes=[((3,7),(5,7)),((2,1,3,7),(1,4,5,7)),((0,7),(3,7)),((3,0),(5,0)),((0,3,7),(1,5,7)),((3,7),(0,7)),((4,31),(5,31)),((2,4097),(3,4097))]
for dtype in ['float32','float64']:
 for index in range(12):
  rng=np.random.RandomState(77+index);a,b=[rng.randn(*s).astype(dtype) for s in shapes[index%len(shapes)]]
  if index==8:a=np.asarray([[np.inf,0],[np.nan,2],[0,0],[-np.inf,1]],dtype=dtype);b=np.asarray([[np.inf,1],[0,-1]],dtype=dtype)
  if index==9:a=np.asarray([[0.,0.],[1.,-1.],[1.,-1.]],dtype=dtype);b=np.asarray([[0.,0.],[0.,0.]],dtype=dtype)
  if index==10:a=rng.randn(3,8).astype(dtype);b=rng.randn(4,8).astype(dtype)
  if index==11:a=rng.randn(8,11).astype(dtype);b=rng.randn(10,11).astype(dtype)
  prefix=f'{dtype}.{index}';inputs[prefix+'.a']=a;inputs[prefix+'.b']=b
  aa,bb=(a[::2],b[::2]) if index==11 else (a,b)
  batch=np.broadcast_shapes(aa.shape[:-2],bb.shape[:-2]);n=aa.reshape(-1,aa.shape[-1]).shape[0] if aa.shape[-1] else 3
  for name,shape in [('cdist',(*batch,aa.shape[-2],bb.shape[-2])),('pdist',(n*(n-1)//2,))]:inputs[prefix+'.'+name+'.seed']=np.sin(np.arange(np.prod(shape))+.3).reshape(shape).astype(dtype)
np.savez_compressed(r/'distance-inputs.npz',**inputs)
(r/'distance-inputs.json').write_text(json.dumps(dict(arrays=len(inputs),sha256=hashlib.sha256((r/'distance-inputs.npz').read_bytes()).hexdigest(),scope='Frozen logical source arrays and output seeds; index 10 applies negative feature strides at runtime, index 11 constructs positive-strided Tensor views after loading.'),indent=2)+'\n');print('frozen arrays',len(inputs))
