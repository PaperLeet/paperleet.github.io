from pathlib import Path
import json,sys,warnings
import numpy as np
backend=sys.argv[1]
if backend=='native':import torch as t
else:from stridetorch import torch as t
r=Path(__file__).resolve().parent;rows={};arrays={};inputs=np.load(r/'distance-inputs.npz')
def record(key,fn,meta):
 if backend=='native':print(key,flush=True)
 try:
  with warnings.catch_warnings():warnings.simplefilter('ignore');value=fn()
  schema=[]
  for i,x in enumerate(value):
   if x is None:schema.append(None);continue
   a=x.detach().numpy();schema.append(dict(dtype=str(a.dtype),shape=list(a.shape)));arrays[f'{key}.{i}']=a.copy()
  rows[key]=dict(status='ok',values=schema,**meta)
 except Exception as e:rows[key]=dict(status='error',error=type(e).__name__,message=str(e)[:200],**meta)
def tensor(a,grad=True):return t.tensor(a,requires_grad=grad)
def case(name,p,dtype,index,workspace):
 a=inputs[f'{dtype}.{index}.a'];b=inputs[f'{dtype}.{index}.b']
 if index==10:a=a[...,::-2];b=b[...,::-2]
 if name=='pdist':a=a.reshape(-1,a.shape[-1]) if a.shape[-1] else np.empty((3,0),dtype=dtype)
 if backend!='native':
  from stridetorch import _distance
  _distance._WORKSPACE_BYTES=workspace
 if index==11:
  x=tensor(a.T.copy(),False).t()[::2].detach().requires_grad_();y=tensor(b.T.copy(),False).t()[::2].detach().requires_grad_()
 else:x=tensor(a);y=tensor(b) if name=='cdist' else None
 value=t.pdist(x,p=p) if name=='pdist' else t.cdist(x,y,p=p,compute_mode='donot_use_mm_for_euclid_dist')
 seed=inputs[f'{dtype}.{index}.{name}.seed']
 if not (backend=='native' and name=='pdist' and a.shape[0]==0 and p!=0):
  (value*tensor(seed,False)).sum().backward()
 return [value,x.grad,*([] if name=='pdist' else [y.grad])]
for dtype in ['float32','float64']:
 for p in [0.,.5,1.,1.5,2.,3.,float('inf'),1e-50,1e40]:
  for name in ['cdist','pdist']:
   for index in range(12):
    for workspace in [8*1024*1024,16*1024]:
     record(f'{name}.{dtype}.{p}.{index}.{workspace}',lambda name=name,p=p,dtype=dtype,index=index,workspace=workspace:case(name,p,dtype,index,workspace),dict(factory=name,dtype=dtype,p=str(p),case=index,workspace=workspace,empty_backward_oracle=(name=='pdist' and index in [2,4] and p!=0)))
if backend!='native':
 from stridetorch import _distance
 _distance._WORKSPACE_BYTES=8*1024*1024
np.savez_compressed(r/(backend+'-distances.npz'),**arrays)
(r/(backend+'-distances.json')).write_text(json.dumps(dict(backend=backend,version=getattr(t,'__version__',None),numpy=np.__version__,rows=rows),indent=2)+'\n');print(backend,len(rows),'cases',sum(v['status']=='error' for v in rows.values()),'errors')
