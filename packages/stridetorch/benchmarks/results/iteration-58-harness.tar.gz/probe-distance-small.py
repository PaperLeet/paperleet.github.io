from pathlib import Path
import importlib.util,json,sys,timeit,statistics
import numpy as np
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');rows=[]
for label,path in [('baseline',r/'baseline-source/stridetorch'),('candidate',repo/'packages/stridetorch/src/stridetorch')]:
 name='_distance_small_'+label;s=importlib.util.spec_from_file_location(name,path/'__init__.py',submodule_search_locations=[str(path)]);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);t=m.torch
 for kind in ['cdist','pdist']:
  for backward in [False,True]:
   x=t.tensor(np.sin(np.arange(28)).reshape(4,7),dtype=t.float32,requires_grad=backward);y=t.tensor(np.cos(np.arange(35)).reshape(5,7),dtype=t.float32,requires_grad=backward)
   def run():
    x.grad=y.grad=None
    d=t.cdist(x,y) if kind=='cdist' else t.pdist(x)
    if backward:d.sum().backward()
   run();samples=timeit.repeat(run,number=2000,repeat=3);rows.append(dict(label=label,kind=kind,backward=backward,median_us=statistics.median(samples)/2000*1e6))
(r/'distance-small-pilot.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
