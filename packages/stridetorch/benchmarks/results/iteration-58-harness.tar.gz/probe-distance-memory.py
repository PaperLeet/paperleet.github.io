from pathlib import Path
import gc,importlib.util,json,sys,time,tracemalloc
import numpy as np
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');rows=[]
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path/'__init__.py',submodule_search_locations=[str(path)]);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m.torch
for label,path in [('baseline',r/'baseline-source/stridetorch'),('candidate',repo/'packages/stridetorch/src/stridetorch')]:
 t=load('_distance_memory_'+label,path)
 for kind in ['cdist','pdist']:
  x=t.tensor(np.sin(np.arange(128*128)).reshape(128,128),dtype=t.float32,requires_grad=True);y=t.tensor(np.cos(np.arange(192*128)).reshape(192,128),dtype=t.float32,requires_grad=True)
  fn=(lambda:t.cdist(x,y)) if kind=='cdist' else (lambda:t.pdist(x))
  gc.collect();tracemalloc.start();start=time.perf_counter();value=fn();forward_s=time.perf_counter()-start;current,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
  tracemalloc.start();start=time.perf_counter();value.sum().backward();backward_s=time.perf_counter()-start;_,backpeak=tracemalloc.get_traced_memory();tracemalloc.stop()
  rows.append(dict(label=label,kind=kind,retained_bytes=current,forward_peak=peak,backward_peak=backpeak,forward_s=forward_s,backward_s=backward_s))
  del x,y,value,fn;gc.collect()
(r/'distance-memory-pilot.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
