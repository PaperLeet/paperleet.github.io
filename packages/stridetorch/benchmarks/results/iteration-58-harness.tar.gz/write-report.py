from pathlib import Path
import json
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');j=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-58.json').read_text());perf=j['performance'];archive=j['raw_archive'];timing=[]
for index,row in enumerate(perf['cpu']):
    if row['dtype']!='float32' or row['p']!='2.0' or not row['matched']:continue
    cells=[]
    for runtime in ['cpu','node','chrome']:
        v=perf[runtime][index];cells.append(f"{v['median_us']['candidate']:.1f} μs / {v['candidate_over_baseline']:.3f}× ({v['ratio_range'][0]:.3f}–{v['ratio_range'][1]:.3f})")
    timing.append('| '+f"{row['factory']} / {row['shape']} / {row['mode']}"+' | '+' | '.join(cells)+' |')
memory=[]
for kind in ['cdist','pdist']:
    old=next(v for v in j['memory']['rows'] if v['variant']=='baseline' and v['factory']==kind);new=next(v for v in j['memory']['rows'] if v['variant']=='candidate' and v['factory']==kind)
    fields=['new_retained_bytes','forward_peak_bytes','backward_peak_bytes'];memory.append('| '+kind+' | '+' | '.join(f"{old[k]/1e6:.3f} → {new[k]/1e6:.3f}" for k in fields)+' |')
text=f'''# Torch runtime iteration 58 — bounded direct pairwise distances

Version 0.58.0 broadens `torch.cdist`, `torch.pdist` and the ordinary
`torch.nn.functional.pdist` alias while replacing retained point-pair-by-feature
difference arrays with bounded recomputation and shared first-order pullbacks.
The broader independent-library/core-efficiency/backend objective remains active.

## Behavior and algorithms

Real float32/64 Minkowski distances support nonnegative orders, including zero,
fractional orders and infinity. Cdist broadcasts batch dimensions; pdist emits
the condensed upper triangle. The mathematical API is compared with the
[PyTorch 2.14 cdist documentation](https://docs.pytorch.org/docs/2.14/generated/torch.cdist.html),
and observed native CPU scalar/IEEE/gradient conventions are separately tested.
No upstream implementation source is vendored.

Point, batch and feature tiles use an 8 MiB work-array planning budget. The bound
excludes input/output storage, requested input gradients and runtime overhead;
it is not a process RSS or browser heap limit. Small cdist geometries and tiny
pdist inputs bypass tile scheduling when the same byte model proves they fit.
The forward tape saves required input arrays, output distances and metadata;
non-leaf Tensor objects need not be retained. Pair directions are recomputed once
per block/backward traversal, shared by active inputs, and broadcast gradients
accumulate directly into original input shapes. Pdist visits upper-triangle
blocks and shares one input-gradient buffer. No result or gradient cache is added.

Outputs remain limited to 16 million elements; pair-feature work is capped at
512 million. A 128-by-129 point problem with 1,024 features now runs and
differentiates under the bounded workspace; the old full-difference allocation
limit rejected that workload. Output/work limits reject oversized requests before
allocation. Zero-coordinate, zero-distance and infinity-tie gradients, storage
versions, dtype conversions, no_grad and graph release/retention are checked.

Cdist still validates all three native compute-mode names and deliberately keeps
the library's existing stable direct-difference numerical policy. It does not
implement native matrix-multiplication dispatch/rounding or its AD behavior.
Half/complex kernels, forward/higher derivatives and GPU execution remain outside
this contract. Existing numerical qualifications from iterations 53 and 56 remain.

## Verification

| Gate | Result |
| --- | --- |
| Full repository CPU tests, including SDK | 40,815 passed, 1 skipped |
| Node Pyodide 0.29.4 / NumPy 2.2.5 | 7,185 passed |
| Chrome {j['chrome_worker']['browser']} worker, same Pyodide | 7,185 passed |
| Public wheel, Python 3.10.19 / NumPy 1.26.4 | 7,198 passed |
| Public/private wheel identity, separate uninstall, fresh pickle/alias processes | Passed |
| Installed public/private `import torch` and `from torch.nn.functional import pdist` | Values, gradients and restoration passed |
| Exported PaperLeet catalog | 78/78 modules, 342 mutants; all original browser budgets passed |
| Independent contracts inside exported attention runtime | 7,185 tests / 53 suites |
| Frontend | Full suite through deb2c6c9 passed; affected writing/preview checks and both builds passed on final main |
| Source/license resources across source, packages and WASM | 60 (58 Python modules plus LICENSE/NOTICE) |
| Immutable payloads retained from previous main | 12,125 unchanged; 158 new reachable payloads |
| Active exports/indices | 161 identities checked |
| Canonical release policies | Seven byte-identical to `13d2782a494415ba72bc604a0ef7e4c4f875ba25` |

The 168 new standalone tests include scalar formulas, scalar finite differences,
broadcast pair-loop gradient oracles, empty shapes, nonfinite conventions,
infinity ties, mutation/version guards, non-leaf collection, saved-array release,
retained seeds, newly accepted workloads, memory/work guards and complete AdamW
training/checkpoint continuation. Existing native distance/model-conversion tests
remain; their former valid-order rejection assertions were updated for the new
coverage. The changed root test is separately hashed and preserved in the archive.
All 1,152 pure-native catalog input hashes were rechecked before reusing that
catalog qualification. The initial package/CPU/frontend gates finish before the full WASM budget run.
Later disjoint UI commits receive separate checks after that run. No heavy
qualification overlaps formal timing.

## Differential qualification

Ninety-six frozen logical source/seed arrays drive the same 864 distance cases
on CPU, Node WASM and Chrome WASM, against installed native Torch
{j['native_dtype_isolation']['native_version']}. Each runtime has the same classification:

| Classification | Cases |
| --- | ---: |
| Native per-element value/gradient comparisons | 720 |
| Separately qualified fractional-gradient cases | 8 |
| Native forward plus independent empty-pdist backward contract | 64 |
| Matching negative-stride construction errors | 72 |

The 728 ordinary/norm-qualified rows contain 1,852 numeric arrays. Dtype/shape
match exactly. Finite/NaN/positive-infinity/negative-infinity masks are checked
separately; ordinary per-element rtol/atol are float32 `3e-5/3e-6` and float64
`3e-12/3e-12`. Both default and deliberately tiny 16 KiB workspaces are exercised.
A further 60 scalar-control cases have 32 numeric matches and 28 matching error
categories, including NumPy scalars, scalar Tensor restrictions, complex-real
conversion, malformed inputs and negative/NaN orders.

Eight cases involve cancellation in fractional distance gradients of longer
vectors. They fail the stated native per-element bound and are not counted as
per-element native passes. Both implementations independently meet scalar
compensated FP64 references built from the exact frozen inputs/seeds, using
math.sqrt/math.fsum; normalized L2 and maximum-component errors are bounded by
`3e-6` for float32 or `2e-12` for float64. Very small float32 orders that round to
zero model the observed native underflowed-order kernel-gradient convention,
not the real-arithmetic norm at that positive order. Per-case errors and formulas
are retained in the qualification JSON; tolerances were not broadened globally.

Native Torch reproducibly exited with code 139 on empty `pdist` input during
fractional backward (the trace ends at float32 p=0.5, shape `(0,7)`). The same
unsafe empty geometry at other nonzero orders was not executed again. Those 64
rows compare native forward only; the adapter's empty gradient is independently
checked for exact shape/dtype and zero elements. Raw progress traces and observed exit-code evidence are retained; no native C stack trace was available.
They are not native backward passes and do not imply that every skipped row was
individually observed to crash.

## Performance and allocation

Baseline is validated 0.57.0 (`dff3444dcd784eb41b1c4e5532cef1e66c2023c7`), candidate 0.58.0.
Four fresh processes per CPU/Node/Chrome runtime, five samples per case, alternate
variant order; shared batches are calibrated outside timing to at least 20 ms.
Input/seed conversion, correctness, warmup and GC are outside timing. Kernel and
graph construction, optional weighted backward, gradient clearing and result
release are included. There are 44 matched legacy-supported rows and 18
candidate-only new-order/larger-workload rows per process. Unsupported baseline
workloads have no speed ratio. No native Torch/GPU throughput is measured.

Representative float32 L2 rows below show candidate latency / time ratio, followed
by the full ratio range across four children. Below one means faster. Cdist
small/medium/large point-feature shapes are 4×5×7, 64×80×64 and 128×192×128;
broadcast uses batch (2,1)/(1,3), 16×20 points and 32 features. Pdist small,
medium and large shapes are 5×7, 64×64 and 128×128.

| Workload / shape / mode | CPU | Node WASM | Chrome WASM |
| --- | --- | --- | --- |
'''+ '\n'.join(timing)+f'''

Small-call validation and bounded packing have costs, and some forward workloads
are slower. The complete table includes these regressions, L1 controls, new-order
latencies and large feature-workload timings; the release is not an all-path
speedup claim. In particular, medium pdist forward remains a follow-up optimization
target even where its backward benefits from block reduction.

The CPU allocation comparison below creates inputs before tracing and uses
float32 cdist 128×192×128 / pdist 128×128. Values are decimal MB. Forward retained
means newly tracked allocations still live after the call; pre-existing input
storage is excluded in both variants. Backward starts a separate trace. These are
not total tape memory, process RSS or WASM heap high-water marks.

| Factory | New forward-retained MB, old → new | Forward peak MB, old → new | Backward peak MB, old → new |
| --- | --- | --- | --- |
'''+ '\n'.join(memory)+f'''

## Integration and reproduction

Main UI work through `{j['baseline_main']}` was preserved. The complete frontend
suite and both builds passed at `deb2c6c96bc65a237c3a7c848b710002cde46439`.
A subsequent disjoint Markdown-editor commit was checked with sixteen affected
writing, section-navigation, preview and reading tests plus driver/policy checks
and both local builds; their twenty receipts identify the final main exactly. Naming remains StrideTorch pending a separate choice.
No tag, workflow dispatch, release, package upload or deployment is initiated.
Main adoption is recorded separately after local verification; the broader goal
remains active.

- Result: `packages/stridetorch/benchmarks/results/iteration-58.json`
- Benchmark: `packages/stridetorch/benchmarks/bench_distances.py`
- Raw archive: `packages/stridetorch/benchmarks/results/{archive['name']}`
- Archive bytes: {archive['bytes']:,}
- Archive SHA-256: `{archive['sha256']}`

The archive contains frozen code/tests/inputs, native arrays and crash traces,
CPU/Node/Chrome qualification reports and replay harnesses, package and alias
proofs, full catalog/frontend receipts, pilots and all twelve final benchmark
children. Environment directories, caches and third-party implementation source
are excluded. GPU/resident-storage work remains separate from this dense CPU/WASM
milestone.
'''
(repo/'docs/validation/torch-runtime-iteration-58.md').write_text(text);print('report written')
