from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;i=r/'integration-proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release');receipts=[];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();env=dict(os.environ,PYTHON=str(r.parent/'torch-iteration-21/stride-dev-env/bin/python'));env['PATH']='/opt/homebrew/bin:'+env['PATH']
def run(args,label,cwd,extra=None):
 started=time.monotonic()
 with (i/('latest-'+label+'.log')).open('w') as log:p=subprocess.run(args,cwd=cwd,env={**env,**(extra or {})},stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(label=label,args=args,cwd=str(cwd),exit_code=p.returncode,elapsed_s=time.monotonic()-started));(i/'latest-ui-qualification.json').write_text(json.dumps(dict(upstream=head,full_suite_baseline='deb2c6c96bc65a237c3a7c848b710002cde46439',scope='Affected writing/Markdown/preview regression checks and driver/policy/build checks after disjoint incoming UI-only commit.',receipts=receipts,status='running'),indent=2)+'\n');p.check_returncode();print(label,'TERMINAL 0',flush=True)
checks=['writing-sections','markdown-editor','live-writing','writing-disclosure','community-writing','community-submit-shortcut','interview-writing','problem-solution-panel','solution-code-draft','community-markdown','community-code-block','math-security','feed-outlines','post-preview','post-search-preview','discussion-reading']
for name in checks:run(['/opt/homebrew/bin/node','scripts/check-'+name+'.mjs'],name,repo/'web')
run(['/opt/homebrew/bin/node','web/scripts/check-wasm-cases.mjs'],'wasm-driver',repo)
run(['/opt/homebrew/bin/node','web/scripts/check-pages-release.cjs'],'pages-policy',repo)
run(['npm','run','build'],'build',repo/'web')
profile=json.loads((i/'pages-profile.json').read_text())['environment'];run(['npm','run','build'],'pages-profile-build',repo/'web',profile)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
path=i/'latest-ui-qualification.json';j=json.loads(path.read_text());j['status']='qualified';path.write_text(json.dumps(j,indent=2)+'\n');print('LATEST UI QUALIFIED',head,flush=True)
