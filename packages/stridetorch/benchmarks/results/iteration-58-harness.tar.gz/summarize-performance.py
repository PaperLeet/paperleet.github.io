from pathlib import Path
import json,statistics
r=Path(__file__).resolve().parent;summary={}
for runtime in ['cpu','node','chrome']:
 processes=[]
 for repeat in range(4):
  data=json.loads((r/f'performance/{runtime}-{repeat}.json').read_text());processes.append(data.get('benchmark',data))
 result=[]
 for index,row in enumerate(processes[0]['rows']):
  rows=[p['rows'][index] for p in processes];keys=['factory','dtype','p','shape','mode','matched','left_shape','right_shape'];assert all(all(v[k]==row[k] for k in keys) for v in rows)
  times={k:[v['median_s'][k] for v in rows] for k in row['median_s']};ratios=[v['candidate_over_baseline'] for v in rows if v['candidate_over_baseline'] is not None]
  result.append({**{k:row[k] for k in keys},'median_us':{k:statistics.median(v)*1e6 for k,v in times.items()},'candidate_over_baseline':statistics.median(ratios) if ratios else None,'ratio_range':[min(ratios),max(ratios)] if ratios else None})
 summary[runtime]=result
summary['method']='Four fresh processes/runtime, five samples/case, alternating variants; common batches calibrated outside timing to >=20 ms. Median process medians and full process-ratio ranges. 44 matched legacy-supported rows plus 18 candidate-only new-order/larger-workload rows. Input conversion outside timing; graph construction, optional weighted backward, gradient clearing and result destruction included. No native Torch/GPU, universal speedup or RSS claim.'
(r/'performance-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({runtime:[{k:v for k,v in row.items() if k in ['factory','shape','mode','candidate_over_baseline']} for row in summary[runtime] if row['dtype']=='float32' and row['p']=='2.0' and row['matched']] for runtime in ['cpu','node','chrome']}))
