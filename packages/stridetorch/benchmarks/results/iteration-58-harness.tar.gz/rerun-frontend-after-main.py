from pathlib import Path
import json,subprocess,time
r=Path(__file__).resolve().parent;i=r/'integration-proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release');py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';args=[str(py),str(i/'run-frontend.py')];started=time.monotonic()
prior=json.loads((i/'receipts.json').read_text());assert len(prior)==2 and all(v['exit_code']==0 for v in prior)
with (i/'frontend-after-main.log').open('w') as log:p=subprocess.run(args,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
prior=[v for v in prior if v['label']!='frontend'];prior.append(dict(label='frontend',args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-started,upstream=json.loads((i/'context.json').read_text())['upstream']))
(i/'receipts.json').write_text(json.dumps(prior,indent=2)+'\n');p.check_returncode();print('frontend-after-main TERMINAL 0',flush=True)
