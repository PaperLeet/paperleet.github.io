from pathlib import Path
import collections,hashlib,json,math
import numpy as np
r=Path(__file__).resolve().parent
native=json.loads((r/'native-distances.json').read_text());adapter=json.loads((r/'adapter-distances.json').read_text());n=native['rows'];a=adapter['rows'];nn=np.load(r/'native-distances.npz');aa=np.load(r/'adapter-distances.npz');inputs=np.load(r/'distance-inputs.npz')
assert set(a)==set(n) and len(a)==864
counts=collections.Counter();qualified=[];references={}
def scalar_reference(meta):
 key=(meta['dtype'],meta['p'],meta['case'])
 if key in references:return references[key]
 prefix=f"{meta['dtype']}.{meta['case']}";x=inputs[prefix+'.a'];y=inputs[prefix+'.b'];seed=inputs[prefix+'.cdist.seed'];p=float(meta['p']);m=x.shape[-1]
 values=np.empty((len(x),len(y)));directions={}
 for i in range(len(x)):
  for j in range(len(y)):
   delta=[float(u)-float(v) for u,v in zip(x[i],y[j])]
   distance=math.fsum(math.sqrt(abs(d)) for d in delta)**2 if p==.5 else float(sum(d!=0 for d in delta))
   values[i,j]=distance
   directions[i,j]=[(math.copysign(math.sqrt(distance/abs(d)),d) if p==.5 else distance/d)*float(seed[i,j]) if d else 0. for d in delta]
 gx=np.array([[math.fsum(directions[i,j][k] for j in range(len(y))) for k in range(m)] for i in range(len(x))])
 gy=np.array([[-math.fsum(directions[i,j][k] for i in range(len(x))) for k in range(m)] for j in range(len(y))])
 references[key]=[values,gx,gy];return references[key]

def compare(x,y,tol,name):
 for mask in [np.isnan,np.isposinf,np.isneginf]:np.testing.assert_array_equal(mask(x),mask(y),err_msg=name)
 finite=np.isfinite(x)&np.isfinite(y);np.testing.assert_allclose(x[finite],y[finite],rtol=tol[0],atol=tol[1],err_msg=name)
for key,right in n.items():
 left=a[key];assert left['status']==right['status'],(key,left,right)
 if right['status']=='error':
  assert right['error']==left['error']=='ValueError' and right['case']==10,(key,left,right)
  counts['negative_stride_error_cases']+=1;continue
 if right['empty_backward_oracle']:
  assert right['factory']=='pdist' and right['values'][1] is None
  compare(aa[key+'.0'],nn[key+'.0'],(0,0),key);gradient=aa[key+'.1'];assert gradient.shape==(0,7) and gradient.dtype==np.dtype(right['dtype']) and not gradient.size
  counts['native_forward_independent_empty_backward_cases']+=1;continue
 assert left['values']==right['values'],(key,left,right)
 tol=(3e-5,3e-6) if right['dtype']=='float32' else (3e-12,3e-12)
 failures=[]
 for i,schema in enumerate(right['values']):
  if schema is None:continue
  try:compare(aa[f'{key}.{i}'],nn[f'{key}.{i}'],tol,f'{key}.{i}')
  except AssertionError:failures.append(i)
 if failures:
  assert right['factory']=='cdist' and right['case'] in [6,7] and right['p'] in ['0.5','1e-50'],(key,failures)
  assert right['p']=='0.5' or right['dtype']=='float32'
  ref=scalar_reference(right);metrics={};bound=3e-6 if right['dtype']=='float32' else 2e-12
  for label,arrays in [('adapter',aa),('native',nn)]:
   errors=[]
   for i,value in enumerate(ref):
    data=arrays[f'{key}.{i}'].astype('float64');assert np.isfinite(data).all() and np.isfinite(value).all()
    delta=data-value;l2=float(np.linalg.norm(delta.ravel())/max(np.linalg.norm(value.ravel()),np.finfo('float64').tiny));linf=float(np.max(np.abs(delta),initial=0)/max(np.max(np.abs(value),initial=0),np.finfo('float64').tiny));assert l2<=bound and linf<=bound,(key,label,i,l2,linf,bound)
    errors.append(dict(array=i,relative_l2=l2,relative_linf=linf))
   metrics[label]=errors
  qualified.append(dict(case=key,native_elementwise_failures=failures,bound=bound,metrics=metrics,reference='Exact frozen inputs/seeds; scalar math.sqrt and math.fsum. The underflowed float32 order uses native kernel p=0 forward and underflowed-order kernel-gradient convention, not mathematical real p=1e-50.'))
  counts['scalar_fp64_norm_qualified_cases']+=1
 else:counts['native_elementwise_cases']+=1
 counts['numeric_arrays']+=len(right['values'])
cn=json.loads((r/'native-distance-controls.json').read_text())['rows'];ca=json.loads((r/'adapter-distance-controls.json').read_text())['rows'];cnn=np.load(r/'native-distance-controls.npz');caa=np.load(r/'adapter-distance-controls.npz');assert set(cn)==set(ca) and len(cn)==60
control_counts=collections.Counter()
for key,expected in cn.items():
 actual=ca[key];assert actual['status']==expected['status'],(key,actual,expected)
 if expected['status']=='error':assert actual['error']==expected['error'],(key,actual,expected);control_counts['error_cases']+=1
 else:
  assert actual==expected,(key,actual,expected);compare(caa[key],cnn[key],(1e-12,1e-12),key);control_counts['numeric_cases']+=1
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
import stridetorch
source=Path(stridetorch.__file__).parent
report=dict(status='qualified',cases=len(a),counts=dict(counts),scalar_fp64_qualification=qualified,source_hashes={f.name:sha(f) for f in source.iterdir() if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']},input_sha256={name:sha(r/name) for name in ['differential-distances.py','qualify-distances.py','distance-inputs.npz','distance-inputs.json','native-distances.json','native-distances.npz','adapter-distances.json','adapter-distances.npz','differential-distance-controls.py','native-distance-controls.json','native-distance-controls.npz','adapter-distance-controls.json','adapter-distance-controls.npz']},controls=dict(cases=60,counts=dict(control_counts)),native_version=native['version'],numpy=np.__version__,scope='Exact schema and separate finite/NaN/signed-infinity masks; standard per-element tolerances float32 3e-5/3e-6, float64 3e-12/3e-12. Ill-conditioned fractional gradients are separately checked for both implementations against scalar compensated FP64 formulas and are not per-element native passes. Empty native pdist backward was not executed after reproducible native process crashes; adapter empty gradients use an independent contract.')
(r/'distances-qualification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status='qualified',cases=len(a),counts=counts,scalar_cases=[x['case'] for x in qualified])))
