from pathlib import Path
import json,subprocess,time
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');args=[str(r.parent.parent/'torch-iteration-21/stride-dev-env/bin/python'),'-m','pytest','tests','packages/stridetorch/tests','-q'];start=time.monotonic()
with (r/'complete-python.log').open('w') as log:p=subprocess.run(args,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
(r/'python-receipt.json').write_text(json.dumps(dict(args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-start),indent=2)+'\n');p.check_returncode();print('COMPLETE MERGED INFRASTRUCTURE TERMINAL0',flush=True)
