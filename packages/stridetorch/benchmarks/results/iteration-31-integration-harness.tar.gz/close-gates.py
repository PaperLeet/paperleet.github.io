from pathlib import Path
import hashlib,json,re,subprocess,tarfile
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');data=repo/'web/public/data';out=repo/'packages/stridetorch/benchmarks/results'
def read(name):return json.loads((r/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
context=read('context.json');latest=read('latest-upstream.json');actual={p.name:sha(p) for p in (repo/'packages/stridetorch/src/stridetorch').iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};assert len(actual)==46 and actual==context['source_hashes']==json.loads((r.parent/'proof-refined/source-hashes.json').read_text())
hashes=read('live-expected-sha256.json');assert len(hashes)==161 and hashes=={name:sha(data/name) for name in hashes}
entries={x['id']:x for x in read('live-expected/index.json')['problems']};w=read('full-wasm-result.json');assert w['concurrency']==2 and w['scope']=='catalog' and w['passed'] and w['modules']==w['catalog_modules']==len(entries)==78 and not w['browser_budget_exceeded']
assert len(w['results'])==78 and {c['id'] for c in w['results']}==set(entries)
for c in w['results']:
 e=entries[c['id']];assert c['passed'] and not c['browser_budget_exceeded'] and c['tests']==sum(e['tests'].values()) and c['budgets']==e['browser_judge']['budgets'] and c['bundle_url']==e['browser_judge']['bundle_url']
 b=c['budgets'];assert c['calibration_ms']<=b['calibration'] and c['learner_ms']<=b['run'] and c['preparation_ms']+c['calibration_ms']+c['learner_ms']<=b['total']
 payload=json.loads((data/c['bundle_url']).read_text());assert c['runtime_bundle_url']==payload['runtime_bundle_url'] and c['source_sha256']==hashlib.sha256(payload['reference'].encode()).hexdigest()
contracts=next(c['independent_contracts'] for c in w['results'] if 'independent_contracts' in c);assert contracts['passed']==1113 and len(contracts['suites'])==31
plan=json.loads((r.parent/'proof-refined/chrome-contracts/plan.json').read_text());harness=read('wasm-harness-identity.json');assert {c['suite']:c['source_sha256'] for c in contracts['suites']}==plan['tests']==harness['test_hashes'];assert harness['expected_passed']==1113 and harness['expected_suites']==31
assert harness['sha256']==sha(repo/harness['file']) and harness['driver_sha256']==sha(repo/harness['driver_file'])
n=read('native-ci.json');assert n['passed'] and not n['issues'] and n['problems']==78 and n['tests_executed']==10218 and n['repeats']==3 and n['duration_s']<=600
assert sum(map(len,n['mutation'].values()))==sum(c['mutants'] for c in w['results'])==342
assert n['mutation']==json.loads((r.parent.parent/'torch-iteration-30/integration-proof/native-ci.json').read_text())['mutation']
assert read('native-receipt.json')['exit_code']==read('wasm-receipt.json')['exit_code']==0
front=read('frontend-receipts.json');assert len(front)==5 and all(x['exit_code']==0 for x in front)
assert all(x['exit_code']==0 for x in read('export-receipts.json'))
for name in latest['upstream_files_preserved']:assert (repo/name).read_bytes()==subprocess.check_output(['git','show',latest['upstream']+':'+name],cwd=repo)
subprocess.run([str(r.parent.parent/'torch-iteration-21/stride-dev-env/bin/python'),str(r/'verify-export.py')],cwd=repo,check=True,stdout=subprocess.DEVNULL)
export=read('export-identity.json');assert export['published_assets_unchanged']==7704 and export['new_assets']==158
owned=read('owned-dependencies.json');assert owned['status']=='success' and not (repo/'web/node_modules').is_symlink() and owned['lock_sha256']==sha(repo/'web/package-lock.json');assert owned['pyodide_sha256']=={p.name:sha(p) for p in (repo/'web/node_modules/pyodide').iterdir() if p.is_file()}
assert read('python-receipt.json')['exit_code']==0
merged_python=re.search(r'(\d+) passed, 1 skipped, (\d+) warnings in ([\d.]+)s',(r/'complete-python.log').read_text());assert merged_python and int(merged_python[1])>=30879
assert len(read('setup-receipts.json'))==3 and all(x['exit_code']==0 for x in read('setup-receipts.json'))
assert 'PASS preparation handbook: 60 maintained bilingual guides / 180 prompts' in (r/'frontend-check.log').read_text() and 'PASS math security:' in (r/'frontend-check.log').read_text()
builds={}
for name in ('frontend-build-latest.log','pages-profile-build-latest.log'):
 m=re.search(r'PASS initial build graph: (\d+) JS assets, (\d+) bytes raw / (\d+) bytes gzip',(r/name).read_text());assert m,name;builds[name]=dict(js_assets=int(m[1]),raw_bytes=int(m[2]),gzip_bytes=int(m[3]))
for name in ('wasm-driver.log','pages-policy.log'):assert 'PASS ' in (r/name).read_text()
followup=read('followup-receipts.json');assert len(followup)==6 and all(x['exit_code']==0 for x in followup)
report=dict(followup_receipts=followup,frontend_scope='Complete npm check/builds at0ac530d0 including60 guides;later769915be CSS/offline-test/script/docs-only update has four targeted checks and both builds repeated',status='all_local_application_gates_passed',version='0.31.0',source_hashes=actual,core_report='iteration-31.json',context=context,latest_upstream=latest,native_catalog={k:v for k,v in n.items() if k!='mutation'},native_mutants=342,complete_python_passed=int(merged_python[1]),complete_python_optional_skipped=1,complete_python_s=float(merged_python[3]),full_wasm={k:v for k,v in w.items() if k!='results'},exported_independent_contracts=contracts,export=export,runtime_sizes=read('runtime-sizes.json'),distribution=read('distribution-identity.json'),builds=builds,pages_profile=read('pages-profile-latest.json'),owned_dependencies=owned,receipts=dict(python=read('python-receipt.json'),setup=read('setup-receipts.json'),native=read('native-receipt.json'),wasm=read('wasm-receipt.json'),frontend=front,export=read('export-receipts.json')),scope='Complete final hardened core after19-file UI/editor/check/guides/docs/interview-catalog merge,with complete infrastructure rerun. Original problem/library/lockfile inputs unchanged. All original native tests,repeats,mutants and browser budgets retained. Full exported VM also executes31 independent suites1113 checks. Catalog runtimes are budget gates,not comparative timing. No manual UI visual QA.',remaining=['Latest-main revalidation and non-force push','Remote Quality','Eligible actual Pages deployment and live-byte proof'])
(r/'integration-gates.json').write_text(json.dumps(report,indent=2)+'\n')
files=[p for p in r.rglob('*') if p.is_file() and p.suffix in ('.py','.mjs','.json','.log','.whl','.gz','.html') and '__pycache__' not in p.parts]
archive=out/'iteration-31-integration-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
report['archive']=dict(file=archive.name,files=len(files),bytes=archive.stat().st_size,sha256=sha(archive));(out/'iteration-31-integration.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],native_s=n['duration_s'],wasm_ms=w['elapsed_ms'],builds=builds,archive=report['archive']),indent=2))
