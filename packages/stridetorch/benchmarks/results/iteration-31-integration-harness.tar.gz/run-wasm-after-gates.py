from pathlib import Path
import json,os,shutil,subprocess,time
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');deadline=time.monotonic()+900
while True:
 try:n=json.loads((r/'native-receipt.json').read_text());front=json.loads((r/'frontend-receipts.json').read_text())
 except (FileNotFoundError,json.JSONDecodeError):n={};front=[]
 if n.get('exit_code')==0 and len(front)==5 and (r/'native-ci.json').exists() and (r/'python-receipt.json').exists() and (r/'setup-receipts.json').exists():
  assert json.loads((r/'python-receipt.json').read_text())['exit_code']==0
  setup=json.loads((r/'setup-receipts.json').read_text());assert len(setup)==3 and all(x['exit_code']==0 for x in setup)
  assert all(x['exit_code']==0 for x in front),front
  break
 if n.get('exit_code',0)!=0 or any(x['exit_code']!=0 for x in front):raise RuntimeError('Pre-WASM gate failed')
 if time.monotonic()>deadline:raise TimeoutError('Pre-WASM gates did not terminate')
 time.sleep(2)
args=['/opt/homebrew/bin/node','web/scripts/check-browser-wasm.mjs','--all'];start=time.monotonic()
with (r/'full-wasm.log').open('w') as log:p=subprocess.run(args,cwd=repo,env=dict(os.environ,PAPERLEET_WASM_CONCURRENCY='2'),stdout=log,stderr=subprocess.STDOUT)
(r/'wasm-receipt.json').write_text(json.dumps(dict(args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-start,concurrency=2),indent=2)+'\n');p.check_returncode();shutil.copy2(repo/'reports/browser-wasm.json',r/'full-wasm-result.json');print('FULL EXPORTED WASM TERMINAL0',flush=True)
