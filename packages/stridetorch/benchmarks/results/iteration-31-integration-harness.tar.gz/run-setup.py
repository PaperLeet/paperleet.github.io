from pathlib import Path
import json,subprocess,time
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');py=str(r.parent.parent/'torch-iteration-21/stride-dev-env/bin/python');receipts=[]
plans=[([py,str(r/'freeze.py')],'freeze.log',r.parent.parent),(['/Users/david/.local/bin/uv','build',str(repo),'--out-dir',str(r/'dist-paperleet')],'build-private.log',repo),([py,str(r/'verify-private.py')],'distribution-identity.log',repo)]
for args,name,cwd in plans:
 start=time.monotonic()
 with (r/name).open('w') as log:p=subprocess.run(args,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(args=args,log=name,cwd=str(cwd),exit_code=p.returncode,elapsed_s=time.monotonic()-start));(r/'setup-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,'terminal',p.returncode,flush=True);p.check_returncode()
