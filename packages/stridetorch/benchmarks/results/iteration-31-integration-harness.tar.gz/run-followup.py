from pathlib import Path
import json,os,shutil,subprocess,time
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');old='0ac530d0d371863b5c155f34976f6a7151cd9938';upstream='769915be5215c22bcb13bd0518e8406dde6731b7';env={**os.environ,'PATH':'/opt/homebrew/bin:'+os.environ['PATH']};receipts=[]
def save(name,value):(r/name).write_text(json.dumps(value,indent=2)+'\n')
new=subprocess.check_output(['git','diff','--name-only',old,upstream],cwd=repo,text=True).splitlines();assert set(new)=={'docs/validation/diagnostic-control-reading.md','web/package.json','web/scripts/check-hosted-offline-recovery.mjs','web/src/feedback-polish.css','web/src/python-editor.css','web/src/workspace-test-results.css'}
for name in new:assert (repo/name).read_bytes()==subprocess.check_output(['git','show',upstream+':'+name],cwd=repo)
pkg=json.loads((repo/'web/package.json').read_text());before=json.loads(subprocess.check_output(['git','show',old+':web/package.json'],cwd=repo));assert pkg['dependencies']==before['dependencies'] and pkg.get('devDependencies')==before.get('devDependencies')
for name in ('context.json','latest-upstream.json','react-review.json','integration-gates.json'):shutil.copy2(r/name,r/('before-followup-'+name))
context=json.loads((r/'context.json').read_text());context.update(upstream=upstream,merge_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),upstream_files_preserved=subprocess.check_output(['git','diff','--name-only','b1a1631a',upstream],cwd=repo,text=True).splitlines(),followup_scope='Later6-file CSS/offline-check/script/docs-only change;no Python/backend/catalog/lock changes. Complete merged infrastructure already passed30879 before this follow-up.');save('context.json',context);save('latest-upstream.json',context)
review=json.loads((r/'react-review.json').read_text());review['observations'].append('Later follow-up changes only diagnostic/editor CSS and adds hosted-offline assertions to npm check;targeted offline/navigation/workspace/source controls and both builds rerun');review['upstream_files_preserved']=context['upstream_files_preserved'];save('react-review.json',review)
value=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED','--jq','.value'],text=True).strip();profile=json.loads((r/'pages-profile.json').read_text());assert value==profile['observed_value'];save('pages-profile-latest.json',profile)
plans=[(['/opt/homebrew/bin/node','scripts/'+name],'latest-'+name+'.log',{}) for name in ('check-hosted-offline-recovery.mjs','check-python-navigation.mjs','check-workspace-actions.mjs','check-source-locations.mjs')]
plans += [(['npm','run','build'],'frontend-build-latest.log',{}),(['npm','run','build'],'pages-profile-build-latest.log',profile['environment'])]
for args,name,overrides in plans:
 start=time.monotonic()
 with (r/name).open('w') as log:p=subprocess.run(args,cwd=repo/'web',env={**env,**overrides},stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(args=args,log=name,cwd=str(repo/'web'),exit_code=p.returncode,elapsed_s=time.monotonic()-start,environment=overrides));save('followup-receipts.json',receipts);print(name,'terminal',p.returncode,flush=True);p.check_returncode()
