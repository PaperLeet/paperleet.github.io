from pathlib import Path
import argparse,contextlib,json,hashlib
import numpy as np

parser=argparse.ArgumentParser();parser.add_argument('backend',choices=['native','adapter']);args=parser.parse_args()
native=args.backend=='native'
if native:
    import torch
    from torch.nn.attention import sdpa_kernel,SDPBackend
    torch.set_num_threads(2)
else:
    import stridetorch
    from stridetorch import torch

r=Path(__file__).resolve().parent
regular=[[(3,4),(5,4),(5,2)],[(2,3,4),(1,5,4),(2,5,2)],[(2,3,4,5),(1,3,6,5),(2,1,6,7)],[(2,1,3,4,5),(1,2,3,6,5),(2,1,1,6,7)]]
grouped=[[(4,3,4),(2,5,4),(2,5,6)],[(2,6,3,4),(1,2,5,4),(2,3,5,6)],[(2,1,4,3,4),(1,2,1,5,4),(2,1,2,5,6)],[(2,4,3,4),(1,4,5,4),(2,1,5,6)]]
empty=[[(2,4,0,4),(1,2,5,4),(2,2,5,6)],[(2,4,3,4),(1,2,0,4),(2,2,0,6)],[(2,4,3,0),(1,2,5,0),(2,2,5,6)],[(2,4,3,4),(1,2,5,4),(2,2,5,0)]]
cases=[]
for dtype in ['float32','float64']:
    for shapes,gqa in [(s,False) for s in regular]+[(s,True) for s in grouped]:
        for mask in ['none','bool','float','causal']:
            for scale in [None,-.37,0.]:cases.append(dict(shapes=shapes,gqa=gqa,dtype=dtype,mask=mask,scale=scale,p=0.))
    for shapes in empty:cases.append(dict(shapes=shapes,gqa=True,dtype=dtype,mask='none',scale=None,p=0.))
    for gqa,shapes in [(False,regular[2]),(True,grouped[1])]:
        cases.append(dict(shapes=shapes,gqa=gqa,dtype=dtype,mask='bool',scale=None,p=1.))

results={};official={};metadata=[];failures=[];checks=0;masked_mixed_differences=[]
expected=np.load(r/'native-differential.npz') if not native else None
for index,case in enumerate(cases):
    rng=np.random.default_rng(502000+index);dtype=np.dtype(case['dtype']);arrays=[rng.normal(size=s).astype(dtype) for s in case['shapes']]
    mask=None
    if case['mask'] in ('bool','float'):
        keep=rng.random((case['shapes'][0][-2],case['shapes'][1][-2]))>.3
        if keep.shape[0]>1:keep[1]=False
        mask=keep if case['mask']=='bool' else np.where(keep,rng.normal(size=keep.shape),-np.inf).astype(dtype)
        if case['mask']=='float':arrays.append(mask)
    values=[torch.tensor(np.asfortranarray(a),requires_grad=True) for a in arrays]
    directions=[torch.tensor(rng.normal(size=a.shape).astype(dtype),requires_grad=True) for a in arrays]
    def call(*x):
        return torch.nn.functional.scaled_dot_product_attention(*x[:3],attn_mask=x[3] if case['mask']=='float' else (torch.tensor(mask) if mask is not None else None),is_causal=case['mask']=='causal',scale=case['scale'],enable_gqa=case['gqa'],dropout_p=case['p'])
    def stable_call(*x):
        q,k,v=x[:3]
        if case['gqa']:
            k=k.repeat_interleave(q.shape[-3]//k.shape[-3],-3)
            v=v.repeat_interleave(q.shape[-3]//v.shape[-3],-3)
        factor=(1/np.sqrt(q.shape[-1]) if q.shape[-1] else 1.) if case['scale'] is None else case['scale']
        scores=q@k.transpose(-1,-2)*float(factor)
        if case['mask']=='causal':
            keep=torch.arange(k.shape[-2])[None,:]<=torch.arange(q.shape[-2])[:,None]
            scores=scores.masked_fill(~keep,-np.inf)
        m=x[3] if case['mask']=='float' else (torch.tensor(mask) if mask is not None else None)
        if m is not None:scores=scores.masked_fill(~m,-np.inf) if m.dtype==torch.bool else scores+m
        all_masked=torch.isneginf(scores).all(-1,keepdim=True)
        p=torch.softmax(torch.where(all_masked,0.,scores),-1)
        p=torch.where(all_masked,0.,p)
        if case['p']==1:p=p*0
        return p@v
    with (sdpa_kernel(SDPBackend.MATH) if native else contextlib.nullcontext()):
        y=call(*values);seed=torch.tensor(rng.normal(size=y.shape).astype(dtype));grads=torch.autograd.grad(y,values,seed)
        p,t=torch.func.jvp(call,tuple(values),tuple(directions));other=torch.tensor(rng.normal(size=y.shape).astype(dtype))
        mixed=torch.autograd.grad((p*seed+t*other).sum(),[*values,*directions])
    current={'y':y,'p':p,'t':t,**{f'g{i}':g for i,g in enumerate(grads)},**{f'm{i}':g for i,g in enumerate(mixed)}}
    if native:
        official_current=current
        y=stable_call(*values);grads=torch.autograd.grad(y,values,seed)
        p,t=torch.func.jvp(stable_call,tuple(values),tuple(directions))
        mixed=torch.autograd.grad((p*seed+t*other).sum(),[*values,*directions])
        current={'y':y,'p':p,'t':t,**{f'g{i}':g for i,g in enumerate(grads)},**{f'm{i}':g for i,g in enumerate(mixed)}}
        for key,value in official_current.items():
            actual=value.detach().numpy();stable=current[key].detach().numpy();official[f'{index}-{key}']=actual
            if key.startswith('m') and np.isnan(actual).any() and np.isfinite(stable).all():
                np.testing.assert_allclose(actual[np.isfinite(actual)],stable[np.isfinite(actual)],rtol=3e-5 if dtype==np.float32 else 1e-11,atol=2e-5 if dtype==np.float32 else 8e-12)
                masked_mixed_differences.append(dict(case=index,key=key,nan_elements=int(np.isnan(actual).sum()),stable_finite=True))
            else:np.testing.assert_allclose(actual,stable,rtol=3e-5 if dtype==np.float32 else 1e-11,atol=2e-5 if dtype==np.float32 else 8e-12,equal_nan=True)
    for key,value in current.items():
        label=f'{index}-{key}';array=value.detach().numpy() if native else value.numpy()
        if native:results[label]=array
        else:
            try:np.testing.assert_allclose(array,expected[label],rtol=3e-5 if dtype==np.float32 else 1e-11,atol=2e-5 if dtype==np.float32 else 8e-12,equal_nan=True)
            except AssertionError as error:failures.append(dict(case=index,key=key,config=case,error=str(error)[-1000:]))
        checks+=1
    metadata.append(dict(index=index,case=case,shape=list(y.shape),stride=list(y.stride()),dtype=str(y.dtype)))
if native:
    np.savez(r/'native-differential.npz',**results)
    np.savez(r/'official-sdpa-differential.npz',**official)
report=dict(status='success' if not failures else 'failure',backend=args.backend,version=torch.__version__ if native else stridetorch.__version__,cases=len(cases),checks=checks,failures=failures,metadata=metadata,fully_masked_mixed_differences=masked_mixed_differences,oracle='Native compositional math with fully-masked rows zeroed before softmax; official SDPA all finite entries and all values/JVP/VJP also checked')
if not native:
    source=Path(stridetorch.__file__).parent
    report['source_hashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']}
(r/f'{args.backend}-differential.json').write_text(json.dumps(report,indent=2)+'\n')
print(args.backend,report['status'],len(cases),'cases',checks,'arrays',len(failures),'failures')
for row in failures[:4]:print(row)
raise SystemExit(bool(failures))
