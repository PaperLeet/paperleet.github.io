from pathlib import Path
import contextlib,copy,hashlib,json,sys
import numpy as np
native=sys.argv[1]=='native'
if native:
    import torch
    from torch.nn.attention import sdpa_kernel,SDPBackend
    torch.set_num_threads(2)
else:
    import stridetorch
    from stridetorch import torch
r=Path(__file__).resolve().parent;results={};checks=0
class Encoder(torch.nn.Module):
    def __init__(self,dtype):
        super().__init__();self.q=torch.nn.Linear(8,16,dtype=dtype);self.k=torch.nn.Linear(8,4,dtype=dtype);self.v=torch.nn.Linear(8,6,dtype=dtype);self.out=torch.nn.Linear(12,8,dtype=dtype);self.norm=torch.nn.LayerNorm(8,dtype=dtype)
    def forward(self,x):
        b,n=x.shape[:2]
        q=self.q(x).reshape(b,n,4,4).transpose(1,2);k=self.k(x).reshape(b,n,1,4).transpose(1,2);v=self.v(x).reshape(b,n,2,3).transpose(1,2)
        y=torch.nn.functional.scaled_dot_product_attention(q,k,v,enable_gqa=True,is_causal=True)
        return self.norm(x+self.out(y.transpose(1,2).reshape(b,n,12)))
expected=None if native else np.load(r/'native-training.npz')
for dtype in ['float32','float64']:
    rng=np.random.default_rng(5017);model=Encoder(getattr(torch,dtype))
    with torch.no_grad():
        for name,p in model.named_parameters():
            raw=(rng.normal(size=p.shape)*.1+(1. if name=='norm.weight' else 0.)).astype(dtype);p[:]=torch.tensor(raw)
    opt=torch.optim.SGD(model.parameters(),lr=.01,momentum=.7)
    x=torch.tensor(rng.normal(size=(2,3,8)).astype(dtype),requires_grad=True);dx=torch.tensor(rng.normal(size=x.shape).astype(dtype),requires_grad=True)
    for step in range(4):
        opt.zero_grad();x.grad=dx.grad=None
        with (sdpa_kernel(SDPBackend.MATH) if native else contextlib.nullcontext()):
            p,t=torch.func.jvp(model,(x,),(dx,));loss=p.square().mean()+.03*t.square().mean();loss.backward()
        values={'p':p,'t':t,'loss':loss,'dx':x.grad,'dtangent':dx.grad,**{name+'.grad':p.grad for name,p in model.named_parameters()}}
        opt.step();values.update(dict(model.named_parameters()))
        for name,value in values.items():
            key=f'{dtype}-{step}-{name}';actual=value.detach().numpy() if native else value.numpy()
            if native:results[key]=actual.copy()
            else:np.testing.assert_allclose(actual,expected[key],rtol=5e-5 if dtype=='float32' else 2e-11,atol=4e-6 if dtype=='float32' else 2e-12)
            checks+=1
        if step==1:
            checkpoint=copy.deepcopy(dict(model=model.state_dict(),optimizer=opt.state_dict()));model=Encoder(getattr(torch,dtype));model.load_state_dict(checkpoint['model']);opt=torch.optim.SGD(model.parameters(),lr=.01,momentum=.7);opt.load_state_dict(checkpoint['optimizer'])
if native:np.savez(r/'native-training.npz',**results)
report=dict(status='success',backend='native' if native else 'adapter',checks=checks,steps_per_dtype=4,dtypes=['float32','float64'],scope='GQA causal encoder with LayerNorm,residual,linear layers; loss depends on primal and JVP. All parameter/input/direction gradients,updated weights and checkpoint+momentum continuation compared against native math SDPA.')
if not native:
    source=Path(stridetorch.__file__).parent;report['source_hashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']}
(r/('native-training.json' if native else 'adapter-training.json')).write_text(json.dumps(report,indent=2)+'\n');print(report['backend'],'training PASS',checks,'arrays')
