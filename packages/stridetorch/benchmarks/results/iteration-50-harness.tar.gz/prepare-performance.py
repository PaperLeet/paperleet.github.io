from pathlib import Path
import shutil,json,hashlib
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-49';repo=Path('/Users/david/Developer/PaperLeet-torch-release');chrome=r/'proof/chrome-contracts'
def hashes(d):return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.iterdir() if p.is_file() and (p.suffix=='.py' or p.name in ['LICENSE','NOTICE'])}
assert (r/'bench_attention.py').read_bytes()==(repo/'packages/stridetorch/benchmarks/bench_attention.py').read_bytes()
shutil.copy2(r/'bench_attention.py',chrome/'bench.py');(chrome/'baseline').mkdir(exist_ok=True)
for p in (r/'baseline-source/stridetorch').iterdir():
    if p.is_file():shutil.copy2(p,chrome/'baseline'/p.name)
plan=dict(source=hashes(r/'proof/source'),baseline=hashes(r/'baseline-source/stridetorch'),benchmark_sha256=hashlib.sha256((r/'bench_attention.py').read_bytes()).hexdigest())
assert len(plan['source'])==55 and len(plan['baseline'])==54
(chrome/'bench-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(r/'baseline.json').write_text(json.dumps(dict(commit='7b5e8f78886a64d00caf831ae53d53cf26346be2',version='0.49.0',source=plan['baseline']),indent=2)+'\n')
shutil.copy2(old/'proof/chrome-contracts/bench-worker.mjs',chrome/'bench-worker.mjs')
for name in ['bench-wasm.mjs','bench-chrome.mjs']:
    s=(old/name).read_text().replace('torch-iteration-49','torch-iteration-50').replace('bench_convolution_padding.py','bench_attention.py');(r/name).write_text(s)
print('Prepared55/54 source identities and22-flow benchmark')
