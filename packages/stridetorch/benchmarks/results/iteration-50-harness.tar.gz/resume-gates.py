from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,subprocess,time,os,hashlib
r=Path(__file__).resolve().parent;p=r/'proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release');py=r.parent/'torch-iteration-21/stride-dev-env/bin/python'
receipts=json.loads((p/'gate-receipts.json').read_text())
assert set(receipts)=={'build-public','build-private','node-wasm','chrome-worker'}
assert receipts['chrome-worker']['exit_code']==1 and all(receipts[n]['exit_code']==0 for n in ['build-public','build-private','node-wasm'])
assert 'ERR_CONNECTION_REFUSED' in (p/'chrome-worker.log').read_text()
for name,digest in json.loads((p/'source-hashes.json').read_text()).items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==digest
(p/'chrome-worker.log').rename(p/'chrome-worker-fixture-unavailable.log')
(p/'failed-gate-attempts.json').write_text(json.dumps([dict(name='chrome-worker',receipt=receipts['chrome-worker'],log='chrome-worker-fixture-unavailable.log',cause='HTTP fixture server not listening; no Python tests executed')],indent=2)+'\n')
env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
def run(name,args):
    start=time.monotonic()
    with (p/(name+'.log')).open('w') as log:child=subprocess.run([str(x) for x in args],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
    return name,dict(exit_code=child.returncode,elapsed_s=time.monotonic()-start,args=[str(x) for x in args],cwd=str(repo))
plans={'chrome-worker':['/opt/homebrew/bin/node',p/'chrome-contracts/run.mjs'],'minimal-wheel':[py,p/'check-wheel.py'],'coinstall':[py,p/'check-coinstall.py']}
with ThreadPoolExecutor(max_workers=3) as pool:
    for future in as_completed([pool.submit(run,name,args) for name,args in plans.items()]):
        name,receipt=future.result();receipts[name]=receipt;(p/'gate-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print('TERMINAL',name,receipt['exit_code'],round(receipt['elapsed_s'],2),flush=True)
assert len(receipts)==6 and all(v['exit_code']==0 for v in receipts.values()),receipts
print('ALL6 GATES PASS',flush=True)
