from pathlib import Path
import hashlib,json,os,statistics,subprocess,time
r=Path(__file__).resolve().parent;out=r/'performance';out.mkdir(exist_ok=True);py=r.parent/'torch-iteration-21/stride-dev-env/bin/python'
def read(name):return json.loads((r/name).read_text())
source=read('proof/source-hashes.json');baseline=read('baseline.json')['source'];receipts={}
assert read('full-root-receipt.json')['exit_code']==0 and read('integration-proof/wasm-receipt.json')['exit_code']==0
assert read('adapter-differential.json')['status']=='success'
for name in ['proof/source-wasm.json','proof/chrome-contracts/result.json']:assert read(name)['source_hashes']==source
env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');load_before=os.getloadavg();bench_sha=hashlib.sha256((r/'bench_attention.py').read_bytes()).hexdigest()
for repeat in range(4):
    for runtime in (('cpu','node','chrome') if repeat%2==0 else ('chrome','node','cpu')):
        name=f'{runtime}-{repeat}';output=out/(name+'.json');reverse=['--reverse'] if repeat%2 else []
        args=([str(py),str(r/'bench_attention.py'),'--baseline-source',str(r/'baseline-source/stridetorch'),'--candidate-source',str(r/'proof/source'),'--output',str(output)] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(r/('bench-wasm.mjs' if runtime=='node' else 'bench-chrome.mjs')),str(output)])+reverse
        start=time.monotonic()
        with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
        receipts[name]=dict(args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-start);(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode()
        j=json.loads(output.read_text());assert j['status']=='success' and j['candidate_version']=='0.50.0' and j['baseline_version']=='0.49.0' and len(j['flows'])==22 and j['source_hashes']==dict(baseline=baseline,candidate=source)
        print(name,'PASS22',round(receipts[name]['elapsed_s'],2),flush=True)
summary={}
for runtime in ['cpu','node','chrome']:
    reports=[read(f'performance/{runtime}-{i}.json') for i in range(4)];rows=[]
    for case in range(22):
        first=reports[0]['flows'][case];row={k:first[k] for k in ['kind','dtype','mode']};times={name:[j['flows'][case]['median_s'][name] for j in reports] for name in first['median_s']};medians={name:statistics.median(v) for name,v in times.items()}
        row.update(median_s=medians,all_child_median_s=times,time_reduction_percent=100*(1-medians['candidate']/medians['baseline']),repeated_control_time_reduction_percent=100*(1-medians['candidate']/medians['repeated_control']));rows.append(row)
    summary[runtime]=rows
assert bench_sha==hashlib.sha256((r/'bench_attention.py').read_bytes()).hexdigest()
(r/'performance-summary.json').write_text(json.dumps(dict(status='success',children=len(receipts),all_children_terminal=True,summary=summary,receipts=receipts,source_hashes=dict(baseline=baseline,candidate=source),benchmark_sha256=bench_sha,load_before=load_before,load_after=os.getloadavg(),scope='0.49 vs0.50 actual-library comparison. Old GQA workloads retain singleton-head broadcasting and repeat only necessary non-singleton K/V heads; candidate uses grouped contractions. Same-source repeated control retained.4fresh processes per CPU/Node/Chrome,5samples/8calls,alternating runtime/method order.22flows verify values/all VJPs and3encoder SGD updates before timing. Not native Torch,GPU,peak RSS,FlashAttention or universal speed evidence.'),indent=2)+'\n')
