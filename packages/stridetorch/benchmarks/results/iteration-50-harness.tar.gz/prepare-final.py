from pathlib import Path
import json,hashlib,shutil,subprocess
r=Path(__file__).resolve().parent;old=r.parent/'torch-iteration-49';repo=Path('/Users/david/Developer/PaperLeet-torch-release');p=r/'proof';p.mkdir(exist_ok=True);chrome=p/'chrome-contracts';chrome.mkdir(exist_ok=True)
def save(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n')
def hashes(folder):return {f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in folder.iterdir() if f.is_file()}
for dest in [p/'source',chrome/'source']:
    dest.mkdir(exist_ok=True)
    for f in (repo/'packages/stridetorch/src/stridetorch').iterdir():
        if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']:shutil.copy2(f,dest/f.name)
source=hashes(p/'source');assert len(source)==55;save(p/'source-hashes.json',source)
tests=chrome/'tests';tests.mkdir(exist_ok=True)
for f in (repo/'packages/stridetorch/tests').glob('test_*.py'):
    if f.name!='test_standalone.py':shutil.copy2(f,tests/f.name)
assert len(hashes(tests))==47
save(chrome/'plan.json',dict(version='0.50.0',expected=6053,source=source,tests=hashes(tests)))
def adapt(text):return text.replace('torch-iteration-49','torch-iteration-50').replace('0.49.0','0.50.0').replace('stride049','stride050')
for name in ['run.mjs','worker.mjs','index.html']:(chrome/name).write_text(adapt((old/'proof/chrome-contracts'/name).read_text()))
for name in ['wasm-contracts.mjs','check-wheel.py','check-coinstall.py']:
    s=adapt((old/'proof'/name).read_text())
    if name=='wasm-contracts.mjs':s=s.replace("'nn_workflows'","'nn_workflows','attention'").replace('5892','6053')
    if name=='check-wheel.py':s=s.replace('len(names)==52','len(names)==53').replace('package_modules=52','package_modules=53')
    if name=='check-coinstall.py':
        extra='''\nfor name in NAMES:
 t=importlib.import_module(name).torch
 q=t.ones(1,6,3,4,dtype=t.float64,requires_grad=True);k=t.ones(1,2,5,4,dtype=t.float64,requires_grad=True);v=t.ones(1,3,5,2,dtype=t.float64,requires_grad=True)
 y,j=t.func.jvp(lambda a,b,c:t.nn.functional.scaled_dot_product_attention(a,b,c,enable_gqa=True),(q,k,v),(t.ones_like(q),t.ones_like(k),t.ones_like(v)))
 np.testing.assert_allclose(y.numpy(),1.);np.testing.assert_allclose(j.numpy(),1.);(y+j).sum().backward();assert np.isfinite(q.grad.numpy()).all()
'''
        anchor="print('PASS isolated ownership,aliases,ZIP resume,triangular,Cholesky and Cholesky solve VJP/JVP/full tangent reverse')"
        assert s.count(anchor)==1;s=s.replace(anchor,extra+'\n'+anchor)
    (p/name).write_text(s)
for name in ['run-full.py','run-gates.py','run-setup-final.py']:(r/name).write_text(adapt((old/name).read_text()))
i=r/'integration-proof';i.mkdir(exist_ok=True)
for name in ['run-setup.py','run-export.py','freeze.py','verify-private.py','verify-export.py','run-native.py','run-frontend.py','run-wasm.py']:
    s=adapt((old/'integration-proof'/name).read_text())
    if name=='freeze.py':s=s.replace('len(tests)==46','len(tests)==47').replace('5892','6053').replace('expected_suites=46','expected_suites=47')
    if name=='verify-export.py':s=s.replace('10703','10861')
    if name=='verify-private.py':s=s.replace('core_modules=52','core_modules=53').replace('all_54_core_license_hashes_identical','all_55_core_license_hashes_identical')
    if name=='run-wasm.py':s=s.replace('5892','6053').replace('==46','==47')
    (i/name).write_text(s)
upstream=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
save(i/'context.json',dict(upstream=upstream,version='0.50.0',source_hashes=source))
shutil.copy2(repo/'packages/stridetorch/benchmarks/bench_attention.py',r/'bench_attention.py')
print(dict(resources=len(source),suites=47,contracts=6053,upstream=upstream))
