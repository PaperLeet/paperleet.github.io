"""Evidence for the next numerical-kernel iteration, outside 0.50 parity scope."""
from pathlib import Path
import argparse,contextlib,json,sys
import numpy as np
p=argparse.ArgumentParser();p.add_argument('backend',choices=['native','baseline','candidate','prototype']);a=p.parse_args();r=Path(__file__).resolve().parent
if a.backend=='native':
    import torch
    from torch.nn.attention import sdpa_kernel,SDPBackend
else:
    sys.path.insert(0,str(r/'baseline-source') if a.backend=='baseline' else str(r/'scaling-prototype') if a.backend=='prototype' else '/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/src')
    from stridetorch import torch
rows=[]
for value in [1e18,1e19]:
    for scale in [None,.5,-.5]:
        q=np.full((1,2,4),value,np.float32);k=np.full((1,3,4),value,np.float32);v=np.arange(6,dtype=np.float32).reshape(1,3,2)
        with (sdpa_kernel(SDPBackend.MATH) if a.backend=='native' else contextlib.nullcontext()):
            y=torch.nn.functional.scaled_dot_product_attention(torch.tensor(q),torch.tensor(k),torch.tensor(v),scale=scale)
        result=y.detach().numpy() if a.backend=='native' else y.numpy()
        rows.append(dict(value=value,scale=scale,finite=bool(np.isfinite(result).all()),output=result.tolist() if np.isfinite(result).all() else 'nonfinite'))
(r/f'next-scaling-{a.backend}.json').write_text(json.dumps(dict(backend=a.backend,rows=rows),indent=2)+'\n');print(a.backend,[(x['value'],x['scale'],x['finite']) for x in rows])
