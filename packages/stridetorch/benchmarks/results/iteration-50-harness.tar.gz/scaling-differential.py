from pathlib import Path
import contextlib,hashlib,json,sys
import numpy as np
native=sys.argv[1]=='native'
if native:
 import torch
 from torch.nn.attention import sdpa_kernel,SDPBackend
else:
 import stridetorch
 from stridetorch import torch
r=Path(__file__).resolve().parent;results={};checks=0;cases=0;expected=None if native else np.load(r/'native-scaling.npz')
for dtype,magnitudes in [('float32',[1e18,1e19]),('float64',[1e153,7e153])]:
 for magnitude in magnitudes:
  for scale in [None,.5,-.5,0.]:
   for constant in [False,True]:
    arrays=[np.full((1,2,4),magnitude,dtype=dtype),np.full((1,3,4),magnitude,dtype=dtype),np.ones((1,3,2),dtype=dtype) if constant else np.arange(6,dtype=dtype).reshape(1,3,2)]
    values=[torch.tensor(a,requires_grad=True) for a in arrays]
    def fn(*x):return torch.nn.functional.scaled_dot_product_attention(*x,scale=scale)
    with (sdpa_kernel(SDPBackend.MATH) if native else contextlib.nullcontext()):
     y=fn(*values);current={'y':y}
     if constant:
      g=torch.autograd.grad(y.sum(),values)
      directions=[torch.zeros_like(values[0]).requires_grad_(),torch.zeros_like(values[1]).requires_grad_(),torch.ones_like(values[2]).requires_grad_()]
      p,t=torch.func.jvp(fn,tuple(values),tuple(directions));mixed=torch.autograd.grad((p+t).sum(),[*values,*directions]);current.update(p=p,t=t,**{f'g{i}':x for i,x in enumerate(g)},**{f'm{i}':x for i,x in enumerate(mixed)})
    for key,value in current.items():
     label=f'{cases}-{key}';actual=value.detach().numpy() if native else value.numpy();assert np.isfinite(actual).all(),(dtype,magnitude,scale,key)
     if native:results[label]=actual
     else:np.testing.assert_allclose(actual,expected[label],rtol=3e-6 if dtype=='float32' else 2e-12,atol=2e-6 if dtype=='float32' else 1e-12)
     checks+=1
    cases+=1
if native:np.savez(r/'native-scaling.npz',**results)
report=dict(status='success',backend='native' if native else 'adapter',cases=cases,checks=checks,scope='Selected extreme finite Q/K values with prescaling;32 configurations compare output, plus constant-V VJP/JVP/mixed paths. This is not universal extreme-logit stability.')
if not native:
 source=Path(stridetorch.__file__).parent;report['source_hashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']}
(r/('native-scaling.json' if native else 'adapter-scaling.json')).write_text(json.dumps(report,indent=2)+'\n');print(report['backend'],'scaling',cases,'cases',checks,'arrays PASS')
