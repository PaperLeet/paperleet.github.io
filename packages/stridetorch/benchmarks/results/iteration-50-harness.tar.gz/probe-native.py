from pathlib import Path
import json, math
import torch
from torch.nn.attention import sdpa_kernel, SDPBackend

rows=[]
def probe(name,shapes,options=None):
    options={} if options is None else options
    try:
        x=[torch.randn(s,dtype=torch.float64,requires_grad=True) for s in shapes]
        with sdpa_kernel(SDPBackend.MATH):
            y=torch.nn.functional.scaled_dot_product_attention(*x,**options)
            grads=torch.autograd.grad(y.sum(),x)
        rows.append(dict(name=name,shapes=shapes,status='success',shape=list(y.shape),stride=list(y.stride()),finite=bool(y.isfinite().all()),zero=bool((y==0).all()),gradient_finite=[bool(g.isfinite().all()) for g in grads]))
    except Exception as error:
        rows.append(dict(name=name,shapes=shapes,status=type(error).__name__,error=str(error)[:400]))

for heads in [(4,2,2),(6,2,3),(4,1,2),(4,2,1),(4,4,4),(4,3,3),(0,1,1),(4,0,0)]:
    probe('gqa-'+str(heads),[(2,heads[0],3,4),(1,heads[1],5,4),(2,heads[2],5,6)],dict(enable_gqa=True))
for shapes in [[(3,4),(5,4),(5,6)],[(3,4),(2,5,4),(2,5,6)],[(2,4,3,4),(2,2,5,4),(2,2,5,6)],[(2,4,3,0),(2,2,5,0),(2,2,5,6)],[(2,4,0,4),(2,2,5,4),(2,2,5,6)],[(2,4,3,4),(2,2,0,4),(2,2,0,6)]]:
    probe('gqa-ranks-empty',shapes,dict(enable_gqa=True))
base=[(2,2,3,4),(2,2,5,4),(2,2,5,6)]
for value in [-.1,0.,.25,1.,1.1,float('nan')]:probe('dropout-'+str(value),base,dict(dropout_p=value))
for causal in [False,True]:
    for kind,mask in [('bool',torch.zeros(3,5,dtype=torch.bool)),('float32',torch.zeros(3,5,dtype=torch.float32)),('float64',torch.full((3,5),-math.inf,dtype=torch.float64))]:
        probe(f'mask-{kind}-causal-{causal}',base,dict(attn_mask=mask,is_causal=causal))
for scale in [0.,-1.,float('inf'),float('nan')]:probe('scale-'+str(scale),base,dict(scale=scale))
out=dict(torch=torch.__version__,backend='math',rows=rows)
Path(__file__).with_name('native-semantics-probe.json').write_text(json.dumps(out,indent=2)+'\n')
for row in rows:print(row['name'],row['status'],row.get('shape',row.get('error')),row.get('gradient_finite',''))
