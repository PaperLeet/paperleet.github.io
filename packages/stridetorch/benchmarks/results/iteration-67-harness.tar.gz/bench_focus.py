"""Three-way inverse-JVP timing: frozen 0.66 and two isolated memory candidates."""
import gc,hashlib,json,statistics,time
from pathlib import Path
import numpy as np
import bench_inverse as common


def operation(module,data,direction,target):
    t=module.torch;a=t.tensor(data,requires_grad=True);e=t.tensor(direction,requires_grad=True);weight=t.tensor(np.full(data.shape,.7,dtype=data.dtype))
    def call():
        a.grad=e.grad=None;p,v=t.func.jvp(t.linalg.inv,(a,),(e,));loss=(v*weight).sum()
        if target=='both':
            loss.backward();return p,v,a.grad,e.grad
        gradient=t.autograd.grad(loss,a if target=='a' else e)[0]
        return p,v,gradient
    return call


def run(baseline,combined,scheduled):
    sources=dict(baseline=baseline,combined=combined,scheduled=scheduled);modules={};hashes={}
    for label,path in sources.items():modules[label],hashes[label]=common.common.load('_focused_'+label,path)
    orders=[['baseline','combined','scheduled'],['combined','scheduled','baseline'],['scheduled','baseline','combined'],['scheduled','combined','baseline'],['baseline','scheduled','combined'],['combined','baseline','scheduled']]
    rows=[]
    for dtype in ['float32','float64']:
        for shape in [(1,1),(2,2),(64,64),(4,32,32)]:
            for target in ['both'] if shape[-1]<32 else ['both','a','e']:
                data=common.common._data(shape,dtype);direction=(np.eye(shape[-1])*.2+np.sin(np.arange(data.size).reshape(shape)*.17)*.01).astype(dtype)
                functions={label:operation(module,data,direction,target) for label,module in modules.items()}
                wanted=[v.numpy().copy() for v in functions['baseline']()]
                for label in ['combined','scheduled']:common.compare([v.numpy().copy() for v in functions[label]()],wanted,dtype,2)
                del wanted;gc.collect();calls=1;calibration={}
                for label,fn in functions.items():
                    batch=1
                    while True:
                        started=time.perf_counter()
                        for _ in range(batch):fn()
                        elapsed=time.perf_counter()-started
                        if elapsed>=.02:break
                        if batch>=1_048_576:raise RuntimeError('Insufficient timer resolution')
                        batch*=2
                    calls=max(calls,batch);calibration[label]=dict(calls=batch,elapsed_s=elapsed)
                samples={label:[] for label in functions}
                for order in orders:
                    for label in order:
                        started=time.perf_counter()
                        for _ in range(calls):functions[label]()
                        samples[label].append((time.perf_counter()-started)/calls)
                medians={label:statistics.median(values) for label,values in samples.items()}
                rows.append(dict(dtype=dtype,input_shape=list(shape),target=target,calls=calls,calibration=calibration,samples_s=samples,median_s=medians,ratios={label:medians[label]/medians['baseline'] for label in ['combined','scheduled']}))
    assert len(rows)==16
    return dict(source_hashes=hashes,program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows,orders=orders,scope='16 actual inverse-JVP weighted full-step/partial-target workflows versus frozen validated 0.66. Three source variants, common calibrated batches >=20ms, six balanced variant permutations, values and gradients checked. Inputs/seeds predate timing; graphs/kernels/backward/clearing/destruction are timed. Candidates still report 0.66.0 and are not repository integrations; no universal speedup claim.')


if __name__=='__main__':
    import sys
    print(json.dumps(run(*sys.argv[1:4]),indent=2))
