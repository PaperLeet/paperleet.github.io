from pathlib import Path
import json,subprocess,os,hashlib,time
r=Path(__file__).resolve().parent;origin=Path('/Users/david/Developer/PaperLeet-torch-release');repo=r/'integration-snapshot';python=str(r.parent/'torch-iteration-21/stride-dev-env/bin/python');proof=r/'integration-proof';proof.mkdir(exist_ok=True);env=dict(os.environ,PYTHONPATH=os.pathsep.join([str(repo/'packages/stridetorch/src'),str(repo)]),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z','--','web/public/data/browser-judge','web/public/data/modules'],cwd=origin).decode().split('\0');paths=[v for v in paths if v];baseline={name:sha(origin/name) for name in paths};assert len(baseline)==13547,len(baseline);(proof/'baseline-export-sha256.json').write_text(json.dumps(baseline,indent=2)+'\n');receipts=[]
for label,args in [('export',[str(Path(python).parent/'paperleet'),'export']),('vizdata',[str(Path(python).parent/'paperleet'),'vizdata','all'])]:
 started=time.time()
 with (proof/(label+'.log')).open('w') as log:subprocess.run(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 receipts.append(dict(name=label,status='success',seconds=time.time()-started));(proof/'export-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(label,'PASS',flush=True)
for name,digest in baseline.items():assert sha(repo/name)==digest and sha(origin/name)==digest,name
code="""
from pathlib import Path
import json,hashlib,stridetorch,paperleet
from stridetorch import runtime
repo=Path.cwd();assert Path(paperleet.__file__).resolve().parent==repo/'paperleet';source=repo/'packages/stridetorch/src/stridetorch';assert Path(stridetorch.__file__).resolve().parent==source
r=repo.parent;proof=r/'integration-proof';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();expected=json.loads((r/'lean-proof/inverse-expected-source.json').read_text());actual={p.name:sha(p) for p in source.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']};assert actual==expected
baseline=json.loads((proof/'baseline-export-sha256.json').read_text());data=repo/'web/public/data';active=set();runtimes={}
def read(relative):
 p=data/relative;raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()[:20] in p.name,relative;active.add(relative);return json.loads(raw)
index=json.loads((data/'index.json').read_text())
for entry in index['problems']:
 read(entry['detail_url']);manifest=read(entry['browser_judge']['bundle_url']);assert manifest['problem']==entry['id'];relative=manifest['runtime_bundle_url'];payload=read(relative);profile='autograd' if payload['backend']=='numpy-autograd-wasm' else 'schedules';files=runtime.source_files(profile);assert all(payload['files'].get(name)==value for name,value in files.items()),entry['id'];runtimes[relative]=dict(backend=payload['backend'],package_files=len(files),sha256=sha(data/relative))
all_paths={str(p.relative_to(repo)) for folder in ['browser-judge','modules'] for p in (data/folder).glob('*.json')};new=all_paths-set(baseline);unreachable=[name for name in new if str(Path(name).relative_to('web/public/data')) not in active];assert not unreachable,unreachable
new_shas={name:sha(repo/name) for name in new};report=dict(status='success',snapshot=str(repo),source_hashes=actual,preserved_assets=len(baseline),catalog_modules=len(index['problems']),active_assets=len(active),new_assets=len(new),new_assets_all_reachable=True,runtimes=runtimes);(proof/'export-identity.json').write_text(json.dumps(report,indent=2)+'\n');(proof/'new-export-sha256.json').write_text(json.dumps(new_shas,indent=2)+'\n');print('Verified',report['catalog_modules'],'catalog modules;',len(baseline),'prior immutable assets preserved;',len(new),'new assets')
"""
subprocess.run([python,'-c',code],cwd=repo,env=env,check=True)
