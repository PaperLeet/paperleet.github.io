
from pathlib import Path
import json,hashlib,stridetorch,paperleet
from stridetorch import runtime
repo=Path.cwd();assert Path(paperleet.__file__).resolve().parent==repo/'paperleet';source=repo/'packages/stridetorch/src/stridetorch';assert Path(stridetorch.__file__).resolve().parent==source
r=repo.parent;proof=r/'integration-proof';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();expected=json.loads((r/'lean-proof/inverse-expected-source.json').read_text());actual={p.name:sha(p) for p in source.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']};assert actual==expected
baseline=json.loads((proof/'baseline-export-sha256.json').read_text());data=repo/'web/public/data';active=set();runtimes={}
def read(relative):
 p=data/relative;raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()[:20] in p.name,relative;active.add(relative);return json.loads(raw)
index=json.loads((data/'index.json').read_text())
for entry in index['problems']:
 read(entry['detail_url']);manifest=read(entry['browser_judge']['bundle_url']);assert manifest['problem']==entry['id'];relative=manifest['runtime_bundle_url'];payload=read(relative);profile='autograd' if payload['backend']=='numpy-autograd-wasm' else 'schedules';files=runtime.source_files(profile);assert all(payload['files'].get(name)==value for name,value in files.items()),entry['id'];runtimes[relative]=dict(backend=payload['backend'],package_files=len(files),sha256=sha(data/relative))
all_paths={str(p.relative_to(repo)) for folder in ['browser-judge','modules'] for p in (data/folder).glob('*.json')};new=all_paths-set(baseline);unreachable=[name for name in new if str(Path(name).relative_to('web/public/data')) not in active];assert not unreachable,unreachable
new_shas={name:sha(repo/name) for name in new};report=dict(status='success',snapshot=str(repo),source_hashes=actual,preserved_assets=len(baseline),catalog_modules=len(index['problems']),active_assets=len(active),new_assets=len(new),new_assets_all_reachable=True,runtimes=runtimes);(proof/'export-identity.json').write_text(json.dumps(report,indent=2)+'
');(proof/'new-export-sha256.json').write_text(json.dumps(new_shas,indent=2)+'
');print('Verified',report['catalog_modules'],'catalog modules;',len(baseline),'prior immutable assets preserved;',len(new),'new assets')
