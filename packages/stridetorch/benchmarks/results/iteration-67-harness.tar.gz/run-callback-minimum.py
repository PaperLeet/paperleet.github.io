from pathlib import Path
import subprocess,os,json,time,hashlib
r=Path(__file__).resolve().parent;p=r/'callback-minimum';python=str(r/'minimum-env/bin/python')
env=dict(os.environ,PYTHONPATH='' ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
receipts=[]
def run(name,args,cwd=p):
 started=time.time()
 with (p/(name+'.log')).open('w') as log:subprocess.run(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 receipts.append(dict(name=name,status='success',seconds=time.time()-started));(p/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,'PASS',flush=True)
run('build',['/Users/david/.local/bin/uv','build','--wheel','--no-build-isolation','--python',str(r.parent/'torch-iteration-21/stride-dev-env/bin/python'),'--out-dir',str(r/'callback-experimental-dist'),str(r/'callback-package')])
wheel=next((r/'callback-experimental-dist').glob('*.whl'));run('install',['/Users/david/.local/bin/uv','pip','install','--python',python,'--no-deps','--reinstall',str(wheel)])
code="import stridetorch,numpy,pathlib,hashlib,json,importlib.util;source=pathlib.Path(stridetorch.__file__).parent;actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']};expected=json.loads(pathlib.Path('inverse-expected-source.json').read_text());assert actual==expected and len(actual)==61;assert numpy.__version__=='1.26.4';assert importlib.util.find_spec('torch') is None;print(source,numpy.__version__)"
run('installed-source',[python,'-c',code])
run('sdk',[python,'-m','pytest','-q',str(r/'callback-package/tests'),'--noconftest','-p','no:cacheprovider','--import-mode=importlib'])
for file in ['differential-inverse.py','probe-inverse-mutation-layouts.py','probe-matmul-guards.py','probe-inverse-api.py']:
 code="import stridetorch._linalg as l;l._INVERSE_JVP_SHARED=True;import sys,runpy;sys.argv=['"+file+"','adapter'];runpy.run_path('"+file+"',run_name='__main__')"
 run(file,[python,'-c',code])
run('qualify-inverse',[python,'qualify-inverse.py'])
run('targets',[python,'probe-inverse-targets.py','adapter','callback','--shared'])
run('qualify-targets',[python,'qualify-inverse-targets.py','callback'])
expected=json.loads((p/'inverse-expected-source.json').read_text());actual={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (r/'callback-source/stridetorch').iterdir() if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']};assert actual==expected
print('ALL CALLBACK CPU QUALIFICATION PASS',flush=True)
