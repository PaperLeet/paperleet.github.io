from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

proof = Path(__file__).resolve().parent
repo = proof.parent / "integration-snapshot"
python = str(proof.parent.parent / "torch-iteration-21/stride-dev-env/bin/python")
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
env = dict(os.environ, PYTHONPATH=os.pathsep.join([
    str(repo / "packages/stridetorch/src"), str(repo)]),
    OMP_NUM_THREADS="2", MKL_NUM_THREADS="2", OPENBLAS_NUM_THREADS="2",
    VECLIB_MAXIMUM_THREADS="2", PAPERLEET_WASM_CONCURRENCY="1")
modules = json.loads((proof / "upstream-stage.json").read_text())["new_modules"]
assert len(modules) == 4

def write(name, value):
    (proof / name).write_text(json.dumps(value, indent=2) + "\n")

def run(label, args, cwd=repo):
    start = time.time()
    with (proof / (label + ".log")).open("w") as out:
        result = subprocess.run(args, cwd=cwd, env=env, stdout=out,
                                stderr=subprocess.STDOUT)
    receipt = dict(exit_code=result.returncode, seconds=time.time()-start,
                   args=args, log_sha256=sha(proof / (label + ".log")))
    write(label + "-receipt.json", receipt)
    print(label, result.returncode, round(receipt["seconds"], 2), flush=True)
    assert result.returncode == 0, label

if sys.argv[1] == "prepare":
    data = repo / "web/public/data"
    index = json.loads((data / "index.json").read_text())
    assert len(index["problems"]) == 82
    active = set()
    for entry in index["problems"]:
        active.add(entry["detail_url"])
        active.add(entry["browser_judge"]["bundle_url"])
        bundle = json.loads((data / entry["browser_judge"]["bundle_url"]).read_text())
        active.add(bundle["runtime_bundle_url"])
    previous = json.loads((proof / "phase78-prototype-sha256.json").read_text())
    baseline = json.loads((proof / "baseline-export-sha256.json").read_text())
    removals = []
    for name, digest in previous.items():
        relative = str(Path(name).relative_to("web/public/data"))
        if relative not in active:
            path = repo / name
            backup = proof / "phase78/prototype-assets" / path.name
            assert name not in baseline and sha(path) == sha(backup) == digest
            removals.append(dict(path=name, sha256=digest, preserved_copy=str(backup)))
    write("superseded-prototype-cleanup.json", removals)
    for item in removals:
        (repo / item["path"]).unlink()
    # The prior verifier wrote a literal backslash-n terminator. Correct this
    # driver only; keep the original phase-78 evidence unchanged.
    verifier = proof / "verify-export.py"
    text = verifier.read_text().replace(r"'\\n'", r"'\n'")
    verifier.write_text(text)
    run("verify-export", [python, str(verifier)])
    write("new-module-source-sha256.json", {
        str(path.relative_to(repo)): sha(path)
        for identifier in modules
        for path in (repo / "problems" / identifier).rglob("*")
        if path.is_file() and "__pycache__" not in path.parts
    })
elif sys.argv[1] == "native":
    args = [str(Path(python).parent / "paperleet"), "ci", "--repeats", "3", "--budget", "180"]
    for identifier in modules:
        args.extend(["--problem", identifier])
    run("native-new-four", args)
    report = json.loads((repo / "reports/ci.json").read_text())
    assert report["passed"] and report["problems"] == 4 and report["repeats"] == 3
    assert sum(map(len, report["mutation"].values())) == 17
    write("native-new-four-report.json", report)
elif sys.argv[1] == "wasm":
    results = []
    for identifier in modules:
        label = "wasm-" + identifier.replace("/", "-")
        run(label, ["/opt/homebrew/bin/node", "scripts/check-browser-wasm.mjs",
                    identifier, "--json"], repo / "web")
        result = json.loads((proof / (label + ".log")).read_text())
        assert result["id"] == identifier and not result["browser_budget_exceeded"]
        results.append(result)
    assert sum(item["mutants"] for item in results) == 17
    write("wasm-new-four-report.json", dict(
        passed=True, modules=4, mutants=17, concurrency=1, results=results))
else:
    raise ValueError(sys.argv[1])
