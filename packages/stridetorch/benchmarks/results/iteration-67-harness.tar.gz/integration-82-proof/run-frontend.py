from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent;repo=r.parent/'integration-snapshot';env=dict(os.environ,PYTHON='/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-21/stride-dev-env/bin/python');env['PATH']='/opt/homebrew/bin:'+str(Path(env['PYTHON']).parent)+':'+env['PATH'];env['PYTHONPATH']=os.pathsep.join([str(repo/'packages/stridetorch/src'),str(repo)]);env.update(OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');receipts=[]
def run(args,name,cwd,overrides=None):
 started=time.monotonic()
 with (r/name).open('w') as log:p=subprocess.run(args,cwd=cwd,env={**env,**(overrides or {})},stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(command=args,log=name,cwd=str(cwd),exit_code=p.returncode,elapsed_s=time.monotonic()-started,environment=overrides or {}));(r/'frontend-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode();print(name,'terminal0',flush=True)
value=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED','--jq','.value'],text=True).strip()
profile=dict(VITE_PUBLIC_SITE='0',VITE_APP_EDITION='hosted',VITE_API_ORIGIN='https://app.paperleet.com',VITE_HOSTED_APP_AVAILABLE='1',VITE_HOSTED_APP_URL='https://app.paperleet.com') if value=='1' else dict(VITE_PUBLIC_SITE='1',VITE_APP_EDITION='local',VITE_API_ORIGIN='',VITE_HOSTED_APP_AVAILABLE='1',VITE_HOSTED_APP_URL='https://app.paperleet.com')
(r/'pages-profile.json').write_text(json.dumps(dict(variable='PAPERLEET_MAIN_SITE_ENABLED',observed_value=value,environment=profile),indent=2)+'\n')
run(['/opt/homebrew/bin/node','web/scripts/check-wasm-cases.mjs'],'wasm-driver.log',repo)
run(['/opt/homebrew/bin/node','web/scripts/check-pages-release.cjs'],'pages-policy.log',repo)
run(['npm','run','check'],'frontend-check.log',repo/'web')
run(['npm','run','build'],'frontend-build.log',repo/'web')
run(['npm','run','build'],'pages-profile-build.log',repo/'web',profile)
