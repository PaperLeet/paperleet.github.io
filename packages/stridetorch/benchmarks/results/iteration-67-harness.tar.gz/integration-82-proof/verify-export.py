from pathlib import Path
import hashlib
import json
import paperleet
import stridetorch
from stridetorch import runtime
import paperleet._vendor.torch as vendored

repo = Path.cwd()
assert Path(paperleet.__file__).resolve().parent == repo / 'paperleet'
source = repo / 'packages/stridetorch/src/stridetorch'
assert Path(stridetorch.__file__).resolve().parent == source
root = repo.parent
proof = root / 'integration-82-proof'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
expected = json.loads((root / 'lean-proof/inverse-expected-source.json').read_text())
actual = {path.name: sha(path) for path in source.iterdir()
          if path.suffix == '.py' or path.name in ['LICENSE', 'NOTICE']}
assert actual == expected
private = repo / "paperleet/_vendor/torch"
assert Path(vendored.__file__).resolve().parent == private
assert {path.name: sha(path) for path in private.iterdir()
        if path.suffix == ".py" or path.name in ["LICENSE", "NOTICE"]} == expected
baseline = json.loads((proof / 'baseline-export-sha256.json').read_text())
data = repo / 'web/public/data'
active = set()
runtimes = {}

def read(relative):
    path = data / relative
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest()[:20] in path.name, relative
    active.add(relative)
    return json.loads(raw)

index = json.loads((data / 'index.json').read_text())
for entry in index['problems']:
    read(entry['detail_url'])
    manifest = read(entry['browser_judge']['bundle_url'])
    assert manifest['problem'] == entry['id']
    relative = manifest['runtime_bundle_url']
    payload = read(relative)
    profile = 'autograd' if payload['backend'] == 'numpy-autograd-wasm' else 'schedules'
    files = runtime.source_files(profile)
    assert all(payload['files'].get(name) == value for name, value in files.items()), entry['id']
    runtimes[relative] = dict(backend=payload['backend'], package_files=len(files), sha256=sha(data / relative))

all_paths = {str(path.relative_to(repo)) for folder in ['browser-judge', 'modules']
             for path in (data / folder).glob('*.json')}
new = all_paths - set(baseline)
unreachable = [name for name in new
               if str(Path(name).relative_to('web/public/data')) not in active]
assert not unreachable, unreachable
origin = Path('/Users/david/Developer/PaperLeet-torch-release')
for name, digest in baseline.items():
    assert sha(repo / name) == digest, name
    if (origin / name).exists():
        assert sha(origin / name) == digest, name
report = dict(status='success', snapshot=str(repo), source_hashes=actual,
              preserved_assets=len(baseline), catalog_modules=len(index['problems']),
              active_assets=len(active), new_assets=len(new),
              new_assets_all_reachable=True, runtimes=runtimes)
(proof / 'export-identity.json').write_text(json.dumps(report, indent=2) + '\n')
(proof / 'new-export-sha256.json').write_text(
    json.dumps({name: sha(repo / name) for name in new}, indent=2) + '\n')
print('Verified', report['catalog_modules'], 'catalog modules;', len(baseline),
      'prior immutable assets preserved;', len(new), 'new assets')
