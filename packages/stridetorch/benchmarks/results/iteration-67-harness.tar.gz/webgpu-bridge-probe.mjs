import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const root=path.dirname(new URL(import.meta.url).pathname);
const assets=path.join(root,'integration-snapshot/web/public/browser-runtime/pyodide-0.29.4');
const prefix='/browser-runtime/pyodide-0.29.4/'; const requests=[];
const server=http.createServer(async(req,res)=>{try{
 const pathname=new URL(req.url,'http://localhost').pathname;requests.push({path:pathname,origin:req.headers.origin||null});
 if(pathname==='/'){res.writeHead(200,{'content-type':'text/html'});res.end('<!doctype html><title>Local bridge probe</title>');return;}
 assert(pathname.startsWith(prefix));const file=pathname===prefix+'stride-webgpu-bridge.mjs'?'/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/benchmarks/webgpu_bridge.mjs':path.resolve(assets,pathname.slice(prefix.length));assert(file.startsWith(assets+path.sep)||file.endsWith('/benchmarks/webgpu_bridge.mjs'));
 const bytes=await fs.promises.readFile(file);res.writeHead(200,{'access-control-allow-origin':'*','content-type':/\.m?js$/.test(file)?'text/javascript':file.endsWith('.wasm')?'application/wasm':'application/octet-stream'});res.end(bytes);
}catch{res.writeHead(404);res.end();}});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const origin='http://127.0.0.1:'+server.address().port; const runtimeURL=origin+prefix;
async function workerMain(runtimeURL){
 try{
  const {loadPyodide}=await import(runtimeURL+'pyodide.mjs');
  const {probeWebGpuBridge}=await import(runtimeURL+'stride-webgpu-bridge.mjs');
  const py=await loadPyodide({indexURL:runtimeURL,stdout(){},stderr(){}});
  const result=await probeWebGpuBridge(py);const repeated=await probeWebGpuBridge(py);if(JSON.stringify(result)!==JSON.stringify(repeated))throw Error('Repeated capability observations differ');result.repeated_probe_consistent=true;
  if(py.runPython("[k for k in globals() if k.startswith('_stride_bridge_')]").toJs().length)throw Error('Probe leaked Python globals');
  self.postMessage({...result,status:result.error?'error':'observed'});
 }catch(error){self.postMessage({status:'error',error:String(error.stack||error)});}
}
const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
try{
 const page=await browser.newPage();await page.goto(origin);
 const source='('+workerMain.toString()+')('+JSON.stringify(runtimeURL)+')';
 const results=await page.evaluate(async({source,runtimeURL})=>{
  async function probe(opaque){return new Promise((resolve,reject)=>{
   const frame=document.createElement('iframe');if(opaque)frame.setAttribute('sandbox','allow-scripts');const nonce=crypto.randomUUID();
   const csp="default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval' blob: "+runtimeURL+"; worker-src blob:; connect-src "+runtimeURL+';';
   const program='const nonce='+JSON.stringify(nonce)+';const relay=payload=>parent.postMessage({nonce,payload},"*");const blob=new Blob(['+JSON.stringify(source)+'],{type:"text/javascript"});const url=URL.createObjectURL(blob);const worker=new Worker(url);URL.revokeObjectURL(url);worker.onmessage=event=>{relay(event.data);worker.terminate();};worker.onerror=event=>relay({status:"worker_error",error:event.message});';
   const timeout=setTimeout(()=>finish(null,Error('Probe timeout')),90000);
   function finish(value,error){clearTimeout(timeout);window.removeEventListener('message',receive);frame.remove();error?reject(error):resolve(value);}
   function receive(event){if(event.source===frame.contentWindow&&event.data?.nonce===nonce)finish(event.data.payload);}
   window.addEventListener('message',receive);frame.srcdoc='<meta http-equiv="Content-Security-Policy" content="'+csp.replaceAll('"','&quot;')+'"><script>'+program.replaceAll('</script','<\\/script')+'</script>';document.body.append(frame);
  });}
  const rows=[];for(const opaque of [false,true])rows.push({opaque_origin_sandbox:opaque,...await probe(opaque)});return rows;
 },{source,runtimeURL});
 const sha=file=>createHash('sha256').update(fs.readFileSync(file)).digest('hex');
 const report={status:'capabilities_observed_not_backend_qualification',observed_utc:new Date().toISOString(),browser:browser.version(),launch:{headless:true,extra_flags:[]},runtime_asset_cors:'Wildcard CORS supplied by local fixture for public assets; opaque-origin requests recorded.',source_sha256:sha(new URL(import.meta.url)),probe_module_sha256:sha('/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/benchmarks/webgpu_bridge.mjs'),pyodide_module_sha256:sha(path.join(assets,'pyodide.mjs')),production_judge_sha256:sha(path.join(root,'integration-snapshot/web/src/browserJudge.ts')),results,requests,production_backend_changed:false,scope:'Pending JS promise and scalar GPU readback only; no tensor, gradient, training or performance qualification.'};
 fs.writeFileSync(path.join(root,'webgpu-bridge-probe-result.json'),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify({browser:report.browser,results}));assert(results.every(row=>row.status==='observed'),JSON.stringify(results));
}finally{await browser.close();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
