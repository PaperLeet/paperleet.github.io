from pathlib import Path
import gc,json,tracemalloc,statistics
import numpy as np
import bench_joint as bench
r=Path(__file__).resolve().parent;labels=['baseline','combined','minimal'];modules={};hashes={}
for label in labels:modules[label],hashes[label]=bench.common.load('_cleanup_memory_'+label,r/(label+'-source/stridetorch'))
rows=[]
for dtype in ['float32','float64']:
 for family,shape,kind in [('classification',(8,16),'soft'),('classification',(64,32),'soft'),('groupnorm',(256,128),'train')]:
  operations={label:bench.fixture(module,family)(shape,kind,np.dtype(dtype),'joint')[0] for label,module in modules.items()}
  for fn in operations.values():fn()
  samples={label:[] for label in labels}
  for order in [labels,list(reversed(labels)),[labels[1],labels[0],labels[2]]]:
   for label in order:
    gc.collect();tracemalloc.start();value=operations[label]();retained,peak=tracemalloc.get_traced_memory();tracemalloc.stop();del value
    samples[label].append(dict(retained_bytes=retained,peak_bytes=peak))
  medians={label:statistics.median(v['peak_bytes'] for v in values) for label,values in samples.items()}
  rows.append(dict(dtype=dtype,family=family,input_shape=list(shape),kind=kind,samples=samples,median_peak_bytes=medians,ratios={label:medians[label]/medians['baseline'] for label in ['combined','minimal']}))
report=dict(status='completed',source_hashes=hashes,rows=rows,scope='Warm whole-call incremental CPU tracemalloc retained/peak, not backward-only, RSS, LAPACK workspace or browser heap. Existing official fixtures validate independent values/gradients before tracing; operands and pre-existing stored gradients predate tracing. Three balanced variant orders. This is a memory observation, not a latency benchmark.')
(r/'cleanup-memory-profile.json').write_text(json.dumps(report,indent=2)+'\n')
for row in rows:print(row['family'],row['dtype'],row['input_shape'],row['ratios'])
