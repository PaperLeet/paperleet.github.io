from pathlib import Path
import json,hashlib,statistics
r=Path(__file__).resolve().parent;p=r/'lean-formal/performance';identity=json.loads((p/'identity.json').read_text());receipts=json.loads((p/'receipts.json').read_text());assert len(receipts)==12 and all(v['exit_code']==0 for v in receipts);plan=json.loads((r/'lean-formal/chrome-contracts/bench-plan.json').read_text());assert identity['source_hashes']=={label:plan[label] for label in ['baseline','candidate']}
rows=[];results=[]
for runtime in ['cpu','node','chrome']:
 children=[]
 for cycle in range(4):
  path=p/f'{runtime}-{cycle}.json';data=json.loads(path.read_text());data=data.get('benchmark',data);assert data['source_hashes']==identity['source_hashes'] and data['versions']==dict(baseline='0.66.0',candidate='0.66.0');assert len(data['rows'])==100;assert len(data['inverse_benchmark']['rows'])==44 and data['inverse_benchmark']['source_hashes']==identity['source_hashes'];assert len(data['joint_benchmark']['rows'])==26 and data['joint_benchmark']['source_hashes']==identity['source_hashes'];children.append(data);results.append(dict(file=str(path.relative_to(r)),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
 for group,count in [('detloggraph',100),('inverse',44),('joint',26)]:
  samples=[child['rows'] if group=='detloggraph' else child[group+'_benchmark']['rows'] for child in children]
  for index in range(count):
   first=samples[0][index];keys=['operation','dtype','input_shape']+(['case','kind'] if group=='joint' else ['shape','mode','matched','baseline_kind']);key={k:first[k] for k in keys};values=[]
   for sample in samples:
    row=sample[index];assert {k:row[k] for k in keys}==key;values.append(row['candidate_over_baseline'])
   rows.append(dict(runtime=runtime,group=group,**key,median=statistics.median(values),minimum=min(values),maximum=max(values),children=values))
summary=dict(status='completed',children=12,workflows_per_child=170,source_hashes=identity['source_hashes'],rows=rows,result_identities=results,scope='Four serial fresh CPU/Node/Chrome children each. Actual frozen validated 0.66 APIs compared with exact isolated lean candidate bytes (still version 0.66.0 by design). 100 determinant/log/graph +44 inverse/JVP/matmul/complex +26 existing GroupNorm/classification workflows per child. Common calibrated >=20ms batches, alternating variant order, complete raw samples preserved. Earlier alternative cleanup variants and A/A CPU controls remain separate evidence. No native-Torch/GPU latency, browser heap, cold start, universal speedup or main integration claim.')
(r/'lean-performance-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for runtime in ['cpu','node','chrome']:
 for group in ['detloggraph','inverse','joint']:
  found=[v for v in rows if v['runtime']==runtime and v['group']==group];worst=sorted(found,key=lambda v:v['median'],reverse=True)[:3];print(runtime,group,'range',round(min(v['median'] for v in found),4),round(max(v['median'] for v in found),4),'worst',[(v['operation'],v.get('case',v.get('shape')),v['dtype'],v.get('mode'),round(v['median'],4)) for v in worst])
