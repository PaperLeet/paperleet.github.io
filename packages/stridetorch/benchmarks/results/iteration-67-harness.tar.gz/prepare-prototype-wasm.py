from pathlib import Path
import hashlib,json,shutil,sys

r=Path(__file__).resolve().parent;scan='--scan' in sys.argv;folder='scan-wasm' if scan else 'prototype-wasm';c=r/folder/'chrome';c.mkdir(parents=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan={}
for label in ['baseline','candidate']:
    source=r/(label+'-source/stridetorch');target=c/label;target.mkdir()
    plan[label]={p.name:sha(p) for p in source.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']}
    for name in plan[label]:shutil.copy2(source/name,target/name)
plan['programs']={name:sha(r/name) for name in ['bench_inverse.py','bench_determinants.py','bench_joint.py','bench_groupnorm_fixture.py','bench_classification_fixture.py',*(['scan_inverse.py'] if scan else [])]}
for name in plan['programs']:shutil.copy2(r/name,c/name)
(c/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');(c/'index.html').write_text('<!doctype html><title>Inverse prototype timing</title>')
python='''
import json,sys,pathlib,hashlib
plan=json.loads(plan_json)
sys.path.insert(0,'/')
for label in ['baseline','candidate']:
 for name,digest in plan[label].items():assert hashlib.sha256(pathlib.Path('/'+label+'/stridetorch',name).read_bytes()).hexdigest()==digest
for name,digest in plan['programs'].items():assert hashlib.sha256(pathlib.Path('/'+name).read_bytes()).hexdigest()==digest
from bench_inverse import run
result=run('/baseline/stridetorch','/candidate/stridetorch')
from bench_joint import run as run_joint
result['joint_benchmark']=run_joint('/baseline/stridetorch','/candidate/stridetorch')
assert result['joint_benchmark']['source_hashes']==result['source_hashes']
assert result['source_hashes']==dict(baseline=plan['baseline'],candidate=plan['candidate'])
json.dumps(result)
'''
if scan:python=python.replace('from bench_inverse import run','from scan_inverse import run')
setup='''
for(const label of ['baseline','candidate']){
 py.FS.mkdirTree('/'+label+'/stridetorch');
 for(const name of Object.keys(plan[label]))py.FS.writeFile('/'+label+'/stridetorch/'+name,await read(label+'/'+name));
}
for(const name of Object.keys(plan.programs))py.FS.writeFile('/'+name,await read(name));
py.globals.set('plan_json',JSON.stringify(plan));
const report=JSON.parse(py.runPython(PYTHON));
'''.replace('PYTHON',json.dumps(python))
worker='''import {loadJudgePackages} from '../../../extraction-browser/packages.mjs';
self.onmessage=async()=>{try{
 const plan=await(await fetch('./plan.json')).json();
 const {loadPyodide}=await import('../../../runtime-0.29.4/pyodide.mjs');
 const py=await loadPyodide({indexURL:new URL('../../../runtime-0.29.4/',self.location.href).href,stdout(){},stderr(){}});
 await loadJudgePackages(py,[]);
 const read=async name=>new Uint8Array(await(await fetch('./'+name)).arrayBuffer());
 SETUP
 self.postMessage({status:'success',pyodide:py.version,numpy:py.runPython('__import__("numpy").__version__'),benchmark:report});
}catch(error){self.postMessage({error:String(error.stack||error)});}};
'''.replace('SETUP',setup)
(c/'worker.mjs').write_text(worker)
node='''import fs from 'node:fs';import assert from 'node:assert/strict';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const root=new URL('./chrome/',import.meta.url);const plan=JSON.parse(fs.readFileSync(new URL('plan.json',root)));
const py=await loadPyodide({indexURL:'/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/',packageCacheDir:'/Users/david/Developer/PaperLeet-torch-release/web/public/browser-runtime/pyodide-0.29.4/',stdout(){},stderr(){}});
await loadJudgePackages(py,[]);
const read=async name=>fs.readFileSync(new URL(name,root));
SETUP
assert.equal(py.runPython('__import__("numpy").__version__'),'2.2.5');
fs.writeFileSync(new URL('node-result.json',import.meta.url),JSON.stringify({status:'success',pyodide:py.version,numpy:'2.2.5',benchmark:report},null,2)+String.fromCharCode(10));
console.log('Node prototype: '+report.rows.length+' workflows');
'''.replace('SETUP',setup)
(c.parent/'node.mjs').write_text(node)
shutil.copy2(r.parent/'torch-iteration-66/fixture-server.mjs',r/'fixture-server.mjs')
runner=(r.parent/'torch-iteration-66/proof/chrome-contracts/run.mjs').read_text()
runner=runner.replace('torch-iteration-66/proof/chrome-contracts','torch-iteration-67/'+folder+'/chrome').replace('120000','300000')
runner=runner.replace("assert.equal(result.status,'success');assert.equal(result.numpy,'2.2.5');","assert.equal(result.status,'success');assert.equal(result.numpy,'2.2.5');assert.equal(result.benchmark.rows.length,"+str(20 if scan else 44)+");")
(c/'run.mjs').write_text(runner)
print('Prepared source-hashed Node/Chrome '+folder+' drivers')
