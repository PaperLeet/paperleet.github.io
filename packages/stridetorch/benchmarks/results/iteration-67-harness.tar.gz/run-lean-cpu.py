from pathlib import Path
import os,subprocess,json,time,hashlib
r=Path(__file__).resolve().parent;p=r/'lean-cpu';p.mkdir();python=str(r.parent/'torch-iteration-21/stride-dev-env/bin/python');source=str(r/'baseline-source/stridetorch');receipts=[];env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2',PYTHONHASHSEED='0')
for index in range(4):
 start=time.time()
 with (p/f'child-{index+1}.log').open('w') as log:found=subprocess.run([python,str(r/'bench_joint.py'),source,str(r/'lean-source/stridetorch')],cwd=r,env=env,stdout=subprocess.PIPE,stderr=log,text=True,check=True)
 result=json.loads(found.stdout);assert len(result['rows'])==26;out=p/f'child-{index+1}.json';out.write_text(json.dumps(result,indent=2)+'\n');receipts.append(dict(child=index+1,status='success',elapsed_s=time.time()-start,sha256=hashlib.sha256(out.read_bytes()).hexdigest()));(p/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print('Lean CPU child',index+1,'26 controls PASS',flush=True)
