from pathlib import Path
import os,subprocess,json,time
r=Path(__file__).resolve().parent;p=r/'scheduled-sdk';env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');receipts=[]
for name,args in [('node',['/opt/homebrew/bin/node',str(p/'wasm-contracts.mjs')]),('chrome',['/opt/homebrew/bin/node',str(p/'chrome-contracts/run.mjs')])]:
 started=time.time()
 with (p/(name+'.log')).open('w') as log:subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 receipts.append(dict(name=name,status='success',seconds=time.time()-started));(p/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,'8067 contracts PASS',flush=True)
