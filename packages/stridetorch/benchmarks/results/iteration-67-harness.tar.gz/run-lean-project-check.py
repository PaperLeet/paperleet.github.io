from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
repo = root / 'integration-snapshot'
proof = root / 'integration-proof'
python = str(root.parent / 'torch-iteration-21/stride-dev-env/bin/python')
expected = json.loads((root / 'lean-proof/inverse-expected-source.json').read_text())
export = json.loads((proof / 'export-identity.json').read_text())
assert export['status'] == 'success' and export['source_hashes'] == expected
assert export['preserved_assets'] == 13547

def sources():
    for folder in [repo / 'packages/stridetorch/src/stridetorch',
                   repo / 'paperleet/_vendor/torch']:
        actual = {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                  for path in folder.iterdir()
                  if path.suffix == '.py' or path.name in ['LICENSE', 'NOTICE']}
        assert actual == expected

sources()
env = dict(os.environ,
           PYTHONPATH=os.pathsep.join([str(repo / 'packages/stridetorch/src'), str(repo)]),
           OMP_NUM_THREADS='2', MKL_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2',
           VECLIB_MAXIMUM_THREADS='2', PAPERLEET_WASM_CONCURRENCY='1')
kind = sys.argv[1]
if kind == 'cpu':
    code = (
        "from pathlib import Path;import paperleet,stridetorch,paperleet._vendor.torch as v;"
        "root=Path.cwd();assert Path(paperleet.__file__).resolve().parent==root/'paperleet';"
        "assert Path(stridetorch.__file__).resolve().parent==root/'packages/stridetorch/src/stridetorch';"
        "assert Path(v.__file__).resolve().parent==root/'paperleet/_vendor/torch';"
        "import pytest,sys;sys.exit(pytest.main(sys.argv[1:]))"
    )
    args = [python, '-c', code, 'tests', 'packages/stridetorch/tests', '-q',
            '-p', 'no:cacheprovider', '--basetemp', str(proof / 'pytest-tmp')]
elif kind == 'wasm':
    args = ['/opt/homebrew/bin/node', 'web/scripts/check-browser-wasm.mjs', '--all']
else:
    raise ValueError(kind)
started = time.time()
with (proof / (kind + '.log')).open('w') as log:
    child = subprocess.run(args, cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT)
sources()
receipt = dict(kind=kind, exit_code=child.returncode, seconds=time.time() - started,
               snapshot=str(repo), source_hashes=expected,
               note='Both standalone and private runtime namespaces are pinned to exact candidate bytes.')
if kind == 'cpu':
    receipt['summary'] = (proof / 'cpu.log').read_text().splitlines()[-1]
elif (repo / 'reports/browser-wasm.json').exists():
    report = json.loads((repo / 'reports/browser-wasm.json').read_text())
    receipt['browser_report'] = {
        key: report[key] for key in ['scope', 'catalog_modules', 'modules', 'passed',
                                    'concurrency', 'browser_budget_exceeded']
    }
    receipt['mutants'] = sum(item.get('mutants', 0) for item in report['results'])
    assert report['passed']
(proof / (kind + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt if kind == 'wasm' else {
    key: receipt[key] for key in ['kind', 'exit_code', 'seconds', 'summary']
}), flush=True)
child.check_returncode()
