from pathlib import Path
import subprocess,os,json,time,hashlib
r=Path(__file__).resolve().parent;p=r/'edge-proof';python=str(r.parent/'torch-iteration-21/stride-dev-env/bin/python')
env=dict(os.environ,PYTHONPATH=str(r/'edge-source'),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
receipts=[]
def run(name,args,cwd=p):
 started=time.time()
 with (p/(name+'.log')).open('w') as log:subprocess.run(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 receipts.append(dict(name=name,status='success',seconds=time.time()-started));(p/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,'PASS',flush=True)
run('sdk',[python,'-m','pytest','-q','/Users/david/Developer/PaperLeet-torch-release/packages/stridetorch/tests',str(r/'test_joint_lifetime.py'),str(r/'test_joint_dense_routing.py'),'--noconftest','-p','no:cacheprovider','--import-mode=importlib'])
for file in ['differential-inverse.py','probe-inverse-mutation-layouts.py','probe-matmul-guards.py','probe-inverse-api.py']:
 code="import stridetorch._linalg as l;l._INVERSE_JVP_SHARED=True;import sys,runpy;sys.argv=['"+file+"','adapter'];runpy.run_path('"+file+"',run_name='__main__')"
 run(file,[python,'-c',code])
run('qualify-inverse',[python,'qualify-inverse.py'])
run('targets',[python,'probe-inverse-targets.py','adapter','edge','--shared'])
run('qualify-targets',[python,'qualify-inverse-targets.py','edge'])
expected=json.loads((p/'inverse-expected-source.json').read_text());actual={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (r/'edge-source/stridetorch').iterdir() if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']};assert actual==expected
print('ALL EDGE CPU QUALIFICATION PASS',flush=True)
