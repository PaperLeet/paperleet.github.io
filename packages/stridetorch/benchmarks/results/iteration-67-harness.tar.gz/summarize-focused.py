from pathlib import Path
import json,statistics,hashlib
r=Path(__file__).resolve().parent;p=r/'focused/results';receipts=json.loads((p/'receipts.json').read_text());assert len(receipts)==12 and all(v['status']=='success' for v in receipts)
plan=json.loads((r/'focused/chrome/plan.json').read_text());rows=[]
for runtime in ['cpu','node','chrome']:
 results=[]
 for receipt in [v for v in receipts if v['runtime']==runtime]:
  f=p/(receipt['name']+'.json');assert hashlib.sha256(f.read_bytes()).hexdigest()==receipt['result_sha256'];found=json.loads(f.read_text())['benchmark'];assert found['source_hashes']=={k:plan[k] for k in ['baseline','combined','scheduled']};results.append(found)
 assert len(results)==4
 for index,row in enumerate(results[0]['rows']):
  identity={k:row[k] for k in ['dtype','input_shape','target']};values={k:[] for k in ['combined','scheduled']}
  for result in results:
   other=result['rows'][index];assert {k:other[k] for k in identity}==identity
   for label in values:values[label].append(other['ratios'][label])
  rows.append(dict(runtime=runtime,**identity,ratios={k:dict(median=statistics.median(v),minimum=min(v),maximum=max(v),children=v) for k,v in values.items()}))
memory={}
for label in ['combined','scheduled']:
 data=json.loads((r/(label+'-memory.json')).read_text());paired={}
 for row in data['rows']:
  if row['operation']!='inverse_jvp':continue
  key=(row['dtype'],tuple(row['input_shape']),row['direction_layout']);paired.setdefault(key,{})[row['variant']]=row
 memory[label]=[dict(dtype=k[0],input_shape=list(k[1]),direction_layout=k[2],baseline_backward_peak_bytes=v['baseline']['backward_peak_bytes'],candidate_backward_peak_bytes=v['candidate']['backward_peak_bytes'],ratio=v['candidate']['backward_peak_bytes']/v['baseline']['backward_peak_bytes']) for k,v in paired.items()]
report=dict(status='completed_isolated_comparison',children=12,workflows_per_child=16,rows=rows,memory=memory,source_hashes={k:plan[k] for k in ['baseline','combined','scheduled']},scope='Each workflow compares actual inverse JVP with weighted full backward or single-input autograd.grad. Four fresh processes per runtime, serial execution, three variants in six balanced permutations, common calibrated batches >=20ms, complete raw samples. Native CPU retains its existing route; forced-shared tracemalloc memory numbers are CPU allocation proxies and are not browser heap measurements. Frozen 0.66 baseline is locally validated but not yet adopted on main. No repository integration or release follows solely from these observations.')
(r/'focused-summary.json').write_text(json.dumps(report,indent=2)+'\n')
for row in rows:print(row['runtime'],row['dtype'],row['input_shape'],row['target'],*[k+'='+format(v['median'],'.3f')+' ['+format(v['minimum'],'.3f')+','+format(v['maximum'],'.3f')+']' for k,v in row['ratios'].items()])
