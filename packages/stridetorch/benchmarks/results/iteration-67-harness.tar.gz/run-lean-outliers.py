from pathlib import Path
import os,subprocess,time,json,hashlib
r=Path(__file__).resolve().parent;p=r/'lean-outliers/results';p.mkdir();python=str(r.parent/'torch-iteration-21/stride-dev-env/bin/python');plan=json.loads((r/'lean-outliers/assets/plan.json').read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def frozen():
 for label,name in [('baseline','baseline'),('candidate','lean')]:
  found={f.name:sha(f) for f in (r/(name+'-source/stridetorch')).iterdir() if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']};assert found==plan[label]
 for name,digest in plan['programs'].items():assert sha(r/name)==digest
frozen();env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2',PYTHONHASHSEED='0');receipts=[]
for cycle in range(4):
 for runtime in ['cpu','node'] if cycle%2==0 else ['node','cpu']:
  frozen();name=f'{runtime}-{cycle}';result=p/(name+'.json');started=time.time()
  with (p/(name+'.log')).open('w') as log:
   if runtime=='cpu':
    output=subprocess.run([python,'bench_lean_outliers.py',str(r/'baseline-source/stridetorch'),str(r/'lean-source/stridetorch'),str(r/'cpu-outlier-plans.json'),str(cycle)],cwd=r,env=env,stdout=subprocess.PIPE,stderr=log,text=True,check=True);found=json.loads(output.stdout);result.write_text(json.dumps(dict(status='success',benchmark=found),indent=2)+'\n')
   else:subprocess.run(['/opt/homebrew/bin/node',str(r/'lean-outliers/node.mjs')],cwd=r,env=dict(env,REPORT_PATH=str(result),CYCLE=str(cycle)),stdout=log,stderr=subprocess.STDOUT,check=True)
  found=json.loads(result.read_text());assert found['status']=='success' and len(found['benchmark']['rows'])==4 and found['benchmark']['source_hashes']==dict(baseline=plan['baseline'],duplicate=plan['baseline'],candidate=plan['candidate']);frozen();receipts.append(dict(name=name,status='success',elapsed_s=time.time()-started,result_sha256=sha(result)));(p/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,'4 A/A/B workflows PASS',round(time.time()-started,1),'s',flush=True)
print('ALL EIGHT A/A/B OUTLIER CHILDREN PASS',flush=True)
