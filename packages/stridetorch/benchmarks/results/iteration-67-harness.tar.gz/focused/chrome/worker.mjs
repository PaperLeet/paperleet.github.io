import {loadJudgePackages} from '../../../extraction-browser/packages.mjs';
self.onmessage=async()=>{try{
 const plan=await(await fetch('./plan.json')).json();
 const {loadPyodide}=await import('../../../runtime-0.29.4/pyodide.mjs');
 const py=await loadPyodide({indexURL:new URL('../../../runtime-0.29.4/',self.location.href).href,stdout(){},stderr(){}});
 await loadJudgePackages(py,[]);
 const read=async name=>new Uint8Array(await(await fetch('./'+name)).arrayBuffer());
 
for(const label of ['baseline','combined','scheduled']){
 py.FS.mkdirTree('/'+label+'/stridetorch');
 for(const name of Object.keys(plan[label]))py.FS.writeFile('/'+label+'/stridetorch/'+name,await read(label+'/'+name));
}
for(const name of Object.keys(plan.programs))py.FS.writeFile('/'+name,await read(name));
py.globals.set('plan_json',JSON.stringify(plan));
const report=JSON.parse(py.runPython("\nimport json,sys,pathlib,hashlib\nplan=json.loads(plan_json);sys.path.insert(0,'/')\nfor label in ['baseline','combined','scheduled']:\n for name,digest in plan[label].items():assert hashlib.sha256(pathlib.Path('/'+label+'/stridetorch',name).read_bytes()).hexdigest()==digest\nfor name,digest in plan['programs'].items():assert hashlib.sha256(pathlib.Path('/'+name).read_bytes()).hexdigest()==digest\nfrom bench_focus import run\nresult=run('/baseline/stridetorch','/combined/stridetorch','/scheduled/stridetorch')\nassert result['source_hashes']=={label:plan[label] for label in ['baseline','combined','scheduled']}\njson.dumps(result)\n"));

 self.postMessage({status:'success',pyodide:py.version,numpy:py.runPython('__import__("numpy").__version__'),benchmark:report});
}catch(error){self.postMessage({error:String(error.stack||error)});}};
