from pathlib import Path
import json,statistics,hashlib
r=Path(__file__).resolve().parent;p=r/'direct-controls/results';receipts=json.loads((p/'receipts.json').read_text());assert len(receipts)==12 and all(v['status']=='success' for v in receipts)
plan=json.loads((r/'direct-controls/chrome/plan.json').read_text());rows=[]
for runtime in ['cpu','node','chrome']:
 results=[]
 for receipt in [v for v in receipts if v['runtime']==runtime]:
  f=p/(receipt['name']+'.json');assert hashlib.sha256(f.read_bytes()).hexdigest()==receipt['result_sha256'];found=json.loads(f.read_text())['benchmark'];assert found['source_hashes']=={label:plan[label] for label in ['baseline','candidate']};results.append(found)
 assert len(results)==4
 for index,row in enumerate(results[0]['rows']):
  identity={k:row[k] for k in ['operation','case','kind','dtype','input_shape']};values=[]
  for result in results:
   other=result['rows'][index];assert {k:other[k] for k in identity}==identity;values.append(other['candidate_over_baseline'])
  rows.append(dict(runtime=runtime,**identity,median=statistics.median(values),minimum=min(values),maximum=max(values),children=values))
report=dict(status='completed_isolated_control_comparison',children=12,workflows_per_child=26,rows=rows,source_hashes={k:plan[k] for k in ['baseline','candidate']},scope='Existing GroupNorm/classification APIs exercise engine-wide consumed-joint callback cleanup. Four fresh serial processes per runtime, actual baseline/candidate calls, five alternating common batches >=20ms; independent fixture checks execute outside measured calls. The earlier explicit-delete combined variant showed persistent CPU soft-label loss regressions in its four-child comparison. This direct callback variant removes the slice and saved callable local; its independent results do not erase those earlier observations. These repeated results remain limited to this host and these workflows.')
(r/'direct-controls-summary.json').write_text(json.dumps(report,indent=2)+'\n')
for runtime in ['cpu','node','chrome']:
 found=sorted([v for v in rows if v['runtime']==runtime],key=lambda v:v['median'],reverse=True)
 print(runtime,'median ratios range',round(min(v['median'] for v in found),4),round(max(v['median'] for v in found),4),'worst',[(v['case'],v['dtype'],round(v['median'],4),[round(v['minimum'],3),round(v['maximum'],3)]) for v in found[:4]])
