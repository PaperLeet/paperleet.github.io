from pathlib import Path
import json,subprocess,os,hashlib,time
r=Path(__file__).resolve().parent;origin=Path('/Users/david/Developer/PaperLeet-torch-release');repo=r/'integration-snapshot';python=str(r.parent/'torch-iteration-21/stride-dev-env/bin/python');proof=r/'integration-proof';proof.mkdir(exist_ok=True);env=dict(os.environ,PYTHONPATH=os.pathsep.join([str(repo/'packages/stridetorch/src'),str(repo)]),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
subprocess.run([python,'-c',"from pathlib import Path;import paperleet,stridetorch,paperleet._vendor.torch as v;root=Path.cwd();assert Path(v.__file__).resolve().parent==root/'paperleet/_vendor/torch';assert Path(stridetorch.__file__).resolve().parent==root/'packages/stridetorch/src/stridetorch';print('Both runtime namespaces resolve inside snapshot')"],cwd=repo,env=env,check=True)
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z','--','web/public/data/browser-judge','web/public/data/modules'],cwd=origin).decode().split('\0');paths=[v for v in paths if v];baseline={name:sha(origin/name) for name in paths};assert len(baseline)==13547,len(baseline);(proof/'baseline-export-sha256.json').write_text(json.dumps(baseline,indent=2)+'\n');receipts=[]
for label,args in [('export',[str(Path(python).parent/'paperleet'),'export']),('vizdata',[str(Path(python).parent/'paperleet'),'vizdata','all'])]:
 started=time.time()
 with (proof/(label+'.log')).open('w') as log:subprocess.run(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 receipts.append(dict(name=label,status='success',seconds=time.time()-started));(proof/'export-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(label,'PASS',flush=True)
for name,digest in baseline.items():assert sha(repo/name)==digest and sha(origin/name)==digest,name
subprocess.run([python,str(proof/'verify-export.py')],cwd=repo,env=env,check=True)
