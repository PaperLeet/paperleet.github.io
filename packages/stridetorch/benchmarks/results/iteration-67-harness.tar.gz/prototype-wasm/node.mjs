import fs from 'node:fs';import assert from 'node:assert/strict';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const root=new URL('./chrome/',import.meta.url);const plan=JSON.parse(fs.readFileSync(new URL('plan.json',root)));
const py=await loadPyodide({indexURL:'/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/',packageCacheDir:'/Users/david/Developer/PaperLeet-torch-release/web/public/browser-runtime/pyodide-0.29.4/',stdout(){},stderr(){}});
await loadJudgePackages(py,[]);
const read=async name=>fs.readFileSync(new URL(name,root));

for(const label of ['baseline','candidate']){
 py.FS.mkdirTree('/'+label+'/stridetorch');
 for(const name of Object.keys(plan[label]))py.FS.writeFile('/'+label+'/stridetorch/'+name,await read(label+'/'+name));
}
for(const name of Object.keys(plan.programs))py.FS.writeFile('/'+name,await read(name));
py.globals.set('plan_json',JSON.stringify(plan));
const report=JSON.parse(py.runPython("\nimport json,sys,pathlib,hashlib\nplan=json.loads(plan_json)\nsys.path.insert(0,'/')\nfor label in ['baseline','candidate']:\n for name,digest in plan[label].items():assert hashlib.sha256(pathlib.Path('/'+label+'/stridetorch',name).read_bytes()).hexdigest()==digest\nfor name,digest in plan['programs'].items():assert hashlib.sha256(pathlib.Path('/'+name).read_bytes()).hexdigest()==digest\nfrom bench_inverse import run\nresult=run('/baseline/stridetorch','/candidate/stridetorch')\nfrom bench_joint import run as run_joint\nresult['joint_benchmark']=run_joint('/baseline/stridetorch','/candidate/stridetorch')\nassert result['joint_benchmark']['source_hashes']==result['source_hashes']\nassert result['source_hashes']==dict(baseline=plan['baseline'],candidate=plan['candidate'])\njson.dumps(result)\n"));

assert.equal(py.runPython('__import__("numpy").__version__'),'2.2.5');
fs.writeFileSync(new URL('node-result.json',import.meta.url),JSON.stringify({status:'success',pyodide:py.version,numpy:'2.2.5',benchmark:report},null,2)+String.fromCharCode(10));
console.log('Node prototype: '+report.rows.length+' workflows');
