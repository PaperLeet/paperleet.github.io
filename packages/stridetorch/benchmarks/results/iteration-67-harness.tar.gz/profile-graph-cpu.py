from pathlib import Path
import cProfile,pstats,json,gc
import numpy as np
import bench_joint as bench
r=Path(__file__).resolve().parent;rows=[]
for label in ['baseline','edge']:
 module,source=bench.common.load('_profile_'+label,r/(label+'-source/stridetorch'));fn,_=bench.fixture(module,'classification')((8,16),'soft',np.dtype('float32'),'joint')
 for _ in range(100):fn()
 gc.collect();profile=cProfile.Profile();profile.enable()
 for _ in range(3000):fn()
 profile.disable();profile.dump_stats(str(r/(label+'-graph-cpu.prof')));stats=pstats.Stats(profile);wanted=[]
 for (file,line,name),(primitive,total,self_time,cumulative,callers) in stats.stats.items():
  if 'stridetorch' in file and name in ['run','_execute','release','_accumulate_gradient','__init__','joint_result','backward','cross_entropy','_soft_loss']:
   wanted.append(dict(file=str(Path(file).relative_to(r)),line=line,name=name,calls=total,self_s=self_time,cumulative_s=cumulative))
 rows.append(dict(label=label,source_hashes=source,total_s=stats.total_tt,calls=stats.total_calls,functions=sorted(wanted,key=lambda v:v['cumulative_s'],reverse=True)))
(r/'graph-cpu-profile.json').write_text(json.dumps(dict(rows=rows,scope='Diagnostic cProfile only: 3000 warmed soft-label float32 8x16 calls. Profiling overhead is not a latency benchmark or a performance gate.'),indent=2)+'\n')
for row in rows:print(row['label'],round(row['total_s'],4),[(v['name'],round(v['self_s'],4),round(v['cumulative_s'],4)) for v in row['functions'][:12]])
