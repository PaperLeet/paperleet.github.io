from pathlib import Path
import json,statistics,hashlib
r=Path(__file__).resolve().parent;p=r/'lean-outliers/results';receipts=json.loads((p/'receipts.json').read_text());assert len(receipts)==8 and all(v['status']=='success' for v in receipts);plan=json.loads((r/'lean-outliers/assets/plan.json').read_text());rows=[]
for runtime in ['cpu','node']:
 data=[]
 for cycle in range(4):
  path=p/f'{runtime}-{cycle}.json';receipt=next(v for v in receipts if v['name']==f'{runtime}-{cycle}');assert hashlib.sha256(path.read_bytes()).hexdigest()==receipt['result_sha256'];value=json.loads(path.read_text())['benchmark'];assert value['source_hashes']==dict(baseline=plan['baseline'],duplicate=plan['baseline'],candidate=plan['candidate']);data.append(value)
 for index,first in enumerate(data[0]['rows']):
  values={label:[] for label in ['duplicate_over_baseline','candidate_over_baseline','candidate_over_duplicate']};alignment=[]
  for child in data:
   row=child['rows'][index];assert row['plan']==first['plan'];aa=row['ratios']['duplicate'];ab=row['ratios']['candidate'];values['duplicate_over_baseline'].append(aa);values['candidate_over_baseline'].append(ab);values['candidate_over_duplicate'].append(ab/aa);alignment.append(dict(load_order=child['load_order'],arrays=row['alignment']))
  rows.append(dict(runtime=runtime,plan=first['plan'],ratios={key:dict(median=statistics.median(v),minimum=min(v),maximum=max(v),children=v) for key,v in values.items()},alignment=alignment))
report=dict(status='completed',children=8,workflows_per_child=4,source_hashes=dict(baseline=plan['baseline'],duplicate=plan['baseline'],candidate=plan['candidate']),rows=rows,scope='Longer targeted follow-up to 12x170 full series. Four fresh CPU/Node children each, rotating import order, twelve balanced three-way common >=50ms batches, matched inputs and pre-timing value/gradient checks. Same-source A/A is explicitly recorded, not subtracted to manufacture speedup. Input alignment metadata is observational; no causal alignment, native-Torch timing, Chrome replication or universal speed claim. Original full-series outliers remain unchanged.')
(r/'lean-outlier-summary.json').write_text(json.dumps(report,indent=2)+'\n')
for row in rows:print(row['runtime'],row['plan']['operation'],row['plan'].get('shape',row['plan'].get('case')),row['plan']['dtype'],row['plan'].get('mode'),{key:round(value['median'],4) for key,value in row['ratios'].items()})
