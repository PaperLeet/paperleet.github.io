from pathlib import Path
import subprocess,os,json,time,hashlib,re
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');python=str(r.parent/'torch-iteration-21/stride-dev-env/bin/python');source=r/'lean-source/stridetorch';hashes=lambda:{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']};before=hashes();files=sorted(repo.joinpath('tests').glob('test_torch_*.py'));assert len(files)==40;env=dict(os.environ,PYTHONPATH=str(r/'lean-source'),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
code="import stridetorch,pathlib,pytest,sys;assert pathlib.Path(stridetorch.__file__).resolve().parent==pathlib.Path("+repr(str(source))+");sys.exit(pytest.main(sys.argv[1:]))"
started=time.time()
with (r/'lean-native-api.log').open('w') as log:child=subprocess.run([python,'-c',code,*map(str,files),'-q','-p','no:cacheprovider'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
assert hashes()==before
text=(r/'lean-native-api.log').read_text();last=text.splitlines()[-1];receipt=dict(exit_code=child.returncode,seconds=time.time()-started,source_hashes=before,test_files={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},summary=last,scope='All 40 repository test_torch_*.py native API comparison modules against isolated lean stridetorch bytes on PYTHONPATH. This does not claim application packaging, catalog export, frontend or full PaperLeet exercise integration.')
(r/'lean-native-api-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(last,flush=True);child.check_returncode()
