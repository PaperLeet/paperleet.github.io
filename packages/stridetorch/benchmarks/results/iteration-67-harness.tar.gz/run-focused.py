from pathlib import Path
import subprocess,os,json,time,hashlib,platform
r=Path(__file__).resolve().parent;p=r/'focused/results';p.mkdir();python=str(r.parent/'torch-iteration-21/stride-dev-env/bin/python');node='/opt/homebrew/bin/node'
plan=json.loads((r/'focused/chrome/plan.json').read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def sources():
 for label in ['baseline','combined','scheduled']:
  actual={f.name:sha(f) for f in (r/(label+'-source/stridetorch')).iterdir() if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']};assert actual==plan[label]
 for name,digest in plan['programs'].items():assert sha(r/name)==digest
sources();sdk=json.loads((r/'scheduled-sdk/receipts.json').read_text());assert [v['name'] for v in sdk]==['node','chrome'] and all(v['status']=='success' for v in sdk)
env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2',PYTHONHASHSEED='0');receipts=[]
orders=[['cpu','node','chrome'],['chrome','node','cpu'],['node','cpu','chrome'],['chrome','cpu','node']]
for cycle,order in enumerate(orders):
 for runtime in order:
  sources();name=f'{runtime}-{cycle+1}';result=p/(name+'.json');started=time.time();load=os.getloadavg()
  args=[python,str(r/'bench_focus.py'),*[str(r/(label+'-source/stridetorch')) for label in ['baseline','combined','scheduled']]] if runtime=='cpu' else [node,str(r/('focused/node.mjs' if runtime=='node' else 'focused/chrome/run.mjs'))]
  with (p/(name+'.log')).open('w') as log:
   if runtime=='cpu':
    output=subprocess.run(args,cwd=r,env=env,stderr=log,stdout=subprocess.PIPE,text=True,check=True);benchmark=json.loads(output.stdout);result.write_text(json.dumps(dict(status='success',python=platform.python_version(),benchmark=benchmark),indent=2)+'\n')
   else:subprocess.run(args,cwd=r,env=dict(env,REPORT_PATH=str(result)),stdout=log,stderr=subprocess.STDOUT,check=True)
  found=json.loads(result.read_text());assert found['status']=='success' and len(found['benchmark']['rows'])==16
  assert found['benchmark']['source_hashes']=={label:plan[label] for label in ['baseline','combined','scheduled']}
  assert found['benchmark']['program_sha256']==plan['programs']['bench_focus.py'];sources()
  receipts.append(dict(name=name,runtime=runtime,cycle=cycle+1,status='success',elapsed_s=time.time()-started,host_load_before=load,result_sha256=sha(result),source_hashes=found['benchmark']['source_hashes']))
  (p/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,'16 workflows PASS',round(time.time()-started,2),'s',flush=True)
assert len(receipts)==12
print('ALL 12 FRESH FOCUSED CHILDREN PASS',flush=True)
