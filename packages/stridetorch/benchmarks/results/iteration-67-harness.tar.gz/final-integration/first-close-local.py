from pathlib import Path
import json,hashlib,re,shutil,tarfile,os,subprocess,platform
p=Path(__file__).resolve().parent;r=p.parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results'
read=lambda path:json.loads(path.read_text());sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
context=read(p/'context.json');source=read(p/'source-hashes.json');tests=read(p/'test-hashes.json');owned=read(p/'owned-source-paths.json');provenance=read(p/'formal-provenance.json')
assert len(source)==61 and len(tests)==63 and len(owned)==9
for name,digest in source.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==digest
for name,digest in tests.items():assert sha(repo/'packages/stridetorch/tests'/name)==digest
for name,digest in read(p/'application-input-sha256.json').items():assert sha(repo/name)==digest
cpu=read(p/'cpu-receipt.json');assert cpu['exit_code']==0 and re.search(r'41705 passed, 1 skipped',cpu['summary'])
assert cpu['source_hashes']==source
wasm_receipt=read(p/'wasm-receipt.json');assert wasm_receipt['exit_code']==0
wasm=read(p/'full-wasm-result.json');assert wasm['passed'] and wasm['modules']==wasm['catalog_modules']==82 and len(wasm['results'])==82 and sum(v['mutants'] for v in wasm['results'])==359 and not wasm['browser_budget_exceeded']
assert all(v['passed'] and not v['browser_budget_exceeded'] for v in wasm['results'])
contracts=next(v for v in wasm['results'] if v['id']=='architecture/attention')['independent_contracts'];assert contracts['passed']==8071 and len(contracts['suites'])==62
expected_tests={k:v for k,v in tests.items() if k!='test_standalone.py'};assert {v['suite']:v['source_sha256'] for v in contracts['suites']}==expected_tests
package=read(r/'final-package-proof/package-identity.json');assert package['status']=='success' and package['source_hashes']==source and package['standalone_installed_tests']==8084 and not package['native_torch']
for name in ['source-wasm.json','chrome-contracts/result.json']:
 result=read(r/'versioned-release/wasm-proof'/name);assert result['passed']==8071 and result['source_hashes']==source and result['library']=='0.67.0'
ui=read(p/'latest-ui-qualification.json');assert ui['status']=='qualified' and len(ui['checks'])==10 and len(ui['receipts'])==14 and all(v['exit_code']==0 for v in ui['receipts'])
assert ui['upstream']==context['upstream']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
export=read(p/'export-identity.json');assert export['version']=='0.67.0' and export['source_hashes']==source and export['preserved_assets']==13563 and export['new_assets']==166 and export['catalog_modules']==82
for name,digest in read(p/'baseline-immutable-sha256.json').items():assert sha(repo/name)==digest
for name,digest in read(p/'new-assets-sha256.json').items():assert sha(repo/name)==digest
live=read(p/'live-export-sha256.json');assert len(live)==169
for name,digest in live.items():assert sha(repo/'web/public/data'/name)==digest
policy=read(p/'release-policy-identity.json')
for name,digest in policy['files'].items():assert sha(repo/name)==digest
runtime=read(r.parent/'torch-iteration-66/runtime-identity.json');assert len(runtime['public_runtime_files'])==18
for name,digest in runtime['public_runtime_files'].items():assert sha(repo/'web/public/browser-runtime/pyodide-0.29.4'/name)==digest
formal=read(r/'lean-performance-summary.json');assert formal['status']=='completed' and formal['children']==12 and formal['workflows_per_child']==170
assert formal['source_hashes']['baseline']==read(p/'baseline-source-sha256.json') and formal['source_hashes']['candidate']==provenance['formal_candidate_source']
controls=read(r/'lean-outlier-summary.json');assert controls['children']==8 and controls['workflows_per_child']==4
memory={label:read(r/name) for label,name in [('actual_inverse','lean-memory-actual.json'),('forced_shared_cpu_proxy','lean-memory-shared.json'),('callback_cleanup','lean-cleanup-memory.json')]}
assert memory['actual_inverse']['source_hashes']==formal['source_hashes'] and memory['forced_shared_cpu_proxy']['source_hashes']==formal['source_hashes']
assert memory['callback_cleanup']['source_hashes']['lean']==formal['source_hashes']['candidate']
benchmark=read(p/'public-benchmark-validation.json');assert benchmark['validation_only'] and len(benchmark['rows'])==26 and benchmark['source_hashes']==dict(baseline=provenance['formal_baseline_source'],candidate=source)
assert benchmark['program_sha256']==sha(repo/'packages/stridetorch/benchmarks/bench_joint.py')
# Preserve exact published source and test inputs without copying disposable app data.
snapshot=p/'published-inputs';snapshot.mkdir(exist_ok=True)
for name in owned:
 target=snapshot/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/name,target)
shutil.copytree(repo/'packages/stridetorch/src/stridetorch',snapshot/'runtime-source',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
shutil.copytree(repo/'packages/stridetorch/tests',snapshot/'runtime-tests',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
owned_hashes={name:sha(repo/name) for name in owned};save(p/'owned-input-sha256.json',owned_hashes)
archive=out/'iteration-67-harness.tar.gz';assert not archive.exists()
excluded={'integration-snapshot','pytest-tmp','node_modules','__pycache__','.pytest_cache','.git','build','dist'}
allowed={'.py','.mjs','.json','.log','.md','.html','.toml','.npz','.txt','.whl','.pkl','.patch'}
with tarfile.open(archive,'w:gz') as target:
 for current,dirs,files in os.walk(r):
  dirs[:]=[name for name in dirs if name not in excluded and not name.endswith(('-env','-venv','.egg-info'))]
  for name in sorted(files):
   file=Path(current)/name
   if file.is_symlink():continue
   if file.name in ['LICENSE','NOTICE'] or file.suffix in allowed or file.name.endswith('.tar.gz'):target.add(file,arcname=file.relative_to(r),recursive=False)
assert archive.stat().st_size<95*1024*1024
report=dict(status='validated_locally',version='0.67.0',baseline_main=context['upstream'],baseline_version='0.66.0',source_hashes=source,test_hashes=tests,owned_inputs=owned_hashes,full_cpu=cpu,full_wasm=wasm,full_wasm_receipt=wasm_receipt,independent_package=package,versioned_node_contracts=read(r/'versioned-release/wasm-proof/source-wasm.json'),versioned_chrome_contracts=read(r/'versioned-release/wasm-proof/chrome-contracts/result.json'),frontend=ui,export_identity=export,active_export_sha256=live,baseline_immutable_assets=13563,new_assets=166,total_immutable_assets=13729,canonical_release_policy=policy,runtime_identity=runtime,formal_provenance=provenance,performance=formal,longer_outlier_controls=controls,memory=memory,public_benchmark_validation=benchmark,prior_native_api=read(r/'lean-native-api-receipt.json'),prior_native_node_oracle=read(r/'lean-oracle/oracle-node-result.json'),prior_native_chrome_oracle=read(r/'lean-oracle/chrome-contracts/oracle-result.json'),limitations=['Real/complex supported API and higher-derivative boundaries are unchanged; this does not add a GPU backend.','Formal timing used frozen A and B0.66 builds; B numerical/graph files exactly match versioned0.67, whose only difference is the version literal. Old timing samples are not relabeled as fresh0.67 runs.','The inverse shared-route CPU allocation probe is explicitly forced and is not a browser heap measurement. Ordinary CPU inverse routing is unchanged.','Original worst timing cases and longer balanced AA/B controls are retained; no uniform speedup is claimed.','The separate iteration68 consumed-cotangent cleanup prototype is not included; its latency tradeoff remains unresolved.'],raw_archive=dict(name=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)))
save(out/'iteration-67.json',report);save(p/'state.json',dict(status='local_gates_passed',version='0.67.0',main_adoption_pending=True,baseline=context['upstream'],source_hashes=source,raw_archive=report['raw_archive']))
print(json.dumps(dict(status='validated_locally',cpu=cpu['summary'],catalog_modules=82,mutants=359,minimum_tests=8084,raw_archive=report['raw_archive'])),flush=True)
