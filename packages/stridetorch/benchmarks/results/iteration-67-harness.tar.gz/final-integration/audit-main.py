from pathlib import Path
import hashlib,json,subprocess,sys
from release_chain_guard import ignorable_stale_queued_quality
repo=Path('/Users/david/Developer/PaperLeet-torch-release');r=Path(__file__).resolve().parent
expected=sys.argv[1];remote=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/git/ref/heads/main','--jq','.object.sha'],cwd=repo,text=True).strip()
runs=json.loads(subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/runs?per_page=100'],cwd=repo,text=True))['workflow_runs']
policy=json.loads((r/'release-policy-identity.json').read_text())
variants=json.loads((r/'release-policy-variants.json').read_text())['variants']
def policies_at(ref):
 try:
  actual={name:hashlib.sha256(subprocess.check_output(['git','show',ref+':'+name],cwd=repo,stderr=subprocess.DEVNULL)).hexdigest() for name in policy['files']}
  return any(actual==variant['files'] for variant in variants)
 except subprocess.CalledProcessError:
  return False
active=[];ignored_stale_quality=[]
for item in runs:
 if item['status']=='completed' or item['name'] not in ('PaperLeet quality gate','Publish PaperLeet public site'):continue
 summary=dict(id=item['id'],name=item['name'],event=item['event'],status=item['status'],head_sha=item['head_sha'],url=item['html_url'])
 if item['name']=='PaperLeet quality gate' and item['status']=='queued' and item['head_sha']!=remote:
  detail=json.loads(subprocess.check_output(['gh','api',f"repos/PaperLeet/paperleet.github.io/actions/runs/{item['id']}"],cwd=repo,text=True))
  jobs=json.loads(subprocess.check_output(['gh','api',f"repos/PaperLeet/paperleet.github.io/actions/runs/{item['id']}/jobs"],cwd=repo,text=True))['jobs']
  ancestor=subprocess.run(['git','merge-base','--is-ancestor',detail['head_sha'],remote],cwd=repo,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
  canonical=policies_at(detail['head_sha']) and policies_at(remote)
  if ignorable_stale_queued_quality(detail,remote,jobs,canonical_policies_verified=canonical,ancestor_verified=ancestor):
   ignored_stale_quality.append(dict(**summary,reason='Unstarted first-party manual ancestor request; exact canonical CI/Pages policies at both SHAs reject release of a non-current SHA.',canonical_policy_files=7,jobs=0,ancestor_verified=True));continue
 active.append(summary)
pending_pages=[];observed=[]
# A successful quality run may finish before its workflow_run child appears.
# Hold current main through that event-delivery gap too.
chain_ids={39004189139,39005098435}
chain_ids.update(v['id'] for v in runs if v['name']=='PaperLeet quality gate' and v['head_sha']==remote)
for run_id in sorted(chain_ids):
 quality=next((v for v in runs if v['id']==run_id),None)
 if quality is None:quality=json.loads(subprocess.check_output(['gh','api',f'repos/PaperLeet/paperleet.github.io/actions/runs/{run_id}'],cwd=repo,text=True))
 pages=[v for v in runs if v['name']=='Publish PaperLeet public site' and v['head_sha']==quality['head_sha'] and ((v['event']=='workflow_run' and v['created_at']>=quality['created_at']) or (quality['status']=='completed' and v['event']=='workflow_dispatch' and v['created_at']>=quality['updated_at']))]
 observed.append(dict(quality_id=run_id,status=quality['status'],conclusion=quality['conclusion'],head_sha=quality['head_sha'],pages=[dict(id=v['id'],status=v['status'],conclusion=v['conclusion']) for v in pages]))
 if quality['status']=='completed' and quality['conclusion']=='success' and quality['head_sha']==remote and not pages:
  pending_pages.append(run_id)
policy=json.loads((r/'release-policy-identity.json').read_text())
for name,digest in policy['files'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
source=json.loads((r/'source-hashes.json').read_text())
for name,digest in source.items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==digest
for name,digest in json.loads((r/'live-export-sha256.json').read_text()).items():assert hashlib.sha256((repo/'web/public/data'/name).read_bytes()).hexdigest()==digest
report=dict(expected_remote=expected,actual_remote=remote,active_release_chains=active,ignored_stale_quality=ignored_stale_quality,pending_pages_event=pending_pages,observed_chains=observed,allowed=remote==expected and not active and not pending_pages,source_resources=len(source),release_policies=len(policy['files']),export_identities=169)
(r/'latest-main-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));sys.exit(0 if report['allowed'] else 2)
