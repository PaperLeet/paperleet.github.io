from pathlib import Path
import subprocess,json,hashlib,sys
p=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');python=sys.executable
git=lambda *a:subprocess.check_output(['git',*a],cwd=repo,text=True).strip();call=lambda *a,cwd=p:subprocess.run(list(map(str,a)),cwd=cwd,check=True)
baseline=json.loads((p/'context.json').read_text())['upstream'];assert git('rev-parse','HEAD')==baseline;call(python,p/'audit-main.py',baseline)
j=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-67.json').read_text());assert j['status']=='validated_locally' and j['baseline_main']==baseline
for name,digest in j['source_hashes'].items():assert hashlib.sha256((repo/'packages/stridetorch/src/stridetorch'/name).read_bytes()).hexdigest()==digest
for name,digest in j['owned_inputs'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
for name,digest in j['test_hashes'].items():assert hashlib.sha256((repo/'packages/stridetorch/tests'/name).read_bytes()).hexdigest()==digest
assert hashlib.sha256((repo/'packages/stridetorch/benchmarks/results'/j['raw_archive']['name']).read_bytes()).hexdigest()==j['raw_archive']['sha256']
expected=json.loads((p/'expected-commit-paths.json').read_text());paths=[b[3:].decode() for b in subprocess.check_output(['git','status','--porcelain','-z'],cwd=repo).split(b'\0') if b];assert len(expected)==181 and sorted(paths)==expected,(set(paths)^set(expected))
call('git','add','--',*expected,cwd=repo);assert git('diff','--cached','--name-only').splitlines()==expected;call('git','diff','--cached','--check',cwd=repo);call('git','commit','--quiet','-m','perf(torch): release consumed joint callbacks and reduce inverse temporaries',cwd=repo)
source=git('rev-parse','HEAD');print('SOURCE_COMMIT',source,flush=True);call(python,p/'push-main-node.py',baseline);call(python,p/'record-adoption.py')
proof=['docs/validation/torch-runtime-iteration-67.md','packages/stridetorch/benchmarks/results/iteration-67-main-adoption.json'];call('git','add','--',*proof,cwd=repo);assert git('diff','--cached','--name-only').splitlines()==proof;call('git','commit','--quiet','-m','docs(torch): record validated0.67 main adoption',cwd=repo);print('PROOF_COMMIT',git('rev-parse','HEAD'),flush=True);call(python,p/'push-main-node.py',source);call(python,p/'verify-adoption.py');print('ITERATION67 ADOPTED; GOAL REMAINS ACTIVE',flush=True)
