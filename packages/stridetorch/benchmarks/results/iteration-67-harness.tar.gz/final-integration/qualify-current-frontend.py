from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).resolve().parent.parent;i=r/'final-integration';repo=Path('/Users/david/Developer/PaperLeet-torch-release');receipts=[];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();baseline=json.loads((i/'context.json').read_text())['upstream'];env=dict(os.environ,PYTHON=str(r.parent/'torch-iteration-21/stride-dev-env/bin/python'));env['PATH']='/Users/david/.npm/_npx/d18f28baf1132559/node_modules/node/bin:/opt/homebrew/bin:'+str(Path(env['PYTHON']).parent)+':'+env['PATH'];env['PYTHONPATH']=os.pathsep.join([str(repo/'packages/stridetorch/src'),str(repo)])
value=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/actions/variables/PAPERLEET_MAIN_SITE_ENABLED','--jq','.value'],text=True).strip()
profile=dict(PAPERLEET_MAIN_SITE_ENABLED=value,VITE_PUBLIC_SITE='0' if value=='1' else '1',VITE_APP_EDITION='hosted' if value=='1' else 'local',VITE_API_ORIGIN='https://app.paperleet.com' if value=='1' else '',VITE_HOSTED_APP_AVAILABLE='1',VITE_HOSTED_APP_URL='https://app.paperleet.com')
(i/'current-pages-profile.json').write_text(json.dumps(dict(observed_value=value,environment=profile),indent=2)+'\n')
checks=['full-frontend-check']
def run(args,label,cwd,extra=None):
 start=time.monotonic()
 with (i/('latest-'+label+'.log')).open('w') as log:p=subprocess.run(args,cwd=cwd,env={**env,**(extra or {})},stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(label=label,args=args,cwd=str(cwd),exit_code=p.returncode,elapsed_s=time.monotonic()-start));(i/'latest-ui-qualification.json').write_text(json.dumps(dict(status='running',upstream=head,full_suite_baseline=baseline,checks=checks,receipts=receipts,scope='Complete current frontend suite after disjoint administrator/taxonomy upstream sync, plus driver/policy/two Node22.23.3 build profiles. All .67 numerical/runtime/application-Python and export bytes preserve their completed full CPU/WASM proof.'),indent=2)+'\n');p.check_returncode();print(label,'TERMINAL 0',flush=True)
for label in checks:run(['npm','run','check'],label,repo/'web')
run(['/Users/david/.npm/_npx/d18f28baf1132559/node_modules/node/bin/node','web/scripts/check-wasm-cases.mjs'],'wasm-driver',repo);run(['/Users/david/.npm/_npx/d18f28baf1132559/node_modules/node/bin/node','web/scripts/check-pages-release.cjs'],'pages-policy',repo)
run(['npm','run','build'],'build',repo/'web');run(['npm','run','build'],'pages-profile-build',repo/'web',json.loads((i/'current-pages-profile.json').read_text())['environment'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
p=i/'latest-ui-qualification.json';j=json.loads(p.read_text());j['status']='qualified';p.write_text(json.dumps(j,indent=2)+'\n');print('LATEST UI QUALIFIED',head,flush=True)
