from pathlib import Path
import json,hashlib,subprocess,datetime
p=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');git=lambda *a:subprocess.check_output(['git',*a],cwd=repo,text=True).strip();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
record=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-67-main-adoption.json').read_text());source=record['source_commit'];proof=git('rev-parse','HEAD');assert git('rev-parse','HEAD^')==source and not git('status','--porcelain')
remote=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/git/ref/heads/main','--jq','.object.sha'],cwd=repo,text=True).strip();assert remote==proof
for name,digest in record['source_resources'].items():
 path='packages/stridetorch/src/stridetorch/'+name;assert sha(repo/path)==digest;assert hashlib.sha256(subprocess.check_output(['git','show',source+':'+path],cwd=repo)).hexdigest()==digest
for name,digest in record['active_export_sha256'].items():assert sha(repo/'web/public/data'/name)==digest
for name,digest in record['canonical_release_policy']['files'].items():assert sha(repo/name)==digest
assert git('diff','--name-only',source,proof).splitlines()==['docs/validation/torch-runtime-iteration-67.md','packages/stridetorch/benchmarks/results/iteration-67-main-adoption.json']
counts={}
for ref in [source,proof]:
 runs=json.loads(subprocess.check_output(['gh','api',f'repos/PaperLeet/paperleet.github.io/actions/runs?head_sha={ref}&per_page=100'],cwd=repo,text=True));assert runs['total_count']==0;counts[ref]=0
result=dict(status='adopted_on_main',version='0.67.0',source_commit=source,proof_commit=proof,observed_remote_main=remote,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actions_runs_by_sha=counts,source_resources=61,active_export_identities=169,immutable_payloads=13729,clean_worktree=True,all_owned_children_terminal=True,scope='Source/proof identities rechecked; no tag, dispatch, release, upload or deployment initiated. Broader independent-library goal remains active.')
(p/'final-adoption-verification.json').write_text(json.dumps(result,indent=2)+'\n');state=json.loads((p/'state.json').read_text());state.update(result,main_adoption_pending=False);(p/'state.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(result),flush=True)
