from pathlib import Path
import json,os,subprocess,time,hashlib
p=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');python=p.parent.parent/'torch-iteration-21/stride-dev-env/bin/python';env=dict(os.environ,PYTHONPATH=os.pathsep.join([str(repo/'packages/stridetorch/src'),str(repo)]),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
expected=json.loads((p/'source-hashes.json').read_text());start=time.time();args=[str(python),'-m','pytest','tests','packages/stridetorch/tests','-q','-p','no:cacheprovider','--basetemp',str(p/'pytest-tmp')]
with (p/'cpu.log').open('w') as out:result=subprocess.run(args,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
actual={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (repo/'packages/stridetorch/src/stridetorch').iterdir() if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']};assert actual==expected
receipt=dict(exit_code=result.returncode,seconds=time.time()-start,args=args,source_hashes=actual,summary=(p/'cpu.log').read_text().splitlines()[-1]);(p/'cpu-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k] for k in ['exit_code','seconds','summary']}),flush=True);result.check_returncode()
