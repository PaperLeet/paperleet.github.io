from pathlib import Path
import hashlib,json
import paperleet,stridetorch
from stridetorch import runtime
import paperleet._vendor.torch as vendored
repo=Path.cwd();proof=Path('/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-67/final-integration');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert Path(paperleet.__file__).resolve().parent==repo/'paperleet'
assert Path(stridetorch.__file__).resolve().parent==repo/'packages/stridetorch/src/stridetorch'
expected=json.loads((proof/'source-hashes.json').read_text())
for folder in [Path(stridetorch.__file__).parent,Path(vendored.__file__).parent]:
 assert {p.name:sha(p) for p in folder.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']}==expected
baseline=json.loads((proof/'baseline-immutable-sha256.json').read_text());assert len(baseline)==13563
for name,digest in baseline.items():assert sha(repo/name)==digest,name
data=repo/'web/public/data';index=json.loads((data/'index.json').read_text());assert len(index['problems'])==82
live={};runtimes={}
def read(name):
 p=data/name;digest=sha(p);assert digest[:20] in p.name;live[name]=digest;return json.loads(p.read_text())
for entry in index['problems']:
 read(entry['detail_url']);bundle=read(entry['browser_judge']['bundle_url']);assert bundle['problem']==entry['id']
 name=bundle['runtime_bundle_url'];payload=read(name);profile='autograd' if payload['backend']=='numpy-autograd-wasm' else 'schedules';files=runtime.source_files(profile);assert all(payload['files'].get(k)==v for k,v in files.items()),entry['id'];runtimes[name]=dict(backend=payload['backend'],package_files=len(files))
all_assets={str(p.relative_to(repo)):sha(p) for directory in ['browser-judge','modules'] for p in (data/directory).glob('*.json')};new={n:h for n,h in all_assets.items() if n not in baseline};assert all(str(Path(n).relative_to('web/public/data')) in live for n in new)
for name in ['index.json','index-v3.json','catalog.json']:live[name]=sha(data/name)
for name,value in [('export-identity.json',dict(status='success',version=stridetorch.__version__,source_hashes=expected,preserved_assets=len(baseline),new_assets=len(new),active_export_and_index_hashes=len(live),catalog_modules=82,all_new_assets_reachable=True,runtimes=runtimes)),('live-export-sha256.json',live),('new-assets-sha256.json',new)]:
 (proof/name).write_text(json.dumps(value,indent=2)+'\n')
print('Verified82 modules;',len(baseline),'preserved assets;',len(new),'new reachable assets;',len(live),'live identities')
