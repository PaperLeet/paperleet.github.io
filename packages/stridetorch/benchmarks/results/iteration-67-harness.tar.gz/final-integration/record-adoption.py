from pathlib import Path
import json,hashlib,subprocess,datetime
p=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
git=lambda *a:subprocess.check_output(['git',*a],cwd=repo,text=True).strip();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
head=git('rev-parse','HEAD');remote=subprocess.check_output(['gh','api','repos/PaperLeet/paperleet.github.io/git/ref/heads/main','--jq','.object.sha'],cwd=repo,text=True).strip();assert head==remote and not git('status','--porcelain')
runs=json.loads(subprocess.check_output(['gh','api',f'repos/PaperLeet/paperleet.github.io/actions/runs?head_sha={head}&per_page=100'],cwd=repo,text=True));assert runs['total_count']==0
local=json.loads((repo/'packages/stridetorch/benchmarks/results/iteration-67.json').read_text());source=local['source_hashes'];live=local['active_export_sha256'];policy=local['canonical_release_policy']
for name,digest in source.items():assert sha(repo/'packages/stridetorch/src/stridetorch'/name)==digest
for name,digest in live.items():assert sha(repo/'web/public/data'/name)==digest
for name,digest in policy['files'].items():assert sha(repo/name)==digest
immutable=len(subprocess.check_output(['git','ls-files','-z','--','web/public/data/browser-judge','web/public/data/modules'],cwd=repo).split(b'\0'))-1;assert immutable==13729 and len(source)==61 and len(live)==169
record=dict(status='source_adopted_on_main',version='0.67.0',source_commit=head,observed_remote_main=remote,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actions_runs_for_source_sha=0,source_resources=source,active_export_sha256=live,canonical_release_policy=policy,immutable_payloads=immutable,scope='Ordinary non-force main adoption after exact-source complete41705 CPU plus1skip,82 exported WASM modules/359 mutants under original budgets,8071 Node/Chrome contracts,8084 installed NumPy-only tests, both namespace ownership/alias/checkpoint/fresh-pickle gates, complete frontend after disjoint UI sync and both Node22 builds. Frozen formal comparisons and version-only provenance retained. No tag, workflow dispatch, release, upload or deployment initiated. Independent-library/core/backend goal remains active.')
(repo/'packages/stridetorch/benchmarks/results/iteration-67-main-adoption.json').write_text(json.dumps(record,indent=2)+'\n')
doc=repo/'docs/validation/torch-runtime-iteration-67.md';s=doc.read_text();assert '## Main adoption' not in s;s+=f'''\n## Main adoption

Validated source `{head}` was adopted on remote main by an ordinary non-force
push, with zero observed Actions runs for that SHA. All 61 runtime resources,
169 active export/index identities, 13,729 immutable payloads and seven unchanged
upstream policy files were verified. A separate proof commit records this result.
No tag, workflow dispatch, release, package upload or deployment was initiated.
The overall independent-library efficiency/core/backend goal remains active.
''';doc.write_text(s);print('RECORDED SOURCE MAIN',head,flush=True)
