from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent;python=str(r.parent/'torch-iteration-21/stride-dev-env/bin/python')
for script in ['run-edge-proof.py','run-edge-cpu.py']:subprocess.run([python,script],cwd=r,check=True)
