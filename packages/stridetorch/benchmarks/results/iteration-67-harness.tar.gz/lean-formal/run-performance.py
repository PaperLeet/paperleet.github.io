from pathlib import Path
import hashlib,json,os,subprocess,time

r=Path(__file__).resolve().parent;repo=r.parent
py=r.parent.parent/'torch-iteration-21/stride-dev-env/bin/python'
bench=r/'chrome-contracts/bench_determinants.py'
plan=json.loads((r/'chrome-contracts/bench-plan.json').read_text())
env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
for name,h in plan['candidate'].items():assert hashlib.sha256((r/'chrome-contracts/source'/name).read_bytes()).hexdigest()==h
assert hashlib.sha256(bench.read_bytes()).hexdigest()==plan['benchmark_sha256']
def frozen_inputs():
    for label,folder in [('baseline', 'baseline'),('candidate','source')]:
        actual={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (r/'chrome-contracts'/folder).iterdir() if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']}
        assert actual==plan[label]
    actual={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (repo/'lean-source/stridetorch').iterdir() if f.suffix=='.py' or f.name in ['LICENSE','NOTICE']}
    assert actual==plan['candidate']
    for name,key in [('bench_determinants.py','benchmark_sha256'),('bench_inverse.py','inverse_benchmark_sha256'),('bench_joint.py','joint_benchmark_sha256')]:assert hashlib.sha256((r/'chrome-contracts'/name).read_bytes()).hexdigest()==plan[key]
for path in ['lean-sdk/receipts.json','lean-oracle/receipts.json','lean-minimum/receipts.json']:
    assert all(v['status']=='success' for v in json.loads((repo/path).read_text()))
api=json.loads((repo/'lean-native-api-receipt.json').read_text());assert api['exit_code']==0 and api['source_hashes']==plan['candidate']
frozen_inputs()
dest=r/'performance';dest.mkdir();receipts=[]
for repeat in range(4):
    for runtime in (['cpu','node','chrome'] if repeat%2==0 else ['chrome','node','cpu']):
        label=f'{runtime}-{repeat}'
        if runtime=='cpu':args=[str(py),str(r/'bench-combined.py'),str(r/'chrome-contracts/baseline'),str(r/'chrome-contracts/source')]
        elif runtime=='node':args=['/opt/homebrew/bin/node',str(r/'bench-node.mjs')]
        else:args=['/opt/homebrew/bin/node',str(r/'chrome-contracts/bench-run.mjs')]
        frozen_inputs()
        load_before=list(os.getloadavg());started=time.monotonic()
        with (dest/(label+'.log')).open('w') as log:
            child=subprocess.run(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
        receipts.append(dict(label=label,args=args,exit_code=child.returncode,elapsed_s=time.monotonic()-started,host_load_before=load_before,host_load_after=list(os.getloadavg())))
        (dest/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
        print(label,'TERMINAL',child.returncode,flush=True);child.check_returncode()
        if runtime=='cpu':data=json.loads((dest/(label+'.log')).read_text())
        else:
            path=r/('bench-node-result.json' if runtime=='node' else 'chrome-contracts/bench-result.json')
            data=json.loads(path.read_text());assert data['numpy']=='2.2.5'
            assert data['benchmark_sha256']==plan['benchmark_sha256']
        actual=data.get('benchmark',data)
        assert actual['source_hashes']==dict(baseline=plan['baseline'],candidate=plan['candidate'])
        assert len(actual['rows'])==100
        extra=actual['inverse_benchmark'];assert len(extra['rows'])==44 and extra['source_hashes']==actual['source_hashes'] and extra['program_sha256']==plan['inverse_benchmark_sha256']
        joint=actual['joint_benchmark'];assert len(joint['rows'])==26 and joint['source_hashes']==actual['source_hashes'] and joint['program_sha256']==plan['joint_benchmark_sha256'] and joint['fixture_hashes']==plan['joint_fixture_sha256']
        (dest/(label+'.json')).write_text(json.dumps(data,indent=2)+'\n')
frozen_inputs()
(dest/'identity.json').write_text(json.dumps(dict(status='success',all_children_terminal=True,children=12,
    source_hashes=dict(baseline=plan['baseline'],candidate=plan['candidate']),benchmark_sha256=plan['benchmark_sha256'],inverse_benchmark_sha256=plan['inverse_benchmark_sha256'],joint_benchmark_sha256=plan['joint_benchmark_sha256'],joint_fixture_sha256=plan['joint_fixture_sha256'],
    thread_caps={k:env[k] for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','VECLIB_MAXIMUM_THREADS']}),indent=2)+'\n')
