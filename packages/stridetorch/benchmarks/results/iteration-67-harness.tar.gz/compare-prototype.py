from pathlib import Path
import json,sys
import bench_inverse,bench_joint
result=bench_inverse.run(sys.argv[1],sys.argv[2]);result['joint_benchmark']=bench_joint.run(sys.argv[1],sys.argv[2]);assert len(result['rows'])==44 and len(result['joint_benchmark']['rows'])==26;print(json.dumps(result,indent=2))
