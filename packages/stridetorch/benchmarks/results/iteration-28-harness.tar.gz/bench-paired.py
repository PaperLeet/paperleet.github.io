"""Same-interpreter paired blocks for the short-run WASM metadata anomalies."""
import contextlib,gc,hashlib,importlib.util,json,os,statistics,sys,time
from pathlib import Path
import numpy as np

dtype=globals().get('bench_dtype',os.environ.get('BENCH_DTYPE','float64'))
paths=globals().get('bench_sources') or json.loads(os.environ['BENCH_SOURCES'])
packages={};hashes={}
for label,path in paths.items():
 root=Path(path);name='paired_'+label;spec=importlib.util.spec_from_file_location(name,root/'__init__.py',submodule_search_locations=[str(root)])
 package=importlib.util.module_from_spec(spec);sys.modules[name]=package;spec.loader.exec_module(package);packages[label]=package
 hashes[label]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
assert packages['baseline'].__version__=='0.27.0' and packages['candidate'].__version__=='0.28.0'
rows={}
for operation,shape,recording in [('permute',(2,2,2,2,2,2),False),('transpose',(2,2,2,2,2,2),True),('transpose',(2,3,4),False),('exp',(128,),False)]:
 name=operation+'_'+'x'.join(map(str,shape))+'_'+str(recording);callbacks={};inputs={};axes=tuple(range(1,len(shape)))+(0,)
 raw=np.arange(int(np.prod(shape)),dtype=dtype).reshape(shape)/int(np.prod(shape))
 for label,package in packages.items():
  x=package.torch.from_numpy(raw).requires_grad_();assert str(x.dtype)==dtype;inputs[label]=x
  callbacks[label]=(lambda x=x:x.permute(axes)) if operation=='permute' else (lambda x=x:x.transpose(0,-1)) if operation=='transpose' else (lambda x=x:x.exp())
 with contextlib.ExitStack() as stack:
  if not recording:
   for p in packages.values():stack.enter_context(p.torch.no_grad())
  expected=raw.transpose(axes) if operation=='permute' else np.swapaxes(raw,0,-1) if operation=='transpose' else np.exp(raw)
  for fn in callbacks.values():
   for _ in range(1000):fn()
   np.testing.assert_array_equal(fn().detach().numpy(),expected)
  gc.collect();gc.disable();blocks=[]
  try:
   for i in range(13):
    order=('baseline','candidate','candidate','baseline') if i%2==0 else ('candidate','baseline','baseline','candidate');samples={'baseline':[],'candidate':[]}
    for label in order:
     fn=callbacks[label];start=time.perf_counter()
     for _ in range(2500):fn()
     samples[label].append((time.perf_counter()-start)*1000/2500)
    blocks.append(dict(samples_ms=samples,time_reduction_percent=100*(1-statistics.mean(samples['candidate'])/statistics.mean(samples['baseline']))))
  finally:gc.enable()
  for fn in callbacks.values():np.testing.assert_array_equal(fn().detach().numpy(),expected)
 rows[name]=dict(median_paired_time_reduction_percent=statistics.median(b['time_reduction_percent'] for b in blocks),blocks=blocks)
result=dict(dtype=dtype,python=sys.version,numpy=np.__version__,source_hashes=hashes,results=rows,scope='Two isolated package namespaces share one NumPy interpreter.13 ABBA/BAAB paired blocks;1000warmups;2500calls per block. Targeted follow-up only;not a replacement for fresh-process results or an application throughput claim.')
if 'bench_dtype' not in globals():print(json.dumps(result))
