from pathlib import Path
import hashlib,json,subprocess,tarfile

r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=repo/'packages/stridetorch/benchmarks/results';proof=r/'proof-final'
def read(p):return json.loads(p.read_text())
def hashes(p):return {x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in p.iterdir() if x.is_file() and (x.suffix=='.py' or x.name in ('LICENSE','NOTICE'))}
source=hashes(repo/'packages/stridetorch/src/stridetorch');assert len(source)==45
assert source==hashes(r/'trial-transpose/stridetorch')==hashes(proof/'source')==hashes(proof/'chrome-contracts/source')
node=read(proof/'source-wasm.json');chrome=read(proof/'chrome-contracts/result.json');wheel=read(proof/'wheel-stride028-result.json');coinstall=read(proof/'coinstall-result.json');performance=read(r/'performance-transpose-summary.json');paired=read(r/'paired-summary.json');native=read(r/'native-ci.json')
for record in (node,chrome,wheel,coinstall):assert record['source_hashes']==source
assert node['passed']==chrome['passed']==881 and node['library']==chrome['library']=='0.28.0'
assert chrome['status']==wheel['status']==coinstall['status']=='success'
assert '29402 passed, 1 skipped' in (r/'full-native-final.log').read_text()
assert '3741 passed' in (r/'focused-transpose.log').read_text()
assert '893 passed' in (proof/'python310-stride028-tests.log').read_text()
assert native['passed'] and native['problems']==78 and native['tests_executed']==10218 and native['repeats']==3 and not native['issues'] and sum(map(len,native['mutation'].values()))==342
assert performance['source_hashes']['trial-transpose']==paired['source_hashes']['candidate']==source
assert len(performance['receipts'])==16 and len(paired['receipts'])==8 and all(x['exit_code']==0 for x in (*performance['receipts'],*paired['receipts']))
for receipt in performance['receipts']:
 data=read(r/'performance-transpose'/(receipt['name']+'.json'));assert len(data['cases'])==6
 assert all(x['dtype']==x['seed_dtype']==x['gradient_dtype']==receipt['dtype'] for x in data['cases'].values())
plan=read(proof/'chrome-contracts/plan.json')
assert chrome['test_hashes']==plan['tests']=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'}
assert len(plan['tests'])==28
report=dict(status='local_core_gates_passed_application_integration_pending',version='0.28.0',baseline_commit='f1b33b0be7b47bb9e06ff92ba60a5032fb8cea06',source_hashes=source,adopted_source='trial-transpose/stridetorch',adopted_proof='proof-final',base=dict(passed=29402,optional_skips=1,warnings=34,elapsed_s=190.93),focused_passed=3741,minimum=dict(passed=893,python=wheel['python'],numpy=wheel['numpy'],native_torch=wheel['native_torch'],artifacts=wheel['artifacts']),node=node,chrome=chrome,coinstall=coinstall,native_catalog={k:v for k,v in native.items() if k!='mutation'},native_mutants=342,native_scope='Original catalog executed with nativeTorch;not a substitute for final shim exported-VM gates',performance=performance,paired_followup=paired,metadata_cache=dict(max_entries=32,contents='Normalized integer-axis tuples and inverse tuples only;no arrays,tensors,graphs,values,seeds or gradients',forward_path='Permute unchanged;transpose valid builtin integer path reads rank once'),earlier_trials={'candidate':'Eager per-node inversion;recorded forward regressions','trial-lazy':'Lazy per-node inverse cache;extra forward/closure costs','trial-cache':'Bounded shared axis cache before scalar-transpose parsing fix;earlier proof folder uses this variant','performance-steady':'Extended-sample follow-up of pre-transpose-fix cache source','trial-transpose':'Adopted scalar-schema/inline-transpose source;final extended fresh and paired measurements'},failed_checks_retained=['Initial draft187fixture failures:complex NumPy scalars instead of ndarrays and unsupported direct nonleaf mutations;corrected without expanding inplace autograd','Transient short-run training and final fresh-process rank-six metadata timing anomalies retained;paired follow-up is additional evidence,not replacement'],scope='Matrix/axis API family,scalar-schema parity and bounded geometry caching;no complex AD,lazy conjugation,symbolic/named axes,higher-order expansion or new backend',remaining=['Merge latest main UI/docs changes while preserving every published immutable file','Full actual exported WASM with CI concurrency2 and latest frontend/profile/application packaging','Non-force main adoption and exact remoteQuality','Eligible actual Pages deployment and frozen live-byte verification'])
(r/'local-gates.json').write_text(json.dumps(report,indent=2)+'\n');(r/'implementation.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=repo))
files={}
def add(p,name=None):
 if p.is_file():files[name or str(p.relative_to(r))]=p
for folder in ('baseline/stridetorch','candidate/stridetorch','trial-lazy/stridetorch','trial-cache/stridetorch','trial-transpose/stridetorch','short-harness','steady-harness','performance','performance-lazy','performance-cache','performance-steady','performance-transpose','performance-paired','proof/source','proof/chrome-contracts','proof/dist-preflight','proof/private-dist','proof/python310-stride028-tests','proof-final/source','proof-final/chrome-contracts','proof-final/dist-preflight','proof-final/private-dist','proof-final/python310-stride028-tests'):
 for p in (r/folder).rglob('*'):
  if '__pycache__' not in p.parts and '.pytest_cache' not in p.parts:add(p)
for folder in (r,r/'proof',proof):
 for p in folder.iterdir():
  if p.suffix in ('.py','.mjs','.json','.log','.patch'):add(p)
for name in ('tests/test_torch_axis_transforms.py','packages/stridetorch/tests/test_axis_transforms.py','packages/stridetorch/README.md','packages/stridetorch/pyproject.toml','docs/validation/torch-runtime-iteration-28.md'):add(repo/name,'maintained/'+name)
archive=out/'iteration-28-harness.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
report['archive']=dict(file=archive.name,files=len(files),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest());(out/'iteration-28.json').write_text(json.dumps(report,indent=2)+'\n')
state=read(r/'state.json');state.update(phase='0.28 final complete core gates passed and archived;latest application integration pending',local_report=str(out/'iteration-28.json'),archive=report['archive'],next=report['remaining']);(r/'state.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(dict(status=report['status'],archive=report['archive'])))
