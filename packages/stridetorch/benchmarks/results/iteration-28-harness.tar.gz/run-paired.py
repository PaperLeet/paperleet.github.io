from pathlib import Path
import hashlib,json,os,subprocess,time
r=Path(__file__).parent;out=r/'performance-paired';out.mkdir(exist_ok=True);paths={'baseline':str(r/'baseline/stridetorch'),'candidate':str(r/'trial-transpose/stridetorch')};receipts=[]
def hashes(p):return {x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in Path(p).iterdir() if x.suffix=='.py' or x.name in ('LICENSE','NOTICE')}
expected={k:hashes(p) for k,p in paths.items()}
for backend in ('cpu','wasm'):
 for dtype in ('float32','float64'):
  for repeat in range(2):
   name=f'{backend}-{dtype}-{repeat}';env=dict(os.environ,BENCH_DTYPE=dtype,BENCH_SOURCES=json.dumps(paths),OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2');cmd=['/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-21/stride-dev-env/bin/python',str(r/'bench-paired.py')] if backend=='cpu' else ['/opt/homebrew/bin/node',str(r/'bench-paired-wasm.mjs'),paths['baseline'],paths['candidate'],dtype]
   start=time.monotonic()
   with (out/(name+'.json')).open('w') as stdout,(out/(name+'.log')).open('w') as stderr:p=subprocess.run(cmd,env=env,stdout=stdout,stderr=stderr)
   receipts.append(dict(name=name,exit_code=p.returncode,elapsed_s=time.monotonic()-start,command=cmd));(r/'paired-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode();result=json.loads((out/(name+'.json')).read_text());assert result['source_hashes']==expected;assert expected=={k:hashes(p) for k,p in paths.items()};print(name,'terminal0',flush=True)
(r/'paired-summary.json').write_text(json.dumps(dict(status='success',source_hashes=expected,receipts=receipts,results={p.stem:json.loads(p.read_text())['results'] for p in out.glob('*.json')}),indent=2)+'\n');print('ALL8TERMINAL0',flush=True)
