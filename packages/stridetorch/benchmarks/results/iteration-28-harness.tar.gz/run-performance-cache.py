from pathlib import Path
import hashlib,json,os,statistics,subprocess,time,shutil
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');out=r/'performance-cache';out.mkdir(exist_ok=True)
python='/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-21/stride-dev-env/bin/python'
sources={label:r/label/'stridetorch' for label in ('baseline','trial-cache')}
def hashes(p):return {x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in p.iterdir() if x.is_file() and (x.suffix=='.py' or x.name in ('LICENSE','NOTICE'))}
expected={k:hashes(p) for k,p in sources.items()};receipts=[]
for backend in ('cpu','wasm'):
 for dtype in ('float32','float64'):
  for i,label in enumerate(('baseline','trial-cache','trial-cache','baseline')):
   assert all(hashes(p)==expected[k] for k,p in sources.items())
   name=f'{backend}-{dtype}-{i}-{label}';env=dict(os.environ,PYTHONPATH=str(sources[label].parent),BENCH_DTYPE=dtype,OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2')
   args=[python,str(r/'bench-permute.py')] if backend=='cpu' else ['/opt/homebrew/bin/node',str(r/'bench-wasm.mjs'),str(sources[label]),dtype]
   started=time.monotonic()
   with (out/(name+'.json')).open('w') as stdout,(out/(name+'.log')).open('w') as stderr:
    p=subprocess.run(args,env=env,cwd=r,stdout=stdout,stderr=stderr)
   receipts.append(dict(name=name,backend=backend,dtype=dtype,label=label,exit_code=p.returncode,elapsed_s=time.monotonic()-started,args=args))
   (r/'performance-cache-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode()
   result=json.loads((out/(name+'.json')).read_text());assert result['source_hashes']==expected[label]
   print(name,'terminal0',flush=True)
summary=dict(status='success',source_hashes=expected,receipts=receipts,scope='Fresh sequential ABBA processes;9 batches/3 warmups. CPU requests2 BLAS threads,actual BLAS threading unverified;shared host. No owned tests/builds overlap timing. Matching old permute APIs only;new t/mT/movedim/moveaxis/swap aliases excluded from speedup claims. Metadata views,recorded forward,retained VJP and full square/backward measured separately. All actual parameter/seed/gradient dtypes asserted. No cold-start/application/peak-memory claims.',results={})
for backend in ('cpu','wasm'):
 for dtype in ('float32','float64'):
  inputs={label:[json.loads((out/(x['name']+'.json')).read_text()) for x in receipts if x['backend']==backend and x['dtype']==dtype and x['label']==label] for label in sources};rows={}
  for name in inputs['baseline'][0]['results']:
   a=[x['results'][name]['median_ms'] for x in inputs['baseline']];b=[x['results'][name]['median_ms'] for x in inputs['trial-cache']]
   rows[name]=dict(baseline_medians_ms=a,candidate_medians_ms=b,time_reduction_percent=100*(1-statistics.mean(b)/statistics.mean(a)))
  summary['results'][backend+'-'+dtype]=rows
(r/'performance-cache-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('ALL16TERMINAL0',flush=True)
