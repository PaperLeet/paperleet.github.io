import json,warnings,itertools
import numpy as np
import torch

rows=[]
for shape in ((),(3,),(2,3),(2,1,3),(0,2,3)):
 x=torch.from_numpy(np.arange(int(np.prod(shape)),dtype='float64').reshape(shape)).requires_grad_()
 args=[(0,0),(-1,-1),((),()),((0,),(-1,)),((0,1),(1,)),((0,1),(0,0)),((0,-1),(0,-1)),
       (0,(0,)),((0,),0),(True,0),((True,),(0,)),(None,0),(1.2,0),(np.int64(0),np.int64(0)),
       (np.array(0),0),(np.array([0]),(0,)),(torch.tensor(0),0),((0,0),(0,0)),((0,-1),(0,1))]
 for a,b in args:
  row=dict(shape=shape,source=repr(a),destination=repr(b))
  try:
   y=x.movedim(a,b);row.update(status='ok',identity=y is x,shape_out=tuple(y.shape),stride=y.stride(),requires_grad=y.requires_grad,is_leaf=y.is_leaf)
  except Exception as e:row.update(status=type(e).__name__)
  rows.append(row)
print(json.dumps(dict(native=torch.__version__,rows=rows),indent=2))
