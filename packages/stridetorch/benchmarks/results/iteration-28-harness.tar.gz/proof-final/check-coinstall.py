from pathlib import Path
import hashlib,json,os,subprocess,time,zipfile
r=Path(__file__).parent;expected=json.loads((r/'source-hashes.json').read_text());public=next((r/'dist-preflight').glob('*.whl'));private=next((r/'private-dist').glob('*.whl'));uv='/Users/david/.local/bin/uv';env=os.environ.copy();env.pop('PYTHONPATH',None);receipts=[]
for wheel,prefix in [(public,'stridetorch/'),(private,'paperleet/_vendor/torch/')]:
 with zipfile.ZipFile(wheel) as z:
  actual={n.removeprefix(prefix):hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith(prefix)}
  assert actual==expected,(wheel,actual.keys()^expected.keys())
venv=r/'coinstall-env';python=venv/'bin/python'
def run(cmd,label):
 start=time.monotonic()
 with (r/(label+'.log')).open('w') as log:p=subprocess.run([str(x) for x in cmd],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipts.append(dict(label=label,command=[str(x) for x in cmd],exit_code=p.returncode,elapsed_s=time.monotonic()-start));(r/'coinstall-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');p.check_returncode();print(label,'terminal0',flush=True)
run([uv,'venv','--clear',venv,'--python','/Users/david/.local/share/uv/python/cpython-3.10.19-macos-aarch64-none/bin/python3.10'],'coinstall-venv')
run([uv,'pip','install','--python',python,'--no-deps','numpy==1.26.4',public,private],'coinstall-install')
check="""import importlib,importlib.util,hashlib,json,pathlib
expected=json.loads(pathlib.Path('source-hashes.json').read_text())
for name in NAMES:
 m=importlib.import_module(name);p=pathlib.Path(m.__file__).parent
 actual={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in p.iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')}
 assert actual==expected and m.__version__=='0.28.0'
 t=m.torch;x=t.tensor([1.,float('nan'),3.],requires_grad=True);y=t.nanmean(x);assert y.item()==2.;y.backward();assert x.grad.tolist()==[.5,0.,.5]
assert importlib.util.find_spec('torch') is None
import numpy as np
for name in NAMES:
 t=importlib.import_module(name).torch
 x=t.from_numpy(np.array([[1.,2.,3.],[4.,5.,6.]],order='F')).requires_grad_()
 x.sum().backward();assert x.grad.stride()==x.stride()
 assert x.t().shape==(3,2) and x.mT.stride()==(2,1)
 assert t.movedim(x,0,1).shape==(3,2)
 y=x*2;y.retain_grad();y.sum().backward(retain_graph=True);old=y.grad
 y.sum().backward();assert y.grad is not old;assert old.tolist()==[[1.,1.,1.],[1.,1.,1.]]
print('PASS isolated module ownership and NaN pullback')
"""
run([python,'-c','NAMES='+repr(['stridetorch','paperleet._vendor.torch'])+'\n'+check],'coinstall-both')
run([uv,'pip','uninstall','--python',python,'paperleet'],'coinstall-uninstall-private')
run([python,'-c',"NAMES=['stridetorch']\n"+check],'coinstall-public-survives')
run([uv,'pip','install','--python',python,'--no-deps',private],'coinstall-reinstall-private')
run([uv,'pip','uninstall','--python',python,'stridetorch'],'coinstall-uninstall-public')
run([python,'-c',"NAMES=['paperleet._vendor.torch']\n"+check+"\nassert importlib.util.find_spec('stridetorch') is None"],'coinstall-private-survives')
(r/'coinstall-result.json').write_text(json.dumps(dict(status='success',source_hashes=expected,wheels={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (public,private)},receipts=receipts,scope='Both no-deps distributions coinstalled in a new NumPy-only Python3.10 environment; both namespaces execute nanmean/VJP; uninstall each owner without changing the other; native Torch absent. This is not an installed PaperLeet application dependency gate.'),indent=2)+'\n')
