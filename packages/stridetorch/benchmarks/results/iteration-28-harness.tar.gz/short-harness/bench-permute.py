import gc,hashlib,json,os,platform,statistics,sys,time
from pathlib import Path
import numpy as np
import stridetorch
from stridetorch import torch

dtype=globals().get('bench_dtype',os.environ.get('BENCH_DTYPE','float32'));results={};cases={}
def measure(name,operation,check,calls):
 for _ in range(3):operation()
 check();gc.collect();gc.disable();samples=[]
 try:
  for _ in range(9):
   start=time.perf_counter()
   for _ in range(calls):operation()
   samples.append((time.perf_counter()-start)*1000/calls)
 finally:gc.enable()
 check();results[name]=dict(median_ms=statistics.median(samples),samples_ms=samples,calls=calls)

for shape in ((2,3,4),(2,2,2,2,2,2),(16,32,64)):
 data=np.arange(int(np.prod(shape)),dtype=dtype).reshape(shape)/int(np.prod(shape));axes=tuple(range(1,len(shape)))+(0,)
 x=torch.from_numpy(data).requires_grad_();assert x.dtype==getattr(torch,dtype)
 expected=np.transpose(data,axes);label='x'.join(map(str,shape))
 def check_forward():
  y=x.permute(axes);assert y.dtype==getattr(torch,dtype) and y._storage is x._storage
  np.testing.assert_array_equal(y.detach().numpy(),expected)
 with torch.no_grad():measure(label+'_forward_nograd',lambda:x.permute(axes),check_forward,500)
 measure(label+'_forward_recording',lambda:x.permute(axes),check_forward,500)
 y=x.permute(axes);raw=np.linspace(-.3,.7,y.numel(),dtype=dtype).reshape(y.shape);seed=torch.from_numpy(raw)
 inverse=tuple(np.argsort(axes));expected_gradient=np.transpose(raw,inverse)
 def reverse():return torch.autograd.grad(y,x,grad_outputs=seed,retain_graph=True)[0]
 def check_reverse():
  g=reverse();assert g.dtype==getattr(torch,dtype);np.testing.assert_array_equal(g.numpy(),expected_gradient)
 measure(label+'_retained_vjp',reverse,check_reverse,500)
 def training():
  x.grad=None;x.permute(axes).square().sum().backward()
 def check_training():
  assert x.grad.dtype==getattr(torch,dtype);np.testing.assert_array_equal(x.grad.numpy(),data*2)
 measure(label+'_square_backward',training,check_training,100 if x.numel()<1000 else 30)
 cases[label]=dict(dtype=str(x.dtype),shape=x.shape,input_stride=x.stride(),axes=axes,output_stride=y.stride(),seed_dtype=str(seed.dtype),gradient_dtype=str(reverse().dtype))
control=torch.ones(128,dtype=getattr(torch,dtype))
measure('exp_control',lambda:control.exp(),lambda:np.testing.assert_allclose(control.exp().numpy(),np.full(128,np.e),rtol=2e-6),500)
source=Path(stridetorch.__file__).parent
result=dict(library=stridetorch.__version__,python=sys.version,numpy=np.__version__,platform=platform.platform(),dtype=dtype,results=results,cases=cases,source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')})
if 'bench_dtype' not in globals():print(json.dumps(result))
