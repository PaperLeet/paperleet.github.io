import ast, cProfile, hashlib, json, pstats, time
from pathlib import Path
import numpy as np
import yaml
from paperleet_torch import install_as_torch, __version__
install_as_torch()
import torch
from paperleet.common.models import TimeMLP
from paperleet.common.toydata import eight_gaussians
from paperleet.common.metrics import mmd_rbf, mode_coverage
import importlib.util

problem = Path('/repo/problems/diffusion/flow_matching')
spec = importlib.util.spec_from_file_location('flow_solution', problem / 'solution.py')
impl = importlib.util.module_from_spec(spec)
spec.loader.exec_module(impl)
test = problem / 'tests/test_flow.py'
tree = ast.parse(test.read_text(), filename=str(test))
function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'test_learns_eight_modes')
function.decorator_list = []
__file__ = str(test)
exec(compile(ast.Module(body=[function], type_ignores=[]), str(test), 'exec'))
artifacts = {}
def artifact(key, value):
    if isinstance(value, torch.Tensor):
        artifacts[key] = dict(shape=list(value.shape), dtype=str(value.dtype), sha256=hashlib.sha256(value._data.tobytes()).hexdigest())
    else:
        artifacts[key] = value
profiler = cProfile.Profile()
profiler.runcall(test_learns_eight_modes, impl, artifact)
profiler.dump_stats('/flow-training.prof')
stats = pstats.Stats(profiler)
rows = []
for (filename, line, name), (primitive, calls, own, cumulative, callers) in stats.stats.items():
    rows.append(dict(file=filename, line=line, name=name, primitive_calls=primitive, calls=calls, own_s=own, cumulative_s=cumulative))
report = dict(status='success', numpy=np.__version__, library=__version__, artifacts=artifacts,
              total_calls=stats.total_calls, total_profile_s=stats.total_tt,
              own=sorted(rows,key=lambda row:row['own_s'],reverse=True)[:80],
              cumulative=sorted(rows,key=lambda row:row['cumulative_s'],reverse=True)[:80],
              scope='Full unchanged 2000-step T3 training, sampling and metrics assertions; profiled diagnostic, not comparable benchmark.')
Path('/flow-profile.json').write_text(json.dumps(report, indent=2) + '\n')
