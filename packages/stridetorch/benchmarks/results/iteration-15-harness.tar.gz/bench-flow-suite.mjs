import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const root=path.dirname(new URL(import.meta.url).pathname),label=process.argv[2],output=process.argv[3];
const plan=JSON.parse(fs.readFileSync(path.join(root,'flow-trial-inputs.json'),'utf8'));
const raw=fs.readFileSync(path.join(root,`flow-${label}-bundle.json`));
assert.equal(createHash('sha256').update(raw).digest('hex'),plan.variants[label].bundle_sha256);
const bundle=JSON.parse(raw);
const py=await loadPyodide({indexURL:'/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/',packageCacheDir:'/Users/david/Developer/PaperLeet-torch-release/web/public/browser-runtime/pyodide-0.29.4/',stdout(){},stderr(){}});
await loadJudgePackages(py,bundle.packages);
py.globals.set('bundle_json',JSON.stringify(bundle));
py.runPython("import json\nbundle=json.loads(bundle_json)\nexec(compile(bundle['harness'],'browser_harness.py','exec'))\nprepare(bundle,bundle['adapter'],'/judge')");
const start=performance.now();
const report=JSON.parse(py.runPython("json.dumps(run_suite(bundle,bundle['reference'],'/judge'))"));
const elapsed=performance.now()-start;
const result={label,elapsed_ms:elapsed,pyodide:py.version,node:process.version,inputs:plan.variants[label],report,
  harness_sha256:createHash('sha256').update(fs.readFileSync(new URL(import.meta.url))).digest('hex'),
  scope:'Full unchanged Flow Matching T0-T3 reference suite including 2000 training steps, 2000-point sampling and distribution metrics; runtime and package preparation excluded.'};
fs.writeFileSync(output,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({label,elapsed_ms:elapsed,passed:report.passed,tests:report.tests.length}));
assert.equal(report.passed,true,JSON.stringify(report.tests.filter(test=>test.status!=='passed')).slice(0,6000));
assert.equal(report.tests.length,8);
