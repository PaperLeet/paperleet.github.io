from pathlib import Path
import hashlib, json, shutil, subprocess

repo = Path.cwd()
root = Path(__file__).parent
target = root / 'frozen-baseline'
assert not target.exists()
inputs = list((repo / 'packages/paperleet-torch/src/paperleet_torch').glob('*.py'))
inputs += [repo / 'packages/paperleet-torch/src/paperleet_torch' / name for name in ('LICENSE', 'NOTICE')]
inputs += list((repo / 'paperleet/common').glob('*.py'))
inputs += [repo / 'paperleet/__init__.py']
inputs += [repo / 'problems/diffusion/flow_matching' / name for name in ('solution.py', 'problem.yaml', 'tests/test_flow.py')]
hashes = {}
for source in inputs:
    relative = source.relative_to(repo)
    destination = target / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    hashes[str(relative)] = hashlib.sha256(source.read_bytes()).hexdigest()
plan = dict(commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
            hashes=hashes, scope='Frozen full 2000-step Flow Matching T3 test; cProfile diagnostic only, no comparative timing claims.')
(root / 'profile-inputs.json').write_text(json.dumps(plan, indent=2) + '\n')
print(json.dumps(dict(files=len(hashes), commit=plan['commit'])))
