from pathlib import Path
import hashlib,json,shutil,subprocess

repo=Path.cwd();root=Path(__file__).parent
base=root/'frozen-baseline/packages/paperleet-torch/src/paperleet_torch'
candidate=root/'frozen-forward-candidate/paperleet_torch'
assert not candidate.exists();candidate.parent.mkdir()
shutil.copytree(base,candidate)
path=candidate/'_nn.py';text=path.read_text();old='    value = x @ w.T\n'
assert text.count(old)==1
new="""    # Direct contractions avoid the slower WASM matmul loop for measured
    # large, contiguous feature vectors. Keep CPU BLAS and small/strided inputs.
    if (_WASM_LINEAR_GRADS and w.shape[1] >= 64 and rows * w.size >= 32768
            and x.strides[-1] == x.itemsize and w.strides[1] == w.itemsize):
        value = np.einsum('...i,oi->...o', x, w, optimize=False)
    else:
        value = x @ w.T
"""
path.write_text(text.replace(old,new))
data=repo/'web/public/data';index=json.loads((data/'index.json').read_text())
entry=next(p for p in index['problems'] if p['id']=='diffusion/flow_matching')
manifest_path=data/entry['browser_judge']['bundle_url'];manifest=json.loads(manifest_path.read_text())
runtime_path=data/manifest['runtime_bundle_url'];runtime=json.loads(runtime_path.read_text())
original={**manifest,'adapter':runtime['adapter'],'harness':runtime['harness'],'files':{**runtime['files'],**manifest['files']}}
plans={}
for label,source in [('baseline',base),('candidate',candidate)]:
    bundle={**original,'files':dict(original['files'])}
    hashes={}
    for source_path in sorted(source.iterdir()):
        if not source_path.is_file() or not (source_path.suffix=='.py' or source_path.name in ('LICENSE','NOTICE')):continue
        raw=source_path.read_bytes();hashes[source_path.name]=hashlib.sha256(raw).hexdigest()
        key='paperleet_torch/'+source_path.name
        if label=='baseline' and key in bundle['files']:assert raw.decode()==bundle['files'][key],key
        bundle['files'][key]=raw.decode()
    output=root/f'flow-{label}-bundle.json';output.write_text(json.dumps(bundle,ensure_ascii=False)+'\n')
    plans[label]=dict(source=str(source),hashes=hashes,bundle_sha256=hashlib.sha256(output.read_bytes()).hexdigest())
(root/'flow-trial-inputs.json').write_text(json.dumps(dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),variants=plans,manifest_sha256=hashlib.sha256(manifest_path.read_bytes()).hexdigest(),runtime_sha256=hashlib.sha256(runtime_path.read_bytes()).hexdigest(),scope='Unreleased prototype; full unchanged Flow Matching test suite, no profiling.'),indent=2)+'\n')
print(json.dumps({k:len(v['hashes']) for k,v in plans.items()}))
