import {loadJudgePackages} from '../../extraction-browser/packages.mjs';
self.onmessage=async({data:{label}})=>{try{
  const {loadPyodide}=await import('../../runtime-0.29.4/pyodide.mjs');
  const py=await loadPyodide({indexURL:new URL('../../runtime-0.29.4/',self.location.href).href,stdout(){},stderr(){}});
  const response=await fetch(`../flow-${label}-bundle.json`);if(!response.ok)throw Error('Missing bundle');
  const raw=await response.arrayBuffer();
  const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',raw)),b=>b.toString(16).padStart(2,'0')).join('');
  const bundle=JSON.parse(new TextDecoder().decode(raw));
  await loadJudgePackages(py,bundle.packages);
  py.globals.set('bundle_json',JSON.stringify(bundle));
  py.runPython("import json\nbundle=json.loads(bundle_json)\nexec(compile(bundle['harness'],'browser_harness.py','exec'))\nprepare(bundle,bundle['adapter'],'/judge')");
  const start=performance.now();
  const report=JSON.parse(py.runPython("json.dumps(run_suite(bundle,bundle['reference'],'/judge'))"));
  self.postMessage({label,elapsed_ms:performance.now()-start,pyodide:py.version,report,bundle_sha256:digest});
}catch(error){self.postMessage({error:String(error.stack||error)});}};
