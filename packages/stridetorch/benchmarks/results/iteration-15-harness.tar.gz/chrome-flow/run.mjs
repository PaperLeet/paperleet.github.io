import fs from 'node:fs';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const plan=JSON.parse(fs.readFileSync(new URL('../flow-trial-inputs.json',import.meta.url)));
const files=['../flow-trial-inputs.json','../flow-baseline-bundle.json','../flow-candidate-bundle.json','worker.mjs','run.mjs'];
const hashes=()=>Object.fromEntries(files.map(name=>[name,createHash('sha256').update(fs.readFileSync(new URL(name,import.meta.url))).digest('hex')]));
const frozen=hashes(),order=['baseline','candidate','candidate','baseline'];
const results=[];
for(const label of order){
  assert.deepEqual(hashes(),frozen);
  const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
  try{
    const page=await browser.newPage();await page.goto('http://127.0.0.1:8766/torch-iteration-15/chrome-flow/');
    const result=await page.evaluate(label=>new Promise((resolve,reject)=>{
      const worker=new Worker('./worker.mjs',{type:'module'});
      const timer=setTimeout(()=>{worker.terminate();reject(Error('Flow suite timeout'));},240000);
      worker.onmessage=({data})=>{clearTimeout(timer);worker.terminate();resolve(data);};
      worker.onerror=event=>{clearTimeout(timer);worker.terminate();reject(Error(event.message));};worker.postMessage({label});
    }),label);
    result.browser=browser.version();assert(!result.error,JSON.stringify(result));
    assert.equal(result.bundle_sha256,plan.variants[label].bundle_sha256);
    results.push(result);
    fs.writeFileSync(new URL('results.json',import.meta.url),JSON.stringify({order,results,frozen_hashes:frozen,
      scope:'Four balanced ABBA fresh entire Chrome processes and Workers; full unchanged Flow Matching suite; no profiling, all samples preserved; preparation excluded.'},null,2)+'\n');
    console.log(JSON.stringify({label,elapsed_ms:result.elapsed_ms,passed:result.report.passed,tests:result.report.tests.length}));
    assert.equal(result.report.passed,true);assert.equal(result.report.tests.length,8);
  }finally{await browser.close();}
}
assert.deepEqual(hashes(),frozen);
