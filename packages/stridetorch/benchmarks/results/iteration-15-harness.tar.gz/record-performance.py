from pathlib import Path
import gzip,hashlib,io,json,statistics,tarfile
import numpy as np

root=Path(__file__).parent;repo=Path.cwd();out=repo/'packages/paperleet-torch/benchmarks/results'
read=lambda name:json.loads((root/name).read_text())
digest=lambda data:hashlib.sha256(data).hexdigest()
canonical=lambda value:json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
plan=read('flow-trial-inputs.json')
actual={p.name:digest(p.read_bytes()) for p in (repo/'packages/paperleet-torch/src/paperleet_torch').iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
assert set(actual)==set(plan['variants']['candidate']['hashes'])
for name,expected in plan['variants']['candidate']['hashes'].items():
    if name!='__init__.py':assert actual[name]==expected,name
prototype=root/'frozen-forward-candidate/paperleet_torch/__init__.py'
assert (repo/'packages/paperleet-torch/src/paperleet_torch/__init__.py').read_text()==prototype.read_text().replace('0.14.0','0.15.0')
def compact(row):
    result={key:value for key,value in row.items() if key!='report'}
    result['report']={key:value for key,value in row['report'].items() if key!='tests'}
    tests=[]
    for test in row['report']['tests']:
        test=dict(test);artifacts=dict(test.get('artifacts',{}))
        for key in ('samples','reference_samples'):
            if key in artifacts:
                value=artifacts[key];artifacts[key]=dict(shape=list(np.asarray(value).shape),sha256=digest(canonical(value)))
        test['artifacts']=artifacts;tests.append(test)
    result['report']['tests']=tests
    return result
node=read('flow-suite-summary.json');chrome=read('chrome-flow/results.json')
node['reports']=[compact(row) for row in node['reports']]
chrome['results']=[compact(row) for row in chrome['results']]
samples={label:[row['elapsed_ms'] for row in chrome['results'] if row['label']==label] for label in ('baseline','candidate')}
chrome['samples_ms']=samples
chrome['time_reduction_percent']=(1-statistics.median(samples['candidate'])/statistics.median(samples['baseline']))*100
raw=[read('flow-suite-samples/00-baseline.json'),read('flow-suite-samples/01-candidate.json')]
artifacts=[row['report']['tests'][-1]['artifacts'] for row in raw]
differences={key:float(np.max(np.abs(np.asarray(artifacts[0][key])-np.asarray(artifacts[1][key])))) for key in ('loss_curve','samples','reference_samples')}
assert artifacts[0]['coverage']==artifacts[1]['coverage']
profile=read('flow-profile-wasm.json')
scripts=['prepare-profile.py','profile-flow.py','profile-flow.mjs','profile-inputs.json',
         'bench-linear-kernels.py','bench-linear-kernels.mjs','run-linear-kernels.py',
         'bench-linear-dispatch.py','bench-linear-dispatch.mjs','run-linear-dispatch.py','linear-dispatch-shapes.json',
         'prepare-flow-trials.py','flow-trial-inputs.json','bench-flow-suite.mjs','run-flow-trials.py',
         'chrome-flow/worker.mjs','chrome-flow/run.mjs','check-wheel-v015.py','record-performance.py']
archive=out/'iteration-15-harness.tar.gz'
with archive.open('wb') as rawfile:
    with gzip.GzipFile(fileobj=rawfile,mode='wb',mtime=0,filename='') as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for name in sorted(scripts):
                data=(root/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644
                tar.addfile(info,io.BytesIO(data))
report=dict(schema_version=1,version='0.15.0',baseline='de4490c9f4fa3825c0fdd9a66d8a569665f92d0d',
    adopted_upstream=read('upstream-invariance.json'),inputs=plan,final_source_hashes=actual,
    release_bridge='All prototype modules/resources identical except package __init__ version 0.14.0 -> 0.15.0; exact bytes asserted.',
    procedure='Completed diagnostic profile first; all actual timing series sequential, without correctness tests/builds/profiling. Fresh balanced ABBA processes per candidate, no removed/normalized samples. Node and Chrome are separate series.',
    profile=dict(scope=profile['scope'],total_profile_s=profile['total_profile_s'],own=profile['own'],cumulative=profile['cumulative'],inputs=profile['inputs'],harness=profile['harness']),
    raw_kernel_comparisons=read('linear-kernel-summary.json'),raw_dispatch_comparisons=read('linear-dispatch-summary.json'),
    selected_dispatch='WASM only, input feature count >=64, rows * weight.size >=32768, both input and weight feature strides equal itemsize. CPU BLAS, shorter features, small or feature-strided inputs preserve matmul.',
    node_full_flow=node,chrome_full_flow=chrome,flow_numeric_differences=differences,
    numerical_scope='The direct contraction changes floating-point reduction order. Full unchanged T0-T3 suites passed in all eight processes; coverage/outlier proportions exactly equal, MMD and loss/sample differences retained. This does not promise bitwise equality or remote deadline compliance.',
    compact_artifacts='All per-process and per-batch timing samples, test outcomes, loss curves, MMD and coverage preserved. Large sample coordinate arrays are SHA256-attested canonical JSON; raw complete reports retained in the local evidence directory.',
    harness_archive=dict(file=archive.name,sha256=digest(archive.read_bytes()),files={name:digest((root/name).read_bytes()) for name in scripts}),
    raw_evidence={str(path.relative_to(root)):digest(path.read_bytes()) for pattern in ('flow-suite-samples/*.json','chrome-flow/results.json','profile-flow.log','focused-native.log') for path in root.glob(pattern)},
    known_tooling_corrections=['First cProfile run completed training assertions but report export requested absent torch.__version__; reran with actual package version. Failed log retained.',
      'Initial new tests incorrectly required an absent zero primal gradient, and used unit-variance weights producing cancellation outside an arbitrary fixed float32 absolute bound in both pre-existing CPU and WASM paths. Test now checks zero math derivative and uses 0.1-scale network weights. Final strict scalar-sum and native checks pass; original failed log retained.'],
    wheel=read('wheel-v015-result.json'))
(out/'iteration-15.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(dict(node_reduction_percent=node['time_reduction_percent'],chrome_reduction_percent=chrome['time_reduction_percent'],differences=differences,archive_sha256=report['harness_archive']['sha256'])))
