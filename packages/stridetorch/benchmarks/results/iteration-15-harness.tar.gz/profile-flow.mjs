import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
const root=path.dirname(new URL(import.meta.url).pathname);
const plan=JSON.parse(fs.readFileSync(path.join(root,'profile-inputs.json'),'utf8'));
const py=await loadPyodide({indexURL:'/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/',packageCacheDir:'/Users/david/Developer/PaperLeet-torch-release/web/public/browser-runtime/pyodide-0.29.4/',stdout(){},stderr(){}});
await py.loadPackage(['numpy','pyyaml']);
for(const [relative,expected] of Object.entries(plan.hashes)){
  const bytes=fs.readFileSync(path.join(root,'frozen-baseline',relative));
  if(createHash('sha256').update(bytes).digest('hex')!==expected)throw Error('Input changed: '+relative);
  const destination=path.posix.join('/repo',relative);
  py.FS.mkdirTree(path.posix.dirname(destination));py.FS.writeFile(destination,bytes);
}
py.FS.writeFile('/profile-flow.py',fs.readFileSync(path.join(root,'profile-flow.py')));
py.runPython("import sys\nsys.path[:0]=['/repo/packages/paperleet-torch/src','/repo']\nexec(compile(open('/profile-flow.py').read(),'/profile-flow.py','exec'))");
const report=JSON.parse(py.FS.readFile('/flow-profile.json',{encoding:'utf8'}));
report.pyodide=py.version;report.inputs=plan;
report.harness=Object.fromEntries(['profile-flow.py','profile-flow.mjs'].map(name=>[name,createHash('sha256').update(fs.readFileSync(path.join(root,name))).digest('hex')]));
fs.writeFileSync(path.join(root,'flow-profile-wasm.json'),JSON.stringify(report,null,2)+'\n');
fs.writeFileSync(path.join(root,'flow-training-wasm.prof'),py.FS.readFile('/flow-training.prof'));
console.log(JSON.stringify({status:report.status,profile_s:report.total_profile_s,own:report.own.slice(0,15)}));
