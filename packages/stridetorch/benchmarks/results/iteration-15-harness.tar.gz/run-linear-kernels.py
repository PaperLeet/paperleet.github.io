from pathlib import Path
import hashlib,json,subprocess,statistics,time

root=Path(__file__).parent
names=['bench-linear-kernels.py','bench-linear-kernels.mjs']
hashes={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in names}
target=root/'linear-kernel-samples';target.mkdir(exist_ok=False)
order=[]
for candidate in ('einsum','flat_einsum','packed','inner'):
    order.extend([('matmul',candidate),(candidate,candidate),(candidate,candidate),('matmul',candidate)])
reports=[]
for index,(variant,comparison) in enumerate(order):
    assert hashes=={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in names}
    output=target/f'{index:02d}-{comparison}-{variant}.json'
    with (target/f'{index:02d}.log').open('w') as log:
        subprocess.run(['/opt/homebrew/bin/node',str(root/'bench-linear-kernels.mjs'),variant,str(output)],stdout=log,stderr=subprocess.STDOUT,check=True)
    report=json.loads(output.read_text());report['comparison']=comparison;reports.append(report)
    print(index,comparison,variant,flush=True)
assert hashes=={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in names}
comparisons={}
for candidate in ('einsum','flat_einsum','packed','inner'):
    selected=[row for row in reports if row['comparison']==candidate]
    comparisons[candidate]={}
    for case in selected[0]['results']:
        samples={variant:[row['results'][case]['median_ms'] for row in selected if row['variant']==variant] for variant in ('matmul',candidate)}
        base=statistics.median(samples['matmul']);new=statistics.median(samples[candidate])
        comparisons[candidate][case]=dict(process_medians_ms=samples,time_reduction_percent=(1-new/base)*100)
report=dict(scope='Exploratory raw WASM forward linear kernels only; not library or full-workflow speedup. Fresh processes, sequential balanced ABBA per candidate, all raw samples retained.',harness=hashes,order=order,comparisons=comparisons,reports=reports)
(root/'linear-kernel-summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(comparisons,indent=2))
