import hashlib, json, platform, statistics, sys, time
import numpy as np

def run(variant, repeat=9, iterations=12):
    rng=np.random.default_rng(1515)
    shapes=[('threshold_0', (1, 128), 256), ('threshold_1', (8, 32), 128), ('threshold_2', (32, 16), 64), ('threshold_3', (64, 16), 32), ('threshold_4', (128, 16), 16), ('threshold_5', (256, 16), 8), ('threshold_6', (256, 64), 2), ('threshold_7', (128, 8), 32), ('threshold_8', (256, 4), 32), ('threshold_9', (256, 1), 128), ('threshold_10', (32768, 1), 1), ('threshold_11', (1, 32768), 1), ('threshold_12', (8, 128), 32), ('threshold_13', (32, 128), 8), ('threshold_14', (64, 32), 8), ('threshold_15', (16, 16), 16), ('threshold_16', (32, 16), 16), ('threshold_17', (64, 16), 16), ('threshold_18', (128, 16), 32), ('threshold_19', (32, 128), 32)]
    results={}
    for dtype in (np.float32,np.float64):
        for name,shape,outputs in shapes:
            x=rng.normal(size=shape).astype(dtype);w=rng.normal(size=(outputs,shape[-1])).astype(dtype)
            def operation():
                if variant=='matmul':return x@w.T
                if variant=='einsum':return np.einsum('...i,oi->...o',x,w,optimize=False)
                if variant=='flat_einsum':return np.einsum('bi,oi->bo',x.reshape(-1,shape[-1]),w,optimize=False).reshape(shape[:-1]+(outputs,))
                if variant=='packed':return x@np.ascontiguousarray(w.T)
                if variant=='inner':return np.inner(x,w)
                raise ValueError(variant)
            actual=operation();expected=x.astype(np.float64)@w.astype(np.float64).T
            tolerance=3e-5 if dtype==np.float32 else 1e-12
            np.testing.assert_allclose(actual,expected,rtol=tolerance,atol=tolerance)
            for _ in range(3):operation()
            count=iterations if name not in ('tiny','batched') else iterations*20
            samples=[]
            for _ in range(repeat):
                start=time.perf_counter()
                for __ in range(count):operation()
                samples.append((time.perf_counter()-start)*1000/count)
            results[np.dtype(dtype).name+'/'+name]=dict(samples_ms=samples,median_ms=statistics.median(samples),iterations=count,
                max_abs_error=float(np.max(np.abs(actual-expected))),input_sha256=hashlib.sha256(x.tobytes()+w.tobytes()).hexdigest())
    return dict(variant=variant,numpy=np.__version__,python=platform.python_version(),repeat=repeat,results=results)

if __name__=='__main__':
    from pathlib import Path
    report=run(sys.argv[1]);Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n')
