from pathlib import Path
import hashlib,json,subprocess,statistics
root=Path(__file__).parent
names=['flow-trial-inputs.json','flow-baseline-bundle.json','flow-candidate-bundle.json','bench-flow-suite.mjs']
hashes={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in names}
target=root/'flow-suite-samples';target.mkdir(exist_ok=False)
reports=[];order=['baseline','candidate','candidate','baseline']
for i,label in enumerate(order):
    assert hashes=={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in names}
    output=target/f'{i:02d}-{label}.json'
    with (target/f'{i:02d}.log').open('w') as log:
        subprocess.run(['/opt/homebrew/bin/node',str(root/'bench-flow-suite.mjs'),label,str(output)],stdout=log,stderr=subprocess.STDOUT,check=True)
    report=json.loads(output.read_text());reports.append(report)
    print(i,label,report['elapsed_ms'],flush=True)
assert hashes=={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in names}
samples={label:[row['elapsed_ms'] for row in reports if row['label']==label] for label in ('baseline','candidate')}
summary=dict(order=order,samples_ms=samples,time_reduction_percent=(1-statistics.median(samples['candidate'])/statistics.median(samples['baseline']))*100,
             frozen_hashes=hashes,reports=reports,scope='Four fresh sequential Node/WASM full suites, balanced ABBA, every sample retained. Local controlled comparison; no prediction for remote deadlines.')
(root/'flow-suite-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ('reports','frozen_hashes')}))
