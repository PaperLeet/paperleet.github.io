import numpy as np


def project(a,upper,unit):
 d=np.triu(a,k=1 if unit else 0) if upper else np.tril(a,k=-1 if unit else 0)
 if unit:
  indices=np.arange(d.shape[-1]);d[...,indices,indices]=1
 return d


def rows(a,b,upper=True,unit=False):
 out=b.copy();n=a.shape[-1]
 with np.errstate(all='ignore'):
  for i in (range(n-1,-1,-1) if upper else range(n)):
   section=slice(i+1,n) if upper else slice(0,i)
   out[...,i,:]-=(a[...,i,section,None]*out[...,section,:]).sum(-2)
   if not unit:out[...,i,:]/=a[...,i,i,None]
 return out


def blocked(a,b,upper=True,unit=False,block=32):
 out=b.copy();n=a.shape[-1]
 for start in (reversed(range(0,n,block)) if upper else range(0,n,block)):
  stop=min(start+block,n);section=slice(stop,n) if upper else slice(0,start)
  rhs=out[...,start:stop,:]
  if section.start!=section.stop:rhs-=a[...,start:stop,section]@out[...,section,:]
  diagonal=project(a[...,start:stop,start:stop],upper,unit)
  try:out[...,start:stop,:]=np.linalg.solve(diagonal,rhs)
  except np.linalg.LinAlgError:out[...,start:stop,:]=rows(diagonal,rhs,upper,unit)
 return out
