from pathlib import Path
import hashlib,json,tarfile,zipfile
r=Path(__file__).resolve().parent/'proof-refined';repo=Path('/Users/david/Developer/PaperLeet-torch-release');expected=json.loads((r/'source-hashes.json').read_text());public=next((r/'dist-preflight').glob('*.whl'));private=next((r/'private-dist').glob('*.whl'));sdist=next((r/'private-dist').glob('*.tar.gz'))
for wheel,prefix in ((public,'stridetorch/'),(private,'paperleet/_vendor/torch/')):
 with zipfile.ZipFile(wheel) as z:
  actual={name.removeprefix(prefix):hashlib.sha256(z.read(name)).hexdigest() for name in z.namelist() if name.startswith(prefix)};assert actual==expected
  if wheel==private:
   for name in ('server.py','interview_catalog.json'):assert z.read('paperleet/'+name)==(repo/'paperleet'/name).read_bytes()
with tarfile.open(sdist) as z:
 for name,h in expected.items():assert hashlib.sha256(z.extractfile('paperleet-0.1.0/packages/stridetorch/src/stridetorch/'+name).read()).hexdigest()==h
 for name in ('server.py','interview_catalog.json'):assert z.extractfile('paperleet-0.1.0/paperleet/'+name).read()==(repo/'paperleet'/name).read_bytes()
assert expected=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'packages/stridetorch/src/stridetorch').iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
result=dict(status='success',source_hashes=expected,python_modules=44,source_resources=46,current_application_server_catalog_equal=True,artifacts={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (public,private,sdist)});(r/'private-artifact-identity.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS public/private core ownership and private wheel/sdist,current server/catalog')
