from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).parent;receipts=[]
for runtime,args in [('cpu',[str(r.parent/'torch-iteration-21/stride-dev-env/bin/python'),str(r/'bench-kernels.py')]),('wasm',['/opt/homebrew/bin/node',str(r/'bench-kernels-wasm.mjs')])]:
 start=time.monotonic()
 with (r/(runtime+'-kernels.json')).open('w') as out,(r/(runtime+'-kernels.stderr.log')).open('w') as err:p=subprocess.run(args,env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2'),stdout=out,stderr=err)
 receipts.append(dict(runtime=runtime,args=args,exit_code=p.returncode,elapsed_s=time.monotonic()-start));(r/'kernel-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(runtime,'terminal',p.returncode,flush=True);p.check_returncode()
