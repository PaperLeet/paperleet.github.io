import fs from 'node:fs';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
import {loadJudgePackages} from '/Users/david/Developer/PaperLeet-torch-release/web/public/browser-judge/packages.mjs';
const py=await loadPyodide({indexURL:'/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/',packageCacheDir:'/Users/david/Developer/PaperLeet-torch-release/web/public/browser-runtime/pyodide-0.29.4/',stdout(){},stderr:console.error});await loadJudgePackages(py,[]);
py.globals.set('kernel_source',fs.readFileSync(new URL('prototype-kernels.py',import.meta.url),'utf8'));py.runPython(fs.readFileSync(new URL('bench-kernels.py',import.meta.url),'utf8'));console.log(py.runPython('json.dumps(result)'));
