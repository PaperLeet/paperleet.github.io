import numpy as np
import torch
print(torch.__version__)
for kind in ('sum','square','matmul','explicit-seed','triangular'):
 array=np.ndarray((1,1),dtype=np.float64,buffer=bytearray(64),strides=(32,16));array[:]=2.;x=torch.from_numpy(array).requires_grad_()
 if kind=='sum':x.sum().backward()
 elif kind=='square':x.square().sum().backward()
 elif kind=='matmul':(x@torch.ones_like(x)).sum().backward()
 elif kind=='explicit-seed':x.backward(torch.ones_like(x))
 else:torch.linalg.solve_triangular(x,torch.ones((1,2),dtype=x.dtype),upper=True).sum().backward()
 print(kind,'parameter',x.stride(),'grad',x.grad.stride(),'contiguous',x.grad.is_contiguous())
