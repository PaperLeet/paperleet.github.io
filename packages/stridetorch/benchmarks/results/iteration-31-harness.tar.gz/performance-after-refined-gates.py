from pathlib import Path
import json,subprocess,time
r=Path(__file__).parent;deadline=time.monotonic()+900
while True:
 try:receipts=json.loads((r/'proof-refined/gate-receipts.json').read_text())
 except (FileNotFoundError,json.JSONDecodeError):receipts={}
 if len(receipts)==4:
  assert all(v['exit_code']==0 for v in receipts.values()),receipts
  break
 if time.monotonic()>deadline:raise TimeoutError('Final compatibility gates did not terminate')
 time.sleep(2)
print('FINAL COMPATIBILITY RECEIPTS VERIFIED;START SEQUENTIAL TIMING',flush=True)
subprocess.run([str(r.parent/'torch-iteration-21/stride-dev-env/bin/python'),str(r/'run-performance-refined.py')],check=True)
