from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).resolve().parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');old=r.parent/'torch-iteration-30/proof-hardened';proof=r/'proof-refined';proof.mkdir(exist_ok=True);source=repo/'packages/stridetorch/src/stridetorch'
for target in (proof/'source',proof/'chrome-contracts/source'):shutil.copytree(source,target,ignore=shutil.ignore_patterns('__pycache__'),dirs_exist_ok=True)
shutil.copytree(repo/'packages/stridetorch/tests',proof/'chrome-contracts/tests',ignore=shutil.ignore_patterns('__pycache__'),dirs_exist_ok=True)
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};assert len(hashes)==46
plan=dict(version='0.31.0',expected=1113,source=hashes,tests={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'packages/stridetorch/tests').glob('test_*.py') if p.name!='test_standalone.py'});assert len(plan['tests'])==31
(proof/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n');(proof/'chrome-contracts/plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for name in ('run.mjs','worker.mjs','index.html'):
 s=(old/'chrome-contracts'/name).read_text().replace('torch-iteration-30/proof-hardened','torch-iteration-31/proof-refined');(proof/'chrome-contracts'/name).write_text(s)
s=(old/'wasm-contracts.mjs').read_text().replace('torch-iteration-30/proof-hardened','torch-iteration-31/proof-refined').replace('0.30.0','0.31.0').replace("'solve','serialization']","'solve','serialization','triangular']").replace('==948','==1113');(proof/'wasm-contracts.mjs').write_text(s)
s=(old/'check-wheel.py').read_text().replace('0.30','0.31').replace('stride030','stride031');(proof/'check-wheel.py').write_text(s)
print('FROZEN46 hashes,31 standalone suites1113 checks')
