from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,os,subprocess,time
r=Path(__file__).parent;p=r/'proof';repo=Path('/Users/david/Developer/PaperLeet-torch-release');py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';receipts={}
plans={'full-native':([str(py),'-m','pytest','tests','packages/stridetorch/tests','-q'],repo),'minimal-wheel':([str(py),str(p/'check-wheel.py')],repo),'node-wasm':(['/opt/homebrew/bin/node',str(p/'wasm-contracts.mjs')],repo),'chrome-worker':(['/opt/homebrew/bin/node',str(p/'chrome-contracts/run.mjs')],repo)}
def run(name,args,cwd):
 start=time.monotonic()
 with (p/(name+'.log')).open('w') as log:result=subprocess.run(args,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
 return name,dict(exit_code=result.returncode,elapsed_s=time.monotonic()-start,args=args,cwd=str(cwd))
with ThreadPoolExecutor(max_workers=4) as pool:
 for future in as_completed([pool.submit(run,name,args,cwd) for name,(args,cwd) in plans.items()]):
  name,receipt=future.result();receipts[name]=receipt;(p/'gate-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print('TERMINAL',name,receipt['exit_code'],round(receipt['elapsed_s'],2),flush=True)
assert all(v['exit_code']==0 for v in receipts.values()),receipts
print('ALL FINAL GATES PASS',flush=True)
