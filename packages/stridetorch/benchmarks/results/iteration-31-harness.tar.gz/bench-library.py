"""Equivalent projected solves vs structured solves in complete recorded flows."""
import contextlib,gc,hashlib,importlib.util,json,os,statistics,sys,time
from pathlib import Path
import numpy as np
paths=globals().get('bench_sources') or json.loads(os.environ['BENCH_SOURCES']);dtype=globals().get('bench_dtype',os.environ.get('BENCH_DTYPE','float64'));packages={};hashes={}
for label,path in paths.items():
 root=Path(path);name='triangular_'+label;spec=importlib.util.spec_from_file_location(name,root/'__init__.py',submodule_search_locations=[str(root)]);p=importlib.util.module_from_spec(spec);sys.modules[name]=p;spec.loader.exec_module(p);packages[label]=p
 hashes[label]={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in root.iterdir() if f.suffix=='.py' or f.name in ('LICENSE','NOTICE')}
assert packages['baseline'].__version__=='0.30.0' and packages['candidate'].__version__=='0.31.0'
configs=[('tiny-backward',2,2,(),True,True,False,'both'),('sgd-update',16,4,(),False,True,True,'both'),('batch-b-only',64,4,(4,),True,False,False,'b'),('large-backward',256,4,(),False,True,False,'both'),('wide-right-backward',256,64,(),True,False,True,'both'),('large-inference',256,4,(),True,True,False,'off'),('jvp',16,4,(),True,True,False,'both'),('unary-control',0,0,(),True,True,False,'both'),('attention-control',0,0,(),True,True,False,'both')];results={}
for operation,n,k,batch,upper,left,unit,mode in configs:
 calls={};validations={};state_checks={}
 for label,p in packages.items():
  lib=p.torch;tdtype=getattr(lib,dtype);rng=np.random.default_rng(31)
  def tensor(raw,grad=True,lib=lib,tdtype=tdtype):return lib.tensor(np.asarray(raw,dtype=dtype),dtype=tdtype,requires_grad=grad)
  if operation.endswith('control'):
   raw=np.linspace(-.4,.7,32).reshape(4,8);x=tensor(raw);inputs=[x]
   if operation=='unary-control':forward=lambda x=x:x.sin().exp().tanh()
   else:forward=lambda lib=lib,x=x:lib.nn.functional.scaled_dot_product_attention(x,x,x)
  else:
   raw=(rng.normal(size=batch+(n,n))*.1/max(1,n)).astype(dtype);raw[...,np.arange(n),np.arange(n)]=2.
   if operation=='batch-b-only':raw=np.triu(raw)
   rhs=rng.normal(size=batch+((n,k) if left else (k,n))).astype(dtype)*.2;A=tensor(raw,mode=='both');B=tensor(rhs,mode!='off');inputs=[A,B];identity=lib.eye(n,dtype=tdtype)
   def forward(A=A,B=B,lib=lib,label=label,upper=upper,left=left,unit=unit,identity=identity,operation=operation):
    if label=='candidate':return lib.linalg.solve_triangular(A,B,upper=upper,left=left,unitriangular=unit)
    if operation=='batch-b-only':coefficient=A
    else:
     coefficient=A.triu(int(unit)) if upper else A.tril(-int(unit))
     if unit:coefficient=coefficient+identity
    return lib.linalg.solve(coefficient,B,left=left)
   effective=np.triu(raw,k=int(unit)) if upper else np.tril(raw,k=-int(unit))
   if unit:effective[...,np.arange(n),np.arange(n)]=1
   expected=np.linalg.solve(effective,rhs) if left else np.linalg.solve(effective.swapaxes(-1,-2),rhs.swapaxes(-1,-2)).swapaxes(-1,-2)
   np.testing.assert_allclose(forward().numpy(),expected,rtol=4e-5,atol=3e-6)
  optimizer=lib.optim.SGD(inputs,lr=.00001) if operation=='sgd-update' else None
  if operation=='jvp':
   direction_a=lib.ones_like(A)*.03;direction_b=lib.ones_like(B)*.07
   def call(A=A,B=B,da=direction_a,db=direction_b,lib=lib,label=label,upper=upper,left=left,unit=unit,identity=identity):
    if label=='candidate':return lib.func.jvp(lambda aa,bb:lib.linalg.solve_triangular(aa,bb,upper=upper,left=left,unitriangular=unit),(A,B),(da,db))
    #0.30 triu/tril have no forward-mode rule. Project primal/direction before
    # JVP,retaining that projection work in the timed mathematical composition.
    projected=A.triu(int(unit)) if upper else A.tril(-int(unit))
    direction=da.triu(int(unit)) if upper else da.tril(-int(unit))
    if unit:projected=projected+identity
    return lib.func.jvp(lambda aa,bb:lib.linalg.solve(aa,bb,left=left),(projected,B),(direction,db))
  elif mode=='off':call=forward
  else:
   def call(inputs=inputs,forward=forward,optimizer=optimizer):
    for item in inputs:item.grad=None
    forward().square().mean().backward()
    if optimizer is not None:optimizer.step()
  calls[label]=call
  def validation(call=call,forward=forward,inputs=inputs,operation=operation):
   if operation=='jvp':return [v.detach().numpy().copy() for v in call()]
   return [item.grad.numpy().copy() if item.grad is not None else None for item in inputs]+[forward().detach().numpy().copy()]
  validations[label]=validation;state_checks[label]=lambda inputs=inputs:[item.numpy().copy() for item in inputs]
 loops=5 if n>=256 else 60 if n>=64 else 100;warmup=20 if n>=256 else 100
 with contextlib.ExitStack() as stack:
  if mode=='off':
   for p in packages.values():stack.enter_context(p.torch.no_grad())
  for call in calls.values():
   for _ in range(warmup):call()
  gc.collect();before=gc.get_stats();blocks=[]
  for block in range(9):
   order=('baseline','candidate','candidate','baseline') if block%2==0 else ('candidate','baseline','baseline','candidate');times={'baseline':[],'candidate':[]}
   for label in order:
    call=calls[label];start=time.perf_counter()
    for _ in range(loops):call()
    times[label].append((time.perf_counter()-start)*1e6/loops)
   blocks.append(dict(samples_us=times,time_reduction_percent=100*(1-statistics.mean(times['candidate'])/statistics.mean(times['baseline']))))
  values={label:validate() for label,validate in validations.items()};states={label:check() for label,check in state_checks.items()}
  for actual,expected in zip(values['candidate'],values['baseline']):
   if expected is None:assert actual is None
   else:
    assert actual.dtype==expected.dtype==np.dtype(dtype);np.testing.assert_allclose(actual,expected,rtol=5e-5,atol=3e-6)
  for actual,expected in zip(states['candidate'],states['baseline']):np.testing.assert_allclose(actual,expected,rtol=5e-5,atol=3e-6)
 results[operation]=dict(shape=dict(n=n,k=k,batch=batch,upper=upper,left=left,unit=unit,mode=mode),baseline_projection=operation not in ('batch-b-only','unary-control','attention-control'),loops_per_sample=loops,warmup=warmup,blocks=blocks,median_time_reduction_percent=statistics.median(b['time_reduction_percent'] for b in blocks),final_checks='values,dtypes,gradients or JVP channels and parameter states matched',gc_before=before,gc_after=gc.get_stats())
result=dict(python=sys.version,numpy=np.__version__,dtype=dtype,source_hashes=hashes,results=results,scope='2isolated namespaces sharing NumPy;9 ABBA/BAAB paired blocks;GC enabled. Baseline projects raw A with triu/tril and adds identity for unit systems,except pretriangular frozen-A B-only case. SGD includes real updates. JVP compares forward channels only because native triangular reverse-of-JVP differs from generic saved-LU reverse. Operators retain their respective native output layouts. Shared host;BLAS threading unverified;not nativeTorch/CPU-WASM comparative throughput.')
if 'bench_sources' not in globals():print(json.dumps(result))
