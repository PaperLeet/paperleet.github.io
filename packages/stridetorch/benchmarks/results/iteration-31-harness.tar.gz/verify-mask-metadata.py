from pathlib import Path
import gc,json,weakref
import numpy as np
from stridetorch import torch
from stridetorch import _linalg
r=Path(__file__).parent;rows=[]
root=torch.tensor([[2.,.2],[.4,3.]],dtype=torch.float64,requires_grad=True);rhs=torch.ones(2,2,dtype=torch.float64,requires_grad=True);saved=torch.linalg.solve_triangular(root,rhs,upper=True)
for n in range(1,72):
 for upper in (False,True):
  for unit in (False,True):
   raw=np.eye(n,dtype=np.float64)*2;reference=weakref.ref(raw);a=torch.from_numpy(raw);b=torch.ones(n,2,dtype=torch.float64)
   with torch.no_grad():out=torch.linalg.solve_triangular(a,b,upper=upper,unitriangular=unit)
   del raw,a,b,out;gc.collect();assert reference() is None
   masks=_linalg._triangular_masks;assert len(masks)<=16 and sum(v.nbytes for v in masks.values())<=65536
   assert all(type(k[0]) is type(k[1]) is int and type(k[2]) is type(k[3]) is bool for k in masks)
   assert all(v.dtype==np.bool_ and not v.flags.writeable and max(v.shape)<=64 for v in masks.values())
   rows.append(dict(n=n,upper=upper,unit=unit,entries=len(masks),bytes=sum(v.nbytes for v in masks.values())))
saved.sum().backward();inv=np.array([[.5,-.2/6],[0.,1/3]]);x=inv@np.ones((2,2));db=inv.T@np.ones((2,2));da=np.triu(-db@x.T);np.testing.assert_allclose(root.grad.numpy(),da);np.testing.assert_allclose(rhs.grad.numpy(),db)
(r/'mask-metadata-result.json').write_text(json.dumps(dict(status='success',max_entries=max(x['entries'] for x in rows),max_mask_bytes=max(x['bytes'] for x in rows),calls=len(rows),all_masks_readonly_bool=True,no_user_array_retained=True,backward_after_cache_churn_verified=True,scope='Structural masks only;Python object overhead is separate from mask-data bound',rows=rows),indent=2)+'\n');print('PASS bounded readonly structural masks,no input retention,and retained graph after cache churn')
