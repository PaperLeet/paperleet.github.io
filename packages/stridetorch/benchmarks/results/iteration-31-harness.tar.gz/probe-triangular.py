from pathlib import Path
import json,subprocess
import numpy as np
import torch
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();source=r/'baseline/stridetorch';source.mkdir(parents=True,exist_ok=True)
for p in (repo/'packages/stridetorch/src/stridetorch').iterdir():
 if p.suffix=='.py' or p.name in ('LICENSE','NOTICE'):(source/p.name).write_bytes(p.read_bytes())
print('NATIVE',torch.__version__,'BASE',head)
for left in (True,False):
 for unit in (True,False):
  for active in ((True,True),(True,False),(False,True)):
   for mutated in ('A','B','X'):
    a=torch.tensor([[2.,.3],[.7,3.]],dtype=torch.float64,requires_grad=active[0]);b=torch.ones((2,2),dtype=torch.float64,requires_grad=active[1]);x=torch.linalg.solve_triangular(a,b,upper=True,left=left,unitriangular=unit)
    with torch.no_grad():{'A':a,'B':b,'X':x}[mutated].add_(.1)
    try:x.sum().backward();error=False
    except RuntimeError:error=True
    print('GUARD',left,unit,active,mutated,error)
 for shape in ((2,2),(2,0),(0,2),(0,0),(1,2),(2,1),(1,0),(0,1)):
  n=shape[0] if left else shape[1];a=torch.eye(n,dtype=torch.float64);b=torch.ones(shape,dtype=torch.float64);x=torch.linalg.solve_triangular(a,b,upper=True,left=left);print('LAYOUT',left,shape,x.stride())
for active in ((0,1),(0,),(1,)):
 for unit in (False,True):
  a=torch.tensor([[2.,.3],[.7,3.]],dtype=torch.float64,requires_grad=True);b=torch.ones((2,2),dtype=torch.float64,requires_grad=True);da=torch.full_like(a,.13,requires_grad=True);db=torch.full_like(b,.27,requires_grad=True);args=(a,b);dargs=(da,db)
  def call(*values):
   inputs=list(args)
   for i,v in zip(active,values):inputs[i]=v
   return torch.linalg.solve_triangular(*inputs,upper=True,unitriangular=unit)
  x,t=torch.func.jvp(call,tuple(args[i] for i in active),tuple(dargs[i] for i in active));grads=torch.autograd.grad(t.sum(),(a,b,da,db),allow_unused=True)
  print('JVP',active,unit,'x',x.tolist(),'t',t.tolist(),'grads',[None if g is None else g.tolist() for g in grads])
for diagonal in (0.,float('inf'),float('nan')):
 a=torch.tensor([[diagonal,.2],[0.,2.]],dtype=torch.float64);b=torch.ones((2,1),dtype=torch.float64)
 for unit in (False,True):
  try:print('NONFINITE',diagonal,unit,torch.linalg.solve_triangular(a,b,upper=True,unitriangular=unit).tolist())
  except Exception as e:print('NONFINITE ERROR',type(e).__name__,str(e))
for flag in (True,1,0,np.bool_(True)):
 try:print('FLAG',repr(flag),torch.linalg.solve_triangular(torch.eye(2),torch.ones(2,1),upper=flag).shape)
 except Exception as e:print('FLAGERROR',repr(flag),type(e).__name__)
