from pathlib import Path
import gc,hashlib,json,statistics,sys,time
import numpy as np
exec(globals().get('kernel_source',Path(__file__).with_name('prototype-kernels.py').read_text() if '__file__' in globals() else ''),globals())
results={}
for dtype in ('float32','float64'):
 for n,k,batch in ((2,1,()),(16,4,()),(64,1,()),(64,32,()),(256,4,()),(256,64,()),(64,4,(4,))):
  rng=np.random.default_rng(31);a=np.triu((rng.normal(size=batch+(n,n))*.15/n).astype(dtype));a[...,np.arange(n),np.arange(n)]+=2;b=rng.normal(size=batch+(n,k)).astype(dtype);expected=np.linalg.solve(a,b)
  calls={'dense':lambda a=a,b=b:np.linalg.solve(a,b),'dense-masked':lambda a=a,b=b:np.linalg.solve(np.triu(a),b)}
  for block in (16,32,64):calls['block'+str(block)]=lambda block=block,a=a,b=b:blocked(a,b,block=block)
  if n<=64:calls['rows']=lambda a=a,b=b:rows(a,b)
  for call in calls.values():
   np.testing.assert_allclose(call(),expected,rtol=2e-6,atol=3e-7)
   for _ in range(10):call()
  gc.collect();samples={label:[] for label in calls};loops=20 if n<=64 else 5
  for repeat in range(7):
   for label in (list(calls) if repeat%2==0 else list(reversed(calls))):
    call=calls[label];start=time.perf_counter()
    for _ in range(loops):call()
    samples[label].append((time.perf_counter()-start)*1e6/loops)
  results[f'{dtype}/{n}/{k}/{batch}']=dict(median_us={label:statistics.median(values) for label,values in samples.items()},samples_us=samples,loops=loops)
result=dict(python=sys.version,numpy=np.__version__,results=results,scope='Raw NumPy kernels,7alternating blocks,GC enabled,10warmups,20calls small/5large;well-conditioned upper-triangular coefficients,known dense solution check;algorithm selection evidence,not integrated-library speedup.')
if 'kernel_source' not in globals():print(json.dumps(result))
