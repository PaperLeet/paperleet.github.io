from pathlib import Path
import cProfile,importlib.util,io,json,pstats,sys
import numpy as np
r=Path(__file__).parent;repo=Path('/Users/david/Developer/PaperLeet-torch-release')
for label,path in [('baseline',r/'baseline/stridetorch'),('candidate',repo/'packages/stridetorch/src/stridetorch')]:
 name='profile_'+label;spec=importlib.util.spec_from_file_location(name,path/'__init__.py',submodule_search_locations=[str(path)]);p=importlib.util.module_from_spec(spec);sys.modules[name]=p;spec.loader.exec_module(p);t=p.torch;rng=np.random.default_rng(31);raw=rng.normal(size=(16,16))*.1/16;raw[np.diag_indices(16)]=2.;a=t.tensor(raw,requires_grad=True);b=t.tensor(rng.normal(size=(16,4))*.2,requires_grad=True);identity=t.eye(16,dtype=t.float64);opt=t.optim.SGD([a,b],lr=.00001)
 def call():
  opt.zero_grad();x=t.linalg.solve(a.tril(-1)+identity,b) if label=='baseline' else t.linalg.solve_triangular(a,b,upper=False,unitriangular=True);x.square().mean().backward();opt.step()
 for _ in range(100):call()
 profiler=cProfile.Profile();profiler.enable()
 for _ in range(1000):call()
 profiler.disable();profiler.dump_stats(str(r/('profile-'+label+'.pstats')))
 with (r/('profile-'+label+'.txt')).open('w') as stream:pstats.Stats(profiler,stream=stream).strip_dirs().sort_stats('cumulative').print_stats(35)
