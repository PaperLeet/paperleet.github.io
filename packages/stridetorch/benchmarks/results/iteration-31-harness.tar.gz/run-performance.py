from pathlib import Path
import gzip,hashlib,json,os,statistics,subprocess,time
r=Path(__file__).resolve().parent;out=r/'performance';out.mkdir(exist_ok=True);py=r.parent/'torch-iteration-21/stride-dev-env/bin/python';sources={'baseline':str(r/'baseline/stridetorch'),'candidate':str(r/'proof/source')};env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2');receipts=[]
def run(name,args,extra):
 start=time.monotonic()
 with (out/(name+'.json')).open('w') as log,(out/(name+'.stderr.log')).open('w') as err:p=subprocess.run([str(x) for x in args],env={**env,**extra},stdout=log,stderr=err,cwd=r)
 receipts.append(dict(name=name,args=[str(x) for x in args],exit_code=p.returncode,elapsed_s=time.monotonic()-start));(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,'terminal',p.returncode,flush=True);p.check_returncode()
for preload in ('0','1'):
 for repeat in range(4):
  for label in (('baseline','candidate') if repeat%2==0 else ('candidate','baseline')):
   run(f'import-{preload}-{repeat}-{label}',[py,r/'bench-import.py'],{'IMPORT_SOURCE':sources[label],'IMPORT_PRELOAD':preload})
for repeat in range(2):
 for runtime in (('cpu','wasm') if repeat%2==0 else ('wasm','cpu')):
  for dtype in ('float32','float64'):
   args=[py,r/'bench-library.py'] if runtime=='cpu' else ['/opt/homebrew/bin/node',r/'bench-library-wasm.mjs',sources['baseline'],sources['candidate'],dtype]
   run(f'paired-{runtime}-{dtype}-{repeat}',args,{'BENCH_SOURCES':json.dumps(sources),'BENCH_DTYPE':dtype})
size={}
for label,source in sources.items():
 files={p.name:p.read_bytes() for p in Path(source).iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};raw=b''.join(files[name] for name in sorted(files));size[label]=dict(files=len(files),raw_bytes=len(raw),gzip_bytes=len(gzip.compress(raw,mtime=0)),hashes={name:hashlib.sha256(data).hexdigest() for name,data in files.items()})
imports={}
for preload in ('0','1'):
 imports[preload]={}
 for label in sources:
  rows=[json.loads((out/f'import-{preload}-{i}-{label}.json').read_text()) for i in range(4)];assert all(not x['zipfile_imported'] and x['source_hashes']==size[label]['hashes'] for x in rows);imports[preload][label]=dict(samples_ms=[x['namespace_import_ms'] for x in rows],median_ms=statistics.median(x['namespace_import_ms'] for x in rows))
summary={}
for runtime in ('cpu','wasm'):
 for dtype in ('float32','float64'):
  rows=[json.loads((out/f'paired-{runtime}-{dtype}-{i}.json').read_text()) for i in range(2)]
  for row in rows:assert row['source_hashes']=={label:context['hashes'] for label,context in size.items()}
  summary[runtime+'/'+dtype]={case:dict(process_time_reductions=[row['results'][case]['median_time_reduction_percent'] for row in rows],median_reduction=statistics.median(row['results'][case]['median_time_reduction_percent'] for row in rows)) for case in rows[0]['results']}
(r/'performance-summary.json').write_text(json.dumps(dict(source_size=size,cold_namespace_import=imports,paired=summary,receipts=receipts,scope='16fresh CPU import processes and8fresh paired performance processes;all sequential after compatibility gates. Paired baseline is0.30 generic solve with required projection except explicit frozen pretriangular B-only case;compare mathematical flows,not identical native allocation implementations. Full scalar-loss backward,real SGD and forward JVP;controls and all anomalies retained.'),indent=2)+'\n');print('PERFORMANCE COMPLETE',flush=True)
