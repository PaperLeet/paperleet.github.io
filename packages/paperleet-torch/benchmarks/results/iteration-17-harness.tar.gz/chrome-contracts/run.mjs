import fs from 'node:fs';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
import {chromium} from '/Users/david/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
try{
 const page=await browser.newPage();await page.goto('http://127.0.0.1:8766/torch-iteration-17/chrome-contracts/');
 const result=await page.evaluate(()=>new Promise((resolve,reject)=>{
  const worker=new Worker('./worker.mjs',{type:'module'});const timer=setTimeout(()=>{worker.terminate();reject(Error('WASM contracts timeout'));},120000);
  worker.onmessage=({data})=>{clearTimeout(timer);worker.terminate();resolve(data);};worker.onerror=event=>{clearTimeout(timer);worker.terminate();reject(Error(event.message));};worker.postMessage({});
 }));
 result.browser=browser.version();result.harness=Object.fromEntries(['run.mjs','worker.mjs','plan.json'].map(name=>[name,createHash('sha256').update(fs.readFileSync(new URL(name,import.meta.url))).digest('hex')]));
 fs.writeFileSync(new URL('result.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
 assert(!result.error,JSON.stringify(result));assert.equal(result.status,'success');assert.equal(result.numpy,'2.2.5');
 console.log(JSON.stringify({status:result.status,browser:result.browser,passed:result.passed,pyodide:result.pyodide,numpy:result.numpy}));
}finally{await browser.close();}
