import json, torch, numpy as np
from pathlib import Path
root=Path('/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-17')
torch.set_num_threads(1)
report={'torch':torch.__version__,'boundaries':[], 'mutations':[], 'jvp':{}}
for shape,groups in [((2,6),3),((1,6),6),((2,6),6),((0,6,4),3),((2,6,0),3),((2,0,4),1),((2,6,4),0),((2,6,4),4),((2,6,4),True)]:
 try:
  x=torch.ones(shape,dtype=torch.float64,requires_grad=True);w=torch.ones(shape[1],dtype=torch.float64,requires_grad=True);b=torch.zeros_like(w,requires_grad=True)
  y=torch.nn.functional.group_norm(x,groups,w,b);y.sum().backward()
  result={'shape':list(y.shape),'weight_grad':w.grad.tolist()}
 except Exception as e:result={'error':type(e).__name__,'message':str(e)}
 report['boundaries'].append({'shape':shape,'groups':groups,**result})
for needs in [(True,True,True),(True,False,False),(False,True,False),(False,False,True)]:
 for changed in ['x','w','b','output']:
  values=[torch.randn(2,6,4,dtype=torch.float64,requires_grad=needs[0]),torch.randn(6,dtype=torch.float64,requires_grad=needs[1]),torch.randn(6,dtype=torch.float64,requires_grad=needs[2])]
  y=torch.nn.functional.group_norm(*[values[0],3,*values[1:]])
  target=y if changed=='output' else values[['x','w','b'].index(changed)]
  with torch.no_grad():target.add_(1)
  try:y.sum().backward();status='ok'
  except Exception as e:status=type(e).__name__
  report['mutations'].append({'needs':needs,'changed':changed,'status':status})
rng=np.random.default_rng(1710)
arrays=[rng.normal(size=(2,6,4)),rng.normal(size=6),rng.normal(size=6)]*2
# Compare native GroupNorm JVP reverse tape to a grouped LayerNorm composition.
records=[]
for kind in ['native','composite']:
 values=[torch.tensor(a,requires_grad=True) for a in arrays]
 def fn(x,w,b):
  if kind=='native':return torch.nn.functional.group_norm(x,3,w,b)
  z=torch.nn.functional.layer_norm(x.reshape(2,3,8),(8,)).reshape(x.shape)
  return z*w.reshape(1,6,1)+b.reshape(1,6,1)
 p,t=torch.func.jvp(fn,tuple(values[:3]),tuple(values[3:])); (p.square().sum()+t.square().sum()).backward()
 records.append([p.detach().numpy(),t.detach().numpy(),*[v.grad.numpy() for v in values]])
report['jvp']['composite_max_errors']=[float(np.max(np.abs(a-b))) for a,b in zip(*records)]
(root/'native-groupnorm-audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
