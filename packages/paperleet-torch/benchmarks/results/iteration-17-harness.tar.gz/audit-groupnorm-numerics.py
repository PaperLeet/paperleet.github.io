import json,numpy as np,torch
from pathlib import Path
from paperleet_torch import torch as lite
torch.set_num_threads(1);rows=[]
for shape,groups,offset in [((3,6),3,0),((2,6),6,0),((2,6,4),3,1e5)]:
 rng=np.random.default_rng(1712);raw=(rng.normal(size=shape)*(.1 if offset else 1)+offset).astype(np.float32)
 w=rng.normal(size=6).astype(np.float32);b=rng.normal(size=6).astype(np.float32);seed=rng.normal(size=shape).astype(np.float32)
 z=raw.astype(np.float64).reshape(shape[0],groups,-1);c=z-z.mean(-1,keepdims=True);inv=1/np.sqrt((c*c).mean(-1,keepdims=True)+1e-5);norm=(c*inv).reshape(shape)
 bc=(1,6,*([1]*(len(shape)-2)));g=(seed.astype(np.float64)*w.reshape(bc)).reshape(z.shape)
 dx=(inv*(g-g.mean(-1,keepdims=True)-c*inv*(g*c*inv).mean(-1,keepdims=True))).reshape(shape)
 expected=[norm*w.reshape(bc)+b.reshape(bc),dx];errors={};outputs={}
 for name,api in [('library',lite),('native',torch)]:
  x=api.tensor(raw,requires_grad=True);weight=api.tensor(w,requires_grad=True);bias=api.tensor(b,requires_grad=True)
  y=api.nn.functional.group_norm(x,groups,weight,bias);y.backward(api.tensor(seed))
  values=[y.detach().numpy(),x.grad.numpy()];errors[name]=[float(np.max(np.abs(a-e))) for a,e in zip(values,expected)];outputs[name]=[a.tolist() for a in values]
 rows.append(dict(shape=shape,groups=groups,offset=offset,max_abs_errors_vs_float64=errors,outputs=outputs))
Path(__file__).with_name('groupnorm-numerics.json').write_text(json.dumps(dict(seed=1712,numpy=np.__version__,native=torch.__version__,rows=rows),indent=2)+'\n')
print(json.dumps([{k:v for k,v in row.items() if k!='outputs'} for row in rows]))
