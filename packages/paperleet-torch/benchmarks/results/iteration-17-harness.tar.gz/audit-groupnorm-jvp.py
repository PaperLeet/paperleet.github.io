import json,torch,numpy as np
from pathlib import Path
torch.set_num_threads(1);rng=np.random.default_rng(1711)
a=[rng.normal(size=(2,6,4)),rng.normal(size=6),rng.normal(size=6),rng.normal(size=(2,6,4)),rng.normal(size=6),rng.normal(size=6)]
records={}
for kind in ['native','full','fixed','fixed_inverse','fixed_mean']:
 v=[torch.tensor(i,requires_grad=True) for i in a]
 if kind=='native':p,t=torch.func.jvp(lambda x,w,b:torch.nn.functional.group_norm(x,3,w,b),tuple(v[:3]),tuple(v[3:]))
 else:
  x,w,b,dx,dw,db=v;z=x.reshape(2,3,8);d=dx.reshape(2,3,8)
  mean=z.mean(-1,keepdim=True);c=z-mean;inverse=(c.square().mean(-1,keepdim=True)+1e-5).rsqrt()
  p=torch.nn.functional.group_norm(x,3,w,b)
  if kind in ['fixed','fixed_mean']:c=z-mean.detach()
  if kind in ['fixed','fixed_inverse']:inverse=inverse.detach()
  projected=d-d.mean(-1,keepdim=True)
  jt=(projected*inverse-c*inverse.pow(3)*(projected*c).mean(-1,keepdim=True)).reshape(x.shape)
  t=jt*w.reshape(1,6,1)+(c*inverse).reshape(x.shape)*dw.reshape(1,6,1)+db.reshape(1,6,1)
 (p.square().sum()+t.square().sum()).backward()
 records[kind]=[p.detach().numpy(),t.detach().numpy(),*[i.grad.numpy() for i in v]]
report={k:[float(np.max(np.abs(x-y))) for x,y in zip(records['native'],r)] for k,r in records.items()}
Path('/Users/david/Developer/paperleet-wasm-evaluation-20261015/torch-iteration-17/native-groupnorm-jvp.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
