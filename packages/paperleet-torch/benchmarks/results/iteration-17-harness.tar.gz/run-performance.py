from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess,time
root=Path(__file__).parent;repo=Path.cwd();frozen=root/'perf-frozen';frozen.mkdir(exist_ok=False)
source=frozen/'src/paperleet_torch';source.mkdir(parents=True)
for file in (repo/'packages/paperleet-torch/src/paperleet_torch').iterdir():
    if file.suffix=='.py' or file.name in ('LICENSE','NOTICE'):shutil.copyfile(file,source/file.name)
bench=frozen/'benchmarks';bench.mkdir()
for name in ('bench_groupnorm.py','bench_wasm.mjs'):shutil.copyfile(repo/'packages/paperleet-torch/benchmarks'/name,bench/name)
def hashes():return {str(file.relative_to(frozen)):hashlib.sha256(file.read_bytes()).hexdigest() for file in sorted(frozen.rglob('*')) if file.is_file() and '__pycache__' not in str(file)}
inputs=hashes();plan=json.loads((root/'chrome-contracts/plan.json').read_text())
assert {name.removeprefix('src/paperleet_torch/'):digest for name,digest in inputs.items() if name.startswith('src/paperleet_torch/')}==plan['source']
env=dict(os.environ,PYTHONPATH=str(frozen/'src'),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2')
target=root/'performance';target.mkdir(exist_ok=False);reports=[]
order=['composite','joint','joint','composite']
for runtime in ('cpu','wasm'):
    for dtype in ('float32','float64'):
        for index,implementation in enumerate(order):
            assert hashes()==inputs
            label=f'{runtime}-{dtype}-{index}-{implementation}';output=target/(label+'.json')
            args=[str(repo/'.venv/bin/python'),str(bench/'bench_groupnorm.py')] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(bench/'bench_wasm.mjs'),'--benchmark','groupnorm','--source',str(source),'--runtime',str(repo/'web/node_modules/pyodide'),'--cache',str(repo/'web/public/browser-runtime/pyodide-0.29.4')]
            args += ['--dtype',dtype,'--implementation',implementation,'--repeat','9','--iterations','80','--output',str(output)]
            start=time.monotonic()
            with (target/(label+'.log')).open('w') as log:result=subprocess.run(args,env=env,cwd=frozen,stdout=log,stderr=subprocess.STDOUT)
            receipt=dict(runtime=runtime,dtype=dtype,index=index,implementation=implementation,exit_code=result.returncode,elapsed_s=time.monotonic()-start,args=args)
            with (target/'receipts.jsonl').open('a') as log:log.write(json.dumps(receipt)+'\n')
            result.check_returncode();report=json.loads(output.read_text())
            assert report['implementation']==implementation and report['dtype']==dtype
            if runtime=='cpu':assert str(source) in report['runtime_module'],report['runtime_module']
            else:assert report['numpy']=='2.2.5' and report['pyodide']=='0.29.4'
            reports.append(dict(runtime=runtime,**report));assert hashes()==inputs
            print(label,'complete',flush=True)
summary={}
for runtime in ('cpu','wasm'):
    summary[runtime]={}
    for dtype in ('float32','float64'):
        rows=[report for report in reports if report['runtime']==runtime and report['dtype']==dtype];summary[runtime][dtype]={}
        for case in rows[0]['results']:
            samples={role:[row['results'][case]['median_ms'] for row in rows if row['implementation']==role] for role in ('composite','joint')}
            before=statistics.median(samples['composite']);after=statistics.median(samples['joint'])
            summary[runtime][dtype][case]=dict(process_medians_ms=samples,time_reduction_percent=(1-after/before)*100)
assert hashes()==inputs
record=dict(status='success',order=order,inputs=inputs,configuration=dict(repeat=9,iterations=80,warmup=3,tiny_multiplier=4,vision_divisor=8),
            scope='Same-source first-order joint GroupNorm versus Tensor composition, sequential balanced fresh processes; correctness/build producers terminal first; every batch/process sample retained. CPU and WASM are independent series. Not native Torch, old-release or full-application speedup.',summary=summary,reports=reports)
(root/'performance-summary.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(summary,indent=2))
