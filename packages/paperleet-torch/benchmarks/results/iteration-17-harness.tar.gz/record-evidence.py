from pathlib import Path
import hashlib,json,shutil,tarfile,io,subprocess
root=Path(__file__).parent;repo=Path.cwd();read=lambda n:json.loads((root/n).read_text());result_dir=repo/'packages/paperleet-torch/benchmarks/results'
source=repo/'packages/paperleet-torch/src/paperleet_torch';hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']}
assert hashes==read('source-hashes.json')==read('distribution-identity.json')['source_hashes']==read('chrome-contracts/result.json')['source_hashes']
perf=read('performance-summary.json');assert perf['status']=='success'
assert hashes=={n.removeprefix('src/paperleet_torch/'):v for n,v in perf['inputs'].items() if n.startswith('src/paperleet_torch/')}
ci=read('native-ci.json');wasm=read('full-wasm-result.json')
assert ci['passed'] and ci['problems']==77 and ci['tests_executed']==9987 and not ci['issues']
assert wasm['passed'] and wasm['modules']==77 and not wasm['browser_budget_exceeded']
assert '17658 passed, 1 skipped' in (root/'full-native.log').read_text()
assert '340 passed' in (root/'python310-v017-tests.log').read_text()
assert 'PASS initial build graph:' in (root/'frontend-build.log').read_text()
data=repo/'web/public/data';index=json.loads((data/'index.json').read_text());by_id={x['id']:x for x in index['problems']};paths={'index.json','index-v3.json','catalog.json'}
for row in wasm['results']:
 entry=by_id[row['id']];assert entry['browser_judge']['bundle_url']==row['bundle_url']
 manifest=json.loads((data/row['bundle_url']).read_text());assert manifest['runtime_bundle_url']==row['runtime_bundle_url']
 assert hashlib.sha256(manifest['reference'].encode()).hexdigest()==row['source_sha256']
 paths.update([entry['detail_url'],row['bundle_url'],row['runtime_bundle_url']])
expected=root/'live-expected';expected.mkdir(exist_ok=False);live_hashes={}
for name in sorted(paths):
 dest=expected/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(data/name,dest);live_hashes[name]=hashlib.sha256(dest.read_bytes()).hexdigest()
(root/'live-expected-hashes.json').write_text(json.dumps(live_hashes,indent=2)+'\n')
logs=['groupnorm-native.log','groupnorm-focused.log','standalone-native.log','full-native.log','full-wasm.log','native-catalog.log','source-wasm.log','frontend-check.log','frontend-build.log','vizdata.log','python310-v017-tests.log','build.log','build-paperleet.log','performance.log']
report=dict(status='all local release gates passed',version='0.17.0',source_hashes=hashes,
 native_probes={n:read(n) for n in ['native-groupnorm-audit.json','native-groupnorm-jvp.json','groupnorm-numerics.json']},
 infrastructure=dict(passed=17658,skipped=1,warnings=7,duration_s=203.05),native_reference_new_tests=137,independent_new_tests=47,
 native_catalog=ci,real_wasm_catalog=wasm,node_contracts=read('source-wasm.json'),chrome_worker=read('chrome-contracts/result.json'),minimum_wheel=read('wheel-v017-result.json'),
 distributions=read('distribution-identity.json'),assets=read('export-identity.json'),runtime_transfer_size=read('runtime-size.json'),performance=perf,
 frontend=dict(check='passed',build='passed',initial_js_raw_bytes=404405,initial_js_gzip_bytes=130081),
 initial_failures='First native run:14 failures,12 float32 tiny-group native cancellation differences and2 helper .numpy() calls on native tensors requiring grad. Original failed source/log preserved. Strict ordinary-group native tests plus independent precision-scaled tiny-group math tests pass.',
 all_local_producers_terminal=True,producer_receipts='Focused29090, standalone55221, native62612, native-catalog37017, full-WASM15939, Node34875, Chrome56811, frontend56062, standalone wheel67008, private build44610, vizdata32847 and performance13041 all observed terminal0. Initial native61084 terminal1 retained.',
 live_expected_hashes=live_hashes,remote_adoption='Publication and exact-commit remote Quality/Pages/live proof follow local validation.',
 logs={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in logs})
(root/'local-validation.json').write_text(json.dumps(report,indent=2)+'\n');(result_dir/'iteration-17.json').write_text(json.dumps(report,indent=2)+'\n')
# Original runners, frozen implementation/harness and browser snapshot; no env,
# binary distributions, node_modules or bytecode are archived.
archive=result_dir/'iteration-17-harness.tar.gz';members=[]
for base in [root,root/'perf-frozen',root/'chrome-contracts']:
 for p in (base.iterdir() if base==root else base.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts and (p.suffix in ['.py','.mjs'] or p.name in ['LICENSE','NOTICE','plan.json','groupnorm-native.log']):members.append(p)
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as out:
 for p in sorted(set(members)):
  raw=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(root)));info.size=len(raw);info.mtime=0;info.mode=0o644;out.addfile(info,io.BytesIO(raw))
print(json.dumps(dict(status=report['status'],frozen_live_files=len(live_hashes),harness_files=len(set(members)),evidence_bytes=(result_dir/'iteration-17.json').stat().st_size)))
