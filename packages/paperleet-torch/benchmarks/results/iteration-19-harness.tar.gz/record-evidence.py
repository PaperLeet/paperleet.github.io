from pathlib import Path
import gzip,hashlib,io,json,math,re,shutil,tarfile
r=Path(__file__).parent;repo=Path.cwd();read=lambda n:json.loads((r/n).read_text());results=repo/'packages/paperleet-torch/benchmarks/results'
def clean(v):
 if isinstance(v,float) and not math.isfinite(v):return 'NaN' if math.isnan(v) else 'Infinity' if v>0 else '-Infinity'
 if isinstance(v,dict):return {k:clean(x) for k,x in v.items()}
 if isinstance(v,list):return [clean(x) for x in v]
 return v
hashes=read('matrix-source-hashes.json');source=repo/'packages/paperleet-torch/src/paperleet_torch'
assert hashes=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
assert hashes==read('distribution-identity-final.json')['source_hashes']==read('matrix-wasm.json')['source_hashes']==read('chrome-matrix/result.json')['source_hashes']
perf=read('performance-summary.json');assert perf['status']=='success'
assert hashes=={k.removeprefix('src/paperleet_torch/'):v for k,v in perf['inputs'].items() if k.startswith('src/paperleet_torch/')}
for name,digest in perf['inputs'].items():assert hashlib.sha256((r/'perf-frozen'/name).read_bytes()).hexdigest()==digest
for name,digest in perf['inputs'].items():
 if name.startswith('benchmarks/'):assert hashlib.sha256((repo/'packages/paperleet-torch'/name).read_bytes()).hexdigest()==digest
ci=read('native-ci.json');wasm=read('full-wasm-result.json')
assert ci['passed'] and ci['problems']==len(json.loads((repo/'web/public/data/index.json').read_text())['problems']) and not ci['issues'] and sum(map(len,ci['mutation'].values()))>=336
assert wasm['passed'] and wasm['modules']==ci['problems']
assert ci['tests_executed']==10218 and sum(map(len,ci['mutation'].values()))==342
assert not wasm['browser_budget_exceeded']
native=(r/'full-native.log').read_text();match=re.search(r'(\d+) passed, (1) skipped, (\d+) warnings in ([\d.]+)s',native);assert match
assert '642 passed' in (r/'python310-v019-final-tests.log').read_text()
assert 'PASS initial build graph:' in (r/'frontend-build.log').read_text()
index=json.loads((repo/'web/public/data/index.json').read_text());by_id={x['id']:x for x in index['problems']};paths={'index.json','index-v3.json','catalog.json'};data=repo/'web/public/data'
for row in wasm['results']:
 entry=by_id[row['id']];assert entry['browser_judge']['bundle_url']==row['bundle_url']
 manifest=json.loads((data/row['bundle_url']).read_text());assert manifest['runtime_bundle_url']==row['runtime_bundle_url']
 assert hashlib.sha256(manifest['reference'].encode()).hexdigest()==row['source_sha256']
 paths.update([entry['detail_url'],row['bundle_url'],row['runtime_bundle_url']])
expected=r/'live-expected';expected.mkdir(exist_ok=False);live_hashes={}
for name in sorted(paths):
 p=expected/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(data/name,p);live_hashes[name]=hashlib.sha256(p.read_bytes()).hexdigest()
(r/'live-expected-hashes.json').write_text(json.dumps(live_hashes,indent=2)+'\n')
logs={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in r.glob('*.log')}
report=dict(status='local release gates passed;exact remote adoption pending',version='0.19.0',source_hashes=hashes,
 infrastructure=dict(passed=int(match[1]),skipped=1,warnings=int(match[3]),duration_s=float(match[4])),native_reference_convolution_cases=1182,independent_convolution_cases=207,focused=1389,
 native_probes={n:read(n) for n in ['native-convolution-audit.json','native-conv-edges.json','native-conv-jvp-boundaries.json']},
 native_catalog=ci,real_wasm_catalog=wasm,node_contracts=read('matrix-wasm.json'),chrome_worker=read('chrome-matrix/result.json'),minimum_wheel=read('wheel-v019-final-result.json'),distributions=read('distribution-identity-final.json'),
 assets=read('export-identity.json'),runtime_transfer_size=read('runtime-size.json'),performance=perf,raw_numpy_prototype=read('kernel-experiment-v2.json'),
 retained_failures='12 native numeric-padding metadata list/tuple mismatch corrected;3 all-mode contiguity tests called unsupported Tensor.stride and now inspect actual NumPy element strides against native;first raw prototype had malformed larger-case fixture and no final report. Original inputs/logs retained. No math tolerance relaxation.',
 benchmark_scope='Production repacks during backward;raw NumPy prototype reused packed input. Distinct scopes and all regressions retained. Local shared machine;no verified actual BLAS thread count, native Torch latency, browser coldstart, peakmemory or whole-app speed claim.',
 timing_process_observation='16 children have exit0 receipts and frozen-hash success summary. Original parent57736 handle unavailable after context transition;authoritative process list confirmed no owned timing process. No fabricated parent terminal receipt.',
 predecessor_remote_adoption='iteration-18-remote-adoption.json retains exact verified predecessor main/Quality/Pages/live proof',logs=logs,live_expected_hashes=live_hashes)
raw=json.dumps(clean(report),indent=2,allow_nan=False)+'\n';(r/'local-validation.json').write_text(raw);(results/'iteration-19.json').write_text(raw)
members=set()
for p in r.iterdir():
 if p.is_file() and p.suffix in ('.py','.mjs','.log','.json'):members.add(p)
for folder in ('perf-frozen','kernel-frozen','kernel-frozen-v2','kernel-performance','kernel-performance-v2','performance','chrome-prototype','chrome-matrix'):
 for p in (r/folder).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and (p.suffix in ('.py','.mjs','.json','.log') or p.name in ('LICENSE','NOTICE')):members.add(p)
with (results/'iteration-19-harness.tar.gz').open('wb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT) as arc:
   for p in sorted(members):
    payload=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(r)));info.size=len(payload);info.mtime=0;info.mode=0o644;arc.addfile(info,io.BytesIO(payload))
print(json.dumps(dict(status=report['status'],evidence_bytes=len(raw.encode()),harness_files=len(members),live_files=len(live_hashes))))
