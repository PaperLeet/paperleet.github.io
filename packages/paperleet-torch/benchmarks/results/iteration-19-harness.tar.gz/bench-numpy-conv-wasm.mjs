import fs from 'node:fs';import path from 'node:path';import {parseArgs} from 'node:util';
import {loadPyodide} from '/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/pyodide.mjs';
const {values}=parseArgs({options:{source:{type:'string'},benchmark:{type:'string'},algorithm:{type:'string'},dtype:{type:'string'},output:{type:'string'}}});
const py=await loadPyodide({indexURL:'/Users/david/Developer/PaperLeet-torch-release/web/node_modules/pyodide/',packageCacheDir:'/Users/david/Developer/PaperLeet-torch-release/web/public/browser-runtime/pyodide-0.29.4/',stdout:console.log,stderr(){}});await py.loadPackage('numpy');py.FS.mkdirTree('/runtime/paperleet_torch');
for(const name of fs.readdirSync(values.source).filter(n=>n.endsWith('.py')||['LICENSE','NOTICE'].includes(n)))py.FS.writeFile('/runtime/paperleet_torch/'+name,fs.readFileSync(path.join(values.source,name),'utf8'));
py.FS.writeFile('/runtime/bench_numpy_conv.py',fs.readFileSync(values.benchmark,'utf8'));py.globals.set('config',JSON.stringify({algorithm:values.algorithm,dtype:values.dtype}));
const r=JSON.parse(py.runPython("import sys,json;sys.path.insert(0,'/runtime');import bench_numpy_conv;json.dumps(bench_numpy_conv.run_benchmarks(**json.loads(config)))"));r.pyodide=py.version;fs.writeFileSync(values.output,JSON.stringify(r,null,2)+'\n');console.log('PASS',r.pyodide,r.algorithm,r.dtype);
