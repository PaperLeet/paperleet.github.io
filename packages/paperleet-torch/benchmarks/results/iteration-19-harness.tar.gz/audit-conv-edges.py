from pathlib import Path
import json,torch
rows=[];torch.set_num_threads(1)
for dim in [1,2,3]:
 for channels in [0,2]:
  for size,padding,kernel,stride in [(0,1,1,1),(7,1,3,2)]:
   try:
    x=torch.ones((1,channels,*([size]*dim)),requires_grad=True);w=torch.ones((4,channels,*([kernel]*dim)),requires_grad=True);b=torch.ones(4,requires_grad=True);y=getattr(torch.nn.functional,f'conv{dim}d')(x,w,b,padding=padding,stride=stride);y.sum().backward();r=dict(shape=list(y.shape),dw=w.grad.sum().item(),db=b.grad.tolist())
   except Exception as e:r=dict(error=type(e).__name__,message=str(e))
   rows.append(dict(case=f'{dim}d C{channels} size{size} pad{padding} K{kernel} stride{stride}',result=r))
for mode in ['reflect','replicate','circular']:
 for pad in [2,3,4]:
  try:
   m=torch.nn.Conv1d(1,1,1,padding=pad,padding_mode=mode);y=m(torch.ones(1,1,3));r=list(y.shape)
  except Exception as e:r=dict(error=type(e).__name__,message=str(e))
  rows.append(dict(case=f'{mode} pad{pad} input3',result=r))
Path(__file__).with_name('native-conv-edges.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
