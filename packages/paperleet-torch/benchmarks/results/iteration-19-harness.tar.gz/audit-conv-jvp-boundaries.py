from pathlib import Path
import json,torch
rows=[];torch.set_num_threads(1)
for xvalue,wvalue in [(1.,1.),(float('inf'),1.),(1.,float('inf')),(float('nan'),1.)]:
 for active in ['input','weight','bias']:
  x=torch.full((1,1,3),xvalue,dtype=torch.float64,requires_grad=True);w=torch.full((1,1,1),wvalue,dtype=torch.float64,requires_grad=True);b=torch.ones(1,dtype=torch.float64,requires_grad=True);v=[x,w,b];i=['input','weight','bias'].index(active)
  def fn(z):
   a=v.copy();a[i]=z;return torch.nn.functional.conv1d(*a)
  p,t=torch.func.jvp(fn,(v[i],),(torch.ones_like(v[i]),));t.sum().backward();rows.append(dict(x=xvalue,w=wvalue,active=active,primal=p.tolist(),tangent=t.tolist(),gradients=[a.grad.tolist() if a.grad is not None else None for a in v]))
Path(__file__).with_name('native-conv-jvp-boundaries.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
