from pathlib import Path
import hashlib,json,tarfile,zipfile
root=Path(__file__).parent;repo=Path.cwd();expected=json.loads((root/'matrix-source-hashes.json').read_text());artifacts={};members={}
for folder,prefix,sdist_prefix in [('dist-final','paperleet_torch/','paperleet_torch-0.19.0/src/paperleet_torch/'),('dist-paperleet-final','paperleet/_vendor/torch/','paperleet-0.1.0/packages/paperleet-torch/src/paperleet_torch/')]:
 wheel=next((root/folder).glob('*.whl'));sdist=next((root/folder).glob('*.tar.gz'))
 with zipfile.ZipFile(wheel) as arc:
  modules=[n for n in arc.namelist() if n.startswith(prefix) and n.endswith('.py')];assert len(modules)==39
  for name,digest in expected.items():assert hashlib.sha256(arc.read(prefix+name)).hexdigest()==digest,(folder,name)
  members[folder]={n for n in arc.namelist() if n.endswith('.py')}
 with tarfile.open(sdist) as arc:
  for name,digest in expected.items():assert hashlib.sha256(arc.extractfile(sdist_prefix+name).read()).hexdigest()==digest,(folder,name)
 for p in [wheel,sdist]:artifacts[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
assert not members['dist-final'].intersection(members['dist-paperleet-final'])
assert expected==json.loads((root/'wheel-v019-final-result.json').read_text())['source_hashes']
assert expected==json.loads((root/'matrix-wasm.json').read_text())['source_hashes']
assert expected==json.loads((root/'chrome-matrix/result.json').read_text())['source_hashes']
assert expected=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'packages/paperleet-torch/src/paperleet_torch').iterdir() if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']}
r=dict(status='success',version='0.19.0',modules=39,source_hashes=expected,artifacts=artifacts,installed_paths_disjoint=True,minimum_environment='Python3.10.19 NumPy1.26.4 without native Torch;642 tests',license='Apache-2.0')
(root/'distribution-identity-final.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(dict(status=r['status'],modules=39,artifacts=artifacts)))
