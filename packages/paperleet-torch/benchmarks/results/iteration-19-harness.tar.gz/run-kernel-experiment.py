from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess,time
root=Path(__file__).parent;repo=Path.cwd();frozen=root/'kernel-frozen';frozen.mkdir(exist_ok=False);source=frozen/'src/paperleet_torch';source.mkdir(parents=True)
for p in (repo/'packages/paperleet-torch/src/paperleet_torch').iterdir():
 if p.suffix=='.py' or p.name in ['LICENSE','NOTICE']:shutil.copyfile(p,source/p.name)
for name in ['bench_numpy_conv.py','bench-numpy-conv-wasm.mjs']:shutil.copyfile(root/name,frozen/name)
def hashes():return {str(p.relative_to(frozen)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(frozen.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
expected=hashes();assert {n.removeprefix('src/paperleet_torch/'):v for n,v in expected.items() if n.startswith('src/paperleet_torch/')}==json.loads((root/'prototype-source-hashes.json').read_text())
target=root/'kernel-performance';target.mkdir(exist_ok=False);reports=[];order=['direct','matrix','matrix','direct']
for runtime in ['cpu','wasm']:
 for dtype in ['float32','float64']:
  for i,algorithm in enumerate(order):
   assert hashes()==expected;name=f'{runtime}-{dtype}-{i}-{algorithm}';out=target/(name+'.json');env=dict(os.environ,PYTHONPATH=str(source.parent),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
   args=[str(repo/'.venv/bin/python'),str(frozen/'bench_numpy_conv.py')] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(frozen/'bench-numpy-conv-wasm.mjs'),'--source',str(source),'--benchmark',str(frozen/'bench_numpy_conv.py')]
   args+=['--algorithm',algorithm,'--dtype',dtype,'--output',str(out)];start=time.monotonic()
   with (target/(name+'.log')).open('w') as log:r=subprocess.run(args,cwd=frozen,env=env,stdout=log,stderr=subprocess.STDOUT)
   with (target/'receipts.jsonl').open('a') as file:file.write(json.dumps(dict(runtime=runtime,dtype=dtype,index=i,algorithm=algorithm,args=args,exit_code=r.returncode,elapsed_s=time.monotonic()-start))+'\n')
   r.check_returncode();reports.append(dict(runtime=runtime,**json.loads(out.read_text())));assert hashes()==expected;print(name,'complete',flush=True)
summary={}
for runtime in ['cpu','wasm']:
 summary[runtime]={}
 for dtype in ['float32','float64']:
  rows=[r for r in reports if r['runtime']==runtime and r['dtype']==dtype];summary[runtime][dtype]={}
  for case in rows[0]['results']:
   medians={algo:[r['results'][case]['median_ms'] for r in rows if r['algorithm']==algo] for algo in ['direct','matrix']};summary[runtime][dtype][case]=dict(process_medians_ms=medians,matrix_time_reduction_percent=(1-statistics.median(medians['matrix'])/statistics.median(medians['direct']))*100)
record=dict(status='success',source_and_harness_hashes=expected,order=order,scope='Prototype NumPy kernels including packing, forward/dX/dW/db;no Tensor/graph/import/nativeTorch/full-application timing.16freshsequentialbalancedprocesses;all correctness/build producers terminal before start;all samples retained.',summary=summary,reports=reports)
(root/'kernel-experiment.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(summary,indent=2))
