from pathlib import Path
import json
r=Path(__file__).parent;repo=Path.cwd();perf=json.loads((r/'performance-summary.json').read_text());rows=[]
for case in perf['summary']['cpu']['float32']:
 vals=[perf['summary'][rt][dt][case]['time_reduction_percent'] for rt in ('cpu','wasm') for dt in ('float32','float64')]
 rows.append('| '+case+' | '+' | '.join(f'{v:.1f}%' for v in vals)+' |')
doc='''# Lightweight torch 0.19: grouped convolution

This iteration adds `nn.Conv1d/2d/3d`, functional `conv1d/2d/3d` and standard
`torch.nn.modules.conv` import aliases. The independent library continues to use
NumPy alone, ordinary torch imports through explicit host aliases/the script
launcher, Apache-2.0 resources and disjoint application/private package paths.

## Contract

Real float32/float64 inputs and matching weights/bias support batched/unbatched
layouts, groups/depthwise, stride/dilation, tuple/integer padding and same/valid.
Modules add zeros/reflect/replicate/circular padding and the common registered
parameter, dtype, initialization and in-memory checkpoint lifecycle. Same padding
requires unit stride. Reflect pads are smaller than the input axis; circular
pads cannot wrap more than once. General transpose convolution, float16/complex
kernels, GPU execution and higher-order reverse AD remain unsupported.

A shared analytical VJP computes only active input/weight/bias gradients.
Input and weight versions remain guarded even on bias-only tapes, without
retaining their original Tensor objects when neither array is required.
Nonzero-padding pullbacks accumulate duplicate source positions. Empty batches
and the native zero-input-channel output convention have explicit contracts.
Bilinear forward AD retains both convolution terms, including absent tangents
represented by explicit zeros: this preserves zero reverse dependencies and
zero-times-infinity/NaN behavior. Bias primals do not acquire tangent gradients.

## Kernel choice and workspace

Small/pointwise inputs use zero-copy window metadata and direct contractions.
Larger finite inputs use packed matrix products if the estimated logical NumPy
workspace fits 32 MiB. The estimate includes packed inputs, batch weight
contributions, output intermediates and padded input gradients; it is not a
NumPy/BLAS peak-memory bound. Inputs are repacked during backward rather than
retaining expanded im2col on the tape. Nonfinite operands/seeds retain direct
products. Forced direct/matrix/auto private test modes exercise all dispatch paths.

## Correctness and retained failures

The focused collection passes **1389 tests**: 1182 native-reference cases and
207 NumPy-only contracts, each covering direct/matrix/auto. Tests include scalar
convolution/gradient formulas, primal and JVP-reverse finite differences,
noncontiguous layouts, groups, padding adjoints, dtype and empty boundaries,
selective mutation guards, object lifetime, workspace fallback and complete
Conv/GroupNorm/SiLU/CE/AdamW/scheduler checkpoint-resume training. Separate native
probes retain geometry, padding, empty and nonfinite/partial-JVP observations.
Node/Pyodide 0.29.4 and Chrome 155.0.8059.82 Worker each pass **622 contracts**
against in-VM source/test hashes using NumPy 2.2.5.

Initial native tests retained 12 failures because numeric module padding metadata
used a list instead of native's tuple. This was corrected without numerical
changes; string same-padding retains native's list. The first all-kernel suite
retained 3 failures because a new contiguity test called the existing unsupported
Tensor.stride method. It now checks NumPy storage strides against native strides;
the outputs were already contiguous. Tensor.stride is not added by this release.
The raw prototype's first orchestrator failed on a malformed larger-case fixture;
the corrected distinct run retains per-sample logs. Original failed inputs/logs
are archived. No mathematical threshold was relaxed.

## Measured production path

The table is percent elapsed-time reduction for production auto dispatch versus
same-source direct convolution, including Tensor validation/allocation, packing,
graph construction, squared-mean loss and active reverse passes. Forward-only,
weight-only and bias-only cases are labeled separately. Each CPU/WASM and dtype
series uses four sequential fresh processes in direct/auto/auto/direct order,
nine batches, twenty base iterations and three warmups; tiny cases multiply
iterations by four, larger cases divide by eight. All raw samples/process medians
and frozen source/harness hashes are retained. CPU uses NumPy 2.5.4, WASM uses
Pyodide 0.29.4/NumPy 2.2.5. Thread-limit environment variables request two CPU
threads; this does not prove BLAS's actual thread count. These are local shared
machine measurements, with no claim about native Torch speed, browser startup,
whole-application latency or peak memory. Negative values mean slower.

| Case | CPU float32 | CPU float64 | WASM float32 | WASM float64 |
| --- | ---: | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'''

Tiny and pointwise dispatches retain direct kernels; their small differences
are process variance/dispatch cost. WASM depthwise results retain the observed
0.6–3.4% regression; matrix dispatch is not a universal improvement. Spatial and
3D cases provide the strongest measured benefit. No previous-release comparison
is possible because 0.18 did not provide these convolution operations.

The separate raw NumPy prototype experiment checks packing plus forward/dX/dW/db
but excludes Tensor graphs and reuses packed inputs within a training call.
Production repacks during backward. Its faster percentages must not be confused
with the complete Tensor measurements above. The first failed prototype has no
final report; only actually emitted evidence is retained.

## Release gates

Full application, minimum-version installation, distribution/export identity and
frontend gates are recorded with actual outcomes in the evidence after they
finish. Publication and exact remote adoption are separate from local correctness.
The fully verified 0.18 predecessor's Quality/Pages/live proof is carried in this
source iteration to avoid a separate documentation-only deployment.
'''
(repo/'docs/validation/torch-runtime-iteration-19.md').write_text(doc)
p=repo/'packages/paperleet-torch/ROADMAP.md';s=p.read_text();key='## Next implementation areas';assert key in s
s=s.replace(key,'''## Version 0.18 milestone

Weighted/smoothed/spatial cross entropy, probability targets and NLL add native
VJP/JVP and full checkpoint-resume coverage. Finite default CE caches its
analytical derivative and avoids generic spatial work. Rejected regressions and
final CPU/WASM measurements are retained. Exact main Quality, Pages and live
assets passed; see the iteration 18 remote adoption receipt.

## Version 0.19 milestone

Grouped 1D/2D/3D convolution adds batched/unbatched layouts, dilation, padding
modes, analytical active VJPs, bilinear JVP reverse tapes and module lifecycle.
Direct/packed-matrix/auto paths are tested against native and scalar mathematics.
A 32 MiB logical-workspace estimate bounds matrix dispatch and backward repacks
rather than retaining expanded activations. Actual WASM/Chrome and independent
CNN training supplement catalog coverage. Same-source CPU/WASM timing records
both spatial gains and depthwise regression. See the iteration 19 validation.

'''+key).replace('weighted/smoothed/spatial losses and convolution, with masked/empty/non-contiguous','transpose convolution and pooling, with masked/empty/non-contiguous')
p.write_text(s)
