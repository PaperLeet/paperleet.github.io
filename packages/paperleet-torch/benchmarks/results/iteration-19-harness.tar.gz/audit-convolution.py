from pathlib import Path
import json,numpy as np,torch
root=Path(__file__).parent;torch.set_num_threads(1);rows=[]
def record(case,fn):
 try:r=fn()
 except Exception as e:r=dict(error=type(e).__name__,message=str(e))
 rows.append(dict(case=case,result=r))
for dim in [1,2,3]:
 for batch in [0,1,2]:
  for padding,stride,dilation in [(0,1,1),(1,2,1),('same',1,2),('valid',2,1),('same',2,1)]:
   def run():
    shape=(2,4,*([7]*dim)) if batch==2 else ((0,4,*([7]*dim)) if batch==0 else (4,*([7]*dim)))
    x=torch.ones(shape,dtype=torch.float64,requires_grad=True);w=torch.ones((6,2,*([3]*dim)),dtype=torch.float64,requires_grad=True);b=torch.ones(6,dtype=torch.float64,requires_grad=True)
    y=getattr(torch.nn.functional,f'conv{dim}d')(x,w,b,stride,padding,dilation,2);y.sum().backward();return dict(shape=list(y.shape),sum=y.sum().item(),dxsum=x.grad.sum().item(),dwsum=w.grad.sum().item(),db=b.grad.tolist())
   record(f'{dim}d batch{batch} pad{padding} stride{stride} dilation{dilation}',run)
for dim in [1,2,3]:
 for mode in ['zeros','reflect','replicate','circular']:
  def run():
   m=getattr(torch.nn,f'Conv{dim}d')(2,4,2,padding='same',padding_mode=mode,dtype=torch.float64);x=torch.ones((1,2,*([3]*dim)),dtype=torch.float64,requires_grad=True);y=m(x);y.sum().backward();return dict(shape=list(y.shape),padding=m.padding,reversed_padding=m._reversed_padding_repeated_twice,repr=repr(m),dx=x.grad.sum().item())
  record(f'module{dim} {mode} same evenkernel',run)
for needs in [(True,True,True),(True,False,False),(False,True,False),(False,False,True)]:
 for changed in ['input','weight','bias','output']:
  def run():
   x=torch.ones(2,4,5,dtype=torch.float64,requires_grad=needs[0]);w=torch.ones(6,2,3,dtype=torch.float64,requires_grad=needs[1]);b=torch.ones(6,dtype=torch.float64,requires_grad=needs[2]);y=torch.nn.functional.conv1d(x,w,b,groups=2);v=dict(input=x,weight=w,bias=b,output=y)[changed]
   with torch.no_grad():v.add_(1)
   y.sum().backward();return 'ok'
  record(f'guards needs{needs} changed{changed}',run)
for dim in [1,2,3]:
 for in_channels,out_channels,spatial in [(0,4,3),(4,0,3),(4,4,0)]:
  def run():
   x=torch.ones((2,in_channels,*([spatial]*dim)),requires_grad=True);w=torch.ones((out_channels,in_channels,*([1]*dim)),requires_grad=True);y=getattr(torch.nn.functional,f'conv{dim}d')(x,w);y.sum().backward();return dict(shape=list(y.shape),dx=list(x.grad.shape),dw=list(w.grad.shape))
  record(f'empty{dim} {in_channels}/{out_channels}/{spatial}',run)
# Tangent dependency structure matters when only one input is dual.
rng=np.random.default_rng(1901);arrays=[rng.normal(size=(1,2,5)),rng.normal(size=(3,2,3)),rng.normal(size=3)]
for active in ['all','input','weight','bias']:
 def run():
  v=[torch.tensor(a,requires_grad=True) for a in arrays];t=[torch.ones_like(a,requires_grad=True) for a in v]
  if active=='all':p,d=torch.func.jvp(lambda x,w,b:torch.nn.functional.conv1d(x,w,b),tuple(v),tuple(t))
  else:
   i=['input','weight','bias'].index(active)
   def fn(z):
    a=v.copy();a[i]=z;return torch.nn.functional.conv1d(*a)
   p,d=torch.func.jvp(fn,(v[i],),(t[i],))
  d.square().sum().backward();return dict(primal_requires=p.requires_grad,tangent_requires=d.requires_grad,primal_grads=[None if a.grad is None else a.grad.tolist() for a in v],tangent_grads=[None if a.grad is None else a.grad.tolist() for a in t])
 record('jvp '+active,run)
report=dict(native=torch.__version__,numpy=np.__version__,rows=rows);(root/'native-convolution-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({r['case']:r['result'] if isinstance(r['result'],str) or 'error' in r['result'] else {k:v for k,v in r['result'].items() if k in ['shape','padding','reversed_padding','primal_requires','tangent_requires']} for r in rows},indent=2))
