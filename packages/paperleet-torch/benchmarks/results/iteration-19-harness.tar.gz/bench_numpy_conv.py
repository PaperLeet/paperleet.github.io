"""Prototype NumPy kernels, including packing and all three training pullbacks.

This excludes Tensor/graph/import costs and is not a production dispatcher.
"""
import itertools,json,math,platform,statistics,sys,time
import numpy as np
from paperleet_torch import _convolution as conv


def fixture(spec,dtype):
    n,ci,co,spatial,kernel,stride,dilation,pad,groups=spec;rng=np.random.default_rng(1911);dim=len(spatial)
    x=rng.normal(size=(n,ci,*spatial)).astype(dtype);w=rng.normal(size=(co,ci//groups,*kernel)).astype(dtype);b=rng.normal(size=co).astype(dtype)
    pairs=tuple((p,p) for p in pad);effective=tuple(d*(k-1)+1 for d,k in zip(dilation,kernel));padded=tuple(v+2*p for v,p in zip(spatial,pad));out=tuple((v-k)//s+1 for v,k,s in zip(padded,effective,stride));g=rng.normal(size=(n,co,*out)).astype(dtype)
    return (x,w,b,g),(groups,kernel,stride,dilation,pairs,padded,effective,out)


def operation(arrays,geometry,algorithm,training):
    x,w,b,seed=arrays;groups,kernel,stride,dilation,pairs,padded,effective,out=geometry;dim=len(kernel);n,ci=x.shape[:2];co=w.shape[0];ig,og=ci//groups,co//groups;sp='pqr'[:dim];ks='uvw'[:dim];points=math.prod(out);width=ig*math.prod(kernel)
    data,_=conv._pad(x,pairs,'zeros');patch=conv._windows(data,x.shape,groups,kernel,stride,dilation,effective,out);wg=w.reshape(groups,og,ig,*kernel);g=seed.reshape(n,groups,og,*out)
    if algorithm=='direct':y=np.einsum(f'bgi{sp}{ks},goi{ks}->bgo{sp}',patch,wg,optimize=False)
    else:
        axes=(0,1,*range(3,3+dim),2,*range(3+dim,3+2*dim));packed=patch.transpose(axes).reshape(n,groups,points,width);wf=wg.reshape(groups,og,width)
        y=np.swapaxes(packed@np.swapaxes(wf,-1,-2),-1,-2).reshape(n,groups,og,*out)
    y=y.reshape(n,co,*out)+b.reshape(1,co,*([1]*dim))
    if not training:return [y]
    dx=np.zeros((n,groups,ig,*padded),dtype=x.dtype)
    if algorithm=='matrix':
        gf=g.reshape(n,groups,og,points);columns=np.swapaxes(gf,-1,-2)@wf
        patch_grad=columns.reshape(n,groups,*out,ig,*kernel).transpose(np.argsort(axes))
        dw=(gf@packed).sum(0).reshape(w.shape)
    else:dw=np.einsum(f'bgo{sp},bgi{sp}{ks}->goi{ks}',g,patch,optimize=False).reshape(w.shape)
    for position in itertools.product(*[range(k) for k in kernel]):
        if algorithm=='direct':delta=np.einsum('goi,bgo...->bgi...',wg[(slice(None),slice(None),slice(None),*position)],g,optimize=False)
        else:delta=patch_grad[(slice(None),slice(None),slice(None),*([slice(None)]*dim),*position)]
        key=(slice(None),slice(None),slice(None),*[slice(p*d,p*d+size*st,st) for p,d,size,st in zip(position,dilation,out,stride)])
        dx[key]+=delta
    dx=conv._unpad(dx.reshape(n,ci,*padded),x.shape,pairs,None);db=seed.sum(axis=(0,*range(2,dim+2)))
    return [y,dx,dw,db]


def run_benchmarks(algorithm='direct',dtype='float32',repeat=7,iterations=3):
    definitions={
      'pointwise':(4,8,16,(16,16),(1,1),(1,1),(1,1),(0,0),1),
      'spatial':(2,8,16,(16,16),(3,3),(1,1),(1,1),(1,1),1),
      'depthwise':(2,16,32,(16,16),(3,3),(1,1),(1,1),(1,1),16),
      'dilated_1d':(4,8,16,(128,),(3,),(2,),(2,),(2,),2),
      'volume_3d':(1,4,8,(8,8,8),(3,3,3),(1,1,1),(1,1,1),(1,1,1),1),
      'larger_image':(2,16,32,(32,32),(3,3),(1,1),(1,1),(1,1),1)}
    results={}
    for name,spec in definitions.items():
        arrays,geometry=fixture(spec,np.dtype(dtype));reference=operation([a.astype(np.float64) for a in arrays],geometry,'direct',True)
        for training in [False,True]:
            label=name+('/train' if training else '/forward');values=operation(arrays,geometry,algorithm,training);errors=[]
            for actual,expected in zip(values,reference):
                np.testing.assert_allclose(actual,expected,rtol=8e-5 if dtype=='float32' else 5e-11,atol=4e-4 if dtype=='float32' else 2e-11);errors.append(float(np.max(np.abs(actual-expected))))
            count=1 if name=='larger_image' else iterations
            for _ in range(2):operation(arrays,geometry,algorithm,training)
            samples=[]
            for _ in range(repeat):
                start=time.perf_counter()
                for __ in range(count):operation(arrays,geometry,algorithm,training)
                samples.append((time.perf_counter()-start)*1000/count)
            points=math.prod(geometry[-1]);workspace=spec[0]*points*spec[1]*math.prod(spec[4])*np.dtype(dtype).itemsize
            results[label]=dict(spec=spec,training=training,samples_ms=samples,median_ms=statistics.median(samples),iterations=count,errors_vs_float64=errors,packed_activation_bytes=workspace)
            print('BENCH_SAMPLE '+json.dumps(dict(case=label,algorithm=algorithm,dtype=dtype,result=results[label])),flush=True)
    return dict(status='success',algorithm=algorithm,dtype=dtype,seed=1911,repeat=repeat,base_iterations=iterations,warmup=2,numpy=np.__version__,python=platform.python_version(),platform=platform.platform(),results=results,scope=__doc__)


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--algorithm',choices=['direct','matrix'],required=True);p.add_argument('--dtype',required=True);p.add_argument('--output',required=True);a=p.parse_args();r=run_benchmarks(a.algorithm,a.dtype);open(a.output,'w').write(json.dumps(r,indent=2)+'\n');print('PASS',a.algorithm,a.dtype)
