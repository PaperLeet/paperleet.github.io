"""Native shape/axis/value/stride/alias and reverse/forward contracts."""
import itertools
import warnings
import numpy as np
import pytest
import torch as native
from paperleet_torch import torch


def boundary_cases():
    rows=[]
    for shape in [(),(1,),(2,3),(2,1,3),(0,1,3)]:
        a=np.arange(np.prod(shape,dtype=int),dtype=np.float64).reshape(shape);n=len(shape)
        dims=[-n-2,-n-1,-1,0,1,n-1,n,n+1,True,1.2,None]
        for lo,hi in itertools.product(dims[:8],dims[:8]):rows += [(a,'flatten',(lo,hi)),(a,'transpose',(lo,hi))]
        for d in dims:rows += [(a,'unsqueeze',(d,)),(a,'squeeze',(d,))]
        rows += [(a,'squeeze',((0,1),)),(a,'squeeze',((0,0),)),(a,'squeeze',((),)),(a,'permute',()),(a,'permute',(tuple(range(n)),)),(a,'permute',(tuple(reversed(range(n))),)),(a,'permute',((n,*range(1,n)),)),(a,'permute',((True,*range(1,n)),)),(a,'permute',((0,)*n,)),(a,'expand',((-1,)*(n+1),)),(a,'expand',((1,*shape),))]
    return rows


@pytest.mark.parametrize('data,method,args',boundary_cases())
def test_native_shape_boundary_matrix(data,method,args):
    x=torch.from_numpy(data);rx=native.from_numpy(data)
    try:expected=getattr(rx,method)(*args)
    except (TypeError,IndexError,RuntimeError) as error:
        with pytest.raises(type(error)):getattr(x,method)(*args)
        return
    actual=getattr(x,method)(*args)
    np.testing.assert_array_equal(actual.numpy(),expected.numpy())
    assert actual.shape==tuple(expected.shape) and actual.stride()==expected.stride()
    assert (actual is x)==(expected is rx)
    assert actual.data_ptr()==x.data_ptr()


def values(shape,layout,dtype):
    a=np.arange(np.prod(shape,dtype=int),dtype=dtype).reshape(shape)/13
    if layout=='fortran':return np.asfortranarray(a)
    if layout=='step' and a.ndim:return np.repeat(a,2,axis=-1)[...,::2]
    if layout=='singleton' and a.ndim:
        strides=list(a.strides)
        for k,n in enumerate(a.shape):
            if n==1:strides[k]=0
        return np.lib.stride_tricks.as_strided(a,shape=a.shape,strides=strides)
    return a


def transform(x,name):
    n=x.ndim
    if name=='flatten':return x.flatten()
    if name=='permute':return x.permute(tuple(reversed(range(n))))
    if name=='transpose':return x.transpose(0,-1)
    if name=='unsqueeze':return x.unsqueeze(0)
    if name=='squeeze':return x.squeeze()
    if name=='squeeze_tuple':return x.squeeze(tuple(range(n)))
    return x.expand(2,*x.shape)


@pytest.mark.parametrize('shape',[(),(1,),(2,3),(2,1,3),(0,1,3)])
@pytest.mark.parametrize('layout',['C','fortran','step','singleton'])
@pytest.mark.parametrize('dtype',[np.float32,np.float64])
@pytest.mark.parametrize('method',['flatten','permute','transpose','unsqueeze','squeeze','squeeze_tuple','expand'])
def test_native_shape_workflow_values_metadata_and_vjp(shape,layout,dtype,method):
    data=values(shape,layout,dtype);x=torch.from_numpy(data).requires_grad_();rx=native.from_numpy(data).requires_grad_()
    y=transform(x,method);ry=transform(rx,method)
    np.testing.assert_array_equal(y.numpy(),ry.detach().numpy())
    assert y.stride()==ry.stride() and (y is x)==(ry is rx)
    for scale in [1.,-.7]:
        g=(np.arange(y.numel(),dtype=dtype)+.1).reshape(y.shape)*scale
        y.backward(torch.from_numpy(g),retain_graph=True);ry.backward(native.from_numpy(g),retain_graph=True)
        np.testing.assert_allclose(x.grad.numpy(),rx.grad.numpy(),rtol=3e-6,atol=2e-7)


@pytest.mark.parametrize('shape',[(2,3),(2,1,3),(0,1,3)])
@pytest.mark.parametrize('primal_layout',['C','fortran','step'])
@pytest.mark.parametrize('tangent_layout',['C','fortran','step'])
@pytest.mark.parametrize('method',['flatten','permute','transpose','unsqueeze','squeeze_tuple','expand'])
def test_native_shape_jvp_values_metadata_and_reverse(shape,primal_layout,tangent_layout,method):
    a=values(shape,primal_layout,np.float64);b=values(shape,tangent_layout,np.float64)
    x=torch.from_numpy(a).requires_grad_();t=torch.from_numpy(b).requires_grad_();rx=native.from_numpy(a).requires_grad_();rt=native.from_numpy(b).requires_grad_()
    p,q=torch.func.jvp(lambda z:transform(z,method),(x,),(t,));rp,rq=native.func.jvp(lambda z:transform(z,method),(rx,),(rt,))
    np.testing.assert_array_equal(p.numpy(),rp.detach().numpy());np.testing.assert_array_equal(q.numpy(),rq.detach().numpy())
    assert p.stride()==rp.stride() and q.stride()==rq.stride()
    g=torch.autograd.grad(q.square().sum(),(x,t),allow_unused=True);rg=native.autograd.grad(rq.square().sum(),(rx,rt),allow_unused=True)
    for actual,expected in zip(g,rg):
        assert (actual is None)==(expected is None)
        if actual is not None:np.testing.assert_allclose(actual.numpy(),expected.numpy(),rtol=1e-12,atol=1e-13)


@pytest.mark.parametrize('name,args',[('flatten',()),('transpose',(0,1)),('unsqueeze',(1,)),('squeeze',()),('squeeze',((0,1),)),('permute',((1,0),)),('broadcast_to',((2,3),))])
def test_native_functional_shape_entries(name,args):
    x=torch.arange(3,dtype=torch.float64).reshape(1,3).requires_grad_();rx=native.arange(3,dtype=native.float64).reshape(1,3).requires_grad_()
    y=getattr(torch,name)(x,*args);ry=getattr(native,name)(rx,*args)
    np.testing.assert_array_equal(y.numpy(),ry.detach().numpy());assert y.stride()==ry.stride()
    y.square().sum().backward();ry.square().sum().backward()
    np.testing.assert_array_equal(x.grad.numpy(),rx.grad.numpy())
    with pytest.raises(TypeError):getattr(torch,name)([1,2,3],*args)


def test_keywords_duplicates_and_empty_permutations():
    x=torch.ones(2,3)
    assert x.permute(dims=(1,0)).shape==(3,2)
    assert torch.permute(x,dims=(1,0)).shape==(3,2)
    assert torch.ones(1,3).expand(size=(2,3),implicit=True).stride()==(0,1)
    with pytest.raises(TypeError):x.permute((1,0),dims=(1,0))
    with pytest.raises(TypeError):torch.permute(x,1,0)
    with pytest.raises(TypeError):torch.permute(torch.ones(2),0)
    with pytest.raises(TypeError):torch.ones(1,3).expand((2,3),size=(2,3))
    with pytest.raises(TypeError):torch.ones(1,3).expand(2,3,implicit=1)
    scalar=torch.tensor(2.);assert scalar.permute(()).shape==()
