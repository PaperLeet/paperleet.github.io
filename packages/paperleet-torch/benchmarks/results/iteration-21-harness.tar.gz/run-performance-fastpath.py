from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess,time
r=Path(__file__).parent;repo=Path.cwd();frozen=r/'perf-frozen-fastpath';frozen.mkdir(exist_ok=False)
for role,source in [('baseline',r.parent/'torch-iteration-20/perf-frozen-inline/candidate/paperleet_torch'),('candidate',repo/'packages/paperleet-torch/src/paperleet_torch')]:
 target=frozen/role/'paperleet_torch';target.mkdir(parents=True)
 for p in source.iterdir():
  if p.suffix=='.py' or p.name in ('LICENSE','NOTICE'):shutil.copyfile(p,target/p.name)
for name in ['bench_layout.py','bench-layout-wasm.mjs']:shutil.copyfile(r/name,frozen/name)
def hashes():return {str(p.relative_to(frozen)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(frozen.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
inputs=hashes();out=r/'performance-fastpath';out.mkdir(exist_ok=False);reports=[]
env=dict(os.environ,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2')
for runtime in ['cpu','wasm']:
 for dtype in ['float32','float64']:
  for index,role in enumerate(['baseline','candidate','candidate','baseline']):
   assert hashes()==inputs
   source=frozen/role/'paperleet_torch';label=f'{runtime}-{dtype}-{index}-{role}';output=out/(label+'.json')
   args=[str(repo/'.venv/bin/python'),str(frozen/'bench_layout.py')] if runtime=='cpu' else ['/opt/homebrew/bin/node',str(frozen/'bench-layout-wasm.mjs'),'--source',str(source)]
   args += ['--dtype',dtype,'--repeat','11','--iterations','1200','--output',str(output)]
   process_env=dict(env,PYTHONPATH=str(source.parent));start=time.monotonic()
   with (out/(label+'.log')).open('w') as log:result=subprocess.run(args,env=process_env,cwd=frozen,stdout=log,stderr=subprocess.STDOUT)
   receipt=dict(runtime=runtime,dtype=dtype,index=index,role=role,args=args,elapsed_s=time.monotonic()-start,exit_code=result.returncode)
   with (out/'receipts.jsonl').open('a') as f:f.write(json.dumps(receipt)+'\n')
   result.check_returncode();report=json.loads(output.read_text());expected={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')};assert report['source_hashes']==expected
   if runtime=='cpu':assert str(source) in report['runtime_module']
   else:assert report['pyodide']=='0.29.4' and report['numpy']=='2.2.5'
   reports.append(dict(runtime=runtime,role=role,**report));assert hashes()==inputs;print(label,'complete',flush=True)
summary={}
for runtime in ['cpu','wasm']:
 summary[runtime]={}
 for dtype in ['float32','float64']:
  rows=[x for x in reports if x['runtime']==runtime and x['dtype']==dtype];summary[runtime][dtype]={}
  for case in rows[0]['results']:
   medians={role:[x['results'][case]['median_ms'] for x in rows if x['role']==role] for role in ['baseline','candidate']}
   before=statistics.median(medians['baseline']);after=statistics.median(medians['candidate']);summary[runtime][dtype][case]=dict(process_medians_ms=medians,time_reduction_percent=(1-after/before)*100)
record=dict(status='success',scope='Same successful shape/views and common allocation controls;baseline0.20 vs candidate0.21;four balanced fresh processes per runtime/dtype;all samples retained;local shared machine,requested thread limits not verified BLAS thread count;no fullapplication/nativeTorch/coldstart/peakmemory claim',inputs=inputs,summary=summary,reports=reports)
(r/'performance-fastpath-summary.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(summary,indent=2))
