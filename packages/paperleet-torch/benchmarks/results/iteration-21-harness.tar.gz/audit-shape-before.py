from pathlib import Path
import json,itertools,warnings
import numpy as np
import torch as native
import paperleet_torch
from paperleet_torch import torch as light
r=Path(__file__).parent;rows=[]
for shape in [(),(1,),(2,3),(2,1,3),(0,1,3)]:
 data=np.arange(np.prod(shape,dtype=int),dtype=np.float64).reshape(shape)
 n=len(shape)
 calls=[]
 dims=[-n-2,-n-1,-1,0,1,n-1,n,n+1,True,1.2,None]
 for a,b in itertools.product(dims[:8],dims[:8]):
  calls += [('flatten',(a,b)),('transpose',(a,b))]
 for axis in dims:
  calls += [('unsqueeze',(axis,)),('squeeze',(axis,))]
 calls += [('squeeze',((0,1),)),('squeeze',((0,0),)),('squeeze',((),)),('permute',()),('permute',(tuple(range(n)),)),('permute',(tuple(reversed(range(n))),)),('permute',((n,*range(1,n)),)),('permute',((True,*range(1,n)),)),('permute',((0,)*n,)),('expand',((-1,)*(n+1),)),('expand',((1,*shape),))]
 for method,args in calls:
  row=dict(shape=shape,method=method,args=repr(args))
  for role,api in [('native',native),('light',light)]:
   x=api.from_numpy(data)
   try:
    y=getattr(x,method)(*args)
    row[role]=dict(status='success',shape=tuple(y.shape),values=y.tolist(),strides=y.stride(),same_object=y is x)
   except Exception as e:row[role]=dict(status='error',type=type(e).__name__,message=str(e))
  a,b=row['native'],row['light'];row['difference']=(a['status']!=b['status'] or a['status']=='success' and a!=b)
  row['error_type_difference']=a['status']==b['status']=='error' and a['type']!=b['type'];rows.append(row)
report=dict(native=native.__version__,numpy=np.__version__,library=paperleet_torch.__version__,cases=len(rows),semantic_differences=sum(x['difference'] for x in rows),error_type_differences=sum(x['error_type_difference'] for x in rows),rows=rows)
(r/'shape-before.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k!='rows'})
for method in ['flatten','transpose','permute','squeeze','unsqueeze','expand']:
 errors=[x for x in rows if x['method']==method and x['difference']];print(method,len(errors))
 for row in errors[:3]:print(row)
