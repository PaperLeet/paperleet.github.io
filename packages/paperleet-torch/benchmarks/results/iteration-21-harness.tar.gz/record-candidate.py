from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;repo=Path.cwd();src=repo/'packages/paperleet-torch/src/paperleet_torch';out=repo/'packages/paperleet-torch/benchmarks/results';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda name:json.loads((r/name).read_text())
source={p.name:sha(p) for p in src.iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
assert len(source)==42 and len([name for name in source if name.endswith('.py')])==40
assert source==read('fastpath-proof/source-hashes.json')==read('fastpath-proof/source-wasm.json')['source_hashes']==read('fastpath-proof/chrome-contracts/result.json')['source_hashes']==read('fastpath-proof/wheel-v021-preflight-result.json')['source_hashes']
assert source=={p.name:sha(p) for p in (r/'perf-frozen-fastpath/candidate/paperleet_torch').iterdir() if p.suffix=='.py' or p.name in ('LICENSE','NOTICE')}
assert sha(repo/'packages/paperleet-torch/benchmarks/bench_shape_ops.py')==sha(r/'perf-frozen-fastpath/bench_layout.py')
assert '22644 passed, 1 skipped, 17 warnings' in (r/'fastpath-proof/full-native.log').read_text()
assert '739 passed' in (r/'fastpath-proof/python310-v021-preflight-tests.log').read_text()
assert read('fastpath-proof/source-wasm.json')['passed']==719 and read('fastpath-proof/chrome-contracts/result.json')['passed']==719
assert not subprocess.check_output(['git','diff','--name-only','--','web/public'],cwd=repo,text=True).strip()
performance={}
for phase in ['shape','fastpath']:
 d=read(f'performance-{phase}-summary.json');receipts=[json.loads(line) for line in (r/f'performance-{phase}/receipts.jsonl').read_text().splitlines()];assert len(receipts)==16 and all(item['exit_code']==0 for item in receipts)
 assert len(d['reports'])==16
 for item in d['reports']:
  assert item['library']==('0.20.0' if item['role']=='baseline' else '0.21.0') and len(item['results'])==17
 performance[phase]=dict(**d,process_receipts=receipts)
receipts=dict(focused_dynamic=dict(handle=61602,exit_code=0,passed=1576),dynamic_node=dict(handle=60056,exit_code=0),dynamic_chrome=dict(handle=12991,exit_code=0),dynamic_minimum=dict(handle=13496,exit_code=0),dynamic_full=dict(handle=23613,exit_code=1,passed=22642,failed=1),expand_focused=dict(handle=49060,exit_code=0,passed=3185),expand_full=dict(handle=55271,exit_code=0,passed=22644),expand_node=dict(handle=19233,exit_code=0),expand_chrome=dict(handle=26660,exit_code=0),expand_minimum=dict(handle=98824,exit_code=0),performance_initial=dict(handle=97774,exit_code=0,child_processes=16),fastpath_focused=dict(handle=82597,exit_code=0,passed=3185),performance_fastpath=dict(handle=54380,exit_code=0,child_processes=16),final_full=dict(handle=1830,exit_code=0,passed=22644,skipped=1,warnings=17,elapsed_s=211.04),final_node=dict(handle=52950,exit_code=0,passed=719),final_chrome=dict(handle=51809,exit_code=0,passed=719),final_minimum=dict(handle=77420,exit_code=0,passed=739),maintained_cli=dict(handle=61108,exit_code=0,cases_per_runtime=17))
report=dict(status='unpublished development candidate;local infrastructure/runtime proofs passed;main adoption held',version='0.21.0',base_main='1770686e676e73c39790ef3e1538180d155a72c4',source_modules=40,license='Apache-2.0',source_hashes=source,new_native_cases=1333,new_independent_cases=42,terminal_receipts=receipts,source_wasm=read('fastpath-proof/source-wasm.json'),chrome=read('fastpath-proof/chrome-contracts/result.json'),minimum_wheel=read('fastpath-proof/wheel-v021-preflight-result.json'),performance=performance,maintained_cli={runtime:read(f'fastpath-proof/maintained-{runtime}.json') for runtime in ['cpu','wasm']},retained_failures=['62 initial0Dfixture mistakes,then20 emptyJVPstride mismatches;original logs/fixtures retained.','ScalarT identity,viewbase/noGradflags andstopedge mismatches repaired;original snapshots/logs retained.','32dynamicflag combos initially9differences;now0;permanent32native cases plus independent lifecycle tests.','Dynamic full suite1failed22642pass due singletonexpand checkedcopy;fixed and both complete188.61s/211.04s successors pass.','Initial python-m-build command failed because build.__main__ unavailable;no dependency installed in shared environment. uv build succeeded;original log retained.','Initial large shape/permutation/expand latency costs retained alongside optimized phase.'],recovered_previous_call='Preceding dynamicflags patch final call handle was unavailable after context truncation;matching processes absent and logs show32case0differences/2950passed. No exact terminal handle invented.',pending=['Complete native reference/mutation/determinism catalog','Complete exported real WASM catalog and application timing budgets','Final private/standalone distribution identity against merged upstream curriculum','Export preserving6124historical immutable assets;frontend andPagespolicy','Safe main integration and exactremoteQuality/eligiblePages/live adoption'],publication=dict(main='0.20 remains adopted;0.21 not pushed',pypi=False,browser_assets_changed=False),timing_limits='Shared machine;requested environment thread limits notverified actualBLASthreads;microbenchmarks do not establish nativeTorch/application/coldstart/peakmemory gain.',dynamic_audit=read('grad-flags-fixed.json'))
raw=json.dumps(report,indent=2,allow_nan=False)+'\n';(r/'local-candidate.json').write_text(raw);(out/'iteration-21.json').write_text(raw)
state=read('state.json');state.update(phase=report['status'],handles={},all_local_producers_terminal=True,current_proofs='fastpath-proof source matches current40modules/2license files and allruntime/distribution/timing snapshots',local_candidate='local-candidate.json',pending=report['pending']);state['terminal'].update(final_full_native=1830,final_node=52950,final_chrome=51809,final_minimum=77420,maintained_cli=61108);state['open_concerns']=['Expansion/bareview checking costs remain;broader application timing gates pending.','Complete catalog/export/private-distribution/upstream/frontend/remote gates remain.'];state['next']=['Review and checkpoint candidate development branch;no main21 adoption before pending gates.','Keep all regression/timing evidence;remaining performance costs documented.','Untracked20remoteadoptionproof carrieswith21substantivecommit;neverstageweb/node_modules.'];(r/'state.json').write_text(json.dumps(state,indent=2)+'\n')
files=[]
for p in r.rglob('*'):
 if not p.is_file() or '__pycache__' in p.parts:continue
 rel=p.relative_to(r)
 if any(part.startswith(('python310-','dist-')) for part in rel.parts):continue
 if p.suffix in ('.py','.mjs','.json','.log','.jsonl') or p.name in ('LICENSE','NOTICE'):files.append(p)
archive_path=out/'iteration-21-harness.tar.gz'
with archive_path.open('wb') as file:
 with gzip.GzipFile(filename='',mode='wb',fileobj=file,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT) as archive:
   for p in sorted(files):
    data=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(r)));info.size=len(data);info.mtime=0;info.mode=0o644;archive.addfile(info,io.BytesIO(data))

print(json.dumps(dict(status=report['status'],evidence_bytes=len(raw.encode()),archive_files=len(files),archive_sha256=sha(archive_path))))
