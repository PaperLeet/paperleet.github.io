from pathlib import Path
import itertools,json,warnings
import numpy as np
import torch as native
from paperleet_torch import torch as light
r=Path(__file__).parent;rows=[]
with warnings.catch_warnings():
 warnings.simplefilter('ignore')
 for mode,initial,promote,changes in itertools.product([False,True],[False,True],[False,True],[(True,),(False,),(True,False),(False,True)]):
  row=dict(recording=mode,initial_base=initial,promote_view=promote,base_changes=changes)
  for label,api in [('native',native),('light',light)]:
   try:
    base=api.from_numpy(np.arange(6.,dtype=np.float64)).requires_grad_(initial)
    with api.set_grad_enabled(mode):view=base.view(2,3)
    if promote:view.requires_grad_()
    steps=[]
    for flag in changes:
     base.requires_grad_(flag);steps.append(dict(base=base.requires_grad,view=view.requires_grad,leaf=view.is_leaf))
    out=view.square().sum()
    if out.requires_grad:out.backward()
    row[label]=dict(status='success',steps=steps,output_requires_grad=out.requires_grad,base_grad=None if base.grad is None else base.grad.tolist(),view_grad=None if view.grad is None else view.grad.tolist())
   except Exception as e:row[label]=dict(status='error',type=type(e).__name__,message=str(e))
  row['different']=row['native']!=row['light'];rows.append(row)
report=dict(cases=len(rows),differences=sum(x['different'] for x in rows),rows=rows);(r/'grad-flags-audit.json').write_text(json.dumps(report,indent=2)+'\n');print('Dynamic grad flag audit:',report['cases'],'cases,',report['differences'],'differences')
