from pathlib import Path
import hashlib,inspect,json,math,platform
import numpy as np
import torch
from paperleet_torch import torch as light, UnsupportedOperation

root=Path(__file__).parent;rng=np.random.default_rng(1601)
cases=[]
for dtype in [torch.float32,torch.float64]:
    for shape in [(5,3),(2,3,4),(2,3,2,4),(2,3,2,2,3)]:
        for training in [False,True]:
            for affine in [False,True]:
                xraw=rng.normal(size=shape);wraw=rng.normal(size=3) if affine else np.ones(3)
                braw=rng.normal(size=3) if affine else np.zeros(3);graw=rng.normal(size=shape)
                mean=rng.normal(size=3);variance=rng.uniform(.2,2,size=3)
                x=torch.tensor(xraw,dtype=dtype,requires_grad=True)
                w=torch.tensor(wraw,dtype=dtype,requires_grad=True) if affine else None
                b=torch.tensor(braw,dtype=dtype,requires_grad=True) if affine else None
                rm=torch.tensor(mean,dtype=dtype);rv=torch.tensor(variance,dtype=dtype)
                raw=[value.detach().double().numpy() if value is not None else None for value in (x,w,b,rm,rv)]
                xx,ww,bb,mm,vv=raw;axes=(0,*range(2,len(shape)));reshape=(1,3,*([1]*(len(shape)-2)))
                count=math.prod(shape)//3
                center=xx-xx.mean(axis=axes,keepdims=True) if training else xx-mm.reshape(reshape)
                var=np.mean(center*center,axis=axes,keepdims=True) if training else vv.reshape(reshape)
                inverse=1/np.sqrt(var+1e-5);normalized=center*inverse
                scale=wraw.reshape(reshape) if not affine else ww.reshape(reshape)
                offset=braw.reshape(reshape) if not affine else bb.reshape(reshape)
                output=normalized*scale+offset;seed=torch.tensor(graw,dtype=dtype);gg=seed.double().numpy();scaled=gg*scale
                dx=inverse*(scaled-scaled.mean(axis=axes,keepdims=True)-normalized*np.mean(scaled*normalized,axis=axes,keepdims=True)) if training else scaled*inverse
                expected=[output,dx]
                expected_mean=.9*mm+.1*xx.mean(axis=axes) if training else mm
                expected_var=.9*vv+.1*var.reshape(3)*count/(count-1) if training else vv
                value=torch.nn.functional.batch_norm(x,rm,rv,w,b,training,.1,1e-5)
                grads=torch.autograd.grad(value,[x,*([w,b] if affine else [])],seed)
                actual=[value.detach().double().numpy(),grads[0].double().numpy()]
                if affine:
                    expected += [np.sum(gg*normalized,axis=axes),np.sum(gg,axis=axes)]
                    actual += [gradient.double().numpy() for gradient in grads[1:]]
                expected += [expected_mean,expected_var];actual += [rm.double().numpy(),rv.double().numpy()]
                tolerance=2e-5 if dtype==torch.float32 else 2e-12
                for got,want in zip(actual,expected):np.testing.assert_allclose(got,want,rtol=tolerance,atol=tolerance)
                cases.append(dict(dtype=str(dtype),shape=shape,training=training,affine=affine,
                                  max_abs_errors=[float(np.max(np.abs(a-b))) for a,b in zip(actual,expected)]))

def capture(operation):
    try:
        value=operation()
        if isinstance(value,torch.Tensor):return dict(status='ok',shape=list(value.shape),values=value.tolist())
        return dict(status='ok',value=value)
    except Exception as error:return dict(status='error',type=type(error).__name__,message=str(error))
boundaries={}
for name,shape,training,eps in [
    ('empty_batch',(0,3),True,1e-5),('empty_spatial',(2,3,0),True,1e-5),('single_observation',(1,3),True,1e-5),
    ('zero_channels',(2,0),True,1e-5),('train_zero_eps',(2,3),True,0.),('eval_zero_eps',(2,3),False,0.),
    ('negative_eps',(2,3),False,-1e-5),('nan_eps',(2,3),True,float('nan'))]:
    module=torch.nn.BatchNorm1d(shape[1],eps=eps).train(training)
    outcome=capture(lambda:module(torch.ones(shape)))
    outcome.update(count=int(module.num_batches_tracked),mean=module.running_mean.tolist(),variance=module.running_var.tolist())
    boundaries[name]=outcome
for mean,var in [(None,None),(torch.zeros(3),None),(None,torch.ones(3))]:
    for training in [False,True]:
        key=f'partial_buffers_mean={mean is not None}_var={var is not None}_training={training}'
        boundaries[key]=capture(lambda:torch.nn.functional.batch_norm(torch.ones(4,3),mean,var,training=training))
for target in ['input','weight','bias','running_mean','running_var','output']:
    x=torch.randn(4,3,requires_grad=True);w=torch.ones(3,requires_grad=True);b=torch.zeros(3,requires_grad=True)
    rm=torch.zeros(3);rv=torch.ones(3);output=torch.nn.functional.batch_norm(x,rm,rv,w,b,True)
    tensors=dict(input=x,weight=w,bias=b,running_mean=rm,running_var=rv,output=output)
    with torch.no_grad():tensors[target].add_(1.)
    boundaries['mutate_'+target]=capture(lambda:output.sum().backward())
for tracked in [False,True]:
    model=torch.nn.BatchNorm1d(3,track_running_stats=tracked,dtype=torch.float64)
    x=torch.randn(4,3,dtype=torch.float64,requires_grad=True);v=torch.randn_like(x,requires_grad=True)
    boundaries['jvp_tracked_'+str(tracked)]=capture(lambda:tuple(value.shape for value in torch.func.jvp(model,(x,),(v,))))
versions=[]
model=torch.nn.BatchNorm1d(3,momentum=None)
for step in range(3):
    x=torch.arange(12,dtype=torch.float32).reshape(4,3)+step
    before=[value._version for value in [model.running_mean,model.running_var,model.num_batches_tracked]]
    model(x)
    versions.append(dict(step=step,before=before,after=[value._version for value in [model.running_mean,model.running_var,model.num_batches_tracked]],
                         count=model.num_batches_tracked.item(),mean=model.running_mean.tolist(),variance=model.running_var.tolist()))
gaps={}
for name in ['BatchNorm1d','BatchNorm2d','BatchNorm3d']:
    gaps[name]=capture(lambda:getattr(light.nn,name)(3))
gaps['functional.batch_norm']=capture(lambda:light.nn.functional.batch_norm(light.ones(4,3),None,None,training=True))
report=dict(status='success',scope='Native semantic audit only; no library implementation or performance claims.',native=torch.__version__,numpy=np.__version__,python=platform.python_version(),
            oracle_cases=cases,boundaries=boundaries,running_buffer_versions=versions,current_015_gaps=gaps,
            native_python_source_sha256=hashlib.sha256(inspect.getsource(torch.nn.modules.batchnorm).encode()).hexdigest(),harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(root/'native-batchnorm-audit.json').write_text(json.dumps(report,indent=2,allow_nan=True)+'\n')
print(json.dumps(dict(status='success',oracle_cases=len(cases),boundaries=boundaries,versions=versions,gaps=gaps),allow_nan=True))
