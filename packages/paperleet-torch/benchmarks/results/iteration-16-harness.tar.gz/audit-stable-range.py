from pathlib import Path
import hashlib,json
import numpy as np
import torch
from paperleet_torch import torch as light
root=Path(__file__).parent;rows=[]
for name,raw in [
    ('offset_small_variance',(10000+np.array([[-.03,.02],[-.01,.01],[.01,-.01],[.03,-.02]],dtype=np.float32)).astype(np.float32)),
    ('offset_unrepresentable_mean',(10000+np.array([[0,.001],[.001,.002],[.002,.004],[.004,.008]],dtype=np.float32)).astype(np.float32))]:
    data=raw.astype(np.float64);expected=(data-data.mean(0))/np.sqrt(data.var(0)+1e-5)
    native=torch.nn.functional.batch_norm(torch.tensor(raw),None,None,training=True).numpy()
    actual=light.nn.functional.batch_norm(light.tensor(raw),None,None,training=True).numpy()
    error=float(np.max(np.abs(actual-expected)));assert error<3e-7
    rows.append(dict(name=name,input=raw.tolist(),expected=expected.tolist(),actual=actual.tolist(),native=native.tolist(),
                     library_max_abs_error=error,native_max_abs_error=float(np.max(np.abs(native-expected)))))
report=dict(status='success',scope='Selected float32 conditioning cases against independent float64 centered math. Native CPU affine results preserved as observations, not a portable bitwise oracle.',native=torch.__version__,numpy=np.__version__,rows=rows,
    sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('packages/paperleet-torch/src/paperleet_torch').glob('*.py')},
    reference='https://github.com/pytorch/pytorch/blob/main/aten/src/ATen/native/cpu/batch_norm_kernel.cpp')
(root/'stable-range.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(rows))
