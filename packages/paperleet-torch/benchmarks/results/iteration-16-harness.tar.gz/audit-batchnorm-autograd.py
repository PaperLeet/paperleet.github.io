from pathlib import Path
import hashlib,json
import numpy as np
import torch

root=Path(__file__).parent;torch.manual_seed(1602);results={}
def capture(fn):
    try:return dict(status='ok',value=fn())
    except Exception as error:return dict(status='error',type=type(error).__name__,message=str(error))

for training in [False,True]:
    dtype=torch.float64
    raw=[torch.randn(4,3,dtype=dtype),torch.randn(3,dtype=dtype),torch.randn(3,dtype=dtype)]
    direction=[torch.randn_like(value) for value in raw]
    fixed_mean=torch.randn(3,dtype=dtype);fixed_var=torch.rand(3,dtype=dtype)+.5
    def native(x,w,b):return torch.nn.functional.batch_norm(x,None if training else fixed_mean,None if training else fixed_var,w,b,training)
    def composite(x,w,b):
        mean=x.mean(0) if training else fixed_mean
        variance=((x-mean)**2).mean(0) if training else fixed_var
        return (x-mean)*torch.rsqrt(variance+1e-5)*w+b
    left=[value.clone().requires_grad_() for value in [*raw,*direction]]
    right=[value.clone().requires_grad_() for value in [*raw,*direction]]
    a=torch.func.jvp(native,tuple(left[:3]),tuple(left[3:]))
    b=torch.func.jvp(composite,tuple(right[:3]),tuple(right[3:]))
    seed=[torch.randn_like(value) for value in a]
    ga=torch.autograd.grad(sum((value*g).sum() for value,g in zip(a,seed)),left)
    gb=torch.autograd.grad(sum((value*g).sum() for value,g in zip(b,seed)),right)
    errors=[float((u-v).abs().max()) for u,v in zip([*a,*ga],[*b,*gb])]
    results['reverse_over_forward_training_'+str(training)]=dict(errors=errors,mathematical_composite_matches=all(error<2e-12 for error in errors))

for tracking in [False,True]:
    model=torch.nn.BatchNorm1d(3,track_running_stats=tracking,dtype=torch.float64)
    before=None if model.num_batches_tracked is None else model.num_batches_tracked.item()
    outcome=capture(lambda:[value.shape for value in torch.func.jvp(model,(torch.randn(4,3,dtype=torch.float64),),(torch.ones(4,3,dtype=torch.float64),))])
    outcome.update(counter_before=before,counter_after=None if model.num_batches_tracked is None else model.num_batches_tracked.item())
    results['jvp_module_tracking_'+str(tracking)]=outcome
rm=torch.zeros(3);rv=torch.ones(3)
results['jvp_functional_closed_buffers']=capture(lambda:[value.shape for value in torch.func.jvp(lambda x:torch.nn.functional.batch_norm(x,rm,rv,training=True),(torch.randn(4,3),),(torch.ones(4,3),))])
results['jvp_functional_buffers_after']=dict(mean=rm.tolist(),variance=rv.tolist())

# Multiple training forwards update running buffers without invalidating the
# first reverse graph. An eval graph can consequently read newer buffers.
for first_training in [False,True]:
    model=torch.nn.BatchNorm1d(3,dtype=torch.float64)
    model.train(first_training)
    x=torch.randn(4,3,dtype=torch.float64,requires_grad=True)
    output=model(x);old_mean=model.running_mean.clone();old_var=model.running_var.clone()
    seed=torch.randn_like(output)
    model.train();model(torch.randn(7,3,dtype=torch.float64)*4+2)
    new_mean=model.running_mean.clone();new_var=model.running_var.clone()
    gradients=torch.autograd.grad(output,[x,model.weight,model.bias],seed)
    current=(x.detach()-new_mean)/torch.sqrt(new_var+model.eps)
    old=(x.detach()-old_mean)/torch.sqrt(old_var+model.eps)
    results['running_updates_after_'+('train' if first_training else 'eval')]=dict(
        dx=gradients[0].tolist(),dw=gradients[1].tolist(),
        eval_current_dx_error=float((gradients[0]-seed/torch.sqrt(new_var+model.eps)).abs().max()),
        eval_old_dx_error=float((gradients[0]-seed/torch.sqrt(old_var+model.eps)).abs().max()),
        eval_current_dw_error=float((gradients[1]-(seed*current).sum(0)).abs().max()),
        eval_old_dw_error=float((gradients[1]-(seed*old).sum(0)).abs().max()))

for active in [(False,False,True),(False,True,False),(True,False,False)]:
    for mutation in ['input','weight','bias','mean','variance','output']:
        x=torch.randn(4,3,requires_grad=active[0]);w=torch.ones(3,requires_grad=active[1]);b=torch.zeros(3,requires_grad=active[2]);mean=torch.zeros(3);variance=torch.ones(3)
        y=torch.nn.functional.batch_norm(x,mean,variance,w,b,training=True)
        with torch.no_grad():dict(input=x,weight=w,bias=b,mean=mean,variance=variance,output=y)[mutation].add_(1.)
        results['active_'+str(active)+'_mutate_'+mutation]=capture(lambda:y.sum().backward())
report=dict(status='success',native=torch.__version__,scope='Independent native BatchNorm graph/JVP audit; no library source changes.',results=results,harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(root/'batchnorm-autograd-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
