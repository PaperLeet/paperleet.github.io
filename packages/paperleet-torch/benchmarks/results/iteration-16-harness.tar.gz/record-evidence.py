from pathlib import Path
import gzip,hashlib,io,json,math,tarfile
root=Path(__file__).parent;repo=Path.cwd();out=repo/'packages/paperleet-torch/benchmarks/results'
read=lambda name:json.loads((root/name).read_text())
source={file.name:hashlib.sha256(file.read_bytes()).hexdigest() for file in (repo/'packages/paperleet-torch/src/paperleet_torch').iterdir() if file.suffix=='.py' or file.name in ('LICENSE','NOTICE')}
wheel=read('wheel-v016-result.json');browser=read('chrome-contracts-final/result.json');wasm=read('source-wasm.json');perf=read('performance-summary.json')
assert source==wheel['source_hashes']==browser['source_hashes']==wasm['source_hashes']
assert source=={name.removeprefix('src/paperleet_torch/'):value for name,value in perf['inputs'].items() if name.startswith('src/paperleet_torch/')}
assert browser['passed']==wasm['passed']==273 and wheel['native_torch'] is False
scripts=['audit-native-batchnorm.py','audit-batchnorm-autograd.py','audit-batchnorm-jvp-tape.py',
         'audit-batchnorm-range.py','audit-batchnorm-range-extended.py','audit-stable-range.py','wasm-contracts.mjs',
         'prepare-chrome-contracts.py','prepare-chrome-final.py','chrome-contracts-final/worker.mjs','chrome-contracts-final/run.mjs',
         'chrome-contracts-final/plan.json','check-wheel-v016.py','run-performance.py','record-evidence.py',
         'prototype/paperleet_torch/_batchnorm.py']
archive=out/'iteration-16-harness.tar.gz'
with archive.open('wb') as target:
    with gzip.GzipFile(fileobj=target,mode='wb',mtime=0,filename='') as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for name in sorted(scripts):
                data=(root/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
def safe(value):
    if isinstance(value,float) and not math.isfinite(value):return 'NaN' if math.isnan(value) else 'Infinity' if value>0 else '-Infinity'
    if isinstance(value,dict):return {key:safe(item) for key,item in value.items()}
    if isinstance(value,list):return [safe(item) for item in value]
    return value
report=dict(schema_version=1,version='0.16.0',scope='Candidate core BatchNorm evidence; complete application release gates remain pending.',source_hashes=source,
            native_semantics=read('native-batchnorm-audit.json'),native_graphs=read('batchnorm-autograd-audit.json'),native_jvp_tape=read('batchnorm-jvp-tape-audit.json'),
            initial_range=read('batchnorm-range-initial.json'),extended_initial_range=read('batchnorm-range-extended.json'),stable_range=read('stable-range.json'),
            running_statistics_jvp=read('native-stat-jvp.json'),performance=perf,browser=browser,wasm=wasm,wheel=wheel,
            native_batchnorm_tests=dict(passed=304,standalone_batchnorm=67,combined=371),
            numerical_policy='Centered output; selectively widened finite ill-conditioned float32 channels; channel-only inverse computed in float64 then cast once. Native CPU affine output differences explicitly retained, not hidden by relaxed general tolerances.',
            performance_scope='Joint BatchNorm versus Tensor composition in the same current library, not native Torch or an unsupported old-release BN API. 16 fresh sequential processes, two per implementation/dtype/runtime, balanced ABBA, all 9 batch samples retained. CPU float64 eval backward costs about4.3% more; it preserves native dynamic-running-buffer behavior.',
            primary_reference='https://github.com/pytorch/pytorch/blob/main/aten/src/ATen/native/cpu/batch_norm_kernel.cpp',
            harness=dict(file=archive.name,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),files={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in scripts}),
            historical_failures='Native audit first tried reading freed saved statistics; corrected collection before backward. Prototype tests initially attempted unsupported direct non-leaf writes, now exercise shared storage through supported detached aliases. No-grad running-statistic flags and forward-stat dual semantics were corrected against native observations. Raw original logs retained.',
            log_hashes={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['prototype-expanded.log','prototype-edges-revised.log','batchnorm-range.log','batchnorm-stable.log','batchnorm-workflows.log','batchnorm-stat-duals.log','wasm-latest.log','chrome-contracts-final/run.log','python310-v016-tests.log','performance-run.log']})
(out/'iteration-16.json').write_text(json.dumps(safe(report),indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(status='candidate evidence recorded',runtime_files=len(source),wasm=273,chrome=273,minimum_wheel_tests=293,performance_processes=len(perf['reports']))))
