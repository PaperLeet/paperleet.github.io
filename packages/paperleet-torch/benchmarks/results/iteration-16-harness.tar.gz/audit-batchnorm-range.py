from pathlib import Path
import hashlib,json
import numpy as np
import torch
from paperleet_torch import torch as light

root=Path(__file__).parent;rows=[]
examples={
    'large_finite':np.array([[-1e20,2e20],[-.5e20,1e20],[.5e20,-1e20],[1e20,-2e20]],dtype=np.float32),
    'offset_small_variance':(10000+np.array([[-.03,.02],[-.01,.01],[.01,-.01],[.03,-.02]],dtype=np.float32)).astype(np.float32),
    'tiny_finite':np.array([[-1e-35,2e-35],[1e-35,-2e-35]],dtype=np.float32),
    'constant_offset':np.full((4,2),10000,dtype=np.float32),
}
for name,raw in examples.items():
    x=torch.tensor(raw,requires_grad=True);a=light.tensor(raw,requires_grad=True)
    output=torch.nn.functional.batch_norm(x,None,None,training=True)
    actual=light.nn.functional.batch_norm(a,None,None,training=True)
    saved_mean=output.grad_fn._saved_result1.tolist();saved_inverse=output.grad_fn._saved_result2.tolist()
    seed=np.arange(raw.size,dtype=np.float32).reshape(raw.shape)+1
    output.backward(torch.tensor(seed));actual.backward(light.tensor(seed))
    rows.append(dict(name=name,input=raw.tolist(),native=output.detach().numpy().tolist(),actual=actual.numpy().tolist(),native_dx=x.grad.numpy().tolist(),actual_dx=a.grad.numpy().tolist(),
                     saved_native_mean=saved_mean,saved_native_inverse=saved_inverse,
                     max_abs_error=float(np.max(np.abs(output.detach().numpy()-actual.numpy())))))
report=dict(native=torch.__version__,numpy=np.__version__,rows=rows,harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Preliminary range audit; every discrepancy preserved; no passing assertion or implementation-completeness claim.')
(root/'batchnorm-range-initial.json').write_text(json.dumps(report,indent=2,allow_nan=True)+'\n');print(json.dumps(report,allow_nan=True))
