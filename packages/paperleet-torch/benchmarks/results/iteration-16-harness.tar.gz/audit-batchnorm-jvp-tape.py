from pathlib import Path
import hashlib,json,math
import torch

root=Path(__file__).parent;torch.manual_seed(1603);rows=[]
for shape in [(5,3),(2,3,4),(2,3,2,4),(2,3,2,2,3)]:
    axes=(0,*range(2,len(shape)));broadcast=(1,3,*([1]*(len(shape)-2)))
    raw=[torch.randn(shape,dtype=torch.float64),torch.randn(3,dtype=torch.float64),torch.randn(3,dtype=torch.float64)]
    directions=[torch.randn_like(value) for value in raw]
    a=[value.clone().requires_grad_() for value in [*raw,*directions]]
    b=[value.clone().requires_grad_() for value in [*raw,*directions]]
    native=lambda x,w,bias:torch.nn.functional.batch_norm(x,None,None,w,bias,training=True)
    primal,tangent=torch.func.jvp(native,tuple(a[:3]),tuple(a[3:]))
    x,w,bias,dx,dw,db=b
    detached_mean=x.detach().mean(axes,keepdim=True)
    centered=x-detached_mean
    inverse=torch.rsqrt((centered.detach()**2).mean(axes,keepdim=True)+1e-5)
    projected=dx-dx.mean(axes,keepdim=True)
    normalized=centered*inverse
    formula=(projected*inverse-centered*inverse**3*(projected*centered).mean(axes,keepdim=True))*w.reshape(broadcast)
    formula=formula+normalized*dw.reshape(broadcast)+db.reshape(broadcast)
    seed=torch.randn_like(tangent)
    left=torch.autograd.grad((tangent*seed).sum(),a,allow_unused=True)
    right=torch.autograd.grad((formula*seed).sum(),b,allow_unused=True)
    errors=[]
    for u,v,source in zip(left,right,a):
        u=torch.zeros_like(source) if u is None else u;v=torch.zeros_like(source) if v is None else v
        errors.append(float((u-v).abs().max()))
        torch.testing.assert_close(u,v,rtol=3e-12,atol=3e-12)
    torch.testing.assert_close(tangent,formula,rtol=3e-12,atol=3e-12)
    rows.append(dict(shape=shape,tangent_max_abs_error=float((tangent-formula).abs().max()),gradient_max_abs_errors=errors))
report=dict(status='success',native=torch.__version__,cases=rows,
            conclusion='Training BN JVP holds saved mean/inverse fixed on reverse tape while centered source has identity reverse derivative; a differentiable-statistics composite gives different native reverse-over-forward gradients.',
            scope='Native graph-convention audit only; no library source or performance claims.',harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(root/'batchnorm-jvp-tape-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
