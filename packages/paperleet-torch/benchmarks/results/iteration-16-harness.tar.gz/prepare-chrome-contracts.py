from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).parent;repo=Path.cwd();target=root/'chrome-contracts'
source=repo/'packages/paperleet-torch/src/paperleet_torch'
(target/'source').mkdir(parents=True,exist_ok=False);(target/'tests').mkdir()
hashes={}
for file in sorted(source.iterdir()):
    if file.suffix=='.py' or file.name in ('LICENSE','NOTICE'):
        shutil.copyfile(file,target/'source'/file.name);hashes[file.name]=hashlib.sha256(file.read_bytes()).hexdigest()
suites=['module_lifecycle','optimizer_lifecycle','conversion_modes','scheduler_lifecycle','nn_workflows','module_hooks','graph_lifecycle','tensor_hooks','numpy_inputs','construction','promotion','arithmetic','ieee','linear_wasm','batchnorm']
tests={}
for name in suites:
    file=repo/f'packages/paperleet-torch/tests/test_{name}.py'
    shutil.copyfile(file,target/'tests'/file.name);tests[file.name]=hashlib.sha256(file.read_bytes()).hexdigest()
(target/'plan.json').write_text(json.dumps(dict(version='0.16.0',source=hashes,tests=tests,expected=265),indent=2)+'\n')
print(json.dumps(dict(package_files=len(hashes),suites=len(tests))))
