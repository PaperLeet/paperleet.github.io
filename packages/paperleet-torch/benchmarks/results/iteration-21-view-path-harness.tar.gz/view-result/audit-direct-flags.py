from pathlib import Path
import argparse,itertools,json,warnings,numpy as np
import torch as native
import paperleet_torch
from paperleet_torch import torch
parser=argparse.ArgumentParser();parser.add_argument('--output',required=True);args=parser.parse_args()
rows=[]
with warnings.catch_warnings():
 warnings.simplefilter('ignore')
 for initial,recording,assignment in itertools.product([False,True],[False,True],[True,False,1,None]):
  row=dict(initial=initial,recording=recording,assignment=assignment)
  for label,api in [('native',native),('light',torch)]:
   base=api.from_numpy(np.arange(3.)).requires_grad_(initial)
   with api.set_grad_enabled(recording):view=base.view(3)
   try:
    view.requires_grad=assignment
    out=view.square().sum()
    if out.requires_grad:out.backward()
    row[label]=dict(flag=view.requires_grad,leaf=view.is_leaf,base_grad=None if base.grad is None else base.grad.tolist(),view_grad=None if view.grad is None else view.grad.tolist())
   except Exception as error:row[label]=dict(error=type(error).__name__)
  rows.append(row)
report=dict(cases=len(rows),differences=sum(x['native']!=x['light'] for x in rows),rows=rows,library_source=paperleet_torch.__file__,native_source=native.__file__)
Path(args.output).write_text(json.dumps(report,indent=2)+'\n');print('Direct flag assignment:',report['differences'],'differences /',report['cases'])
assert report['differences']==0
